(function(){"use strict";var Lo=`{
  "packId": "fictional-eight-01",
  "schemaVersion": "1.0.0",
  "players": [
    {
      "playerId": "p001",
      "name": "Ulen Elmcroft",
      "birthDate": "2006-01-24",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 55,
          "timing": 53,
          "power": 49,
          "rotation": 35,
          "vsPace": 58,
          "vsSpin": 47,
          "control": 23,
          "movement": 20,
          "variation": 40,
          "stamina": 35,
          "catching": 63,
          "groundFielding": 48,
          "throwing": 50,
          "keeping": 78
        },
        "ODI": {
          "defence": 42,
          "timing": 39,
          "power": 53,
          "rotation": 55,
          "vsPace": 46,
          "vsSpin": 54,
          "control": 16,
          "movement": 42,
          "variation": 23,
          "stamina": 37,
          "catching": 57,
          "groundFielding": 64,
          "throwing": 71,
          "keeping": 82
        },
        "RED_BALL": {
          "defence": 68,
          "timing": 59,
          "power": 41,
          "rotation": 57,
          "vsPace": 57,
          "vsSpin": 43,
          "control": 33,
          "movement": 20,
          "variation": 37,
          "stamina": 23,
          "catching": 41,
          "groundFielding": 54,
          "throwing": 52,
          "keeping": 78
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        769,
        543,
        812,
        249,
        256,
        943,
        996,
        930
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p002",
      "name": "Caro Harden",
      "birthDate": "1999-12-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 47,
          "power": 39,
          "rotation": 45,
          "vsPace": 40,
          "vsSpin": 40,
          "control": 15,
          "movement": 24,
          "variation": 38,
          "stamina": 36,
          "catching": 70,
          "groundFielding": 47,
          "throwing": 67,
          "keeping": 70
        },
        "ODI": {
          "defence": 56,
          "timing": 54,
          "power": 61,
          "rotation": 45,
          "vsPace": 35,
          "vsSpin": 36,
          "control": 26,
          "movement": 23,
          "variation": 32,
          "stamina": 22,
          "catching": 46,
          "groundFielding": 48,
          "throwing": 69,
          "keeping": 70
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 54,
          "power": 52,
          "rotation": 34,
          "vsPace": 50,
          "vsSpin": 37,
          "control": 19,
          "movement": 24,
          "variation": 13,
          "stamina": 31,
          "catching": 55,
          "groundFielding": 50,
          "throwing": 71,
          "keeping": 80
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        626,
        792,
        596,
        535,
        453,
        701,
        994,
        207
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p003",
      "name": "Talor Elmholt",
      "birthDate": "1988-07-28",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 49,
          "timing": 31,
          "power": 34,
          "rotation": 36,
          "vsPace": 30,
          "vsSpin": 34,
          "control": 64,
          "movement": 73,
          "variation": 62,
          "stamina": 56,
          "catching": 49,
          "groundFielding": 45,
          "throwing": 62,
          "keeping": 27
        },
        "ODI": {
          "defence": 30,
          "timing": 25,
          "power": 27,
          "rotation": 46,
          "vsPace": 36,
          "vsSpin": 40,
          "control": 64,
          "movement": 64,
          "variation": 69,
          "stamina": 78,
          "catching": 63,
          "groundFielding": 64,
          "throwing": 67,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 36,
          "timing": 43,
          "power": 26,
          "rotation": 41,
          "vsPace": 20,
          "vsSpin": 22,
          "control": 55,
          "movement": 58,
          "variation": 77,
          "stamina": 68,
          "catching": 68,
          "groundFielding": 42,
          "throwing": 56,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        650,
        907,
        747,
        833,
        478,
        405,
        619,
        846
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p004",
      "name": "Fenn Glenthorne",
      "birthDate": "1999-08-07",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 32,
          "timing": 40,
          "power": 29,
          "rotation": 19,
          "vsPace": 29,
          "vsSpin": 33,
          "control": 62,
          "movement": 79,
          "variation": 51,
          "stamina": 71,
          "catching": 58,
          "groundFielding": 62,
          "throwing": 69,
          "keeping": 34
        },
        "ODI": {
          "defence": 22,
          "timing": 46,
          "power": 34,
          "rotation": 19,
          "vsPace": 30,
          "vsSpin": 34,
          "control": 73,
          "movement": 56,
          "variation": 50,
          "stamina": 61,
          "catching": 49,
          "groundFielding": 54,
          "throwing": 60,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 50,
          "timing": 35,
          "power": 18,
          "rotation": 25,
          "vsPace": 39,
          "vsSpin": 37,
          "control": 63,
          "movement": 61,
          "variation": 74,
          "stamina": 60,
          "catching": 47,
          "groundFielding": 43,
          "throwing": 64,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        757,
        461,
        833,
        706,
        622,
        326,
        818,
        927
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p005",
      "name": "Arven Valebridge",
      "birthDate": "2007-07-01",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 28,
          "timing": 21,
          "power": 53,
          "rotation": 45,
          "vsPace": 45,
          "vsSpin": 37,
          "control": 80,
          "movement": 74,
          "variation": 69,
          "stamina": 50,
          "catching": 40,
          "groundFielding": 58,
          "throwing": 55,
          "keeping": 11
        },
        "ODI": {
          "defence": 35,
          "timing": 45,
          "power": 39,
          "rotation": 38,
          "vsPace": 24,
          "vsSpin": 47,
          "control": 76,
          "movement": 79,
          "variation": 54,
          "stamina": 61,
          "catching": 47,
          "groundFielding": 40,
          "throwing": 47,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 28,
          "timing": 45,
          "power": 20,
          "rotation": 37,
          "vsPace": 49,
          "vsSpin": 26,
          "control": 73,
          "movement": 77,
          "variation": 61,
          "stamina": 77,
          "catching": 66,
          "groundFielding": 62,
          "throwing": 62,
          "keeping": 12
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        307,
        372,
        469,
        256,
        638,
        703,
        520,
        273
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p006",
      "name": "Halen Normere",
      "birthDate": "1995-05-07",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 22,
          "timing": 46,
          "power": 42,
          "rotation": 49,
          "vsPace": 39,
          "vsSpin": 35,
          "control": 62,
          "movement": 69,
          "variation": 62,
          "stamina": 69,
          "catching": 41,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 29
        },
        "ODI": {
          "defence": 38,
          "timing": 23,
          "power": 49,
          "rotation": 26,
          "vsPace": 30,
          "vsSpin": 31,
          "control": 54,
          "movement": 66,
          "variation": 60,
          "stamina": 69,
          "catching": 61,
          "groundFielding": 41,
          "throwing": 53,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 41,
          "timing": 28,
          "power": 20,
          "rotation": 28,
          "vsPace": 45,
          "vsSpin": 33,
          "control": 60,
          "movement": 66,
          "variation": 60,
          "stamina": 65,
          "catching": 51,
          "groundFielding": 65,
          "throwing": 69,
          "keeping": 30
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        906,
        645,
        484,
        377,
        657,
        740,
        737,
        339
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p007",
      "name": "Sela Sablestone",
      "birthDate": "2002-06-18",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 46,
          "timing": 38,
          "power": 46,
          "rotation": 34,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 75,
          "movement": 71,
          "variation": 64,
          "stamina": 73,
          "catching": 59,
          "groundFielding": 39,
          "throwing": 61,
          "keeping": 12
        },
        "ODI": {
          "defence": 29,
          "timing": 32,
          "power": 40,
          "rotation": 27,
          "vsPace": 24,
          "vsSpin": 26,
          "control": 78,
          "movement": 54,
          "variation": 56,
          "stamina": 70,
          "catching": 56,
          "groundFielding": 48,
          "throwing": 48,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 46,
          "timing": 48,
          "power": 35,
          "rotation": 35,
          "vsPace": 43,
          "vsSpin": 42,
          "control": 60,
          "movement": 60,
          "variation": 51,
          "stamina": 63,
          "catching": 52,
          "groundFielding": 42,
          "throwing": 49,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        435,
        439,
        593,
        453,
        422,
        720,
        912,
        250
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p008",
      "name": "Isen Kelholt",
      "birthDate": "1996-07-10",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 29,
          "timing": 33,
          "power": 35,
          "rotation": 23,
          "vsPace": 31,
          "vsSpin": 23,
          "control": 74,
          "movement": 75,
          "variation": 80,
          "stamina": 76,
          "catching": 42,
          "groundFielding": 40,
          "throwing": 55,
          "keeping": 25
        },
        "ODI": {
          "defence": 34,
          "timing": 22,
          "power": 20,
          "rotation": 40,
          "vsPace": 36,
          "vsSpin": 30,
          "control": 62,
          "movement": 77,
          "variation": 61,
          "stamina": 50,
          "catching": 58,
          "groundFielding": 63,
          "throwing": 64,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 22,
          "power": 24,
          "rotation": 36,
          "vsPace": 24,
          "vsSpin": 41,
          "control": 79,
          "movement": 52,
          "variation": 57,
          "stamina": 53,
          "catching": 54,
          "groundFielding": 39,
          "throwing": 62,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        301,
        977,
        683,
        544,
        561,
        755,
        997,
        769
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p009",
      "name": "Nerin Orinbridge",
      "birthDate": "1988-03-08",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 38,
          "timing": 46,
          "power": 64,
          "rotation": 48,
          "vsPace": 56,
          "vsSpin": 52,
          "control": 55,
          "movement": 58,
          "variation": 53,
          "stamina": 43,
          "catching": 52,
          "groundFielding": 44,
          "throwing": 70,
          "keeping": 40
        },
        "ODI": {
          "defence": 39,
          "timing": 53,
          "power": 59,
          "rotation": 43,
          "vsPace": 48,
          "vsSpin": 52,
          "control": 61,
          "movement": 67,
          "variation": 43,
          "stamina": 47,
          "catching": 45,
          "groundFielding": 72,
          "throwing": 63,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 51,
          "power": 46,
          "rotation": 47,
          "vsPace": 41,
          "vsSpin": 43,
          "control": 63,
          "movement": 51,
          "variation": 51,
          "stamina": 62,
          "catching": 52,
          "groundFielding": 56,
          "throwing": 56,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        760,
        392,
        574,
        472,
        422,
        243,
        293,
        872
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p010",
      "name": "Zerin Sablebrook",
      "birthDate": "2003-05-22",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 38,
          "timing": 38,
          "power": 68,
          "rotation": 42,
          "vsPace": 48,
          "vsSpin": 53,
          "control": 55,
          "movement": 60,
          "variation": 52,
          "stamina": 56,
          "catching": 71,
          "groundFielding": 54,
          "throwing": 43,
          "keeping": 40
        },
        "ODI": {
          "defence": 68,
          "timing": 49,
          "power": 51,
          "rotation": 40,
          "vsPace": 54,
          "vsSpin": 48,
          "control": 62,
          "movement": 37,
          "variation": 38,
          "stamina": 48,
          "catching": 65,
          "groundFielding": 72,
          "throwing": 42,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 54,
          "timing": 51,
          "power": 39,
          "rotation": 56,
          "vsPace": 64,
          "vsSpin": 47,
          "control": 57,
          "movement": 48,
          "variation": 37,
          "stamina": 54,
          "catching": 67,
          "groundFielding": 71,
          "throwing": 61,
          "keeping": 25
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        763,
        267,
        604,
        292,
        768,
        345,
        424,
        560
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p011",
      "name": "Fenn Jorthorne",
      "birthDate": "2007-11-18",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 43,
          "power": 58,
          "rotation": 41,
          "vsPace": 38,
          "vsSpin": 65,
          "control": 45,
          "movement": 58,
          "variation": 59,
          "stamina": 37,
          "catching": 72,
          "groundFielding": 69,
          "throwing": 51,
          "keeping": 12
        },
        "ODI": {
          "defence": 49,
          "timing": 39,
          "power": 67,
          "rotation": 46,
          "vsPace": 61,
          "vsSpin": 55,
          "control": 37,
          "movement": 61,
          "variation": 41,
          "stamina": 46,
          "catching": 62,
          "groundFielding": 60,
          "throwing": 66,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 46,
          "power": 35,
          "rotation": 50,
          "vsPace": 45,
          "vsSpin": 39,
          "control": 53,
          "movement": 45,
          "variation": 49,
          "stamina": 37,
          "catching": 51,
          "groundFielding": 59,
          "throwing": 68,
          "keeping": 32
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        610,
        352,
        658,
        987,
        637,
        873,
        208,
        224
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p012",
      "name": "Elio Ashbrook",
      "birthDate": "1997-12-28",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 58,
          "timing": 63,
          "power": 59,
          "rotation": 53,
          "vsPace": 61,
          "vsSpin": 54,
          "control": 43,
          "movement": 19,
          "variation": 28,
          "stamina": 19,
          "catching": 58,
          "groundFielding": 43,
          "throwing": 41,
          "keeping": 17
        },
        "ODI": {
          "defence": 54,
          "timing": 69,
          "power": 58,
          "rotation": 66,
          "vsPace": 55,
          "vsSpin": 62,
          "control": 30,
          "movement": 33,
          "variation": 17,
          "stamina": 27,
          "catching": 54,
          "groundFielding": 45,
          "throwing": 63,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 66,
          "timing": 70,
          "power": 71,
          "rotation": 74,
          "vsPace": 61,
          "vsSpin": 51,
          "control": 14,
          "movement": 39,
          "variation": 32,
          "stamina": 35,
          "catching": 62,
          "groundFielding": 51,
          "throwing": 38,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        809,
        987,
        357,
        874,
        249,
        843,
        813,
        950
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p013",
      "name": "Quill Sablebridge",
      "birthDate": "1994-04-18",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 75,
          "timing": 64,
          "power": 55,
          "rotation": 59,
          "vsPace": 64,
          "vsSpin": 76,
          "control": 16,
          "movement": 29,
          "variation": 28,
          "stamina": 23,
          "catching": 65,
          "groundFielding": 64,
          "throwing": 46,
          "keeping": 26
        },
        "ODI": {
          "defence": 77,
          "timing": 57,
          "power": 76,
          "rotation": 72,
          "vsPace": 68,
          "vsSpin": 52,
          "control": 19,
          "movement": 17,
          "variation": 26,
          "stamina": 30,
          "catching": 46,
          "groundFielding": 51,
          "throwing": 43,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 71,
          "power": 55,
          "rotation": 54,
          "vsPace": 74,
          "vsSpin": 67,
          "control": 21,
          "movement": 38,
          "variation": 38,
          "stamina": 25,
          "catching": 60,
          "groundFielding": 57,
          "throwing": 60,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        552,
        929,
        640,
        875,
        271,
        354,
        860,
        670
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p014",
      "name": "Nave Elmford",
      "birthDate": "1991-01-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 70,
          "timing": 80,
          "power": 74,
          "rotation": 67,
          "vsPace": 68,
          "vsSpin": 77,
          "control": 32,
          "movement": 21,
          "variation": 27,
          "stamina": 29,
          "catching": 40,
          "groundFielding": 48,
          "throwing": 53,
          "keeping": 15
        },
        "ODI": {
          "defence": 74,
          "timing": 78,
          "power": 64,
          "rotation": 74,
          "vsPace": 80,
          "vsSpin": 73,
          "control": 23,
          "movement": 24,
          "variation": 44,
          "stamina": 41,
          "catching": 43,
          "groundFielding": 57,
          "throwing": 66,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 59,
          "power": 65,
          "rotation": 63,
          "vsPace": 56,
          "vsSpin": 68,
          "control": 38,
          "movement": 33,
          "variation": 26,
          "stamina": 41,
          "catching": 64,
          "groundFielding": 41,
          "throwing": 38,
          "keeping": 25
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        249,
        795,
        989,
        996,
        471,
        606,
        638,
        740
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p015",
      "name": "Eren Ashstead",
      "birthDate": "1988-05-06",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 55,
          "power": 59,
          "rotation": 52,
          "vsPace": 65,
          "vsSpin": 60,
          "control": 40,
          "movement": 34,
          "variation": 27,
          "stamina": 38,
          "catching": 51,
          "groundFielding": 59,
          "throwing": 59,
          "keeping": 19
        },
        "ODI": {
          "defence": 61,
          "timing": 56,
          "power": 64,
          "rotation": 52,
          "vsPace": 54,
          "vsSpin": 67,
          "control": 36,
          "movement": 37,
          "variation": 26,
          "stamina": 42,
          "catching": 63,
          "groundFielding": 40,
          "throwing": 56,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 50,
          "power": 55,
          "rotation": 63,
          "vsPace": 79,
          "vsSpin": 62,
          "control": 29,
          "movement": 18,
          "variation": 40,
          "stamina": 29,
          "catching": 37,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        305,
        339,
        390,
        487,
        867,
        724,
        327,
        533
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p016",
      "name": "Eren Rookholt",
      "birthDate": "2007-10-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 54,
          "power": 62,
          "rotation": 76,
          "vsPace": 78,
          "vsSpin": 69,
          "control": 24,
          "movement": 23,
          "variation": 40,
          "stamina": 19,
          "catching": 54,
          "groundFielding": 59,
          "throwing": 39,
          "keeping": 21
        },
        "ODI": {
          "defence": 50,
          "timing": 71,
          "power": 59,
          "rotation": 62,
          "vsPace": 51,
          "vsSpin": 69,
          "control": 37,
          "movement": 29,
          "variation": 19,
          "stamina": 34,
          "catching": 38,
          "groundFielding": 45,
          "throwing": 57,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 77,
          "power": 60,
          "rotation": 76,
          "vsPace": 77,
          "vsSpin": 51,
          "control": 30,
          "movement": 31,
          "variation": 22,
          "stamina": 34,
          "catching": 38,
          "groundFielding": 55,
          "throwing": 50,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        254,
        646,
        361,
        756,
        972,
        341,
        803,
        293
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p017",
      "name": "Nerin Elmcroft",
      "birthDate": "1996-01-18",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 58,
          "timing": 74,
          "power": 56,
          "rotation": 53,
          "vsPace": 73,
          "vsSpin": 73,
          "control": 26,
          "movement": 36,
          "variation": 21,
          "stamina": 21,
          "catching": 49,
          "groundFielding": 52,
          "throwing": 62,
          "keeping": 30
        },
        "ODI": {
          "defence": 58,
          "timing": 79,
          "power": 55,
          "rotation": 60,
          "vsPace": 77,
          "vsSpin": 52,
          "control": 37,
          "movement": 39,
          "variation": 18,
          "stamina": 34,
          "catching": 40,
          "groundFielding": 62,
          "throwing": 47,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 75,
          "timing": 67,
          "power": 61,
          "rotation": 67,
          "vsPace": 74,
          "vsSpin": 69,
          "control": 43,
          "movement": 42,
          "variation": 30,
          "stamina": 14,
          "catching": 45,
          "groundFielding": 54,
          "throwing": 61,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        470,
        461,
        260,
        560,
        430,
        410,
        792,
        532
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p018",
      "name": "Yoran Pellbrook",
      "birthDate": "1994-01-23",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 63,
          "power": 59,
          "rotation": 67,
          "vsPace": 74,
          "vsSpin": 79,
          "control": 25,
          "movement": 33,
          "variation": 40,
          "stamina": 26,
          "catching": 53,
          "groundFielding": 51,
          "throwing": 45,
          "keeping": 16
        },
        "ODI": {
          "defence": 68,
          "timing": 58,
          "power": 50,
          "rotation": 50,
          "vsPace": 73,
          "vsSpin": 66,
          "control": 25,
          "movement": 41,
          "variation": 29,
          "stamina": 44,
          "catching": 48,
          "groundFielding": 48,
          "throwing": 39,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 52,
          "power": 53,
          "rotation": 77,
          "vsPace": 75,
          "vsSpin": 64,
          "control": 27,
          "movement": 15,
          "variation": 21,
          "stamina": 26,
          "catching": 44,
          "groundFielding": 50,
          "throwing": 40,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        738,
        743,
        243,
        780,
        627,
        438,
        793,
        662
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p019",
      "name": "Yoran Harridge",
      "birthDate": "2004-12-01",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 70,
          "timing": 50,
          "power": 56,
          "rotation": 58,
          "vsPace": 59,
          "vsSpin": 50,
          "control": 30,
          "movement": 18,
          "variation": 20,
          "stamina": 44,
          "catching": 53,
          "groundFielding": 50,
          "throwing": 48,
          "keeping": 16
        },
        "ODI": {
          "defence": 51,
          "timing": 78,
          "power": 69,
          "rotation": 76,
          "vsPace": 77,
          "vsSpin": 50,
          "control": 24,
          "movement": 20,
          "variation": 28,
          "stamina": 32,
          "catching": 62,
          "groundFielding": 54,
          "throwing": 67,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 57,
          "timing": 79,
          "power": 54,
          "rotation": 65,
          "vsPace": 63,
          "vsSpin": 74,
          "control": 27,
          "movement": 44,
          "variation": 23,
          "stamina": 16,
          "catching": 59,
          "groundFielding": 57,
          "throwing": 51,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        829,
        413,
        737,
        576,
        955,
        951,
        844,
        913
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p020",
      "name": "Galen Zornden",
      "birthDate": "2002-08-20",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 53,
          "power": 80,
          "rotation": 73,
          "vsPace": 76,
          "vsSpin": 80,
          "control": 38,
          "movement": 41,
          "variation": 37,
          "stamina": 33,
          "catching": 50,
          "groundFielding": 45,
          "throwing": 50,
          "keeping": 31
        },
        "ODI": {
          "defence": 56,
          "timing": 80,
          "power": 74,
          "rotation": 80,
          "vsPace": 78,
          "vsSpin": 51,
          "control": 31,
          "movement": 34,
          "variation": 37,
          "stamina": 28,
          "catching": 60,
          "groundFielding": 49,
          "throwing": 48,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 78,
          "timing": 76,
          "power": 63,
          "rotation": 64,
          "vsPace": 57,
          "vsSpin": 68,
          "control": 31,
          "movement": 30,
          "variation": 14,
          "stamina": 32,
          "catching": 44,
          "groundFielding": 40,
          "throwing": 61,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        437,
        997,
        413,
        917,
        402,
        660,
        705,
        463
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p021",
      "name": "Walen Sableholt",
      "birthDate": "1997-12-15",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 36,
          "power": 41,
          "rotation": 56,
          "vsPace": 51,
          "vsSpin": 58,
          "control": 42,
          "movement": 31,
          "variation": 29,
          "stamina": 12,
          "catching": 56,
          "groundFielding": 58,
          "throwing": 57,
          "keeping": 73
        },
        "ODI": {
          "defence": 61,
          "timing": 37,
          "power": 63,
          "rotation": 53,
          "vsPace": 39,
          "vsSpin": 64,
          "control": 35,
          "movement": 42,
          "variation": 13,
          "stamina": 41,
          "catching": 69,
          "groundFielding": 65,
          "throwing": 45,
          "keeping": 80
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 55,
          "power": 43,
          "rotation": 42,
          "vsPace": 55,
          "vsSpin": 45,
          "control": 19,
          "movement": 14,
          "variation": 17,
          "stamina": 20,
          "catching": 48,
          "groundFielding": 66,
          "throwing": 52,
          "keeping": 76
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        691,
        484,
        492,
        590,
        991,
        255,
        476,
        877
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p022",
      "name": "Ulen Wrenthorne",
      "birthDate": "1998-06-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 54,
          "power": 60,
          "rotation": 40,
          "vsPace": 64,
          "vsSpin": 55,
          "control": 42,
          "movement": 13,
          "variation": 26,
          "stamina": 20,
          "catching": 45,
          "groundFielding": 62,
          "throwing": 41,
          "keeping": 56
        },
        "ODI": {
          "defence": 41,
          "timing": 58,
          "power": 48,
          "rotation": 34,
          "vsPace": 60,
          "vsSpin": 35,
          "control": 21,
          "movement": 38,
          "variation": 13,
          "stamina": 31,
          "catching": 66,
          "groundFielding": 44,
          "throwing": 44,
          "keeping": 59
        },
        "RED_BALL": {
          "defence": 51,
          "timing": 41,
          "power": 56,
          "rotation": 40,
          "vsPace": 60,
          "vsSpin": 54,
          "control": 25,
          "movement": 17,
          "variation": 17,
          "stamina": 13,
          "catching": 48,
          "groundFielding": 69,
          "throwing": 51,
          "keeping": 78
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        598,
        605,
        697,
        615,
        410,
        240,
        621,
        805
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p023",
      "name": "Pavan Zornstone",
      "birthDate": "2003-11-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 39,
          "timing": 48,
          "power": 39,
          "rotation": 32,
          "vsPace": 47,
          "vsSpin": 30,
          "control": 66,
          "movement": 77,
          "variation": 67,
          "stamina": 60,
          "catching": 65,
          "groundFielding": 52,
          "throwing": 62,
          "keeping": 24
        },
        "ODI": {
          "defence": 28,
          "timing": 29,
          "power": 24,
          "rotation": 36,
          "vsPace": 45,
          "vsSpin": 31,
          "control": 73,
          "movement": 74,
          "variation": 52,
          "stamina": 78,
          "catching": 63,
          "groundFielding": 52,
          "throwing": 68,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 27,
          "timing": 19,
          "power": 32,
          "rotation": 40,
          "vsPace": 24,
          "vsSpin": 48,
          "control": 64,
          "movement": 67,
          "variation": 61,
          "stamina": 76,
          "catching": 67,
          "groundFielding": 42,
          "throwing": 49,
          "keeping": 18
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        708,
        357,
        237,
        752,
        382,
        449,
        761,
        542
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p024",
      "name": "Rilan Rookfield",
      "birthDate": "2005-05-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 25,
          "timing": 37,
          "power": 30,
          "rotation": 22,
          "vsPace": 28,
          "vsSpin": 48,
          "control": 72,
          "movement": 65,
          "variation": 57,
          "stamina": 70,
          "catching": 65,
          "groundFielding": 58,
          "throwing": 42,
          "keeping": 21
        },
        "ODI": {
          "defence": 45,
          "timing": 24,
          "power": 34,
          "rotation": 47,
          "vsPace": 19,
          "vsSpin": 48,
          "control": 64,
          "movement": 52,
          "variation": 77,
          "stamina": 65,
          "catching": 64,
          "groundFielding": 40,
          "throwing": 69,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 27,
          "timing": 40,
          "power": 27,
          "rotation": 46,
          "vsPace": 48,
          "vsSpin": 19,
          "control": 55,
          "movement": 53,
          "variation": 50,
          "stamina": 80,
          "catching": 63,
          "groundFielding": 55,
          "throwing": 48,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        584,
        917,
        279,
        473,
        646,
        402,
        706,
        403
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p025",
      "name": "Zerin Wrenbrook",
      "birthDate": "1990-07-28",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 32,
          "timing": 20,
          "power": 34,
          "rotation": 35,
          "vsPace": 35,
          "vsSpin": 48,
          "control": 57,
          "movement": 65,
          "variation": 67,
          "stamina": 52,
          "catching": 50,
          "groundFielding": 45,
          "throwing": 40,
          "keeping": 29
        },
        "ODI": {
          "defence": 31,
          "timing": 37,
          "power": 42,
          "rotation": 19,
          "vsPace": 31,
          "vsSpin": 39,
          "control": 70,
          "movement": 69,
          "variation": 53,
          "stamina": 73,
          "catching": 41,
          "groundFielding": 55,
          "throwing": 52,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 31,
          "timing": 23,
          "power": 29,
          "rotation": 40,
          "vsPace": 40,
          "vsSpin": 39,
          "control": 56,
          "movement": 50,
          "variation": 71,
          "stamina": 50,
          "catching": 42,
          "groundFielding": 65,
          "throwing": 53,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        657,
        773,
        958,
        885,
        245,
        815,
        766,
        513
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p026",
      "name": "Borin Zornbrook",
      "birthDate": "1998-06-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 27,
          "timing": 36,
          "power": 25,
          "rotation": 49,
          "vsPace": 37,
          "vsSpin": 27,
          "control": 50,
          "movement": 78,
          "variation": 53,
          "stamina": 56,
          "catching": 65,
          "groundFielding": 42,
          "throwing": 49,
          "keeping": 41
        },
        "ODI": {
          "defence": 46,
          "timing": 43,
          "power": 33,
          "rotation": 25,
          "vsPace": 20,
          "vsSpin": 31,
          "control": 68,
          "movement": 54,
          "variation": 77,
          "stamina": 59,
          "catching": 48,
          "groundFielding": 57,
          "throwing": 56,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 28,
          "timing": 35,
          "power": 38,
          "rotation": 23,
          "vsPace": 28,
          "vsSpin": 33,
          "control": 63,
          "movement": 67,
          "variation": 55,
          "stamina": 63,
          "catching": 53,
          "groundFielding": 63,
          "throwing": 60,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        230,
        311,
        805,
        559,
        449,
        768,
        803,
        604
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p027",
      "name": "Jora Mossridge",
      "birthDate": "1988-08-21",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 44,
          "power": 41,
          "rotation": 22,
          "vsPace": 42,
          "vsSpin": 32,
          "control": 52,
          "movement": 76,
          "variation": 70,
          "stamina": 60,
          "catching": 55,
          "groundFielding": 59,
          "throwing": 51,
          "keeping": 31
        },
        "ODI": {
          "defence": 27,
          "timing": 39,
          "power": 47,
          "rotation": 26,
          "vsPace": 49,
          "vsSpin": 44,
          "control": 55,
          "movement": 58,
          "variation": 53,
          "stamina": 50,
          "catching": 49,
          "groundFielding": 60,
          "throwing": 47,
          "keeping": 34
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 34,
          "power": 36,
          "rotation": 38,
          "vsPace": 30,
          "vsSpin": 37,
          "control": 63,
          "movement": 76,
          "variation": 75,
          "stamina": 63,
          "catching": 42,
          "groundFielding": 45,
          "throwing": 43,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        685,
        344,
        907,
        538,
        521,
        813,
        493,
        981
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p028",
      "name": "Quill Ternstead",
      "birthDate": "1992-12-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 20,
          "timing": 28,
          "power": 41,
          "rotation": 33,
          "vsPace": 38,
          "vsSpin": 19,
          "control": 58,
          "movement": 69,
          "variation": 76,
          "stamina": 67,
          "catching": 46,
          "groundFielding": 60,
          "throwing": 58,
          "keeping": 38
        },
        "ODI": {
          "defence": 47,
          "timing": 31,
          "power": 25,
          "rotation": 40,
          "vsPace": 26,
          "vsSpin": 40,
          "control": 50,
          "movement": 78,
          "variation": 72,
          "stamina": 75,
          "catching": 48,
          "groundFielding": 52,
          "throwing": 65,
          "keeping": 27
        },
        "RED_BALL": {
          "defence": 44,
          "timing": 47,
          "power": 37,
          "rotation": 24,
          "vsPace": 19,
          "vsSpin": 22,
          "control": 69,
          "movement": 68,
          "variation": 54,
          "stamina": 54,
          "catching": 68,
          "groundFielding": 42,
          "throwing": 59,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        736,
        772,
        877,
        718,
        401,
        406,
        386,
        736
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p029",
      "name": "Leron Briarstone",
      "birthDate": "2003-01-02",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 47,
          "power": 49,
          "rotation": 59,
          "vsPace": 48,
          "vsSpin": 49,
          "control": 41,
          "movement": 64,
          "variation": 60,
          "stamina": 64,
          "catching": 54,
          "groundFielding": 49,
          "throwing": 54,
          "keeping": 32
        },
        "ODI": {
          "defence": 66,
          "timing": 51,
          "power": 45,
          "rotation": 43,
          "vsPace": 54,
          "vsSpin": 62,
          "control": 45,
          "movement": 44,
          "variation": 50,
          "stamina": 47,
          "catching": 53,
          "groundFielding": 51,
          "throwing": 55,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 55,
          "timing": 65,
          "power": 48,
          "rotation": 49,
          "vsPace": 46,
          "vsSpin": 56,
          "control": 50,
          "movement": 57,
          "variation": 67,
          "stamina": 58,
          "catching": 55,
          "groundFielding": 64,
          "throwing": 66,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        904,
        606,
        465,
        429,
        811,
        658,
        919,
        529
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p030",
      "name": "Rilan Jorfield",
      "birthDate": "1999-05-05",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 48,
          "timing": 38,
          "power": 61,
          "rotation": 46,
          "vsPace": 50,
          "vsSpin": 58,
          "control": 46,
          "movement": 58,
          "variation": 65,
          "stamina": 52,
          "catching": 68,
          "groundFielding": 44,
          "throwing": 59,
          "keeping": 18
        },
        "ODI": {
          "defence": 57,
          "timing": 48,
          "power": 49,
          "rotation": 66,
          "vsPace": 58,
          "vsSpin": 41,
          "control": 65,
          "movement": 54,
          "variation": 60,
          "stamina": 47,
          "catching": 63,
          "groundFielding": 67,
          "throwing": 55,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 49,
          "timing": 65,
          "power": 35,
          "rotation": 44,
          "vsPace": 52,
          "vsSpin": 50,
          "control": 52,
          "movement": 53,
          "variation": 50,
          "stamina": 58,
          "catching": 62,
          "groundFielding": 55,
          "throwing": 58,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        842,
        423,
        606,
        680,
        454,
        661,
        759,
        226
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p031",
      "name": "Elio Valethorne",
      "birthDate": "1995-08-25",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 45,
          "power": 46,
          "rotation": 58,
          "vsPace": 38,
          "vsSpin": 38,
          "control": 62,
          "movement": 66,
          "variation": 67,
          "stamina": 58,
          "catching": 45,
          "groundFielding": 69,
          "throwing": 57,
          "keeping": 21
        },
        "ODI": {
          "defence": 65,
          "timing": 63,
          "power": 65,
          "rotation": 41,
          "vsPace": 40,
          "vsSpin": 60,
          "control": 52,
          "movement": 57,
          "variation": 45,
          "stamina": 43,
          "catching": 65,
          "groundFielding": 48,
          "throwing": 65,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 68,
          "timing": 38,
          "power": 59,
          "rotation": 62,
          "vsPace": 64,
          "vsSpin": 66,
          "control": 58,
          "movement": 44,
          "variation": 54,
          "stamina": 52,
          "catching": 45,
          "groundFielding": 68,
          "throwing": 53,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        806,
        641,
        284,
        837,
        960,
        505,
        380,
        216
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p032",
      "name": "Ari Mossbridge",
      "birthDate": "1992-04-18",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 63,
          "power": 62,
          "rotation": 60,
          "vsPace": 51,
          "vsSpin": 50,
          "control": 18,
          "movement": 33,
          "variation": 35,
          "stamina": 30,
          "catching": 58,
          "groundFielding": 56,
          "throwing": 61,
          "keeping": 18
        },
        "ODI": {
          "defence": 58,
          "timing": 72,
          "power": 68,
          "rotation": 60,
          "vsPace": 62,
          "vsSpin": 60,
          "control": 19,
          "movement": 34,
          "variation": 15,
          "stamina": 22,
          "catching": 51,
          "groundFielding": 65,
          "throwing": 45,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 66,
          "power": 52,
          "rotation": 77,
          "vsPace": 80,
          "vsSpin": 57,
          "control": 15,
          "movement": 41,
          "variation": 33,
          "stamina": 18,
          "catching": 60,
          "groundFielding": 58,
          "throwing": 47,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        627,
        857,
        373,
        300,
        225,
        798,
        405,
        627
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p033",
      "name": "Vero Glenthorne",
      "birthDate": "1991-04-10",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 76,
          "timing": 62,
          "power": 68,
          "rotation": 73,
          "vsPace": 57,
          "vsSpin": 74,
          "control": 29,
          "movement": 20,
          "variation": 43,
          "stamina": 25,
          "catching": 57,
          "groundFielding": 59,
          "throwing": 61,
          "keeping": 25
        },
        "ODI": {
          "defence": 53,
          "timing": 76,
          "power": 77,
          "rotation": 70,
          "vsPace": 63,
          "vsSpin": 58,
          "control": 29,
          "movement": 20,
          "variation": 42,
          "stamina": 44,
          "catching": 44,
          "groundFielding": 42,
          "throwing": 50,
          "keeping": 41
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 67,
          "power": 75,
          "rotation": 57,
          "vsPace": 62,
          "vsSpin": 64,
          "control": 24,
          "movement": 21,
          "variation": 37,
          "stamina": 28,
          "catching": 48,
          "groundFielding": 54,
          "throwing": 66,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        362,
        821,
        415,
        466,
        660,
        589,
        420,
        203
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p034",
      "name": "Isen Ternfell",
      "birthDate": "2001-07-20",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 64,
          "power": 68,
          "rotation": 54,
          "vsPace": 67,
          "vsSpin": 78,
          "control": 15,
          "movement": 33,
          "variation": 31,
          "stamina": 39,
          "catching": 50,
          "groundFielding": 56,
          "throwing": 53,
          "keeping": 11
        },
        "ODI": {
          "defence": 60,
          "timing": 68,
          "power": 54,
          "rotation": 52,
          "vsPace": 72,
          "vsSpin": 62,
          "control": 34,
          "movement": 23,
          "variation": 16,
          "stamina": 17,
          "catching": 48,
          "groundFielding": 46,
          "throwing": 59,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 59,
          "timing": 66,
          "power": 72,
          "rotation": 51,
          "vsPace": 65,
          "vsSpin": 80,
          "control": 16,
          "movement": 30,
          "variation": 18,
          "stamina": 33,
          "catching": 61,
          "groundFielding": 48,
          "throwing": 48,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        561,
        842,
        1000,
        382,
        426,
        520,
        249,
        916
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p035",
      "name": "Talor Pellbridge",
      "birthDate": "1996-03-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 58,
          "power": 61,
          "rotation": 63,
          "vsPace": 53,
          "vsSpin": 68,
          "control": 40,
          "movement": 23,
          "variation": 15,
          "stamina": 18,
          "catching": 38,
          "groundFielding": 42,
          "throwing": 47,
          "keeping": 13
        },
        "ODI": {
          "defence": 57,
          "timing": 70,
          "power": 55,
          "rotation": 66,
          "vsPace": 57,
          "vsSpin": 72,
          "control": 35,
          "movement": 38,
          "variation": 15,
          "stamina": 36,
          "catching": 46,
          "groundFielding": 44,
          "throwing": 50,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 53,
          "power": 66,
          "rotation": 71,
          "vsPace": 73,
          "vsSpin": 53,
          "control": 16,
          "movement": 17,
          "variation": 29,
          "stamina": 42,
          "catching": 59,
          "groundFielding": 64,
          "throwing": 46,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        276,
        713,
        500,
        665,
        875,
        299,
        367,
        263
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p036",
      "name": "Vero Jorcroft",
      "birthDate": "2007-12-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 71,
          "power": 54,
          "rotation": 77,
          "vsPace": 53,
          "vsSpin": 76,
          "control": 39,
          "movement": 40,
          "variation": 44,
          "stamina": 28,
          "catching": 37,
          "groundFielding": 44,
          "throwing": 57,
          "keeping": 21
        },
        "ODI": {
          "defence": 70,
          "timing": 68,
          "power": 73,
          "rotation": 53,
          "vsPace": 66,
          "vsSpin": 58,
          "control": 18,
          "movement": 19,
          "variation": 39,
          "stamina": 14,
          "catching": 44,
          "groundFielding": 54,
          "throwing": 44,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 64,
          "timing": 73,
          "power": 62,
          "rotation": 64,
          "vsPace": 63,
          "vsSpin": 69,
          "control": 43,
          "movement": 29,
          "variation": 20,
          "stamina": 39,
          "catching": 57,
          "groundFielding": 51,
          "throwing": 39,
          "keeping": 32
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        850,
        339,
        912,
        540,
        951,
        924,
        338,
        394
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p037",
      "name": "Walen Mosswell",
      "birthDate": "2001-09-28",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 61,
          "power": 73,
          "rotation": 62,
          "vsPace": 67,
          "vsSpin": 57,
          "control": 34,
          "movement": 43,
          "variation": 21,
          "stamina": 35,
          "catching": 42,
          "groundFielding": 39,
          "throwing": 51,
          "keeping": 34
        },
        "ODI": {
          "defence": 59,
          "timing": 61,
          "power": 51,
          "rotation": 69,
          "vsPace": 79,
          "vsSpin": 63,
          "control": 18,
          "movement": 28,
          "variation": 43,
          "stamina": 14,
          "catching": 63,
          "groundFielding": 59,
          "throwing": 63,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 83,
          "timing": 63,
          "power": 64,
          "rotation": 54,
          "vsPace": 60,
          "vsSpin": 62,
          "control": 23,
          "movement": 38,
          "variation": 21,
          "stamina": 27,
          "catching": 59,
          "groundFielding": 59,
          "throwing": 37,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        214,
        200,
        732,
        547,
        844,
        659,
        331,
        523
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p038",
      "name": "Nalo Rookfield",
      "birthDate": "1998-05-04",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 63,
          "power": 83,
          "rotation": 58,
          "vsPace": 68,
          "vsSpin": 74,
          "control": 38,
          "movement": 33,
          "variation": 14,
          "stamina": 26,
          "catching": 41,
          "groundFielding": 58,
          "throwing": 50,
          "keeping": 13
        },
        "ODI": {
          "defence": 70,
          "timing": 61,
          "power": 78,
          "rotation": 67,
          "vsPace": 76,
          "vsSpin": 73,
          "control": 18,
          "movement": 16,
          "variation": 20,
          "stamina": 21,
          "catching": 66,
          "groundFielding": 62,
          "throwing": 61,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 79,
          "timing": 70,
          "power": 72,
          "rotation": 65,
          "vsPace": 62,
          "vsSpin": 64,
          "control": 32,
          "movement": 17,
          "variation": 31,
          "stamina": 33,
          "catching": 50,
          "groundFielding": 62,
          "throwing": 42,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        896,
        650,
        511,
        581,
        589,
        936,
        411,
        727
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p039",
      "name": "Arven Rookridge",
      "birthDate": "2002-12-12",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 52,
          "power": 67,
          "rotation": 53,
          "vsPace": 58,
          "vsSpin": 55,
          "control": 39,
          "movement": 31,
          "variation": 23,
          "stamina": 33,
          "catching": 51,
          "groundFielding": 57,
          "throwing": 37,
          "keeping": 14
        },
        "ODI": {
          "defence": 66,
          "timing": 62,
          "power": 50,
          "rotation": 53,
          "vsPace": 78,
          "vsSpin": 67,
          "control": 29,
          "movement": 43,
          "variation": 32,
          "stamina": 34,
          "catching": 42,
          "groundFielding": 63,
          "throwing": 59,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 83,
          "timing": 60,
          "power": 68,
          "rotation": 56,
          "vsPace": 77,
          "vsSpin": 75,
          "control": 40,
          "movement": 42,
          "variation": 39,
          "stamina": 21,
          "catching": 40,
          "groundFielding": 44,
          "throwing": 53,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        834,
        749,
        746,
        898,
        334,
        726,
        623,
        341
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p040",
      "name": "Jora Ashholt",
      "birthDate": "1996-09-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 67,
          "power": 55,
          "rotation": 66,
          "vsPace": 58,
          "vsSpin": 62,
          "control": 27,
          "movement": 14,
          "variation": 41,
          "stamina": 21,
          "catching": 48,
          "groundFielding": 48,
          "throwing": 57,
          "keeping": 31
        },
        "ODI": {
          "defence": 62,
          "timing": 78,
          "power": 79,
          "rotation": 52,
          "vsPace": 66,
          "vsSpin": 75,
          "control": 42,
          "movement": 30,
          "variation": 20,
          "stamina": 25,
          "catching": 67,
          "groundFielding": 40,
          "throwing": 66,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 76,
          "power": 64,
          "rotation": 62,
          "vsPace": 58,
          "vsSpin": 57,
          "control": 43,
          "movement": 43,
          "variation": 28,
          "stamina": 42,
          "catching": 46,
          "groundFielding": 64,
          "throwing": 41,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        930,
        412,
        455,
        976,
        691,
        811,
        208,
        872
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p041",
      "name": "Nave Glenthorne",
      "birthDate": "1988-01-02",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 47,
          "timing": 42,
          "power": 51,
          "rotation": 60,
          "vsPace": 38,
          "vsSpin": 40,
          "control": 12,
          "movement": 39,
          "variation": 26,
          "stamina": 14,
          "catching": 57,
          "groundFielding": 48,
          "throwing": 49,
          "keeping": 60
        },
        "ODI": {
          "defence": 37,
          "timing": 47,
          "power": 49,
          "rotation": 43,
          "vsPace": 63,
          "vsSpin": 44,
          "control": 28,
          "movement": 32,
          "variation": 40,
          "stamina": 28,
          "catching": 69,
          "groundFielding": 54,
          "throwing": 55,
          "keeping": 82
        },
        "RED_BALL": {
          "defence": 60,
          "timing": 45,
          "power": 45,
          "rotation": 34,
          "vsPace": 58,
          "vsSpin": 62,
          "control": 12,
          "movement": 34,
          "variation": 13,
          "stamina": 12,
          "catching": 71,
          "groundFielding": 66,
          "throwing": 43,
          "keeping": 71
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        554,
        322,
        981,
        809,
        689,
        395,
        238,
        434
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p042",
      "name": "Nave Harridge",
      "birthDate": "2007-03-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 54,
          "power": 60,
          "rotation": 45,
          "vsPace": 62,
          "vsSpin": 54,
          "control": 32,
          "movement": 27,
          "variation": 32,
          "stamina": 37,
          "catching": 58,
          "groundFielding": 56,
          "throwing": 70,
          "keeping": 61
        },
        "ODI": {
          "defence": 38,
          "timing": 45,
          "power": 52,
          "rotation": 55,
          "vsPace": 49,
          "vsSpin": 51,
          "control": 23,
          "movement": 18,
          "variation": 35,
          "stamina": 38,
          "catching": 48,
          "groundFielding": 56,
          "throwing": 49,
          "keeping": 71
        },
        "RED_BALL": {
          "defence": 55,
          "timing": 36,
          "power": 51,
          "rotation": 49,
          "vsPace": 60,
          "vsSpin": 43,
          "control": 15,
          "movement": 39,
          "variation": 30,
          "stamina": 18,
          "catching": 67,
          "groundFielding": 48,
          "throwing": 44,
          "keeping": 86
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        467,
        662,
        323,
        598,
        678,
        252,
        722,
        607
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p043",
      "name": "Isen Harbrook",
      "birthDate": "1991-01-10",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 28,
          "timing": 49,
          "power": 51,
          "rotation": 39,
          "vsPace": 36,
          "vsSpin": 34,
          "control": 68,
          "movement": 63,
          "variation": 78,
          "stamina": 58,
          "catching": 57,
          "groundFielding": 44,
          "throwing": 45,
          "keeping": 26
        },
        "ODI": {
          "defence": 42,
          "timing": 21,
          "power": 24,
          "rotation": 45,
          "vsPace": 37,
          "vsSpin": 39,
          "control": 75,
          "movement": 58,
          "variation": 75,
          "stamina": 60,
          "catching": 65,
          "groundFielding": 55,
          "throwing": 68,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 35,
          "timing": 48,
          "power": 32,
          "rotation": 38,
          "vsPace": 35,
          "vsSpin": 19,
          "control": 58,
          "movement": 78,
          "variation": 66,
          "stamina": 50,
          "catching": 66,
          "groundFielding": 48,
          "throwing": 53,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        861,
        505,
        271,
        974,
        891,
        585,
        230,
        505
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p044",
      "name": "Ari Mossthorne",
      "birthDate": "1991-07-12",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 19,
          "power": 32,
          "rotation": 36,
          "vsPace": 48,
          "vsSpin": 35,
          "control": 53,
          "movement": 63,
          "variation": 67,
          "stamina": 64,
          "catching": 42,
          "groundFielding": 39,
          "throwing": 57,
          "keeping": 19
        },
        "ODI": {
          "defence": 49,
          "timing": 49,
          "power": 45,
          "rotation": 36,
          "vsPace": 20,
          "vsSpin": 49,
          "control": 77,
          "movement": 79,
          "variation": 59,
          "stamina": 76,
          "catching": 64,
          "groundFielding": 41,
          "throwing": 55,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 39,
          "timing": 44,
          "power": 35,
          "rotation": 45,
          "vsPace": 36,
          "vsSpin": 49,
          "control": 79,
          "movement": 51,
          "variation": 73,
          "stamina": 67,
          "catching": 40,
          "groundFielding": 51,
          "throwing": 48,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        302,
        488,
        563,
        996,
        469,
        245,
        404,
        226
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p045",
      "name": "Belan Falkholt",
      "birthDate": "2007-08-02",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 47,
          "power": 34,
          "rotation": 43,
          "vsPace": 26,
          "vsSpin": 41,
          "control": 71,
          "movement": 56,
          "variation": 59,
          "stamina": 73,
          "catching": 65,
          "groundFielding": 68,
          "throwing": 67,
          "keeping": 26
        },
        "ODI": {
          "defence": 48,
          "timing": 24,
          "power": 19,
          "rotation": 22,
          "vsPace": 29,
          "vsSpin": 43,
          "control": 60,
          "movement": 75,
          "variation": 67,
          "stamina": 72,
          "catching": 46,
          "groundFielding": 59,
          "throwing": 45,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 30,
          "timing": 38,
          "power": 36,
          "rotation": 26,
          "vsPace": 37,
          "vsSpin": 30,
          "control": 74,
          "movement": 54,
          "variation": 66,
          "stamina": 62,
          "catching": 40,
          "groundFielding": 40,
          "throwing": 44,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        774,
        414,
        657,
        220,
        485,
        974,
        483,
        405
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p046",
      "name": "Borin Jorbridge",
      "birthDate": "2006-04-20",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 27,
          "power": 33,
          "rotation": 20,
          "vsPace": 44,
          "vsSpin": 35,
          "control": 78,
          "movement": 67,
          "variation": 70,
          "stamina": 68,
          "catching": 66,
          "groundFielding": 59,
          "throwing": 39,
          "keeping": 26
        },
        "ODI": {
          "defence": 28,
          "timing": 25,
          "power": 34,
          "rotation": 24,
          "vsPace": 32,
          "vsSpin": 46,
          "control": 65,
          "movement": 76,
          "variation": 77,
          "stamina": 73,
          "catching": 44,
          "groundFielding": 49,
          "throwing": 60,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 42,
          "timing": 31,
          "power": 45,
          "rotation": 30,
          "vsPace": 43,
          "vsSpin": 41,
          "control": 77,
          "movement": 55,
          "variation": 55,
          "stamina": 74,
          "catching": 61,
          "groundFielding": 43,
          "throwing": 61,
          "keeping": 31
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        461,
        201,
        894,
        586,
        504,
        767,
        306,
        799
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p047",
      "name": "Eren Corwell",
      "birthDate": "1988-02-20",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 25,
          "timing": 37,
          "power": 51,
          "rotation": 40,
          "vsPace": 22,
          "vsSpin": 42,
          "control": 66,
          "movement": 73,
          "variation": 54,
          "stamina": 59,
          "catching": 57,
          "groundFielding": 49,
          "throwing": 64,
          "keeping": 16
        },
        "ODI": {
          "defence": 30,
          "timing": 25,
          "power": 25,
          "rotation": 46,
          "vsPace": 37,
          "vsSpin": 19,
          "control": 56,
          "movement": 67,
          "variation": 50,
          "stamina": 62,
          "catching": 60,
          "groundFielding": 40,
          "throwing": 45,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 35,
          "timing": 21,
          "power": 45,
          "rotation": 41,
          "vsPace": 33,
          "vsSpin": 46,
          "control": 50,
          "movement": 57,
          "variation": 73,
          "stamina": 68,
          "catching": 59,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        226,
        331,
        974,
        685,
        901,
        851,
        617,
        250
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p048",
      "name": "Galen Dunstone",
      "birthDate": "1996-03-09",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 30,
          "timing": 27,
          "power": 36,
          "rotation": 45,
          "vsPace": 20,
          "vsSpin": 22,
          "control": 51,
          "movement": 50,
          "variation": 55,
          "stamina": 57,
          "catching": 64,
          "groundFielding": 46,
          "throwing": 53,
          "keeping": 14
        },
        "ODI": {
          "defence": 34,
          "timing": 28,
          "power": 36,
          "rotation": 39,
          "vsPace": 41,
          "vsSpin": 42,
          "control": 76,
          "movement": 59,
          "variation": 78,
          "stamina": 68,
          "catching": 59,
          "groundFielding": 42,
          "throwing": 47,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 33,
          "timing": 23,
          "power": 17,
          "rotation": 23,
          "vsPace": 39,
          "vsSpin": 34,
          "control": 77,
          "movement": 75,
          "variation": 67,
          "stamina": 53,
          "catching": 64,
          "groundFielding": 52,
          "throwing": 44,
          "keeping": 16
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        571,
        939,
        491,
        529,
        224,
        842,
        965,
        567
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p049",
      "name": "Isen Harfield",
      "birthDate": "1997-11-23",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 62,
          "power": 55,
          "rotation": 43,
          "vsPace": 47,
          "vsSpin": 56,
          "control": 51,
          "movement": 60,
          "variation": 42,
          "stamina": 55,
          "catching": 54,
          "groundFielding": 55,
          "throwing": 44,
          "keeping": 38
        },
        "ODI": {
          "defence": 52,
          "timing": 42,
          "power": 39,
          "rotation": 48,
          "vsPace": 57,
          "vsSpin": 39,
          "control": 39,
          "movement": 61,
          "variation": 62,
          "stamina": 60,
          "catching": 65,
          "groundFielding": 45,
          "throwing": 56,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 60,
          "timing": 64,
          "power": 51,
          "rotation": 46,
          "vsPace": 47,
          "vsSpin": 65,
          "control": 52,
          "movement": 59,
          "variation": 50,
          "stamina": 50,
          "catching": 48,
          "groundFielding": 51,
          "throwing": 46,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        259,
        933,
        283,
        687,
        986,
        262,
        696,
        458
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p050",
      "name": "Deren Norbridge",
      "birthDate": "2002-10-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 53,
          "power": 60,
          "rotation": 51,
          "vsPace": 38,
          "vsSpin": 68,
          "control": 64,
          "movement": 38,
          "variation": 53,
          "stamina": 37,
          "catching": 70,
          "groundFielding": 45,
          "throwing": 50,
          "keeping": 37
        },
        "ODI": {
          "defence": 55,
          "timing": 58,
          "power": 50,
          "rotation": 42,
          "vsPace": 39,
          "vsSpin": 67,
          "control": 65,
          "movement": 60,
          "variation": 62,
          "stamina": 56,
          "catching": 66,
          "groundFielding": 66,
          "throwing": 64,
          "keeping": 30
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 44,
          "power": 58,
          "rotation": 61,
          "vsPace": 66,
          "vsSpin": 50,
          "control": 45,
          "movement": 64,
          "variation": 52,
          "stamina": 57,
          "catching": 66,
          "groundFielding": 64,
          "throwing": 60,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        369,
        933,
        321,
        900,
        474,
        819,
        831,
        971
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p051",
      "name": "Vero Mossridge",
      "birthDate": "2001-12-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 66,
          "power": 51,
          "rotation": 52,
          "vsPace": 47,
          "vsSpin": 41,
          "control": 43,
          "movement": 44,
          "variation": 39,
          "stamina": 40,
          "catching": 47,
          "groundFielding": 54,
          "throwing": 66,
          "keeping": 40
        },
        "ODI": {
          "defence": 43,
          "timing": 47,
          "power": 68,
          "rotation": 42,
          "vsPace": 59,
          "vsSpin": 46,
          "control": 55,
          "movement": 63,
          "variation": 38,
          "stamina": 48,
          "catching": 46,
          "groundFielding": 54,
          "throwing": 51,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 51,
          "power": 40,
          "rotation": 60,
          "vsPace": 46,
          "vsSpin": 67,
          "control": 54,
          "movement": 65,
          "variation": 58,
          "stamina": 58,
          "catching": 47,
          "groundFielding": 53,
          "throwing": 44,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        902,
        350,
        646,
        728,
        370,
        419,
        256,
        623
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p052",
      "name": "Leron Zornfell",
      "birthDate": "1995-01-23",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 73,
          "power": 84,
          "rotation": 72,
          "vsPace": 69,
          "vsSpin": 79,
          "control": 20,
          "movement": 31,
          "variation": 30,
          "stamina": 23,
          "catching": 65,
          "groundFielding": 61,
          "throwing": 41,
          "keeping": 15
        },
        "ODI": {
          "defence": 79,
          "timing": 57,
          "power": 62,
          "rotation": 75,
          "vsPace": 79,
          "vsSpin": 77,
          "control": 32,
          "movement": 35,
          "variation": 35,
          "stamina": 39,
          "catching": 50,
          "groundFielding": 40,
          "throwing": 62,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 52,
          "power": 50,
          "rotation": 76,
          "vsPace": 62,
          "vsSpin": 60,
          "control": 21,
          "movement": 31,
          "variation": 44,
          "stamina": 36,
          "catching": 60,
          "groundFielding": 64,
          "throwing": 41,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        985,
        472,
        867,
        797,
        859,
        932,
        300,
        671
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p053",
      "name": "Galen Valecombe",
      "birthDate": "1991-06-02",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 70,
          "power": 71,
          "rotation": 68,
          "vsPace": 65,
          "vsSpin": 71,
          "control": 34,
          "movement": 25,
          "variation": 26,
          "stamina": 39,
          "catching": 48,
          "groundFielding": 62,
          "throwing": 62,
          "keeping": 40
        },
        "ODI": {
          "defence": 75,
          "timing": 73,
          "power": 74,
          "rotation": 60,
          "vsPace": 65,
          "vsSpin": 77,
          "control": 14,
          "movement": 29,
          "variation": 35,
          "stamina": 41,
          "catching": 62,
          "groundFielding": 63,
          "throwing": 60,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 71,
          "power": 76,
          "rotation": 59,
          "vsPace": 51,
          "vsSpin": 50,
          "control": 26,
          "movement": 25,
          "variation": 15,
          "stamina": 17,
          "catching": 61,
          "groundFielding": 52,
          "throwing": 63,
          "keeping": 25
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        548,
        406,
        572,
        896,
        960,
        888,
        453,
        993
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p054",
      "name": "Jora Ternstone",
      "birthDate": "1996-01-23",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 72,
          "power": 55,
          "rotation": 72,
          "vsPace": 70,
          "vsSpin": 63,
          "control": 25,
          "movement": 35,
          "variation": 36,
          "stamina": 37,
          "catching": 64,
          "groundFielding": 63,
          "throwing": 62,
          "keeping": 30
        },
        "ODI": {
          "defence": 56,
          "timing": 70,
          "power": 53,
          "rotation": 75,
          "vsPace": 66,
          "vsSpin": 78,
          "control": 14,
          "movement": 36,
          "variation": 26,
          "stamina": 18,
          "catching": 41,
          "groundFielding": 38,
          "throwing": 59,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 85,
          "timing": 55,
          "power": 70,
          "rotation": 56,
          "vsPace": 51,
          "vsSpin": 51,
          "control": 27,
          "movement": 38,
          "variation": 22,
          "stamina": 21,
          "catching": 61,
          "groundFielding": 48,
          "throwing": 37,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        210,
        865,
        602,
        871,
        522,
        207,
        801,
        940
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p055",
      "name": "Fenn Iverthorne",
      "birthDate": "1993-05-03",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 72,
          "timing": 52,
          "power": 62,
          "rotation": 54,
          "vsPace": 79,
          "vsSpin": 71,
          "control": 33,
          "movement": 26,
          "variation": 42,
          "stamina": 38,
          "catching": 63,
          "groundFielding": 55,
          "throwing": 54,
          "keeping": 13
        },
        "ODI": {
          "defence": 63,
          "timing": 72,
          "power": 61,
          "rotation": 54,
          "vsPace": 53,
          "vsSpin": 52,
          "control": 19,
          "movement": 20,
          "variation": 15,
          "stamina": 15,
          "catching": 63,
          "groundFielding": 38,
          "throwing": 45,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 85,
          "timing": 56,
          "power": 56,
          "rotation": 79,
          "vsPace": 77,
          "vsSpin": 78,
          "control": 15,
          "movement": 33,
          "variation": 22,
          "stamina": 20,
          "catching": 45,
          "groundFielding": 38,
          "throwing": 42,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        877,
        672,
        503,
        606,
        984,
        625,
        959,
        266
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p056",
      "name": "Nalo Mossridge",
      "birthDate": "1999-12-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 75,
          "timing": 67,
          "power": 76,
          "rotation": 50,
          "vsPace": 72,
          "vsSpin": 79,
          "control": 33,
          "movement": 32,
          "variation": 25,
          "stamina": 25,
          "catching": 53,
          "groundFielding": 47,
          "throwing": 52,
          "keeping": 17
        },
        "ODI": {
          "defence": 73,
          "timing": 53,
          "power": 64,
          "rotation": 72,
          "vsPace": 57,
          "vsSpin": 53,
          "control": 29,
          "movement": 20,
          "variation": 22,
          "stamina": 30,
          "catching": 64,
          "groundFielding": 48,
          "throwing": 38,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 78,
          "power": 50,
          "rotation": 71,
          "vsPace": 76,
          "vsSpin": 54,
          "control": 32,
          "movement": 25,
          "variation": 19,
          "stamina": 43,
          "catching": 54,
          "groundFielding": 51,
          "throwing": 47,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        420,
        716,
        754,
        455,
        911,
        204,
        557,
        978
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p057",
      "name": "Ulen Iverwick",
      "birthDate": "1997-04-13",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 61,
          "power": 80,
          "rotation": 68,
          "vsPace": 71,
          "vsSpin": 75,
          "control": 15,
          "movement": 42,
          "variation": 30,
          "stamina": 41,
          "catching": 63,
          "groundFielding": 64,
          "throwing": 43,
          "keeping": 31
        },
        "ODI": {
          "defence": 74,
          "timing": 70,
          "power": 56,
          "rotation": 54,
          "vsPace": 51,
          "vsSpin": 79,
          "control": 24,
          "movement": 22,
          "variation": 37,
          "stamina": 23,
          "catching": 37,
          "groundFielding": 58,
          "throwing": 54,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 64,
          "power": 54,
          "rotation": 61,
          "vsPace": 65,
          "vsSpin": 51,
          "control": 26,
          "movement": 40,
          "variation": 17,
          "stamina": 25,
          "catching": 50,
          "groundFielding": 41,
          "throwing": 57,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        906,
        466,
        610,
        991,
        441,
        743,
        358,
        236
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p058",
      "name": "Halen Briarmere",
      "birthDate": "1995-01-05",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 66,
          "power": 77,
          "rotation": 73,
          "vsPace": 58,
          "vsSpin": 51,
          "control": 17,
          "movement": 21,
          "variation": 33,
          "stamina": 39,
          "catching": 64,
          "groundFielding": 40,
          "throwing": 38,
          "keeping": 36
        },
        "ODI": {
          "defence": 51,
          "timing": 80,
          "power": 63,
          "rotation": 53,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 18,
          "movement": 22,
          "variation": 21,
          "stamina": 29,
          "catching": 47,
          "groundFielding": 44,
          "throwing": 39,
          "keeping": 19
        },
        "RED_BALL": {
          "defence": 78,
          "timing": 77,
          "power": 63,
          "rotation": 75,
          "vsPace": 80,
          "vsSpin": 51,
          "control": 34,
          "movement": 29,
          "variation": 37,
          "stamina": 29,
          "catching": 38,
          "groundFielding": 46,
          "throwing": 57,
          "keeping": 32
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        681,
        756,
        973,
        589,
        574,
        521,
        390,
        269
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p059",
      "name": "Walen Sablecombe",
      "birthDate": "1994-09-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 51,
          "timing": 77,
          "power": 83,
          "rotation": 78,
          "vsPace": 77,
          "vsSpin": 57,
          "control": 32,
          "movement": 26,
          "variation": 37,
          "stamina": 24,
          "catching": 49,
          "groundFielding": 46,
          "throwing": 54,
          "keeping": 28
        },
        "ODI": {
          "defence": 72,
          "timing": 75,
          "power": 72,
          "rotation": 59,
          "vsPace": 69,
          "vsSpin": 54,
          "control": 38,
          "movement": 26,
          "variation": 38,
          "stamina": 19,
          "catching": 44,
          "groundFielding": 53,
          "throwing": 61,
          "keeping": 39
        },
        "RED_BALL": {
          "defence": 69,
          "timing": 55,
          "power": 61,
          "rotation": 60,
          "vsPace": 58,
          "vsSpin": 67,
          "control": 27,
          "movement": 41,
          "variation": 16,
          "stamina": 17,
          "catching": 45,
          "groundFielding": 51,
          "throwing": 54,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        828,
        229,
        562,
        337,
        391,
        316,
        398,
        315
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p060",
      "name": "Sela Mossford",
      "birthDate": "1998-12-16",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 75,
          "timing": 61,
          "power": 73,
          "rotation": 52,
          "vsPace": 57,
          "vsSpin": 63,
          "control": 31,
          "movement": 18,
          "variation": 22,
          "stamina": 15,
          "catching": 60,
          "groundFielding": 44,
          "throwing": 42,
          "keeping": 37
        },
        "ODI": {
          "defence": 50,
          "timing": 51,
          "power": 61,
          "rotation": 59,
          "vsPace": 55,
          "vsSpin": 71,
          "control": 42,
          "movement": 38,
          "variation": 34,
          "stamina": 44,
          "catching": 39,
          "groundFielding": 55,
          "throwing": 59,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 68,
          "timing": 73,
          "power": 63,
          "rotation": 74,
          "vsPace": 54,
          "vsSpin": 71,
          "control": 23,
          "movement": 30,
          "variation": 42,
          "stamina": 41,
          "catching": 64,
          "groundFielding": 53,
          "throwing": 61,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        670,
        375,
        899,
        406,
        877,
        435,
        790,
        223
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p061",
      "name": "Vero Wrenford",
      "birthDate": "1995-12-12",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 51,
          "timing": 53,
          "power": 65,
          "rotation": 53,
          "vsPace": 62,
          "vsSpin": 47,
          "control": 26,
          "movement": 23,
          "variation": 23,
          "stamina": 22,
          "catching": 62,
          "groundFielding": 60,
          "throwing": 67,
          "keeping": 80
        },
        "ODI": {
          "defence": 53,
          "timing": 39,
          "power": 55,
          "rotation": 42,
          "vsPace": 44,
          "vsSpin": 44,
          "control": 21,
          "movement": 13,
          "variation": 33,
          "stamina": 33,
          "catching": 71,
          "groundFielding": 49,
          "throwing": 60,
          "keeping": 59
        },
        "RED_BALL": {
          "defence": 54,
          "timing": 47,
          "power": 45,
          "rotation": 51,
          "vsPace": 52,
          "vsSpin": 38,
          "control": 18,
          "movement": 38,
          "variation": 12,
          "stamina": 28,
          "catching": 46,
          "groundFielding": 67,
          "throwing": 67,
          "keeping": 59
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        371,
        981,
        638,
        488,
        314,
        344,
        429,
        265
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p062",
      "name": "Kaelen Iverridge",
      "birthDate": "2007-07-02",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 53,
          "power": 61,
          "rotation": 63,
          "vsPace": 54,
          "vsSpin": 38,
          "control": 24,
          "movement": 20,
          "variation": 42,
          "stamina": 38,
          "catching": 65,
          "groundFielding": 47,
          "throwing": 48,
          "keeping": 72
        },
        "ODI": {
          "defence": 41,
          "timing": 50,
          "power": 37,
          "rotation": 58,
          "vsPace": 64,
          "vsSpin": 53,
          "control": 28,
          "movement": 31,
          "variation": 22,
          "stamina": 36,
          "catching": 56,
          "groundFielding": 71,
          "throwing": 49,
          "keeping": 76
        },
        "RED_BALL": {
          "defence": 39,
          "timing": 57,
          "power": 46,
          "rotation": 44,
          "vsPace": 43,
          "vsSpin": 60,
          "control": 37,
          "movement": 38,
          "variation": 20,
          "stamina": 32,
          "catching": 45,
          "groundFielding": 45,
          "throwing": 47,
          "keeping": 65
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        795,
        405,
        427,
        863,
        786,
        596,
        544,
        896
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p063",
      "name": "Vero Rookcombe",
      "birthDate": "2007-10-16",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 45,
          "power": 41,
          "rotation": 21,
          "vsPace": 45,
          "vsSpin": 33,
          "control": 67,
          "movement": 78,
          "variation": 64,
          "stamina": 80,
          "catching": 53,
          "groundFielding": 58,
          "throwing": 56,
          "keeping": 37
        },
        "ODI": {
          "defence": 40,
          "timing": 33,
          "power": 42,
          "rotation": 26,
          "vsPace": 48,
          "vsSpin": 20,
          "control": 76,
          "movement": 53,
          "variation": 57,
          "stamina": 72,
          "catching": 53,
          "groundFielding": 61,
          "throwing": 54,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 43,
          "power": 36,
          "rotation": 49,
          "vsPace": 49,
          "vsSpin": 27,
          "control": 62,
          "movement": 62,
          "variation": 66,
          "stamina": 70,
          "catching": 46,
          "groundFielding": 52,
          "throwing": 48,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        266,
        669,
        587,
        706,
        581,
        623,
        982,
        646
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p064",
      "name": "Talor Zornbrook",
      "birthDate": "1988-02-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 40,
          "power": 35,
          "rotation": 41,
          "vsPace": 35,
          "vsSpin": 24,
          "control": 56,
          "movement": 71,
          "variation": 77,
          "stamina": 67,
          "catching": 53,
          "groundFielding": 62,
          "throwing": 51,
          "keeping": 37
        },
        "ODI": {
          "defence": 32,
          "timing": 39,
          "power": 43,
          "rotation": 49,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 55,
          "movement": 74,
          "variation": 59,
          "stamina": 52,
          "catching": 41,
          "groundFielding": 46,
          "throwing": 68,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 22,
          "power": 44,
          "rotation": 39,
          "vsPace": 45,
          "vsSpin": 43,
          "control": 77,
          "movement": 57,
          "variation": 50,
          "stamina": 64,
          "catching": 65,
          "groundFielding": 66,
          "throwing": 47,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        594,
        235,
        994,
        438,
        965,
        915,
        510,
        668
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p065",
      "name": "Miran Ashford",
      "birthDate": "1998-08-04",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 19,
          "timing": 44,
          "power": 39,
          "rotation": 26,
          "vsPace": 46,
          "vsSpin": 26,
          "control": 71,
          "movement": 58,
          "variation": 68,
          "stamina": 78,
          "catching": 56,
          "groundFielding": 60,
          "throwing": 40,
          "keeping": 40
        },
        "ODI": {
          "defence": 45,
          "timing": 48,
          "power": 28,
          "rotation": 29,
          "vsPace": 45,
          "vsSpin": 21,
          "control": 79,
          "movement": 53,
          "variation": 74,
          "stamina": 67,
          "catching": 64,
          "groundFielding": 66,
          "throwing": 41,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 41,
          "timing": 22,
          "power": 37,
          "rotation": 22,
          "vsPace": 35,
          "vsSpin": 23,
          "control": 57,
          "movement": 73,
          "variation": 72,
          "stamina": 69,
          "catching": 55,
          "groundFielding": 42,
          "throwing": 59,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        458,
        404,
        543,
        534,
        606,
        925,
        259,
        838
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p066",
      "name": "Deren Kelwick",
      "birthDate": "2006-03-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 23,
          "power": 32,
          "rotation": 42,
          "vsPace": 30,
          "vsSpin": 27,
          "control": 54,
          "movement": 69,
          "variation": 67,
          "stamina": 70,
          "catching": 47,
          "groundFielding": 67,
          "throwing": 67,
          "keeping": 21
        },
        "ODI": {
          "defence": 22,
          "timing": 37,
          "power": 23,
          "rotation": 33,
          "vsPace": 21,
          "vsSpin": 51,
          "control": 55,
          "movement": 62,
          "variation": 53,
          "stamina": 52,
          "catching": 64,
          "groundFielding": 42,
          "throwing": 47,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 34,
          "timing": 40,
          "power": 38,
          "rotation": 27,
          "vsPace": 42,
          "vsSpin": 46,
          "control": 74,
          "movement": 78,
          "variation": 50,
          "stamina": 68,
          "catching": 65,
          "groundFielding": 56,
          "throwing": 41,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        974,
        595,
        981,
        599,
        699,
        634,
        494,
        745
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p067",
      "name": "Saren Elmstead",
      "birthDate": "1992-03-17",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 34,
          "timing": 41,
          "power": 41,
          "rotation": 46,
          "vsPace": 36,
          "vsSpin": 20,
          "control": 79,
          "movement": 61,
          "variation": 59,
          "stamina": 61,
          "catching": 63,
          "groundFielding": 55,
          "throwing": 66,
          "keeping": 29
        },
        "ODI": {
          "defence": 36,
          "timing": 21,
          "power": 35,
          "rotation": 49,
          "vsPace": 45,
          "vsSpin": 37,
          "control": 58,
          "movement": 69,
          "variation": 75,
          "stamina": 69,
          "catching": 67,
          "groundFielding": 41,
          "throwing": 46,
          "keeping": 41
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 39,
          "power": 35,
          "rotation": 29,
          "vsPace": 20,
          "vsSpin": 31,
          "control": 56,
          "movement": 68,
          "variation": 71,
          "stamina": 74,
          "catching": 53,
          "groundFielding": 55,
          "throwing": 46,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        406,
        721,
        505,
        304,
        766,
        827,
        835,
        643
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p068",
      "name": "Galen Pellthorne",
      "birthDate": "2002-05-01",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 22,
          "timing": 25,
          "power": 27,
          "rotation": 21,
          "vsPace": 19,
          "vsSpin": 26,
          "control": 71,
          "movement": 53,
          "variation": 69,
          "stamina": 59,
          "catching": 57,
          "groundFielding": 56,
          "throwing": 40,
          "keeping": 39
        },
        "ODI": {
          "defence": 41,
          "timing": 25,
          "power": 31,
          "rotation": 33,
          "vsPace": 38,
          "vsSpin": 48,
          "control": 74,
          "movement": 68,
          "variation": 79,
          "stamina": 75,
          "catching": 56,
          "groundFielding": 48,
          "throwing": 42,
          "keeping": 17
        },
        "RED_BALL": {
          "defence": 44,
          "timing": 25,
          "power": 46,
          "rotation": 29,
          "vsPace": 39,
          "vsSpin": 28,
          "control": 79,
          "movement": 56,
          "variation": 57,
          "stamina": 58,
          "catching": 64,
          "groundFielding": 61,
          "throwing": 59,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        983,
        685,
        772,
        337,
        674,
        819,
        297,
        499
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p069",
      "name": "Nerin Wrenstone",
      "birthDate": "2000-11-04",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 68,
          "power": 64,
          "rotation": 61,
          "vsPace": 38,
          "vsSpin": 50,
          "control": 37,
          "movement": 54,
          "variation": 38,
          "stamina": 46,
          "catching": 59,
          "groundFielding": 64,
          "throwing": 60,
          "keeping": 36
        },
        "ODI": {
          "defence": 56,
          "timing": 47,
          "power": 51,
          "rotation": 68,
          "vsPace": 65,
          "vsSpin": 40,
          "control": 67,
          "movement": 60,
          "variation": 60,
          "stamina": 65,
          "catching": 70,
          "groundFielding": 59,
          "throwing": 50,
          "keeping": 34
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 63,
          "power": 57,
          "rotation": 51,
          "vsPace": 55,
          "vsSpin": 43,
          "control": 64,
          "movement": 63,
          "variation": 62,
          "stamina": 63,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 52,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        311,
        258,
        414,
        904,
        662,
        231,
        496,
        665
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p070",
      "name": "Talor Pellfell",
      "birthDate": "1989-01-28",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 45,
          "timing": 59,
          "power": 47,
          "rotation": 60,
          "vsPace": 50,
          "vsSpin": 59,
          "control": 44,
          "movement": 62,
          "variation": 66,
          "stamina": 52,
          "catching": 69,
          "groundFielding": 43,
          "throwing": 61,
          "keeping": 16
        },
        "ODI": {
          "defence": 52,
          "timing": 68,
          "power": 47,
          "rotation": 39,
          "vsPace": 45,
          "vsSpin": 63,
          "control": 58,
          "movement": 53,
          "variation": 40,
          "stamina": 48,
          "catching": 70,
          "groundFielding": 54,
          "throwing": 53,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 73,
          "timing": 54,
          "power": 37,
          "rotation": 43,
          "vsPace": 52,
          "vsSpin": 59,
          "control": 37,
          "movement": 46,
          "variation": 47,
          "stamina": 42,
          "catching": 70,
          "groundFielding": 61,
          "throwing": 59,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        512,
        329,
        726,
        590,
        711,
        697,
        478,
        615
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p071",
      "name": "Ari Ashford",
      "birthDate": "1990-08-16",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 49,
          "power": 67,
          "rotation": 51,
          "vsPace": 62,
          "vsSpin": 61,
          "control": 37,
          "movement": 46,
          "variation": 48,
          "stamina": 58,
          "catching": 49,
          "groundFielding": 50,
          "throwing": 63,
          "keeping": 24
        },
        "ODI": {
          "defence": 56,
          "timing": 38,
          "power": 58,
          "rotation": 63,
          "vsPace": 47,
          "vsSpin": 58,
          "control": 49,
          "movement": 51,
          "variation": 67,
          "stamina": 48,
          "catching": 50,
          "groundFielding": 52,
          "throwing": 71,
          "keeping": 17
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 50,
          "power": 63,
          "rotation": 39,
          "vsPace": 63,
          "vsSpin": 58,
          "control": 60,
          "movement": 58,
          "variation": 43,
          "stamina": 46,
          "catching": 44,
          "groundFielding": 50,
          "throwing": 66,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        462,
        507,
        226,
        870,
        491,
        965,
        356,
        812
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p072",
      "name": "Caro Pellwick",
      "birthDate": "1997-11-21",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 64,
          "timing": 59,
          "power": 77,
          "rotation": 69,
          "vsPace": 60,
          "vsSpin": 55,
          "control": 44,
          "movement": 21,
          "variation": 30,
          "stamina": 28,
          "catching": 46,
          "groundFielding": 43,
          "throwing": 45,
          "keeping": 11
        },
        "ODI": {
          "defence": 68,
          "timing": 78,
          "power": 78,
          "rotation": 60,
          "vsPace": 69,
          "vsSpin": 54,
          "control": 40,
          "movement": 32,
          "variation": 24,
          "stamina": 20,
          "catching": 46,
          "groundFielding": 46,
          "throwing": 41,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 63,
          "power": 68,
          "rotation": 56,
          "vsPace": 63,
          "vsSpin": 74,
          "control": 25,
          "movement": 31,
          "variation": 41,
          "stamina": 19,
          "catching": 56,
          "groundFielding": 41,
          "throwing": 38,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        249,
        441,
        328,
        399,
        390,
        509,
        968,
        742
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p073",
      "name": "Galen Lornford",
      "birthDate": "2007-01-13",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 72,
          "timing": 56,
          "power": 71,
          "rotation": 73,
          "vsPace": 76,
          "vsSpin": 72,
          "control": 16,
          "movement": 25,
          "variation": 42,
          "stamina": 35,
          "catching": 39,
          "groundFielding": 38,
          "throwing": 52,
          "keeping": 37
        },
        "ODI": {
          "defence": 66,
          "timing": 53,
          "power": 67,
          "rotation": 55,
          "vsPace": 78,
          "vsSpin": 71,
          "control": 40,
          "movement": 30,
          "variation": 18,
          "stamina": 44,
          "catching": 43,
          "groundFielding": 43,
          "throwing": 61,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 65,
          "power": 76,
          "rotation": 52,
          "vsPace": 67,
          "vsSpin": 56,
          "control": 16,
          "movement": 38,
          "variation": 32,
          "stamina": 24,
          "catching": 37,
          "groundFielding": 66,
          "throwing": 48,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        284,
        506,
        652,
        805,
        305,
        993,
        333,
        368
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p074",
      "name": "Isen Sablefield",
      "birthDate": "1997-09-09",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 64,
          "power": 72,
          "rotation": 61,
          "vsPace": 72,
          "vsSpin": 60,
          "control": 21,
          "movement": 31,
          "variation": 39,
          "stamina": 33,
          "catching": 44,
          "groundFielding": 58,
          "throwing": 48,
          "keeping": 32
        },
        "ODI": {
          "defence": 51,
          "timing": 67,
          "power": 63,
          "rotation": 68,
          "vsPace": 69,
          "vsSpin": 52,
          "control": 42,
          "movement": 18,
          "variation": 17,
          "stamina": 22,
          "catching": 43,
          "groundFielding": 67,
          "throwing": 48,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 70,
          "power": 75,
          "rotation": 63,
          "vsPace": 56,
          "vsSpin": 50,
          "control": 19,
          "movement": 37,
          "variation": 24,
          "stamina": 43,
          "catching": 49,
          "groundFielding": 43,
          "throwing": 52,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        753,
        977,
        988,
        677,
        304,
        288,
        916,
        488
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p075",
      "name": "Yoran Pellbrook 15",
      "birthDate": "1994-11-24",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 73,
          "power": 59,
          "rotation": 57,
          "vsPace": 58,
          "vsSpin": 75,
          "control": 40,
          "movement": 17,
          "variation": 31,
          "stamina": 21,
          "catching": 50,
          "groundFielding": 62,
          "throwing": 57,
          "keeping": 20
        },
        "ODI": {
          "defence": 56,
          "timing": 70,
          "power": 68,
          "rotation": 61,
          "vsPace": 51,
          "vsSpin": 62,
          "control": 21,
          "movement": 19,
          "variation": 25,
          "stamina": 35,
          "catching": 40,
          "groundFielding": 45,
          "throwing": 53,
          "keeping": 41
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 50,
          "power": 70,
          "rotation": 70,
          "vsPace": 57,
          "vsSpin": 65,
          "control": 30,
          "movement": 16,
          "variation": 21,
          "stamina": 34,
          "catching": 67,
          "groundFielding": 65,
          "throwing": 39,
          "keeping": 16
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        220,
        817,
        910,
        584,
        429,
        541,
        263,
        319
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p076",
      "name": "Pavan Sableford",
      "birthDate": "1996-09-21",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 61,
          "power": 59,
          "rotation": 55,
          "vsPace": 64,
          "vsSpin": 64,
          "control": 33,
          "movement": 28,
          "variation": 42,
          "stamina": 14,
          "catching": 61,
          "groundFielding": 43,
          "throwing": 48,
          "keeping": 28
        },
        "ODI": {
          "defence": 69,
          "timing": 53,
          "power": 67,
          "rotation": 74,
          "vsPace": 54,
          "vsSpin": 54,
          "control": 38,
          "movement": 22,
          "variation": 27,
          "stamina": 20,
          "catching": 39,
          "groundFielding": 56,
          "throwing": 47,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 83,
          "timing": 52,
          "power": 60,
          "rotation": 51,
          "vsPace": 57,
          "vsSpin": 66,
          "control": 18,
          "movement": 39,
          "variation": 19,
          "stamina": 21,
          "catching": 49,
          "groundFielding": 67,
          "throwing": 53,
          "keeping": 30
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        474,
        282,
        203,
        857,
        595,
        507,
        245,
        548
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p077",
      "name": "Saren Briarstone",
      "birthDate": "2007-04-03",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 73,
          "power": 62,
          "rotation": 54,
          "vsPace": 71,
          "vsSpin": 69,
          "control": 32,
          "movement": 41,
          "variation": 42,
          "stamina": 32,
          "catching": 61,
          "groundFielding": 57,
          "throwing": 55,
          "keeping": 27
        },
        "ODI": {
          "defence": 60,
          "timing": 53,
          "power": 59,
          "rotation": 76,
          "vsPace": 80,
          "vsSpin": 74,
          "control": 44,
          "movement": 16,
          "variation": 43,
          "stamina": 24,
          "catching": 60,
          "groundFielding": 64,
          "throwing": 40,
          "keeping": 17
        },
        "RED_BALL": {
          "defence": 76,
          "timing": 72,
          "power": 51,
          "rotation": 52,
          "vsPace": 72,
          "vsSpin": 80,
          "control": 21,
          "movement": 36,
          "variation": 24,
          "stamina": 21,
          "catching": 67,
          "groundFielding": 46,
          "throwing": 45,
          "keeping": 13
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        966,
        686,
        370,
        626,
        443,
        253,
        963,
        426
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p078",
      "name": "Borin Kelholt",
      "birthDate": "1992-05-26",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 60,
          "timing": 63,
          "power": 54,
          "rotation": 75,
          "vsPace": 66,
          "vsSpin": 76,
          "control": 17,
          "movement": 19,
          "variation": 19,
          "stamina": 43,
          "catching": 63,
          "groundFielding": 53,
          "throwing": 42,
          "keeping": 14
        },
        "ODI": {
          "defence": 65,
          "timing": 69,
          "power": 69,
          "rotation": 71,
          "vsPace": 78,
          "vsSpin": 54,
          "control": 27,
          "movement": 39,
          "variation": 27,
          "stamina": 43,
          "catching": 39,
          "groundFielding": 45,
          "throwing": 46,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 59,
          "timing": 55,
          "power": 65,
          "rotation": 54,
          "vsPace": 52,
          "vsSpin": 66,
          "control": 17,
          "movement": 35,
          "variation": 27,
          "stamina": 22,
          "catching": 50,
          "groundFielding": 51,
          "throwing": 47,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        487,
        677,
        900,
        418,
        222,
        507,
        879,
        887
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p079",
      "name": "Rilan Iverbridge",
      "birthDate": "2007-05-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 58,
          "timing": 75,
          "power": 72,
          "rotation": 64,
          "vsPace": 59,
          "vsSpin": 60,
          "control": 41,
          "movement": 31,
          "variation": 31,
          "stamina": 33,
          "catching": 46,
          "groundFielding": 56,
          "throwing": 47,
          "keeping": 19
        },
        "ODI": {
          "defence": 70,
          "timing": 75,
          "power": 51,
          "rotation": 50,
          "vsPace": 57,
          "vsSpin": 75,
          "control": 39,
          "movement": 17,
          "variation": 28,
          "stamina": 32,
          "catching": 59,
          "groundFielding": 38,
          "throwing": 56,
          "keeping": 33
        },
        "RED_BALL": {
          "defence": 79,
          "timing": 57,
          "power": 54,
          "rotation": 63,
          "vsPace": 56,
          "vsSpin": 75,
          "control": 27,
          "movement": 43,
          "variation": 17,
          "stamina": 34,
          "catching": 49,
          "groundFielding": 48,
          "throwing": 45,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        608,
        223,
        973,
        216,
        304,
        949,
        257,
        544
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p080",
      "name": "Galen Ashcombe",
      "birthDate": "1991-09-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 70,
          "power": 77,
          "rotation": 80,
          "vsPace": 76,
          "vsSpin": 51,
          "control": 31,
          "movement": 27,
          "variation": 44,
          "stamina": 31,
          "catching": 59,
          "groundFielding": 52,
          "throwing": 44,
          "keeping": 39
        },
        "ODI": {
          "defence": 67,
          "timing": 55,
          "power": 75,
          "rotation": 64,
          "vsPace": 72,
          "vsSpin": 51,
          "control": 15,
          "movement": 16,
          "variation": 27,
          "stamina": 38,
          "catching": 59,
          "groundFielding": 63,
          "throwing": 38,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 69,
          "power": 57,
          "rotation": 80,
          "vsPace": 70,
          "vsSpin": 58,
          "control": 23,
          "movement": 38,
          "variation": 14,
          "stamina": 16,
          "catching": 41,
          "groundFielding": 46,
          "throwing": 37,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        252,
        830,
        574,
        985,
        267,
        995,
        394,
        371
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p081",
      "name": "Rilan Jorfield 1",
      "birthDate": "2005-10-18",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 48,
          "power": 59,
          "rotation": 38,
          "vsPace": 37,
          "vsSpin": 52,
          "control": 20,
          "movement": 12,
          "variation": 19,
          "stamina": 40,
          "catching": 61,
          "groundFielding": 43,
          "throwing": 50,
          "keeping": 62
        },
        "ODI": {
          "defence": 44,
          "timing": 43,
          "power": 37,
          "rotation": 36,
          "vsPace": 49,
          "vsSpin": 41,
          "control": 16,
          "movement": 42,
          "variation": 42,
          "stamina": 28,
          "catching": 70,
          "groundFielding": 57,
          "throwing": 59,
          "keeping": 62
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 63,
          "power": 32,
          "rotation": 39,
          "vsPace": 55,
          "vsSpin": 35,
          "control": 14,
          "movement": 19,
          "variation": 41,
          "stamina": 19,
          "catching": 61,
          "groundFielding": 58,
          "throwing": 46,
          "keeping": 67
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        693,
        966,
        272,
        820,
        972,
        832,
        990,
        890
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p082",
      "name": "Fenn Quenbridge",
      "birthDate": "1992-09-16",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 38,
          "timing": 39,
          "power": 51,
          "rotation": 60,
          "vsPace": 35,
          "vsSpin": 37,
          "control": 31,
          "movement": 15,
          "variation": 40,
          "stamina": 27,
          "catching": 66,
          "groundFielding": 56,
          "throwing": 69,
          "keeping": 63
        },
        "ODI": {
          "defence": 60,
          "timing": 58,
          "power": 39,
          "rotation": 62,
          "vsPace": 40,
          "vsSpin": 56,
          "control": 40,
          "movement": 42,
          "variation": 18,
          "stamina": 25,
          "catching": 51,
          "groundFielding": 57,
          "throwing": 52,
          "keeping": 76
        },
        "RED_BALL": {
          "defence": 59,
          "timing": 51,
          "power": 31,
          "rotation": 43,
          "vsPace": 39,
          "vsSpin": 43,
          "control": 18,
          "movement": 41,
          "variation": 20,
          "stamina": 31,
          "catching": 53,
          "groundFielding": 68,
          "throwing": 48,
          "keeping": 63
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        700,
        527,
        702,
        320,
        843,
        322,
        308,
        496
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p083",
      "name": "Belan Sablestone",
      "birthDate": "1993-01-10",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 23,
          "timing": 29,
          "power": 34,
          "rotation": 22,
          "vsPace": 30,
          "vsSpin": 24,
          "control": 67,
          "movement": 77,
          "variation": 56,
          "stamina": 67,
          "catching": 43,
          "groundFielding": 56,
          "throwing": 54,
          "keeping": 28
        },
        "ODI": {
          "defence": 28,
          "timing": 34,
          "power": 21,
          "rotation": 40,
          "vsPace": 39,
          "vsSpin": 22,
          "control": 62,
          "movement": 59,
          "variation": 78,
          "stamina": 75,
          "catching": 46,
          "groundFielding": 52,
          "throwing": 49,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 51,
          "timing": 30,
          "power": 40,
          "rotation": 46,
          "vsPace": 28,
          "vsSpin": 31,
          "control": 77,
          "movement": 74,
          "variation": 56,
          "stamina": 77,
          "catching": 46,
          "groundFielding": 50,
          "throwing": 55,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        636,
        699,
        683,
        546,
        932,
        404,
        687,
        325
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p084",
      "name": "Deren Falkholt",
      "birthDate": "2005-01-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 24,
          "timing": 26,
          "power": 40,
          "rotation": 41,
          "vsPace": 25,
          "vsSpin": 45,
          "control": 72,
          "movement": 62,
          "variation": 63,
          "stamina": 67,
          "catching": 69,
          "groundFielding": 66,
          "throwing": 66,
          "keeping": 39
        },
        "ODI": {
          "defence": 40,
          "timing": 41,
          "power": 30,
          "rotation": 31,
          "vsPace": 32,
          "vsSpin": 46,
          "control": 54,
          "movement": 62,
          "variation": 55,
          "stamina": 73,
          "catching": 67,
          "groundFielding": 54,
          "throwing": 39,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 33,
          "power": 29,
          "rotation": 45,
          "vsPace": 44,
          "vsSpin": 22,
          "control": 51,
          "movement": 64,
          "variation": 69,
          "stamina": 72,
          "catching": 57,
          "groundFielding": 49,
          "throwing": 65,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        366,
        275,
        515,
        637,
        604,
        429,
        381,
        650
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p085",
      "name": "Oren Elmwell",
      "birthDate": "2007-01-07",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 34,
          "timing": 41,
          "power": 36,
          "rotation": 37,
          "vsPace": 40,
          "vsSpin": 31,
          "control": 74,
          "movement": 71,
          "variation": 64,
          "stamina": 52,
          "catching": 68,
          "groundFielding": 46,
          "throwing": 46,
          "keeping": 37
        },
        "ODI": {
          "defence": 30,
          "timing": 49,
          "power": 39,
          "rotation": 22,
          "vsPace": 41,
          "vsSpin": 33,
          "control": 79,
          "movement": 59,
          "variation": 61,
          "stamina": 57,
          "catching": 50,
          "groundFielding": 67,
          "throwing": 47,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 28,
          "timing": 28,
          "power": 45,
          "rotation": 48,
          "vsPace": 34,
          "vsSpin": 31,
          "control": 58,
          "movement": 57,
          "variation": 67,
          "stamina": 77,
          "catching": 53,
          "groundFielding": 62,
          "throwing": 42,
          "keeping": 12
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        805,
        520,
        568,
        739,
        572,
        870,
        421,
        649
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p086",
      "name": "Nalo Zornfell",
      "birthDate": "2001-02-03",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 40,
          "timing": 47,
          "power": 53,
          "rotation": 28,
          "vsPace": 36,
          "vsSpin": 48,
          "control": 72,
          "movement": 68,
          "variation": 78,
          "stamina": 51,
          "catching": 45,
          "groundFielding": 50,
          "throwing": 51,
          "keeping": 22
        },
        "ODI": {
          "defence": 35,
          "timing": 45,
          "power": 49,
          "rotation": 20,
          "vsPace": 41,
          "vsSpin": 49,
          "control": 67,
          "movement": 79,
          "variation": 68,
          "stamina": 66,
          "catching": 61,
          "groundFielding": 66,
          "throwing": 60,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 23,
          "power": 43,
          "rotation": 47,
          "vsPace": 23,
          "vsSpin": 32,
          "control": 65,
          "movement": 63,
          "variation": 51,
          "stamina": 71,
          "catching": 62,
          "groundFielding": 65,
          "throwing": 46,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        367,
        952,
        234,
        774,
        996,
        934,
        265,
        805
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p087",
      "name": "Nalo Rookstead",
      "birthDate": "1991-09-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 32,
          "power": 43,
          "rotation": 39,
          "vsPace": 47,
          "vsSpin": 49,
          "control": 51,
          "movement": 64,
          "variation": 54,
          "stamina": 53,
          "catching": 67,
          "groundFielding": 41,
          "throwing": 51,
          "keeping": 32
        },
        "ODI": {
          "defence": 43,
          "timing": 46,
          "power": 23,
          "rotation": 35,
          "vsPace": 26,
          "vsSpin": 38,
          "control": 62,
          "movement": 54,
          "variation": 58,
          "stamina": 60,
          "catching": 58,
          "groundFielding": 39,
          "throwing": 39,
          "keeping": 19
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 30,
          "power": 45,
          "rotation": 21,
          "vsPace": 29,
          "vsSpin": 43,
          "control": 52,
          "movement": 74,
          "variation": 57,
          "stamina": 73,
          "catching": 50,
          "groundFielding": 42,
          "throwing": 63,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        781,
        457,
        433,
        387,
        473,
        645,
        245,
        716
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p088",
      "name": "Belan Briarstead",
      "birthDate": "1993-07-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 49,
          "timing": 35,
          "power": 49,
          "rotation": 35,
          "vsPace": 42,
          "vsSpin": 40,
          "control": 79,
          "movement": 56,
          "variation": 62,
          "stamina": 72,
          "catching": 53,
          "groundFielding": 60,
          "throwing": 58,
          "keeping": 29
        },
        "ODI": {
          "defence": 37,
          "timing": 33,
          "power": 26,
          "rotation": 47,
          "vsPace": 46,
          "vsSpin": 35,
          "control": 64,
          "movement": 52,
          "variation": 60,
          "stamina": 53,
          "catching": 51,
          "groundFielding": 46,
          "throwing": 48,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 33,
          "timing": 24,
          "power": 43,
          "rotation": 30,
          "vsPace": 38,
          "vsSpin": 37,
          "control": 55,
          "movement": 55,
          "variation": 65,
          "stamina": 56,
          "catching": 43,
          "groundFielding": 59,
          "throwing": 52,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        512,
        538,
        669,
        697,
        635,
        741,
        656,
        313
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p089",
      "name": "Ari Zornstead",
      "birthDate": "1997-09-12",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "FAST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 63,
          "power": 66,
          "rotation": 51,
          "vsPace": 54,
          "vsSpin": 50,
          "control": 46,
          "movement": 56,
          "variation": 65,
          "stamina": 55,
          "catching": 47,
          "groundFielding": 62,
          "throwing": 53,
          "keeping": 12
        },
        "ODI": {
          "defence": 41,
          "timing": 43,
          "power": 49,
          "rotation": 51,
          "vsPace": 63,
          "vsSpin": 63,
          "control": 41,
          "movement": 44,
          "variation": 39,
          "stamina": 66,
          "catching": 42,
          "groundFielding": 60,
          "throwing": 54,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 48,
          "timing": 68,
          "power": 64,
          "rotation": 41,
          "vsPace": 41,
          "vsSpin": 65,
          "control": 53,
          "movement": 58,
          "variation": 57,
          "stamina": 65,
          "catching": 56,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        992,
        249,
        689,
        675,
        942,
        205,
        830,
        984
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p090",
      "name": "Kaelen Quenthorne",
      "birthDate": "2007-06-24",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 59,
          "power": 69,
          "rotation": 55,
          "vsPace": 39,
          "vsSpin": 47,
          "control": 50,
          "movement": 57,
          "variation": 57,
          "stamina": 52,
          "catching": 60,
          "groundFielding": 57,
          "throwing": 72,
          "keeping": 11
        },
        "ODI": {
          "defence": 58,
          "timing": 40,
          "power": 59,
          "rotation": 55,
          "vsPace": 48,
          "vsSpin": 60,
          "control": 45,
          "movement": 52,
          "variation": 63,
          "stamina": 61,
          "catching": 52,
          "groundFielding": 61,
          "throwing": 62,
          "keeping": 34
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 54,
          "power": 39,
          "rotation": 57,
          "vsPace": 62,
          "vsSpin": 55,
          "control": 52,
          "movement": 48,
          "variation": 63,
          "stamina": 39,
          "catching": 43,
          "groundFielding": 55,
          "throwing": 66,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        762,
        675,
        915,
        758,
        723,
        372,
        280,
        570
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p091",
      "name": "Leron Ashcroft",
      "birthDate": "1999-04-20",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 38,
          "power": 49,
          "rotation": 66,
          "vsPace": 38,
          "vsSpin": 54,
          "control": 56,
          "movement": 55,
          "variation": 48,
          "stamina": 54,
          "catching": 59,
          "groundFielding": 42,
          "throwing": 42,
          "keeping": 25
        },
        "ODI": {
          "defence": 57,
          "timing": 48,
          "power": 51,
          "rotation": 53,
          "vsPace": 60,
          "vsSpin": 67,
          "control": 67,
          "movement": 39,
          "variation": 56,
          "stamina": 39,
          "catching": 54,
          "groundFielding": 64,
          "throwing": 48,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 57,
          "timing": 56,
          "power": 51,
          "rotation": 65,
          "vsPace": 39,
          "vsSpin": 58,
          "control": 60,
          "movement": 64,
          "variation": 48,
          "stamina": 38,
          "catching": 65,
          "groundFielding": 43,
          "throwing": 60,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        512,
        970,
        378,
        262,
        892,
        763,
        288,
        657
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p092",
      "name": "Kaelen Norden",
      "birthDate": "1990-06-06",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 63,
          "power": 72,
          "rotation": 63,
          "vsPace": 58,
          "vsSpin": 50,
          "control": 21,
          "movement": 18,
          "variation": 24,
          "stamina": 24,
          "catching": 43,
          "groundFielding": 60,
          "throwing": 55,
          "keeping": 25
        },
        "ODI": {
          "defence": 68,
          "timing": 71,
          "power": 77,
          "rotation": 79,
          "vsPace": 73,
          "vsSpin": 61,
          "control": 39,
          "movement": 23,
          "variation": 27,
          "stamina": 32,
          "catching": 50,
          "groundFielding": 67,
          "throwing": 56,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 84,
          "timing": 54,
          "power": 73,
          "rotation": 52,
          "vsPace": 80,
          "vsSpin": 60,
          "control": 37,
          "movement": 35,
          "variation": 42,
          "stamina": 41,
          "catching": 41,
          "groundFielding": 62,
          "throwing": 65,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        749,
        462,
        236,
        845,
        885,
        256,
        793,
        713
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p093",
      "name": "Eren Falkfield",
      "birthDate": "2003-04-11",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 80,
          "timing": 77,
          "power": 56,
          "rotation": 69,
          "vsPace": 67,
          "vsSpin": 78,
          "control": 40,
          "movement": 27,
          "variation": 36,
          "stamina": 22,
          "catching": 38,
          "groundFielding": 62,
          "throwing": 46,
          "keeping": 35
        },
        "ODI": {
          "defence": 74,
          "timing": 60,
          "power": 58,
          "rotation": 63,
          "vsPace": 59,
          "vsSpin": 57,
          "control": 14,
          "movement": 21,
          "variation": 31,
          "stamina": 24,
          "catching": 59,
          "groundFielding": 54,
          "throwing": 62,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 75,
          "power": 48,
          "rotation": 68,
          "vsPace": 78,
          "vsSpin": 57,
          "control": 33,
          "movement": 26,
          "variation": 20,
          "stamina": 21,
          "catching": 41,
          "groundFielding": 57,
          "throwing": 62,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        683,
        271,
        412,
        334,
        822,
        353,
        718,
        316
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p094",
      "name": "Galen Yewfell",
      "birthDate": "2007-01-25",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 61,
          "timing": 70,
          "power": 69,
          "rotation": 62,
          "vsPace": 57,
          "vsSpin": 65,
          "control": 27,
          "movement": 19,
          "variation": 44,
          "stamina": 30,
          "catching": 57,
          "groundFielding": 53,
          "throwing": 53,
          "keeping": 26
        },
        "ODI": {
          "defence": 80,
          "timing": 76,
          "power": 75,
          "rotation": 63,
          "vsPace": 67,
          "vsSpin": 71,
          "control": 35,
          "movement": 36,
          "variation": 21,
          "stamina": 34,
          "catching": 47,
          "groundFielding": 48,
          "throwing": 44,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 74,
          "power": 70,
          "rotation": 78,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 35,
          "movement": 32,
          "variation": 34,
          "stamina": 27,
          "catching": 57,
          "groundFielding": 65,
          "throwing": 54,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        818,
        846,
        709,
        603,
        275,
        679,
        496,
        911
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p095",
      "name": "Miran Mosscroft",
      "birthDate": "2005-11-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 57,
          "power": 82,
          "rotation": 64,
          "vsPace": 69,
          "vsSpin": 78,
          "control": 23,
          "movement": 29,
          "variation": 22,
          "stamina": 33,
          "catching": 61,
          "groundFielding": 48,
          "throwing": 56,
          "keeping": 29
        },
        "ODI": {
          "defence": 63,
          "timing": 79,
          "power": 68,
          "rotation": 56,
          "vsPace": 78,
          "vsSpin": 65,
          "control": 24,
          "movement": 22,
          "variation": 37,
          "stamina": 22,
          "catching": 42,
          "groundFielding": 57,
          "throwing": 53,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 58,
          "power": 72,
          "rotation": 53,
          "vsPace": 53,
          "vsSpin": 65,
          "control": 31,
          "movement": 23,
          "variation": 17,
          "stamina": 40,
          "catching": 39,
          "groundFielding": 51,
          "throwing": 38,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        876,
        822,
        379,
        875,
        305,
        352,
        616,
        890
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p096",
      "name": "Kaelen Pellcroft",
      "birthDate": "1998-05-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 68,
          "timing": 61,
          "power": 82,
          "rotation": 74,
          "vsPace": 73,
          "vsSpin": 59,
          "control": 24,
          "movement": 36,
          "variation": 35,
          "stamina": 28,
          "catching": 53,
          "groundFielding": 66,
          "throwing": 61,
          "keeping": 33
        },
        "ODI": {
          "defence": 56,
          "timing": 65,
          "power": 76,
          "rotation": 76,
          "vsPace": 51,
          "vsSpin": 55,
          "control": 16,
          "movement": 22,
          "variation": 33,
          "stamina": 36,
          "catching": 62,
          "groundFielding": 40,
          "throwing": 64,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 66,
          "timing": 58,
          "power": 63,
          "rotation": 68,
          "vsPace": 76,
          "vsSpin": 70,
          "control": 24,
          "movement": 28,
          "variation": 29,
          "stamina": 34,
          "catching": 49,
          "groundFielding": 58,
          "throwing": 67,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        690,
        360,
        957,
        592,
        239,
        721,
        208,
        431
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p097",
      "name": "Jora Orinstead",
      "birthDate": "2005-09-09",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 63,
          "timing": 64,
          "power": 77,
          "rotation": 55,
          "vsPace": 74,
          "vsSpin": 78,
          "control": 35,
          "movement": 21,
          "variation": 40,
          "stamina": 40,
          "catching": 60,
          "groundFielding": 66,
          "throwing": 55,
          "keeping": 38
        },
        "ODI": {
          "defence": 56,
          "timing": 57,
          "power": 53,
          "rotation": 73,
          "vsPace": 71,
          "vsSpin": 69,
          "control": 27,
          "movement": 18,
          "variation": 39,
          "stamina": 39,
          "catching": 55,
          "groundFielding": 56,
          "throwing": 42,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 60,
          "power": 73,
          "rotation": 52,
          "vsPace": 58,
          "vsSpin": 62,
          "control": 20,
          "movement": 36,
          "variation": 15,
          "stamina": 21,
          "catching": 44,
          "groundFielding": 41,
          "throwing": 65,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        213,
        408,
        467,
        537,
        464,
        282,
        634,
        886
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p098",
      "name": "Sela Iverwick",
      "birthDate": "1992-08-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 74,
          "power": 54,
          "rotation": 73,
          "vsPace": 68,
          "vsSpin": 77,
          "control": 14,
          "movement": 22,
          "variation": 44,
          "stamina": 26,
          "catching": 50,
          "groundFielding": 47,
          "throwing": 66,
          "keeping": 31
        },
        "ODI": {
          "defence": 63,
          "timing": 76,
          "power": 58,
          "rotation": 63,
          "vsPace": 53,
          "vsSpin": 52,
          "control": 35,
          "movement": 19,
          "variation": 16,
          "stamina": 17,
          "catching": 49,
          "groundFielding": 61,
          "throwing": 58,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 74,
          "timing": 68,
          "power": 48,
          "rotation": 79,
          "vsPace": 76,
          "vsSpin": 54,
          "control": 24,
          "movement": 44,
          "variation": 33,
          "stamina": 35,
          "catching": 47,
          "groundFielding": 40,
          "throwing": 58,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        773,
        492,
        637,
        590,
        524,
        460,
        823,
        857
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p099",
      "name": "Zerin Sablestone",
      "birthDate": "2007-08-17",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 63,
          "timing": 51,
          "power": 80,
          "rotation": 62,
          "vsPace": 66,
          "vsSpin": 76,
          "control": 25,
          "movement": 41,
          "variation": 43,
          "stamina": 30,
          "catching": 48,
          "groundFielding": 67,
          "throwing": 67,
          "keeping": 31
        },
        "ODI": {
          "defence": 63,
          "timing": 69,
          "power": 76,
          "rotation": 77,
          "vsPace": 59,
          "vsSpin": 69,
          "control": 15,
          "movement": 19,
          "variation": 20,
          "stamina": 28,
          "catching": 59,
          "groundFielding": 40,
          "throwing": 44,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 77,
          "power": 48,
          "rotation": 50,
          "vsPace": 67,
          "vsSpin": 75,
          "control": 37,
          "movement": 18,
          "variation": 40,
          "stamina": 27,
          "catching": 67,
          "groundFielding": 38,
          "throwing": 43,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        845,
        992,
        983,
        206,
        503,
        659,
        699,
        707
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p100",
      "name": "Fenn Terncombe",
      "birthDate": "2002-08-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 70,
          "timing": 63,
          "power": 80,
          "rotation": 72,
          "vsPace": 66,
          "vsSpin": 73,
          "control": 42,
          "movement": 28,
          "variation": 25,
          "stamina": 44,
          "catching": 64,
          "groundFielding": 57,
          "throwing": 39,
          "keeping": 21
        },
        "ODI": {
          "defence": 54,
          "timing": 77,
          "power": 80,
          "rotation": 58,
          "vsPace": 59,
          "vsSpin": 80,
          "control": 43,
          "movement": 19,
          "variation": 34,
          "stamina": 19,
          "catching": 59,
          "groundFielding": 53,
          "throwing": 37,
          "keeping": 27
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 70,
          "power": 67,
          "rotation": 53,
          "vsPace": 73,
          "vsSpin": 56,
          "control": 34,
          "movement": 36,
          "variation": 37,
          "stamina": 30,
          "catching": 41,
          "groundFielding": 59,
          "throwing": 53,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        710,
        482,
        639,
        749,
        530,
        928,
        474,
        647
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p101",
      "name": "Eren Briarridge",
      "birthDate": "2005-02-14",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 47,
          "power": 54,
          "rotation": 60,
          "vsPace": 49,
          "vsSpin": 45,
          "control": 30,
          "movement": 20,
          "variation": 18,
          "stamina": 21,
          "catching": 41,
          "groundFielding": 46,
          "throwing": 65,
          "keeping": 68
        },
        "ODI": {
          "defence": 51,
          "timing": 60,
          "power": 50,
          "rotation": 56,
          "vsPace": 50,
          "vsSpin": 35,
          "control": 32,
          "movement": 16,
          "variation": 33,
          "stamina": 26,
          "catching": 47,
          "groundFielding": 46,
          "throwing": 63,
          "keeping": 74
        },
        "RED_BALL": {
          "defence": 48,
          "timing": 36,
          "power": 49,
          "rotation": 51,
          "vsPace": 52,
          "vsSpin": 43,
          "control": 35,
          "movement": 19,
          "variation": 17,
          "stamina": 13,
          "catching": 49,
          "groundFielding": 63,
          "throwing": 48,
          "keeping": 69
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        238,
        504,
        324,
        935,
        256,
        871,
        597,
        419
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p102",
      "name": "Nerin Harridge",
      "birthDate": "2007-09-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 38,
          "power": 53,
          "rotation": 42,
          "vsPace": 48,
          "vsSpin": 51,
          "control": 13,
          "movement": 24,
          "variation": 31,
          "stamina": 39,
          "catching": 55,
          "groundFielding": 61,
          "throwing": 46,
          "keeping": 77
        },
        "ODI": {
          "defence": 50,
          "timing": 49,
          "power": 59,
          "rotation": 52,
          "vsPace": 39,
          "vsSpin": 60,
          "control": 19,
          "movement": 29,
          "variation": 28,
          "stamina": 14,
          "catching": 70,
          "groundFielding": 70,
          "throwing": 57,
          "keeping": 61
        },
        "RED_BALL": {
          "defence": 49,
          "timing": 49,
          "power": 37,
          "rotation": 54,
          "vsPace": 60,
          "vsSpin": 38,
          "control": 38,
          "movement": 42,
          "variation": 14,
          "stamina": 27,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 52,
          "keeping": 63
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        271,
        223,
        930,
        377,
        298,
        674,
        440,
        757
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p103",
      "name": "Galen Briarcombe",
      "birthDate": "2001-09-24",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 37,
          "timing": 23,
          "power": 44,
          "rotation": 33,
          "vsPace": 35,
          "vsSpin": 24,
          "control": 61,
          "movement": 56,
          "variation": 65,
          "stamina": 52,
          "catching": 69,
          "groundFielding": 58,
          "throwing": 61,
          "keeping": 34
        },
        "ODI": {
          "defence": 27,
          "timing": 48,
          "power": 22,
          "rotation": 22,
          "vsPace": 29,
          "vsSpin": 24,
          "control": 61,
          "movement": 61,
          "variation": 76,
          "stamina": 71,
          "catching": 56,
          "groundFielding": 59,
          "throwing": 49,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 39,
          "timing": 35,
          "power": 23,
          "rotation": 20,
          "vsPace": 26,
          "vsSpin": 30,
          "control": 77,
          "movement": 55,
          "variation": 72,
          "stamina": 58,
          "catching": 60,
          "groundFielding": 45,
          "throwing": 42,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        290,
        448,
        335,
        206,
        964,
        566,
        323,
        698
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p104",
      "name": "Arven Terncroft",
      "birthDate": "1992-09-04",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 37,
          "power": 25,
          "rotation": 22,
          "vsPace": 41,
          "vsSpin": 21,
          "control": 65,
          "movement": 78,
          "variation": 53,
          "stamina": 66,
          "catching": 58,
          "groundFielding": 50,
          "throwing": 40,
          "keeping": 40
        },
        "ODI": {
          "defence": 19,
          "timing": 25,
          "power": 40,
          "rotation": 25,
          "vsPace": 49,
          "vsSpin": 43,
          "control": 61,
          "movement": 67,
          "variation": 54,
          "stamina": 63,
          "catching": 44,
          "groundFielding": 63,
          "throwing": 57,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 49,
          "power": 28,
          "rotation": 22,
          "vsPace": 31,
          "vsSpin": 24,
          "control": 54,
          "movement": 53,
          "variation": 77,
          "stamina": 51,
          "catching": 68,
          "groundFielding": 45,
          "throwing": 66,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        633,
        226,
        543,
        739,
        927,
        325,
        434,
        642
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p105",
      "name": "Nerin Jorwick",
      "birthDate": "1994-10-17",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 22,
          "timing": 47,
          "power": 28,
          "rotation": 44,
          "vsPace": 37,
          "vsSpin": 37,
          "control": 69,
          "movement": 77,
          "variation": 61,
          "stamina": 56,
          "catching": 47,
          "groundFielding": 64,
          "throwing": 46,
          "keeping": 30
        },
        "ODI": {
          "defence": 43,
          "timing": 45,
          "power": 23,
          "rotation": 47,
          "vsPace": 43,
          "vsSpin": 47,
          "control": 76,
          "movement": 54,
          "variation": 55,
          "stamina": 69,
          "catching": 47,
          "groundFielding": 40,
          "throwing": 50,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 37,
          "timing": 30,
          "power": 27,
          "rotation": 25,
          "vsPace": 25,
          "vsSpin": 22,
          "control": 59,
          "movement": 69,
          "variation": 54,
          "stamina": 70,
          "catching": 63,
          "groundFielding": 61,
          "throwing": 61,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        633,
        714,
        491,
        836,
        838,
        601,
        767,
        692
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p106",
      "name": "Elio Rookmere",
      "birthDate": "1990-12-18",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 34,
          "timing": 25,
          "power": 45,
          "rotation": 24,
          "vsPace": 21,
          "vsSpin": 35,
          "control": 66,
          "movement": 56,
          "variation": 70,
          "stamina": 72,
          "catching": 47,
          "groundFielding": 52,
          "throwing": 64,
          "keeping": 40
        },
        "ODI": {
          "defence": 44,
          "timing": 42,
          "power": 37,
          "rotation": 26,
          "vsPace": 39,
          "vsSpin": 25,
          "control": 77,
          "movement": 70,
          "variation": 65,
          "stamina": 76,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 49,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 51,
          "timing": 33,
          "power": 38,
          "rotation": 47,
          "vsPace": 43,
          "vsSpin": 51,
          "control": 50,
          "movement": 61,
          "variation": 62,
          "stamina": 77,
          "catching": 57,
          "groundFielding": 65,
          "throwing": 45,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        245,
        755,
        575,
        424,
        755,
        839,
        280,
        259
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p107",
      "name": "Walen Glenmere",
      "birthDate": "1989-06-11",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 49,
          "timing": 42,
          "power": 31,
          "rotation": 46,
          "vsPace": 39,
          "vsSpin": 43,
          "control": 58,
          "movement": 63,
          "variation": 69,
          "stamina": 74,
          "catching": 57,
          "groundFielding": 42,
          "throwing": 41,
          "keeping": 23
        },
        "ODI": {
          "defence": 42,
          "timing": 22,
          "power": 33,
          "rotation": 28,
          "vsPace": 44,
          "vsSpin": 42,
          "control": 58,
          "movement": 58,
          "variation": 68,
          "stamina": 62,
          "catching": 65,
          "groundFielding": 49,
          "throwing": 47,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 48,
          "power": 17,
          "rotation": 30,
          "vsPace": 19,
          "vsSpin": 33,
          "control": 56,
          "movement": 52,
          "variation": 60,
          "stamina": 77,
          "catching": 58,
          "groundFielding": 68,
          "throwing": 50,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        620,
        798,
        355,
        506,
        651,
        582,
        438,
        323
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p108",
      "name": "Isen Jorden",
      "birthDate": "1996-07-11",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 48,
          "timing": 27,
          "power": 32,
          "rotation": 49,
          "vsPace": 26,
          "vsSpin": 32,
          "control": 50,
          "movement": 62,
          "variation": 54,
          "stamina": 62,
          "catching": 50,
          "groundFielding": 56,
          "throwing": 57,
          "keeping": 31
        },
        "ODI": {
          "defence": 45,
          "timing": 40,
          "power": 40,
          "rotation": 30,
          "vsPace": 42,
          "vsSpin": 21,
          "control": 65,
          "movement": 60,
          "variation": 60,
          "stamina": 62,
          "catching": 65,
          "groundFielding": 57,
          "throwing": 62,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 32,
          "timing": 37,
          "power": 46,
          "rotation": 30,
          "vsPace": 40,
          "vsSpin": 47,
          "control": 71,
          "movement": 60,
          "variation": 59,
          "stamina": 64,
          "catching": 54,
          "groundFielding": 62,
          "throwing": 46,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        709,
        759,
        438,
        577,
        847,
        335,
        228,
        860
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p109",
      "name": "Arven Lornford",
      "birthDate": "2005-12-03",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "MEDIUM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 68,
          "power": 54,
          "rotation": 43,
          "vsPace": 51,
          "vsSpin": 65,
          "control": 62,
          "movement": 55,
          "variation": 52,
          "stamina": 63,
          "catching": 46,
          "groundFielding": 61,
          "throwing": 66,
          "keeping": 31
        },
        "ODI": {
          "defence": 54,
          "timing": 63,
          "power": 40,
          "rotation": 45,
          "vsPace": 62,
          "vsSpin": 40,
          "control": 40,
          "movement": 39,
          "variation": 43,
          "stamina": 47,
          "catching": 47,
          "groundFielding": 51,
          "throwing": 50,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 69,
          "timing": 45,
          "power": 45,
          "rotation": 55,
          "vsPace": 39,
          "vsSpin": 48,
          "control": 53,
          "movement": 38,
          "variation": 59,
          "stamina": 59,
          "catching": 45,
          "groundFielding": 70,
          "throwing": 69,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        863,
        784,
        391,
        964,
        521,
        604,
        457,
        926
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p110",
      "name": "Arven Ternholt",
      "birthDate": "2005-01-17",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 68,
          "power": 67,
          "rotation": 57,
          "vsPace": 54,
          "vsSpin": 61,
          "control": 45,
          "movement": 41,
          "variation": 53,
          "stamina": 52,
          "catching": 71,
          "groundFielding": 66,
          "throwing": 44,
          "keeping": 32
        },
        "ODI": {
          "defence": 48,
          "timing": 45,
          "power": 41,
          "rotation": 56,
          "vsPace": 48,
          "vsSpin": 57,
          "control": 55,
          "movement": 64,
          "variation": 52,
          "stamina": 44,
          "catching": 65,
          "groundFielding": 69,
          "throwing": 44,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 41,
          "power": 59,
          "rotation": 38,
          "vsPace": 57,
          "vsSpin": 48,
          "control": 55,
          "movement": 52,
          "variation": 59,
          "stamina": 59,
          "catching": 65,
          "groundFielding": 72,
          "throwing": 56,
          "keeping": 18
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        420,
        938,
        616,
        266,
        696,
        540,
        594,
        757
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p111",
      "name": "Walen Wrenden",
      "birthDate": "1996-05-03",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 41,
          "timing": 41,
          "power": 53,
          "rotation": 68,
          "vsPace": 64,
          "vsSpin": 60,
          "control": 51,
          "movement": 64,
          "variation": 66,
          "stamina": 46,
          "catching": 42,
          "groundFielding": 46,
          "throwing": 52,
          "keeping": 15
        },
        "ODI": {
          "defence": 52,
          "timing": 61,
          "power": 53,
          "rotation": 60,
          "vsPace": 61,
          "vsSpin": 45,
          "control": 53,
          "movement": 52,
          "variation": 43,
          "stamina": 45,
          "catching": 72,
          "groundFielding": 57,
          "throwing": 53,
          "keeping": 39
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 59,
          "power": 44,
          "rotation": 49,
          "vsPace": 55,
          "vsSpin": 68,
          "control": 63,
          "movement": 45,
          "variation": 41,
          "stamina": 61,
          "catching": 42,
          "groundFielding": 47,
          "throwing": 46,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        933,
        816,
        732,
        351,
        375,
        655,
        289,
        495
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p112",
      "name": "Walen Mossstead",
      "birthDate": "2002-07-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 79,
          "timing": 70,
          "power": 68,
          "rotation": 66,
          "vsPace": 77,
          "vsSpin": 54,
          "control": 40,
          "movement": 16,
          "variation": 32,
          "stamina": 43,
          "catching": 44,
          "groundFielding": 61,
          "throwing": 50,
          "keeping": 28
        },
        "ODI": {
          "defence": 52,
          "timing": 79,
          "power": 55,
          "rotation": 78,
          "vsPace": 61,
          "vsSpin": 64,
          "control": 34,
          "movement": 38,
          "variation": 44,
          "stamina": 34,
          "catching": 39,
          "groundFielding": 47,
          "throwing": 56,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 71,
          "power": 77,
          "rotation": 71,
          "vsPace": 66,
          "vsSpin": 75,
          "control": 14,
          "movement": 28,
          "variation": 36,
          "stamina": 27,
          "catching": 39,
          "groundFielding": 50,
          "throwing": 57,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        836,
        815,
        207,
        925,
        531,
        827,
        438,
        278
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p113",
      "name": "Vero Yewfield",
      "birthDate": "2003-05-15",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 59,
          "power": 63,
          "rotation": 67,
          "vsPace": 72,
          "vsSpin": 72,
          "control": 32,
          "movement": 27,
          "variation": 33,
          "stamina": 14,
          "catching": 51,
          "groundFielding": 63,
          "throwing": 59,
          "keeping": 28
        },
        "ODI": {
          "defence": 55,
          "timing": 64,
          "power": 57,
          "rotation": 59,
          "vsPace": 68,
          "vsSpin": 65,
          "control": 41,
          "movement": 33,
          "variation": 26,
          "stamina": 33,
          "catching": 52,
          "groundFielding": 63,
          "throwing": 39,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 52,
          "power": 74,
          "rotation": 69,
          "vsPace": 79,
          "vsSpin": 75,
          "control": 44,
          "movement": 43,
          "variation": 26,
          "stamina": 32,
          "catching": 60,
          "groundFielding": 52,
          "throwing": 64,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        629,
        278,
        209,
        824,
        698,
        273,
        715,
        223
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p114",
      "name": "Miran Elmden",
      "birthDate": "1990-09-19",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 69,
          "timing": 64,
          "power": 77,
          "rotation": 66,
          "vsPace": 76,
          "vsSpin": 69,
          "control": 39,
          "movement": 18,
          "variation": 20,
          "stamina": 22,
          "catching": 49,
          "groundFielding": 57,
          "throwing": 52,
          "keeping": 27
        },
        "ODI": {
          "defence": 80,
          "timing": 65,
          "power": 60,
          "rotation": 77,
          "vsPace": 67,
          "vsSpin": 60,
          "control": 38,
          "movement": 19,
          "variation": 28,
          "stamina": 21,
          "catching": 65,
          "groundFielding": 38,
          "throwing": 48,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 67,
          "power": 63,
          "rotation": 75,
          "vsPace": 55,
          "vsSpin": 73,
          "control": 37,
          "movement": 23,
          "variation": 34,
          "stamina": 41,
          "catching": 65,
          "groundFielding": 64,
          "throwing": 50,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        864,
        450,
        886,
        902,
        237,
        488,
        472,
        992
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p115",
      "name": "Halen Briarfell",
      "birthDate": "2003-07-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 52,
          "timing": 50,
          "power": 60,
          "rotation": 70,
          "vsPace": 73,
          "vsSpin": 51,
          "control": 34,
          "movement": 35,
          "variation": 36,
          "stamina": 44,
          "catching": 66,
          "groundFielding": 51,
          "throwing": 42,
          "keeping": 35
        },
        "ODI": {
          "defence": 79,
          "timing": 61,
          "power": 77,
          "rotation": 59,
          "vsPace": 67,
          "vsSpin": 57,
          "control": 38,
          "movement": 15,
          "variation": 41,
          "stamina": 16,
          "catching": 65,
          "groundFielding": 60,
          "throwing": 46,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 75,
          "timing": 72,
          "power": 67,
          "rotation": 53,
          "vsPace": 61,
          "vsSpin": 67,
          "control": 32,
          "movement": 19,
          "variation": 24,
          "stamina": 26,
          "catching": 62,
          "groundFielding": 63,
          "throwing": 44,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        818,
        779,
        876,
        255,
        612,
        682,
        399,
        656
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p116",
      "name": "Arven Quenholt",
      "birthDate": "2001-11-17",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 78,
          "timing": 57,
          "power": 75,
          "rotation": 57,
          "vsPace": 78,
          "vsSpin": 50,
          "control": 32,
          "movement": 40,
          "variation": 18,
          "stamina": 41,
          "catching": 38,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 11
        },
        "ODI": {
          "defence": 80,
          "timing": 61,
          "power": 77,
          "rotation": 70,
          "vsPace": 63,
          "vsSpin": 58,
          "control": 17,
          "movement": 32,
          "variation": 15,
          "stamina": 43,
          "catching": 53,
          "groundFielding": 60,
          "throwing": 50,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 57,
          "power": 48,
          "rotation": 63,
          "vsPace": 65,
          "vsSpin": 56,
          "control": 39,
          "movement": 28,
          "variation": 14,
          "stamina": 44,
          "catching": 65,
          "groundFielding": 40,
          "throwing": 54,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        680,
        565,
        749,
        875,
        221,
        982,
        852,
        925
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p117",
      "name": "Elio Elmwick",
      "birthDate": "2007-03-25",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 76,
          "timing": 74,
          "power": 79,
          "rotation": 56,
          "vsPace": 64,
          "vsSpin": 52,
          "control": 36,
          "movement": 18,
          "variation": 32,
          "stamina": 37,
          "catching": 41,
          "groundFielding": 66,
          "throwing": 58,
          "keeping": 23
        },
        "ODI": {
          "defence": 63,
          "timing": 76,
          "power": 66,
          "rotation": 80,
          "vsPace": 74,
          "vsSpin": 65,
          "control": 27,
          "movement": 25,
          "variation": 27,
          "stamina": 30,
          "catching": 56,
          "groundFielding": 59,
          "throwing": 44,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 76,
          "timing": 53,
          "power": 74,
          "rotation": 78,
          "vsPace": 74,
          "vsSpin": 78,
          "control": 20,
          "movement": 25,
          "variation": 16,
          "stamina": 32,
          "catching": 38,
          "groundFielding": 51,
          "throwing": 66,
          "keeping": 31
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        786,
        207,
        474,
        679,
        262,
        934,
        781,
        450
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p118",
      "name": "Jora Wrenthorne",
      "birthDate": "2004-02-11",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 68,
          "timing": 76,
          "power": 60,
          "rotation": 71,
          "vsPace": 73,
          "vsSpin": 57,
          "control": 23,
          "movement": 24,
          "variation": 30,
          "stamina": 20,
          "catching": 41,
          "groundFielding": 63,
          "throwing": 43,
          "keeping": 23
        },
        "ODI": {
          "defence": 51,
          "timing": 71,
          "power": 77,
          "rotation": 67,
          "vsPace": 71,
          "vsSpin": 57,
          "control": 33,
          "movement": 44,
          "variation": 26,
          "stamina": 41,
          "catching": 42,
          "groundFielding": 60,
          "throwing": 60,
          "keeping": 39
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 59,
          "power": 70,
          "rotation": 78,
          "vsPace": 78,
          "vsSpin": 64,
          "control": 39,
          "movement": 35,
          "variation": 41,
          "stamina": 44,
          "catching": 63,
          "groundFielding": 44,
          "throwing": 63,
          "keeping": 16
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        256,
        689,
        269,
        609,
        376,
        223,
        732,
        367
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p119",
      "name": "Saren Zornbrook",
      "birthDate": "1994-11-27",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 77,
          "power": 57,
          "rotation": 71,
          "vsPace": 62,
          "vsSpin": 80,
          "control": 36,
          "movement": 23,
          "variation": 29,
          "stamina": 28,
          "catching": 39,
          "groundFielding": 65,
          "throwing": 54,
          "keeping": 32
        },
        "ODI": {
          "defence": 65,
          "timing": 75,
          "power": 69,
          "rotation": 56,
          "vsPace": 72,
          "vsSpin": 79,
          "control": 31,
          "movement": 16,
          "variation": 38,
          "stamina": 40,
          "catching": 49,
          "groundFielding": 52,
          "throwing": 45,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 66,
          "timing": 54,
          "power": 54,
          "rotation": 54,
          "vsPace": 56,
          "vsSpin": 71,
          "control": 23,
          "movement": 20,
          "variation": 41,
          "stamina": 43,
          "catching": 62,
          "groundFielding": 61,
          "throwing": 56,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        692,
        284,
        435,
        758,
        933,
        595,
        399,
        565
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p120",
      "name": "Kaelen Corcombe",
      "birthDate": "2007-09-27",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 52,
          "power": 80,
          "rotation": 53,
          "vsPace": 74,
          "vsSpin": 68,
          "control": 24,
          "movement": 15,
          "variation": 20,
          "stamina": 44,
          "catching": 50,
          "groundFielding": 65,
          "throwing": 65,
          "keeping": 35
        },
        "ODI": {
          "defence": 55,
          "timing": 57,
          "power": 62,
          "rotation": 63,
          "vsPace": 72,
          "vsSpin": 50,
          "control": 25,
          "movement": 36,
          "variation": 44,
          "stamina": 16,
          "catching": 66,
          "groundFielding": 66,
          "throwing": 58,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 84,
          "timing": 56,
          "power": 49,
          "rotation": 74,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 15,
          "movement": 35,
          "variation": 14,
          "stamina": 29,
          "catching": 59,
          "groundFielding": 58,
          "throwing": 37,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        289,
        410,
        376,
        829,
        514,
        297,
        236,
        244
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p121",
      "name": "Yoran Jorcroft",
      "birthDate": "1987-01-08",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 64,
          "timing": 53,
          "power": 56,
          "rotation": 36,
          "vsPace": 49,
          "vsSpin": 50,
          "control": 36,
          "movement": 32,
          "variation": 18,
          "stamina": 25,
          "catching": 52,
          "groundFielding": 45,
          "throwing": 61,
          "keeping": 83
        },
        "ODI": {
          "defence": 47,
          "timing": 43,
          "power": 35,
          "rotation": 47,
          "vsPace": 45,
          "vsSpin": 63,
          "control": 32,
          "movement": 16,
          "variation": 15,
          "stamina": 37,
          "catching": 41,
          "groundFielding": 68,
          "throwing": 59,
          "keeping": 61
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 44,
          "power": 38,
          "rotation": 59,
          "vsPace": 62,
          "vsSpin": 59,
          "control": 39,
          "movement": 28,
          "variation": 39,
          "stamina": 22,
          "catching": 67,
          "groundFielding": 45,
          "throwing": 71,
          "keeping": 82
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        638,
        501,
        1000,
        644,
        893,
        299,
        485,
        623
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p122",
      "name": "Nave Jorthorne",
      "birthDate": "2000-06-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 64,
          "power": 57,
          "rotation": 63,
          "vsPace": 48,
          "vsSpin": 40,
          "control": 18,
          "movement": 40,
          "variation": 18,
          "stamina": 32,
          "catching": 55,
          "groundFielding": 57,
          "throwing": 49,
          "keeping": 60
        },
        "ODI": {
          "defence": 52,
          "timing": 40,
          "power": 58,
          "rotation": 50,
          "vsPace": 43,
          "vsSpin": 46,
          "control": 37,
          "movement": 33,
          "variation": 19,
          "stamina": 15,
          "catching": 57,
          "groundFielding": 53,
          "throwing": 62,
          "keeping": 69
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 64,
          "power": 42,
          "rotation": 60,
          "vsPace": 64,
          "vsSpin": 41,
          "control": 31,
          "movement": 17,
          "variation": 14,
          "stamina": 24,
          "catching": 48,
          "groundFielding": 50,
          "throwing": 70,
          "keeping": 60
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        664,
        755,
        466,
        620,
        755,
        878,
        668,
        533
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p123",
      "name": "Caro Mossholt",
      "birthDate": "1990-11-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 37,
          "timing": 26,
          "power": 49,
          "rotation": 21,
          "vsPace": 25,
          "vsSpin": 34,
          "control": 61,
          "movement": 57,
          "variation": 69,
          "stamina": 66,
          "catching": 64,
          "groundFielding": 64,
          "throwing": 39,
          "keeping": 16
        },
        "ODI": {
          "defence": 21,
          "timing": 24,
          "power": 41,
          "rotation": 36,
          "vsPace": 38,
          "vsSpin": 35,
          "control": 77,
          "movement": 51,
          "variation": 65,
          "stamina": 64,
          "catching": 68,
          "groundFielding": 39,
          "throwing": 39,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 46,
          "timing": 44,
          "power": 37,
          "rotation": 49,
          "vsPace": 26,
          "vsSpin": 30,
          "control": 54,
          "movement": 77,
          "variation": 54,
          "stamina": 75,
          "catching": 46,
          "groundFielding": 41,
          "throwing": 48,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        769,
        727,
        297,
        726,
        387,
        726,
        891,
        218
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p124",
      "name": "Caro Sablefield",
      "birthDate": "2000-06-22",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 25,
          "timing": 36,
          "power": 41,
          "rotation": 37,
          "vsPace": 44,
          "vsSpin": 43,
          "control": 67,
          "movement": 58,
          "variation": 52,
          "stamina": 77,
          "catching": 39,
          "groundFielding": 46,
          "throwing": 54,
          "keeping": 30
        },
        "ODI": {
          "defence": 45,
          "timing": 31,
          "power": 40,
          "rotation": 20,
          "vsPace": 43,
          "vsSpin": 29,
          "control": 66,
          "movement": 54,
          "variation": 70,
          "stamina": 71,
          "catching": 67,
          "groundFielding": 44,
          "throwing": 66,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 37,
          "timing": 33,
          "power": 37,
          "rotation": 49,
          "vsPace": 49,
          "vsSpin": 38,
          "control": 56,
          "movement": 50,
          "variation": 56,
          "stamina": 66,
          "catching": 42,
          "groundFielding": 53,
          "throwing": 43,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        761,
        450,
        302,
        206,
        781,
        942,
        708,
        456
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p125",
      "name": "Nave Mossbridge",
      "birthDate": "1997-10-15",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 26,
          "timing": 29,
          "power": 41,
          "rotation": 19,
          "vsPace": 31,
          "vsSpin": 38,
          "control": 59,
          "movement": 57,
          "variation": 76,
          "stamina": 65,
          "catching": 54,
          "groundFielding": 41,
          "throwing": 55,
          "keeping": 32
        },
        "ODI": {
          "defence": 24,
          "timing": 25,
          "power": 37,
          "rotation": 39,
          "vsPace": 42,
          "vsSpin": 45,
          "control": 50,
          "movement": 57,
          "variation": 54,
          "stamina": 51,
          "catching": 67,
          "groundFielding": 66,
          "throwing": 48,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 30,
          "timing": 48,
          "power": 22,
          "rotation": 34,
          "vsPace": 24,
          "vsSpin": 47,
          "control": 77,
          "movement": 68,
          "variation": 76,
          "stamina": 64,
          "catching": 40,
          "groundFielding": 48,
          "throwing": 63,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        754,
        590,
        861,
        924,
        563,
        348,
        580,
        222
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p126",
      "name": "Leron Corwick",
      "birthDate": "1993-07-17",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 32,
          "power": 27,
          "rotation": 44,
          "vsPace": 44,
          "vsSpin": 51,
          "control": 60,
          "movement": 58,
          "variation": 72,
          "stamina": 54,
          "catching": 55,
          "groundFielding": 43,
          "throwing": 58,
          "keeping": 19
        },
        "ODI": {
          "defence": 43,
          "timing": 47,
          "power": 25,
          "rotation": 28,
          "vsPace": 26,
          "vsSpin": 47,
          "control": 68,
          "movement": 64,
          "variation": 79,
          "stamina": 53,
          "catching": 40,
          "groundFielding": 55,
          "throwing": 51,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 23,
          "power": 44,
          "rotation": 44,
          "vsPace": 27,
          "vsSpin": 39,
          "control": 62,
          "movement": 68,
          "variation": 65,
          "stamina": 65,
          "catching": 58,
          "groundFielding": 51,
          "throwing": 66,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        620,
        974,
        396,
        563,
        285,
        542,
        825,
        244
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p127",
      "name": "Tavin Lornbridge",
      "birthDate": "2007-10-03",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 21,
          "power": 47,
          "rotation": 32,
          "vsPace": 34,
          "vsSpin": 38,
          "control": 61,
          "movement": 53,
          "variation": 62,
          "stamina": 52,
          "catching": 66,
          "groundFielding": 45,
          "throwing": 64,
          "keeping": 25
        },
        "ODI": {
          "defence": 36,
          "timing": 28,
          "power": 44,
          "rotation": 38,
          "vsPace": 36,
          "vsSpin": 41,
          "control": 72,
          "movement": 72,
          "variation": 58,
          "stamina": 56,
          "catching": 63,
          "groundFielding": 69,
          "throwing": 68,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 32,
          "timing": 27,
          "power": 41,
          "rotation": 38,
          "vsPace": 31,
          "vsSpin": 19,
          "control": 69,
          "movement": 78,
          "variation": 77,
          "stamina": 68,
          "catching": 41,
          "groundFielding": 50,
          "throwing": 41,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        886,
        525,
        590,
        668,
        623,
        326,
        631,
        916
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p128",
      "name": "Saren Orinwick",
      "birthDate": "2000-02-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 23,
          "timing": 22,
          "power": 42,
          "rotation": 32,
          "vsPace": 24,
          "vsSpin": 43,
          "control": 55,
          "movement": 57,
          "variation": 55,
          "stamina": 75,
          "catching": 58,
          "groundFielding": 43,
          "throwing": 69,
          "keeping": 25
        },
        "ODI": {
          "defence": 20,
          "timing": 32,
          "power": 34,
          "rotation": 31,
          "vsPace": 39,
          "vsSpin": 34,
          "control": 62,
          "movement": 77,
          "variation": 56,
          "stamina": 77,
          "catching": 53,
          "groundFielding": 63,
          "throwing": 61,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 35,
          "timing": 20,
          "power": 25,
          "rotation": 44,
          "vsPace": 26,
          "vsSpin": 29,
          "control": 57,
          "movement": 67,
          "variation": 79,
          "stamina": 80,
          "catching": 48,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        872,
        778,
        656,
        586,
        911,
        353,
        420,
        823
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p129",
      "name": "Oren Norford",
      "birthDate": "1987-04-23",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 60,
          "power": 56,
          "rotation": 58,
          "vsPace": 55,
          "vsSpin": 46,
          "control": 47,
          "movement": 54,
          "variation": 46,
          "stamina": 63,
          "catching": 69,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 25
        },
        "ODI": {
          "defence": 65,
          "timing": 53,
          "power": 42,
          "rotation": 63,
          "vsPace": 38,
          "vsSpin": 67,
          "control": 55,
          "movement": 54,
          "variation": 53,
          "stamina": 39,
          "catching": 54,
          "groundFielding": 56,
          "throwing": 64,
          "keeping": 27
        },
        "RED_BALL": {
          "defence": 48,
          "timing": 45,
          "power": 54,
          "rotation": 54,
          "vsPace": 41,
          "vsSpin": 54,
          "control": 45,
          "movement": 45,
          "variation": 54,
          "stamina": 64,
          "catching": 52,
          "groundFielding": 55,
          "throwing": 42,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        669,
        720,
        482,
        852,
        422,
        390,
        982,
        367
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p130",
      "name": "Walen Jorbridge",
      "birthDate": "2000-05-06",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 47,
          "timing": 60,
          "power": 53,
          "rotation": 60,
          "vsPace": 52,
          "vsSpin": 61,
          "control": 55,
          "movement": 48,
          "variation": 43,
          "stamina": 42,
          "catching": 50,
          "groundFielding": 71,
          "throwing": 67,
          "keeping": 26
        },
        "ODI": {
          "defence": 48,
          "timing": 45,
          "power": 38,
          "rotation": 44,
          "vsPace": 53,
          "vsSpin": 54,
          "control": 46,
          "movement": 40,
          "variation": 57,
          "stamina": 45,
          "catching": 71,
          "groundFielding": 72,
          "throwing": 49,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 58,
          "power": 44,
          "rotation": 43,
          "vsPace": 65,
          "vsSpin": 55,
          "control": 62,
          "movement": 46,
          "variation": 57,
          "stamina": 37,
          "catching": 57,
          "groundFielding": 59,
          "throwing": 56,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        549,
        245,
        719,
        699,
        624,
        266,
        958,
        326
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p131",
      "name": "Quill Harcombe",
      "birthDate": "1987-01-22",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 63,
          "timing": 48,
          "power": 48,
          "rotation": 49,
          "vsPace": 63,
          "vsSpin": 39,
          "control": 59,
          "movement": 56,
          "variation": 38,
          "stamina": 65,
          "catching": 51,
          "groundFielding": 42,
          "throwing": 58,
          "keeping": 38
        },
        "ODI": {
          "defence": 44,
          "timing": 43,
          "power": 47,
          "rotation": 45,
          "vsPace": 47,
          "vsSpin": 49,
          "control": 40,
          "movement": 59,
          "variation": 39,
          "stamina": 42,
          "catching": 46,
          "groundFielding": 66,
          "throwing": 43,
          "keeping": 19
        },
        "RED_BALL": {
          "defence": 60,
          "timing": 66,
          "power": 61,
          "rotation": 67,
          "vsPace": 59,
          "vsSpin": 42,
          "control": 49,
          "movement": 47,
          "variation": 65,
          "stamina": 47,
          "catching": 57,
          "groundFielding": 61,
          "throwing": 46,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        599,
        839,
        878,
        997,
        263,
        270,
        289,
        426
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p132",
      "name": "Halen Quenstone",
      "birthDate": "2003-01-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 51,
          "power": 73,
          "rotation": 56,
          "vsPace": 76,
          "vsSpin": 63,
          "control": 30,
          "movement": 30,
          "variation": 38,
          "stamina": 36,
          "catching": 56,
          "groundFielding": 63,
          "throwing": 57,
          "keeping": 23
        },
        "ODI": {
          "defence": 51,
          "timing": 71,
          "power": 78,
          "rotation": 50,
          "vsPace": 59,
          "vsSpin": 67,
          "control": 15,
          "movement": 29,
          "variation": 44,
          "stamina": 15,
          "catching": 39,
          "groundFielding": 57,
          "throwing": 67,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 74,
          "timing": 67,
          "power": 52,
          "rotation": 67,
          "vsPace": 52,
          "vsSpin": 63,
          "control": 17,
          "movement": 23,
          "variation": 14,
          "stamina": 42,
          "catching": 64,
          "groundFielding": 40,
          "throwing": 58,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        325,
        666,
        348,
        648,
        538,
        960,
        677,
        963
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p133",
      "name": "Miran Falkridge",
      "birthDate": "2005-11-18",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 51,
          "timing": 54,
          "power": 63,
          "rotation": 66,
          "vsPace": 76,
          "vsSpin": 60,
          "control": 14,
          "movement": 24,
          "variation": 34,
          "stamina": 18,
          "catching": 55,
          "groundFielding": 59,
          "throwing": 53,
          "keeping": 19
        },
        "ODI": {
          "defence": 78,
          "timing": 54,
          "power": 66,
          "rotation": 63,
          "vsPace": 79,
          "vsSpin": 74,
          "control": 39,
          "movement": 15,
          "variation": 14,
          "stamina": 21,
          "catching": 65,
          "groundFielding": 50,
          "throwing": 51,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 58,
          "power": 70,
          "rotation": 50,
          "vsPace": 77,
          "vsSpin": 78,
          "control": 27,
          "movement": 24,
          "variation": 22,
          "stamina": 17,
          "catching": 44,
          "groundFielding": 50,
          "throwing": 47,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        551,
        297,
        340,
        522,
        690,
        919,
        670,
        493
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p134",
      "name": "Elio Dunfell",
      "birthDate": "1989-03-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 52,
          "timing": 77,
          "power": 77,
          "rotation": 56,
          "vsPace": 65,
          "vsSpin": 58,
          "control": 21,
          "movement": 26,
          "variation": 17,
          "stamina": 19,
          "catching": 67,
          "groundFielding": 58,
          "throwing": 48,
          "keeping": 11
        },
        "ODI": {
          "defence": 50,
          "timing": 58,
          "power": 76,
          "rotation": 69,
          "vsPace": 77,
          "vsSpin": 72,
          "control": 39,
          "movement": 33,
          "variation": 41,
          "stamina": 32,
          "catching": 57,
          "groundFielding": 50,
          "throwing": 63,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 66,
          "power": 57,
          "rotation": 72,
          "vsPace": 67,
          "vsSpin": 72,
          "control": 44,
          "movement": 40,
          "variation": 30,
          "stamina": 43,
          "catching": 48,
          "groundFielding": 61,
          "throwing": 60,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        978,
        452,
        353,
        480,
        940,
        708,
        433,
        349
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p135",
      "name": "Eren Quenstead",
      "birthDate": "2007-02-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 58,
          "power": 73,
          "rotation": 53,
          "vsPace": 71,
          "vsSpin": 75,
          "control": 34,
          "movement": 23,
          "variation": 44,
          "stamina": 25,
          "catching": 54,
          "groundFielding": 55,
          "throwing": 48,
          "keeping": 23
        },
        "ODI": {
          "defence": 54,
          "timing": 67,
          "power": 58,
          "rotation": 76,
          "vsPace": 61,
          "vsSpin": 56,
          "control": 27,
          "movement": 37,
          "variation": 26,
          "stamina": 42,
          "catching": 50,
          "groundFielding": 37,
          "throwing": 58,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 57,
          "timing": 65,
          "power": 51,
          "rotation": 73,
          "vsPace": 60,
          "vsSpin": 78,
          "control": 34,
          "movement": 23,
          "variation": 30,
          "stamina": 31,
          "catching": 43,
          "groundFielding": 60,
          "throwing": 39,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        658,
        275,
        311,
        699,
        207,
        341,
        556,
        672
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p136",
      "name": "Eren Rookmere",
      "birthDate": "1990-02-19",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 53,
          "power": 74,
          "rotation": 65,
          "vsPace": 70,
          "vsSpin": 63,
          "control": 37,
          "movement": 22,
          "variation": 30,
          "stamina": 27,
          "catching": 60,
          "groundFielding": 40,
          "throwing": 39,
          "keeping": 20
        },
        "ODI": {
          "defence": 57,
          "timing": 79,
          "power": 80,
          "rotation": 75,
          "vsPace": 73,
          "vsSpin": 73,
          "control": 25,
          "movement": 35,
          "variation": 16,
          "stamina": 42,
          "catching": 59,
          "groundFielding": 64,
          "throwing": 38,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 50,
          "power": 50,
          "rotation": 68,
          "vsPace": 72,
          "vsSpin": 58,
          "control": 16,
          "movement": 36,
          "variation": 24,
          "stamina": 44,
          "catching": 43,
          "groundFielding": 67,
          "throwing": 61,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        446,
        685,
        661,
        273,
        675,
        361,
        355,
        794
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p137",
      "name": "Elio Norbrook",
      "birthDate": "2004-01-14",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 53,
          "power": 80,
          "rotation": 52,
          "vsPace": 79,
          "vsSpin": 63,
          "control": 20,
          "movement": 33,
          "variation": 17,
          "stamina": 28,
          "catching": 64,
          "groundFielding": 65,
          "throwing": 43,
          "keeping": 35
        },
        "ODI": {
          "defence": 57,
          "timing": 54,
          "power": 68,
          "rotation": 58,
          "vsPace": 65,
          "vsSpin": 72,
          "control": 29,
          "movement": 26,
          "variation": 27,
          "stamina": 42,
          "catching": 56,
          "groundFielding": 40,
          "throwing": 38,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 64,
          "timing": 52,
          "power": 62,
          "rotation": 72,
          "vsPace": 56,
          "vsSpin": 79,
          "control": 27,
          "movement": 17,
          "variation": 38,
          "stamina": 22,
          "catching": 66,
          "groundFielding": 63,
          "throwing": 54,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        539,
        482,
        812,
        800,
        952,
        836,
        992,
        706
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p138",
      "name": "Belan Quencroft",
      "birthDate": "1998-04-18",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 61,
          "timing": 60,
          "power": 58,
          "rotation": 68,
          "vsPace": 73,
          "vsSpin": 57,
          "control": 35,
          "movement": 26,
          "variation": 21,
          "stamina": 20,
          "catching": 64,
          "groundFielding": 57,
          "throwing": 55,
          "keeping": 32
        },
        "ODI": {
          "defence": 65,
          "timing": 67,
          "power": 65,
          "rotation": 70,
          "vsPace": 71,
          "vsSpin": 78,
          "control": 32,
          "movement": 37,
          "variation": 30,
          "stamina": 26,
          "catching": 42,
          "groundFielding": 53,
          "throwing": 51,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 73,
          "timing": 61,
          "power": 72,
          "rotation": 52,
          "vsPace": 75,
          "vsSpin": 78,
          "control": 25,
          "movement": 35,
          "variation": 42,
          "stamina": 42,
          "catching": 47,
          "groundFielding": 48,
          "throwing": 50,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        673,
        756,
        695,
        641,
        702,
        640,
        408,
        285
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p139",
      "name": "Caro Sablefield 19",
      "birthDate": "2007-10-10",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 55,
          "timing": 74,
          "power": 65,
          "rotation": 53,
          "vsPace": 53,
          "vsSpin": 75,
          "control": 23,
          "movement": 31,
          "variation": 21,
          "stamina": 27,
          "catching": 54,
          "groundFielding": 53,
          "throwing": 43,
          "keeping": 12
        },
        "ODI": {
          "defence": 71,
          "timing": 74,
          "power": 56,
          "rotation": 66,
          "vsPace": 68,
          "vsSpin": 54,
          "control": 24,
          "movement": 31,
          "variation": 17,
          "stamina": 39,
          "catching": 56,
          "groundFielding": 48,
          "throwing": 49,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 57,
          "power": 47,
          "rotation": 71,
          "vsPace": 63,
          "vsSpin": 72,
          "control": 41,
          "movement": 15,
          "variation": 35,
          "stamina": 29,
          "catching": 49,
          "groundFielding": 49,
          "throwing": 55,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        941,
        779,
        733,
        649,
        702,
        652,
        544,
        240
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p140",
      "name": "Rilan Dunwick",
      "birthDate": "1995-01-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 63,
          "power": 74,
          "rotation": 76,
          "vsPace": 65,
          "vsSpin": 76,
          "control": 44,
          "movement": 42,
          "variation": 23,
          "stamina": 28,
          "catching": 52,
          "groundFielding": 51,
          "throwing": 51,
          "keeping": 21
        },
        "ODI": {
          "defence": 77,
          "timing": 69,
          "power": 54,
          "rotation": 71,
          "vsPace": 74,
          "vsSpin": 78,
          "control": 44,
          "movement": 22,
          "variation": 21,
          "stamina": 23,
          "catching": 44,
          "groundFielding": 67,
          "throwing": 38,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 58,
          "power": 56,
          "rotation": 59,
          "vsPace": 79,
          "vsSpin": 53,
          "control": 28,
          "movement": 24,
          "variation": 31,
          "stamina": 23,
          "catching": 52,
          "groundFielding": 49,
          "throwing": 56,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        529,
        773,
        309,
        938,
        794,
        980,
        712,
        855
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p141",
      "name": "Rilan Sablecroft",
      "birthDate": "2006-06-16",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 50,
          "power": 53,
          "rotation": 53,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 28,
          "movement": 20,
          "variation": 12,
          "stamina": 34,
          "catching": 48,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 56
        },
        "ODI": {
          "defence": 55,
          "timing": 46,
          "power": 53,
          "rotation": 53,
          "vsPace": 55,
          "vsSpin": 59,
          "control": 31,
          "movement": 41,
          "variation": 12,
          "stamina": 41,
          "catching": 71,
          "groundFielding": 70,
          "throwing": 67,
          "keeping": 72
        },
        "RED_BALL": {
          "defence": 69,
          "timing": 45,
          "power": 31,
          "rotation": 41,
          "vsPace": 43,
          "vsSpin": 51,
          "control": 21,
          "movement": 38,
          "variation": 36,
          "stamina": 19,
          "catching": 46,
          "groundFielding": 53,
          "throwing": 65,
          "keeping": 76
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        206,
        622,
        342,
        507,
        501,
        476,
        388,
        614
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p142",
      "name": "Pavan Jorstone",
      "birthDate": "1999-11-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 42,
          "power": 66,
          "rotation": 49,
          "vsPace": 53,
          "vsSpin": 41,
          "control": 36,
          "movement": 38,
          "variation": 37,
          "stamina": 41,
          "catching": 51,
          "groundFielding": 41,
          "throwing": 71,
          "keeping": 63
        },
        "ODI": {
          "defence": 51,
          "timing": 59,
          "power": 50,
          "rotation": 43,
          "vsPace": 50,
          "vsSpin": 53,
          "control": 27,
          "movement": 37,
          "variation": 18,
          "stamina": 36,
          "catching": 43,
          "groundFielding": 48,
          "throwing": 45,
          "keeping": 60
        },
        "RED_BALL": {
          "defence": 64,
          "timing": 51,
          "power": 39,
          "rotation": 38,
          "vsPace": 41,
          "vsSpin": 52,
          "control": 27,
          "movement": 26,
          "variation": 15,
          "stamina": 33,
          "catching": 42,
          "groundFielding": 56,
          "throwing": 43,
          "keeping": 75
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        526,
        434,
        275,
        985,
        273,
        445,
        577,
        521
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p143",
      "name": "Halen Orinmere",
      "birthDate": "1995-05-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 24,
          "timing": 22,
          "power": 43,
          "rotation": 30,
          "vsPace": 34,
          "vsSpin": 40,
          "control": 76,
          "movement": 52,
          "variation": 50,
          "stamina": 56,
          "catching": 47,
          "groundFielding": 62,
          "throwing": 67,
          "keeping": 30
        },
        "ODI": {
          "defence": 40,
          "timing": 23,
          "power": 28,
          "rotation": 25,
          "vsPace": 48,
          "vsSpin": 32,
          "control": 50,
          "movement": 55,
          "variation": 71,
          "stamina": 63,
          "catching": 67,
          "groundFielding": 69,
          "throwing": 55,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 35,
          "power": 31,
          "rotation": 19,
          "vsPace": 26,
          "vsSpin": 27,
          "control": 72,
          "movement": 61,
          "variation": 68,
          "stamina": 56,
          "catching": 56,
          "groundFielding": 64,
          "throwing": 50,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        895,
        882,
        998,
        602,
        488,
        751,
        508,
        379
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p144",
      "name": "Rilan Ternford",
      "birthDate": "1995-11-04",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 45,
          "power": 29,
          "rotation": 35,
          "vsPace": 48,
          "vsSpin": 47,
          "control": 58,
          "movement": 72,
          "variation": 58,
          "stamina": 53,
          "catching": 44,
          "groundFielding": 46,
          "throwing": 47,
          "keeping": 40
        },
        "ODI": {
          "defence": 23,
          "timing": 48,
          "power": 27,
          "rotation": 34,
          "vsPace": 47,
          "vsSpin": 37,
          "control": 69,
          "movement": 50,
          "variation": 60,
          "stamina": 51,
          "catching": 44,
          "groundFielding": 55,
          "throwing": 45,
          "keeping": 33
        },
        "RED_BALL": {
          "defence": 40,
          "timing": 27,
          "power": 29,
          "rotation": 32,
          "vsPace": 44,
          "vsSpin": 20,
          "control": 66,
          "movement": 66,
          "variation": 69,
          "stamina": 65,
          "catching": 61,
          "groundFielding": 64,
          "throwing": 47,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        397,
        792,
        913,
        206,
        591,
        888,
        479,
        844
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p145",
      "name": "Caro Jorwell",
      "birthDate": "2003-04-05",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 41,
          "power": 48,
          "rotation": 23,
          "vsPace": 30,
          "vsSpin": 27,
          "control": 71,
          "movement": 50,
          "variation": 61,
          "stamina": 79,
          "catching": 54,
          "groundFielding": 48,
          "throwing": 62,
          "keeping": 35
        },
        "ODI": {
          "defence": 24,
          "timing": 40,
          "power": 31,
          "rotation": 24,
          "vsPace": 45,
          "vsSpin": 41,
          "control": 62,
          "movement": 70,
          "variation": 75,
          "stamina": 75,
          "catching": 54,
          "groundFielding": 59,
          "throwing": 66,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 49,
          "power": 27,
          "rotation": 21,
          "vsPace": 23,
          "vsSpin": 26,
          "control": 66,
          "movement": 74,
          "variation": 56,
          "stamina": 61,
          "catching": 47,
          "groundFielding": 58,
          "throwing": 45,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        873,
        213,
        669,
        741,
        604,
        688,
        678,
        674
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p146",
      "name": "Nave Orincombe",
      "birthDate": "1992-10-23",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 39,
          "timing": 37,
          "power": 45,
          "rotation": 35,
          "vsPace": 30,
          "vsSpin": 30,
          "control": 70,
          "movement": 64,
          "variation": 54,
          "stamina": 54,
          "catching": 43,
          "groundFielding": 49,
          "throwing": 53,
          "keeping": 25
        },
        "ODI": {
          "defence": 45,
          "timing": 43,
          "power": 35,
          "rotation": 44,
          "vsPace": 39,
          "vsSpin": 49,
          "control": 58,
          "movement": 70,
          "variation": 70,
          "stamina": 67,
          "catching": 41,
          "groundFielding": 61,
          "throwing": 58,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 48,
          "power": 41,
          "rotation": 30,
          "vsPace": 19,
          "vsSpin": 22,
          "control": 71,
          "movement": 56,
          "variation": 77,
          "stamina": 72,
          "catching": 59,
          "groundFielding": 59,
          "throwing": 65,
          "keeping": 18
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        301,
        506,
        311,
        999,
        880,
        420,
        945,
        213
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p147",
      "name": "Elio Yewwell",
      "birthDate": "2001-11-22",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 31,
          "timing": 34,
          "power": 49,
          "rotation": 33,
          "vsPace": 30,
          "vsSpin": 37,
          "control": 55,
          "movement": 59,
          "variation": 71,
          "stamina": 76,
          "catching": 50,
          "groundFielding": 53,
          "throwing": 52,
          "keeping": 12
        },
        "ODI": {
          "defence": 47,
          "timing": 34,
          "power": 46,
          "rotation": 30,
          "vsPace": 22,
          "vsSpin": 34,
          "control": 75,
          "movement": 51,
          "variation": 53,
          "stamina": 60,
          "catching": 39,
          "groundFielding": 60,
          "throwing": 57,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 54,
          "timing": 26,
          "power": 29,
          "rotation": 30,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 62,
          "movement": 60,
          "variation": 52,
          "stamina": 69,
          "catching": 69,
          "groundFielding": 63,
          "throwing": 65,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        882,
        373,
        542,
        439,
        374,
        374,
        736,
        266
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p148",
      "name": "Deren Norwick",
      "birthDate": "1992-11-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 34,
          "power": 25,
          "rotation": 35,
          "vsPace": 39,
          "vsSpin": 25,
          "control": 79,
          "movement": 78,
          "variation": 53,
          "stamina": 70,
          "catching": 69,
          "groundFielding": 56,
          "throwing": 60,
          "keeping": 33
        },
        "ODI": {
          "defence": 37,
          "timing": 44,
          "power": 24,
          "rotation": 41,
          "vsPace": 38,
          "vsSpin": 21,
          "control": 50,
          "movement": 51,
          "variation": 55,
          "stamina": 67,
          "catching": 41,
          "groundFielding": 64,
          "throwing": 68,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 42,
          "timing": 45,
          "power": 26,
          "rotation": 30,
          "vsPace": 46,
          "vsSpin": 31,
          "control": 79,
          "movement": 76,
          "variation": 64,
          "stamina": 54,
          "catching": 51,
          "groundFielding": 66,
          "throwing": 53,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        200,
        823,
        328,
        585,
        951,
        503,
        696,
        715
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p149",
      "name": "Galen Zornwick",
      "birthDate": "1998-07-01",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 60,
          "timing": 57,
          "power": 70,
          "rotation": 64,
          "vsPace": 48,
          "vsSpin": 45,
          "control": 41,
          "movement": 60,
          "variation": 58,
          "stamina": 63,
          "catching": 55,
          "groundFielding": 72,
          "throwing": 48,
          "keeping": 36
        },
        "ODI": {
          "defence": 50,
          "timing": 55,
          "power": 39,
          "rotation": 48,
          "vsPace": 47,
          "vsSpin": 58,
          "control": 59,
          "movement": 46,
          "variation": 51,
          "stamina": 52,
          "catching": 51,
          "groundFielding": 43,
          "throwing": 47,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 68,
          "power": 56,
          "rotation": 57,
          "vsPace": 67,
          "vsSpin": 52,
          "control": 49,
          "movement": 64,
          "variation": 60,
          "stamina": 46,
          "catching": 59,
          "groundFielding": 56,
          "throwing": 49,
          "keeping": 30
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        450,
        480,
        658,
        273,
        913,
        577,
        543,
        670
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p150",
      "name": "Borin Jorfield",
      "birthDate": "2007-08-03",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 67,
          "power": 46,
          "rotation": 49,
          "vsPace": 41,
          "vsSpin": 61,
          "control": 65,
          "movement": 58,
          "variation": 42,
          "stamina": 40,
          "catching": 49,
          "groundFielding": 71,
          "throwing": 47,
          "keeping": 12
        },
        "ODI": {
          "defence": 58,
          "timing": 56,
          "power": 56,
          "rotation": 40,
          "vsPace": 61,
          "vsSpin": 51,
          "control": 49,
          "movement": 42,
          "variation": 38,
          "stamina": 57,
          "catching": 51,
          "groundFielding": 44,
          "throwing": 66,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 67,
          "power": 42,
          "rotation": 42,
          "vsPace": 66,
          "vsSpin": 51,
          "control": 58,
          "movement": 45,
          "variation": 56,
          "stamina": 40,
          "catching": 68,
          "groundFielding": 55,
          "throwing": 42,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        501,
        429,
        592,
        335,
        549,
        786,
        997,
        258
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p151",
      "name": "Zerin Harridge",
      "birthDate": "2000-05-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 41,
          "timing": 53,
          "power": 50,
          "rotation": 43,
          "vsPace": 53,
          "vsSpin": 56,
          "control": 64,
          "movement": 51,
          "variation": 53,
          "stamina": 50,
          "catching": 68,
          "groundFielding": 59,
          "throwing": 67,
          "keeping": 13
        },
        "ODI": {
          "defence": 41,
          "timing": 67,
          "power": 38,
          "rotation": 38,
          "vsPace": 40,
          "vsSpin": 56,
          "control": 47,
          "movement": 65,
          "variation": 54,
          "stamina": 39,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 66,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 50,
          "timing": 44,
          "power": 55,
          "rotation": 57,
          "vsPace": 38,
          "vsSpin": 57,
          "control": 47,
          "movement": 59,
          "variation": 51,
          "stamina": 61,
          "catching": 47,
          "groundFielding": 45,
          "throwing": 49,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        584,
        570,
        841,
        998,
        767,
        814,
        270,
        238
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p152",
      "name": "Oren Lornmere",
      "birthDate": "2004-05-27",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 69,
          "power": 75,
          "rotation": 52,
          "vsPace": 71,
          "vsSpin": 67,
          "control": 27,
          "movement": 32,
          "variation": 35,
          "stamina": 44,
          "catching": 52,
          "groundFielding": 44,
          "throwing": 55,
          "keeping": 27
        },
        "ODI": {
          "defence": 50,
          "timing": 61,
          "power": 74,
          "rotation": 50,
          "vsPace": 65,
          "vsSpin": 54,
          "control": 24,
          "movement": 24,
          "variation": 22,
          "stamina": 17,
          "catching": 46,
          "groundFielding": 47,
          "throwing": 67,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 53,
          "power": 70,
          "rotation": 64,
          "vsPace": 62,
          "vsSpin": 56,
          "control": 28,
          "movement": 42,
          "variation": 15,
          "stamina": 25,
          "catching": 47,
          "groundFielding": 37,
          "throwing": 52,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        539,
        300,
        203,
        819,
        329,
        944,
        559,
        506
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p153",
      "name": "Oren Kelwell",
      "birthDate": "1991-11-14",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 79,
          "timing": 55,
          "power": 61,
          "rotation": 68,
          "vsPace": 64,
          "vsSpin": 57,
          "control": 27,
          "movement": 24,
          "variation": 36,
          "stamina": 17,
          "catching": 58,
          "groundFielding": 54,
          "throwing": 50,
          "keeping": 11
        },
        "ODI": {
          "defence": 60,
          "timing": 61,
          "power": 69,
          "rotation": 65,
          "vsPace": 79,
          "vsSpin": 59,
          "control": 22,
          "movement": 16,
          "variation": 23,
          "stamina": 17,
          "catching": 58,
          "groundFielding": 49,
          "throwing": 62,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 54,
          "power": 56,
          "rotation": 78,
          "vsPace": 70,
          "vsSpin": 68,
          "control": 43,
          "movement": 16,
          "variation": 37,
          "stamina": 38,
          "catching": 51,
          "groundFielding": 49,
          "throwing": 51,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        821,
        868,
        333,
        281,
        290,
        743,
        728,
        855
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p154",
      "name": "Nerin Ashwell",
      "birthDate": "1995-08-15",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 76,
          "timing": 72,
          "power": 72,
          "rotation": 73,
          "vsPace": 79,
          "vsSpin": 51,
          "control": 41,
          "movement": 38,
          "variation": 25,
          "stamina": 23,
          "catching": 43,
          "groundFielding": 62,
          "throwing": 57,
          "keeping": 22
        },
        "ODI": {
          "defence": 65,
          "timing": 78,
          "power": 65,
          "rotation": 69,
          "vsPace": 61,
          "vsSpin": 67,
          "control": 21,
          "movement": 18,
          "variation": 40,
          "stamina": 24,
          "catching": 51,
          "groundFielding": 67,
          "throwing": 56,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 65,
          "power": 55,
          "rotation": 74,
          "vsPace": 50,
          "vsSpin": 73,
          "control": 19,
          "movement": 33,
          "variation": 37,
          "stamina": 25,
          "catching": 48,
          "groundFielding": 55,
          "throwing": 61,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        721,
        440,
        724,
        668,
        257,
        352,
        452,
        353
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p155",
      "name": "Eren Orinthorne",
      "birthDate": "1996-03-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 77,
          "power": 58,
          "rotation": 69,
          "vsPace": 71,
          "vsSpin": 63,
          "control": 24,
          "movement": 42,
          "variation": 17,
          "stamina": 28,
          "catching": 56,
          "groundFielding": 51,
          "throwing": 64,
          "keeping": 12
        },
        "ODI": {
          "defence": 66,
          "timing": 52,
          "power": 64,
          "rotation": 62,
          "vsPace": 50,
          "vsSpin": 78,
          "control": 23,
          "movement": 27,
          "variation": 15,
          "stamina": 18,
          "catching": 38,
          "groundFielding": 49,
          "throwing": 58,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 78,
          "power": 63,
          "rotation": 53,
          "vsPace": 62,
          "vsSpin": 54,
          "control": 25,
          "movement": 19,
          "variation": 36,
          "stamina": 17,
          "catching": 42,
          "groundFielding": 63,
          "throwing": 65,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        358,
        605,
        607,
        969,
        946,
        475,
        718,
        325
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p156",
      "name": "Miran Quenfell",
      "birthDate": "1989-02-22",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 66,
          "power": 77,
          "rotation": 63,
          "vsPace": 55,
          "vsSpin": 51,
          "control": 24,
          "movement": 30,
          "variation": 41,
          "stamina": 34,
          "catching": 39,
          "groundFielding": 45,
          "throwing": 65,
          "keeping": 35
        },
        "ODI": {
          "defence": 64,
          "timing": 54,
          "power": 54,
          "rotation": 62,
          "vsPace": 57,
          "vsSpin": 63,
          "control": 18,
          "movement": 31,
          "variation": 22,
          "stamina": 30,
          "catching": 48,
          "groundFielding": 64,
          "throwing": 58,
          "keeping": 30
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 59,
          "power": 47,
          "rotation": 79,
          "vsPace": 77,
          "vsSpin": 61,
          "control": 25,
          "movement": 20,
          "variation": 42,
          "stamina": 33,
          "catching": 46,
          "groundFielding": 55,
          "throwing": 54,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        754,
        345,
        805,
        911,
        635,
        821,
        904,
        868
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p157",
      "name": "Vero Norfield",
      "birthDate": "1997-02-07",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 61,
          "timing": 62,
          "power": 70,
          "rotation": 70,
          "vsPace": 58,
          "vsSpin": 55,
          "control": 32,
          "movement": 20,
          "variation": 19,
          "stamina": 14,
          "catching": 38,
          "groundFielding": 49,
          "throwing": 55,
          "keeping": 19
        },
        "ODI": {
          "defence": 50,
          "timing": 71,
          "power": 60,
          "rotation": 59,
          "vsPace": 71,
          "vsSpin": 60,
          "control": 34,
          "movement": 22,
          "variation": 31,
          "stamina": 42,
          "catching": 66,
          "groundFielding": 60,
          "throwing": 66,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 79,
          "timing": 63,
          "power": 63,
          "rotation": 75,
          "vsPace": 76,
          "vsSpin": 55,
          "control": 30,
          "movement": 36,
          "variation": 40,
          "stamina": 34,
          "catching": 41,
          "groundFielding": 43,
          "throwing": 50,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        243,
        968,
        635,
        930,
        759,
        338,
        318,
        426
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p158",
      "name": "Walen Norbridge",
      "birthDate": "1998-10-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 66,
          "power": 84,
          "rotation": 68,
          "vsPace": 80,
          "vsSpin": 66,
          "control": 27,
          "movement": 36,
          "variation": 18,
          "stamina": 23,
          "catching": 52,
          "groundFielding": 65,
          "throwing": 54,
          "keeping": 19
        },
        "ODI": {
          "defence": 60,
          "timing": 67,
          "power": 62,
          "rotation": 71,
          "vsPace": 75,
          "vsSpin": 57,
          "control": 31,
          "movement": 33,
          "variation": 27,
          "stamina": 33,
          "catching": 43,
          "groundFielding": 64,
          "throwing": 45,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 79,
          "power": 64,
          "rotation": 52,
          "vsPace": 79,
          "vsSpin": 75,
          "control": 40,
          "movement": 34,
          "variation": 36,
          "stamina": 42,
          "catching": 56,
          "groundFielding": 40,
          "throwing": 54,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        404,
        994,
        500,
        710,
        410,
        410,
        893,
        935
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p159",
      "name": "Nerin Yewfield",
      "birthDate": "1993-12-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 80,
          "power": 81,
          "rotation": 65,
          "vsPace": 65,
          "vsSpin": 69,
          "control": 44,
          "movement": 15,
          "variation": 39,
          "stamina": 16,
          "catching": 67,
          "groundFielding": 49,
          "throwing": 46,
          "keeping": 41
        },
        "ODI": {
          "defence": 68,
          "timing": 59,
          "power": 52,
          "rotation": 57,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 42,
          "movement": 33,
          "variation": 42,
          "stamina": 29,
          "catching": 64,
          "groundFielding": 57,
          "throwing": 45,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 58,
          "power": 73,
          "rotation": 80,
          "vsPace": 64,
          "vsSpin": 53,
          "control": 39,
          "movement": 23,
          "variation": 26,
          "stamina": 40,
          "catching": 56,
          "groundFielding": 50,
          "throwing": 60,
          "keeping": 12
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        403,
        914,
        988,
        266,
        785,
        607,
        522,
        395
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p160",
      "name": "Rilan Yewbridge",
      "birthDate": "1998-02-04",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 52,
          "power": 69,
          "rotation": 57,
          "vsPace": 53,
          "vsSpin": 70,
          "control": 33,
          "movement": 44,
          "variation": 41,
          "stamina": 18,
          "catching": 67,
          "groundFielding": 59,
          "throwing": 57,
          "keeping": 29
        },
        "ODI": {
          "defence": 52,
          "timing": 80,
          "power": 76,
          "rotation": 77,
          "vsPace": 58,
          "vsSpin": 59,
          "control": 39,
          "movement": 42,
          "variation": 38,
          "stamina": 27,
          "catching": 52,
          "groundFielding": 66,
          "throwing": 50,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 75,
          "power": 60,
          "rotation": 54,
          "vsPace": 70,
          "vsSpin": 63,
          "control": 18,
          "movement": 31,
          "variation": 42,
          "stamina": 43,
          "catching": 40,
          "groundFielding": 41,
          "throwing": 61,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        651,
        392,
        434,
        495,
        242,
        984,
        898,
        624
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    }
  ],
  "teams": [
    {
      "teamId": "team-01",
      "name": "Aster Harbour",
      "squadIds": [
        "p001",
        "p002",
        "p003",
        "p004",
        "p005",
        "p006",
        "p007",
        "p008",
        "p009",
        "p010",
        "p011",
        "p012",
        "p013",
        "p014",
        "p015",
        "p016",
        "p017",
        "p018",
        "p019",
        "p020"
      ],
      "colours": [
        "#254B69",
        "#E6C97D"
      ]
    },
    {
      "teamId": "team-02",
      "name": "Copper Vale",
      "squadIds": [
        "p021",
        "p022",
        "p023",
        "p024",
        "p025",
        "p026",
        "p027",
        "p028",
        "p029",
        "p030",
        "p031",
        "p032",
        "p033",
        "p034",
        "p035",
        "p036",
        "p037",
        "p038",
        "p039",
        "p040"
      ],
      "colours": [
        "#9B4A32",
        "#EEE5D1"
      ]
    },
    {
      "teamId": "team-03",
      "name": "Northlight Ridge",
      "squadIds": [
        "p041",
        "p042",
        "p043",
        "p044",
        "p045",
        "p046",
        "p047",
        "p048",
        "p049",
        "p050",
        "p051",
        "p052",
        "p053",
        "p054",
        "p055",
        "p056",
        "p057",
        "p058",
        "p059",
        "p060"
      ],
      "colours": [
        "#254A3D",
        "#D1DBDC"
      ]
    },
    {
      "teamId": "team-04",
      "name": "Westmere Isles",
      "squadIds": [
        "p061",
        "p062",
        "p063",
        "p064",
        "p065",
        "p066",
        "p067",
        "p068",
        "p069",
        "p070",
        "p071",
        "p072",
        "p073",
        "p074",
        "p075",
        "p076",
        "p077",
        "p078",
        "p079",
        "p080"
      ],
      "colours": [
        "#433E79",
        "#E7CBE5"
      ]
    },
    {
      "teamId": "team-05",
      "name": "Ember Plains",
      "squadIds": [
        "p081",
        "p082",
        "p083",
        "p084",
        "p085",
        "p086",
        "p087",
        "p088",
        "p089",
        "p090",
        "p091",
        "p092",
        "p093",
        "p094",
        "p095",
        "p096",
        "p097",
        "p098",
        "p099",
        "p100"
      ],
      "colours": [
        "#A43D38",
        "#27282E"
      ]
    },
    {
      "teamId": "team-06",
      "name": "Silver Fen",
      "squadIds": [
        "p101",
        "p102",
        "p103",
        "p104",
        "p105",
        "p106",
        "p107",
        "p108",
        "p109",
        "p110",
        "p111",
        "p112",
        "p113",
        "p114",
        "p115",
        "p116",
        "p117",
        "p118",
        "p119",
        "p120"
      ],
      "colours": [
        "#5F7480",
        "#F3E6CA"
      ]
    },
    {
      "teamId": "team-07",
      "name": "Larchwood",
      "squadIds": [
        "p121",
        "p122",
        "p123",
        "p124",
        "p125",
        "p126",
        "p127",
        "p128",
        "p129",
        "p130",
        "p131",
        "p132",
        "p133",
        "p134",
        "p135",
        "p136",
        "p137",
        "p138",
        "p139",
        "p140"
      ],
      "colours": [
        "#395431",
        "#F3B76D"
      ]
    },
    {
      "teamId": "team-08",
      "name": "Moonstone Bay",
      "squadIds": [
        "p141",
        "p142",
        "p143",
        "p144",
        "p145",
        "p146",
        "p147",
        "p148",
        "p149",
        "p150",
        "p151",
        "p152",
        "p153",
        "p154",
        "p155",
        "p156",
        "p157",
        "p158",
        "p159",
        "p160"
      ],
      "colours": [
        "#2A5B69",
        "#D9DDEA"
      ]
    }
  ],
  "grounds": [
    {
      "groundId": "ground-01",
      "name": "Aster Quay",
      "pitchPrior": {
        "seamBp": 6177,
        "turnBp": 6532,
        "variabilityBp": 4835,
        "moistureBp": 5963,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        8098,
        7182,
        7420,
        8266,
        7479,
        7978,
        8045,
        6931
      ],
      "outfieldSpeedBp": 5243
    },
    {
      "groundId": "ground-02",
      "name": "Copperfield",
      "pitchPrior": {
        "seamBp": 3946,
        "turnBp": 5277,
        "variabilityBp": 3840,
        "moistureBp": 4647,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7475,
        8038,
        7893,
        7532,
        7948,
        7349,
        7019,
        7213
      ],
      "outfieldSpeedBp": 4077
    },
    {
      "groundId": "ground-03",
      "name": "Northlight Park",
      "pitchPrior": {
        "seamBp": 5887,
        "turnBp": 6027,
        "variabilityBp": 5931,
        "moistureBp": 5222,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7204,
        7872,
        7641,
        8200,
        7538,
        8077,
        7936,
        6875
      ],
      "outfieldSpeedBp": 4303
    },
    {
      "groundId": "ground-04",
      "name": "Westmere Oval",
      "pitchPrior": {
        "seamBp": 4070,
        "turnBp": 4899,
        "variabilityBp": 6441,
        "moistureBp": 4496,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7587,
        7191,
        8208,
        6975,
        8011,
        6864,
        8345,
        7383
      ],
      "outfieldSpeedBp": 4457
    },
    {
      "groundId": "ground-05",
      "name": "Ember Meadow",
      "pitchPrior": {
        "seamBp": 6866,
        "turnBp": 6651,
        "variabilityBp": 5198,
        "moistureBp": 5995,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7972,
        6928,
        7231,
        7988,
        7989,
        8065,
        7220,
        6729
      ],
      "outfieldSpeedBp": 4302
    },
    {
      "groundId": "ground-06",
      "name": "Silverfen",
      "pitchPrior": {
        "seamBp": 7299,
        "turnBp": 3602,
        "variabilityBp": 6252,
        "moistureBp": 4016,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        8174,
        7699,
        7499,
        7502,
        7661,
        8045,
        8337,
        7332
      ],
      "outfieldSpeedBp": 5892
    },
    {
      "groundId": "ground-07",
      "name": "Larchwood Ground",
      "pitchPrior": {
        "seamBp": 4864,
        "turnBp": 6232,
        "variabilityBp": 6003,
        "moistureBp": 4907,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7244,
        7584,
        7976,
        7439,
        8089,
        8236,
        7218,
        7782
      ],
      "outfieldSpeedBp": 4289
    },
    {
      "groundId": "ground-08",
      "name": "Moonstone Fields",
      "pitchPrior": {
        "seamBp": 4567,
        "turnBp": 4791,
        "variabilityBp": 3999,
        "moistureBp": 4992,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        8089,
        6702,
        7226,
        7499,
        8292,
        7176,
        6829,
        7070
      ],
      "outfieldSpeedBp": 5114
    }
  ],
  "rulesIds": [
    "LC_T20_01",
    "LC_ODI_01",
    "LC_RED5_01"
  ],
  "provenance": "FICTIONAL: One-time offline SHA256_COUNTER_V1 WORLD_GENERATION seed; provisional SYNTHETIC_ALPHA skills, not empirical cricket."
}
`,bl={worldPackId:"fictional-eight-01",schemaVersion:"1.0.0",worldGeneratorVersion:"LC_FICTIONAL_WORLD_GENERATOR_V1",worldSeed:"lcxxvi-fictional-eight-v1-20260927",generatorSourceSha256:"a3aaa4b64926ad9859f84222eb51274e7881df750308c2e9ae8fd1fa66e2f4da",provenanceSourceSha256:"97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",worldFileSha256:"0136173903ba42a199c84a17407cf711c2caf1b57c52472abb52e9be7a6d8257",worldCanonicalSha256:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",worldByteLength:310033,rulesIds:["LC_T20_01","LC_ODI_01","LC_RED5_01"],modelId:"synthetic-alpha-01",modelHash:"d47d5caca955b7a374b0052d712b1674bca6d855e222194ce9f0587d8580b7ab",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:"34efa3037702e44a134ea38b414eab3e97c6f79f10b3e5458bc2ab05412e5d7a",randomId:"SHA256_COUNTER_V1",variationIds:["stock"],provenance:"FICTIONAL",modelStatus:"SYNTHETIC_ALPHA",teamIds:["team-01","team-02","team-03","team-04","team-05","team-06","team-07","team-08"],groundIds:["ground-01","ground-02","ground-03","ground-04","ground-05","ground-06","ground-07","ground-08"],homeGroundIds:{"team-01":"ground-01","team-02":"ground-02","team-03":"ground-03","team-04":"ground-04","team-05":"ground-05","team-06":"ground-06","team-07":"ground-07","team-08":"ground-08"}};function B(n,e,t){function i(s,d){var g;Object.defineProperty(s,"_zod",{value:s._zod??{},enumerable:!1}),(g=s._zod).traits??(g.traits=new Set),s._zod.traits.add(n),e(s,d);for(const E in o.prototype)E in s||Object.defineProperty(s,E,{value:o.prototype[E].bind(s)});s._zod.constr=o,s._zod.def=d}const a=t?.Parent??Object;class r extends a{}Object.defineProperty(r,"name",{value:n});function o(s){var d;const g=t?.Parent?new r:this;i(g,s),(d=g._zod).deferred??(d.deferred=[]);for(const E of g._zod.deferred)E();return g}return Object.defineProperty(o,"init",{value:i}),Object.defineProperty(o,Symbol.hasInstance,{value:s=>t?.Parent&&s instanceof t.Parent?!0:s?._zod?.traits?.has(n)}),Object.defineProperty(o,"name",{value:n}),o}class st extends Error{constructor(){super("Encountered Promise during synchronous parse. Use .parseAsync() instead.")}}class Oo extends Error{constructor(e){super(`Encountered unidirectional transform during encode: ${e}`),this.name="ZodEncodeError"}}const Ki={};function Ne(n){return n&&Object.assign(Ki,n),Ki}function vl(n){const e=Object.values(n).filter(i=>typeof i=="number");return Object.entries(n).filter(([i,a])=>e.indexOf(+i)===-1).map(([i,a])=>a)}function ji(n,e){return typeof e=="bigint"?e.toString():e}function Qt(n){return{get value(){{const e=n();return Object.defineProperty(this,"value",{value:e}),e}}}}function qi(n){return n==null}function Zi(n){const e=n.startsWith("^")?1:0,t=n.endsWith("$")?n.length-1:n.length;return n.slice(e,t)}function Rl(n,e){const t=(n.toString().split(".")[1]||"").length,i=e.toString();let a=(i.split(".")[1]||"").length;if(a===0&&/\d?e-\d?/.test(i)){const d=i.match(/\d?e-(\d?)/);d?.[1]&&(a=Number.parseInt(d[1]))}const r=t>a?t:a,o=Number.parseInt(n.toFixed(r).replace(".","")),s=Number.parseInt(e.toFixed(r).replace(".",""));return o%s/10**r}const wo=Symbol("evaluating");function un(n,e,t){let i;Object.defineProperty(n,e,{get(){if(i!==wo)return i===void 0&&(i=wo,i=t()),i},set(a){Object.defineProperty(n,e,{value:a})},configurable:!0})}function nt(n,e,t){Object.defineProperty(n,e,{value:t,writable:!0,enumerable:!0,configurable:!0})}function et(...n){const e={};for(const t of n){const i=Object.getOwnPropertyDescriptors(t);Object.assign(e,i)}return Object.defineProperties({},e)}function No(n){return JSON.stringify(n)}const Do="captureStackTrace"in Error?Error.captureStackTrace:(...n)=>{};function wt(n){return typeof n=="object"&&n!==null&&!Array.isArray(n)}const Al=Qt(()=>{if(typeof navigator<"u"&&navigator?.userAgent?.includes("Cloudflare"))return!1;try{const n=Function;return new n(""),!0}catch{return!1}});function ct(n){if(wt(n)===!1)return!1;const e=n.constructor;if(e===void 0)return!0;const t=e.prototype;return!(wt(t)===!1||Object.prototype.hasOwnProperty.call(t,"isPrototypeOf")===!1)}function yo(n){return ct(n)?{...n}:Array.isArray(n)?[...n]:n}const Ll=new Set(["string","number","symbol"]);function lt(n){return n.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function He(n,e,t){const i=new n._zod.constr(e??n._zod.def);return(!e||t?.parent)&&(i._zod.parent=n),i}function j(n){const e=n;if(!e)return{};if(typeof e=="string")return{error:()=>e};if(e?.message!==void 0){if(e?.error!==void 0)throw new Error("Cannot specify both `message` and `error` params");e.error=e.message}return delete e.message,typeof e.error=="string"?{...e,error:()=>e.error}:e}function Ol(n){return Object.keys(n).filter(e=>n[e]._zod.optin==="optional"&&n[e]._zod.optout==="optional")}const wl={safeint:[Number.MIN_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],int32:[-2147483648,2147483647],uint32:[0,4294967295],float32:[-34028234663852886e22,34028234663852886e22],float64:[-Number.MAX_VALUE,Number.MAX_VALUE]};function Nl(n,e){const t=n._zod.def,i=et(n._zod.def,{get shape(){const a={};for(const r in e){if(!(r in t.shape))throw new Error(`Unrecognized key: "${r}"`);e[r]&&(a[r]=t.shape[r])}return nt(this,"shape",a),a},checks:[]});return He(n,i)}function Dl(n,e){const t=n._zod.def,i=et(n._zod.def,{get shape(){const a={...n._zod.def.shape};for(const r in e){if(!(r in t.shape))throw new Error(`Unrecognized key: "${r}"`);e[r]&&delete a[r]}return nt(this,"shape",a),a},checks:[]});return He(n,i)}function yl(n,e){if(!ct(e))throw new Error("Invalid input to extend: expected a plain object");const t=n._zod.def.checks;if(t&&t.length>0)throw new Error("Object schemas containing refinements cannot be extended. Use `.safeExtend()` instead.");const a=et(n._zod.def,{get shape(){const r={...n._zod.def.shape,...e};return nt(this,"shape",r),r},checks:[]});return He(n,a)}function Cl(n,e){if(!ct(e))throw new Error("Invalid input to safeExtend: expected a plain object");const t={...n._zod.def,get shape(){const i={...n._zod.def.shape,...e};return nt(this,"shape",i),i},checks:n._zod.def.checks};return He(n,t)}function kl(n,e){const t=et(n._zod.def,{get shape(){const i={...n._zod.def.shape,...e._zod.def.shape};return nt(this,"shape",i),i},get catchall(){return e._zod.def.catchall},checks:[]});return He(n,t)}function Bl(n,e,t){const i=et(e._zod.def,{get shape(){const a=e._zod.def.shape,r={...a};if(t)for(const o in t){if(!(o in a))throw new Error(`Unrecognized key: "${o}"`);t[o]&&(r[o]=n?new n({type:"optional",innerType:a[o]}):a[o])}else for(const o in a)r[o]=n?new n({type:"optional",innerType:a[o]}):a[o];return nt(this,"shape",r),r},checks:[]});return He(e,i)}function Pl(n,e,t){const i=et(e._zod.def,{get shape(){const a=e._zod.def.shape,r={...a};if(t)for(const o in t){if(!(o in r))throw new Error(`Unrecognized key: "${o}"`);t[o]&&(r[o]=new n({type:"nonoptional",innerType:a[o]}))}else for(const o in a)r[o]=new n({type:"nonoptional",innerType:a[o]});return nt(this,"shape",r),r},checks:[]});return He(e,i)}function dt(n,e=0){if(n.aborted===!0)return!0;for(let t=e;t<n.issues.length;t++)if(n.issues[t]?.continue!==!0)return!0;return!1}function tt(n,e){return e.map(t=>{var i;return(i=t).path??(i.path=[]),t.path.unshift(n),t})}function ni(n){return typeof n=="string"?n:n?.message}function Me(n,e,t){const i={...n,path:n.path??[]};if(!n.message){const a=ni(n.inst?._zod.def?.error?.(n))??ni(e?.error?.(n))??ni(t.customError?.(n))??ni(t.localeError?.(n))??"Invalid input";i.message=a}return delete i.inst,delete i.continue,e?.reportInput||delete i.input,i}function Xi(n){return Array.isArray(n)?"array":typeof n=="string"?"string":"unknown"}function Nt(...n){const[e,t,i]=n;return typeof e=="string"?{message:e,code:"custom",input:t,inst:i}:{...e}}const Co=(n,e)=>{n.name="$ZodError",Object.defineProperty(n,"_zod",{value:n._zod,enumerable:!1}),Object.defineProperty(n,"issues",{value:e,enumerable:!1}),n.message=JSON.stringify(e,ji,2),Object.defineProperty(n,"toString",{value:()=>n.message,enumerable:!1})},ko=B("$ZodError",Co),Bo=B("$ZodError",Co,{Parent:Error});function xl(n,e=t=>t.message){const t={},i=[];for(const a of n.issues)a.path.length>0?(t[a.path[0]]=t[a.path[0]]||[],t[a.path[0]].push(e(a))):i.push(e(a));return{formErrors:i,fieldErrors:t}}function Fl(n,e=t=>t.message){const t={_errors:[]},i=a=>{for(const r of a.issues)if(r.code==="invalid_union"&&r.errors.length)r.errors.map(o=>i({issues:o}));else if(r.code==="invalid_key")i({issues:r.issues});else if(r.code==="invalid_element")i({issues:r.issues});else if(r.path.length===0)t._errors.push(e(r));else{let o=t,s=0;for(;s<r.path.length;){const d=r.path[s];s===r.path.length-1?(o[d]=o[d]||{_errors:[]},o[d]._errors.push(e(r))):o[d]=o[d]||{_errors:[]},o=o[d],s++}}};return i(n),t}const Ji=n=>(e,t,i,a)=>{const r=i?Object.assign(i,{async:!1}):{async:!1},o=e._zod.run({value:t,issues:[]},r);if(o instanceof Promise)throw new st;if(o.issues.length){const s=new(a?.Err??n)(o.issues.map(d=>Me(d,r,Ne())));throw Do(s,a?.callee),s}return o.value},Qi=n=>async(e,t,i,a)=>{const r=i?Object.assign(i,{async:!0}):{async:!0};let o=e._zod.run({value:t,issues:[]},r);if(o instanceof Promise&&(o=await o),o.issues.length){const s=new(a?.Err??n)(o.issues.map(d=>Me(d,r,Ne())));throw Do(s,a?.callee),s}return o.value},ei=n=>(e,t,i)=>{const a=i?{...i,async:!1}:{async:!1},r=e._zod.run({value:t,issues:[]},a);if(r instanceof Promise)throw new st;return r.issues.length?{success:!1,error:new(n??ko)(r.issues.map(o=>Me(o,a,Ne())))}:{success:!0,data:r.value}},Hl=ei(Bo),ti=n=>async(e,t,i)=>{const a=i?Object.assign(i,{async:!0}):{async:!0};let r=e._zod.run({value:t,issues:[]},a);return r instanceof Promise&&(r=await r),r.issues.length?{success:!1,error:new n(r.issues.map(o=>Me(o,a,Ne())))}:{success:!0,data:r.value}},Ml=ti(Bo),Vl=n=>(e,t,i)=>{const a=i?Object.assign(i,{direction:"backward"}):{direction:"backward"};return Ji(n)(e,t,a)},Wl=n=>(e,t,i)=>Ji(n)(e,t,i),$l=n=>async(e,t,i)=>{const a=i?Object.assign(i,{direction:"backward"}):{direction:"backward"};return Qi(n)(e,t,a)},Ul=n=>async(e,t,i)=>Qi(n)(e,t,i),Gl=n=>(e,t,i)=>{const a=i?Object.assign(i,{direction:"backward"}):{direction:"backward"};return ei(n)(e,t,a)},zl=n=>(e,t,i)=>ei(n)(e,t,i),Yl=n=>async(e,t,i)=>{const a=i?Object.assign(i,{direction:"backward"}):{direction:"backward"};return ti(n)(e,t,a)},Kl=n=>async(e,t,i)=>ti(n)(e,t,i),jl=/^[cC][^\s-]{8,}$/,ql=/^[0-9a-z]+$/,Zl=/^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/,Xl=/^[0-9a-vA-V]{20}$/,Jl=/^[A-Za-z0-9]{27}$/,Ql=/^[a-zA-Z0-9_-]{21}$/,nd=/^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/,ed=/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/,Po=n=>n?new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${n}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`):/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/,td=/^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/,id="^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";function ad(){return new RegExp(id,"u")}const od=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,rd=/^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/,sd=/^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/,cd=/^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,ld=/^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/,xo=/^[A-Za-z0-9_-]*$/,dd=/^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/,ud=/^\+(?:[0-9]){6,14}[0-9]$/,Fo="(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))",md=new RegExp(`^${Fo}$`);function Ho(n){const e="(?:[01]\\d|2[0-3]):[0-5]\\d";return typeof n.precision=="number"?n.precision===-1?`${e}`:n.precision===0?`${e}:[0-5]\\d`:`${e}:[0-5]\\d\\.\\d{${n.precision}}`:`${e}(?::[0-5]\\d(?:\\.\\d+)?)?`}function gd(n){return new RegExp(`^${Ho(n)}$`)}function pd(n){const e=Ho({precision:n.precision}),t=["Z"];n.local&&t.push(""),n.offset&&t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");const i=`${e}(?:${t.join("|")})`;return new RegExp(`^${Fo}T(?:${i})$`)}const Id=n=>{const e=n?`[\\s\\S]{${n?.minimum??0},${n?.maximum??""}}`:"[\\s\\S]*";return new RegExp(`^${e}$`)},hd=/^-?\d+$/,fd=/^-?\d+(?:\.\d+)?/,Ed=/^(?:true|false)$/i,Sd=/^null$/i,_d=/^[^A-Z]*$/,Td=/^[^a-z]*$/,ie=B("$ZodCheck",(n,e)=>{var t;n._zod??(n._zod={}),n._zod.def=e,(t=n._zod).onattach??(t.onattach=[])}),Mo={number:"number",bigint:"bigint",object:"date"},Vo=B("$ZodCheckLessThan",(n,e)=>{ie.init(n,e);const t=Mo[typeof e.value];n._zod.onattach.push(i=>{const a=i._zod.bag,r=(e.inclusive?a.maximum:a.exclusiveMaximum)??Number.POSITIVE_INFINITY;e.value<r&&(e.inclusive?a.maximum=e.value:a.exclusiveMaximum=e.value)}),n._zod.check=i=>{(e.inclusive?i.value<=e.value:i.value<e.value)||i.issues.push({origin:t,code:"too_big",maximum:e.value,input:i.value,inclusive:e.inclusive,inst:n,continue:!e.abort})}}),Wo=B("$ZodCheckGreaterThan",(n,e)=>{ie.init(n,e);const t=Mo[typeof e.value];n._zod.onattach.push(i=>{const a=i._zod.bag,r=(e.inclusive?a.minimum:a.exclusiveMinimum)??Number.NEGATIVE_INFINITY;e.value>r&&(e.inclusive?a.minimum=e.value:a.exclusiveMinimum=e.value)}),n._zod.check=i=>{(e.inclusive?i.value>=e.value:i.value>e.value)||i.issues.push({origin:t,code:"too_small",minimum:e.value,input:i.value,inclusive:e.inclusive,inst:n,continue:!e.abort})}}),bd=B("$ZodCheckMultipleOf",(n,e)=>{ie.init(n,e),n._zod.onattach.push(t=>{var i;(i=t._zod.bag).multipleOf??(i.multipleOf=e.value)}),n._zod.check=t=>{if(typeof t.value!=typeof e.value)throw new Error("Cannot mix number and bigint in multiple_of check.");(typeof t.value=="bigint"?t.value%e.value===BigInt(0):Rl(t.value,e.value)===0)||t.issues.push({origin:typeof t.value,code:"not_multiple_of",divisor:e.value,input:t.value,inst:n,continue:!e.abort})}}),vd=B("$ZodCheckNumberFormat",(n,e)=>{ie.init(n,e),e.format=e.format||"float64";const t=e.format?.includes("int"),i=t?"int":"number",[a,r]=wl[e.format];n._zod.onattach.push(o=>{const s=o._zod.bag;s.format=e.format,s.minimum=a,s.maximum=r,t&&(s.pattern=hd)}),n._zod.check=o=>{const s=o.value;if(t){if(!Number.isInteger(s)){o.issues.push({expected:i,format:e.format,code:"invalid_type",continue:!1,input:s,inst:n});return}if(!Number.isSafeInteger(s)){s>0?o.issues.push({input:s,code:"too_big",maximum:Number.MAX_SAFE_INTEGER,note:"Integers must be within the safe integer range.",inst:n,origin:i,continue:!e.abort}):o.issues.push({input:s,code:"too_small",minimum:Number.MIN_SAFE_INTEGER,note:"Integers must be within the safe integer range.",inst:n,origin:i,continue:!e.abort});return}}s<a&&o.issues.push({origin:"number",input:s,code:"too_small",minimum:a,inclusive:!0,inst:n,continue:!e.abort}),s>r&&o.issues.push({origin:"number",input:s,code:"too_big",maximum:r,inst:n})}}),Rd=B("$ZodCheckMaxLength",(n,e)=>{var t;ie.init(n,e),(t=n._zod.def).when??(t.when=i=>{const a=i.value;return!qi(a)&&a.length!==void 0}),n._zod.onattach.push(i=>{const a=i._zod.bag.maximum??Number.POSITIVE_INFINITY;e.maximum<a&&(i._zod.bag.maximum=e.maximum)}),n._zod.check=i=>{const a=i.value;if(a.length<=e.maximum)return;const o=Xi(a);i.issues.push({origin:o,code:"too_big",maximum:e.maximum,inclusive:!0,input:a,inst:n,continue:!e.abort})}}),Ad=B("$ZodCheckMinLength",(n,e)=>{var t;ie.init(n,e),(t=n._zod.def).when??(t.when=i=>{const a=i.value;return!qi(a)&&a.length!==void 0}),n._zod.onattach.push(i=>{const a=i._zod.bag.minimum??Number.NEGATIVE_INFINITY;e.minimum>a&&(i._zod.bag.minimum=e.minimum)}),n._zod.check=i=>{const a=i.value;if(a.length>=e.minimum)return;const o=Xi(a);i.issues.push({origin:o,code:"too_small",minimum:e.minimum,inclusive:!0,input:a,inst:n,continue:!e.abort})}}),Ld=B("$ZodCheckLengthEquals",(n,e)=>{var t;ie.init(n,e),(t=n._zod.def).when??(t.when=i=>{const a=i.value;return!qi(a)&&a.length!==void 0}),n._zod.onattach.push(i=>{const a=i._zod.bag;a.minimum=e.length,a.maximum=e.length,a.length=e.length}),n._zod.check=i=>{const a=i.value,r=a.length;if(r===e.length)return;const o=Xi(a),s=r>e.length;i.issues.push({origin:o,...s?{code:"too_big",maximum:e.length}:{code:"too_small",minimum:e.length},inclusive:!0,exact:!0,input:i.value,inst:n,continue:!e.abort})}}),ii=B("$ZodCheckStringFormat",(n,e)=>{var t,i;ie.init(n,e),n._zod.onattach.push(a=>{const r=a._zod.bag;r.format=e.format,e.pattern&&(r.patterns??(r.patterns=new Set),r.patterns.add(e.pattern))}),e.pattern?(t=n._zod).check??(t.check=a=>{e.pattern.lastIndex=0,!e.pattern.test(a.value)&&a.issues.push({origin:"string",code:"invalid_format",format:e.format,input:a.value,...e.pattern?{pattern:e.pattern.toString()}:{},inst:n,continue:!e.abort})}):(i=n._zod).check??(i.check=()=>{})}),Od=B("$ZodCheckRegex",(n,e)=>{ii.init(n,e),n._zod.check=t=>{e.pattern.lastIndex=0,!e.pattern.test(t.value)&&t.issues.push({origin:"string",code:"invalid_format",format:"regex",input:t.value,pattern:e.pattern.toString(),inst:n,continue:!e.abort})}}),wd=B("$ZodCheckLowerCase",(n,e)=>{e.pattern??(e.pattern=_d),ii.init(n,e)}),Nd=B("$ZodCheckUpperCase",(n,e)=>{e.pattern??(e.pattern=Td),ii.init(n,e)}),Dd=B("$ZodCheckIncludes",(n,e)=>{ie.init(n,e);const t=lt(e.includes),i=new RegExp(typeof e.position=="number"?`^.{${e.position}}${t}`:t);e.pattern=i,n._zod.onattach.push(a=>{const r=a._zod.bag;r.patterns??(r.patterns=new Set),r.patterns.add(i)}),n._zod.check=a=>{a.value.includes(e.includes,e.position)||a.issues.push({origin:"string",code:"invalid_format",format:"includes",includes:e.includes,input:a.value,inst:n,continue:!e.abort})}}),yd=B("$ZodCheckStartsWith",(n,e)=>{ie.init(n,e);const t=new RegExp(`^${lt(e.prefix)}.*`);e.pattern??(e.pattern=t),n._zod.onattach.push(i=>{const a=i._zod.bag;a.patterns??(a.patterns=new Set),a.patterns.add(t)}),n._zod.check=i=>{i.value.startsWith(e.prefix)||i.issues.push({origin:"string",code:"invalid_format",format:"starts_with",prefix:e.prefix,input:i.value,inst:n,continue:!e.abort})}}),Cd=B("$ZodCheckEndsWith",(n,e)=>{ie.init(n,e);const t=new RegExp(`.*${lt(e.suffix)}$`);e.pattern??(e.pattern=t),n._zod.onattach.push(i=>{const a=i._zod.bag;a.patterns??(a.patterns=new Set),a.patterns.add(t)}),n._zod.check=i=>{i.value.endsWith(e.suffix)||i.issues.push({origin:"string",code:"invalid_format",format:"ends_with",suffix:e.suffix,input:i.value,inst:n,continue:!e.abort})}}),kd=B("$ZodCheckOverwrite",(n,e)=>{ie.init(n,e),n._zod.check=t=>{t.value=e.tx(t.value)}});class Bd{constructor(e=[]){this.content=[],this.indent=0,this&&(this.args=e)}indented(e){this.indent+=1,e(this),this.indent-=1}write(e){if(typeof e=="function"){e(this,{execution:"sync"}),e(this,{execution:"async"});return}const i=e.split(`
`).filter(o=>o),a=Math.min(...i.map(o=>o.length-o.trimStart().length)),r=i.map(o=>o.slice(a)).map(o=>" ".repeat(this.indent*2)+o);for(const o of r)this.content.push(o)}compile(){const e=Function,t=this?.args,a=[...(this?.content??[""]).map(r=>`  ${r}`)];return new e(...t,a.join(`
`))}}const Pd={major:4,minor:1,patch:12},Sn=B("$ZodType",(n,e)=>{var t;n??(n={}),n._zod.def=e,n._zod.bag=n._zod.bag||{},n._zod.version=Pd;const i=[...n._zod.def.checks??[]];n._zod.traits.has("$ZodCheck")&&i.unshift(n);for(const a of i)for(const r of a._zod.onattach)r(n);if(i.length===0)(t=n._zod).deferred??(t.deferred=[]),n._zod.deferred?.push(()=>{n._zod.run=n._zod.parse});else{const a=(o,s,d)=>{let g=dt(o),E;for(const h of s){if(h._zod.def.when){if(!h._zod.def.when(o))continue}else if(g)continue;const f=o.issues.length,A=h._zod.check(o);if(A instanceof Promise&&d?.async===!1)throw new st;if(E||A instanceof Promise)E=(E??Promise.resolve()).then(async()=>{await A,o.issues.length!==f&&(g||(g=dt(o,f)))});else{if(o.issues.length===f)continue;g||(g=dt(o,f))}}return E?E.then(()=>o):o},r=(o,s,d)=>{if(dt(o))return o.aborted=!0,o;const g=a(s,i,d);if(g instanceof Promise){if(d.async===!1)throw new st;return g.then(E=>n._zod.parse(E,d))}return n._zod.parse(g,d)};n._zod.run=(o,s)=>{if(s.skipChecks)return n._zod.parse(o,s);if(s.direction==="backward"){const g=n._zod.parse({value:o.value,issues:[]},{...s,skipChecks:!0});return g instanceof Promise?g.then(E=>r(E,o,s)):r(g,o,s)}const d=n._zod.parse(o,s);if(d instanceof Promise){if(s.async===!1)throw new st;return d.then(g=>a(g,i,s))}return a(d,i,s)}}n["~standard"]={validate:a=>{try{const r=Hl(n,a);return r.success?{value:r.data}:{issues:r.error?.issues}}catch{return Ml(n,a).then(o=>o.success?{value:o.data}:{issues:o.error?.issues})}},vendor:"zod",version:1}}),na=B("$ZodString",(n,e)=>{Sn.init(n,e),n._zod.pattern=[...n?._zod.bag?.patterns??[]].pop()??Id(n._zod.bag),n._zod.parse=(t,i)=>{if(e.coerce)try{t.value=String(t.value)}catch{}return typeof t.value=="string"||t.issues.push({expected:"string",code:"invalid_type",input:t.value,inst:n}),t}}),vn=B("$ZodStringFormat",(n,e)=>{ii.init(n,e),na.init(n,e)}),xd=B("$ZodGUID",(n,e)=>{e.pattern??(e.pattern=ed),vn.init(n,e)}),Fd=B("$ZodUUID",(n,e)=>{if(e.version){const i={v1:1,v2:2,v3:3,v4:4,v5:5,v6:6,v7:7,v8:8}[e.version];if(i===void 0)throw new Error(`Invalid UUID version: "${e.version}"`);e.pattern??(e.pattern=Po(i))}else e.pattern??(e.pattern=Po());vn.init(n,e)}),Hd=B("$ZodEmail",(n,e)=>{e.pattern??(e.pattern=td),vn.init(n,e)}),Md=B("$ZodURL",(n,e)=>{vn.init(n,e),n._zod.check=t=>{try{const i=t.value.trim(),a=new URL(i);e.hostname&&(e.hostname.lastIndex=0,e.hostname.test(a.hostname)||t.issues.push({code:"invalid_format",format:"url",note:"Invalid hostname",pattern:dd.source,input:t.value,inst:n,continue:!e.abort})),e.protocol&&(e.protocol.lastIndex=0,e.protocol.test(a.protocol.endsWith(":")?a.protocol.slice(0,-1):a.protocol)||t.issues.push({code:"invalid_format",format:"url",note:"Invalid protocol",pattern:e.protocol.source,input:t.value,inst:n,continue:!e.abort})),e.normalize?t.value=a.href:t.value=i;return}catch{t.issues.push({code:"invalid_format",format:"url",input:t.value,inst:n,continue:!e.abort})}}}),Vd=B("$ZodEmoji",(n,e)=>{e.pattern??(e.pattern=ad()),vn.init(n,e)}),Wd=B("$ZodNanoID",(n,e)=>{e.pattern??(e.pattern=Ql),vn.init(n,e)}),$d=B("$ZodCUID",(n,e)=>{e.pattern??(e.pattern=jl),vn.init(n,e)}),Ud=B("$ZodCUID2",(n,e)=>{e.pattern??(e.pattern=ql),vn.init(n,e)}),Gd=B("$ZodULID",(n,e)=>{e.pattern??(e.pattern=Zl),vn.init(n,e)}),zd=B("$ZodXID",(n,e)=>{e.pattern??(e.pattern=Xl),vn.init(n,e)}),Yd=B("$ZodKSUID",(n,e)=>{e.pattern??(e.pattern=Jl),vn.init(n,e)}),Kd=B("$ZodISODateTime",(n,e)=>{e.pattern??(e.pattern=pd(e)),vn.init(n,e)}),jd=B("$ZodISODate",(n,e)=>{e.pattern??(e.pattern=md),vn.init(n,e)}),qd=B("$ZodISOTime",(n,e)=>{e.pattern??(e.pattern=gd(e)),vn.init(n,e)}),Zd=B("$ZodISODuration",(n,e)=>{e.pattern??(e.pattern=nd),vn.init(n,e)}),Xd=B("$ZodIPv4",(n,e)=>{e.pattern??(e.pattern=od),vn.init(n,e),n._zod.onattach.push(t=>{const i=t._zod.bag;i.format="ipv4"})}),Jd=B("$ZodIPv6",(n,e)=>{e.pattern??(e.pattern=rd),vn.init(n,e),n._zod.onattach.push(t=>{const i=t._zod.bag;i.format="ipv6"}),n._zod.check=t=>{try{new URL(`http://[${t.value}]`)}catch{t.issues.push({code:"invalid_format",format:"ipv6",input:t.value,inst:n,continue:!e.abort})}}}),Qd=B("$ZodCIDRv4",(n,e)=>{e.pattern??(e.pattern=sd),vn.init(n,e)}),n0=B("$ZodCIDRv6",(n,e)=>{e.pattern??(e.pattern=cd),vn.init(n,e),n._zod.check=t=>{const i=t.value.split("/");try{if(i.length!==2)throw new Error;const[a,r]=i;if(!r)throw new Error;const o=Number(r);if(`${o}`!==r)throw new Error;if(o<0||o>128)throw new Error;new URL(`http://[${a}]`)}catch{t.issues.push({code:"invalid_format",format:"cidrv6",input:t.value,inst:n,continue:!e.abort})}}});function $o(n){if(n==="")return!0;if(n.length%4!==0)return!1;try{return atob(n),!0}catch{return!1}}const e0=B("$ZodBase64",(n,e)=>{e.pattern??(e.pattern=ld),vn.init(n,e),n._zod.onattach.push(t=>{t._zod.bag.contentEncoding="base64"}),n._zod.check=t=>{$o(t.value)||t.issues.push({code:"invalid_format",format:"base64",input:t.value,inst:n,continue:!e.abort})}});function t0(n){if(!xo.test(n))return!1;const e=n.replace(/[-_]/g,i=>i==="-"?"+":"/"),t=e.padEnd(Math.ceil(e.length/4)*4,"=");return $o(t)}const i0=B("$ZodBase64URL",(n,e)=>{e.pattern??(e.pattern=xo),vn.init(n,e),n._zod.onattach.push(t=>{t._zod.bag.contentEncoding="base64url"}),n._zod.check=t=>{t0(t.value)||t.issues.push({code:"invalid_format",format:"base64url",input:t.value,inst:n,continue:!e.abort})}}),a0=B("$ZodE164",(n,e)=>{e.pattern??(e.pattern=ud),vn.init(n,e)});function o0(n,e=null){try{const t=n.split(".");if(t.length!==3)return!1;const[i]=t;if(!i)return!1;const a=JSON.parse(atob(i));return!("typ"in a&&a?.typ!=="JWT"||!a.alg||e&&(!("alg"in a)||a.alg!==e))}catch{return!1}}const r0=B("$ZodJWT",(n,e)=>{vn.init(n,e),n._zod.check=t=>{o0(t.value,e.alg)||t.issues.push({code:"invalid_format",format:"jwt",input:t.value,inst:n,continue:!e.abort})}}),Uo=B("$ZodNumber",(n,e)=>{Sn.init(n,e),n._zod.pattern=n._zod.bag.pattern??fd,n._zod.parse=(t,i)=>{if(e.coerce)try{t.value=Number(t.value)}catch{}const a=t.value;if(typeof a=="number"&&!Number.isNaN(a)&&Number.isFinite(a))return t;const r=typeof a=="number"?Number.isNaN(a)?"NaN":Number.isFinite(a)?void 0:"Infinity":void 0;return t.issues.push({expected:"number",code:"invalid_type",input:a,inst:n,...r?{received:r}:{}}),t}}),s0=B("$ZodNumber",(n,e)=>{vd.init(n,e),Uo.init(n,e)}),c0=B("$ZodBoolean",(n,e)=>{Sn.init(n,e),n._zod.pattern=Ed,n._zod.parse=(t,i)=>{if(e.coerce)try{t.value=!!t.value}catch{}const a=t.value;return typeof a=="boolean"||t.issues.push({expected:"boolean",code:"invalid_type",input:a,inst:n}),t}}),l0=B("$ZodNull",(n,e)=>{Sn.init(n,e),n._zod.pattern=Sd,n._zod.values=new Set([null]),n._zod.parse=(t,i)=>{const a=t.value;return a===null||t.issues.push({expected:"null",code:"invalid_type",input:a,inst:n}),t}}),d0=B("$ZodUnknown",(n,e)=>{Sn.init(n,e),n._zod.parse=t=>t}),u0=B("$ZodNever",(n,e)=>{Sn.init(n,e),n._zod.parse=(t,i)=>(t.issues.push({expected:"never",code:"invalid_type",input:t.value,inst:n}),t)});function Go(n,e,t){n.issues.length&&e.issues.push(...tt(t,n.issues)),e.value[t]=n.value}const m0=B("$ZodArray",(n,e)=>{Sn.init(n,e),n._zod.parse=(t,i)=>{const a=t.value;if(!Array.isArray(a))return t.issues.push({expected:"array",code:"invalid_type",input:a,inst:n}),t;t.value=Array(a.length);const r=[];for(let o=0;o<a.length;o++){const s=a[o],d=e.element._zod.run({value:s,issues:[]},i);d instanceof Promise?r.push(d.then(g=>Go(g,t,o))):Go(d,t,o)}return r.length?Promise.all(r).then(()=>t):t}});function ai(n,e,t,i){n.issues.length&&e.issues.push(...tt(t,n.issues)),n.value===void 0?t in i&&(e.value[t]=void 0):e.value[t]=n.value}function zo(n){const e=Object.keys(n.shape);for(const i of e)if(!n.shape?.[i]?._zod?.traits?.has("$ZodType"))throw new Error(`Invalid element at key "${i}": expected a Zod schema`);const t=Ol(n.shape);return{...n,keys:e,keySet:new Set(e),numKeys:e.length,optionalKeys:new Set(t)}}function Yo(n,e,t,i,a,r){const o=[],s=a.keySet,d=a.catchall._zod,g=d.def.type;for(const E of Object.keys(e)){if(s.has(E))continue;if(g==="never"){o.push(E);continue}const h=d.run({value:e[E],issues:[]},i);h instanceof Promise?n.push(h.then(f=>ai(f,t,E,e))):ai(h,t,E,e)}return o.length&&t.issues.push({code:"unrecognized_keys",keys:o,input:e,inst:r}),n.length?Promise.all(n).then(()=>t):t}const g0=B("$ZodObject",(n,e)=>{if(Sn.init(n,e),!Object.getOwnPropertyDescriptor(e,"shape")?.get){const s=e.shape;Object.defineProperty(e,"shape",{get:()=>{const d={...s};return Object.defineProperty(e,"shape",{value:d}),d}})}const i=Qt(()=>zo(e));un(n._zod,"propValues",()=>{const s=e.shape,d={};for(const g in s){const E=s[g]._zod;if(E.values){d[g]??(d[g]=new Set);for(const h of E.values)d[g].add(h)}}return d});const a=wt,r=e.catchall;let o;n._zod.parse=(s,d)=>{o??(o=i.value);const g=s.value;if(!a(g))return s.issues.push({expected:"object",code:"invalid_type",input:g,inst:n}),s;s.value={};const E=[],h=o.shape;for(const f of o.keys){const N=h[f]._zod.run({value:g[f],issues:[]},d);N instanceof Promise?E.push(N.then(b=>ai(b,s,f,g))):ai(N,s,f,g)}return r?Yo(E,g,s,d,i.value,n):E.length?Promise.all(E).then(()=>s):s}}),p0=B("$ZodObjectJIT",(n,e)=>{g0.init(n,e);const t=n._zod.parse,i=Qt(()=>zo(e)),a=f=>{const A=new Bd(["shape","payload","ctx"]),N=i.value,b=I=>{const v=No(I);return`shape[${v}]._zod.run({ value: input[${v}], issues: [] }, ctx)`};A.write("const input = payload.value;");const w=Object.create(null);let D=0;for(const I of N.keys)w[I]=`key_${D++}`;A.write("const newResult = {};");for(const I of N.keys){const v=w[I],y=No(I);A.write(`const ${v} = ${b(I)};`),A.write(`
        if (${v}.issues.length) {
          payload.issues = payload.issues.concat(${v}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${y}, ...iss.path] : [${y}]
          })));
        }
        
        
        if (${v}.value === undefined) {
          if (${y} in input) {
            newResult[${y}] = undefined;
          }
        } else {
          newResult[${y}] = ${v}.value;
        }
        
      `)}A.write("payload.value = newResult;"),A.write("return payload;");const p=A.compile();return(I,v)=>p(f,I,v)};let r;const o=wt,s=!Ki.jitless,g=s&&Al.value,E=e.catchall;let h;n._zod.parse=(f,A)=>{h??(h=i.value);const N=f.value;return o(N)?s&&g&&A?.async===!1&&A.jitless!==!0?(r||(r=a(e.shape)),f=r(f,A),E?Yo([],N,f,A,h,n):f):t(f,A):(f.issues.push({expected:"object",code:"invalid_type",input:N,inst:n}),f)}});function Ko(n,e,t,i){for(const r of n)if(r.issues.length===0)return e.value=r.value,e;const a=n.filter(r=>!dt(r));return a.length===1?(e.value=a[0].value,a[0]):(e.issues.push({code:"invalid_union",input:e.value,inst:t,errors:n.map(r=>r.issues.map(o=>Me(o,i,Ne())))}),e)}const jo=B("$ZodUnion",(n,e)=>{Sn.init(n,e),un(n._zod,"optin",()=>e.options.some(a=>a._zod.optin==="optional")?"optional":void 0),un(n._zod,"optout",()=>e.options.some(a=>a._zod.optout==="optional")?"optional":void 0),un(n._zod,"values",()=>{if(e.options.every(a=>a._zod.values))return new Set(e.options.flatMap(a=>Array.from(a._zod.values)))}),un(n._zod,"pattern",()=>{if(e.options.every(a=>a._zod.pattern)){const a=e.options.map(r=>r._zod.pattern);return new RegExp(`^(${a.map(r=>Zi(r.source)).join("|")})$`)}});const t=e.options.length===1,i=e.options[0]._zod.run;n._zod.parse=(a,r)=>{if(t)return i(a,r);let o=!1;const s=[];for(const d of e.options){const g=d._zod.run({value:a.value,issues:[]},r);if(g instanceof Promise)s.push(g),o=!0;else{if(g.issues.length===0)return g;s.push(g)}}return o?Promise.all(s).then(d=>Ko(d,a,n,r)):Ko(s,a,n,r)}}),I0=B("$ZodDiscriminatedUnion",(n,e)=>{jo.init(n,e);const t=n._zod.parse;un(n._zod,"propValues",()=>{const a={};for(const r of e.options){const o=r._zod.propValues;if(!o||Object.keys(o).length===0)throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(r)}"`);for(const[s,d]of Object.entries(o)){a[s]||(a[s]=new Set);for(const g of d)a[s].add(g)}}return a});const i=Qt(()=>{const a=e.options,r=new Map;for(const o of a){const s=o._zod.propValues?.[e.discriminator];if(!s||s.size===0)throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(o)}"`);for(const d of s){if(r.has(d))throw new Error(`Duplicate discriminator value "${String(d)}"`);r.set(d,o)}}return r});n._zod.parse=(a,r)=>{const o=a.value;if(!wt(o))return a.issues.push({code:"invalid_type",expected:"object",input:o,inst:n}),a;const s=i.value.get(o?.[e.discriminator]);return s?s._zod.run(a,r):e.unionFallback?t(a,r):(a.issues.push({code:"invalid_union",errors:[],note:"No matching discriminator",discriminator:e.discriminator,input:o,path:[e.discriminator],inst:n}),a)}}),h0=B("$ZodIntersection",(n,e)=>{Sn.init(n,e),n._zod.parse=(t,i)=>{const a=t.value,r=e.left._zod.run({value:a,issues:[]},i),o=e.right._zod.run({value:a,issues:[]},i);return r instanceof Promise||o instanceof Promise?Promise.all([r,o]).then(([d,g])=>qo(t,d,g)):qo(t,r,o)}});function ea(n,e){if(n===e)return{valid:!0,data:n};if(n instanceof Date&&e instanceof Date&&+n==+e)return{valid:!0,data:n};if(ct(n)&&ct(e)){const t=Object.keys(e),i=Object.keys(n).filter(r=>t.indexOf(r)!==-1),a={...n,...e};for(const r of i){const o=ea(n[r],e[r]);if(!o.valid)return{valid:!1,mergeErrorPath:[r,...o.mergeErrorPath]};a[r]=o.data}return{valid:!0,data:a}}if(Array.isArray(n)&&Array.isArray(e)){if(n.length!==e.length)return{valid:!1,mergeErrorPath:[]};const t=[];for(let i=0;i<n.length;i++){const a=n[i],r=e[i],o=ea(a,r);if(!o.valid)return{valid:!1,mergeErrorPath:[i,...o.mergeErrorPath]};t.push(o.data)}return{valid:!0,data:t}}return{valid:!1,mergeErrorPath:[]}}function qo(n,e,t){if(e.issues.length&&n.issues.push(...e.issues),t.issues.length&&n.issues.push(...t.issues),dt(n))return n;const i=ea(e.value,t.value);if(!i.valid)throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(i.mergeErrorPath)}`);return n.value=i.data,n}const f0=B("$ZodTuple",(n,e)=>{Sn.init(n,e);const t=e.items,i=t.length-[...t].reverse().findIndex(a=>a._zod.optin!=="optional");n._zod.parse=(a,r)=>{const o=a.value;if(!Array.isArray(o))return a.issues.push({input:o,inst:n,expected:"tuple",code:"invalid_type"}),a;a.value=[];const s=[];if(!e.rest){const g=o.length>t.length,E=o.length<i-1;if(g||E)return a.issues.push({...g?{code:"too_big",maximum:t.length}:{code:"too_small",minimum:t.length},input:o,inst:n,origin:"array"}),a}let d=-1;for(const g of t){if(d++,d>=o.length&&d>=i)continue;const E=g._zod.run({value:o[d],issues:[]},r);E instanceof Promise?s.push(E.then(h=>oi(h,a,d))):oi(E,a,d)}if(e.rest){const g=o.slice(t.length);for(const E of g){d++;const h=e.rest._zod.run({value:E,issues:[]},r);h instanceof Promise?s.push(h.then(f=>oi(f,a,d))):oi(h,a,d)}}return s.length?Promise.all(s).then(()=>a):a}});function oi(n,e,t){n.issues.length&&e.issues.push(...tt(t,n.issues)),e.value[t]=n.value}const E0=B("$ZodRecord",(n,e)=>{Sn.init(n,e),n._zod.parse=(t,i)=>{const a=t.value;if(!ct(a))return t.issues.push({expected:"record",code:"invalid_type",input:a,inst:n}),t;const r=[];if(e.keyType._zod.values){const o=e.keyType._zod.values;t.value={};for(const d of o)if(typeof d=="string"||typeof d=="number"||typeof d=="symbol"){const g=e.valueType._zod.run({value:a[d],issues:[]},i);g instanceof Promise?r.push(g.then(E=>{E.issues.length&&t.issues.push(...tt(d,E.issues)),t.value[d]=E.value})):(g.issues.length&&t.issues.push(...tt(d,g.issues)),t.value[d]=g.value)}let s;for(const d in a)o.has(d)||(s=s??[],s.push(d));s&&s.length>0&&t.issues.push({code:"unrecognized_keys",input:a,inst:n,keys:s})}else{t.value={};for(const o of Reflect.ownKeys(a)){if(o==="__proto__")continue;const s=e.keyType._zod.run({value:o,issues:[]},i);if(s instanceof Promise)throw new Error("Async schemas not supported in object keys currently");if(s.issues.length){t.issues.push({code:"invalid_key",origin:"record",issues:s.issues.map(g=>Me(g,i,Ne())),input:o,path:[o],inst:n}),t.value[s.value]=s.value;continue}const d=e.valueType._zod.run({value:a[o],issues:[]},i);d instanceof Promise?r.push(d.then(g=>{g.issues.length&&t.issues.push(...tt(o,g.issues)),t.value[s.value]=g.value})):(d.issues.length&&t.issues.push(...tt(o,d.issues)),t.value[s.value]=d.value)}}return r.length?Promise.all(r).then(()=>t):t}}),S0=B("$ZodEnum",(n,e)=>{Sn.init(n,e);const t=vl(e.entries),i=new Set(t);n._zod.values=i,n._zod.pattern=new RegExp(`^(${t.filter(a=>Ll.has(typeof a)).map(a=>typeof a=="string"?lt(a):a.toString()).join("|")})$`),n._zod.parse=(a,r)=>{const o=a.value;return i.has(o)||a.issues.push({code:"invalid_value",values:t,input:o,inst:n}),a}}),_0=B("$ZodLiteral",(n,e)=>{if(Sn.init(n,e),e.values.length===0)throw new Error("Cannot create literal schema with no valid values");n._zod.values=new Set(e.values),n._zod.pattern=new RegExp(`^(${e.values.map(t=>typeof t=="string"?lt(t):t?lt(t.toString()):String(t)).join("|")})$`),n._zod.parse=(t,i)=>{const a=t.value;return n._zod.values.has(a)||t.issues.push({code:"invalid_value",values:e.values,input:a,inst:n}),t}}),T0=B("$ZodTransform",(n,e)=>{Sn.init(n,e),n._zod.parse=(t,i)=>{if(i.direction==="backward")throw new Oo(n.constructor.name);const a=e.transform(t.value,t);if(i.async)return(a instanceof Promise?a:Promise.resolve(a)).then(o=>(t.value=o,t));if(a instanceof Promise)throw new st;return t.value=a,t}});function Zo(n,e){return n.issues.length&&e===void 0?{issues:[],value:void 0}:n}const b0=B("$ZodOptional",(n,e)=>{Sn.init(n,e),n._zod.optin="optional",n._zod.optout="optional",un(n._zod,"values",()=>e.innerType._zod.values?new Set([...e.innerType._zod.values,void 0]):void 0),un(n._zod,"pattern",()=>{const t=e.innerType._zod.pattern;return t?new RegExp(`^(${Zi(t.source)})?$`):void 0}),n._zod.parse=(t,i)=>{if(e.innerType._zod.optin==="optional"){const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(r=>Zo(r,t.value)):Zo(a,t.value)}return t.value===void 0?t:e.innerType._zod.run(t,i)}}),v0=B("$ZodNullable",(n,e)=>{Sn.init(n,e),un(n._zod,"optin",()=>e.innerType._zod.optin),un(n._zod,"optout",()=>e.innerType._zod.optout),un(n._zod,"pattern",()=>{const t=e.innerType._zod.pattern;return t?new RegExp(`^(${Zi(t.source)}|null)$`):void 0}),un(n._zod,"values",()=>e.innerType._zod.values?new Set([...e.innerType._zod.values,null]):void 0),n._zod.parse=(t,i)=>t.value===null?t:e.innerType._zod.run(t,i)}),R0=B("$ZodDefault",(n,e)=>{Sn.init(n,e),n._zod.optin="optional",un(n._zod,"values",()=>e.innerType._zod.values),n._zod.parse=(t,i)=>{if(i.direction==="backward")return e.innerType._zod.run(t,i);if(t.value===void 0)return t.value=e.defaultValue,t;const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(r=>Xo(r,e)):Xo(a,e)}});function Xo(n,e){return n.value===void 0&&(n.value=e.defaultValue),n}const A0=B("$ZodPrefault",(n,e)=>{Sn.init(n,e),n._zod.optin="optional",un(n._zod,"values",()=>e.innerType._zod.values),n._zod.parse=(t,i)=>(i.direction==="backward"||t.value===void 0&&(t.value=e.defaultValue),e.innerType._zod.run(t,i))}),L0=B("$ZodNonOptional",(n,e)=>{Sn.init(n,e),un(n._zod,"values",()=>{const t=e.innerType._zod.values;return t?new Set([...t].filter(i=>i!==void 0)):void 0}),n._zod.parse=(t,i)=>{const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(r=>Jo(r,n)):Jo(a,n)}});function Jo(n,e){return!n.issues.length&&n.value===void 0&&n.issues.push({code:"invalid_type",expected:"nonoptional",input:n.value,inst:e}),n}const O0=B("$ZodCatch",(n,e)=>{Sn.init(n,e),un(n._zod,"optin",()=>e.innerType._zod.optin),un(n._zod,"optout",()=>e.innerType._zod.optout),un(n._zod,"values",()=>e.innerType._zod.values),n._zod.parse=(t,i)=>{if(i.direction==="backward")return e.innerType._zod.run(t,i);const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(r=>(t.value=r.value,r.issues.length&&(t.value=e.catchValue({...t,error:{issues:r.issues.map(o=>Me(o,i,Ne()))},input:t.value}),t.issues=[]),t)):(t.value=a.value,a.issues.length&&(t.value=e.catchValue({...t,error:{issues:a.issues.map(r=>Me(r,i,Ne()))},input:t.value}),t.issues=[]),t)}}),w0=B("$ZodPipe",(n,e)=>{Sn.init(n,e),un(n._zod,"values",()=>e.in._zod.values),un(n._zod,"optin",()=>e.in._zod.optin),un(n._zod,"optout",()=>e.out._zod.optout),un(n._zod,"propValues",()=>e.in._zod.propValues),n._zod.parse=(t,i)=>{if(i.direction==="backward"){const r=e.out._zod.run(t,i);return r instanceof Promise?r.then(o=>ri(o,e.in,i)):ri(r,e.in,i)}const a=e.in._zod.run(t,i);return a instanceof Promise?a.then(r=>ri(r,e.out,i)):ri(a,e.out,i)}});function ri(n,e,t){return n.issues.length?(n.aborted=!0,n):e._zod.run({value:n.value,issues:n.issues},t)}const N0=B("$ZodReadonly",(n,e)=>{Sn.init(n,e),un(n._zod,"propValues",()=>e.innerType._zod.propValues),un(n._zod,"values",()=>e.innerType._zod.values),un(n._zod,"optin",()=>e.innerType._zod.optin),un(n._zod,"optout",()=>e.innerType._zod.optout),n._zod.parse=(t,i)=>{if(i.direction==="backward")return e.innerType._zod.run(t,i);const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(Qo):Qo(a)}});function Qo(n){return n.value=Object.freeze(n.value),n}const D0=B("$ZodLazy",(n,e)=>{Sn.init(n,e),un(n._zod,"innerType",()=>e.getter()),un(n._zod,"pattern",()=>n._zod.innerType._zod.pattern),un(n._zod,"propValues",()=>n._zod.innerType._zod.propValues),un(n._zod,"optin",()=>n._zod.innerType._zod.optin??void 0),un(n._zod,"optout",()=>n._zod.innerType._zod.optout??void 0),n._zod.parse=(t,i)=>n._zod.innerType._zod.run(t,i)}),y0=B("$ZodCustom",(n,e)=>{ie.init(n,e),Sn.init(n,e),n._zod.parse=(t,i)=>t,n._zod.check=t=>{const i=t.value,a=e.fn(i);if(a instanceof Promise)return a.then(r=>nr(r,t,i,n));nr(a,t,i,n)}});function nr(n,e,t,i){if(!n){const a={code:"custom",input:t,inst:i,path:[...i._zod.def.path??[]],continue:!i._zod.def.abort};i._zod.def.params&&(a.params=i._zod.def.params),e.issues.push(Nt(a))}}class C0{constructor(){this._map=new WeakMap,this._idmap=new Map}add(e,...t){const i=t[0];if(this._map.set(e,i),i&&typeof i=="object"&&"id"in i){if(this._idmap.has(i.id))throw new Error(`ID ${i.id} already exists in the registry`);this._idmap.set(i.id,e)}return this}clear(){return this._map=new WeakMap,this._idmap=new Map,this}remove(e){const t=this._map.get(e);return t&&typeof t=="object"&&"id"in t&&this._idmap.delete(t.id),this._map.delete(e),this}get(e){const t=e._zod.parent;if(t){const i={...this.get(t)??{}};delete i.id;const a={...i,...this._map.get(e)};return Object.keys(a).length?a:void 0}return this._map.get(e)}has(e){return this._map.has(e)}}function k0(){return new C0}const si=k0();function B0(n,e){return new n({type:"string",...j(e)})}function P0(n,e){return new n({type:"string",format:"email",check:"string_format",abort:!1,...j(e)})}function er(n,e){return new n({type:"string",format:"guid",check:"string_format",abort:!1,...j(e)})}function x0(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,...j(e)})}function F0(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,version:"v4",...j(e)})}function H0(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,version:"v6",...j(e)})}function M0(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,version:"v7",...j(e)})}function V0(n,e){return new n({type:"string",format:"url",check:"string_format",abort:!1,...j(e)})}function W0(n,e){return new n({type:"string",format:"emoji",check:"string_format",abort:!1,...j(e)})}function $0(n,e){return new n({type:"string",format:"nanoid",check:"string_format",abort:!1,...j(e)})}function U0(n,e){return new n({type:"string",format:"cuid",check:"string_format",abort:!1,...j(e)})}function G0(n,e){return new n({type:"string",format:"cuid2",check:"string_format",abort:!1,...j(e)})}function z0(n,e){return new n({type:"string",format:"ulid",check:"string_format",abort:!1,...j(e)})}function Y0(n,e){return new n({type:"string",format:"xid",check:"string_format",abort:!1,...j(e)})}function K0(n,e){return new n({type:"string",format:"ksuid",check:"string_format",abort:!1,...j(e)})}function j0(n,e){return new n({type:"string",format:"ipv4",check:"string_format",abort:!1,...j(e)})}function q0(n,e){return new n({type:"string",format:"ipv6",check:"string_format",abort:!1,...j(e)})}function Z0(n,e){return new n({type:"string",format:"cidrv4",check:"string_format",abort:!1,...j(e)})}function X0(n,e){return new n({type:"string",format:"cidrv6",check:"string_format",abort:!1,...j(e)})}function J0(n,e){return new n({type:"string",format:"base64",check:"string_format",abort:!1,...j(e)})}function Q0(n,e){return new n({type:"string",format:"base64url",check:"string_format",abort:!1,...j(e)})}function nu(n,e){return new n({type:"string",format:"e164",check:"string_format",abort:!1,...j(e)})}function eu(n,e){return new n({type:"string",format:"jwt",check:"string_format",abort:!1,...j(e)})}function tu(n,e){return new n({type:"string",format:"datetime",check:"string_format",offset:!1,local:!1,precision:null,...j(e)})}function iu(n,e){return new n({type:"string",format:"date",check:"string_format",...j(e)})}function au(n,e){return new n({type:"string",format:"time",check:"string_format",precision:null,...j(e)})}function ou(n,e){return new n({type:"string",format:"duration",check:"string_format",...j(e)})}function ru(n,e){return new n({type:"number",checks:[],...j(e)})}function su(n,e){return new n({type:"number",check:"number_format",abort:!1,format:"safeint",...j(e)})}function cu(n,e){return new n({type:"boolean",...j(e)})}function lu(n,e){return new n({type:"null",...j(e)})}function du(n){return new n({type:"unknown"})}function uu(n,e){return new n({type:"never",...j(e)})}function tr(n,e){return new Vo({check:"less_than",...j(e),value:n,inclusive:!1})}function ta(n,e){return new Vo({check:"less_than",...j(e),value:n,inclusive:!0})}function ir(n,e){return new Wo({check:"greater_than",...j(e),value:n,inclusive:!1})}function ia(n,e){return new Wo({check:"greater_than",...j(e),value:n,inclusive:!0})}function ar(n,e){return new bd({check:"multiple_of",...j(e),value:n})}function or(n,e){return new Rd({check:"max_length",...j(e),maximum:n})}function ci(n,e){return new Ad({check:"min_length",...j(e),minimum:n})}function rr(n,e){return new Ld({check:"length_equals",...j(e),length:n})}function mu(n,e){return new Od({check:"string_format",format:"regex",...j(e),pattern:n})}function gu(n){return new wd({check:"string_format",format:"lowercase",...j(n)})}function pu(n){return new Nd({check:"string_format",format:"uppercase",...j(n)})}function Iu(n,e){return new Dd({check:"string_format",format:"includes",...j(e),includes:n})}function hu(n,e){return new yd({check:"string_format",format:"starts_with",...j(e),prefix:n})}function fu(n,e){return new Cd({check:"string_format",format:"ends_with",...j(e),suffix:n})}function Dt(n){return new kd({check:"overwrite",tx:n})}function Eu(n){return Dt(e=>e.normalize(n))}function Su(){return Dt(n=>n.trim())}function _u(){return Dt(n=>n.toLowerCase())}function Tu(){return Dt(n=>n.toUpperCase())}function bu(n,e,t){return new n({type:"array",element:e,...j(t)})}function vu(n,e,t){return new n({type:"custom",check:"custom",fn:e,...j(t)})}function Ru(n){const e=Au(t=>(t.addIssue=i=>{if(typeof i=="string")t.issues.push(Nt(i,t.value,e._zod.def));else{const a=i;a.fatal&&(a.continue=!1),a.code??(a.code="custom"),a.input??(a.input=t.value),a.inst??(a.inst=e),a.continue??(a.continue=!e._zod.def.abort),t.issues.push(Nt(a))}},n(t.value,t)));return e}function Au(n,e){const t=new ie({check:"custom",...j(e)});return t._zod.check=n,t}const Lu=B("ZodISODateTime",(n,e)=>{Kd.init(n,e),Nn.init(n,e)});function De(n){return tu(Lu,n)}const Ou=B("ZodISODate",(n,e)=>{jd.init(n,e),Nn.init(n,e)});function tn(n){return iu(Ou,n)}const wu=B("ZodISOTime",(n,e)=>{qd.init(n,e),Nn.init(n,e)});function Nu(n){return au(wu,n)}const Du=B("ZodISODuration",(n,e)=>{Zd.init(n,e),Nn.init(n,e)});function yu(n){return ou(Du,n)}const me=B("ZodError",(n,e)=>{ko.init(n,e),n.name="ZodError",Object.defineProperties(n,{format:{value:t=>Fl(n,t)},flatten:{value:t=>xl(n,t)},addIssue:{value:t=>{n.issues.push(t),n.message=JSON.stringify(n.issues,ji,2)}},addIssues:{value:t=>{n.issues.push(...t),n.message=JSON.stringify(n.issues,ji,2)}},isEmpty:{get(){return n.issues.length===0}}})},{Parent:Error}),Cu=Ji(me),ku=Qi(me),Bu=ei(me),Pu=ti(me),xu=Vl(me),Fu=Wl(me),Hu=$l(me),Mu=Ul(me),Vu=Gl(me),Wu=zl(me),$u=Yl(me),Uu=Kl(me),bn=B("ZodType",(n,e)=>(Sn.init(n,e),n.def=e,n.type=e.type,Object.defineProperty(n,"_def",{value:e}),n.check=(...t)=>n.clone(et(e,{checks:[...e.checks??[],...t.map(i=>typeof i=="function"?{_zod:{check:i,def:{check:"custom"},onattach:[]}}:i)]})),n.clone=(t,i)=>He(n,t,i),n.brand=()=>n,n.register=((t,i)=>(t.add(n,i),n)),n.parse=(t,i)=>Cu(n,t,i,{callee:n.parse}),n.safeParse=(t,i)=>Bu(n,t,i),n.parseAsync=async(t,i)=>ku(n,t,i,{callee:n.parseAsync}),n.safeParseAsync=async(t,i)=>Pu(n,t,i),n.spa=n.safeParseAsync,n.encode=(t,i)=>xu(n,t,i),n.decode=(t,i)=>Fu(n,t,i),n.encodeAsync=async(t,i)=>Hu(n,t,i),n.decodeAsync=async(t,i)=>Mu(n,t,i),n.safeEncode=(t,i)=>Vu(n,t,i),n.safeDecode=(t,i)=>Wu(n,t,i),n.safeEncodeAsync=async(t,i)=>$u(n,t,i),n.safeDecodeAsync=async(t,i)=>Uu(n,t,i),n.refine=(t,i)=>n.check(xm(t,i)),n.superRefine=t=>n.check(Fm(t)),n.overwrite=t=>n.check(Dt(t)),n.optional=()=>Ir(n),n.nullable=()=>hr(n),n.nullish=()=>Ir(hr(n)),n.nonoptional=t=>wm(n,t),n.array=()=>_(n),n.or=t=>Zn([n,t]),n.and=t=>fm(n,t),n.transform=t=>Er(n,bm(t)),n.default=t=>Am(n,t),n.prefault=t=>Om(n,t),n.catch=t=>Dm(n,t),n.pipe=t=>Er(n,t),n.readonly=()=>km(n),n.describe=t=>{const i=n.clone();return si.add(i,{description:t}),i},Object.defineProperty(n,"description",{get(){return si.get(n)?.description},configurable:!0}),n.meta=(...t)=>{if(t.length===0)return si.get(n);const i=n.clone();return si.add(i,t[0]),i},n.isOptional=()=>n.safeParse(void 0).success,n.isNullable=()=>n.safeParse(null).success,n)),sr=B("_ZodString",(n,e)=>{na.init(n,e),bn.init(n,e);const t=n._zod.bag;n.format=t.format??null,n.minLength=t.minimum??null,n.maxLength=t.maximum??null,n.regex=(...i)=>n.check(mu(...i)),n.includes=(...i)=>n.check(Iu(...i)),n.startsWith=(...i)=>n.check(hu(...i)),n.endsWith=(...i)=>n.check(fu(...i)),n.min=(...i)=>n.check(ci(...i)),n.max=(...i)=>n.check(or(...i)),n.length=(...i)=>n.check(rr(...i)),n.nonempty=(...i)=>n.check(ci(1,...i)),n.lowercase=i=>n.check(gu(i)),n.uppercase=i=>n.check(pu(i)),n.trim=()=>n.check(Su()),n.normalize=(...i)=>n.check(Eu(...i)),n.toLowerCase=()=>n.check(_u()),n.toUpperCase=()=>n.check(Tu())}),Gu=B("ZodString",(n,e)=>{na.init(n,e),sr.init(n,e),n.email=t=>n.check(P0(zu,t)),n.url=t=>n.check(V0(Yu,t)),n.jwt=t=>n.check(eu(sm,t)),n.emoji=t=>n.check(W0(Ku,t)),n.guid=t=>n.check(er(cr,t)),n.uuid=t=>n.check(x0(li,t)),n.uuidv4=t=>n.check(F0(li,t)),n.uuidv6=t=>n.check(H0(li,t)),n.uuidv7=t=>n.check(M0(li,t)),n.nanoid=t=>n.check($0(ju,t)),n.guid=t=>n.check(er(cr,t)),n.cuid=t=>n.check(U0(qu,t)),n.cuid2=t=>n.check(G0(Zu,t)),n.ulid=t=>n.check(z0(Xu,t)),n.base64=t=>n.check(J0(am,t)),n.base64url=t=>n.check(Q0(om,t)),n.xid=t=>n.check(Y0(Ju,t)),n.ksuid=t=>n.check(K0(Qu,t)),n.ipv4=t=>n.check(j0(nm,t)),n.ipv6=t=>n.check(q0(em,t)),n.cidrv4=t=>n.check(Z0(tm,t)),n.cidrv6=t=>n.check(X0(im,t)),n.e164=t=>n.check(nu(rm,t)),n.datetime=t=>n.check(De(t)),n.date=t=>n.check(tn(t)),n.time=t=>n.check(Nu(t)),n.duration=t=>n.check(yu(t))});function O(n){return B0(Gu,n)}const Nn=B("ZodStringFormat",(n,e)=>{vn.init(n,e),sr.init(n,e)}),zu=B("ZodEmail",(n,e)=>{Hd.init(n,e),Nn.init(n,e)}),cr=B("ZodGUID",(n,e)=>{xd.init(n,e),Nn.init(n,e)}),li=B("ZodUUID",(n,e)=>{Fd.init(n,e),Nn.init(n,e)}),Yu=B("ZodURL",(n,e)=>{Md.init(n,e),Nn.init(n,e)}),Ku=B("ZodEmoji",(n,e)=>{Vd.init(n,e),Nn.init(n,e)}),ju=B("ZodNanoID",(n,e)=>{Wd.init(n,e),Nn.init(n,e)}),qu=B("ZodCUID",(n,e)=>{$d.init(n,e),Nn.init(n,e)}),Zu=B("ZodCUID2",(n,e)=>{Ud.init(n,e),Nn.init(n,e)}),Xu=B("ZodULID",(n,e)=>{Gd.init(n,e),Nn.init(n,e)}),Ju=B("ZodXID",(n,e)=>{zd.init(n,e),Nn.init(n,e)}),Qu=B("ZodKSUID",(n,e)=>{Yd.init(n,e),Nn.init(n,e)}),nm=B("ZodIPv4",(n,e)=>{Xd.init(n,e),Nn.init(n,e)}),em=B("ZodIPv6",(n,e)=>{Jd.init(n,e),Nn.init(n,e)}),tm=B("ZodCIDRv4",(n,e)=>{Qd.init(n,e),Nn.init(n,e)}),im=B("ZodCIDRv6",(n,e)=>{n0.init(n,e),Nn.init(n,e)}),am=B("ZodBase64",(n,e)=>{e0.init(n,e),Nn.init(n,e)}),om=B("ZodBase64URL",(n,e)=>{i0.init(n,e),Nn.init(n,e)}),rm=B("ZodE164",(n,e)=>{a0.init(n,e),Nn.init(n,e)}),sm=B("ZodJWT",(n,e)=>{r0.init(n,e),Nn.init(n,e)}),lr=B("ZodNumber",(n,e)=>{Uo.init(n,e),bn.init(n,e),n.gt=(i,a)=>n.check(ir(i,a)),n.gte=(i,a)=>n.check(ia(i,a)),n.min=(i,a)=>n.check(ia(i,a)),n.lt=(i,a)=>n.check(tr(i,a)),n.lte=(i,a)=>n.check(ta(i,a)),n.max=(i,a)=>n.check(ta(i,a)),n.int=i=>n.check(dr(i)),n.safe=i=>n.check(dr(i)),n.positive=i=>n.check(ir(0,i)),n.nonnegative=i=>n.check(ia(0,i)),n.negative=i=>n.check(tr(0,i)),n.nonpositive=i=>n.check(ta(0,i)),n.multipleOf=(i,a)=>n.check(ar(i,a)),n.step=(i,a)=>n.check(ar(i,a)),n.finite=()=>n;const t=n._zod.bag;n.minValue=Math.max(t.minimum??Number.NEGATIVE_INFINITY,t.exclusiveMinimum??Number.NEGATIVE_INFINITY)??null,n.maxValue=Math.min(t.maximum??Number.POSITIVE_INFINITY,t.exclusiveMaximum??Number.POSITIVE_INFINITY)??null,n.isInt=(t.format??"").includes("int")||Number.isSafeInteger(t.multipleOf??.5),n.isFinite=!0,n.format=t.format??null});function k(n){return ru(lr,n)}const cm=B("ZodNumberFormat",(n,e)=>{s0.init(n,e),lr.init(n,e)});function dr(n){return su(cm,n)}const lm=B("ZodBoolean",(n,e)=>{c0.init(n,e),bn.init(n,e)});function W(n){return cu(lm,n)}const dm=B("ZodNull",(n,e)=>{l0.init(n,e),bn.init(n,e)});function Ve(n){return lu(dm,n)}const um=B("ZodUnknown",(n,e)=>{d0.init(n,e),bn.init(n,e)});function ur(){return du(um)}const mm=B("ZodNever",(n,e)=>{u0.init(n,e),bn.init(n,e)});function mr(n){return uu(mm,n)}const gm=B("ZodArray",(n,e)=>{m0.init(n,e),bn.init(n,e),n.element=e.element,n.min=(t,i)=>n.check(ci(t,i)),n.nonempty=t=>n.check(ci(1,t)),n.max=(t,i)=>n.check(or(t,i)),n.length=(t,i)=>n.check(rr(t,i)),n.unwrap=()=>n.element});function _(n,e){return bu(gm,n,e)}const pm=B("ZodObject",(n,e)=>{p0.init(n,e),bn.init(n,e),un(n,"shape",()=>e.shape),n.keyof=()=>L(Object.keys(n._zod.def.shape)),n.catchall=t=>n.clone({...n._zod.def,catchall:t}),n.passthrough=()=>n.clone({...n._zod.def,catchall:ur()}),n.loose=()=>n.clone({...n._zod.def,catchall:ur()}),n.strict=()=>n.clone({...n._zod.def,catchall:mr()}),n.strip=()=>n.clone({...n._zod.def,catchall:void 0}),n.extend=t=>yl(n,t),n.safeExtend=t=>Cl(n,t),n.merge=t=>kl(n,t),n.pick=t=>Nl(n,t),n.omit=t=>Dl(n,t),n.partial=(...t)=>Bl(pr,n,t[0]),n.required=(...t)=>Pl(fr,n,t[0])});function u(n,e){return new pm({type:"object",shape:n,catchall:mr(),...j(e)})}const gr=B("ZodUnion",(n,e)=>{jo.init(n,e),bn.init(n,e),n.options=e.options});function Zn(n,e){return new gr({type:"union",options:n,...j(e)})}const Im=B("ZodDiscriminatedUnion",(n,e)=>{gr.init(n,e),I0.init(n,e)});function Dn(n,e,t){return new Im({type:"union",options:e,discriminator:n,...j(t)})}const hm=B("ZodIntersection",(n,e)=>{h0.init(n,e),bn.init(n,e)});function fm(n,e){return new hm({type:"intersection",left:n,right:e})}const Em=B("ZodTuple",(n,e)=>{f0.init(n,e),bn.init(n,e),n.rest=t=>n.clone({...n._zod.def,rest:t})});function Cn(n,e,t){const i=e instanceof Sn,a=i?t:e,r=i?e:null;return new Em({type:"tuple",items:n,rest:r,...j(a)})}const Sm=B("ZodRecord",(n,e)=>{E0.init(n,e),bn.init(n,e),n.keyType=e.keyType,n.valueType=e.valueType});function mn(n,e,t){return new Sm({type:"record",keyType:n,valueType:e,...j(t)})}const aa=B("ZodEnum",(n,e)=>{S0.init(n,e),bn.init(n,e),n.enum=e.entries,n.options=Object.values(e.entries);const t=new Set(Object.keys(e.entries));n.extract=(i,a)=>{const r={};for(const o of i)if(t.has(o))r[o]=e.entries[o];else throw new Error(`Key ${o} not found in enum`);return new aa({...e,checks:[],...j(a),entries:r})},n.exclude=(i,a)=>{const r={...e.entries};for(const o of i)if(t.has(o))delete r[o];else throw new Error(`Key ${o} not found in enum`);return new aa({...e,checks:[],...j(a),entries:r})}});function L(n,e){const t=Array.isArray(n)?Object.fromEntries(n.map(i=>[i,i])):n;return new aa({type:"enum",entries:t,...j(e)})}const _m=B("ZodLiteral",(n,e)=>{_0.init(n,e),bn.init(n,e),n.values=new Set(e.values),Object.defineProperty(n,"value",{get(){if(e.values.length>1)throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");return e.values[0]}})});function m(n,e){return new _m({type:"literal",values:Array.isArray(n)?n:[n],...j(e)})}const Tm=B("ZodTransform",(n,e)=>{T0.init(n,e),bn.init(n,e),n._zod.parse=(t,i)=>{if(i.direction==="backward")throw new Oo(n.constructor.name);t.addIssue=r=>{if(typeof r=="string")t.issues.push(Nt(r,t.value,e));else{const o=r;o.fatal&&(o.continue=!1),o.code??(o.code="custom"),o.input??(o.input=t.value),o.inst??(o.inst=n),t.issues.push(Nt(o))}};const a=e.transform(t.value,t);return a instanceof Promise?a.then(r=>(t.value=r,t)):(t.value=a,t)}});function bm(n){return new Tm({type:"transform",transform:n})}const pr=B("ZodOptional",(n,e)=>{b0.init(n,e),bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function Ir(n){return new pr({type:"optional",innerType:n})}const vm=B("ZodNullable",(n,e)=>{v0.init(n,e),bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function hr(n){return new vm({type:"nullable",innerType:n})}const Rm=B("ZodDefault",(n,e)=>{R0.init(n,e),bn.init(n,e),n.unwrap=()=>n._zod.def.innerType,n.removeDefault=n.unwrap});function Am(n,e){return new Rm({type:"default",innerType:n,get defaultValue(){return typeof e=="function"?e():yo(e)}})}const Lm=B("ZodPrefault",(n,e)=>{A0.init(n,e),bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function Om(n,e){return new Lm({type:"prefault",innerType:n,get defaultValue(){return typeof e=="function"?e():yo(e)}})}const fr=B("ZodNonOptional",(n,e)=>{L0.init(n,e),bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function wm(n,e){return new fr({type:"nonoptional",innerType:n,...j(e)})}const Nm=B("ZodCatch",(n,e)=>{O0.init(n,e),bn.init(n,e),n.unwrap=()=>n._zod.def.innerType,n.removeCatch=n.unwrap});function Dm(n,e){return new Nm({type:"catch",innerType:n,catchValue:typeof e=="function"?e:()=>e})}const ym=B("ZodPipe",(n,e)=>{w0.init(n,e),bn.init(n,e),n.in=e.in,n.out=e.out});function Er(n,e){return new ym({type:"pipe",in:n,out:e})}const Cm=B("ZodReadonly",(n,e)=>{N0.init(n,e),bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function km(n){return new Cm({type:"readonly",innerType:n})}const Bm=B("ZodLazy",(n,e)=>{D0.init(n,e),bn.init(n,e),n.unwrap=()=>n._zod.def.getter()});function Pm(n){return new Bm({type:"lazy",getter:n})}const Sr=B("ZodCustom",(n,e)=>{y0.init(n,e),bn.init(n,e)});function xm(n,e={}){return vu(Sr,n,e)}function Fm(n){return Ru(n)}function Hm(n,e={error:`Input not instance of ${n.name}`}){const t=new Sr({type:"custom",check:"custom",fn:i=>i instanceof n,abort:!0,...j(e)});return t._zod.bag.Class=n,t}function ut(n){const e=Pm(()=>Zn([O(n),k(),W(),Ve(),_(e),mn(O(),e)]));return e}const Mm=typeof globalThis<"u"&&"document"in globalThis,Vm=typeof globalThis<"u"&&"importScripts"in globalThis;(Mm||Vm)&&Ne({jitless:!0});const l=k().int().min(0).max(Number.MAX_SAFE_INTEGER),M=l.min(1),c=O().min(1).max(128).regex(/^(?!(?:constructor|prototype)$)[A-Za-z0-9][A-Za-z0-9_.:-]*$/),T=O().regex(/^[a-f0-9]{64}$/),_r=O().min(1).max(128),Xn=L(["T20","ODI","RED_BALL"]),_n=l.max(100),Vn=l.max(1e4),mt=L(["R","L"]),di=L(["FAST","MEDIUM","OFF_SPIN","LEG_SPIN","SLOW_LEFT_ARM","LEFT_ARM_WRIST"]),Wn=O().regex(/^[\s\S]{1,80}$/u),Wm=u({kind:L(["FICTIONAL","LICENSED","USER_SUPPLIED"]),sourceId:c,sourceHash:T,confidenceBp:Vn}),gt=u({defence:_n,timing:_n,power:_n,rotation:_n,vsPace:_n,vsSpin:_n,control:_n,movement:_n,variation:_n,stamina:_n,catching:_n,groundFielding:_n,throwing:_n,keeping:_n}),We=u({playerId:c,name:Wn,birthDate:tn(),batHand:mt,bowlHand:mt,bowlingStyle:di.nullable(),role:L(["BATTER","BOWLER","ALLROUNDER","KEEPER"]),skills:mn(Xn,gt),variations:_(c),shotSectorWeights:_(l).length(8),exposureBalls:mn(Xn,l),provenance:Wm}),Tr=u({schema:m("1.0.0"),engine:_r,random:_r,rules:c,rulesHash:T,model:c,modelHash:T,worldHash:T}),yt=u({playerId:c,aggression:l.max(4),intent:L(["NORMAL","ROTATE","PROTECT"])}),Ct=u({bowlerId:c,line:L(["OFF","STUMPS","LEG"]),length:L(["YORKER","FULL","GOOD","SHORT"]),variationId:c,effort:L(["CONSERVE","NORMAL","MAXIMUM"])}),oa=u({slotId:c,playerId:c}),br=u({battingOrder:W(),bowlerSelection:W(),battingTactics:W(),bowlingTactics:W(),declarations:W(),followOn:W()}),vr=u({battingPlans:mn(c,yt),bowlingPlan:Ct,fieldSlots:_(oa).length(9),nextBatterId:c.nullable(),delegation:br}),Rr=u({seamBp:Vn,turnBp:Vn,variabilityBp:Vn,moistureBp:Vn,wearPoints:l}),$m=L(["DRY","OVERCAST","RAIN","UNSAFE_LIGHT"]),Ar=u({pitch:Rr,weather:$m,outfieldSpeedBp:Vn,ballId:c,ballAgeLegalBalls:l,weatherScheduleId:c}),ra=u({wides:l,noBalls:l,byes:l,legByes:l,penalties:l}),pt=L(["NORTH","SOUTH"]),Lr=u({kind:L(["BOWLED","LBW","CAUGHT","RUN_OUT","STUMPED","HIT_WICKET"]),playerId:c,creditedBowlerId:c.nullable(),fielderId:c.nullable(),wicketEnd:pt}),ui=u({type:m("DELIVERY_RECORDED"),inningsIndex:l,deliveryIndex:l,strikerId:c,nonStrikerId:c,bowlerId:c,legality:L(["LEGAL","WIDE","NO_BALL","DEAD"]),legalBall:W(),countsAsBallFaced:W(),batRuns:l,extras:ra,completedRuns:l,boundary:L(["NONE","FOUR","SIX"]),dismissal:Lr.nullable(),endsAfter:u({north:c.nullable(),south:c.nullable()}),shotSector:l.max(7).nullable(),trajectory:L(["GROUND","AERIAL","EDGE"]).nullable(),executedLength:L(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"]).nullable(),fieldOutcome:L(["NONE","STOP","DROP","CATCH","MISS","RUN_OUT"]),elapsedSeconds:l,freeHitNext:W()}),sa=u({index:l,battingTeamId:c,bowlingTeamId:c,runs:l,wickets:l.max(10),legalBalls:l,deliveryAttempts:l,targetToWin:M.nullable(),allocatedBalls:M.nullable(),extras:ra,northBatterId:c.nullable(),southBatterId:c.nullable(),strikerEnd:pt,battingOrder:_(c),dismissed:_(c),bowlerId:c.nullable(),previousOverBowlerId:c.nullable(),bowlerLegalBalls:mn(c,l),freeHitPending:W(),ballAgeLegalBalls:l,complete:W()});L(["LUNCH","TEA","STUMPS","INNINGS"]);const It=u({day:M.max(5),localSeconds:l.max(86399),dayLegalBalls:l,finalHourActive:W(),finalHourBallsRequired:l,finalHourBallsDelivered:l,pendingInterval:L(["LUNCH","TEA","STUMPS"]).nullable()}),Um={winnerTeamId:Ve(),marginType:Ve(),marginRuns:Ve(),marginWickets:Ve(),completionReason:O().min(1).max(240)},it=Zn([u({kind:m("WIN"),winnerTeamId:c,marginType:m("RUNS"),marginRuns:M,marginWickets:Ve(),completionReason:O().min(1).max(240)}),u({kind:m("WIN"),winnerTeamId:c,marginType:m("WICKETS"),marginRuns:Ve(),marginWickets:M.max(10),completionReason:O().min(1).max(240)}),u({kind:m("WIN"),winnerTeamId:c,marginType:m("INNINGS"),marginRuns:M,marginWickets:Ve(),completionReason:O().min(1).max(240)}),u({kind:L(["TIE","DRAW","NO_RESULT"]),...Um})]),ca=L(["SETUP","TOSS","AWAITING_INNINGS","READY","AWAITING_BATTER","AWAITING_BOWLER","INTERVAL","WEATHER_DELAY","COMPLETE"]);u({matchId:c,revision:l,versions:Tr,seed:O().min(1).max(256),format:Xn,phase:ca,teamIds:Cn([c,c]),xi:mn(c,_(We).length(11)),inningsOrder:_(c).max(4),innings:_(sa).max(4),activeInningsIndex:l.max(3),clock:It,tactics:mn(c,vr),conditions:Ar,fatigueBp:mn(c,Vn),result:it.nullable()});function Or(n,e){return n<e?-1:n>e?1:0}const Gm=u({limitedOversRain:m(!1),superOver:m(!1),injuries:m(!1),prediction:W()}),la=u({schemaVersion:m("1.0.0"),gameId:c,matchId:c,format:Xn,worldPackId:c,rulesId:c,modelId:c,randomId:m("SHA256_COUNTER_V1"),seed:O().min(1).max(256),teamIds:Cn([c,c]),groundId:c,capabilities:Gm}),zm=u({teamId:c,name:Wn,squadIds:_(c).min(11).max(100),colours:Cn([O().regex(/^#[a-fA-F0-9]{6}$/),O().regex(/^#[a-fA-F0-9]{6}$/)])}),Ym=u({groundId:c,name:Wn,pitchPrior:Rr,sectorRadiiCm:_(M).length(8),outfieldSpeedBp:Vn}),Km=u({slotId:c,sector:l.max(7),angleDegrees:l.max(359),depth:L(["INNER","MIDDLE","DEEP"]),insideCircle:W(),legSide:W(),behindSquare:W()}),wr=u({registryId:c,referenceHand:m("R"),positions:_(Km).min(9)}),jm=u({fromLegalBall:l,maxOutside:l.max(9)}),qm=u({rulesId:c,schemaVersion:m("1.0.0"),format:Xn,referenceEdition:m("MCC_2017_FOURTH_EDITION_2026"),effectiveDate:m("2026-10-01"),customProfile:m(!0),ballsPerOver:m(6),playersPerXI:m(11),wicketsToAllOut:m(10),inningsPerTeam:Zn([m(1),m(2)]),allocatedBalls:M.nullable(),bowlerMaxBalls:M.nullable(),consecutiveOvers:m(!1),freeHitAfterNoBall:W(),declarations:W(),followOnLead:M.nullable(),newBallAfterLegalBalls:M.nullable(),fieldPhases:_(jm),maxLegSide:m(5),maxBehindSquareLegSide:m(2),limitedOversRain:m(!1),superOver:m(!1),supportedClauses:_(O().min(1)),localVariations:_(O().min(1)),fixtureIds:_(c),validationStatus:m("CONTRACT_ONLY")});u({modelId:c,schemaVersion:m("1.0.0"),status:L(["SYNTHETIC_ALPHA","EMPIRICALLY_VALIDATED"]),randomId:m("SHA256_COUNTER_V1"),fixedPointScale:m(1e4),expLutHash:T,featureSpecHash:T,variationIds:_(c),effects:u({overAroundWicket:m(!1),individualVariations:m(!1),moisture:m(!1),geometryEffects:m(!1),outfieldSpeed:m(!1)})});const kt=u({packId:c,schemaVersion:m("1.0.0"),players:_(We).min(1).max(1e4),teams:_(zm).min(2).max(500),grounds:_(Ym).min(1),rulesIds:_(c).min(1),provenance:O().min(1).max(2e3)}),Zm=u({path:O().min(1).max(240).regex(/^(?!\/)(?!.*(?:^|\/)\.\.(?:\/|$))(?!.*\\)[A-Za-z0-9_./-]+$/),bytes:l.max(1e8),sha256:T});u({schemaVersion:m("1.0.0"),gameId:c,versions:Tr,entries:_(Zm).min(1).max(2e3)});const Bt=u({copyVersion:m("LC_NEW_GAME_WORLD_COPY_V1"),baseWorldCanonicalSha256:T,worldCanonicalSha256:T,world:kt}),da={commandId:c,aggregateId:c,expectedRevision:l,actorId:O().regex(/^(?:(?:USER|AI):[A-Za-z0-9][A-Za-z0-9_.:-]*|SYSTEM)$/)},ae=(n,e)=>u({...da,kind:m(n),payload:u(e)}),Xm=Dn("kind",[ae("SELECT_XI",{teamId:c,playerIds:_(c).length(11),captainId:c,keeperId:c}),ae("CONFIRM_TEAMS",{}),ae("CALL_TOSS",{teamId:c,call:L(["HEADS","TAILS"])}),ae("CHOOSE_INNINGS",{teamId:c,choice:L(["BAT","BOWL"])}),ae("SET_BATTER",{teamId:c,playerId:c}),ae("SET_BOWLER",{teamId:c,bowlerId:c}),u({...da,kind:m("SET_BATTING_PLAN"),payload:yt}),u({...da,kind:m("SET_BOWLING_PLAN"),payload:Ct}),ae("SET_FIELD",{teamId:c,fieldSlots:_(oa).length(9)}),ae("SET_DELEGATION",{teamId:c,delegation:br}),ae("ADVANCE",{scope:L(["DELIVERY","OVER","NEXT_DECISION","INNINGS","MATCH"])}),ae("DECLARE",{teamId:c}),ae("CHOOSE_FOLLOW_ON",{teamId:c,enforce:W()}),ae("TAKE_NEW_BALL",{teamId:c}),ae("RESUME_AFTER_DELAY",{}),ae("FINISH_MATCH",{})]),Jn=(n,e)=>u({type:m(n),...e}),Jm=Dn("type",[Jn("TEAMS_CONFIRMED",{teams:_(u({teamId:c,players:_(We).length(11),captainId:c,keeperId:c})).length(2)}),Jn("TOSS_RESOLVED",{callingTeamId:c,call:L(["HEADS","TAILS"]),outcome:L(["HEADS","TAILS"]),winnerTeamId:c}),Jn("INNINGS_STARTED",{innings:sa}),Jn("BATTER_SELECTED",{inningsIndex:l,teamId:c,playerId:c,end:L(["NORTH","SOUTH"])}),Jn("BOWLER_SELECTED",{inningsIndex:l,teamId:c,bowlerId:c}),Jn("TACTICS_CHANGED",{teamId:c,tactics:vr}),Jn("OVER_COMPLETED",{inningsIndex:l,bowlerId:c,overIndex:l}),Jn("INNINGS_COMPLETED",{inningsIndex:l,reason:L(["ALL_OUT","ALLOCATION","TARGET","DECLARATION","TIME","ABANDONMENT"])}),Jn("INTERVAL_STARTED",{kind:L(["LUNCH","TEA","STUMPS","INNINGS"]),clock:It}),Jn("INTERVAL_ENDED",{clock:It}),Jn("WEATHER_CHANGED",{conditions:Ar,clock:It}),Jn("RULES_ADJUSTED",{calculationSequence:M,providerId:c,providerVersion:c,auditHash:T,targetToWin:M.nullable(),allocations:_(M),resultEligible:W()}),Jn("FOLLOW_ON_CHOSEN",{teamId:c,enforced:W(),inningsOrder:_(c).length(4)}),Jn("BALL_REPLACED",{inningsIndex:l,ballId:c,ballAgeLegalBalls:m(0)}),Jn("MATCH_COMPLETED",{result:it})]),Qm=Zn([ui,Jm]),ng=u({gameId:c,matchId:c,sequence:M,commandId:c,previousHash:T,stateHash:T,payload:Qm}),eg=u({commandId:c,committedRevision:l,eventRange:u({first:M,last:M}).nullable()}),tg=L(["STALE_REVISION","ILLEGAL_ACTION","INVALID_DATA","UNSUPPORTED_VERSION","PERSISTENCE_FAILED","INTERNAL_INVARIANT"]);Dn("type",[u({type:m("COMMAND"),command:Xm}),u({type:m("CANCEL_BATCH"),commandId:c})]),Dn("type",[u({type:m("ACK"),receipt:eg}),u({type:m("STATE_DELTA"),fromRevision:l,toRevision:l,events:_(ng)}),u({type:m("ERROR"),commandId:c.nullable(),code:tg,message:O().min(1).max(1e3)})]);const $n="SHA256_COUNTER_V1",mi="LC_CANONICAL_JSON_V1_SHA256",gi=u({seed:O().min(1).max(256),domain:L(["MATCH_DELIVERY","TOSS","WEATHER","AI_TIE_BREAK","CAREER_TRAINING","WORLD_GENERATION","PREDICTION"]),entityId:c,eventOrdinal:l,stageName:c,drawIndex:l}),ig=u({kind:m("RANDOM"),version:m($n),address:gi}),ag=u({kind:m("HASH_STATE"),version:m(mi),value:ut()});Dn("kind",[ig,ag]);function og(n){const e=gi.parse(n);return JSON.stringify([e.seed,e.domain,e.entityId,e.eventOrdinal,e.stageName,e.drawIndex])}function In(n){const e=new Set,t=i=>{if(i===null)return"null";if(typeof i=="string"||typeof i=="boolean")return JSON.stringify(i);if(typeof i=="number"){if(!Number.isFinite(i))throw new Error("Non-finite JSON number");return JSON.stringify(i)}if(typeof i!="object")throw new Error("Non-JSON value");if(e.has(i))throw new Error("Cyclic JSON");e.add(i);let a;if(Array.isArray(i)){if(Object.getOwnPropertyNames(i).length!==i.length+1||Object.keys(i).length!==i.length)throw new Error("Sparse or decorated array");if(Object.getOwnPropertySymbols(i).length)throw new Error("Symbol keys");const r=[];for(let o=0;o<i.length;o++){const s=Object.getOwnPropertyDescriptor(i,String(o));if(!s||!("value"in s))throw new Error("Sparse array or JSON accessor");r.push(t(s.value))}a="["+r.join(",")+"]"}else{if(Object.getPrototypeOf(i)!==Object.prototype&&Object.getPrototypeOf(i)!==null)throw new Error("Non-plain JSON object");if(Object.getOwnPropertySymbols(i).length)throw new Error("Symbol keys");if(Object.getOwnPropertyNames(i).length!==Object.keys(i).length)throw new Error("Non-enumerable JSON property");const r=i;a="{"+Object.keys(r).sort().map(o=>{const s=Object.getOwnPropertyDescriptor(r,o);if(!s||!("value"in s))throw new Error("JSON accessors forbidden");return JSON.stringify(o)+":"+t(s.value)}).join(",")+"}"}return e.delete(i),a};return t(n)}function Pt(n,e){if(!n)throw new Error(`INVALID_DATA: ${e}`)}const ht=n=>new Set(n).size===n.length;function rg(n,e){const t=We.parse(n);return Pt(t.shotSectorWeights.some(i=>i>0),"shot sector total must be positive"),Pt(ht(t.variations)&&t.variations.every(i=>e.includes(i)),"unknown or duplicate variation"),t}function ua(n,e,t){const i=kt.parse(n);Pt(ht(i.players.map(r=>r.playerId))&&ht(i.teams.map(r=>r.teamId))&&ht(i.grounds.map(r=>r.groundId)),"duplicate world IDs"),i.players.forEach(r=>rg(r,e));const a=new Set(i.players.map(r=>r.playerId));return Pt(i.teams.every(r=>ht(r.squadIds)&&r.squadIds.every(o=>a.has(o))),"invalid squad references"),Pt(ht(i.rulesIds)&&i.rulesIds.every(r=>t.includes(r)),"unknown rule references"),i}const ft=u({rulesId:L(["LC_T20_01","LC_ODI_01","LC_RED5_01"]),inningsIndex:l,deliveryIndex:l,battingTeamId:c,bowlingTeamId:c,strikerId:c,nonStrikerId:c,bowlerId:c,keeperId:c,outfieldIds:_(c).length(9),endsBefore:u({north:c,south:c}),strikerEnd:pt,runs:l,wickets:l.max(9),legalBalls:l,allocatedBalls:M.nullable(),targetToWin:M.nullable(),freeHitPending:W(),ballAgeLegalBalls:l}),pi=u({stage:L(["DELIVERY","IMMEDIATE_PENALTY"]),legality:L(["LEGAL","WIDE","NO_BALL","DEAD"]),batRuns:l,extras:ra,completedRuns:l,attemptedRuns:l,boundary:L(["NONE","FOUR","SIX"]),dismissal:u({kind:L(["BOWLED","LBW","CAUGHT","RUN_OUT","STUMPED","HIT_WICKET"]),playerId:c,fielderId:c.nullable(),wicketEnd:pt}).nullable(),endsAfter:u({north:c.nullable(),south:c.nullable()}),batContact:W(),attemptedStroke:W(),shotSector:l.max(7).nullable(),trajectory:L(["GROUND","AERIAL","EDGE"]).nullable(),executedLength:L(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"]).nullable(),fieldOutcome:L(["NONE","STOP","DROP","CATCH","MISS","RUN_OUT"]),elapsedSeconds:l}),sg=L(["INVALID_STRUCTURE","INVALID_CONTEXT","UNSUPPORTED_PENALTY","INVALID_EXTRAS","INVALID_BOUNDARY","INVALID_RUNNING","INVALID_DISMISSAL","INVALID_ENDS","INVALID_IMMEDIATE_PENALTY","UNSAFE_TOTAL"]),Nr=u({event:ui,delta:u({teamRuns:l,batterRuns:l,bowlerRuns:l,legalBalls:l.max(1),ballsFaced:l.max(1),wickets:l.max(1),bowlerWickets:l.max(1),deliveryAttempts:m(1)}),totals:u({runs:l,wickets:l.max(10),legalBalls:l,ballAgeLegalBalls:l}),strikerEndAfter:pt,nextStrikerId:c.nullable(),requiredBatterEnd:pt.nullable(),freeHitPending:W(),overCompleted:W(),inningsComplete:W(),result:it.nullable(),events:_(L(["DELIVERY_RECORDED","OVER_COMPLETED","INNINGS_COMPLETED","MATCH_COMPLETED"])).min(1),nextAction:L(["ADVANCE","SELECT_BATTER","SELECT_BOWLER","START_NEXT_INNINGS","NONE"])}),Et={id:c,source:O().min(1),description:O().min(1),reasoning:O().min(1),tags:_(c).min(1)},cg=u({...Et,context:ft,resolution:pi,expected:Nr}),lg=u({...Et,context:ut(),resolution:ut(),expectedError:sg}),dg=u({...Et,rulesId:L(["LC_T20_01","LC_ODI_01","LC_RED5_01"]),teamIds:Cn([c,c]),innings:_(u({teamId:c,runs:l,wickets:l.max(10),legalBalls:l,complete:W()})).min(1).max(4),timeExpired:W(),expected:u({result:it.nullable(),targetToWin:M.nullable(),phase:ca,nextAction:L(["ADVANCE","START_NEXT_INNINGS","NONE"])})}),ug=u({...Et,trigger:L(["WICKET","INNINGS_COMPLETED","RAIN_DELAY","NEW_BALL","TARGET_REACHED"]),before:u({clock:It,inningsLegalBalls:l,ballAgeLegalBalls:l,runs:l,targetToWin:M.nullable()}),input:u({attemptSeconds:l,wicketSeconds:l,overSeconds:l,delaySeconds:l,replacementSeconds:l,batRuns:l}),expected:u({clock:It,inningsLegalBalls:l,ballAgeLegalBalls:l,phase:ca,nextAction:L(["SELECT_BATTER","START_NEXT_INNINGS","ADVANCE","NONE"]),intervalSeconds:l,events:_(c)})}),mg=Dn("category",[u({...Et,category:m("PERSISTENCE"),before:u({durableRevision:l,lastSequence:l}),input:u({commandId:c,retryCommitted:W(),provisionalEvents:l,abortWrite:W()}),expected:u({durableRevision:l,lastSequence:l,extraCommittedEvents:l,returnOriginalReceipt:W(),resumeFromPreviousCheckpoint:W()})}),u({...Et,category:m("NRR"),input:u({runs:l,legalBalls:l,allocatedBalls:M,allOut:W(),successfulChase:W()}),expected:u({battingDenominatorBalls:M})})]);u({fixtureVersion:m("1.0.0"),authority:m("Lord_Cricket_XXVI_Technical_Design_V0_1(1).docx"),scorerImplemented:m(!1),deliveries:_(cg).min(1),invalid:_(lg).min(1),terminal:_(dg).min(1),clock:_(ug).min(1),deferred:_(mg).min(1)}),u({context:ft,resolution:pi});const $e="LC_SCORING_V1",gg=u({runs:l,ballsFaced:l,fours:l,sixes:l,dismissed:W()}),pg=u({runsConceded:l,legalBalls:l,wickets:l,maidens:l}),Ig=u({engineVersion:m($e),rulesId:L(["LC_T20_01","LC_ODI_01","LC_RED5_01"]),innings:sa,nextDeliveryIndex:l,batting:mn(c,gg),dismissals:mn(c,Lr),bowling:mn(c,pg),keeperId:c,outfieldIds:_(c).length(9),currentOverRuns:l}),zn="LC_INTEGER_PROBABILITY_V1",Se="LC_EXP_LUT_V1",ge="synthetic-alpha-01",hg=1e4,St=4294967296,fg=k().int().min(-2e4).max(2e4),ma=k().int().min(-1e5).max(1e5),Eg=k().int().min(-2e5).max(2e5),Sg=u({coefficientBp:ma,featureBp:fg}),_g=u({id:c,baseWeight:k().int().min(0).max(1e9),allowed:W(),interceptBp:Eg,terms:_(Sg).max(32)}),ga=u({probabilityVersion:m(zn),modelId:m(ge),modelHash:T,lutVersion:m(Se),lutHash:T,categories:_(_g).min(1).max(32)}),Tg=ga.extend({kind:m("NORMALISE_CATEGORIES")}),bg=ga.extend({kind:m("SAMPLE_CATEGORY"),stageName:c,randomVersion:m("SHA256_COUNTER_V1"),address:gi}),vg=Dn("kind",[Tg,bg]),Dr=u({id:c,baseWeight:k().int().min(0).max(1e4)}),Rg=u({manifest:u({modelId:m(ge),schemaVersion:m("1.0.0"),status:m("SYNTHETIC_ALPHA"),randomId:m("SHA256_COUNTER_V1"),fixedPointScale:m(hg),expLutHash:T,featureSpecHash:T,variationIds:_(c),effects:u({overAroundWicket:m(!1),individualVariations:m(!1),moisture:m(!1),geometryEffects:m(!1),outfieldSpeed:m(!1)})}),probabilityVersion:m(zn),lutVersion:m(Se),lutScale:m("1000000000000"),lutStepBp:m(100),lutMinDeltaBp:m(-16e4),lutMaxDeltaBp:m(0),logitMinBp:m(-8e4),logitMaxBp:m(8e4),coefficients:u({legality:mn(c,mn(c,ma)),contact:mn(c,mn(c,ma))}),featureSpec:u({maxTerms:m(32),fixedPointScale:m(1e4),termMultiplyRounding:m("NEAREST_TIES_AWAY_FROM_ZERO"),accumulationOrder:m("INTERCEPT_TERMS_IN_ARRAY_ORDER"),clipTiming:m("AFTER_SUM"),lutDeltaRounding:m("NEAREST_TIES_AWAY_FROM_ZERO"),categoryOrder:m("AS_SUPPLIED"),massAllocation:m("LARGEST_REMAINDER_CATEGORY_INDEX")}),expLutValues:_(k().int().min(1).max(1e12)).length(1601),baselines:u({legality:_(Dr).length(3),contact:mn(c,_(Dr).length(6))})}),Ag=u({controlRating:k().int().min(0).max(100),fatigueBp:k().int().min(0).max(1e4),line:L(["OFF","STUMPS","LEG"]),effort:L(["CONSERVE","NORMAL","MAXIMUM"])}),Lg=u({phase:L(["T20_EARLY","T20_MIDDLE","T20_LATE","ODI_EARLY","ODI_MIDDLE","ODI_LATE","RED_BALL"]),defenceRating:k().int().min(0).max(100),timingRating:k().int().min(0).max(100),powerRating:k().int().min(0).max(100),effectiveMovementBp:k().int().min(-1e4).max(1e4),aggression:k().int().min(0).max(4)}),Ii="LC_CONDITIONAL_DELIVERY_V1",yr="synthetic-alpha-01-delivery-v1",Og=L(["OFF","STUMPS","LEG"]),wg=L(["YORKER","FULL","GOOD","SHORT"]),Ng=L(["CONSERVE","NORMAL","MAXIMUM"]),Dg=L(["INNER","MIDDLE","DEEP"]),yg=u({playerId:c,sector:l.max(7),depth:Dg,role:L(["NORMAL","SLIP","GULLY"]),catchingRating:_n,throwingRating:_n}),Cg=u({kind:m("GENERATE_DELIVERY"),generatorVersion:m(Ii),stagePackId:m(yr),stagePackHash:T,randomVersion:m("SHA256_COUNTER_V1"),probabilityVersion:m(zn),modelId:m(ge),modelHash:T,lutVersion:m(Se),lutHash:T,rulesHash:T,matchId:c,seed:O().min(1).max(256),attemptOrdinal:l,format:Xn,phase:L(["T20_EARLY","T20_MIDDLE","T20_LATE","ODI_EARLY","ODI_MIDDLE","ODI_LATE","RED_BALL"]),context:ft,bowling:u({bowlingStyle:di,controlRating:_n,movementRating:_n,fatigueBp:Vn,line:Og,intendedLength:wg,effort:Ng,variationId:m("stock")}),batting:u({defenceRating:_n,timingRating:_n,powerRating:_n,rotationRating:_n,vsPaceRating:_n,vsSpinRating:_n,aggression:k().int().min(0).max(4),intent:L(["NORMAL","ROTATE","PROTECT"]),attemptedStroke:W(),shotSectorWeights:_(k().int().min(0).max(1e4)).length(8)}),conditions:u({seamBp:Vn,turnBp:Vn}),field:u({keeper:u({keepingRating:_n,catchingRating:_n,throwingRating:_n}),slots:_(yg).length(9)})}),kg=u({stageName:c,address:gi,draw:k().int().min(0).max(4294967295),selectedCategoryId:c,categories:_(u({id:c,allowed:W(),logitBp:k().int().nullable(),lutIndex:k().int().nullable(),mass:l,cumulative:l})).min(1)}),Bg=u({kind:m("GENERATED_DELIVERY"),generatorVersion:m(Ii),modelHash:T,stagePackHash:T,internalOnly:m(!0),trace:_(kg).min(2),resolution:pi}),Pg=u({worldPackId:m("fictional-eight-01"),schemaVersion:m("1.0.0"),worldGeneratorVersion:m("LC_FICTIONAL_WORLD_GENERATOR_V1"),worldSeed:O().min(1).max(256),generatorSourceSha256:T,provenanceSourceSha256:T,worldFileSha256:T,worldCanonicalSha256:T,worldByteLength:k().int().min(1).max(25e6),rulesIds:_(c).length(3),modelId:m("synthetic-alpha-01"),modelHash:T,stagePackId:m("synthetic-alpha-01-delivery-v1"),stagePackHash:T,randomId:m("SHA256_COUNTER_V1"),variationIds:_(c).min(1),provenance:m("FICTIONAL"),modelStatus:m("SYNTHETIC_ALPHA"),teamIds:_(c).length(8),groundIds:_(c).length(8),homeGroundIds:mn(c,c)}),Yn=u({teamId:c,playerIds:_(c).length(11),captainId:c,keeperId:c}),Cr=u({setup:la,worldFileSha256:T,worldCanonicalSha256:T,rulesHash:T,modelHash:T,stagePackHash:T,setupVersion:m("LC_T20_SETUP_V1"),selectedTeams:Cn([Yn,Yn])}),xg=u({setup:la,worldFileSha256:T,worldCanonicalSha256:T,rulesHash:T,modelHash:T,stagePackHash:T,setupVersion:m("LC_ODI_SETUP_V1"),selectedTeams:Cn([Yn,Yn])});u({setup:la,worldFileSha256:T,worldCanonicalSha256:T,rulesHash:T,modelHash:T,stagePackHash:T,setupVersion:m("LC_RED5_SETUP_V1"),selectedTeams:Cn([Yn,Yn])});const kr="LC_T20_MATCH_V1",pe="LC_T20_EVENT_CHAIN_V1",pa="LC_T20_CONDITIONS_V1",Br=u({engine:m(kr),eventChain:m(pe),conditionPolicy:m(pa),conditionPolicyHash:T,setupHash:T,worldHash:T,rulesHash:T,modelHash:T,stagePackHash:T,randomVersion:m("SHA256_COUNTER_V1"),scoringVersion:m("LC_SCORING_V1"),probabilityVersion:m("LC_INTEGER_PROBABILITY_V1")}),Pr=Dn("kind",[u({commandId:c,expectedRevision:l,actorId:c,kind:m("CONFIRM_TEAMS"),payload:u({})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("CALL_TOSS"),payload:u({teamId:c,call:L(["HEADS","TAILS"])})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("CHOOSE_INNINGS"),payload:u({teamId:c,choice:L(["BAT","BOWL"])})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_BATTER"),payload:u({teamId:c,playerId:c})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_BOWLER"),payload:u({teamId:c,bowlerId:c})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_FIELD"),payload:u({teamId:c,fieldSlots:_(u({slotId:c,playerId:c})).length(9)})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_BATTING_PLAN"),payload:yt}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_BOWLING_PLAN"),payload:Ct}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("ADVANCE"),payload:u({scope:L(["DELIVERY","OVER"])})})]),hi=u({version:m(pe),sequence:l.min(1),commandId:c,type:c,payload:ut(),previousHash:T,stateHash:T,eventHash:T}),Fg=u({commandId:c,committedRevision:l.min(1),fromSequence:l.min(1),toSequence:l.min(1),lastEventHash:T}),xt=u({version:m(pe),genesisHash:T,finalEventHash:T,finalStateHash:T,eventCount:l,executionManifestHash:T}),Ia=u({matchId:c,innings:_(u({battingTeamId:c,bowlingTeamId:c,runs:l,wickets:l,legalBalls:l,overs:O(),extras:u({wides:l,noBalls:l,byes:l,legByes:l,penalties:l}),batting:mn(c,u({runs:l,ballsFaced:l,fours:l,sixes:l,dismissed:W()})),bowling:mn(c,u({runsConceded:l,legalBalls:l,wickets:l,maidens:l})),fallOfWickets:_(u({playerId:c,runs:l,legalBalls:l,sequence:l})),targetToWin:l.nullable()})).length(2),result:it});u({caseId:c,seed:O().min(1).max(256),teamIds:Cn([c,c]),groundId:c,modelId:m("synthetic-alpha-01"),rulesId:m("LC_T20_01"),stagePackId:m("synthetic-alpha-01-delivery-v1"),fixtureCaptainPolicyId:m("LC_FIXTURE_CAPTAIN_V1"),expectedFinalEventHash:T.nullable(),expectedScorecardSha256:T.nullable(),oracleStatus:L(["NOT_AUTHORED_UNTIL_PASS_07B","GENERATED_FROM_PRODUCTION_NOT_INDEPENDENT"])});const xr="LC_ODI_MATCH_V1",Ie="LC_ODI_EVENT_CHAIN_V1",ha="LC_ODI_CONDITIONS_V1",Fr=u({engine:m(xr),eventChain:m(Ie),conditionPolicy:m(ha),conditionPolicyHash:T,setupHash:T,worldHash:T,rulesHash:T,modelHash:T,stagePackHash:T,randomVersion:m("SHA256_COUNTER_V1"),scoringVersion:m("LC_SCORING_V1"),probabilityVersion:m("LC_INTEGER_PROBABILITY_V1")}),Hr=Dn("kind",[u({commandId:c,expectedRevision:l,actorId:c,kind:m("CONFIRM_TEAMS"),payload:u({})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("CALL_TOSS"),payload:u({teamId:c,call:L(["HEADS","TAILS"])})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("CHOOSE_INNINGS"),payload:u({teamId:c,choice:L(["BAT","BOWL"])})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_BATTER"),payload:u({teamId:c,playerId:c})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_BOWLER"),payload:u({teamId:c,bowlerId:c})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_FIELD"),payload:u({teamId:c,fieldSlots:_(u({slotId:c,playerId:c})).length(9)})}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_BATTING_PLAN"),payload:yt}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("SET_BOWLING_PLAN"),payload:Ct}),u({commandId:c,expectedRevision:l,actorId:c,kind:m("ADVANCE"),payload:u({scope:L(["DELIVERY","OVER"])})})]),Mr=u({version:m(Ie),sequence:l.min(1),commandId:c,type:c,payload:ut(),previousHash:T,stateHash:T,eventHash:T}),Hg=u({commandId:c,committedRevision:l.min(1),fromSequence:l.min(1),toSequence:l.min(1),lastEventHash:T}),Vr=u({version:m(Ie),genesisHash:T,finalEventHash:T,finalStateHash:T,eventCount:l,executionManifestHash:T}),Mg=u({matchId:c,innings:_(u({battingTeamId:c,bowlingTeamId:c,runs:l,wickets:l,legalBalls:l,overs:O(),extras:u({wides:l,noBalls:l,byes:l,legByes:l,penalties:l}),batting:mn(c,u({runs:l,ballsFaced:l,fours:l,sixes:l,dismissed:W()})),bowling:mn(c,u({runsConceded:l,legalBalls:l,wickets:l,maidens:l})),fallOfWickets:_(u({playerId:c,runs:l,legalBalls:l,sequence:l})),targetToWin:l.nullable()})).length(2),result:it});u({caseId:c,seed:O().min(1).max(256),teamIds:Cn([c,c]),groundId:c,modelId:m("synthetic-alpha-01"),rulesId:m("LC_ODI_01"),stagePackId:m("synthetic-alpha-01-delivery-v1"),fixtureCaptainPolicyId:m("LC_FIXTURE_CAPTAIN_V1"),expectedFinalEventHash:T.nullable(),expectedScorecardSha256:T.nullable(),oracleStatus:L(["NOT_AUTHORED_UNTIL_PASS_07B","GENERATED_FROM_PRODUCTION_NOT_INDEPENDENT"])});const Vg="LC_RED5_MATCH_V1",fa="LC_RED5_EVENT_CHAIN_V1",Wg="LC_RED5_CONDITIONS_V1",$g=u({day:k().int().min(1).max(5),localSeconds:k().int().min(0).max(24*3600),phase:L(["PLAY","LUNCH","TEA","INNINGS_INTERVAL","STUMPS","RAIN","COMPLETE"]),dayLegalBalls:l,finalHourActive:W(),finalHourBallsRemaining:l,overMustFinish:W(),delaySecondsToday:l}),Ug=u({engine:m(Vg),eventChain:m(fa),conditionPolicy:m(Wg),conditionPolicyHash:T,setupHash:T,worldHash:T,rulesHash:T,modelHash:T,stagePackHash:T,randomVersion:m("SHA256_COUNTER_V1"),scoringVersion:m("LC_SCORING_V1"),probabilityVersion:m("LC_INTEGER_PROBABILITY_V1")}),ce=(n,e)=>u({commandId:c,expectedRevision:l,actorId:c,kind:m(n),payload:e}),Gg=Dn("kind",[ce("CONFIRM_TEAMS",u({})),ce("CALL_TOSS",u({teamId:c,call:L(["HEADS","TAILS"])})),ce("CHOOSE_INNINGS",u({teamId:c,choice:L(["BAT","BOWL"])})),ce("SET_BATTER",u({teamId:c,playerId:c})),ce("SET_BOWLER",u({teamId:c,bowlerId:c})),ce("SET_FIELD",u({teamId:c,fieldSlots:_(u({slotId:c,playerId:c})).length(9)})),ce("SET_BATTING_PLAN",yt),ce("SET_BOWLING_PLAN",Ct),ce("ADVANCE",u({scope:L(["DELIVERY","OVER"])})),ce("DECLARE",u({teamId:c})),ce("CHOOSE_FOLLOW_ON",u({teamId:c,enforce:W()})),ce("TAKE_NEW_BALL",u({teamId:c})),ce("ADD_RAIN_DELAY",u({seconds:k().int().min(60).max(6*3600)}))]);u({version:m(fa),sequence:l.min(1),commandId:c,type:c,payload:ut(),previousHash:T,stateHash:T,eventHash:T}),u({commandId:c,committedRevision:l.min(1),fromSequence:l.min(1),toSequence:l.min(1),lastEventHash:T}),u({version:m(fa),genesisHash:T,finalEventHash:T,finalStateHash:T,eventCount:l,executionManifestHash:T});const zg=u({battingTeamId:c,bowlingTeamId:c,runs:l,wickets:l,legalBalls:l,overs:O(),declared:W(),batting:mn(c,u({runs:l,ballsFaced:l,fours:l,sixes:l,dismissed:W()})),bowling:mn(c,u({runsConceded:l,legalBalls:l,wickets:l,maidens:l}))});u({matchId:c,innings:_(zg).max(4),result:it,clock:$g,followOnEnforced:W()});const Yg=u({competitionVersion:m("LC_T20_LEAGUE_COMPETITION_V1"),competitionId:m("LC_T20_LEAGUE_01"),format:m("T20"),worldPackId:m("fictional-eight-01"),worldCanonicalSha256:T,teamIds:_(c).length(8),groundIds:_(c).length(8),homeGroundIds:mn(c,c),teamCount:m(8),rounds:m(14),matchesPerRound:m(4),totalFixtures:m(56),roundSpacingDays:m(3),playoffs:m(!1),points:u({win:m(2),tie:m(1),noResult:m(1),loss:m(0)}),tableOrder:Cn([m("POINTS"),m("WINS"),m("NET_RUN_RATE"),m("HEAD_TO_HEAD_POINTS"),m("TEAM_ID")]),rainAdjustedNrr:m(!1),schedulerAlgorithm:m("CIRCLE_REVERSE_VENUES_V1")});u({scheduleVersion:m("LC_T20_SEASON_SCHEDULE_V1"),seasonId:c,gameId:c,competitionId:m("LC_T20_LEAGUE_01"),worldPackId:m("fictional-eight-01"),worldCanonicalSha256:T,seasonSeed:O().min(1).max(256),startDate:tn(),teamIds:_(c).length(8),groundIds:_(c).length(8),homeGroundIds:mn(c,c)});const Wr=u({fixtureId:c,matchId:c,ordinal:k().int().min(0).max(55),roundNumber:M.max(14),roundFixtureIndex:M.max(4),matchDayDate:tn(),homeTeamId:c,awayTeamId:c,groundId:c,matchSeed:T,status:m("SCHEDULED")}),$r=u({roundNumber:M.max(14),matchDayDate:tn(),fixtureIds:_(c).length(4)}),Ur={scheduleVersion:m("LC_T20_SEASON_SCHEDULE_V1"),schedulerAlgorithm:m("CIRCLE_REVERSE_VENUES_V1"),seasonId:c,gameId:c,competitionId:m("LC_T20_LEAGUE_01"),worldPackId:m("fictional-eight-01"),worldCanonicalSha256:T,seasonSeedHash:T,startDate:tn(),teamIds:_(c).length(8),groundIds:_(c).length(8),homeGroundIds:mn(c,c),rounds:_($r).length(14),fixtures:_(Wr).length(56)};u(Ur);const Kg=u({...Ur,scheduleSha256:T}),jg=u({conditionPolicyVersion:m("LC_T20_CAREER_CONDITION_V1"),maxFatigueBp:m(1e4),restRecoveryPerDayBp:m(2e3),practiceRecoveryPerDayBp:m(1400),noRandomInjuries:m(!0)}),qg=u({playerId:c,startDate:tn(),endDate:tn(),reason:O().min(1).max(240),source:m("MANUAL_FIXTURE_PACK")}),Zg=u({availabilityVersion:m("LC_T20_AVAILABILITY_PACK_V1"),packId:c,worldPackId:m("fictional-eight-01"),worldCanonicalSha256:T,entries:_(qg).max(320)}),Ea=u({playerId:c,fatigueBp:Vn,lastUpdatedDate:tn()}),Sa=u({matchCompletionKey:c,matchId:c,matchDayDate:tn(),payloadSha256:T}),_a=u({deltaVersion:m("LC_T20_MATCH_CONDITION_DELTA_V1"),matchCompletionKey:c,matchId:c,matchDayDate:tn(),playerFatigueDeltaBp:mn(c,Vn)}),Gr={careerStateVersion:m("LC_T20_CAREER_DAY_STATE_V1"),conditionPolicyVersion:m("LC_T20_CAREER_CONDITION_V1"),careerId:c,gameId:c,seasonId:c,competitionId:m("LC_T20_LEAGUE_01"),scheduleVersion:m("LC_T20_SEASON_SCHEDULE_V1"),scheduleSha256:T,worldPackId:m("fictional-eight-01"),worldCanonicalSha256:T,availabilityPackId:c,availabilityPackSha256:T,startDate:tn(),finalScheduledDate:tn(),currentDate:tn(),revision:k().int().min(0).max(Number.MAX_SAFE_INTEGER),playerConditions:_(Ea).length(160),appliedMatchConditions:_(Sa).max(56)};u(Gr),u({...Gr,stateSha256:T});const Xg=u({playerId:c,fatigueBp:Vn,availability:L(["AVAILABLE","UNAVAILABLE"]),availabilityReason:O().min(1).max(240).nullable(),unavailableThrough:tn().nullable()});u({teamId:c,date:tn(),players:_(Xg).length(20)}),u({command:m("ADVANCE_DAY"),previousDate:tn(),currentDate:tn(),recoveredPlayers:l,recoveryPerPlayerBp:m(2e3),revision:k().int().min(1).max(Number.MAX_SAFE_INTEGER),stateSha256:T});const Jg=u({trainingPolicyVersion:m("LC_T20_CAREER_TRAINING_V1"),readinessMinRatingDelta:m(-3),readinessMaxRatingDelta:m(3),readinessPracticeGainPerDay:m(1),readinessDecayPerDay:m(1),restRecoveryPerDayBp:m(2e3),practiceRecoveryPerDayBp:m(1400),noPermanentAttributeGrowth:m(!0)}),_t=L(["REST","BATTING_PRACTICE","BOWLING_PRACTICE","FIELDING_PRACTICE"]),zr=u({playerId:c,batting:k().int().min(-3).max(3),bowling:k().int().min(-3).max(3),fielding:k().int().min(-3).max(3),lastUpdatedDate:tn()}),Yr=u({playerId:c,directive:_t}),Kr={careerStateVersion:m("LC_T20_CAREER_DAY_STATE_V2"),conditionPolicyVersion:m("LC_T20_CAREER_CONDITION_V1"),trainingPolicyVersion:m("LC_T20_CAREER_TRAINING_V1"),careerId:c,gameId:c,seasonId:c,competitionId:m("LC_T20_LEAGUE_01"),scheduleVersion:m("LC_T20_SEASON_SCHEDULE_V1"),scheduleSha256:T,worldPackId:m("fictional-eight-01"),worldCanonicalSha256:T,availabilityPackId:c,availabilityPackSha256:T,startDate:tn(),finalScheduledDate:tn(),currentDate:tn(),revision:k().int().min(0).max(Number.MAX_SAFE_INTEGER),playerConditions:_(Ea).length(160),playerReadiness:_(zr).length(160),trainingAssignments:_(Yr).length(160),appliedMatchConditions:_(Sa).max(56)};u(Kr);const Qg=u({...Kr,stateSha256:T});u({command:m("SET_TRAINING_DIRECTIVE"),playerId:c,directive:_t,effectiveDate:tn(),expectedRevision:k().int().min(0).max(Number.MAX_SAFE_INTEGER)}),u({command:m("SET_TRAINING_DIRECTIVE"),playerId:c,previousDirective:_t,directive:_t,changed:W(),revision:k().int().min(0).max(Number.MAX_SAFE_INTEGER),stateSha256:T}),u({command:m("ADVANCE_DAY"),previousDate:tn(),currentDate:tn(),restPlayers:l,practicePlayers:l,recoveredPlayers:l,readinessChangedPlayers:l,restRecoveryPerPlayerBp:m(2e3),practiceRecoveryPerPlayerBp:m(1400),revision:k().int().min(1).max(Number.MAX_SAFE_INTEGER),stateSha256:T});const jr=u({playerId:c,fatigueBp:Vn,availability:L(["AVAILABLE","UNAVAILABLE"]),availabilityReason:O().min(1).max(240).nullable(),unavailableThrough:tn().nullable(),directive:_t,battingReadiness:k().int().min(-3).max(3),bowlingReadiness:k().int().min(-3).max(3),fieldingReadiness:k().int().min(-3).max(3)});u({teamId:c,date:tn(),players:_(jr).length(20)});const np=u({policyVersion:m("LC_T20_OFFSCREEN_POLICY_V1"),executionVersion:m("LC_T20_OFFSCREEN_FIXTURE_V1"),selectionPolicyId:m("LC_SEASON_XI_BASELINE_V1"),captainPolicyId:m("LC_FIXTURE_CAPTAIN_V1"),conditionDeltaPolicyId:m("LC_ENGINE_FINAL_FATIGUE_DELTA_V1"),matchEngineVersion:m("LC_T20_MATCH_V1"),selectionScorePolicy:m("SUM_SUPPORTED_T20_SKILLS_PLUS_AREA_READINESS_V1"),unavailablePlayersExcluded:m(!0),fatigueSelectionEffect:m("LOWER_FATIGUE_STABLE_TIEBREAK_ONLY"),minimumNonKeeperBowlingCapable:m(5),requiresKeeper:m(!0),noFutureRandomAccess:m(!0),noAlternateMatchSimulator:m(!0)}),qr={executionVersion:m("LC_T20_OFFSCREEN_FIXTURE_V1"),policyVersion:m("LC_T20_OFFSCREEN_POLICY_V1"),fixtureId:c,matchId:c,roundNumber:k().int().min(1).max(14),roundFixtureIndex:k().int().min(1).max(4),matchDayDate:tn(),homeTeamId:c,awayTeamId:c,groundId:c,scheduleSha256:T,matchSeedHash:T,careerRevisionBefore:l,careerRevisionAfter:l,careerStateSha256Before:T,careerStateSha256After:T,selectionPolicyId:m("LC_SEASON_XI_BASELINE_V1"),captainPolicyId:m("LC_FIXTURE_CAPTAIN_V1"),conditionDeltaPolicyId:m("LC_ENGINE_FINAL_FATIGUE_DELTA_V1"),selectedTeams:Cn([Yn,Yn]),eventChain:xt,eventLogSha256:T,commandLogSha256:T,scorecard:Ia,scorecardSha256:T,conditionDelta:_a,conditionDeltaSha256:T};u(qr);const Zr=u({...qr,outcomeSha256:T}),Xr={executionVersion:m("LC_T20_OFFSCREEN_ROUND_V1"),seasonId:c,roundNumber:k().int().min(1).max(14),matchDayDate:tn(),scheduleSha256:T,userTeamId:c.nullable(),skippedUserFixtureId:c.nullable(),executedFixtureIds:_(c).max(4),outcomes:_(Zr).max(4),careerRevisionBefore:l,careerRevisionAfter:l,careerStateSha256Before:T,careerStateSha256After:T};u(Xr),u({...Xr,executionSha256:T});const Jr=k().int().min(Number.MIN_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),fi=u({completionVersion:m("LC_T20_SEASON_MATCH_COMPLETION_V1"),seasonId:c,scheduleSha256:T,fixtureId:c,matchId:c,fixtureOrdinal:k().int().min(0).max(55),roundNumber:M.max(14),matchDayDate:tn(),homeTeamId:c,awayTeamId:c,source:L(["OFFSCREEN","USER_MATCH"]),sourceCompletionSha256:T,selectedTeams:Cn([Yn,Yn]),scorecard:Ia,scorecardSha256:T}),ep=u({fixtureId:c,matchId:c,fixtureOrdinal:k().int().min(0).max(55),roundNumber:M.max(14),homeTeamId:c,awayTeamId:c,sourceCompletionSha256:T,resultKind:L(["WIN","TIE","NO_RESULT"]),winnerTeamId:c.nullable(),homePoints:l.max(2),awayPoints:l.max(2),nrrEligible:W(),homeRuns:l,homeBalls:l,awayRuns:l,awayBalls:l}),Ta=u({rank:M.max(8),teamId:c,played:l.max(14),wins:l.max(14),losses:l.max(14),ties:l.max(14),noResults:l.max(14),points:l.max(28),runsFor:l,ballsFor:l,runsAgainst:l,ballsAgainst:l,nrrNumerator:Jr,nrrDenominator:M.nullable(),nrrX1000:Jr.nullable(),headToHeadPoints:l.max(28)}),ba=u({playerId:c,teamId:c,matches:l.max(14),runs:l,dismissals:l.max(14),ballsFaced:l,fours:l,sixes:l,battingAverageX100:l.nullable(),strikeRateX100:l.nullable(),bowlingRunsConceded:l,bowlingLegalBalls:l,bowlingWickets:l,maidens:l,bowlingAverageX100:l.nullable(),economyX100:l.nullable(),bowlingStrikeRateX100:l.nullable()}),Ei=u({playerId:c,teamId:c,value:l}),Si=u({runs:_(Ei).max(10),wickets:_(Ei).max(10)}),tp=u({appliedCount:l.max(56),highestAppliedFixtureOrdinal:k().int().min(0).max(55).nullable(),missingFixtureOrdinals:_(k().int().min(0).max(55)).max(56)}),Qr=u({projectionVersion:m("LC_T20_SEASON_PROJECTION_V1"),seasonId:c,scheduleSha256:T,competitionId:m("LC_T20_LEAGUE_01"),revision:l.max(56),cursor:tp,appliedMatches:_(ep).max(56),table:_(Ta).length(8),players:_(ba).max(160),leaders:Si}),ip=1e6,ap="LC_COMPLETED_CAREER_MATCH_EVENT_ARCHIVE_V1",ns={seasonStateVersion:m("LC_T20_SEASON_STATE_V1"),seasonId:c,gameId:c,careerId:c,controlledTeamId:c.nullable(),schedule:Kg,careerState:Qg,projection:Qr,completedMatches:_(fi).max(56),revision:l,phase:L(["ACTIVE","COMPLETE"])};u(ns);const es=u({...ns,stateSha256:T}),op=u({saveId:c,kind:L(["AUTO","MANUAL","IMPORTED"]),title:O().min(1).max(240),seasonId:c,careerId:c,controlledTeamId:c.nullable(),currentDate:tn(),revision:l,completedFixtures:l.max(56),phase:L(["ACTIVE","COMPLETE"]),stateSha256:T,updatedAt:De()});u({commandId:c,requestCanonical:O(),responseJson:O(),committedRevision:l});const rp=u({archiveVersion:m("LC_T20_SEASON_ARCHIVE_V1"),seasonId:c,careerId:c,scheduleSha256:T,stateSha256:T,projectionRevision:m(56),fixtureCount:m(56),completedAt:De(),championTeamId:c,finalTable:_(Ta).length(8),leaders:Si,completionKeys:_(c).length(56)}),sp=u({...rp.shape,archiveSha256:T});u({saveId:c,requestedGeneration:k().int().min(0).max(2).nullable(),recoveredGeneration:k().int().min(0).max(2).nullable(),recoveredCheckpointSerial:l.nullable(),recoveredRevision:l.nullable(),corruptedGenerations:_(k().int().min(0).max(2)).max(3)});const va=u({archiveVersion:m("LC_T20_SEASON_PORTABLE_V1"),saveSchema:m("LC_SEASON_SAVE_V1"),exportedAt:De(),summary:op,files:mn(O().min(1),u({bytes:l,sha256:T}))});va.extend({archiveVersion:m("LC_T20_SEASON_PORTABLE_V2"),saveSchema:m("LC_SEASON_SAVE_V2_PRESENTATION"),worldCopySha256:T});const cp=u({archiveVersion:m(ap),seasonId:c,scheduleSha256:T,fixtureId:c,matchId:c,fixtureOrdinal:l.max(55),roundNumber:k().int().min(1).max(14),matchDayDate:tn(),source:L(["OFFSCREEN","USER_MATCH"]),sourceCompletionSha256:T,scorecardSha256:T,setupRequest:Cr,eventChain:xt,eventCount:l.min(1).max(600),finalEventHash:T,eventsSha256:T,events:_(hi).min(1).max(600),byteLength:l.min(1).max(ip)});u({...cp.shape,archiveSha256:T});const lp=u({generation:k().int().min(0).max(2),checkpointSerial:l,revision:l,completedFixtures:l.max(56),currentDate:tn(),phase:L(["ACTIVE","COMPLETE"]),stateSha256:T,createdAt:De()});u({saveId:c,title:O().min(1).max(240),currentSerial:l,currentGeneration:k().int().min(0).max(2),corruptedGenerations:_(k().int().min(0).max(2)).max(3),validGenerations:_(lp).max(3)}),va.extend({archiveVersion:m("LC_T20_SEASON_PORTABLE_V3_EVENT_ARCHIVES"),saveSchema:L(["LC_SEASON_SAVE_V1","LC_SEASON_SAVE_V2_PRESENTATION"]),worldCopySha256:T.optional(),matchEventArchiveCount:l.min(1).max(56)});const X=200,dp="LC_PERSISTENT_WORLD_IDENTITY_V1",up="LC_COMPLETED_SEASON_RECORD_V1",mp="LC_PERSISTENT_CAREER_PROJECTION_V1",gp="LC_PERSISTENT_WORLD_ROLLOVER_RECEIPT_V1",pp="LC_PERSISTENT_WORLD_STATE_V1",Ip="LC_PERSISTENT_WORLD_SAVE_V1",hp="LC_PERSISTENT_WORLD_SAVE_V1_PRESENTATION",fp="LC_PERSISTENT_WORLD_PORTABLE_V1",Ra=u({worldIdentityVersion:m(dp),worldId:c,worldPackId:c,worldCanonicalSha256:T,baseSeed:O().min(1).max(256),originKind:L(["NEW_PERSISTENT_CAREER","COPIED_FROM_SINGLE_SEASON_V1"]),sourceSingleSeasonSaveId:c.nullable(),sourceSingleSeasonFinalStateSha256:T.nullable()}),Ep=u({completedSeasonVersion:m(up),seasonNumber:M.max(X),calendarYear:k().int().min(1900).max(9999),seasonId:c,gameId:c,competitionId:m("LC_T20_LEAGUE_01"),startDate:tn(),endDate:tn(),scheduleSha256:T,finalSeasonStateSha256:T,championTeamId:c,runnerUpTeamId:c,seasonArchive:sp,table:_(Ta).length(8),players:_(ba).max(1e4),leaders:Si,completedMatches:_(fi).length(56)}),Aa=u({...Ep.shape,recordSha256:T}),Sp=u({playerId:c,teamId:c,seasonsPlayed:l.max(X),matches:l,battingInnings:l,notOuts:l,runs:l,dismissals:l,ballsFaced:l,fours:l,sixes:l,fifties:l,hundreds:l,ducks:l,highScoreRuns:l,highScoreNotOut:W(),battingAverageX100:l.nullable(),strikeRateX100:l.nullable(),bowlingInnings:l,bowlingRunsConceded:l,bowlingLegalBalls:l,bowlingWickets:l,maidens:l,bestBowlingWickets:l,bestBowlingRuns:l.nullable(),bowlingAverageX100:l.nullable(),economyX100:l.nullable(),bowlingStrikeRateX100:l.nullable()}),_p=u({teamId:c,seasonsCompleted:l.max(X),titles:l.max(X),runnerUpFinishes:l.max(X),played:l,wins:l,losses:l,ties:l,noResults:l,points:l,runsFor:l,ballsFor:l,runsAgainst:l,ballsAgainst:l}),Tp=u({seasonNumber:M.max(X),calendarYear:k().int().min(1900).max(9999),seasonId:c,championTeamId:c,runnerUpTeamId:c,leadingRunScorer:Ei.nullable(),leadingWicketTaker:Ei.nullable(),finalSeasonStateSha256:T}),bp=u({careerProjectionVersion:m(mp),worldId:c,completedSeasonCount:l.max(X),activeSeasonNumber:M.max(X),activeSeasonMatchesApplied:l.max(56),totalMatchesApplied:l,rollOfHonour:_(Tp).max(X),teamHistory:_(_p).length(8),players:_(Sp).max(1e4),leaders:Si}),La=u({...bp.shape,projectionSha256:T}),Oa=u({receiptVersion:m(gp),fromSeasonNumber:M.max(X-1),toSeasonNumber:M.max(X),closedSeasonId:c,closedSeasonStateSha256:T,closedSeasonRecordSha256:T,nextSeasonId:c,nextStartDate:tn(),nextScheduleSha256:T}),vp=u({worldStateVersion:m(pp),worldIdentity:Ra,careerId:c,controlledTeamId:c.nullable(),currentSeasonNumber:M.max(X),currentCalendarYear:k().int().min(1900).max(9999),currentSeason:es,completedSeasons:_(Aa).max(X-1),careerProjection:La,lastRolloverReceipt:Oa.nullable(),revision:l});u({...vp.shape,stateSha256:T});const wa=u({saveId:c,kind:L(["AUTO","MANUAL","IMPORTED"]),title:O().min(1).max(240),worldId:c,careerId:c,controlledTeamId:c.nullable(),currentSeasonNumber:M.max(X),currentCalendarYear:k().int().min(1900).max(9999),completedSeasonCount:l.max(X-1),seasonId:c,currentDate:tn(),revision:l,completedFixtures:l.max(56),phase:L(["ACTIVE","COMPLETE"]),stateSha256:T,updatedAt:De()});u({archiveVersion:m(fp),saveSchema:L([Ip,hp]),exportedAt:De(),summary:wa,careerProjectionSha256:T,worldCopySha256:T.optional(),matchEventArchiveCount:l.max(X*56),files:mn(O().min(1),u({bytes:l,sha256:T}))});const ts=25e6,Na=["T20","ODI","RED_BALL"],Da=gt.partial(),Rp=u({T20:Da.optional(),ODI:Da.optional(),RED_BALL:Da.optional()}),Ap=u({T20:l.optional(),ODI:l.optional(),RED_BALL:l.optional()}),Lp=We.omit({skills:!0,exposureBalls:!0,provenance:!0}).extend({skills:Rp.optional(),exposureBalls:Ap.optional()}),Op=u({version:m("LC_ROSTER_IMPORT_V1"),sourceId:c,world:kt.omit({players:!0}).extend({players:_(Lp).min(1).max(1e4)})}),ye=u({version:m("LC_STAGED_ROSTER_PACK_V1"),sourceText:O().max(ts),sourceHash:T,world:kt,priorFields:_(u({playerId:c,format:L(Na),fields:_(O()),exposureMissing:W()}))}),is=u({teamId:c,playerIds:_(c).length(11),captainId:c,keeperId:c}),as=u({groundId:c,teams:Cn([is,is])}),os=u({gameId:c,matchId:c,seed:O().min(1).max(256),format:L(Na),selection:as}),rs=Br.extend({engine:m("LC_T20_MATCH_ROSTER_V2")}),wp=Fr.extend({engine:m("LC_ODI_MATCH_ROSTER_V2")});Ug.extend({engine:m("LC_RED5_MATCH_ROSTER_V2")});const Np=u({seasonId:c,gameId:c,seasonSeed:O().min(1).max(256),startDate:tn()}),ss=u({version:m("LC_T20_ROSTER_SCHEDULE_V2"),request:Np,rosterPackHash:T,worldHash:T,teamIds:_(c).length(8),groundIds:_(c).length(8),homeGroundIds:mn(c,c),rounds:_($r).length(14),fixtures:_(Wr).length(56),scheduleSha256:T}),cs=u({version:m("LC_T20_ROSTER_CAREER_DAY_V3"),careerId:c,scheduleSha256:T,rosterPackHash:T,worldHash:T,startDate:tn(),finalScheduledDate:tn(),currentDate:tn(),revision:l,playerConditions:_(Ea).min(22).max(1e4),playerReadiness:_(zr).min(22).max(1e4),trainingAssignments:_(Yr).min(22).max(1e4),appliedMatchConditions:_(Sa).max(56),stateSha256:T}),Dp=Zr.extend({executionVersion:m("LC_T20_ROSTER_OFFSCREEN_FIXTURE_V2"),policyVersion:m("LC_T20_ROSTER_OFFSCREEN_POLICY_V2"),engineManifest:rs}),yp=fi.extend({completionVersion:m("LC_T20_ROSTER_SEASON_COMPLETION_V2")}),ls=Qr.extend({projectionVersion:m("LC_T20_ROSTER_SEASON_PROJECTION_V2"),players:_(ba).max(1e4)}),Cp=u({version:m("LC_T20_ROSTER_MANAGED_FIXTURE_V1"),completion:yp,conditionDelta:_a,outcomeSha256:T});u({version:m("LC_T20_ROSTER_SEASON_STATE_V2"),careerId:c,controlledTeamId:c,schedule:ss,careerState:cs,projection:ls,outcomes:_(Zn([Dp,Cp])).max(56),revision:l,phase:L(["ACTIVE","COMPLETE"]),stateSha256:T}),va.extend({archiveVersion:m("LC_T20_ROSTER_SEASON_PORTABLE_V1"),saveSchema:m("LC_SEASON_SAVE_V3_ROSTER"),rosterPackSha256:T});const ds="LC_PLAYER_LIFECYCLE_MODEL_FICTIONAL_V1",kp="LC_PLAYER_LIFECYCLE_STATE_V1",Bp="LC_PLAYER_LIFECYCLE_STATE_V2_BOUNDED_PACKS",Pp=2,xp="LC_T20_LIFECYCLE_SEASON_STATE_V1",Fp="LC_COMPLETED_CAREER_MATCH_EVENT_ARCHIVE_V2_LIFECYCLE",Hp="LC_PERSISTENT_WORLD_STATE_V2",Mp="LC_PERSISTENT_WORLD_SAVE_V2",Vp="LC_PERSISTENT_WORLD_SAVE_V2_PRESENTATION",Wp="LC_PERSISTENT_WORLD_PORTABLE_V2_LIFECYCLE",$p=18,Up=22,Gp=3,us=u({modelVersion:m(ds),calibrationStatus:m("FICTIONAL_PLACEHOLDER"),disclaimer:O().min(1).max(400),minPermanentSkill:k().int().min(10).max(40),maxPermanentSkill:k().int().min(80).max(100),youthMinAgeYears:k().int().min(16).max(20),youthMaxAgeYears:k().int().min(17).max(22),growthWindowMaxAgeYears:k().int().min(22).max(28),primeWindowMaxAgeYears:k().int().min(27).max(33),earliestVoluntaryRetirementAgeYears:k().int().min(32).max(38),mandatoryRetirementAgeYears:k().int().min(37).max(45),minSquadKeepers:k().int().min(1).max(4),minSquadBowlingCapable:k().int().min(5).max(12)}),zp=u({playerId:c,battingPracticeDays:l.max(366),bowlingPracticeDays:l.max(366),fieldingPracticeDays:l.max(366),restDays:l.max(366)}),Ft=k().int().min(-25).max(25),ms=u({battingDelta:Ft,bowlingDelta:Ft,fieldingDelta:Ft,keepingDelta:Ft,staminaDelta:Ft}),Yp=u({playerId:c,teamId:c,ageBefore:k().int().min(15).max(60),ageAfter:k().int().min(16).max(61),matchesPlayed:l.max(56),ballsFaced:l,ballsBowled:l,battingPracticeDays:l.max(366),bowlingPracticeDays:l.max(366),fieldingPracticeDays:l.max(366),restDays:l.max(366),deltas:ms,phaseLabel:L(["YOUTH_GROWTH","EARLY_DEVELOPMENT","PRIME_MAINTENANCE","VETERAN_DECLINE"])}),Kp=u({playerId:c,player:We,debutSeasonNumber:M.max(X),retiredAfterSeasonNumber:M.max(X),retiredCalendarYear:k().int().min(1900).max(9999),ageAtRetirement:k().int().min(18).max(65),lastTeamId:c,careerTeamIds:_(c).min(1).max(8),retirementReason:L(["AGE_AND_WORKLOAD","VETERAN_TRANSITION","MANDATORY_AGE_LIMIT"])}),jp=L(["ACADEMY_GRADUATE","FIRST_TEAM_PROSPECT","HIGH_CEILING_PROSPECT"]),gs=L(["BALANCED","BATTING_PRACTICE","BOWLING_PRACTICE","FIELDING_PRACTICE"]),qp=u({prospectId:c,teamId:c,generatedInSeasonNumber:M.max(X),generatedCalendarYear:k().int().min(1900).max(9999),intakeRank:k().int().min(1).max(Gp),fictionalCeilingTier:jp,academyFocus:gs,queuedForPromotion:W(),promotedInSeasonNumber:M.max(X).nullable(),player:We}),Zp=u({fromSeasonNumber:M.max(X-1),toSeasonNumber:M.max(X),calendarYear:k().int().min(1900).max(9999),agedPlayerCount:l.max(1e4),developedPlayers:_(Yp).max(1e4),retiredPlayerIds:_(c).max(1e4),promotedYouthIds:_(c).max(1e4),generatedYouthIds:_(c).max(1e4)}),Xp=u({...Zp.shape,transitionSha256:T}),Jp=u({playerId:c,debutSeasonNumber:M.max(X),careerEntryT20Skills:gt,priorSeasonT20Skills:gt,lastSeasonDelta:ms}),ya=u({lifecycleVersion:m(kp),model:us,activeWorld:kt,activeRosterPack:ye.nullable(),historicalRosterPacks:_(ye).max(X*4),skillLedger:_(Jp).min(22).max(1e4),seasonTrainingExposure:_(zp).min(22).max(1e4),retiredPlayers:_(Kp).max(1e4),youthAcademy:_(qp).max(1e4),transitions:_(Xp).max(X),squadRegistrationRevision:l}),Ca=u({...ya.shape,lifecycleSha256:T}),ps=ya.extend({lifecycleVersion:m(Bp),historicalRosterPacks:_(ye).max(Pp)}),Is=u({...ps.shape,lifecycleSha256:T});Dn("lifecycleVersion",[ya,ps]),Dn("lifecycleVersion",[Ca,Is]);const Qp=u({seasonStateVersion:m(xp),seasonId:c,gameId:c,careerId:c,controlledTeamId:c.nullable(),rosterPackSha256:T,schedule:ss,careerState:cs,projection:ls,completedMatches:_(fi).max(56),revision:l,phase:L(["ACTIVE","COMPLETE"])}),nI=u({...Qp.shape,stateSha256:T}),hs=Dn("seasonStateVersion",[es,nI]),eI=u({archiveVersion:m(Fp),seasonId:c,scheduleSha256:T,fixtureId:c,matchId:c,fixtureOrdinal:k().int().min(0).max(55),roundNumber:M.max(14),matchDayDate:tn(),source:L(["OFFSCREEN","USER_MATCH"]),sourceCompletionSha256:T,rosterPackSha256:T,preparation:os,eventChain:xt,events:_(hi).min(1).max(2e3),scorecardSha256:T});u({...eI.shape,archiveSha256:T});const tI=u({worldStateVersion:m(Hp),worldIdentity:Ra,careerId:c,controlledTeamId:c.nullable(),currentSeasonNumber:M.max(X),currentCalendarYear:k().int().min(1900).max(9999),currentSeason:hs,completedSeasons:_(Aa).max(X-1),careerProjection:La,lifecycle:Ca,lastRolloverReceipt:Oa.nullable(),revision:l});u({...tI.shape,stateSha256:T}),u({archiveVersion:m(Wp),saveSchema:L([Mp,Vp]),exportedAt:De(),summary:wa,careerProjectionSha256:T,lifecycleSha256:T,worldCopySha256:T.optional(),rosterPackHashes:_(T).max(X),matchEventArchiveCount:l.max(X*56),files:mn(O().min(1),u({bytes:l,sha256:T}))}),u({command:m("SET_ACADEMY_PROSPECT_FOCUS"),prospectId:c,academyFocus:gs}),u({command:m("SET_ACADEMY_PROSPECT_QUEUE"),prospectId:c,queuedForPromotion:W()}),u({command:m("PROMOTE_YOUTH_PROSPECT"),prospectId:c,seasonNumber:M.max(X)});const Ht=u({min:k().int().min(0).max(100),p10:k().int().min(0).max(100),median:k().int().min(0).max(100),meanX10:k().int().min(0).max(1e3),p90:k().int().min(0).max(100),max:k().int().min(0).max(100)});u({seasonNumber:M.max(X),calendarYear:k().int().min(1900).max(9999),activePlayerCount:l,cumulativeRetiredCount:l,cumulativeYouthPromotedCount:l,minClubSquadSize:l,maxClubSquadSize:l,minClubKeepers:l,minClubBowlingCapable:l,clubsWithRoleShortage:l,meanAgeX10:l,battingAbility:Ht,bowlingAbility:Ht,fieldingAbility:Ht,keepingAbility:Ht,roleCounts:u({BATTER:l,BOWLER:l,ALLROUNDER:l,KEEPER:l}),directiveSampleCheck:_t.optional()}),u({teamId:c,date:tn(),players:_(jr).min($p).max(Up)});const fs="LC_SQUAD_ECONOMY_MODEL_FICTIONAL_V1",iI="LC_SQUAD_ECONOMY_STATE_V1",aI="LC_ECONOMY_LEDGER_ENTRY_V1",oI="LC_PERSISTENT_WORLD_STATE_V3",rI="LC_PERSISTENT_WORLD_SAVE_V3",sI="LC_PERSISTENT_WORLD_SAVE_V3_PRESENTATION",cI="LC_PERSISTENT_WORLD_PORTABLE_V3_ECONOMY",lI="LC_PERSISTENT_WORLD_STATE_V4",dI="LC_PERSISTENT_WORLD_SAVE_V4",uI="LC_PERSISTENT_WORLD_SAVE_V4_PRESENTATION",mI="LC_PERSISTENT_WORLD_STATE_V5",gI="LC_PERSISTENT_WORLD_SAVE_V5",pI="LC_PERSISTENT_WORLD_SAVE_V5_PRESENTATION",II=2500,hI=35,fI=450,EI=40,Es=1,at=3,ot=3,SI=50,_I=16,TI=40,Ss=u({modelVersion:m(fs),calibrationStatus:m("FICTIONAL_PLACEHOLDER"),disclaimer:O().min(1).max(400),annualClubWageBudgetK:k().int().min(1e3).max(1e4),minAnnualWageK:k().int().min(20).max(100),maxAnnualWageK:k().int().min(200).max(1e3),youthRookieAnnualWageK:k().int().min(25).max(100),minContractTermSeasons:m(Es),maxContractTermSeasons:m(at),maxNegotiationRounds:m(ot),releaseBuyoutPercent:k().int().min(0).max(100),minFreeAgentPoolSize:k().int().min(8).max(64),maxFreeAgentPoolSize:k().int().min(16).max(128)}),bI=L(["INITIAL_SQUAD","RENEWAL","FREE_AGENT_SIGNING","YOUTH_GRADUATE","EMERGENCY_MINIMUM"]),vI=u({contractId:c,playerId:c,teamId:c,signedSeasonNumber:M.max(X),startsSeasonNumber:M.max(X+1),expiresAfterSeasonNumber:M.max(X+5),annualWageK:k().int().min(20).max(1e3),origin:bI,careerTeamIds:_(c).min(1).max(8)}),RI=L(["UNATTACHED_POOL","CONTRACT_EXPIRED","CLUB_RELEASED"]),AI=u({playerId:c,player:We,enteredMarketSeasonNumber:M.max(X),enteredReason:RI,previousTeamId:c.nullable(),careerTeamIds:_(c).max(8),restrictedFromSigningTeamId:c.nullable(),restrictedSeasonNumber:M.max(X).nullable(),askingAnnualWageK:k().int().min(20).max(1e3),preferredTermSeasons:k().int().min(1).max(at)}),LI=u({teamId:c,seasonNumber:M.max(X),annualWageBudgetK:k().int().min(500).max(2e4),committedWagesK:l.max(2e4),deadCapWagesK:l.max(2e4),pendingOfferReservedWagesK:l.max(2e4),availableWageSpaceK:l.max(2e4)}),_s=L(["FREE_AGENT","RENEWAL"]),OI=L(["PENDING_ROUND","COUNTERED","SIGNED","REJECTED","WITHDRAWN"]),wI=L(["AWAITING_ROUND_RESOLUTION","PLAYER_ACCEPTED_BEST_OFFER","PLAYER_COUNTERED_TERMS","WAGE_BELOW_RESERVATION","SIGNED_WITH_COMPETING_CLUB","CLUB_WITHDREW_OFFER","PLAYER_NO_LONGER_ELIGIBLE","CAP_OR_ROSTER_LIMIT"]),NI=u({offerId:c,commandId:c,seasonNumber:M.max(X),roundSubmitted:k().int().min(1).max(ot),roundResolved:k().int().min(1).max(ot).nullable(),offeringTeamId:c,submittedBy:L(["HUMAN_MANAGER","AI_CLUB"]),playerId:c,offerKind:_s,annualWageK:k().int().min(20).max(1e3),termSeasons:k().int().min(1).max(at),status:OI,reason:wI,counterAnnualWageK:k().int().min(20).max(1e3).nullable(),counterTermSeasons:k().int().min(1).max(at).nullable(),rationale:O().min(1).max(280)}),DI=u({seasonNumber:M.max(X),windowPhase:L(["OPEN","CLOSED"]),currentRound:k().int().min(1).max(ot),maxRounds:m(ot),offers:_(NI).max(2e3)}),yI=L(["INITIAL_CONTRACT_REGISTERED","CONTRACT_RENEWED","FREE_AGENT_SIGNED","YOUTH_ROOKIE_CONTRACT_SIGNED","CONTRACT_EXPIRED_TO_FREE_AGENCY","CONTRACT_RELEASE_BUYOUT","CONTRACT_ENDED_ON_RETIREMENT","MINIMUM_SQUAD_TOPUP_SIGNED"]),CI=u({ledgerEntryVersion:m(aI),sequence:M,transactionId:c,seasonNumber:M.max(X),calendarYear:k().int().min(1900).max(9999),date:tn(),type:yI,teamId:c,playerId:c,contractId:c.nullable(),offerId:c.nullable(),annualWageK:l.max(2e3),deadCapDeltaK:l.max(2e3),termSeasons:l.max(at),teamCommittedWagesAfterK:l.max(2e4),teamDeadCapAfterK:l.max(2e4),teamBudgetLimitK:k().int().min(500).max(2e4),summary:O().min(1).max(320),prevEntrySha256:T.nullable()}),kI=u({...CI.shape,entrySha256:T}),BI=u({fromSeasonNumber:M.max(X-1),toSeasonNumber:M.max(X),calendarYear:k().int().min(1900).max(9999),humanRenewedCount:l.max(1e3),aiRenewedCount:l.max(1e3),expiredToFreeAgencyIds:_(c).max(1e3),retiredContractClosedIds:_(c).max(1e3),youthContractsSignedIds:_(c).max(1e3),aiOffseasonFreeAgentSigningsIds:_(c).max(1e3),minimumTopupSignedIds:_(c).max(1e3)}),PI=u({economyVersion:m(iI),model:Ss,contracts:_(vI).min(22).max(1e4),freeAgents:_(AI).max(2e3),clubBudgets:_(LI).length(8),negotiationWindow:DI,ledger:_(kI).min(1).max(5e4),appliedCommandIds:_(c).max(1e4),transitions:_(BI).max(X)}),xI=u({...PI.shape,economySha256:T}),Ts=u({worldStateVersion:m(oI),worldIdentity:Ra,careerId:c,controlledTeamId:c.nullable(),currentSeasonNumber:M.max(X),currentCalendarYear:k().int().min(1900).max(9999),currentSeason:hs,completedSeasons:_(Aa).max(X-1),careerProjection:La,lifecycle:Ca,economy:xI,lastRolloverReceipt:Oa.nullable(),revision:l});u({...Ts.shape,stateSha256:T});const bs=Ts.extend({worldStateVersion:m(lI),lifecycle:Is});u({...bs.shape,stateSha256:T});const FI=bs.extend({worldStateVersion:m(mI)}),HI=u({...FI.shape,stateSha256:T}),MI=u({seasonId:c,recordSha256:T});u({...HI.shape,completedSeasons:_(MI).max(X-1)});const VI=u({archiveVersion:m(cI),saveSchema:L([rI,sI]),exportedAt:De(),summary:wa,careerProjectionSha256:T,lifecycleSha256:T,economySha256:T,worldCopySha256:T.optional(),rosterPackHashes:_(T).max(X*4),matchEventArchiveCount:l.max(X*56),files:mn(O().min(1),u({bytes:l,sha256:T}))});u({command:m("SUBMIT_CONTRACT_OFFER"),commandId:c,offeringTeamId:c,playerId:c,offerKind:_s,annualWageK:k().int().min(20).max(1e3),termSeasons:k().int().min(1).max(at)}),u({command:m("WITHDRAW_CONTRACT_OFFER"),commandId:c,offeringTeamId:c,offerId:c}),u({command:m("ACCEPT_COUNTER_OFFER"),commandId:c,offeringTeamId:c,offerId:c}),u({command:m("RESOLVE_NEGOTIATION_ROUND"),commandId:c,seasonNumber:M.max(X),expectedRound:k().int().min(1).max(ot)}),u({command:m("RELEASE_CONTRACTED_PLAYER"),commandId:c,teamId:c,playerId:c}),u({seasonNumber:M.max(X),calendarYear:k().int().min(1900).max(9999),activeContractCount:l,freeAgentPoolCount:l,minClubPayrollUsedK:l,medianClubPayrollUsedK:l,maxClubPayrollUsedK:l,clubWageBudgetK:k().int().min(500).max(2e4),clubsOverspentCount:l,clubsWithRoleShortageCount:l,seasonFreeAgentSigningsCount:l,seasonRenewalsCount:l,seasonExpiredToFreeAgencyCount:l,seasonReleaseBuyoutsCount:l,wageDistributionK:Ht,aiHiddenFutureAbilityReads:m(0)});const vs=L(["TOSS","INNINGS","BATTER","BOWLER","BATTING_PLAN","BOWLING_PLAN","FIELD","DECLARATION","FOLLOW_ON","NEW_BALL"]),ka=L(["CONSERVATIVE","BALANCED","AGGRESSIVE"]),WI=_(vs).max(10).refine(n=>new Set(n).size===n.length).meta({uniqueItems:!0}),$I=u({commandId:O().min(1).max(128),expectedRevision:k().int().nonnegative(),matchRevision:k().int().nonnegative(),teamId:O().min(1).max(128),categories:WI,redBallProfile:ka.optional()});u({version:m("LC_DELEGATION_JOURNAL_V1"),changes:_($I)});const Ba="LC_TACTICAL_BRIEFING_V1",UI=L(["SEAM_FRIENDLY","SPIN_FRIENDLY","LIVE_BOTH","BALANCED","FLAT"]),GI=L(["FRESH","READY","WORKED","TIRED"]),zI=u({playerId:c,name:Wn,role:L(["BATTER","BOWLER","ALLROUNDER","KEEPER"]),batHand:mt,bowlingStyle:di.nullable(),canBowl:W(),selectedInXI:W(),fatigueBp:Vn,readinessDelta:k().int().min(-20).max(20),conditionBand:GI}),Rs=u({teamId:c,teamName:Wn,squadSize:M,selectedCount:l.max(11),selectedKeepers:l.max(11),selectedBowlingOptions:l.max(11),selectedPaceOptions:l.max(11),selectedSpinOptions:l.max(11),selectedLeftHandBatters:l.max(11),freshInXI:l.max(11),tiredInXI:l.max(11),balanceSummary:O().min(1).max(320),players:_(zI).min(11).max(30)}),As=u({opponentTeamId:c,opponentTeamName:Wn,poolLabel:L(["SELECTED_XI","AVAILABLE_SQUAD"]),leftHandBatters:l.max(30),rightHandBatters:l.max(30),keepers:l.max(30),paceOptions:l.max(30),spinOptions:l.max(30),bowlingStyles:_(di).max(6),observations:_(O().min(1).max(280)).min(1).max(6)}),YI=u({groundId:c,groundName:Wn,seamBp:Vn,turnBp:Vn,pitchTendency:UI,pitchSummary:O().min(1).max(320),formatRulesSummary:O().min(1).max(320),modelLimitsDisclosure:O().min(1).max(320)});u({version:m(Ba),format:Xn,ground:YI,teams:Cn([Rs,Rs]),opponentObservations:Cn([As,As])});const KI=L(["BATTING_AGGRESSION","BATTING_INTENT","BOWLING_LINE","BOWLING_LENGTH","BOWLING_EFFORT","BOWLING_VARIATION","FIELD_PLACEMENT"]),jI=u({controlId:KI,side:L(["BATTING","BOWLING","FIELDING"]),label:O().min(1).max(80),currentSetting:O().min(1).max(160),upside:O().min(1).max(280),tradeOff:O().min(1).max(280)}),qI=L(["BAT_CONSOLIDATE","BAT_ROTATE_STRIKE","BAT_BALANCED_TEMPO","BAT_BOUNDARY_PUSH","BOWL_DISCIPLINED_CHANNEL","BOWL_ATTACK_STUMPS","BOWL_CONSERVE_SPELL","BOWL_YORKER_CLOSE","BOWL_SHORT_TEST","FIELD_SLIP_ATTACK","FIELD_BALANCED_RING","FIELD_BOUNDARY_PROTECT"]),ZI=u({presetId:qI,commandKind:L(["SET_BATTING_PLAN","SET_BOWLING_PLAN","SET_FIELD"]),label:O().min(1).max(80),whenToUse:O().min(1).max(240),tradeOff:O().min(1).max(240),contextualMatch:W(),contextualReason:O().max(200),activeNow:W(),battingPatch:u({aggression:l.max(4),intent:L(["NORMAL","ROTATE","PROTECT"])}).optional(),bowlingPatch:u({line:L(["OFF","STUMPS","LEG"]),length:L(["YORKER","FULL","GOOD","SHORT"]),effort:L(["CONSERVE","NORMAL","MAXIMUM"]),variationId:c}).optional(),fieldSlots:_(oa).length(9).optional()}),XI=u({primaryLine:L(["OFF","STUMPS","LEG"]),primaryLength:L(["YORKER","FULL","GOOD","SHORT"]),primaryEffort:L(["CONSERVE","NORMAL","MAXIMUM"]),primaryVariationId:c,latestRingFielders:l.max(9),latestBoundaryFielders:l.max(9),latestCloseCatchers:l.max(9),planChangesCount:l,fieldChangesCount:l}),JI=u({YORKER:l,FULL:l,GOOD:l,SHORT:l,FULL_TOSS:l}),QI=u({GROUND:l,AERIAL:l,EDGE:l,NO_CONTACT:l}),nh=u({STOP:l,CATCH:l,DROP:l,MISS:l,RUN_OUT:l}),eh=u({legalBalls:l,oversDisplay:O().regex(/^[0-9]+\.[0-5]$/),deliveryAttempts:l,runsConceded:l,wickets:l,dots:l,singles:l,boundaries:l,fours:l,sixes:l,wides:l,noBalls:l,economyX100:l.nullable(),intendedLengthMatches:l,intendedLengthEvaluatedBalls:l,executedLengths:JI,trajectories:QI,fieldOutcomes:nh}),th=u({spellId:O().min(1).max(160),inningsIndex:l,spellNumberInInnings:M,bowlerId:c,bowlerName:Wn,status:L(["IN_PROGRESS","BETWEEN_OVERS","COMPLETED"]),startOver:l,endOver:l,acceptedPlan:XI,outcomes:eh,factualSummary:O().min(1).max(420)}),ih=u({stintId:O().min(1).max(160),inningsIndex:l,playerId:c,playerName:Wn,dismissed:W(),acceptedPlan:u({primaryAggression:l.max(4),primaryIntent:L(["NORMAL","ROTATE","PROTECT"]),planChangesCount:l}),outcomes:u({ballsFaced:l,runs:l,dots:l,singles:l,boundaries:l,strikeRateX100:l.nullable()}),factualSummary:O().min(1).max(360)}),ah=u({phaseLabel:O().min(1).max(120),fieldRestrictionLabel:O().min(1).max(160),scoreContextLabel:O().min(1).max(200),pitchSummaryLabel:O().min(1).max(200),activeBowlerWorkloadLabel:O().max(200)}),oh=u({version:m(Ba),format:Xn,situation:ah,controlGuide:_(jI).length(7),presets:_(ZI).max(16),spellReviews:_(th),battingStintReviews:_(ih)}),Ls="LC_FIELD_PRESENTATION_V1";L(["EVERY_BALL","KEY_MOMENT","FAST"]),L(["AUTO","REDUCED"]);const rh=L(["WICKET","SIX","FOUR","FREE_HIT","EXTRA","RUNS","DOT"]),sh=L(["RECORDED_SECTOR","PITCH_CHANNEL_ONLY"]),ch=L(["SLOT_COUNT","UNIQUE_PLAYERS","DUPLICATE_POSITION","UNSUPPORTED_POSITION","CIRCLE_RESTRICTION","LEG_SIDE_LIMIT","BEHIND_SQUARE_LEG_LIMIT"]),lh=u({code:ch,message:O().min(1).max(240),affectedSlotIds:_(c).max(9)}),Os=u({isLegal:W(),format:Xn,strikerHand:mt,phaseLabel:O().min(1).max(120),outsideCircleCount:l.max(9),maxOutsideCircle:l.max(9),legSideCount:l.max(9),maxLegSide:m(5),behindSquareLegCount:l.max(9),maxBehindSquareLeg:m(2),duplicateSlotIds:_(c).max(9),violations:_(lh).max(16),summaryText:O().min(1).max(320)}),Ce=u({x10:l.max(2e3),y10:l.max(2e3)}),dh=u({slotId:c,label:Wn,sector:l.max(7),displaySector:l.max(7),depth:L(["INNER","MIDDLE","DEEP"]),insideCircle:W(),legSideForStriker:W(),behindSquare:W(),point:Ce,occupiedByPlayerId:c.nullable(),occupiedByName:Wn.nullable()}),Pa=u({sequence:M,eventHash:T,inningsIndex:l.max(3),deliveryIndex:l,overBallLabel:O().min(1).max(24),strikerId:c,strikerName:Wn,strikerHand:mt,bowlerId:c,bowlerName:Wn,momentKind:rh,isKeyMoment:W(),runsScored:l,batRuns:l,boundary:L(["NONE","FOUR","SIX"]),legality:L(["LEGAL","WIDE","NO_BALL","DEAD"]),dismissalKind:L(["BOWLED","LBW","CAUGHT","RUN_OUT","STUMPED","HIT_WICKET"]).nullable(),dismissedPlayerName:Wn.nullable(),fieldOutcome:L(["NONE","STOP","DROP","CATCH","MISS","RUN_OUT"]),executedLength:L(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"]).nullable(),trajectory:L(["GROUND","AERIAL","EDGE"]).nullable(),recordedSector:l.max(7).nullable(),displaySector:l.max(7).nullable(),sectorStatus:sh,releasePoint:Ce,pitchBouncePoint:Ce,strikerCreasePoint:Ce,targetPoint:Ce,headline:O().min(1).max(160),detailText:O().min(1).max(280),trackingDisclaimer:O().min(1).max(220)}),uh=u({version:m(Ls),format:Xn,phase:O().min(1).max(64),activeInningsIndex:l.max(3),strikerId:c.nullable(),strikerName:Wn.nullable(),strikerHand:mt,nonStrikerId:c.nullable(),nonStrikerName:Wn.nullable(),bowlerId:c.nullable(),bowlerName:Wn.nullable(),keeperId:c.nullable(),keeperName:Wn.nullable(),keeperPoint:Ce,bowlerReleasePoint:Ce,strikerPoint:Ce,nonStrikerPoint:Ce,boundaryRadiusX10:m(840),circleRadiusX10:m(480),positions:_(dh).min(11).max(12),legality:Os,recentHighlights:_(Pa).max(24),latestHighlight:Pa.nullable(),orientationNote:O().min(1).max(200),trackingDisclaimer:O().min(1).max(220)}),xn="LC_COMMENTARY_ADAPTER_V1";L(["BRIEF","STANDARD","DETAILED","OFF"]);const mh=L(["DELIVERY","OVER","PARTNERSHIP","MILESTONE","DISMISSAL","TACTICAL","CONDITIONS","INNINGS","RESULT","SELECTION"]),gh=L(["EVENT_FIELD","INNINGS_PROJECTION","BATTER_PROJECTION","BOWLER_PROJECTION","PARTNERSHIP_PROJECTION","CHASE_PROJECTION","MATCH_RESULT","FORMAT_RULE"]),ph=u({slot:c,value:O().min(1).max(160),sourceKind:gh,sourceRef:O().min(1).max(160)}),Ih=L(["BATTER_FIFTY","BATTER_CENTURY","BATTER_150","BATTER_DOUBLE_CENTURY","PARTNERSHIP_FIFTY","PARTNERSHIP_CENTURY","PARTNERSHIP_150","BOWLER_THREE_FOR","BOWLER_FIVE_FOR","MAIDEN_OVER","ALL_OUT","WINNING_DELIVERY"]),hh=u({adapterVersion:m(xn),sequence:M,eventType:c,category:mh,templateId:c,templateFamily:c,cooldownApplied:W(),presentationDigest:O().regex(/^[a-f0-9]{8}$/),milestoneTags:_(Ih).max(6),short:O().min(1).max(240),text:O().min(1).max(640),detailed:O().min(1).max(960),factSlots:_(ph).min(1).max(24)});u({adapterVersion:m(xn),format:Xn,presentationKeyDigest:O().regex(/^[a-f0-9]{8}$/),repetitionCooldownWindow:M.max(12),entries:_(hh)});const xa="LC_AUDIO_PRESENTATION_V1",ws="LC_AUDIO_PROVENANCE_V1",Ns=L(["CROWD","EFFECTS","COMMENTARY","INTERFACE"]),Ds=L(["BAT_BALL_DOT","BAT_BALL_SINGLE","BOUNDARY_FOUR","BOUNDARY_SIX","WICKET_FALL","MILESTONE_CHIME","OVER_BELL","INNINGS_CHANGE","MATCH_COMPLETE","UI_CLICK"]),fh=L(["ORIGINAL_PROCEDURAL_SYNTH","ORIGINAL_IN_REPO_PCM"]);L(["PLAYED","QUEUED_AWAITING_GESTURE","DEDUP_SKIPPED","EXPIRED_FAST_FORWARD","MUTED_OR_ZERO_VOLUME","BACKGROUND_TAB_SUPPRESSED","MISSING_ASSET_FALLBACK","DECODE_FAILED_FALLBACK"]);const _i=k().int().min(0).max(100);u({version:m(xa),muted:W(),crowdVolume:_i,effectsVolume:_i,commentaryVolume:_i,interfaceVolume:_i,narrationEnabled:W(),captionsEnabled:W()});const Eh=u({assetId:c,cueKind:Ds,channel:Ns,title:O().min(1).max(120),author:O().min(1).max(120),license:m("MIT_ORIGINAL_LORD_CRICKET_XXVI"),origin:fh,synthesisProfile:O().min(1).max(200),durationMs:M.max(1e4),sha256:T});u({manifestVersion:m(ws),attributionNotice:O().min(1).max(320),networkCallsAllowed:m(!1),assets:_(Eh).min(1).max(64)});const Sh=u({cueId:c,sequence:M,channel:Ns,cueKind:Ds,assetId:c,priority:k().int().min(1).max(100),caption:O().min(1).max(280),narrationText:O().min(1).max(360).optional(),ttlMs:M.max(3e4)});u({adapterVersion:m(xa),matchId:c,format:Xn,cues:_(Sh)});const _h="LC_HISTORICAL_STATISTICS_PROJECTION_V1",Th=L(["CAREER"]),ys=L(["ALL","OPENER","TOP_ORDER","MIDDLE_ORDER","LOWER_ORDER"]),bh=L(["ALL","ACTIVE","RETIRED"]),vh=Zn([m("ALL"),m("ACTIVE"),M.max(X)]),Rh=u({seasonScope:vh,format:m("T20"),competitionId:O().min(1).max(64),opponentTeamId:O().min(1).max(64),venueGroundId:O().min(1).max(64),battingPositionBand:ys,battingPositionExact:M.max(11).nullable(),playerStatus:bh,teamId:O().min(1).max(64)}),Ah=u({seasonNumber:M.max(X),calendarYear:k().int().min(1900).max(9999),phase:L(["ACTIVE","COMPLETE"]),matchesCount:l}),Lh=u({competitionId:c,label:O().min(1).max(120),format:Xn}),Oh=u({formats:_(Xn).min(1).max(3),unsupportedFormatsNote:O().min(1).max(240),competitions:_(Lh).max(32),seasons:_(Ah).max(X),opponents:_(c).max(64),teams:_(c).max(64),venues:u({available:W(),coverage:L(["ALL_RESOLVED","PARTIAL","UNAVAILABLE"]),groundIds:_(c).max(64),note:O().min(1).max(240)}),battingPosition:u({available:m(!0),bands:_(ys).min(1),note:O().min(1).max(240)}),fielding:u({available:W(),archiveCoverageCount:l,totalMatchesCount:l,coverage:L(["ALL_ARCHIVED","PARTIAL_ARCHIVES","UNAVAILABLE"]),note:O().min(1).max(240)})}),wh=u({fixtureId:c,matchId:c,seasonNumber:M.max(X),calendarYear:k().int().min(1900).max(9999),roundNumber:M.max(14),matchDayDate:tn(),competitionId:c,format:m("T20"),groundId:c.nullable(),homeTeamId:c,awayTeamId:c,teamId:c,opponentTeamId:c,battedInnings:M.max(2).nullable(),battingPosition:M.max(11).nullable(),runsScored:l.nullable(),ballsFaced:l.nullable(),fours:l.nullable(),sixes:l.nullable(),notOut:W().nullable(),bowledLegalBalls:l.nullable(),bowlingRunsConceded:l.nullable(),bowlingWickets:l.max(10).nullable(),maidens:l.max(4).nullable(),catches:l.nullable(),stumpings:l.nullable(),runOuts:l.nullable(),archiveEvaluated:W(),archiveReplayAvailable:W(),resultSummary:O().min(1).max(240),sourceCompletionSha256:T}),Nh=u({playerId:c,status:L(["ACTIVE","RETIRED"]),currentTeamId:c,careerTeamIds:_(c).min(1).max(64),retiredAfterSeasonNumber:M.max(X).nullable(),retiredCalendarYear:k().int().min(1900).max(9999).nullable(),seasonsPlayed:l.max(X),matches:l,battingInnings:l,notOuts:l,runs:l,dismissals:l,ballsFaced:l,fours:l,sixes:l,fifties:l,hundreds:l,ducks:l,highScoreRuns:l,highScoreNotOut:W(),highScoreFixtureId:c.nullable(),battingAverageX100:l.nullable(),strikeRateX100:l.nullable(),boundaryRunsPercentX100:l.nullable(),bowlingInnings:l,bowlingRunsConceded:l,bowlingLegalBalls:l,bowlingWickets:l,maidens:l,threeWicketHauls:l,fourWicketHauls:l,fiveWicketHauls:l,bestBowlingWickets:l.max(10),bestBowlingRuns:l.nullable(),bestBowlingFixtureId:c.nullable(),bowlingAverageX100:l.nullable(),economyX100:l.nullable(),bowlingStrikeRateX100:l.nullable(),fieldingMatchesArchived:l,catches:l,stumpings:l,runOuts:l,totalFieldingDismissals:l,bestMatchCatches:l,bestMatchFieldingDismissals:l,bestFieldingFixtureId:c.nullable(),contributingMatches:_(wh).max(X*14)}),Dh=L(["RUNS","BATTING_AVERAGE","BATTING_STRIKE_RATE","HIGH_SCORE","SIXES","WICKETS","BOWLING_AVERAGE","ECONOMY","BOWLING_STRIKE_RATE","BEST_BOWLING","FIELDING_DISMISSALS","CATCHES"]),yh=u({rank:M,tied:W(),playerId:c,teamId:c,status:L(["ACTIVE","RETIRED"]),qualified:W(),primaryDisplay:O().min(1).max(64),primaryValueX100:l,secondaryDisplay:O().min(1).max(96),denominatorCount:l,denominatorLabel:O().min(1).max(64),contributingFixtureIds:_(c).min(1).max(X*14)}),Ch=u({summary:O().min(1).max(200),minDenominator:l,denominatorField:O().min(1).max(64),secondaryRule:O().min(1).max(160).nullable()}),he=u({metric:Dh,title:O().min(1).max(80),sortDirection:L(["DESC","ASC"]),qualificationRule:Ch,denominatorDefinition:O().min(1).max(160),nullPolicy:O().min(1).max(160),tieRule:O().min(1).max(160),entries:_(yh).max(200),qualifiedCount:l,totalCandidatesCount:l}),kh=u({teamId:c,played:l,wins:l,losses:l,ties:l,noResults:l,points:l,runsFor:l,ballsFor:l,runsAgainst:l,ballsAgainst:l});u({projectionVersion:m(_h),sourceClass:Th,separationNotice:O().min(1).max(240),filterQuery:Rh,filterSupport:Oh,totalSourceMatches:l,filteredMatchesCount:l,players:_(Nh).max(1e4),leaderboards:u({RUNS:he,BATTING_AVERAGE:he,BATTING_STRIKE_RATE:he,HIGH_SCORE:he,SIXES:he,WICKETS:he,BOWLING_AVERAGE:he,ECONOMY:he,BOWLING_STRIKE_RATE:he,BEST_BOWLING:he,FIELDING_DISMISSALS:he,CATCHES:he}),teamStandings:_(kh).max(64),projectionDigest:O().regex(/^[0-9a-f]{32}$/)});const Mt="LC_AWARDS_HEURISTIC_GAME_V1",Bh="LC_CAREER_AWARDS_LEDGER_V1",rt=k().int().min(Number.MIN_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),Ph=L(["T20","ODI","RED_BALL"]),xh=u({battingPointsX100:rt,bowlingPointsX100:rt,fieldingPointsX100:l,resultBonusX100:l}),Fh=u({playerId:c,teamId:c,battingPointsX100:rt,bowlingPointsX100:rt,fieldingPointsX100:l,resultBonusX100:l,totalPointsX100:rt,fromWinningTeam:W(),summaryLine:O().min(1).max(240)}),Fa=u({awardVersion:m(Mt),awardCategory:m("PLAYER_OF_THE_MATCH"),awardProvenance:m("GAME_AWARD"),format:Ph,matchId:c,fixtureId:c.nullable(),seasonNumber:M.nullable(),sourceCompletionSha256:T.nullable(),status:L(["AWARDED","NO_RESULT_NOT_AWARDED"]),winnerPlayerId:c.nullable(),winnerTeamId:c.nullable(),fromWinningTeam:W().nullable(),fromLosingTeam:W(),scoreTotalX100:rt.nullable(),components:xh.nullable(),fieldingSourceStatus:L(["ARCHIVE_EVENTS","SCORECARD_NOT_ATTRIBUTABLE"]),explanationText:O().min(1).max(400),formulaSummary:O().min(1).max(400),candidates:_(Fh).max(5)}),Hh=L(["PLAYER_OF_THE_SEASON","LEADING_RUN_SCORER","LEADING_WICKET_TAKER","BEST_FIELDER","EMERGING_YOUTH_PLAYER"]),Mh=u({awardVersion:m(Mt),category:Hh,label:O().min(1).max(120),awardProvenance:m("GAME_AWARD"),status:L(["AWARDED","UNAVAILABLE"]),unavailableReason:O().min(1).max(240).nullable(),qualificationRule:O().min(1).max(240),formulaSummary:O().min(1).max(320),winnerPlayerId:c.nullable(),winnerTeamId:c.nullable(),headlineStat:O().min(1).max(160).nullable(),scoreX100:rt.nullable(),tieBroken:W(),runnerUpPlayerId:c.nullable(),explanationText:O().min(1).max(400)}),Vh=u({awardVersion:m(Mt),seasonNumber:M,calendarYear:k().int().min(1900).max(9999),competitionId:m("LC_T20_LEAGUE_01"),sealedAtSeasonSha256:T.nullable(),provenanceNotice:O().min(1).max(320),awards:_(Mh).length(5)}),Wh=u({key:O().min(1).max(256),seasonNumber:M,fixtureId:c,matchId:c,sourceCompletionSha256:T,award:Fa});u({ledgerVersion:m(Bh),worldOrCareerId:c,matchAwards:_(Wh).max(2e4),seasonAwards:_(Vh).max(200),ledgerSha256:T});const $h="LC_CAREER_MATCH_DIGEST_V1",Ha=k().int().min(0).max(1e3);u({digestVersion:m($h),fixtureId:c,groundId:c.nullable(),creaseOrder:Cn([_(c).max(64),_(c).max(64)]),fielding:_(u({playerId:c,teamId:c,catches:Ha,stumpings:Ha,runOuts:Ha})).max(64)});const Cs=VI.extend({archiveVersion:m("LC_PERSISTENT_WORLD_PORTABLE_V4_GZIP"),compression:m("gzip")});Cs.extend({archiveVersion:m("LC_PERSISTENT_WORLD_PORTABLE_V5_WORLD_V4"),saveSchema:L([dI,uI])}),Cs.extend({archiveVersion:m("LC_PERSISTENT_WORLD_PORTABLE_V6_WORLD_V5"),saveSchema:L([gI,pI])});const Uh="LC_CAREER_STORIES_PROJECTION_V1",Gh=L(["MILESTONE_BATTING","MILESTONE_BOWLING","MILESTONE_FIELDING","FORM_STREAK","YOUTH_BREAKTHROUGH","CONTRACT_TENSION","RETIREMENT_WATCH","AWARD_RECOGNITION","CLUB_BOARD_REVIEW"]),zh=u({key:O().min(1).max(80),value:Zn([O().min(1).max(200),k().int()])}),Yh=u({storyId:O().min(1).max(256),seasonNumber:M,roundNumber:k().int().min(1).max(99),category:Gh,headline:O().min(1).max(160),summaryText:O().min(1).max(480),subjectPlayerId:c.nullable(),subjectTeamId:c.nullable(),linkedMatchKey:O().min(1).max(160).nullable(),factProvenance:_(zh).min(1).max(20)});u({schemaId:m(Uh),worldOrCareerId:c,stories:_(Yh).max(2e4)});const le="LC_SCENARIO_CHALLENGE_V1",Kh="LC_SCENARIO_RECORD_LEDGER_V1",jh=L(["STANDARD","HARD","ELITE"]),ks=L(["WIN","AVOID_DEFEAT"]),qh=u({inningsIndex:l.max(3),legalBalls:l.max(3e3),revision:M,battingTeamId:c,runs:l.max(2e3),wickets:l.max(10),targetToWin:M.max(2e3).nullable()}),Zh=u({schemaId:m(le),scenarioId:c,title:O().min(1).max(80),format:Xn,difficulty:jh,sourceType:m("FICTIONAL_CURATED"),seed:O().min(1).max(256),matchId:c,teamIds:Cn([c,c]),groundId:c,playerTeamId:c,objective:ks,objectiveSummary:O().min(1).max(160),briefing:O().min(1).max(480),checkpoint:qh}),Bs=L(["COMPLETED","FAILED"]),Xh=u({scenarioId:c,challengeSha256:T,attempts:M,completions:l,failures:l,bestMarginType:L(["RUNS","WICKETS","INNINGS"]).nullable(),bestMarginValue:M.nullable(),lastOutcome:Bs.nullable()}),Jh=u({gameId:c,scenarioId:c,challengeSha256:T,playerTeamId:c,objective:ks,outcome:Bs.nullable(),resultText:O().min(1).max(160).nullable()});u({schemaId:m(Kh),records:_(Xh).max(256),attempts:_(Jh).max(64)}).superRefine((n,e)=>{new Set(n.records.map(i=>`${i.scenarioId}:${i.challengeSha256}`)).size!==n.records.length&&e.addIssue({code:"custom",message:"SCENARIO_RECORD_DUPLICATE"}),new Set(n.attempts.map(i=>i.gameId)).size!==n.attempts.length&&e.addIssue({code:"custom",message:"SCENARIO_ATTEMPT_DUPLICATE"});for(const i of n.records)i.completions+i.failures>i.attempts&&e.addIssue({code:"custom",message:"SCENARIO_RECORD_COUNTS"});for(const i of n.attempts)i.outcome===null!=(i.resultText===null)&&e.addIssue({code:"custom",message:"SCENARIO_ATTEMPT_RESULT"})});const Ps="LC_T20_SUPER_OVER_01",xs="LC_T20_SUPER_OVER_RECORD_V1",Fs="LC_ODI_SUPER_OVER_01",Hs="LC_ODI_SUPER_OVER_RECORD_V1",Ti=Dn("kind",[u({kind:m("SET_SUPER_OVER_BATTERS"),teamId:c,playerIds:_(c).min(2).max(3)}),u({kind:m("SET_SUPER_OVER_BOWLER"),teamId:c,playerId:c}),u({kind:m("SET_SUPER_OVER_AGGRESSION"),playerId:c,aggression:l.max(4)}),u({kind:m("BOWL_SUPER_OVER_BALL")})]),Qh=u({schemaId:m(xs),rulesId:m(Ps),gameId:c,baseLastEventHash:T,commands:_(Ti).max(2e3),stateSha256:T}),n2=u({schemaId:m(Hs),rulesId:m(Fs),gameId:c,baseLastEventHash:T,commands:_(Ti).max(2e3),stateSha256:T});Dn("schemaId",[Qh,n2]);const e2=u({battingTeamId:c,runs:l,wickets:l.max(2),legalBalls:l.max(6)});u({roundNumber:M,innings:_(e2).max(2)});const Ms="LC_CUSTOM_COMPETITION_PACK_V1",t2="LC_TOURNAMENT_RUN_V1",i2=Dn("kind",[u({kind:m("ROUND_ROBIN"),legs:Zn([m(1),m(2)]),finalTopTwo:W()}),u({kind:m("GROUPS_KNOCKOUT"),groups:Cn([_(c).min(3).max(4),_(c).min(3).max(4)])}),u({kind:m("SERIES"),matches:Zn([m(1),m(3),m(5),m(7)])})]);function Vs(n,e){new Set(n.teamIds).size!==n.teamIds.length&&e.addIssue({code:"custom",message:"COMPETITION_DUPLICATE_TEAM"}),new Set(n.groundIds).size!==n.groundIds.length&&e.addIssue({code:"custom",message:"COMPETITION_DUPLICATE_GROUND"});const t=n.structure;if(t.kind==="SERIES"&&n.teamIds.length!==2&&e.addIssue({code:"custom",message:"SERIES_NEEDS_TWO_TEAMS"}),t.kind==="ROUND_ROBIN"&&n.teamIds.length<(t.finalTopTwo?3:2)&&e.addIssue({code:"custom",message:"ROUND_ROBIN_TOO_FEW_TEAMS"}),t.kind==="GROUPS_KNOCKOUT"){const i=[...t.groups[0],...t.groups[1]];(new Set(i).size!==i.length||i.length!==n.teamIds.length||!i.every(a=>n.teamIds.includes(a)))&&e.addIssue({code:"custom",message:"GROUPS_MUST_PARTITION_TEAMS"})}}function Ws(n){return u({competitionId:c,title:O().min(1).max(80),format:L(["T20","ODI"]),sourceType:m(n),worldPackId:m("fictional-eight-01"),teamIds:_(c).min(2).max(8),groundIds:_(c).min(1).max(8),structure:i2,points:u({win:l.max(10),tie:l.max(10),loss:l.max(10)}),summary:O().min(1).max(320)})}const $s=Ws("FICTIONAL_CURATED").superRefine(Vs),a2=u({schemaId:m(Ms),packId:c,competitions:_($s).min(1).max(32)}),o2=L(["LEAGUE","GROUP_A","GROUP_B","SEMI_FINAL","FINAL","SERIES"]),r2=u({fixtureId:c,matchNumber:M,stage:o2,homeTeamId:c,awayTeamId:c,groundId:c}),Us=u({fixtureId:c,homeTeamId:c,awayTeamId:c,resultKind:L(["WIN","TIE"]),winnerTeamId:c.nullable(),superOverWinnerTeamId:c.nullable(),homeRuns:l,homeWickets:l.max(10),homeLegalBalls:l,awayRuns:l,awayWickets:l.max(10),awayLegalBalls:l,resultText:O().min(1).max(160),lastEventHash:T});u({schemaId:m(t2),runId:c,competitionId:c,competitionSha256:T,seed:O().min(1).max(128),results:_(Us).max(64)});const s2="LC_USER_COMPETITION_V1",c2="LC_USER_COMPETITION_PACK_V1",Ma=Ws("USER_AUTHORED").superRefine((n,e)=>{Vs(n,e),n.competitionId.startsWith("user-")||e.addIssue({code:"custom",message:"USER_COMPETITION_ID_PREFIX"})});u({schemaId:m(s2),competition:Ma}),u({schemaId:m(c2),competitions:_(Ma).min(1).max(32)});const l2="LC_USER_TOUR_V1",Gs=u({tourId:c.refine(n=>n.startsWith("user-tour-"),"USER_TOUR_ID_PREFIX"),title:O().min(1).max(80),format:L(["T20","ODI"]),hostTeamId:c,touringName:O().min(1).max(40),matches:Zn([m(1),m(3),m(5),m(7)]),groundIds:_(c).min(1).max(8)});u({schemaId:m(l2),tour:Gs});const d2="LC_TOURNAMENT_AUCTION_V1",u2=Dn("kind",[u({kind:m("BID"),max:M.max(1e3)}),u({kind:m("PASS")}),u({kind:m("AUTO")})]);u({schemaId:m(d2),runId:c,competitionId:c,seed:O().min(1).max(160),playerTeamId:c.nullable(),decisions:_(u2).max(400),squadsSha256:T});const m2=Zn([$s,Ma]),zs="LC_T20_RAIN_01",Ys="LC_ODI_RAIN_01",g2="LC_RAIN_MATCH_RECORD_V1",Ks=Dn("kind",[u({kind:m("CALL_TOSS"),teamId:c,call:L(["HEADS","TAILS"])}),u({kind:m("CHOOSE_INNINGS"),teamId:c,choice:L(["BAT","BOWL"])}),u({kind:m("SET_BATTER"),teamId:c,playerId:c}),u({kind:m("SET_BOWLER"),teamId:c,playerId:c}),u({kind:m("SET_AGGRESSION"),playerId:c,aggression:l.max(4)}),u({kind:m("BOWL"),scope:L(["BALL","OVER"])})]),p2=u({inningsIndex:Zn([m(0),m(1)]),atLegalBall:M,oversLost:M,terminal:W()});u({stoppages:_(p2).min(1).max(2)}),u({inningsIndex:Zn([m(0),m(1)]),legalBalls:l,wickets:l.max(10),runs:l,ballsLost:l,allocations:Cn([l,l]),terminal:W(),targetAfter:M.nullable()}),u({kind:L(["WIN","TIE","NO_RESULT"]),winnerTeamId:c.nullable(),marginType:L(["RUNS","WICKETS"]).nullable(),margin:l.nullable(),method:L(["STANDARD","RESOURCE_TABLE"])});const I2=u({schemaId:m(g2),rulesId:L([zs,Ys]),gameId:c,matchId:c,seed:O().min(1).max(256),groundId:c,selectedTeams:_(u({teamId:c,playerIds:_(c).length(11),captainId:c,keeperId:c})).length(2),commands:_(Ks).max(4e3),stateSha256:T}),h2="LC_T20_DRS_01",f2="LC_ODI_DRS_01",E2="LC_EXTRA_RULES_RECORD_V1",S2=Dn("kind",[...Ks.options,u({kind:m("REVIEW_DECISION"),teamId:c,review:W()})]),Va=L(["IN","UMPIRES_CALL","OUT"]);u({pitching:Va,impact:Va,wickets:Va});const _2=u({schemaId:m(E2),rulesId:L([zs,Ys]),rain:W(),reviewRulesId:L([h2,f2]).nullable(),gameId:c,matchId:c,seed:O().min(1).max(256),groundId:c,selectedTeams:_(u({teamId:c,playerIds:_(c).length(11),captainId:c,keeperId:c})).length(2),commands:_(S2).max(6e3),stateSha256:T});Dn("schemaId",[I2,_2]);function _e(n,e){if(!n)throw new Error(`LC_MATCH_ANALYTICS_${e}`)}function T2(n){return n.batRuns+n.extras.wides+n.extras.noBalls+n.extras.byes+n.extras.legByes+n.extras.penalties}function js(n){_e(Number.isInteger(n)&&n>=0&&n<=4,"INNINGS_COUNT");const e=new Map,t=[],i=new Map,a=[],r=[],o=new Map,s=Array(n).fill(0),d=Array(n).fill(0),g=Array(n).fill(0);let E=0,h=0,f=0;function A(b){if(_e(b.sequence===f+1,"SEQUENCE_ORDER"),b.type!=="DELIVERY_RECORDED"){f=b.sequence;return}const w=b.payload.event,D=w.inningsIndex;_e(Number.isInteger(D)&&D>=0&&D<n,"INNINGS_INDEX");const p=T2(w);_e(Number.isSafeInteger(p)&&p>=0,"INVALID_RUNS"),w.shotSector!==null&&_e(Number.isInteger(w.shotSector)&&w.shotSector>=0&&w.shotSector<8,"SHOT_SECTOR"),w.executedLength!==null&&_e(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"].includes(w.executedLength),"PITCH_LENGTH");const I=Math.floor(g[D]/6)+1,v=`${D}:${I}`,y=e.get(v)??{inningsIndex:D,overNumber:I,runs:0,wickets:0,legalBalls:0,attempts:0};y.runs+=p,y.wickets+=+(w.dismissal!==null),y.legalBalls+=Number(w.legalBall),y.attempts+=1,e.set(v,y);const S=[w.strikerId,w.nonStrikerId].sort();let R=t.at(-1);if((!R||R.inningsIndex!==D||R.players[0]!==S[0]||R.players[1]!==S[1])&&(R={inningsIndex:D,players:S,runs:0,legalBalls:0,fromSequence:b.sequence,toSequence:b.sequence},t.push(R)),R.runs+=p,R.legalBalls+=Number(w.legalBall),R.toSequence=b.sequence,w.shotSector!==null){const V=`${D}:${w.strikerId}:${w.shotSector}`,U=i.get(V)??{inningsIndex:D,batterId:w.strikerId,sector:w.shotSector,attempts:0,batRuns:0,fours:0,sixes:0};U.attempts++,U.batRuns+=w.batRuns,U.fours+=+(w.boundary==="FOUR"),U.sixes+=+(w.boundary==="SIX"),i.set(V,U)}else w.batRuns>0&&E++;s[D]+=p,d[D]+=+(w.dismissal!==null),g[D]+=Number(w.legalBall),w.executedLength===null?h++:o.set(w.executedLength,(o.get(w.executedLength)??0)+1),w.dismissal&&r.push({inningsIndex:D,sequence:b.sequence,playerId:w.dismissal.playerId,runs:s[D],wickets:d[D],legalBalls:g[D]}),a.push({inningsIndex:D,sequence:b.sequence,legalBalls:g[D],totalRuns:s[D],wickets:d[D]}),f=b.sequence}function N(b){const w=b?.innings.length??n;if(_e(w<=n,"INNINGS_COUNT"),b){for(let D=0;D<w;D++){const p=b.innings[D];_e(!!p&&s[D]===p.runs,`RUN_RECONCILIATION_${D}`),_e(d[D]===p.wickets,`WICKET_RECONCILIATION_${D}`),_e(g[D]===p.legalBalls,`BALL_RECONCILIATION_${D}`)}for(let D=w;D<n;D++)_e(s[D]===0&&d[D]===0&&g[D]===0,`INNINGS_RECONCILIATION_${D}`)}return{overSummaries:[...e.values()].map(D=>({...D})),worm:a.map(D=>({...D})),partnerships:t.map(D=>({...D,players:[...D.players]})),shotSectors:[...i.values()].map(D=>({...D})).sort((D,p)=>D.inningsIndex-p.inningsIndex||D.batterId.localeCompare(p.batterId)||D.sector-p.sector),unlocatedShots:E,finalRuns:s.slice(0,w),finalLegalBalls:g.slice(0,w),finalWickets:d.slice(0,w),fallOfWickets:r.map(D=>({...D})),pitchLengths:["YORKER","FULL","GOOD","SHORT","FULL_TOSS"].filter(D=>o.has(D)).map(D=>({length:D,attempts:o.get(D)})),unrecordedLengths:h}}return{append:A,snapshot:N,get appliedSequence(){return f}}}function qs(n){let e=js(n),t=null;function i(a){const r=e.appliedSequence;(a.length<r||r>0&&a[r-1]?.eventHash!==t)&&(e=js(n),t=null);for(const o of a.slice(e.appliedSequence))e.append(o),t=o.eventHash}return{update:i,snapshot:a=>e.snapshot(a),get appliedSequence(){return e.appliedSequence}}}const b2=new Set(["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket"]),v2=new Set(["slip-1","slip-2"]);function Vt(n){return`${Math.floor(n/6)}.${n%6}`}function Zs(n){let e=0,t=0,i=0;for(const a of n)b2.has(a.slotId)?e+=1:t+=1,v2.has(a.slotId)&&(i+=1);return{ring:e,boundary:t,closeCatchers:i}}function Wa(n,e,t){const i=n==="T20"&&e<36||n==="ODI"&&e<60;return t==="SLIP_ATTACK"?["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"]:i?["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","long-on"]:t==="BALANCED_RING"?["slip-1","point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","long-on"]:n==="ODI"&&e>=240?["point","cover","deep-cover","long-off","mid-on","midwicket","deep-square-leg","fine-leg","long-on"]:["point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","fine-leg","long-on"]}function $a(n,e){return[...n].sort().map((i,a)=>({slotId:e[a],playerId:i}))}function Ua(n,e){if(n.length!==e.length)return!1;const t=i=>[...i].sort((a,r)=>Or(a.playerId,r.playerId)).map(a=>`${a.playerId}:${a.slotId}`).join("|");return t(n)===t(e)}function R2(n,e,t){const i=Zs(t);return[{controlId:"BATTING_AGGRESSION",side:"BATTING",label:"Batting aggression (0–4)",currentSetting:n?`Level ${n.aggression} / 4`:"Awaiting striker",upside:"Higher aggression shifts contact toward scoring strokes and boundaries when chasing or accelerating late.",tradeOff:"Higher aggression increases aerial, edge, and miss contact; lower levels lean on defence at a slower scoring rate."},{controlId:"BATTING_INTENT",side:"BATTING",label:"Batting intent",currentSetting:n?n.intent:"Awaiting striker",upside:"ROTATE boosts single-taking to turn strike over; PROTECT suppresses risky singles to shield a partner or survive a spell.",tradeOff:"ROTATE adds run-out exposure against sharp ring fielders; PROTECT passes up singles and can stall scoreboard momentum."},{controlId:"BOWLING_LINE",side:"BOWLING",label:"Bowling line",currentSetting:e?e.line:"Awaiting bowler",upside:"STUMPS brings bowled and LBW into play and narrows straight sectors; OFF channels strokes into off-side catchers and ring stops.",tradeOff:"LEG line disables LBW dismissals and raises wide risk under the legality model."},{controlId:"BOWLING_LENGTH",side:"BOWLING",label:"Intended bowling length",currentSetting:e?e.length:"Awaiting bowler",upside:"GOOD balances control; YORKER raises misses and suppresses lofted contact; SHORT tests batters with higher aerial and edge rates.",tradeOff:"Execution depends on control and low fatigue: missed YORKER or FULL balls spill into high-scoring full tosses."},{controlId:"BOWLING_EFFORT",side:"BOWLING",label:"Bowling effort",currentSetting:e?e.effort:"Awaiting bowler",upside:"CONSERVE lowers wide/no-ball risk and slows fatigue across longer spells; MAXIMUM pushes effort in short bursts.",tradeOff:"MAXIMUM raises wide/no-ball risk and accelerates bowler fatigue, degrading movement and length accuracy later in the spell."},{controlId:"BOWLING_VARIATION",side:"BOWLING",label:"Delivery variation",currentSetting:e?e.variationId:"Awaiting bowler",upside:"Stock ball uses baseline control; selecting a bowler's supported variation changes pace or turn mix when batters settle.",tradeOff:"Only variations listed on the active bowler are legal; overusing effort alongside variations still accumulates spell fatigue."},{controlId:"FIELD_PLACEMENT",side:"FIELDING",label:"Named 9-man field",currentSetting:t.length===9?`${i.ring} in ring · ${i.boundary} outside · ${i.closeCatchers} slip${i.closeCatchers===1?"":"s"}`:"Awaiting innings",upside:"Slips maximize edge catches; ring fielders cut singles and create run-out pressure; deep riders suppress fours and sixes.",tradeOff:"Pushing fielders to the boundary opens single-taking gaps in the ring; circle and leg-side limits apply by format and striker hand."}]}const Ga={line:"STUMPS",length:"GOOD",variationId:"stock",effort:"NORMAL"},Xs={aggression:2,intent:"NORMAL"},A2=new Set(["BOWLED","LBW","CAUGHT","STUMPED","HIT_WICKET"]);function L2(n,e,t=[]){let i=0,a=0,r=0,o={...Ga},s=[...t];const d=new Map,g=[],E={0:null,1:null};let h=null;const f=[],A=new Map;function N(p,I){const v=`${p}:${I}`,y=A.get(v);if(y)return y;const S=d.get(I)??{...Xs},R={inningsIndex:p,playerId:I,dismissed:!1,initialPlan:{...S},planCounts:new Map,planChangesCount:0,ballsFaced:0,runs:0,dots:0,singles:0,boundaries:0};return A.set(v,R),f.push(R),R}function b(){for(const p of[0,1])E[p]&&(E[p].status="COMPLETED",E[p]=null);h&&(h.status="COMPLETED",h=null)}for(const p of n){const I=typeof p.payload=="object"&&p.payload!==null&&!Array.isArray(p.payload)?p.payload:{};if(p.type==="INNINGS_STARTED"){b(),i=typeof I.inningsIndex=="number"?I.inningsIndex:i+1,a=0,r=0,o={...Ga},d.clear();continue}if(p.type==="INNINGS_COMPLETED"||p.type==="DECLARED"||p.type==="MATCH_COMPLETED"){b();continue}if(p.type==="BATTER_SELECTED"){const v=String(I.playerId??"");v&&N(i,v);continue}if(p.type==="BATTING_PLAN_CHANGED"){const v=String(I.playerId??""),y=typeof I.aggression=="number"?I.aggression:2,S=I.intent==="ROTATE"||I.intent==="PROTECT"?I.intent:"NORMAL";if(v){d.set(v,{aggression:y,intent:S});const R=N(i,v);R.planChangesCount+=1,R.ballsFaced===0&&(R.initialPlan={aggression:y,intent:S})}continue}if(p.type==="BOWLER_SELECTED"){const v=String(I.playerId??""),y=Math.floor(a/6),S=y%2;o={...Ga};const R=E[S];if(R&&R.bowlerId===v)R.status="IN_PROGRESS",R.endOver=y+1,h=R;else{R&&(R.status="COMPLETED");const V=1-S;E[V]?.bowlerId===v&&(E[V].status="COMPLETED",E[V]=null),r+=1;const U={inningsIndex:i,spellNumberInInnings:r,endParity:S,bowlerId:v,status:"IN_PROGRESS",startOver:y+1,endOver:y+1,planCounts:new Map,initialPlan:{...o},planChangesCount:0,fieldChangesCount:0,latestFieldSlots:[...s],legalBalls:0,deliveryAttempts:0,runsConceded:0,wickets:0,dots:0,singles:0,boundaries:0,fours:0,sixes:0,wides:0,noBalls:0,intendedLengthMatches:0,intendedLengthEvaluatedBalls:0,executedLengths:{YORKER:0,FULL:0,GOOD:0,SHORT:0,FULL_TOSS:0},trajectories:{GROUND:0,AERIAL:0,EDGE:0,NO_CONTACT:0},fieldOutcomes:{STOP:0,CATCH:0,DROP:0,MISS:0,RUN_OUT:0}};E[S]=U,h=U,g.push(U)}continue}if(p.type==="BOWLING_PLAN_CHANGED"){const v=I.line==="OFF"||I.line==="LEG"?I.line:"STUMPS",y=I.length==="YORKER"||I.length==="FULL"||I.length==="SHORT"?I.length:"GOOD",S=I.effort==="CONSERVE"||I.effort==="MAXIMUM"?I.effort:"NORMAL",R=typeof I.variationId=="string"&&I.variationId.length>0?I.variationId:"stock";o={line:v,length:y,variationId:R,effort:S},h&&(h.planChangesCount+=1,h.deliveryAttempts===0&&(h.initialPlan={...o}));continue}if(p.type==="FIELD_CHANGED"){Array.isArray(I.fieldSlots)&&(s=I.fieldSlots.map(v=>({slotId:v.slotId,playerId:v.playerId})),h&&(h.fieldChangesCount+=1,h.latestFieldSlots=[...s]));continue}if(p.type==="OVER_COMPLETED"){h&&h.status==="IN_PROGRESS"&&(h.status="BETWEEN_OVERS");continue}if(p.type==="DELIVERY_RECORDED"){const v=I.event;if(!v)continue;const y=Math.floor(a/6);(!h||h.bowlerId!==v.bowlerId)&&(r+=1,h={inningsIndex:v.inningsIndex,spellNumberInInnings:r,endParity:y%2,bowlerId:v.bowlerId,status:"IN_PROGRESS",startOver:y+1,endOver:y+1,planCounts:new Map,initialPlan:{...o},planChangesCount:0,fieldChangesCount:0,latestFieldSlots:[...s],legalBalls:0,deliveryAttempts:0,runsConceded:0,wickets:0,dots:0,singles:0,boundaries:0,fours:0,sixes:0,wides:0,noBalls:0,intendedLengthMatches:0,intendedLengthEvaluatedBalls:0,executedLengths:{YORKER:0,FULL:0,GOOD:0,SHORT:0,FULL_TOSS:0},trajectories:{GROUND:0,AERIAL:0,EDGE:0,NO_CONTACT:0},fieldOutcomes:{STOP:0,CATCH:0,DROP:0,MISS:0,RUN_OUT:0}},g.push(h)),h.endOver=Math.max(h.endOver,y+1),h.latestFieldSlots=s.length===9?[...s]:h.latestFieldSlots,h.deliveryAttempts+=1;const S=`${o.line}|${o.length}|${o.effort}|${o.variationId}`,R=h.planCounts.get(S);R?R.balls+=1:h.planCounts.set(S,{plan:{...o},balls:1}),v.legalBall&&(h.legalBalls+=1,a+=1);const V=v.batRuns+v.extras.wides+v.extras.noBalls;h.runsConceded+=V,v.legality==="WIDE"&&(h.wides+=v.extras.wides),v.legality==="NO_BALL"&&(h.noBalls+=v.extras.noBalls),v.legalBall&&v.batRuns===0&&v.extras.wides===0&&v.extras.noBalls===0&&v.extras.byes===0&&v.extras.legByes===0&&(h.dots+=1),v.batRuns===1&&v.boundary==="NONE"&&(h.singles+=1),v.boundary==="FOUR"?(h.boundaries+=1,h.fours+=1):v.boundary==="SIX"&&(h.boundaries+=1,h.sixes+=1),v.dismissal&&A2.has(v.dismissal.kind)&&(h.wickets+=1),v.executedLength&&(h.executedLengths[v.executedLength]+=1,h.intendedLengthEvaluatedBalls+=1,v.executedLength===o.length&&(h.intendedLengthMatches+=1)),v.trajectory?h.trajectories[v.trajectory]+=1:h.trajectories.NO_CONTACT+=1,v.fieldOutcome!=="NONE"&&(h.fieldOutcomes[v.fieldOutcome]+=1);const U=N(v.inningsIndex,v.strikerId),H=d.get(v.strikerId)??{...Xs},en=`${H.aggression}|${H.intent}`;if(v.countsAsBallFaced){U.ballsFaced+=1;const P=U.planCounts.get(en);P?P.balls+=1:U.planCounts.set(en,{plan:{...H},balls:1}),v.batRuns===0&&(U.dots+=1)}if(U.runs+=v.batRuns,v.batRuns===1&&v.boundary==="NONE"&&(U.singles+=1),(v.boundary==="FOUR"||v.boundary==="SIX")&&(U.boundaries+=1),v.dismissal){const P=N(v.inningsIndex,v.dismissal.playerId);P.dismissed=!0}}}const w=g.filter(p=>p.deliveryAttempts>0).map(p=>{let I=p.initialPlan,v=-1;for(const P of p.planCounts.values())P.balls>v&&(v=P.balls,I=P.plan);const y=Zs(p.latestFieldSlots),S=Vt(p.legalBalls),R=p.legalBalls>0?Math.round(p.runsConceded*600/p.legalBalls):null,V=R===null?"—":(R/100).toFixed(2),U=e[p.bowlerId]??p.bowlerId,en=`${p.status==="COMPLETED"?"Completed spell":p.status==="BETWEEN_OVERS"?"Spell between overs":"Current over"} (overs ${p.startOver}–${p.endOver}): accepted plan targeted ${I.length} length on ${I.line} (${I.effort} effort, ${I.variationId}, ${y.ring} in ring / ${y.boundary} deep). Recorded ${S} overs, ${p.wickets}/${p.runsConceded} (econ ${V}), ${p.intendedLengthMatches}/${p.intendedLengthEvaluatedBalls} on intended length, ${p.dots} dots, ${p.boundaries} boundaries.`;return{spellId:`inn${p.inningsIndex}-spell${p.spellNumberInInnings}-${p.bowlerId}`,inningsIndex:p.inningsIndex,spellNumberInInnings:p.spellNumberInInnings,bowlerId:p.bowlerId,bowlerName:U,status:p.status,startOver:p.startOver,endOver:p.endOver,acceptedPlan:{primaryLine:I.line,primaryLength:I.length,primaryEffort:I.effort,primaryVariationId:I.variationId,latestRingFielders:y.ring,latestBoundaryFielders:y.boundary,latestCloseCatchers:y.closeCatchers,planChangesCount:p.planChangesCount,fieldChangesCount:p.fieldChangesCount},outcomes:{legalBalls:p.legalBalls,oversDisplay:S,deliveryAttempts:p.deliveryAttempts,runsConceded:p.runsConceded,wickets:p.wickets,dots:p.dots,singles:p.singles,boundaries:p.boundaries,fours:p.fours,sixes:p.sixes,wides:p.wides,noBalls:p.noBalls,economyX100:R,intendedLengthMatches:p.intendedLengthMatches,intendedLengthEvaluatedBalls:p.intendedLengthEvaluatedBalls,executedLengths:{...p.executedLengths},trajectories:{...p.trajectories},fieldOutcomes:{...p.fieldOutcomes}},factualSummary:en}}).reverse(),D=f.filter(p=>p.ballsFaced>0||p.runs>0||p.dismissed).map(p=>{let I=p.initialPlan,v=-1;for(const U of p.planCounts.values())U.balls>v&&(v=U.balls,I=U.plan);const y=p.ballsFaced>0?Math.round(p.runs*1e4/p.ballsFaced):null,S=y===null?"—":(y/100).toFixed(2),R=e[p.playerId]??p.playerId,V=`Accepted plan: aggression ${I.aggression}/4 (${I.intent}). Recorded ${p.runs}${p.dismissed?"":"*"} (${p.ballsFaced}b, SR ${S}), ${p.dots} dots, ${p.singles} singles, ${p.boundaries} boundaries.`;return{stintId:`inn${p.inningsIndex}-bat-${p.playerId}`,inningsIndex:p.inningsIndex,playerId:p.playerId,playerName:R,dismissed:p.dismissed,acceptedPlan:{primaryAggression:I.aggression,primaryIntent:I.intent,planChangesCount:p.planChangesCount},outcomes:{ballsFaced:p.ballsFaced,runs:p.runs,dots:p.dots,singles:p.singles,boundaries:p.boundaries,strikeRateX100:y},factualSummary:V}}).reverse();return{spellReviews:w,battingStintReviews:D}}function Js(n){const e=n.innings[n.activeIndex],t=e?.innings,i=t?.legalBalls??0,a=t?.runs??0,r=t?.wickets??0,o=t?.targetToWin??null,s=t==null?null:t.strikerEnd==="NORTH"?t.northBatterId:t.southBatterId,d=s!=null?n.activeBattingPlans[s]??{aggression:2,intent:"NORMAL"}:null;let g=`${n.format} · ${n.phase}`,E="Named 9-man field · max 5 leg-side · max 2 behind square leg.";n.format==="T20"?i<36?(g="T20 Powerplay (Overs 0.0–5.5)",E="Max 2 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):i<90?(g="T20 Middle Overs (Overs 6.0–14.5)",E="Max 5 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):(g="T20 Late Overs (Overs 15.0–19.5)",E="Max 5 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):n.format==="ODI"?i<60?(g="ODI Powerplay 1 (Overs 0.0–9.5)",E="Max 2 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):i<240?(g="ODI Middle Overs (Overs 10.0–39.5)",E="Max 4 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):(g="ODI Late Overs (Overs 40.0–49.5)",E="Max 5 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):(g=`Five-day Red-ball · Day ${n.redBallDay??1} · Innings ${n.activeIndex+1}`,E="No circle limit · max 5 leg-side · max 2 behind square leg · new ball at 80.0 overs.");const h=n.format==="T20"?120:n.format==="ODI"?300:null,f=h===null?null:Math.max(0,h-i),A=i>0?(a*6/i).toFixed(2):"0.00",N=o!==null&&f!==null&&f>0?(Math.max(0,o-a)*6/f).toFixed(2):null;let b=t?`${a}/${r} (${Vt(i)} ov, CRR ${A}) · ${10-r} wicket${10-r===1?"":"s"} in hand.`:"Match setup complete; awaiting opening innings.";if(t&&o!==null){const H=Math.max(0,o-a);b=f!==null?`Chasing ${o}: need ${H} from ${f} balls (RRR ${N??"—"}, CRR ${A}, ${10-r} wkts in hand).`:`Fourth-innings target ${o}: need ${H} more runs (${10-r} wkts in hand).`}else if(t&&n.format==="RED_BALL"&&n.innings.length>1){const H=t.battingTeamId,en=n.innings.filter(K=>K.innings.battingTeamId===H).reduce((K,F)=>K+F.innings.runs,0),P=n.innings.filter(K=>K.innings.battingTeamId!==H).reduce((K,F)=>K+F.innings.runs,0),x=en-P;b=`${a}/${r} (${Vt(i)} ov) · batting side ${x>=0?`leads by ${x}`:`trails by ${Math.abs(x)}`} overall.`}const w=`Seam ${(n.pitch.seamBp/100).toFixed(2)}/100 · Spin ${(n.pitch.turnBp/100).toFixed(2)}/100 · Wear ${n.pitch.wearPoints} pts.`;let D="No active bowler selected.";const p=t?.bowlerId??n.activeBowlingPlan?.bowlerId??null;if(p&&e){const H=e.bowling[p],en=H?.legalBalls??0,P=n.fatigueBpByPlayerId[p]??0,x=n.format==="T20"?24:n.format==="ODI"?60:null,K=x===null?"no over cap":`${Vt(Math.max(0,x-en))} ov left in quota`;D=`${n.names[p]??p}: ${Vt(en)} ov, ${H?.wickets??0}/${H?.runsConceded??0} · Fatigue ${Math.round(P/100)}% · ${K}.`}const I=R2(d,n.activeBowlingPlan,n.activeFieldSlots),v=[],y=n.format==="T20"&&i>=90||n.format==="ODI"&&i>=240,S=n.format==="T20"&&i>=36&&i<90||n.format==="ODI"&&i>=60&&i<240,R=N===null?null:Number(N);if(s&&d){const H=r>=4&&(f===null||f>24);v.push({presetId:"BAT_CONSOLIDATE",commandKind:"SET_BATTING_PLAN",label:"Consolidate & protect wicket",whenToUse:"Rebuild after early wickets, survive a testing spell, or bat time in red-ball.",tradeOff:"Lowers boundary frequency and passes up tight singles (aggression 1, PROTECT).",contextualMatch:H||n.format==="RED_BALL"&&r>=5,contextualReason:H?`${r} wickets down with overs remaining.`:"",activeNow:d.aggression===1&&d.intent==="PROTECT",battingPatch:{aggression:1,intent:"PROTECT"}},{presetId:"BAT_ROTATE_STRIKE",commandKind:"SET_BATTING_PLAN",label:"Work singles & rotate strike",whenToUse:"Keep the scoreboard moving in middle overs or a measured chase.",tradeOff:"Increases single attempts and run-out exposure against inner-ring fielders (aggression 2, ROTATE).",contextualMatch:S||R!==null&&R>=5&&R<=8,contextualReason:S?"Middle-overs spread field leaves single-taking pockets.":R!==null&&R>=5&&R<=8?`Measured required rate (${N}).`:"",activeNow:d.aggression===2&&d.intent==="ROTATE",battingPatch:{aggression:2,intent:"ROTATE"}},{presetId:"BAT_BALANCED_TEMPO",commandKind:"SET_BATTING_PLAN",label:"Balanced tempo",whenToUse:"Default tempo when building an innings platform without extra run-out risk.",tradeOff:"Neutral contact and running weights (aggression 2, NORMAL).",contextualMatch:!H&&!S&&!y&&(R===null||R<=8),contextualReason:!H&&!S&&!y?"Opening phase platform.":"",activeNow:d.aggression===2&&d.intent==="NORMAL",battingPatch:{aggression:2,intent:"NORMAL"}},{presetId:"BAT_BOUNDARY_PUSH",commandKind:"SET_BATTING_PLAN",label:"Boundary push",whenToUse:"Accelerate in death overs or chase a steep required rate with wickets in hand.",tradeOff:"Sharply increases aerial, edge, and miss dismissal exposure (aggression 4, NORMAL).",contextualMatch:y&&r<=6||R!==null&&R>8.5,contextualReason:R!==null&&R>8.5?`Required rate is ${N} per over.`:y?"Death-overs acceleration window.":"",activeNow:d.aggression===4&&d.intent==="NORMAL",battingPatch:{aggression:4,intent:"NORMAL"}})}if(n.activeBowlingPlan){const H=n.activeBowlingPlan,en=n.fatigueBpByPlayerId[H.bowlerId]??0,P=n.bowlerVariationsByPlayerId[H.bowlerId]??["stock"],x=P.includes("stock")?"stock":P[0]??"stock",K=n.format==="T20"&&i<36||n.format==="ODI"&&i<60;v.push({presetId:"BOWL_DISCIPLINED_CHANNEL",commandKind:"SET_BOWLING_PLAN",label:"Disciplined off-stump channel",whenToUse:"Standard containing and wicket-hunting plan feeding off-side ring and slip fielders.",tradeOff:"Missed lengths spill to FULL rather than yorkers (OFF, GOOD, NORMAL).",contextualMatch:!y&&en<4500,contextualReason:!y&&en<4500?"Controlled channel with fresh bowler.":"",activeNow:H.line==="OFF"&&H.length==="GOOD"&&H.effort==="NORMAL"&&H.variationId===x,bowlingPatch:{line:"OFF",length:"GOOD",effort:"NORMAL",variationId:x}},{presetId:"BOWL_ATTACK_STUMPS",commandKind:"SET_BOWLING_PLAN",label:"Pitch full at the stumps",whenToUse:"Search for bowled/LBW with a new ball, seam/spin movement, or against lower-order batters.",tradeOff:"Length errors become high-scoring full tosses (STUMPS, FULL, NORMAL).",contextualMatch:K||r>=7||n.pitch.seamBp>=5600,contextualReason:r>=7?"Lower order exposed.":K?"Powerplay / new-ball wicket window.":n.pitch.seamBp>=5600?"Above-neutral seam assistance.":"",activeNow:H.line==="STUMPS"&&H.length==="FULL"&&H.effort==="NORMAL"&&H.variationId===x,bowlingPatch:{line:"STUMPS",length:"FULL",effort:"NORMAL",variationId:x}},{presetId:"BOWL_CONSERVE_SPELL",commandKind:"SET_BOWLING_PLAN",label:"Conserve spell accuracy",whenToUse:"Extend a tired bowler's spell or cut extras when fatigue rises above 40%.",tradeOff:"Uses CONSERVE effort rather than maximum pace effort (OFF, GOOD, CONSERVE).",contextualMatch:en>=4e3,contextualReason:en>=4e3?`Active bowler fatigue is ${Math.round(en/100)}%.`:"",activeNow:H.line==="OFF"&&H.length==="GOOD"&&H.effort==="CONSERVE"&&H.variationId===x,bowlingPatch:{line:"OFF",length:"GOOD",effort:"CONSERVE",variationId:x}},{presetId:"BOWL_YORKER_CLOSE",commandKind:"SET_BOWLING_PLAN",label:"Death-overs yorker plan",whenToUse:"Suppress lofted boundaries in the closing overs with a high-control, rested bowler.",tradeOff:"Missed yorkers become full tosses, and MAXIMUM effort adds wide/no-ball and fatigue risk.",contextualMatch:y&&en<4500,contextualReason:y&&en<4500?"Late overs with rested bowler.":"",activeNow:H.line==="STUMPS"&&H.length==="YORKER"&&H.effort==="MAXIMUM"&&H.variationId===x,bowlingPatch:{line:"STUMPS",length:"YORKER",effort:"MAXIMUM",variationId:x}},{presetId:"BOWL_SHORT_TEST",commandKind:"SET_BOWLING_PLAN",label:"Short-ball examination",whenToUse:"Force aerial and edge contact for a short burst when catchers are in place.",tradeOff:"Raises aerial boundary risk plus MAXIMUM effort extras and faster fatigue.",contextualMatch:n.format==="RED_BALL"&&r>=6&&en<3500,contextualReason:n.format==="RED_BALL"&&r>=6&&en<3500?"Rested bowler testing lower order.":"",activeNow:H.line==="OFF"&&H.length==="SHORT"&&H.effort==="MAXIMUM"&&H.variationId===x,bowlingPatch:{line:"OFF",length:"SHORT",effort:"MAXIMUM",variationId:x}})}if(n.outfieldIds.length===9){const H=$a(n.outfieldIds,Wa(n.format,i,"SLIP_ATTACK")),en=$a(n.outfieldIds,Wa(n.format,i,"BALANCED_RING")),P=$a(n.outfieldIds,Wa(n.format,i,"BOUNDARY_PROTECT")),x=n.format==="T20"&&i<36||n.format==="ODI"&&i<60;v.push({presetId:"FIELD_SLIP_ATTACK",commandKind:"SET_FIELD",label:"Attacking two-slip cordon",whenToUse:"Convert edges with a new ball, live seam/spin pitch, or exposed lower order.",tradeOff:"Leaves fewer boundary sweepers if batters clear the infield (7 in ring, 2 slips, 2 deep).",contextualMatch:x||r>=7||n.format==="RED_BALL",contextualReason:x?"Legal 2-out powerplay cordon.":r>=7?"Catching cordon for lower order.":"",activeNow:Ua(n.activeFieldSlots,H),fieldSlots:H},{presetId:"FIELD_BALANCED_RING",commandKind:"SET_FIELD",label:"Balanced slip & ring",whenToUse:"Keep 1 slip and ring single-saving cover while posting phase-legal sweepers.",tradeOff:"Splits protection between edge catching and deep boundary cover.",contextualMatch:S,contextualReason:S?"Middle-overs ring + sweeper balance.":"",activeNow:Ua(n.activeFieldSlots,en),fieldSlots:en},{presetId:"FIELD_BOUNDARY_PROTECT",commandKind:"SET_FIELD",label:"Boundary rider defence",whenToUse:"Defend a total in late overs or against high-aggression boundary hitting.",tradeOff:"Removes slips and opens single-taking space inside the circle.",contextualMatch:y||R!==null&&R>8,contextualReason:y?"Maximum phase-legal boundary protection.":R!==null&&R>8?"Chasing side needs boundaries.":"",activeNow:Ua(n.activeFieldSlots,P),fieldSlots:P})}const{spellReviews:V,battingStintReviews:U}=L2(n.events,n.names,n.activeFieldSlots);return oh.parse({version:Ba,format:n.format,situation:{phaseLabel:g,fieldRestrictionLabel:E,scoreContextLabel:b,pitchSummaryLabel:w,activeBowlerWorkloadLabel:D},controlGuide:I,presets:v,spellReviews:V,battingStintReviews:U})}const Qs="Illustrative highlight from committed event categories — no measured ball speed, distance, or tracking coordinates.",za=[{slotId:"slip-1",label:"First slip",sector:7,depth:"INNER",insideCircle:!0,legSideRhb:!1,behindSquare:!0,rhbPoint:{x10:1135,y10:1315}},{slotId:"slip-2",label:"Second slip",sector:7,depth:"INNER",insideCircle:!0,legSideRhb:!1,behindSquare:!0,rhbPoint:{x10:1225,y10:1275}},{slotId:"point",label:"Point",sector:6,depth:"MIDDLE",insideCircle:!0,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1380,y10:1080}},{slotId:"cover",label:"Cover",sector:5,depth:"MIDDLE",insideCircle:!0,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1320,y10:820}},{slotId:"mid-off",label:"Mid-off",sector:4,depth:"MIDDLE",insideCircle:!0,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1145,y10:650}},{slotId:"mid-on",label:"Mid-on",sector:4,depth:"MIDDLE",insideCircle:!0,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:855,y10:650}},{slotId:"midwicket",label:"Midwicket",sector:3,depth:"MIDDLE",insideCircle:!0,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:680,y10:820}},{slotId:"deep-square-leg",label:"Deep square leg",sector:2,depth:"DEEP",insideCircle:!1,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:245,y10:1050}},{slotId:"fine-leg",label:"Fine leg",sector:1,depth:"DEEP",insideCircle:!1,legSideRhb:!0,behindSquare:!0,rhbPoint:{x10:460,y10:1530}},{slotId:"deep-cover",label:"Deep cover",sector:5,depth:"DEEP",insideCircle:!1,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1560,y10:480}},{slotId:"long-on",label:"Long-on",sector:4,depth:"DEEP",insideCircle:!1,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:790,y10:240}},{slotId:"long-off",label:"Long-off",sector:4,depth:"DEEP",insideCircle:!1,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1210,y10:240},odiOnly:!0}],nc=new Map(za.map(n=>[n.slotId,n])),ec={x10:1e3,y10:740},tc={x10:1e3,y10:1180},O2={x10:1e3,y10:1340};function ic(n,e){if(!Number.isInteger(n)||n<0||n>7)throw new Error("INVALID_PRESENTATION_SECTOR");return e==="L"?7-n:n}function ac(n,e){return{x10:e==="L"?2e3-n.x10:n.x10,y10:n.y10}}function oc(n){return n==="ODI"?za:za.filter(e=>!e.odiOnly)}function w2(n,e){return n==="T20"?e<36?{maxOutsideCircle:2,phaseLabel:"T20 Powerplay (overs 1–6): max 2 outside circle"}:{maxOutsideCircle:5,phaseLabel:"T20 Overs 7–20: max 5 outside circle"}:n==="ODI"?e<60?{maxOutsideCircle:2,phaseLabel:"ODI Powerplay 1 (overs 1–10): max 2 outside circle"}:e<240?{maxOutsideCircle:4,phaseLabel:"ODI Powerplay 2 (overs 11–40): max 4 outside circle"}:{maxOutsideCircle:5,phaseLabel:"ODI Powerplay 3 (overs 41–50): max 5 outside circle"}:{maxOutsideCircle:9,phaseLabel:"Five-day red-ball: outer circle unrestricted, max 5 leg side, max 2 behind square leg"}}function N2(n){const{format:e,strikerHand:t,legalBalls:i,fieldSlots:a,outfieldIds:r}=n,{maxOutsideCircle:o,phaseLabel:s}=w2(e,i),d=new Set(oc(e).map(y=>y.slotId)),g=[];if(a.length!==9&&g.push({code:"SLOT_COUNT",message:`Exactly 9 outfielders must be placed (currently ${a.length}).`,affectedSlotIds:[]}),r.length===9){const y=[...a.map(R=>R.playerId)].sort().join("|"),S=[...r].sort().join("|");y!==S&&g.push({code:"UNIQUE_PLAYERS",message:"Every active outfielder must be assigned to exactly one field position.",affectedSlotIds:[]})}else new Set(a.map(y=>y.playerId)).size!==a.length&&g.push({code:"UNIQUE_PLAYERS",message:"Each outfielder may occupy only one position.",affectedSlotIds:[]});const E=new Map;for(const y of a)E.set(y.slotId,(E.get(y.slotId)??0)+1);const h=[...E.entries()].filter(([,y])=>y>1).map(([y])=>y);if(h.length>0){const y=h.map(S=>nc.get(S)?.label??S);g.push({code:"DUPLICATE_POSITION",message:`Duplicate field position${h.length>1?"s":""}: ${y.join(", ")}.`,affectedSlotIds:h.slice(0,9)})}const f=[...new Set(a.map(y=>y.slotId).filter(y=>!d.has(y)))];f.length>0&&g.push({code:"UNSUPPORTED_POSITION",message:`Unsupported position for ${e}: ${f.join(", ")}.`,affectedSlotIds:f.slice(0,9)});let A=0,N=0,b=0;const w=[],D=[],p=[];for(const y of a){const S=nc.get(y.slotId);if(!S)continue;S.insideCircle||(A+=1,w.push(y.slotId)),(t==="R"?S.legSideRhb:!S.legSideRhb)&&(N+=1,D.push(y.slotId),S.behindSquare&&(b+=1,p.push(y.slotId)))}A>o&&g.push({code:"CIRCLE_RESTRICTION",message:`Too many fielders outside the 30-yard circle (${A}/${o} allowed in this phase).`,affectedSlotIds:[...new Set(w)].slice(0,9)}),N>5&&g.push({code:"LEG_SIDE_LIMIT",message:`Too many leg-side fielders for ${t==="L"?"left-hand":"right-hand"} striker (${N}/5 maximum).`,affectedSlotIds:[...new Set(D)].slice(0,9)}),b>2&&g.push({code:"BEHIND_SQUARE_LEG_LIMIT",message:`Too many fielders behind square on the leg side (${b}/2 maximum).`,affectedSlotIds:[...new Set(p)].slice(0,9)});const I=g.length===0,v=I?`Legal field (${t}HB): ${A}/${o} outside circle · ${N}/5 leg side · ${b}/2 behind square leg.`:g.map(y=>y.message).join(" ");return Os.parse({isLegal:I,format:e,strikerHand:t,phaseLabel:s,outsideCircleCount:A,maxOutsideCircle:o,legSideCount:N,maxLegSide:5,behindSquareLegCount:b,maxBehindSquareLeg:2,duplicateSlotIds:h,violations:g,summaryText:v.slice(0,320)})}function D2(n,e){const t=n.slice(0,8),i=Number.parseInt(t,16);return((Number.isFinite(i)?i:0)^Math.imul(e,2654435761))>>>0&255}function y2(n,e){const t=(e%5-2)*5,i=n==="YORKER"?1155:n==="FULL_TOSS"?1170:n==="FULL"?1095:n==="SHORT"?925:1020;return{x10:1e3+t,y10:i}}function C2(n){const{displaySector:e,boundary:t,fieldOutcome:i,runsScored:a,variationByte:r}=n,s=((r>>3)%7-3)*.045,d=(e-3.5)*(Math.PI/4)+s,g=t==="SIX"?895:t==="FOUR"?840:i==="CATCH"?530+r%150:i==="STOP"||a===0?370+r%70:a===1?520+r%80:670+r%90,E=Math.round(1e3+Math.sin(d)*g),h=Math.round(1e3-Math.cos(d)*g);return{x10:Math.max(40,Math.min(1960,E)),y10:Math.max(40,Math.min(1960,h))}}function k2(n){if(n.dismissal)return{momentKind:"WICKET",isKeyMoment:!0};if(n.boundary==="SIX")return{momentKind:"SIX",isKeyMoment:!0};if(n.boundary==="FOUR")return{momentKind:"FOUR",isKeyMoment:!0};if(n.freeHitNext)return{momentKind:"FREE_HIT",isKeyMoment:!0};const e=n.extras.wides+n.extras.noBalls+n.extras.byes+n.extras.legByes+n.extras.penalties;return n.legality!=="LEGAL"||e>0?{momentKind:"EXTRA",isKeyMoment:!1}:n.batRuns+n.completedRuns>0?{momentKind:"RUNS",isKeyMoment:!1}:{momentKind:"DOT",isKeyMoment:!1}}function B2(n){const{events:e,names:t,hands:i}=n,a=new Map,r=[];for(const o of e){if(o.type!=="DELIVERY_RECORDED")continue;const d=o.payload?.event;if(!d||d.type!=="DELIVERY_RECORDED")continue;const g=a.get(d.inningsIndex)??0,E=d.legalBall?g+1:g;a.set(d.inningsIndex,E);const h=Math.floor((d.legalBall?E-1:g)/6),f=d.legalBall?(E-1)%6+1:g%6+1,A=d.legality==="WIDE"?`${h}.${f}wd`:d.legality==="NO_BALL"?`${h}.${f}nb`:`${h}.${f}`,N=i[d.strikerId]??"R",b=t[d.strikerId]??d.strikerId,w=t[d.bowlerId]??d.bowlerId,D=d.dismissal?t[d.dismissal.playerId]??d.dismissal.playerId:null,p=d.extras.wides+d.extras.noBalls+d.extras.byes+d.extras.legByes+d.extras.penalties,I=d.batRuns+p,{momentKind:v,isKeyMoment:y}=k2(d),S=D2(o.eventHash,o.sequence),R=y2(d.executedLength,S),U=typeof d.shotSector=="number"&&Number.isInteger(d.shotSector)&&d.shotSector>=0&&d.shotSector<=7?d.shotSector:null,H=U!==null?ic(U,N):null,en=H!==null?"RECORDED_SECTOR":"PITCH_CHANNEL_ONLY",P=H!==null?C2({displaySector:H,boundary:d.boundary,fieldOutcome:d.fieldOutcome,runsScored:I,variationByte:S}):d.dismissal&&["BOWLED","LBW","HIT_WICKET"].includes(d.dismissal.kind)?{x10:1e3,y10:1190}:{x10:1e3,y10:1330},x=d.dismissal?`WICKET · ${D} (${d.dismissal.kind.toLowerCase().replaceAll("_"," ")})`:d.boundary==="SIX"?`SIX · ${b} off ${w}`:d.boundary==="FOUR"?`FOUR · ${b} off ${w}`:d.freeHitNext?`NO-BALL (Free hit next) · ${I} run${I===1?"":"s"}`:`${A} · ${w} to ${b}: ${I} run${I===1?"":"s"}`,K=U!==null?`Recorded sector ${U+1} (${N}HB display sector ${(H??U)+1})`:"No shot sector recorded (pitch/keeper channel only)",F=d.executedLength?`${d.executedLength.toLowerCase().replaceAll("_"," ")} length`:"unrecorded length",C=d.trajectory?`, ${d.trajectory.toLowerCase()} trajectory`:"",$=`${A}: ${F}${C}. ${K}.`;r.push(Pa.parse({sequence:o.sequence,eventHash:o.eventHash,inningsIndex:d.inningsIndex,deliveryIndex:d.deliveryIndex,overBallLabel:A,strikerId:d.strikerId,strikerName:b,strikerHand:N,bowlerId:d.bowlerId,bowlerName:w,momentKind:v,isKeyMoment:y,runsScored:I,batRuns:d.batRuns,boundary:d.boundary,legality:d.legality,dismissalKind:d.dismissal?d.dismissal.kind:null,dismissedPlayerName:D,fieldOutcome:d.fieldOutcome,executedLength:d.executedLength,trajectory:d.trajectory,recordedSector:U,displaySector:H,sectorStatus:en,releasePoint:ec,pitchBouncePoint:R,strikerCreasePoint:tc,targetPoint:P,headline:x.slice(0,160),detailText:$.slice(0,280),trackingDisclaimer:Qs}))}return r.slice(-24)}function rc(n){const{format:e,phase:t,innings:i,activeIndex:a,fieldSlots:r,events:o,names:s,hands:d}=n,g=i[a]??i[i.length-1]??null,E=g?.innings??null,h=E===null?null:E.strikerEnd==="NORTH"?E.northBatterId:E.southBatterId,f=E===null?null:E.strikerEnd==="NORTH"?E.southBatterId:E.northBatterId,A=E?.bowlerId??null,N=g?.keeperId??null,b=h&&d[h]||"R",w=new Map(r.map(S=>[S.slotId,S.playerId])),D=oc(e).map(S=>{const R=w.get(S.slotId)??null;return{slotId:S.slotId,label:S.label,sector:S.sector,displaySector:ic(S.sector,b),depth:S.depth,insideCircle:S.insideCircle,legSideForStriker:b==="R"?S.legSideRhb:!S.legSideRhb,behindSquare:S.behindSquare,point:ac(S.rhbPoint,b),occupiedByPlayerId:R,occupiedByName:R?s[R]??R:null}}),p=N2({format:e,strikerHand:b,legalBalls:E?.legalBalls??0,fieldSlots:r,outfieldIds:g?.outfieldIds??r.map(S=>S.playerId)}),I=B2({events:o,names:s,hands:d}),v=I.length>0?I[I.length-1]:null,y=b==="L"?"Left-hand batter on strike: off side is on the left, leg side is on the right.":"Right-hand batter on strike: off side is on the right, leg side is on the left.";return uh.parse({version:Ls,format:e,phase:t,activeInningsIndex:Math.min(3,Math.max(0,a)),strikerId:h,strikerName:h?s[h]??h:null,strikerHand:b,nonStrikerId:f,nonStrikerName:f?s[f]??f:null,bowlerId:A,bowlerName:A?s[A]??A:null,keeperId:N,keeperName:N?s[N]??N:null,keeperPoint:O2,bowlerReleasePoint:ec,strikerPoint:tc,nonStrikerPoint:ac({x10:935,y10:755},b),boundaryRadiusX10:840,circleRadiusX10:480,positions:D,legality:p,recentHighlights:I,latestHighlight:v,orientationNote:y,trackingDisclaimer:Qs})}const P2=3,sc=["third man","point","cover","mid-off","mid-on","mid-wicket","square leg","fine leg"],x2={YORKER:"yorker",FULL:"full",GOOD:"good-length",SHORT:"short",FULL_TOSS:"full-toss"},F2={GROUND:"along the turf",AERIAL:"in the air",EDGE:"off the edge"};function oe(n){let e=2166136261;for(let t=0;t<n.length;t+=1)e^=n.charCodeAt(t),e=Math.imul(e,16777619);return e>>>0}function re(n){return(n>>>0).toString(16).padStart(8,"0")}function Tt(n){return`${Math.floor(n/6)}.${n%6}`}function H2(n){return`${Math.floor(n/6)}.${n%6+1}`}function bi(n){return`${Tt(n.legalBalls)}-${n.maidens}-${n.runsConceded}-${n.wickets}`}function M2(n){return n==="T20"?120:n==="ODI"?300:null}function Wt(n,e,t,i,a,r,o){const s=oe(`${t}|${i}|${a}|${n}`),d=re(s),g=s%e.length;let E=g,h=!1;if(e.length>1&&o>0){const A=r.slice(-o);if(A.includes(e[g].id))for(let N=1;N<e.length;N+=1){const b=(g+N)%e.length;if(!A.includes(e[b].id)){E=b,h=!0;break}}}const f=e[E];return r.push(f.id),{selected:f,cooldownApplied:h,digest:d}}function V2(n,e,t,i){if(n==="T20"||n==="ODI")return e===1&&i[0]?i[0].runs+1:null;if(e===3&&i.length>=3){let a=0,r=0;for(const s of i)s.battingTeamId===t?a+=s.runs:r+=s.runs;const o=r-a;return o>=0?o+1:null}return null}function cc(n){const e=Math.max(1,Math.min(12,n.repetitionCooldownWindow??P2)),t=n.presentationKey??`lcxxvi-commentary:${n.format}:${n.teamIds[0]}:${n.teamIds[1]}:${n.groundName??"ground"}`,i=re(oe(t)),a=[],r=N=>N?n.playerNames[N]??N:"Unknown player",o=N=>N?n.teamNames[N]??N:"Unknown team",s=N=>N===n.teamIds[0]?n.teamIds[1]:n.teamIds[0],d=new Map;let g=0;const E=(N,b)=>{const w=d.get(N);if(w)return w;const D=b??n.teamIds[N%2],p=[...d.values()].filter(v=>v.inningsIndex<N),I={inningsIndex:N,battingTeamId:D,bowlingTeamId:s(D),runs:0,wickets:0,legalBalls:0,declared:!1,targetToWin:V2(n.format,N,D,p),allocatedBalls:M2(n.format),overTeamRuns:0,overWickets:0,overLegalBalls:0,pendingFreeHit:!1,partnershipRuns:0,partnershipBalls:0,batters:new Map,bowlers:new Map};return d.set(N,I),I},h=(N,b)=>{let w=N.batters.get(b);return w||(w={runs:0,ballsFaced:0,fours:0,sixes:0},N.batters.set(b,w)),w},f=(N,b)=>{let w=N.bowlers.get(b);return w||(w={legalBalls:0,maidens:0,runsConceded:0,wickets:0,currentOverBowlerRuns:0,currentOverLegalBalls:0},N.bowlers.set(b,w)),w},A=[];for(let N=0;N<n.events.length;N+=1){const b=n.events[N],w=b.eventHash??`seq-${b.sequence}`;if(b.type==="DELIVERY_RECORDED"){const p=b.payload.event;g=p.inningsIndex;const I=E(p.inningsIndex),v=(n.format==="T20"||n.format==="ODI")&&I.pendingFreeHit,y=H2(I.legalBalls),S=r(p.bowlerId),R=r(p.strikerId),V=r(p.nonStrikerId),U=p.extras.wides+p.extras.noBalls+p.extras.byes+p.extras.legByes+p.extras.penalties,H=p.batRuns+U,en=p.batRuns+p.extras.wides+p.extras.noBalls,P=h(I,p.strikerId),x=P.runs;p.countsAsBallFaced&&(P.ballsFaced+=1),P.runs+=p.batRuns,p.boundary==="FOUR"&&(P.fours+=1),p.boundary==="SIX"&&(P.sixes+=1);const K=f(I,p.bowlerId),F=K.wickets;K.runsConceded+=en,K.currentOverBowlerRuns+=en,p.legalBall&&(K.legalBalls+=1,K.currentOverLegalBalls+=1),p.dismissal&&p.dismissal.creditedBowlerId===p.bowlerId&&(K.wickets+=1);const C=I.partnershipRuns;I.runs+=H,I.overTeamRuns+=H,p.legalBall&&(I.legalBalls+=1,I.overLegalBalls+=1),I.partnershipRuns+=H,(p.legalBall||p.legality==="NO_BALL")&&(I.partnershipBalls+=1);const $=[],q=[],G=[{slot:"inningsNumber",value:String(p.inningsIndex+1),sourceKind:"EVENT_FIELD",sourceRef:"delivery.inningsIndex"},{slot:"ballCoord",value:y,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.legalBallsBefore"},{slot:"bowlerName",value:S,sourceKind:"EVENT_FIELD",sourceRef:"delivery.bowlerId"},{slot:"strikerName",value:R,sourceKind:"EVENT_FIELD",sourceRef:"delivery.strikerId"},{slot:"teamRuns",value:`${I.runs}/${p.dismissal?I.wickets+1:I.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"}];p.batRuns>0&&(x<200&&P.runs>=200?($.push("BATTER_DOUBLE_CENTURY"),q.push(`${R} reaches a double century (${P.runs} off ${P.ballsFaced} balls).`)):x<150&&P.runs>=150?($.push("BATTER_150"),q.push(`${R} brings up 150 (${P.runs} off ${P.ballsFaced} balls).`)):x<100&&P.runs>=100?($.push("BATTER_CENTURY"),q.push(`Century for ${R} (${P.runs} off ${P.ballsFaced} balls).`)):x<50&&P.runs>=50&&($.push("BATTER_FIFTY"),q.push(`Fifty for ${R} (${P.runs} off ${P.ballsFaced} balls).`))),!p.dismissal&&H>0&&(C<150&&I.partnershipRuns>=150?($.push("PARTNERSHIP_150"),q.push(`150-run partnership (${I.partnershipRuns} off ${I.partnershipBalls} balls).`)):C<100&&I.partnershipRuns>=100?($.push("PARTNERSHIP_CENTURY"),q.push(`100-run stand (${I.partnershipRuns} off ${I.partnershipBalls} balls).`)):C<50&&I.partnershipRuns>=50&&($.push("PARTNERSHIP_FIFTY"),q.push(`50-run partnership (${I.partnershipRuns} off ${I.partnershipBalls} balls).`))),F<5&&K.wickets>=5?($.push("BOWLER_FIVE_FOR"),q.push(`Five-wicket haul for ${S} (${K.wickets}/${K.runsConceded}).`)):F<3&&K.wickets>=3&&($.push("BOWLER_THREE_FOR"),q.push(`Third wicket for ${S} (${K.wickets}/${K.runsConceded}).`));const Z={runs:I.partnershipRuns,balls:I.partnershipBalls};p.dismissal&&(I.wickets+=1,I.overWickets+=1,I.partnershipRuns=0,I.partnershipBalls=0,I.wickets===10&&($.push("ALL_OUT"),q.push(`${o(I.battingTeamId)} are all out for ${I.runs}.`))),I.targetToWin!==null&&I.runs>=I.targetToWin&&($.push("WINNING_DELIVERY"),q.push(`Winning runs! ${o(I.battingTeamId)} reach ${I.runs}/${I.wickets} to pass the target of ${I.targetToWin}.`),G.push({slot:"targetToWin",value:String(I.targetToWin),sourceKind:"CHASE_PROJECTION",sourceRef:"innings.targetToWin"}));const gn=p.shotSector!==null&&sc[p.shotSector]?sc[p.shotSector]:null,Gn=p.executedLength!==null?x2[p.executedLength]??p.executedLength.toLowerCase():null,fe=p.trajectory!==null?F2[p.trajectory]??p.trajectory.toLowerCase():null;gn&&G.push({slot:"shotSector",value:gn,sourceKind:"EVENT_FIELD",sourceRef:"delivery.shotSector"}),Gn&&G.push({slot:"executedLength",value:Gn,sourceKind:"EVENT_FIELD",sourceRef:"delivery.executedLength"}),G.push({slot:"batterScore",value:`${P.runs} (${P.ballsFaced})`,sourceKind:"BATTER_PROJECTION",sourceRef:`batter.${p.strikerId}`},{slot:"bowlerFigures",value:bi(K),sourceKind:"BOWLER_PROJECTION",sourceRef:`bowler.${p.bowlerId}`});const Ee=(n.format==="T20"||n.format==="ODI")&&(p.freeHitNext||p.legality==="NO_BALL");v&&G.push({slot:"isFreeHit",value:"true",sourceKind:"FORMAT_RULE",sourceRef:`${n.format}.freeHitDelivery`}),Ee?(I.pendingFreeHit=!0,G.push({slot:"freeHitNext",value:"FREE_HIT",sourceKind:"FORMAT_RULE",sourceRef:`${n.format}.freeHitNext`})):p.legalBall&&(I.pendingFreeHit=!1);const be=n.events[N+1]?.type==="OVER_COMPLETED";p.legalBall&&I.overLegalBalls===6&&!be&&(K.currentOverLegalBalls===6&&K.currentOverBowlerRuns===0&&(K.maidens+=1,$.push("MAIDEN_OVER"),q.push(`Maiden over completed by ${S}.`)),I.overTeamRuns=0,I.overWickets=0,I.overLegalBalls=0,K.currentOverBowlerRuns=0,K.currentOverLegalBalls=0);let Tn="DELIVERY_DOT",nn="DELIVERY",cn=String(H),rn=[];if(p.dismissal){nn="DISMISSAL";const dn=p.dismissal.playerId,hn=r(dn),on=h(I,dn),Tl=dn===p.nonStrikerId,we=p.dismissal.fielderId?r(p.dismissal.fielderId):null;if(cn=Tl?"W (run out NS)":"W",G.push({slot:"dismissedBatter",value:hn,sourceKind:"EVENT_FIELD",sourceRef:"delivery.dismissal.playerId"},{slot:"dismissalKind",value:p.dismissal.kind,sourceKind:"EVENT_FIELD",sourceRef:"delivery.dismissal.kind"},{slot:"dismissedScore",value:`${on.runs} (${on.ballsFaced})`,sourceKind:"BATTER_PROJECTION",sourceRef:`batter.${dn}`}),we&&G.push({slot:"fielderName",value:we,sourceKind:"EVENT_FIELD",sourceRef:"delivery.dismissal.fielderId"}),p.dismissal.kind==="RUN_OUT"&&Tl){Tn="WICKET_RUN_OUT_NON_STRIKER";const te=we?` by ${we}`:"",Ao=p.dismissal.wicketEnd.toLowerCase();rn=[{id:"W_RO_NS_1",render:()=>`${S} to ${R}. Non-striker ${hn} is run out${te} at the ${Ao} end for ${on.runs} (${on.ballsFaced})!`},{id:"W_RO_NS_2",render:()=>`${S} to ${R}. Mix-up in the running — non-striker ${hn} caught short${te} at the ${Ao} end, out for ${on.runs} (${on.ballsFaced}).`},{id:"W_RO_NS_3",render:()=>`${S} to ${R}. Direct trouble at the ${Ao} end: non-striker ${hn} run out${te} for ${on.runs} (${on.ballsFaced}).`}]}else if(p.dismissal.kind==="BOWLED")Tn="WICKET_BOWLED",rn=[{id:"W_BWL_1",render:()=>`${S} bowls ${hn} for ${on.runs} (${on.ballsFaced})!`},{id:"W_BWL_2",render:()=>`${S} to ${R} — through the defence, ${hn} bowled for ${on.runs} (${on.ballsFaced})!`},{id:"W_BWL_3",render:()=>`${S} hits the stumps! ${hn} departs bowled for ${on.runs} (${on.ballsFaced}).`}];else if(p.dismissal.kind==="LBW")Tn="WICKET_LBW",rn=[{id:"W_LBW_1",render:()=>`${S} traps ${hn} lbw for ${on.runs} (${on.ballsFaced})!`},{id:"W_LBW_2",render:()=>`${S} to ${R} — pinned in front, ${hn} out lbw for ${on.runs} (${on.ballsFaced}).`},{id:"W_LBW_3",render:()=>`Up goes the finger! ${S} strikes as ${hn} falls lbw for ${on.runs} (${on.ballsFaced}).`}];else if(p.dismissal.kind==="CAUGHT"){Tn="WICKET_CAUGHT";const te=we?`caught by ${we}`:"caught";rn=[{id:"W_CT_1",render:()=>`${S} to ${R} — ${hn} ${te} for ${on.runs} (${on.ballsFaced})!`},{id:"W_CT_2",render:()=>`Taken! ${S} induces the mistake and ${hn} is ${te} for ${on.runs} (${on.ballsFaced}).`},{id:"W_CT_3",render:()=>`Wicket for ${S}: ${hn} departs, ${te}, for ${on.runs} (${on.ballsFaced}).`}]}else if(p.dismissal.kind==="STUMPED"){Tn="WICKET_STUMPED";const te=we?`stumped by ${we}`:"stumped";rn=[{id:"W_ST_1",render:()=>`${S} deceives ${hn} — ${te} for ${on.runs} (${on.ballsFaced})!`},{id:"W_ST_2",render:()=>`Sharp work behind the stumps! ${hn} is ${te} off ${S} for ${on.runs} (${on.ballsFaced}).`},{id:"W_ST_3",render:()=>`${S} draws ${hn} out of the crease, ${te} for ${on.runs} (${on.ballsFaced}).`}]}else if(p.dismissal.kind==="RUN_OUT"){Tn="WICKET_RUN_OUT_STRIKER";const te=we?` (${we})`:"";rn=[{id:"W_RO_S_1",render:()=>`${S} to ${R} — ${hn} run out${te} for ${on.runs} (${on.ballsFaced})!`},{id:"W_RO_S_2",render:()=>`Quick throw${te}! ${hn} is run out for ${on.runs} (${on.ballsFaced}).`},{id:"W_RO_S_3",render:()=>`Short of the ground! ${hn} departs run out${te} for ${on.runs} (${on.ballsFaced}).`}]}else Tn="WICKET_HIT_WICKET",rn=[{id:"W_HW_1",render:()=>`${S} to ${R} — ${hn} is out hit wicket for ${on.runs} (${on.ballsFaced})!`},{id:"W_HW_2",render:()=>`Unfortunate dismissal: ${hn} disturbs the stumps, out hit wicket off ${S} for ${on.runs} (${on.ballsFaced}).`},{id:"W_HW_3",render:()=>`${hn} falls hit wicket to ${S} for ${on.runs} (${on.ballsFaced}).`}]}else if(p.legality==="WIDE")Tn="DELIVERY_WIDE",cn=`${H}wd`,G.push({slot:"wides",value:String(p.extras.wides),sourceKind:"EVENT_FIELD",sourceRef:"delivery.extras.wides"}),rn=[{id:"DLV_WD_1",render:()=>`${S} strays wide to ${R}; ${H} wide${H===1?"":"s"} added, ball to be re-bowled.`},{id:"DLV_WD_2",render:()=>`${S} misses the radar against ${R} — called wide (${H} extra${H===1?"":"s"}).`},{id:"DLV_WD_3",render:()=>`Wide signalled off ${S} to ${R}: ${H} run${H===1?"":"s"} to the total.`}];else if(p.legality==="NO_BALL"){Tn="DELIVERY_NO_BALL",cn=Ee?`${H}nb (FH)`:`${H}nb`,G.push({slot:"noBalls",value:String(p.extras.noBalls),sourceKind:"EVENT_FIELD",sourceRef:"delivery.extras.noBalls"});const dn=Ee?" Free Hit coming up next.":"",hn=p.batRuns>0?` plus ${p.batRuns} off the bat`:U>p.extras.noBalls?` plus ${U-p.extras.noBalls} extra${U-p.extras.noBalls===1?"":"s"}`:"";rn=[{id:"DLV_NB_1",render:()=>`No-ball called on ${S} to ${R} (${H} run${H===1?"":"s"}${hn}).${dn}`},{id:"DLV_NB_2",render:()=>`${S} oversteps against ${R}: no-ball costs ${H} run${H===1?"":"s"}${hn}.${dn}`},{id:"DLV_NB_3",render:()=>`Front-foot no-ball from ${S} to ${R}, ${H} added${hn}.${dn}`}]}else if(p.boundary==="SIX"){Tn="DELIVERY_SIX",cn="6";const dn=gn?` over ${gn}`:"";rn=[{id:"DLV_SIX_1",render:()=>`${S} to ${R} — launched${dn} for SIX!`},{id:"DLV_SIX_2",render:()=>`SIX! ${R} clears the rope${dn} off ${S}.`},{id:"DLV_SIX_3",render:()=>`${R} gets hold of ${S} and sends it sailing${dn} for 6.`},{id:"DLV_SIX_4",render:()=>`Maximum! Clean strike by ${R}${dn} off ${S} for six runs.`}]}else if(p.boundary==="FOUR"){Tn="DELIVERY_FOUR",cn="4";const dn=gn?` through ${gn}`:"";rn=[{id:"DLV_FOUR_1",render:()=>`${S} to ${R} — crisp stroke${dn} for FOUR!`},{id:"DLV_FOUR_2",render:()=>`FOUR! ${R} pierces the gap${dn} off ${S}.`},{id:"DLV_FOUR_3",render:()=>`${R} leans on ${S} and races it away${dn} to the boundary for 4.`},{id:"DLV_FOUR_4",render:()=>`Boundary for ${R}! Timed neatly${dn} off ${S}.`}]}else if(H===0){Tn="DELIVERY_DOT",cn="0";const dn=p.fieldOutcome==="STOP"?gn?`, tidy stop at ${gn}`:", tidy stop in the ring":"";rn=[{id:"DLV_DOT_1",render:()=>`${S} to ${R}, defended solidly — no run${dn}.`},{id:"DLV_DOT_2",render:()=>`Dot ball from ${S}; ${R} watchful at the crease${dn}.`},{id:"DLV_DOT_3",render:()=>`${S} hits the spot to ${R}, no scoring opportunity${dn}.`},{id:"DLV_DOT_4",render:()=>`${R} plays ${S} back safely — dot ball${dn}.`}]}else if(p.batRuns===0&&(p.extras.byes>0||p.extras.legByes>0)){Tn="DELIVERY_BYES_LEGBYES";const dn=p.extras.legByes>0?"lb":"b",hn=p.extras.legByes>0?"leg-bye":"bye";cn=`${H}${dn}`,rn=[{id:"DLV_BLB_1",render:()=>`${S} to ${R}: ${H} ${hn}${H===1?"":"s"} scampered through.`},{id:"DLV_BLB_2",render:()=>`Past the bat off ${S}; ${R} and ${V} cross for ${H} ${hn}${H===1?"":"s"}.`},{id:"DLV_BLB_3",render:()=>`${H} ${hn}${H===1?"":"s"} signalled as ${S} goes past ${R}.`}]}else if(H===1){Tn="DELIVERY_SINGLE",cn="1";const dn=gn?` toward ${gn}`:"";rn=[{id:"DLV_ONE_1",render:()=>`${S} to ${R}, worked${dn} for a single.`},{id:"DLV_ONE_2",render:()=>`${R} nudges ${S}${dn} to rotate the strike — 1 run.`},{id:"DLV_ONE_3",render:()=>`Quick single taken by ${R}${dn} off ${S}.`},{id:"DLV_ONE_4",render:()=>`${R} taps ${S}${dn} and crosses cleanly for 1.`}]}else{Tn="DELIVERY_MULTI_RUN",cn=String(H);const dn=gn?` into ${gn}`:"";rn=[{id:"DLV_MULTI_1",render:()=>`${S} to ${R}, placed${dn} and they come back for ${H} runs.`},{id:"DLV_MULTI_2",render:()=>`Good running between ${R} and ${V}${dn} off ${S} — ${H} runs.`},{id:"DLV_MULTI_3",render:()=>`${R} works ${S}${dn} in the gap for ${H} runs.`}]}$.length>0&&nn==="DELIVERY"&&(nn="MILESTONE");const Q=Wt(Tn,rn,t,b.sequence,w,a,e),En=!p.dismissal&&p.fieldOutcome==="DROP"?" Dropped chance in the field!":!p.dismissal&&p.fieldOutcome==="MISS"?" Misfield concedes extra ground.":"",wn=q.length>0?` ${q.join(" ")}`:"",Yi=`Innings ${p.inningsIndex+1}, ${y}: ${Q.selected.render()}${En}${wn}`,Qe=[];v&&Qe.push("free-hit delivery"),Gn&&Qe.push(`${Gn} length`),fe&&Qe.push(fe),gn&&Qe.push(`sector: ${gn}`);const u3=Qe.length>0?` [${Qe.join(", ")}]`:"",m3=p.dismissal?`Stand ended on ${Z.runs} (${Z.balls}b)`:`Stand ${I.partnershipRuns} (${I.partnershipBalls}b)`,g3=I.targetToWin!==null&&I.runs<I.targetToWin?I.allocatedBalls!==null?` · Need ${I.targetToWin-I.runs} off ${Math.max(0,I.allocatedBalls-I.legalBalls)}b`:` · Need ${I.targetToWin-I.runs} more to win`:"",p3=`${Yi}${u3} — Score ${I.runs}/${I.wickets}; ${R} ${P.runs} (${P.ballsFaced}), ${S} ${bi(K)}, ${m3}${g3}.`;A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:nn,templateId:Q.selected.id,templateFamily:Tn,cooldownApplied:Q.cooldownApplied,presentationDigest:Q.digest,milestoneTags:$,short:`${y} · ${cn}`,text:Yi,detailed:p3,factSlots:G});continue}if(b.type==="OVER_COMPLETED"){const p=b.payload,I=E(g),v=Math.floor(I.legalBalls/6),y=r(p.bowlerId),S=f(I,p.bowlerId),R=S.currentOverLegalBalls===6&&S.currentOverBowlerRuns===0;R&&(S.maidens+=1);const V=I.overTeamRuns,U=I.overWickets;I.overTeamRuns=0,I.overWickets=0,I.overLegalBalls=0,S.currentOverBowlerRuns=0,S.currentOverLegalBalls=0;const H=R?["MAIDEN_OVER"]:[],en=o(I.battingTeamId),P=bi(S),x=I.targetToWin!==null&&I.runs<I.targetToWin?I.allocatedBalls!==null?` (${I.targetToWin-I.runs} needed from ${Math.max(0,I.allocatedBalls-I.legalBalls)} balls)`:` (${I.targetToWin-I.runs} needed to win)`:"",K=R?"OVER_MAIDEN":"OVER_SUMMARY",C=Wt(K,R?[{id:"OV_MDN_1",render:()=>`End of over ${v} (maiden from ${y}): ${en} ${I.runs}/${I.wickets}${x}.`},{id:"OV_MDN_2",render:()=>`Maiden over! ${y} closes over ${v} without conceding off the bat or bowling extras — ${en} ${I.runs}/${I.wickets}${x}.`},{id:"OV_MDN_3",render:()=>`Over ${v} complete, a probing maiden by ${y}. ${en} stand at ${I.runs}/${I.wickets}${x}.`}]:[{id:"OV_SUM_1",render:()=>`End of over ${v} (${V} run${V===1?"":"s"}${U>0?`, ${U} wkt${U===1?"":"s"}`:""}): ${en} ${I.runs}/${I.wickets}${x}.`},{id:"OV_SUM_2",render:()=>`Over ${v} complete — ${V} off it${U>0?` and ${U} wicket${U===1?"":"s"}`:""}. ${en} are ${I.runs}/${I.wickets}${x}.`},{id:"OV_SUM_3",render:()=>`After ${v} over${v===1?"":"s"}, ${en} move to ${I.runs}/${I.wickets} (${V} from ${y}'s over)${x}.`}],t,b.sequence,w,a,e),$=C.selected.render();A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"OVER",templateId:C.selected.id,templateFamily:K,cooldownApplied:C.cooldownApplied,presentationDigest:C.digest,milestoneTags:H,short:`Ov ${v}: ${I.runs}/${I.wickets}${R?" (M)":""}`,text:$,detailed:`${$} ${y} figures: ${P}; current stand ${I.partnershipRuns} (${I.partnershipBalls}b).`,factSlots:[{slot:"overNumber",value:String(v),sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.completedOvers"},{slot:"overRuns",value:String(V),sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.overTeamRuns"},{slot:"inningsScore",value:`${I.runs}/${I.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"},{slot:"bowlerFigures",value:P,sourceKind:"BOWLER_PROJECTION",sourceRef:`bowler.${p.bowlerId}`}]});continue}if(b.type==="INNINGS_STARTED"){const p=b.payload;g=p.inningsIndex;const I=E(p.inningsIndex,p.battingTeamId),v=o(I.battingTeamId),y=I.targetToWin!==null?I.allocatedBalls!==null?` chasing ${I.targetToWin} from ${Math.floor(I.allocatedBalls/6)} overs`:` requiring ${I.targetToWin} to win`:"",S=Wt("INNINGS_STARTED",[{id:"INN_START_1",render:()=>`Start of innings ${p.inningsIndex+1}: ${v} begin batting${y}.`},{id:"INN_START_2",render:()=>`Opening innings ${p.inningsIndex+1} — ${v} take the crease${y}.`}],t,b.sequence,w,a,e),R=S.selected.render(),V=[{slot:"inningsNumber",value:String(p.inningsIndex+1),sourceKind:"EVENT_FIELD",sourceRef:"event.inningsIndex"},{slot:"battingTeam",value:v,sourceKind:"EVENT_FIELD",sourceRef:"event.battingTeamId"}];I.targetToWin!==null&&V.push({slot:"targetToWin",value:String(I.targetToWin),sourceKind:"CHASE_PROJECTION",sourceRef:"innings.targetToWin"}),A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"INNINGS",templateId:S.selected.id,templateFamily:"INNINGS_STARTED",cooldownApplied:S.cooldownApplied,presentationDigest:S.digest,milestoneTags:[],short:`Inn ${p.inningsIndex+1}: ${v}`,text:R,detailed:`${R} Format: ${n.format}.`,factSlots:V});continue}if(b.type==="INNINGS_COMPLETED"){const p=b.payload,I=E(p.inningsIndex),v=o(I.battingTeamId),y=Tt(I.legalBalls),S=I.wickets>=10,R=S?`End of innings ${p.inningsIndex+1}: ${v} all out for ${I.runs} in ${y} overs.`:`End of innings ${p.inningsIndex+1}: ${v} close on ${I.runs}/${I.wickets} (${y} overs).`;A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"INNINGS",templateId:S?"INN_END_ALL_OUT":"INN_END_CLOSED",templateFamily:"INNINGS_COMPLETED",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|INN_END`)),milestoneTags:S?["ALL_OUT"]:[],short:`End Inn ${p.inningsIndex+1}: ${I.runs}/${I.wickets}`,text:R,detailed:`${R} Legal deliveries: ${I.legalBalls}.`,factSlots:[{slot:"inningsNumber",value:String(p.inningsIndex+1),sourceKind:"EVENT_FIELD",sourceRef:"event.inningsIndex"},{slot:"inningsTotal",value:`${I.runs}/${I.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"},{slot:"overs",value:y,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.legalBalls"}]});continue}if(b.type==="MATCH_COMPLETED"){const p=b.payload.result;let I="Match complete",v="Match completed.";const y=[];if(p)if(y.push({slot:"resultKind",value:p.kind,sourceKind:"MATCH_RESULT",sourceRef:"result.kind"}),p.kind==="WIN"){const R=o(p.winnerTeamId);y.push({slot:"winnerTeam",value:R,sourceKind:"MATCH_RESULT",sourceRef:"result.winnerTeamId"}),p.marginType==="RUNS"?(I=`${R} won by ${p.marginRuns} runs`,v=`Result: ${R} win by ${p.marginRuns} run${p.marginRuns===1?"":"s"}.`,y.push({slot:"marginRuns",value:String(p.marginRuns),sourceKind:"MATCH_RESULT",sourceRef:"result.marginRuns"})):p.marginType==="WICKETS"?(I=`${R} won by ${p.marginWickets} wkts`,v=`Result: ${R} win by ${p.marginWickets} wicket${p.marginWickets===1?"":"s"}.`,y.push({slot:"marginWickets",value:String(p.marginWickets),sourceKind:"MATCH_RESULT",sourceRef:"result.marginWickets"})):(I=`${R} won by innings & ${p.marginRuns}`,v=`Result: ${R} win by an innings and ${p.marginRuns} run${p.marginRuns===1?"":"s"}.`,y.push({slot:"marginRuns",value:String(p.marginRuns),sourceKind:"MATCH_RESULT",sourceRef:"result.marginRuns"}))}else p.kind==="TIE"?(I="Match tied",v=`Result: Match tied (${p.completionReason}).`):p.kind==="DRAW"?(I="Match drawn",v=`Result: Match drawn (${p.completionReason}).`):(I="No result",v=`Result: No result (${p.completionReason}).`);else y.push({slot:"eventType",value:b.type,sourceKind:"EVENT_FIELD",sourceRef:"event.type"});const S=[...d.values()].sort((R,V)=>R.inningsIndex-V.inningsIndex).map(R=>`${o(R.battingTeamId)} ${R.runs}/${R.wickets}${R.declared?"d":""} (${Tt(R.legalBalls)} ov)`).join("; ");A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"RESULT",templateId:`RESULT_${p?.kind??"COMPLETE"}`,templateFamily:"MATCH_COMPLETED",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|RESULT`)),milestoneTags:[],short:I,text:v,detailed:S?`${v} Final scores: ${S}.`:v,factSlots:y});continue}if(b.type==="TOSS_RESOLVED"){const p=b.payload,I=o(p.winnerId),v=p.coin.toLowerCase(),y=`Toss: ${v}. ${I} won the toss.`;A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"SELECTION",templateId:"TOSS_RESOLVED_1",templateFamily:"TOSS_RESOLVED",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|TOSS`)),milestoneTags:[],short:`Toss: ${I} (${v})`,text:y,detailed:p.callerId&&p.call?`${y} (${o(p.callerId)} called ${p.call.toLowerCase()}).`:y,factSlots:[{slot:"coin",value:v,sourceKind:"EVENT_FIELD",sourceRef:"event.coin"},{slot:"winnerTeam",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.winnerId"}]});continue}if(b.type==="BATTER_SELECTED"){const p=b.payload.playerId,I=r(p),v=E(g),y=Wt("BATTER_SELECTED",[{id:"BAT_SEL_1",render:()=>`${I} comes in to bat.`},{id:"BAT_SEL_2",render:()=>`${I} walks to the crease.`}],t,b.sequence,w,a,e),S=y.selected.render();A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"SELECTION",templateId:y.selected.id,templateFamily:"BATTER_SELECTED",cooldownApplied:y.cooldownApplied,presentationDigest:y.digest,milestoneTags:[],short:`In: ${I}`,text:S,detailed:`${S} (${o(v.battingTeamId)} ${v.runs}/${v.wickets}).`,factSlots:[{slot:"batterName",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.playerId"}]});continue}if(b.type==="BOWLER_SELECTED"){const p=b.payload.playerId,I=r(p),v=E(g),y=bi(f(v,p)),S=Wt("BOWLER_SELECTED",[{id:"BWL_SEL_1",render:()=>`${I} will bowl.`},{id:"BWL_SEL_2",render:()=>`${I} comes into the attack.`}],t,b.sequence,w,a,e),R=S.selected.render();A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"SELECTION",templateId:S.selected.id,templateFamily:"BOWLER_SELECTED",cooldownApplied:S.cooldownApplied,presentationDigest:S.digest,milestoneTags:[],short:`Bowl: ${I}`,text:R,detailed:`${R} Current figures: ${y}.`,factSlots:[{slot:"bowlerName",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.playerId"},{slot:"bowlerFigures",value:y,sourceKind:"BOWLER_PROJECTION",sourceRef:`bowler.${p}`}]});continue}if(b.type==="RAIN_DELAY"){const p=b.payload.seconds,I=Math.round(p/60),v=`Weather delay: ${I} minute${I===1?"":"s"} lost to rain.`;A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"CONDITIONS",templateId:"RAIN_DELAY_1",templateFamily:"RAIN_DELAY",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|RAIN`)),milestoneTags:[],short:`Rain (${I}m)`,text:v,detailed:`${v} (${p} seconds deducted from playing time).`,factSlots:[{slot:"lostMinutes",value:`${I} minute${I===1?"":"s"}`,sourceKind:"EVENT_FIELD",sourceRef:"event.seconds"}]});continue}if(b.type==="DECLARED"){const p=b.payload.teamId,I=o(p),v=E(g);v.declared=!0;const y=`${I} declared the innings at ${v.runs}/${v.wickets}.`;A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"TACTICAL",templateId:"DECLARED_1",templateFamily:"DECLARED",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|DECL`)),milestoneTags:[],short:`Declared (${v.runs}/${v.wickets}d)`,text:y,detailed:`${y} (${Tt(v.legalBalls)} overs bowled).`,factSlots:[{slot:"declaringTeam",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.teamId"},{slot:"declaredTotal",value:`${v.runs}/${v.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"}]});continue}if(b.type==="FOLLOW_ON_CHOSEN"){const p=!!b.payload.enforce,I=p?"Follow-on enforced.":"Follow-on declined.";A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"TACTICAL",templateId:p?"FOLLOW_ON_ENFORCED":"FOLLOW_ON_DECLINED",templateFamily:"FOLLOW_ON_CHOSEN",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|FO`)),milestoneTags:[],short:I,text:I,detailed:p?`${I} The trailing side will bat again immediately.`:`${I} The leading side elects to bat again.`,factSlots:[{slot:"followOnEnforced",value:String(p),sourceKind:"EVENT_FIELD",sourceRef:"event.enforce"}]});continue}if(b.type==="NEW_BALL_TAKEN"){const p=E(g),I="New ball taken.";A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"TACTICAL",templateId:"NEW_BALL_TAKEN_1",templateFamily:"NEW_BALL_TAKEN",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|NB`)),milestoneTags:[],short:"New ball",text:I,detailed:`${I} Taken after ${Tt(p.legalBalls)} overs with the score at ${p.runs}/${p.wickets}.`,factSlots:[{slot:"oversAtNewBall",value:Tt(p.legalBalls),sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.legalBalls"}]});continue}if(b.type==="BATTING_PLAN_CHANGED"){const p=b.payload,I=r(p.playerId),v=`Batting plan updated for ${I}: aggression ${p.aggression}, ${p.intent.toLowerCase()} intent.`;A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"TACTICAL",templateId:"BAT_PLAN_1",templateFamily:"BATTING_PLAN_CHANGED",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|BATP`)),milestoneTags:[],short:`Bat plan: ${I}`,text:v,detailed:v,factSlots:[{slot:"batterName",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.playerId"},{slot:"aggression",value:String(p.aggression),sourceKind:"EVENT_FIELD",sourceRef:"event.aggression"}]});continue}if(b.type==="BOWLING_PLAN_CHANGED"){const p=b.payload,I=r(p.bowlerId),v=`Bowling plan for ${I}: ${p.line.toLowerCase()} line, ${p.length.toLowerCase().replaceAll("_"," ")} length (${p.effort.toLowerCase()} effort).`;A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"TACTICAL",templateId:"BWL_PLAN_1",templateFamily:"BOWLING_PLAN_CHANGED",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|BWLP`)),milestoneTags:[],short:`Bowl plan: ${I}`,text:v,detailed:v,factSlots:[{slot:"bowlerName",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.bowlerId"},{slot:"line",value:p.line.toLowerCase(),sourceKind:"EVENT_FIELD",sourceRef:"event.line"},{slot:"length",value:p.length.toLowerCase(),sourceKind:"EVENT_FIELD",sourceRef:"event.length"}]});continue}if(b.type==="FIELD_CHANGED"){const p=b.payload.fieldSlots,I="Field placement adjusted.",v=p.slice(0,4).map(y=>y.slotId.toLowerCase().replaceAll("_"," ")).join(", ");A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"TACTICAL",templateId:"FIELD_CHANGED_1",templateFamily:"FIELD_CHANGED",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|FLD`)),milestoneTags:[],short:"Field adjusted",text:I,detailed:v?`${I} Key ring/slip posts include ${v}.`:I,factSlots:[{slot:"slotCount",value:String(p.length),sourceKind:"EVENT_FIELD",sourceRef:"event.fieldSlots"}]});continue}if(b.type==="TEAMS_CONFIRMED"){const p=o(n.teamIds[0]),I=o(n.teamIds[1]),v=`Teams confirmed: ${p} vs ${I}.`;A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"SELECTION",templateId:"TEAMS_CONFIRMED_1",templateFamily:"TEAMS_CONFIRMED",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|TC`)),milestoneTags:[],short:`${p} v ${I}`,text:v,detailed:n.groundName?`${v} Venue: ${n.groundName} (${n.format}).`:`${v} Format: ${n.format}.`,factSlots:[{slot:"homeTeam",value:p,sourceKind:"INNINGS_PROJECTION",sourceRef:"match.teamIds[0]"},{slot:"awayTeam",value:I,sourceKind:"INNINGS_PROJECTION",sourceRef:"match.teamIds[1]"}]});continue}const D=b.type.replaceAll("_"," ").toLowerCase();A.push({adapterVersion:xn,sequence:b.sequence,eventType:b.type,category:"SELECTION",templateId:"EVENT_GENERIC_FALLBACK",templateFamily:"EVENT_GENERIC",cooldownApplied:!1,presentationDigest:re(oe(`${t}|${b.sequence}|${w}|GEN`)),milestoneTags:[],short:D,text:D,detailed:D,factSlots:[{slot:"eventType",value:b.type,sourceKind:"EVENT_FIELD",sourceRef:"event.type"}]})}return{adapterVersion:xn,format:n.format,presentationKeyDigest:i,repetitionCooldownWindow:e,entries:A}}const W2=4500,$2=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]);function ve(n,e){return n>>>e|n<<32-e}function U2(n){const e=new TextEncoder().encode(n),t=e.length*8,i=Math.ceil((e.length+9)/64)*64,a=new Uint8Array(i);a.set(e),a[e.length]=128;const r=new DataView(a.buffer);r.setUint32(i-8,Math.floor(t/4294967296),!1),r.setUint32(i-4,t>>>0,!1);const o=new Uint32Array([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),s=new Uint32Array(64);for(let d=0;d<i;d+=64){for(let D=0;D<16;D+=1)s[D]=r.getUint32(d+D*4,!1);for(let D=16;D<64;D+=1){const p=ve(s[D-15],7)^ve(s[D-15],18)^s[D-15]>>>3,I=ve(s[D-2],17)^ve(s[D-2],19)^s[D-2]>>>10;s[D]=s[D-16]+p+s[D-7]+I>>>0}let g=o[0],E=o[1],h=o[2],f=o[3],A=o[4],N=o[5],b=o[6],w=o[7];for(let D=0;D<64;D+=1){const p=ve(A,6)^ve(A,11)^ve(A,25),I=A&N^~A&b,v=w+p+I+$2[D]+s[D]>>>0,y=ve(g,2)^ve(g,13)^ve(g,22),S=g&E^g&h^E&h,R=y+S>>>0;w=b,b=N,N=A,A=f+v>>>0,f=h,h=E,E=g,g=v+R>>>0}o[0]=o[0]+g>>>0,o[1]=o[1]+E>>>0,o[2]=o[2]+h>>>0,o[3]=o[3]+f>>>0,o[4]=o[4]+A>>>0,o[5]=o[5]+N>>>0,o[6]=o[6]+b>>>0,o[7]=o[7]+w>>>0}return Array.from(o).map(d=>d.toString(16).padStart(8,"0")).join("")}const G2=[{assetId:"lc-sfx-bat-dot-v1",cueKind:"BAT_BALL_DOT",channel:"EFFECTS",title:"Willow tap — defensive dot",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"triangle-210Hz->120Hz-bandpass-65ms",durationMs:75},{assetId:"lc-sfx-bat-single-v1",cueKind:"BAT_BALL_SINGLE",channel:"EFFECTS",title:"Crisp bat knock — rotated single/runs",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"triangle-340Hz->165Hz-click-95ms",durationMs:105},{assetId:"lc-crowd-boundary-four-v1",cueKind:"BOUNDARY_FOUR",channel:"CROWD",title:"Sweet-spot drive + boundary applause swell",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"harmonic-knock-440Hz+bandpass-applause-680ms",durationMs:720},{assetId:"lc-crowd-boundary-six-v1",cueKind:"BOUNDARY_SIX",channel:"CROWD",title:"Lofted strike + full stadium roar",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"harmonic-strike-520Hz+warm-crowd-swell-960ms",durationMs:980},{assetId:"lc-sfx-wicket-fall-v1",cueKind:"WICKET_FALL",channel:"EFFECTS",title:"Timber rattle + crowd gasp",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"dual-stump-resonance-610Hz-390Hz+crowd-hush-820ms",durationMs:840},{assetId:"lc-sfx-milestone-chime-v1",cueKind:"MILESTONE_CHIME",channel:"CROWD",title:"Milestone applause & fifth-chord chime",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"sine-triad-523Hz-659Hz-784Hz+soft-applause-640ms",durationMs:680},{assetId:"lc-sfx-over-bell-v1",cueKind:"OVER_BELL",channel:"EFFECTS",title:"End-of-over brass chime",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"sine-bell-660Hz-880Hz-240ms",durationMs:260},{assetId:"lc-sfx-innings-change-v1",cueKind:"INNINGS_CHANGE",channel:"CROWD",title:"Innings interval pavilion chime",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"warm-chord-392Hz-494Hz-587Hz-540ms",durationMs:560},{assetId:"lc-crowd-match-complete-v1",cueKind:"MATCH_COMPLETE",channel:"CROWD",title:"Full-time pavilion fanfare & crowd ovation",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"major-fanfare-523Hz-659Hz-784Hz-1046Hz+ovation-1100ms",durationMs:1150},{assetId:"lc-ui-click-v1",cueKind:"UI_CLICK",channel:"INTERFACE",title:"Subtle tactile slate click",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"sine-tick-740Hz->420Hz-35ms",durationMs:40}].map(n=>({...n,sha256:U2(JSON.stringify({assetId:n.assetId,cueKind:n.cueKind,channel:n.channel,license:n.license,origin:n.origin,synthesisProfile:n.synthesisProfile,durationMs:n.durationMs}))})),z2={manifestVersion:ws,attributionNotice:"All audio cues are synthesized offline in-repo from original mathematical waveforms and noise envelopes owned by Lord Cricket XXVI (MIT). No third-party commercial sound recordings, voices, or network audio streams are used.",networkCallsAllowed:!1,assets:[...G2]};function Y2(n,e=z2){return e.assets.find(t=>t.cueKind===n)??null}function Ya(n,e){return n.factSlots.find(t=>t.slot===e)?.value}function K2(n){if(n.category==="RESULT")return{cueKind:"MATCH_COMPLETE",channel:"CROWD",priority:95,caption:`Match complete: ${n.short}`,narrationText:n.text};if(n.category==="INNINGS")return{cueKind:"INNINGS_CHANGE",channel:"CROWD",priority:75,caption:`Innings update: ${n.short}`,narrationText:n.text};if(n.category==="DISMISSAL")return{cueKind:"WICKET_FALL",channel:"EFFECTS",priority:92,caption:`Wicket! ${n.short}`,narrationText:n.text};if(n.milestoneTags.some(e=>["BATTER_FIFTY","BATTER_CENTURY","BATTER_150","BATTER_DOUBLE_CENTURY","PARTNERSHIP_FIFTY","PARTNERSHIP_CENTURY","PARTNERSHIP_150","BOWLER_THREE_FOR","BOWLER_FIVE_FOR"].includes(e))){const e=Ya(n,"boundary"),t=n.milestoneTags.join(", ").replace(/_/g," ").toLowerCase();return{cueKind:"MILESTONE_CHIME",channel:"CROWD",priority:e==="6"?88:82,caption:`Milestone (${t}): ${n.short}`,narrationText:n.text}}if(n.category==="OVER")return{cueKind:"OVER_BELL",channel:"EFFECTS",priority:55,caption:`Over complete: ${n.short}`,narrationText:n.short};if(n.category==="DELIVERY"){const e=Ya(n,"boundary"),t=Number(Ya(n,"runs")??"0");return e==="6"?{cueKind:"BOUNDARY_SIX",channel:"CROWD",priority:86,caption:`SIX! ${n.short}`,narrationText:n.text}:e==="4"?{cueKind:"BOUNDARY_FOUR",channel:"CROWD",priority:80,caption:`FOUR! ${n.short}`,narrationText:n.text}:t>0?{cueKind:"BAT_BALL_SINGLE",channel:"EFFECTS",priority:35,caption:n.short}:{cueKind:"BAT_BALL_DOT",channel:"EFFECTS",priority:20,caption:n.short}}return null}function lc(n){const e=n.maxCues??48,t=[...n.commentaryEntries].sort((r,o)=>r.sequence-o.sequence),i=e>0?t.slice(-e):t,a=[];for(const r of i){const o=K2(r);if(!o)continue;const s=Y2(o.cueKind);s&&a.push({cueId:`${n.matchId}:${r.sequence}:${o.cueKind}`,sequence:r.sequence,channel:o.channel,cueKind:o.cueKind,assetId:s.assetId,priority:o.priority,caption:o.caption.slice(0,280),...o.narrationText?{narrationText:o.narrationText.slice(0,360)}:{},ttlMs:W2})}return{adapterVersion:xa,matchId:n.matchId,format:n.format,cues:a}}const dc="Transparent Game Award: batting (runs, boundaries, milestones, not-out, format-par strike rate) + bowling (24 pts/wkt, 3w/5w hauls, maidens, format-par economy) + attributable fielding (catches 7, stumpings 9, run-outs 11) + modest winning-team bonus (5 pts; standout losing performances can still win).",j2={T20:13e3,ODI:9200,RED_BALL:5500},q2={T20:750,ODI:520,RED_BALL:320},Z2={T20:12,ODI:24,RED_BALL:30};function uc(n,e,t){return Math.max(e,Math.min(t,Math.round(n)))}function X2(n,e){if(!n)return{byPlayer:new Map,evaluated:!1};const t=new Map;for(const i of n){if(i.type!=="DELIVERY_RECORDED")continue;const r=i.payload?.event,o=r?.dismissal;if(!o||!o.fielderId)continue;const s=o.fielderId,d=e[s]??r?.bowlingTeamId??"unknown",g=t.get(s)??{teamId:d,catches:0,stumpings:0,runOuts:0};o.kind==="CAUGHT"?g.catches+=1:o.kind==="STUMPED"?g.stumpings+=1:o.kind==="RUN_OUT"&&(g.runOuts+=1),t.set(s,g)}return{byPlayer:t,evaluated:!0}}function J2(n){return{byPlayer:new Map(n.map(e=>[e.playerId,{teamId:e.teamId,catches:e.catches,stumpings:e.stumpings,runOuts:e.runOuts}])),evaluated:!0}}function Q2(n,e){if(!n.batted)return 0;let t=n.runs*100;if(n.runs>=150?t+=5e3:n.runs>=100?t+=3500:n.runs>=50?t+=1500:n.runs>=30&&(t+=500),n.notOutWithRuns&&n.runs>=20&&(t+=400),t+=n.sixes*150+n.fours*50,n.ballsFaced>=10&&n.runs>=15){const i=Math.round(n.runs*1e4/n.ballsFaced),a=j2[e];t+=uc((i-a)*Math.min(40,n.ballsFaced)/250,-600,1400)}return t}function n1(n,e){if(!n.bowled)return 0;let t=n.wickets*2400;if(n.wickets>=5?t+=3e3:n.wickets>=3&&(t+=1200),t+=n.maidens*500,n.legalBalls>=Z2[e]){const i=Math.round(n.runsConceded*600/n.legalBalls),a=q2[e],r=n.legalBalls/6;t+=uc((a-i)*Math.min(8,r)/4,-900,1600)}return t}function e1(n){return n.catches*700+n.stumpings*900+n.runOuts*1100}function t1(n){const e=[];if(n.batted&&e.push(`${n.runs}${n.notOutWithRuns?"*":""} (${n.ballsFaced})`),n.bowled&&e.push(`${n.wickets}/${n.runsConceded} (${Math.floor(n.legalBalls/6)}.${n.legalBalls%6})`),n.catches+n.stumpings+n.runOuts>0){const i=[];n.catches>0&&i.push(`${n.catches}c`),n.stumpings>0&&i.push(`${n.stumpings}st`),n.runOuts>0&&i.push(`${n.runOuts}ro`),e.push(i.join(" "))}return e.length>0?e.join(" · "):"Selected XI"}function i1(n){const{format:e,scorecard:t}=n,i=n.fixtureId??null,a=n.seasonNumber??null,r=n.sourceCompletionSha256??null,o=n.events??n.archive?.events,s={...n.participantTeamByPlayerId??{}},d=new Map,g=(S,R)=>{let V=d.get(S);return V||(V={playerId:S,teamId:R,runs:0,ballsFaced:0,fours:0,sixes:0,batted:!1,notOutWithRuns:!1,wickets:0,runsConceded:0,legalBalls:0,maidens:0,bowled:!1,catches:0,stumpings:0,runOuts:0},d.set(S,V)),s[S]=V.teamId,V};for(const S of t.innings){for(const[R,V]of Object.entries(S.batting)){const U=g(R,S.battingTeamId);(V.ballsFaced>0||V.dismissed||V.runs>0)&&(U.batted=!0,U.runs+=V.runs,U.ballsFaced+=V.ballsFaced,U.fours+=V.fours,U.sixes+=V.sixes,!V.dismissed&&V.runs>0&&(U.notOutWithRuns=!0))}for(const[R,V]of Object.entries(S.bowling)){const U=g(R,S.bowlingTeamId);(V.legalBalls>0||V.runsConceded>0||V.wickets>0)&&(U.bowled=!0,U.wickets+=V.wickets,U.runsConceded+=V.runsConceded,U.legalBalls+=V.legalBalls,U.maidens+=V.maidens)}}const E=!o&&n.fieldingDigest?J2(n.fieldingDigest):X2(o,s);for(const[S,R]of E.byPlayer.entries()){const V=g(S,R.teamId);V.catches+=R.catches,V.stumpings+=R.stumpings,V.runOuts+=R.runOuts}const h=E.evaluated?"ARCHIVE_EVENTS":"SCORECARD_NOT_ATTRIBUTABLE";if(t.result.kind==="NO_RESULT"||d.size===0)return{record:Fa.parse({awardVersion:Mt,awardCategory:"PLAYER_OF_THE_MATCH",awardProvenance:"GAME_AWARD",format:e,matchId:t.matchId,fixtureId:i,seasonNumber:a,sourceCompletionSha256:r,status:"NO_RESULT_NOT_AWARDED",winnerPlayerId:null,winnerTeamId:null,fromWinningTeam:null,fromLosingTeam:!1,scoreTotalX100:null,components:null,fieldingSourceStatus:h,explanationText:"No Player of the Match awarded because the fixture finished as a no-result without a completed competitive outcome.",formulaSummary:dc,candidates:[]}),allCandidates:[]};const f=t.result.kind==="WIN"?t.result.winnerTeamId:null,A=t.result.kind==="WIN"&&f!==null,N=[...d.values()].map(S=>{const R=Q2(S,e),V=n1(S,e),U=e1(S),H=f!==null&&S.teamId===f,en=H?500:0,P=R+V+U+en;return{playerId:S.playerId,teamId:S.teamId,battingPointsX100:R,bowlingPointsX100:V,fieldingPointsX100:U,resultBonusX100:en,totalPointsX100:P,fromWinningTeam:H,summaryLine:t1(S)}}).sort((S,R)=>{if(R.totalPointsX100!==S.totalPointsX100)return R.totalPointsX100-S.totalPointsX100;const V=S.battingPointsX100+S.bowlingPointsX100+S.fieldingPointsX100,U=R.battingPointsX100+R.bowlingPointsX100+R.fieldingPointsX100;return U!==V?U-V:S.fromWinningTeam!==R.fromWinningTeam?S.fromWinningTeam?-1:1:Or(S.playerId,R.playerId)}),b=N[0],w=A&&b.teamId!==f,D=n.playerNames?.[b.playerId]??b.playerId,p=n.teamNames?.[b.teamId]??b.teamId,I=w?" (standout performance from the losing side)":"",v=h==="SCORECARD_NOT_ATTRIBUTABLE"?" Attributable fielding points unavailable because delivery event archive was not attached.":"";return{record:Fa.parse({awardVersion:Mt,awardCategory:"PLAYER_OF_THE_MATCH",awardProvenance:"GAME_AWARD",format:e,matchId:t.matchId,fixtureId:i,seasonNumber:a,sourceCompletionSha256:r,status:"AWARDED",winnerPlayerId:b.playerId,winnerTeamId:b.teamId,fromWinningTeam:A?b.fromWinningTeam:null,fromLosingTeam:w,scoreTotalX100:b.totalPointsX100,components:{battingPointsX100:b.battingPointsX100,bowlingPointsX100:b.bowlingPointsX100,fieldingPointsX100:b.fieldingPointsX100,resultBonusX100:b.resultBonusX100},fieldingSourceStatus:h,explanationText:`${D} (${p}${I}) awarded Player of the Match with ${(b.totalPointsX100/100).toFixed(2)} pts — ${b.summaryLine}.${v}`,formulaSummary:dc,candidates:N.slice(0,5)}),allCandidates:N}}function mc(n){return i1(n).record}function gc(n){return n.format==="T20"?120:300}function pc(n,e){const t=[...n];t.length%2===1&&t.push(null);const i=t.length,a=[],r=[...t];for(let o=0;o<i-1;o+=1){for(let s=0;s<i/2;s+=1){const d=r[s],g=r[i-1-s];d!==null&&g!==null&&a.push(o%2===0?[d,g]:[g,d])}r.splice(1,0,r.pop())}return e===1?a:[...a,...a.map(([o,s])=>[s,o])]}function a1(n,e,t,i,a){return{fixtureId:`${n.competitionId}:m${e}`,matchNumber:e,stage:t,homeTeamId:i,awayTeamId:a,groundId:n.groundIds[(e-1)%n.groundIds.length]}}function Ue(n,e){return n.find(t=>t.fixtureId===e)??null}function Ic(n){return n>=10}function vi(n,e,t,i){const a=new Map(e.map(r=>[r,{teamId:r,played:0,won:0,lost:0,tied:0,points:0,runsFor:0,ballsFaced:0,runsAgainst:0,ballsBowled:0,netRunRate:0}]));for(const r of t){const o=Ue(i,r.fixtureId);if(!o)continue;const s=[{id:o.homeTeamId,runs:o.homeRuns,wickets:o.homeWickets,balls:o.homeLegalBalls},{id:o.awayTeamId,runs:o.awayRuns,wickets:o.awayWickets,balls:o.awayLegalBalls}];for(const[d,g]of[[s[0],s[1]],[s[1],s[0]]]){const E=a.get(d.id);E&&(E.played+=1,E.runsFor+=d.runs,E.ballsFaced+=Ic(d.wickets)?gc(n):d.balls,E.runsAgainst+=g.runs,E.ballsBowled+=Ic(g.wickets)?gc(n):g.balls,o.resultKind==="TIE"?(E.tied+=1,E.points+=n.points.tie):o.winnerTeamId===d.id?(E.won+=1,E.points+=n.points.win):(E.lost+=1,E.points+=n.points.loss))}}for(const r of a.values()){const o=r.ballsFaced?r.runsFor*6/r.ballsFaced:0,s=r.ballsBowled?r.runsAgainst*6/r.ballsBowled:0;r.netRunRate=Math.round((o-s)*1e3)/1e3}return[...a.values()].sort((r,o)=>o.points-r.points||o.won-r.won||o.netRunRate-r.netRunRate||(r.teamId<o.teamId?-1:r.teamId>o.teamId?1:0))}function Ri(n,e){return n.winnerTeamId?n.winnerTeamId:n.superOverWinnerTeamId?n.superOverWinnerTeamId:e}function Ka(n,e){return n.every(t=>Ue(e,t.fixtureId)!==null)}function hc(n,e){const t=n.structure,i=[],a=[];let r={status:"IN_PROGRESS"},o=0;const s=(g,E,h)=>{o+=1;const f=a1(n,o,g,E,h);return i.push(f),f};if(t.kind==="SERIES"){const[g,E]=n.teamIds,h=Math.floor(t.matches/2)+1;let f=0,A=0;for(let b=0;b<t.matches;b+=1){const w=s("SERIES",b%2===0?g:E,b%2===0?E:g),D=Ue(e,w.fixtureId);if(!D||(D.winnerTeamId===g&&(f+=1),D.winnerTeamId===E&&(A+=1),f>=h||A>=h))break}if(f>=h||A>=h||Ka(i,e)&&i.length===t.matches){const b=`Series ${Math.max(f,A)}-${Math.min(f,A)}`;r=f===A?{status:"SERIES_DRAWN",how:`Series drawn ${f}-${A}`}:{status:"CHAMPION",teamId:f>A?g:E,how:b}}a.push({stage:"SERIES",rows:vi(n,n.teamIds,i,e)})}else if(t.kind==="ROUND_ROBIN"){for(const[h,f]of pc(n.teamIds,t.legs))s("LEAGUE",h,f);const g=i.slice(),E=vi(n,n.teamIds,g,e);if(a.push({stage:"LEAGUE",rows:E}),Ka(g,e))if(!t.finalTopTwo)r={status:"CHAMPION",teamId:E[0].teamId,how:"Top of the table"};else{const h=s("FINAL",E[0].teamId,E[1].teamId),f=Ue(e,h.fixtureId);f&&(r={status:"CHAMPION",teamId:Ri(f,E[0].teamId),how:"Won the final"})}}else{const g=["GROUP_A","GROUP_B"];t.groups.forEach((A,N)=>{for(const[b,w]of pc(A,1))s(g[N],b,w)});const E=A=>i.filter(N=>N.stage===A),h=vi(n,t.groups[0],E("GROUP_A"),e),f=vi(n,t.groups[1],E("GROUP_B"),e);if(a.push({stage:"GROUP_A",rows:h},{stage:"GROUP_B",rows:f}),Ka(i,e)){const A=s("SEMI_FINAL",h[0].teamId,f[1].teamId),N=s("SEMI_FINAL",f[0].teamId,h[1].teamId),b=Ue(e,A.fixtureId),w=Ue(e,N.fixtureId);if(b&&w){const D=Ri(b,h[0].teamId),p=Ri(w,f[0].teamId),I=s("FINAL",D,p),v=Ue(e,I.fixtureId);v&&(r={status:"CHAMPION",teamId:Ri(v,D),how:"Won the final"})}}}const d=r.status==="IN_PROGRESS"?i.find(g=>!Ue(e,g.fixtureId))??null:null;return{fixtures:i,tables:a,outcome:r,next:d}}/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */function o1(n){return n instanceof Uint8Array||ArrayBuffer.isView(n)&&n.constructor.name==="Uint8Array"}function Ai(n,...e){if(!o1(n))throw new Error("Uint8Array expected");if(e.length>0&&!e.includes(n.length))throw new Error("Uint8Array expected of length "+e+", got length="+n.length)}function fc(n,e=!0){if(n.destroyed)throw new Error("Hash instance has been destroyed");if(e&&n.finished)throw new Error("Hash#digest() has already been called")}function r1(n,e){Ai(n);const t=e.outputLen;if(n.length<t)throw new Error("digestInto() expects output buffer of length at least "+t)}function ja(...n){for(let e=0;e<n.length;e++)n[e].fill(0)}function qa(n){return new DataView(n.buffer,n.byteOffset,n.byteLength)}function Re(n,e){return n<<32-e|n>>>e}const s1=typeof Uint8Array.from([]).toHex=="function"&&typeof Uint8Array.fromHex=="function",c1=Array.from({length:256},(n,e)=>e.toString(16).padStart(2,"0"));function l1(n){if(Ai(n),s1)return n.toHex();let e="";for(let t=0;t<n.length;t++)e+=c1[n[t]];return e}function Za(n){if(typeof n!="string")throw new Error("string expected");return new Uint8Array(new TextEncoder().encode(n))}function Ec(n){return typeof n=="string"&&(n=Za(n)),Ai(n),n}class d1{}function u1(n){const e=i=>n().update(Ec(i)).digest(),t=n();return e.outputLen=t.outputLen,e.blockLen=t.blockLen,e.create=()=>n(),e}function m1(n,e,t,i){if(typeof n.setBigUint64=="function")return n.setBigUint64(e,t,i);const a=BigInt(32),r=BigInt(4294967295),o=Number(t>>a&r),s=Number(t&r),d=i?4:0,g=i?0:4;n.setUint32(e+d,o,i),n.setUint32(e+g,s,i)}function g1(n,e,t){return n&e^~n&t}function p1(n,e,t){return n&e^n&t^e&t}class I1 extends d1{constructor(e,t,i,a){super(),this.finished=!1,this.length=0,this.pos=0,this.destroyed=!1,this.blockLen=e,this.outputLen=t,this.padOffset=i,this.isLE=a,this.buffer=new Uint8Array(e),this.view=qa(this.buffer)}update(e){fc(this),e=Ec(e),Ai(e);const{view:t,buffer:i,blockLen:a}=this,r=e.length;for(let o=0;o<r;){const s=Math.min(a-this.pos,r-o);if(s===a){const d=qa(e);for(;a<=r-o;o+=a)this.process(d,o);continue}i.set(e.subarray(o,o+s),this.pos),this.pos+=s,o+=s,this.pos===a&&(this.process(t,0),this.pos=0)}return this.length+=e.length,this.roundClean(),this}digestInto(e){fc(this),r1(e,this),this.finished=!0;const{buffer:t,view:i,blockLen:a,isLE:r}=this;let{pos:o}=this;t[o++]=128,ja(this.buffer.subarray(o)),this.padOffset>a-o&&(this.process(i,0),o=0);for(let h=o;h<a;h++)t[h]=0;m1(i,a-8,BigInt(this.length*8),r),this.process(i,0);const s=qa(e),d=this.outputLen;if(d%4)throw new Error("_sha2: outputLen should be aligned to 32bit");const g=d/4,E=this.get();if(g>E.length)throw new Error("_sha2: outputLen bigger than state");for(let h=0;h<g;h++)s.setUint32(4*h,E[h],r)}digest(){const{buffer:e,outputLen:t}=this;this.digestInto(e);const i=e.slice(0,t);return this.destroy(),i}_cloneInto(e){e||(e=new this.constructor),e.set(...this.get());const{blockLen:t,buffer:i,length:a,finished:r,destroyed:o,pos:s}=this;return e.destroyed=o,e.finished=r,e.length=a,e.pos=s,a%t&&e.buffer.set(i),e}clone(){return this._cloneInto()}}const Ge=Uint32Array.from([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),h1=Uint32Array.from([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),ze=new Uint32Array(64);class f1 extends I1{constructor(e=32){super(64,e,8,!1),this.A=Ge[0]|0,this.B=Ge[1]|0,this.C=Ge[2]|0,this.D=Ge[3]|0,this.E=Ge[4]|0,this.F=Ge[5]|0,this.G=Ge[6]|0,this.H=Ge[7]|0}get(){const{A:e,B:t,C:i,D:a,E:r,F:o,G:s,H:d}=this;return[e,t,i,a,r,o,s,d]}set(e,t,i,a,r,o,s,d){this.A=e|0,this.B=t|0,this.C=i|0,this.D=a|0,this.E=r|0,this.F=o|0,this.G=s|0,this.H=d|0}process(e,t){for(let h=0;h<16;h++,t+=4)ze[h]=e.getUint32(t,!1);for(let h=16;h<64;h++){const f=ze[h-15],A=ze[h-2],N=Re(f,7)^Re(f,18)^f>>>3,b=Re(A,17)^Re(A,19)^A>>>10;ze[h]=b+ze[h-7]+N+ze[h-16]|0}let{A:i,B:a,C:r,D:o,E:s,F:d,G:g,H:E}=this;for(let h=0;h<64;h++){const f=Re(s,6)^Re(s,11)^Re(s,25),A=E+f+g1(s,d,g)+h1[h]+ze[h]|0,b=(Re(i,2)^Re(i,13)^Re(i,22))+p1(i,a,r)|0;E=g,g=d,d=s,s=o+A|0,o=r,r=a,a=i,i=A+b|0}i=i+this.A|0,a=a+this.B|0,r=r+this.C|0,o=o+this.D|0,s=s+this.E|0,d=d+this.F|0,g=g+this.G|0,E=E+this.H|0,this.set(i,a,r,o,s,d,g,E)}roundClean(){ja(ze)}destroy(){this.set(0,0,0,0,0,0,0,0),ja(this.buffer)}}const Sc=u1(()=>new f1);function Kn(n){return l1(Sc(n))}function Qn(n){return Za(In(n))}function E1(n){return In(n),Za(og(n))}function Ye(n=$n){if(n!==$n)throw new Error("UNSUPPORTED_RANDOM_VERSION: "+String(n));return Object.freeze({version:$n,uint32(e){const t=Sc(E1(e));return new DataView(t.buffer,t.byteOffset,t.byteLength).getUint32(0,!1)}})}function kn(n=mi){if(n!==mi)throw new Error("UNSUPPORTED_STATE_HASH_VERSION: "+String(n));return Object.freeze({version:mi,hash(e){return Kn(Qn(e))}})}const Xa={schemaVersion:"1.0.0",referenceEdition:"MCC_2017_FOURTH_EDITION_2026",effectiveDate:"2026-10-01",customProfile:!0,ballsPerOver:6,playersPerXI:11,wicketsToAllOut:10,consecutiveOvers:!1,maxLegSide:5,maxBehindSquareLegSide:2,limitedOversRain:!1,superOver:!1,supportedClauses:[],validationStatus:"CONTRACT_ONLY"},ke=[{...Xa,rulesId:"LC_T20_01",format:"T20",inningsPerTeam:1,allocatedBalls:120,bowlerMaxBalls:24,freeHitAfterNoBall:!0,declarations:!1,followOnLead:null,newBallAfterLegalBalls:null,fieldPhases:[{fromLegalBall:0,maxOutside:2},{fromLegalBall:36,maxOutside:5}],localVariations:["No super over; ties share points"],fixtureIds:["F01","F02","F03","F04","F05","F06","F07","F08","F09"]},{...Xa,rulesId:"LC_ODI_01",format:"ODI",inningsPerTeam:1,allocatedBalls:300,bowlerMaxBalls:60,freeHitAfterNoBall:!0,declarations:!1,followOnLead:null,newBallAfterLegalBalls:null,fieldPhases:[{fromLegalBall:0,maxOutside:2},{fromLegalBall:60,maxOutside:4},{fromLegalBall:240,maxOutside:5}],localVariations:["One ball per innings"],fixtureIds:["F01","F02","F07","F08","F09"]},{...Xa,rulesId:"LC_RED5_01",format:"RED_BALL",inningsPerTeam:2,allocatedBalls:null,bowlerMaxBalls:null,freeHitAfterNoBall:!1,declarations:!0,followOnLead:200,newBallAfterLegalBalls:480,fieldPhases:[],localVariations:["Custom five-day clock; over completed at stumps despite wicket","No limited-overs rain provider"],fixtureIds:["F10","F11","F12"]}].map(n=>qm.parse(n)),Li=wr.parse({registryId:"LC_FIELD_CONTRACT_01",referenceHand:"R",positions:[{slotId:"slip-1",sector:7,angleDegrees:315,depth:"INNER",insideCircle:!0,legSide:!1,behindSquare:!0},{slotId:"slip-2",sector:7,angleDegrees:300,depth:"INNER",insideCircle:!0,legSide:!1,behindSquare:!0},{slotId:"point",sector:6,angleDegrees:270,depth:"MIDDLE",insideCircle:!0,legSide:!1,behindSquare:!1},{slotId:"cover",sector:5,angleDegrees:225,depth:"MIDDLE",insideCircle:!0,legSide:!1,behindSquare:!1},{slotId:"mid-off",sector:4,angleDegrees:190,depth:"MIDDLE",insideCircle:!0,legSide:!1,behindSquare:!1},{slotId:"mid-on",sector:4,angleDegrees:170,depth:"MIDDLE",insideCircle:!0,legSide:!0,behindSquare:!1},{slotId:"midwicket",sector:3,angleDegrees:135,depth:"MIDDLE",insideCircle:!0,legSide:!0,behindSquare:!1},{slotId:"deep-square-leg",sector:2,angleDegrees:90,depth:"DEEP",insideCircle:!1,legSide:!0,behindSquare:!1},{slotId:"fine-leg",sector:1,angleDegrees:45,depth:"DEEP",insideCircle:!1,legSide:!0,behindSquare:!0},{slotId:"deep-cover",sector:5,angleDegrees:225,depth:"DEEP",insideCircle:!1,legSide:!1,behindSquare:!1},{slotId:"long-on",sector:4,angleDegrees:170,depth:"DEEP",insideCircle:!1,legSide:!0,behindSquare:!1}]}),Ja=["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"],_c=["deep-cover","long-on","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"],Tc=wr.parse({registryId:"LC_ODI_FIELD_01",referenceHand:"R",positions:[...Li.positions,{slotId:"long-off",sector:4,angleDegrees:190,depth:"DEEP",insideCircle:!1,legSide:!1,behindSquare:!1}]}),bc=Ja,S1=_c,_1=["deep-cover","long-off","long-on","deep-square-leg","fine-leg","point","cover","mid-on","midwicket"],ne=Object.freeze({manifest:{modelId:"synthetic-alpha-01",schemaVersion:"1.0.0",status:"SYNTHETIC_ALPHA",randomId:"SHA256_COUNTER_V1",fixedPointScale:1e4,expLutHash:"d0cb73226646dec41e482127fc745ef64213f1c71f898ed7ad8c345ce591f825",featureSpecHash:"8a369a30b377ede7f7bc8c8f523a1c0124b6fd299ddf4f9fad5b3fd402d065b7",variationIds:["stock"],effects:{overAroundWicket:!1,individualVariations:!1,moisture:!1,geometryEffects:!1,outfieldSpeed:!1}},probabilityVersion:"LC_INTEGER_PROBABILITY_V1",lutVersion:"LC_EXP_LUT_V1",lutScale:"1000000000000",lutStepBp:100,lutMinDeltaBp:-16e4,lutMaxDeltaBp:0,logitMinBp:-8e4,logitMaxBp:8e4,coefficients:{legality:{WIDE:{CONTROL:-7e3,FATIGUE:5e3,LEG_LINE:2e3,MAXIMUM_EFFORT:1500,CONSERVE_EFFORT:-1e3},NO_BALL:{CONTROL:-5e3,FATIGUE:4e3,MAXIMUM_EFFORT:1500,CONSERVE_EFFORT:-1e3}},contact:{MISS:{DEFENCE:-4e3,AGGRESSION:2500,MOVEMENT:2500},PAD:{DEFENCE:-3e3,MOVEMENT:2e3},GROUND:{TIMING:3500,AGGRESSION:-1500},AERIAL:{AGGRESSION:4500,POWER:2500},EDGE:{TIMING:-4e3,AGGRESSION:2500,MOVEMENT:3e3},HIT_WICKET:{AGGRESSION:1e3}}},featureSpec:{maxTerms:32,fixedPointScale:1e4,termMultiplyRounding:"NEAREST_TIES_AWAY_FROM_ZERO",accumulationOrder:"INTERCEPT_TERMS_IN_ARRAY_ORDER",clipTiming:"AFTER_SUM",lutDeltaRounding:"NEAREST_TIES_AWAY_FROM_ZERO",categoryOrder:"AS_SUPPLIED",massAllocation:"LARGEST_REMAINDER_CATEGORY_INDEX"},expLutValues:[1e12,990049833749,980198673307,970445533549,960789439152,951229424501,941764533584,932393819906,923116346387,913931185271,904837418036,895834135297,886920436717,878095430921,869358235399,860707976425,852143788966,843664816596,835270211411,826959133943,818730753078,810584245970,802518797962,794533602503,786627861067,778800783071,771051585804,763379494337,755783741456,748263567579,740818220682,733446956224,726149037074,718923733432,711770322763,704688089719,697676326071,690734330637,683861409212,677056874498,670320046036,663650250136,657046819815,650509094723,644036421083,637628151622,631283645507,625002268283,618783391806,612626394184,606530659713,600495578812,594520547970,588604969678,582748252374,576949810380,571209063849,565525438700,559898366565,554327284735,548811636094,543350869074,537944437595,532591801007,527292424043,522045776761,516851334492,511708577787,506616992366,501576069066,496585303791,491644197461,486752255960,481908990090,477113915521,472366552741,467666427010,463013068311,458406011305,453844795282,449328964117,444858066223,440431654506,436049286322,431710523429,427414931949,423162082318,418951549248,414782911682,410655752752,406569659741,402524224034,398519041085,394553710372,390627835359,386741023455,382892885975,379083038103,375311098851,371576691022,367879441171,364218979572,360594940173,357006960569,353454681959,349937749111,346455810330,343008517419,339595525645,336216493707,332871083698,329558961075,326279794623,323033256422,319819021816,316636769379,313486180883,310366941265,307278738601,304221264067,301194211912,298197279430,295230166924,292292577681,289384217939,286504796860,283654026500,280831621778,278037300453,275270783090,272531793034,269820056385,267135301966,264477261300,261845668580,259240260646,256660776954,254106959553,251578553060,249075304632,246596963942,244143283153,241714016897,239308922244,236927758682,234570288094,232236274730,229925485187,227637688384,225372655539,223130160148,220909977959,218711886952,216535667316,214381101427,212247973827,210136071201,208045182357,205975098205,203925611734,201896517995,199887614075,197898699084,195929574127,193980042291,192049908621,190138980102,188247065639,186373976039,184519523993,182683524053,180865792617,179066147911,177284409970,175520400617,173773943450,172044863823,170332988825,168638147269,166960169667,165298888222,163654136803,162025750934,160413567775,158817426107,157237166314,155672630368,154123661815,152590105757,151071808836,149568619223,148080386595,146606962130,145148198484,143703949778,142274071587,140858420921,139456856215,138069237311,136695425446,135335283237,133988674669,132655465080,131335521148,130028710878,128734903588,127453969895,126185781705,124930212199,123687135817,122456428253,121237966433,120031628511,118837293852,117654843022,116484157773,115325121038,114177616911,113041530640,111916748617,110803158362,109700648516,108609108825,107528430136,106458504379,105399224562,104350484755,103312180083,102284206716,101266461854,100258843723,99261251560,98273585604,97295747090,96327638230,95369162216,94420223196,93480726278,92550577510,91629683878,90717953289,89815294572,88921617459,88036832582,87160851462,86293586499,85434950967,84584859002,83743225592,82909966575,82084998624,81268239241,80459606750,79659020286,78866399791,78081666001,77304740443,76535545424,75774004023,75020040085,74273578214,73534543763,72802862827,72078462239,71361269556,70651213060,69948221745,69252225309,68563154154,67880939372,67205512740,66536806715,65874754426,65219289668,64570346893,63927861207,63291768360,62662004742,62038507377,61421213915,60810062625,60204992392,59605942709,59012853669,58425665965,57844320875,57268760265,56698926580,56134762834,55576212611,55023220056,54475729869,53933687300,53397038145,52865728738,52339705948,51818917173,51303310332,50792833865,50287436724,49787068368,49291678760,48801218362,48315638126,47834889494,47358924391,46887695220,46421154857,45959256649,45501954405,45049202394,44600955340,44157168420,43717797253,43282797902,42852126867,42425741081,42003597903,41585655121,41171870939,40762203978,40356613272,39955058261,39557498788,39163895099,38774207832,38388398018,38006427075,37628256807,37253849396,36883167401,36516173754,36152831754,35793105068,35436957722,35084354101,34735258945,34389637343,34047454735,33708676900,33373269960,33041200376,32712434939,32386940773,32064685328,31745636378,31429762018,31117030661,30807411033,30500872171,30197383422,29896914437,29599435168,29304915867,29013327082,28724639654,28438824714,28155853680,27875698255,27598330423,27323722447,27051846866,26782676493,26516184409,26252343966,25991128779,25732512726,25476469947,25222974835,24972002042,24723526470,24477523272,24233967846,23992835837,23754103131,23517745856,23283740375,23052063287,22822691425,22595601851,22370771856,22148178957,21927800894,21709615630,21493601345,21279736438,21067999523,20858369425,20650825182,20445346038,20241911446,20040501062,19841094744,19643672553,19448214745,19254701775,19063114292,18873433135,18685639338,18499714120,18315638889,18133395237,17952964940,17774329954,17597472416,17422374639,17249019115,17077388507,16907465653,16739233559,16572675402,16407774526,16244514442,16082878823,15922851505,15764416485,15607557920,15452260124,15298507567,15146284873,14995576820,14846368338,14698644505,14552390548,14407591843,14264233909,14122302410,13981783153,13842662086,13704925297,13568559012,13433549594,13299883542,13167547490,13036528203,12906812580,12778387650,12651240568,12525358621,12400729220,12277339903,12155178330,12034232285,11914489673,11795938520,11678566970,11562363287,11447315851,11333413155,11220643810,11108996538,10998460176,10889023669,10780676073,10673406554,10567204384,10462058943,10357959718,10254896296,10152858373,10051835745,9951818308,9852796061,9754759102,9657697628,9561601931,9466462402,9372269527,9279013887,9186686156,9095277102,9004777582,8915178548,8826471040,8738646185,8651695203,8565609397,8480380160,8395998967,8312457382,8229747049,8147859698,8066787139,7986521266,7907054052,7828377549,7750483891,7673365288,7597014028,7521422475,7446583071,7372488331,7299130847,7226503281,7154598372,7083408929,7012927833,6943148035,6874062557,6805664492,6737946999,6670903306,6604526709,6538810571,6473748318,6409333446,6345559513,6282420141,6219909016,6158019887,6096746566,6036082924,5976022895,5916560474,5857689713,5799404727,5741699686,5684568819,5628006414,5572006815,5516564421,5461673688,5407329126,5353525303,5300256836,5247518399,5195304719,5143610573,5092430793,5041760260,4991593907,4941926718,4892753725,4844070012,4795870710,4748150999,4700906108,4654131310,4607821930,4561973336,4516580943,4471640211,4427146648,4383095803,4339483271,4296304691,4253555745,4211232158,4169329698,4127844174,4086771438,4046107383,4005847942,3965989089,3926526838,3887457243,3848776398,3810480433,3772565519,3735027865,3697863716,3661069358,3624641109,3588575327,3552868406,3517516775,3482516898,3447865276,3413558443,3379592969,3345965457,3312672545,3279710902,3247077234,3214768275,3182780797,3151111598,3119757514,3088715408,3057982176,3027554745,2997430072,2967605145,2938076980,2908842626,2879899158,2851243683,2822873334,2794785275,2766976697,2739444819,2712186887,2685200177,2658481989,2632029651,2605840518,2579911972,2554241419,2528826292,2503664050,2478752177,2454088180,2429669595,2405493979,2381558914,2357862006,2334400888,2311173211,2288176653,2265408915,2242867719,2220550813,2198455963,2176580961,2154923618,2133481770,2112253272,2091236001,2070427855,2049826753,2029430636,2009237464,1989245217,1969451897,1949855523,1930454136,1911245797,1892228583,1873400594,1854759947,1836304777,1818033239,1799943506,1782033769,1764302237,1746747136,1729366712,1712159226,1695122957,1678256201,1661557273,1645024502,1628656235,1612450834,1596406681,1580522169,1564795710,1549225733,1533810679,1518549008,1503439193,1488479723,1473669102,1459005850,1444488499,1430115598,1415885710,1401797412,1387849295,1374039964,1360368038,1346832149,1333430946,1320163086,1307027244,1294022105,1281146370,1268398751,1255777973,1243282773,1230911903,1218664125,1206538214,1194532958,1182647157,1170879621,1159229174,1147694651,1136274898,1124968774,1113775148,1102692900,1091720922,1080858118,1070103400,1059455693,1048913933,1038477065,1028144045,1017913841,1007785429,997757796,987829941,978000868,968269597,958635154,949096575,939652906,930303203,921046532,911881966,902808588,893825493,884931781,876126562,867408957,858778094,850233109,841773148,833397366,825104923,816894992,808766751,800719387,792752096,784864081,777054553,769322731,761667842,754089120,746585808,739157155,731802419,724520863,717311760,710174389,703108036,696111994,689185564,682328053,675538775,668817052,662162211,655573587,649050521,642592360,636198460,629868179,623600886,617395954,611252761,605170695,599149146,593187512,587285198,581441612,575656171,569928297,564257416,558642960,553084370,547581089,542132566,536738257,531397622,526110127,520875244,515692449,510561223,505481054,500451433,495471858,490541831,485660858,480828452,476044129,471307411,466617824,461974899,457378172,452827183,448321477,443860604,439444117,435071575,430742541,426456581,422213267,418012175,413852884,409734979,405658048,401621683,397625480,393669041,389751968,385873871,382034362,378233057,374469575,370743540,367054581,363402326,359786413,356206478,352662165,349153117,345678986,342239423,338834083,335462628,332124719,328820023,325548209,322308950,319101922,315926805,312783281,309671035,306589757,303539138,300518873,297528660,294568201,291637198,288735360,285862395,283018016,280201940,277413884,274653570,271920721,269215065,266536330,263884249,261258557,258658991,256085291,253537200,251014463,248516827,246044043,243595864,241172045,238772343,236396518,234044334,231715554,229409945,227127278,224867324,222629857,220414653,218221490,216050150,213900415,211772071,209664903,207578703,205513260,203468369,201443825,199439425,197454970,195490260,193545100,191619294,189712650,187824977,185956088,184105794,182273910,180460255,178664645,176886902,175126848,173384307,171659104,169951068,168260026,166585811,164928254,163287191,161662456,160053888,158461325,156884609,155323581,153778085,152247968,150733075,149233256,147748360,146278239,144822747,143381736,141955064,140542588,139144166,137759658,136388926,135031834,133688245,132358025,131041040,129737160,128446254,127168192,125902848,124650093,123409804,122181856,120966126,119762493,118570836,117391037,116222977,115066539,113921607,112788069,111665808,110554715,109454677,108365585,107287330,106219803,105162898,104116510,103080533,102054865,101039402,100034043,99038688,98053236,97077590,96111652,95155325,94208514,93271123,92343060,91424231,90514545,89613910,88722237,87839436,86965419,86100099,85243388,84395203,83555456,82724066,81900947,81086019,80279200,79480409,78689565,77906591,77131407,76363937,75604103,74851830,74107042,73369664,72639624,71916848,71201263,70492799,69791384,69096948,68409422,67728736,67054824,66387618,65727050,65073055,64425567,63784522,63149855,62521504,61899404,61283495,60673714,60070001,59472294,58880535,58294664,57714622,57140352,56571796,56008897,55451599,54899847,54353584,53812757,53277311,52747193,52222350,51702729,51188278,50678946,50174682,49675436,49181157,48691796,48207305,47727634,47252736,46782563,46317069,45856207,45399930,44948193,44500951,44058159,43619773,43185749,42756044,42330614,41909417,41492412,41079555,40670807,40266126,39865471,39468803,39076082,38687268,38302323,37921209,37543887,37170319,36800468,36434297,36071770,35712850,35357501,35005688,34657375,34312529,33971113,33633095,33298440,32967115,32639087,32314323,31992790,31674456,31359290,31047260,30738335,30432483,30129675,29829879,29533067,29239208,28948273,28660233,28375059,28092723,27813195,27536449,27262457,26991191,26722624,26456730,26193481,25932851,25674815,25419347,25166420,24916010,24668091,24422640,24179630,23939039,23700842,23465014,23231533,23000376,22771518,22544938,22320612,22098518,21878634,21660938,21445408,21232023,21020761,20811601,20604522,20399503,20196525,19995566,19796607,19599627,19404608,19211529,19020371,18831115,18643742,18458234,18274571,18092736,17912711,17734476,17558015,17383310,17210343,17039098,16869556,16701701,16535516,16370985,16208091,16046818,15887149,15729069,15572563,15417613,15264205,15112324,14961954,14813080,14665687,14519761,14375287,14232251,14090637,13950433,13811624,13674196,13538136,13403429,13270062,13138023,13007298,12877873,12749736,12622874,12497274,12372924,12249812,12127924,12007249,11887775,11769490,11652381,11536438,11421649,11308001,11195485,11084088,10973799,10864608,10756504,10649475,10543511,10438601,10334735,10231903,10130094,10029297,9929504,9830704,9732887,9636043,9540163,9445237,9351255,9258208,9166088,9074884,8984587,8895189,8806680,8719052,8632296,8546404,8461365,8377173,8293819,8211294,8129591,8048700,7968614,7889325,7810825,7733106,7656160,7579980,7504558,7429886,7355958,7282765,7210300,7138556,7067526,6997203,6927580,6858650,6790405,6722839,6655946,6589718,6524149,6459233,6394962,6331331,6268334,6205963,6144212,6083076,6022549,5962623,5903294,5844556,5786401,5728826,5671823,5615387,5559513,5504195,5449428,5395205,5341522,5288373,5235752,5183656,5132078,5081013,5030456,4980402,4930846,4881783,4833209,4785117,4737505,4690366,4643696,4597490,4551744,4506454,4461614,4417220,4373268,4329753,4286672,4244018,4201790,4159981,4118589,4077608,4037035,3996866,3957097,3917723,3878741,3840147,3801937,3764107,3726653,3689572,3652860,3616514,3580529,3544902,3509630,3474708,3440134,3405905,3372015,3338463,3305245,3272357,3239797,3207560,3175644,3144046,3112762,3081790,3051126,3020766,2990709,2960951,2931489,2902320,2873442,2844851,2816544,2788519,2760773,2733302,2706106,2679179,2652521,2626128,2599998,2574127,2548514,2523156,2498050,2473194,2448586,2424222,2400100,2376219,2352575,2329167,2305991,2283046,2260329,2237839,2215572,2193527,2171701,2150092,2128698,2107517,2086547,2065786,2045231,2024880,2004732,1984785,1965036,1945484,1926126,1906960,1887986,1869200,1850601,1832187,1813957,1795908,1778038,1760346,1742831,1725489,1708320,1691322,1674493,1657832,1641336,1625004,1608835,1592827,1576978,1561287,1545752,1530372,1515144,1500068,1485142,1470365,1455734,1441250,1426909,1412711,1398654,1384737,1370959,1357318,1343812,1330441,1317203,1304097,1291121,1278274,1265555,1252962,1240495,1228152,1215932,1203833,1191855,1179995,1168254,1156630,1145121,1133727,1122446,1111278,1100220,1089273,1078435,1067704,1057080,1046562,1036149,1025839,1015631,1005526,995521,985615,975808,966099,956486,946969,937546,928217,918981,909837,900784,891821,882948,874162,865464,856853,848327,839886,831529,823255,815063,806953,798924,790975,783104,775312,767598,759960,752398,744912,737500,730162,722896,715703,708582,701532,694551,687640,680798,674024,667317,660678,654104,647595,641152,634772,628456,622203,616012,609882,603814,597806,591857,585968,580138,574365,568650,562992,557390,551844,546353,540917,535535,530206,524930,519707,514536,509416,504348,499329,494361,489442,484572,479750,474977,470251,465572,460939,456353,451812,447316,442865,438459,434096,429777,425500,421267,417075,412925,408816,404748,400721,396734,392786,388878,385009,381178,377385,373630,369912,366232,362588,358980,355408,351871,348370,344904,341472,338074,334710,331380,328083,324818,321586,318386,315218,312082,308977,305902,302859,299845,296862,293908,290983,288088,285221,282383,279574,276792,274038,271311,268611,265939,263293,260673,258079,255511,252969,250452,247960,245492,243050,240631,238237,235866,233520,231196,228896,226618,224363,222131,219920,217732,215566,213421,211297,209195,207113,205052,203012,200992,198992,197012,195052,193111,191190,189287,187404,185539,183693,181865,180056,178264,176490,174734,172996,171274,169570,167883,166212,164558,162921,161300,159695,158106,156533,154975,153433,151907,150395,148899,147417,145950,144498,143060,141637,140227,138832,137451,136083,134729,133388,132061,130747,129446,128158,126883,125621,124371,123133,121908,120695,119494,118305,117128,115962,114809,113666,112535],baselines:{legality:[{id:"LEGAL",baseWeight:9820},{id:"WIDE",baseWeight:130},{id:"NO_BALL",baseWeight:50}],contact:{T20_EARLY:[{id:"MISS",baseWeight:1250},{id:"PAD",baseWeight:700},{id:"GROUND",baseWeight:5900},{id:"AERIAL",baseWeight:1500},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],T20_MIDDLE:[{id:"MISS",baseWeight:1100},{id:"PAD",baseWeight:650},{id:"GROUND",baseWeight:6100},{id:"AERIAL",baseWeight:1500},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],T20_LATE:[{id:"MISS",baseWeight:1350},{id:"PAD",baseWeight:500},{id:"GROUND",baseWeight:5e3},{id:"AERIAL",baseWeight:2500},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],ODI_EARLY:[{id:"MISS",baseWeight:1700},{id:"PAD",baseWeight:900},{id:"GROUND",baseWeight:5950},{id:"AERIAL",baseWeight:800},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],ODI_MIDDLE:[{id:"MISS",baseWeight:1300},{id:"PAD",baseWeight:800},{id:"GROUND",baseWeight:6400},{id:"AERIAL",baseWeight:900},{id:"EDGE",baseWeight:595},{id:"HIT_WICKET",baseWeight:5}],ODI_LATE:[{id:"MISS",baseWeight:1300},{id:"PAD",baseWeight:550},{id:"GROUND",baseWeight:5300},{id:"AERIAL",baseWeight:2200},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],RED_BALL:[{id:"MISS",baseWeight:1900},{id:"PAD",baseWeight:1400},{id:"GROUND",baseWeight:5650},{id:"AERIAL",baseWeight:400},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}]}}}),Ae="d0cb73226646dec41e482127fc745ef64213f1c71f898ed7ad8c345ce591f825",Bn="d47d5caca955b7a374b0052d712b1674bca6d855e222194ce9f0587d8580b7ab";function vc(n){for(const e of Object.values(n))e&&typeof e=="object"&&vc(e);return Object.freeze(n)}const ln=vc({stagePackId:"synthetic-alpha-01-delivery-v1",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",status:"SYNTHETIC_ALPHA",source:"Lord_Cricket_XXVI_Technical_Design_V0_1(1).docx Appendix F",length:{intended:7e3,neighboursTotal:2500,gross:500,intendedControlBp:6e3,intendedFatigueBp:-5e3},elapsedSeconds:40,sectorLineMultiplierBp:12500,coverage:{neighbourBp:3500,ground:{INNER:8e3,MIDDLE:1e4,DEEP:7e3},aerial:{INNER:2e3,MIDDLE:5e3,DEEP:1e4},edge:{keeper:1e4,slip:1e4,gully:6e3,other:1e3}},catchOpportunityBp:{AERIAL:3e3,EDGE:4500},catchConversion:{interceptBp:15e3,catchingBp:12e3},runs:{GROUND:[4400,3600,900,100,1e3,0],AERIAL:[1800,1600,900,100,2400,3200],EDGE:[6e3,1300,300,0,2400,0],NONE:[9700,250,0,0,50,0],WIDE:[9800,150,50]},running:{interceptBp:-65e3,throwingBp:5e3,coverageBp:3e3,rotateBp:2500},bowled:{interceptBp:-35e3,controlBp:3e3,defenceBp:-3e3,stumpsBp:4e3},lbw:{interceptBp:-4e4,controlBp:3e3,defenceBp:-3e3},stumping:{numerator:3,denominator:1e3},noLiveMatchOrCalibration:!0}),jn="34efa3037702e44a134ea38b414eab3e97c6f79f10b3e5458bc2ab05412e5d7a",Mn=Object.freeze({worldPackId:"fictional-eight-01",worldSeed:"lcxxvi-fictional-eight-v1-20260927",worldGeneratorVersion:"LC_FICTIONAL_WORLD_GENERATOR_V1",generatorSourceSha256:"a3aaa4b64926ad9859f84222eb51274e7881df750308c2e9ae8fd1fa66e2f4da",provenanceSourceSha256:"97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",worldFileSha256:"0136173903ba42a199c84a17407cf711c2caf1b57c52472abb52e9be7a6d8257",worldCanonicalSha256:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",worldByteLength:310033}),Qa=n=>new Set(n).size===n.length;function fn(n,e){if(!n)throw new Error(`INVALID_DEFAULT_WORLD: ${e}`)}const Le=n=>n.bowlingStyle!==null&&(n.role==="BOWLER"||n.role==="ALLROUNDER");function T1(n,e){const t=Pg.parse(e),i=Mn;for(const f of Object.keys(i))fn(t[f]===i[f],`manifest violates frozen ${f}`);fn(t.modelHash===Bn,"model hash mismatch"),fn(t.stagePackHash===jn,"stage pack hash mismatch"),fn(t.modelId===ne.manifest.modelId,"wrong model"),fn(t.stagePackId===ln.stagePackId,"wrong stage pack");const a=ke.map(f=>f.rulesId);fn(JSON.stringify(t.rulesIds)===JSON.stringify(a),"inconsistent rule IDs"),fn(JSON.stringify(t.variationIds)===JSON.stringify(ne.manifest.variationIds),"model variation set mismatch");const r=ua(n,t.variationIds,a);fn(r.packId===t.worldPackId,"pack ID mismatch"),fn(r.schemaVersion===t.schemaVersion,"schema mismatch"),fn(r.players.length===160&&r.teams.length===8&&r.grounds.length===8,"expected exactly 160 players, eight teams and eight grounds"),fn(JSON.stringify(r.rulesIds)===JSON.stringify(t.rulesIds),"world rules differ from manifest");const o=r.teams.map(f=>f.teamId),s=r.grounds.map(f=>f.groundId),d=f=>Array.from({length:8},(A,N)=>`${f}-${String(N+1).padStart(2,"0")}`);fn(JSON.stringify(o)===JSON.stringify(d("team")),"team ID/order convention changed"),fn(JSON.stringify(s)===JSON.stringify(d("ground")),"ground ID/order convention changed"),fn(JSON.stringify(o)===JSON.stringify(t.teamIds)&&JSON.stringify(s)===JSON.stringify(t.groundIds),"world/manifest ID mismatch");const g=new Set(s);fn(JSON.stringify(Object.keys(t.homeGroundIds))===JSON.stringify(o),"home-ground keys mismatch"),fn(t.homeGroundIds&&Qa(Object.values(t.homeGroundIds))&&Object.values(t.homeGroundIds).every(f=>g.has(f)),"home-ground reference invalid");const E=new Map(r.players.map(f=>[f.playerId,f])),h=[];for(const f of r.teams){fn(f.squadIds.length===20,`20 players required: ${f.teamId}`);const A=f.squadIds.map(N=>E.get(N));h.push(...f.squadIds),fn(A.filter(N=>N.role==="KEEPER").length>=2,`keepers missing: ${f.teamId}`),fn(A.filter(Le).length>=6,`bowling capacity missing: ${f.teamId}`),fn(new Set(A.map(N=>N.role)).size>=3,`insufficient role variety: ${f.teamId}`),fn(Qa(A.map(N=>N.playerId)),`repeated player in squad: ${f.teamId}`),fn(new Set(A.map(N=>N.batHand)).size===2,`bat handedness missing: ${f.teamId}`),fn(new Set(A.filter(Le).map(N=>N.bowlHand)).size===2,`bowling handedness missing: ${f.teamId}`)}fn(Qa(h)&&h.length===160&&h.every(f=>E.has(f)),"shared squad member or missing assignment");for(const f of r.players)fn(f.provenance.kind==="FICTIONAL"&&f.provenance.sourceId===r.packId&&f.provenance.sourceHash===t.provenanceSourceSha256,`wrong provenance: ${f.playerId}`),fn(f.exposureBalls.T20===0&&f.exposureBalls.ODI===0&&f.exposureBalls.RED_BALL===0,`invented exposure: ${f.playerId}`),fn(Object.keys(f.skills).length===3&&Object.keys(f.exposureBalls).length===3,`missing format or exposure: ${f.playerId}`),fn(f.variations.length===1&&f.variations[0]==="stock",`unsupported variation: ${f.playerId}`);return{world:r,manifest:t}}const Oi=Object.freeze({version:"LC_T20_CONDITIONS_V1",fatigueBaseBp:{pace:20,spin:12},effortFactorBp:{CONSERVE:8e3,NORMAL:1e4,MAXIMUM:13e3},recoveryNonBowlerPerOverBp:15,wearIncrementPerLegalBall:1,wearStep:100,wearTurnDeltaBp:20,wearVariabilityDeltaBp:10,wearSeamDeltaBp:-10,maxBasisPoints:1e4,weather:"DRY",ballAgeResetAtInnings:!0}),Rc=Object.freeze({...Oi,version:"LC_ODI_CONDITIONS_V1"});Yg.parse({competitionVersion:"LC_T20_LEAGUE_COMPETITION_V1",competitionId:"LC_T20_LEAGUE_01",format:"T20",worldPackId:"fictional-eight-01",worldCanonicalSha256:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",teamIds:["team-01","team-02","team-03","team-04","team-05","team-06","team-07","team-08"],groundIds:["ground-01","ground-02","ground-03","ground-04","ground-05","ground-06","ground-07","ground-08"],homeGroundIds:{"team-01":"ground-01","team-02":"ground-02","team-03":"ground-03","team-04":"ground-04","team-05":"ground-05","team-06":"ground-06","team-07":"ground-07","team-08":"ground-08"},teamCount:8,rounds:14,matchesPerRound:4,totalFixtures:56,roundSpacingDays:3,playoffs:!1,points:{win:2,tie:1,noResult:1,loss:0},tableOrder:["POINTS","WINS","NET_RUN_RATE","HEAD_TO_HEAD_POINTS","TEAM_ID"],rainAdjustedNrr:!1,schedulerAlgorithm:"CIRCLE_REVERSE_VENUES_V1"}),jg.parse({conditionPolicyVersion:"LC_T20_CAREER_CONDITION_V1",maxFatigueBp:1e4,restRecoveryPerDayBp:2e3,practiceRecoveryPerDayBp:1400,noRandomInjuries:!0}),Zg.parse({availabilityVersion:"LC_T20_AVAILABILITY_PACK_V1",packId:"fictional-eight-01-availability-v1",worldPackId:Mn.worldPackId,worldCanonicalSha256:Mn.worldCanonicalSha256,entries:[]});const b1=Object.freeze(Object.fromEntries(Array.from({length:8},(n,e)=>{const t=e*20+1;return[`team-${String(e+1).padStart(2,"0")}`,Array.from({length:20},(i,a)=>`p${String(t+a).padStart(3,"0")}`)]}))),v1=Object.freeze(Array.from({length:160},(n,e)=>`p${String(e+1).padStart(3,"0")}`));Jg.parse({trainingPolicyVersion:"LC_T20_CAREER_TRAINING_V1",readinessMinRatingDelta:-3,readinessMaxRatingDelta:3,readinessPracticeGainPerDay:1,readinessDecayPerDay:1,restRecoveryPerDayBp:2e3,practiceRecoveryPerDayBp:1400,noPermanentAttributeGrowth:!0}),np.parse({policyVersion:"LC_T20_OFFSCREEN_POLICY_V1",executionVersion:"LC_T20_OFFSCREEN_FIXTURE_V1",selectionPolicyId:"LC_SEASON_XI_BASELINE_V1",captainPolicyId:"LC_FIXTURE_CAPTAIN_V1",conditionDeltaPolicyId:"LC_ENGINE_FINAL_FATIGUE_DELTA_V1",matchEngineVersion:"LC_T20_MATCH_V1",selectionScorePolicy:"SUM_SUPPORTED_T20_SKILLS_PLUS_AREA_READINESS_V1",unavailablePlayersExcluded:!0,fatigueSelectionEffect:"LOWER_FATIGUE_STABLE_TIEBREAK_ONLY",minimumNonKeeperBowlingCapable:5,requiresKeeper:!0,noFutureRandomAccess:!0,noAlternateMatchSimulator:!0}),Object.freeze([{schemaId:le,scenarioId:"t20-death-overs-chase",title:"Death-overs chase",format:"T20",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-2",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-03",objective:"WIN",objectiveSummary:"Score 23 from the last 24 balls with 5 wickets in hand.",briefing:"Northlight Ridge are 68 for 5 after 16 overs, chasing 91 against Silver Fen at Northlight Park. You captain the chase: pick your batters and their intent, and see it home.",checkpoint:{inningsIndex:1,legalBalls:96,revision:105,battingTeamId:"team-03",runs:68,wickets:5,targetToWin:91}},{schemaId:le,scenarioId:"t20-tail-end-chase",title:"Tail-end chase",format:"T20",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-12",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-06",objective:"WIN",objectiveSummary:"Score 46 from the last 30 balls with 3 wickets in hand.",briefing:"Silver Fen have collapsed to 36 for 7 after 15 overs, chasing 82 against Northlight Ridge. Three wickets remain. Find 46 runs before the overs or the batters run out.",checkpoint:{inningsIndex:1,legalBalls:90,revision:102,battingTeamId:"team-06",runs:36,wickets:7,targetToWin:82}},{schemaId:le,scenarioId:"t20-defend-55",title:"Hold the line",format:"T20",difficulty:"STANDARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-11",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-03",objective:"WIN",objectiveSummary:"Stop Silver Fen scoring 55 from the last 30 balls.",briefing:"Silver Fen are 49 for 4 after 15 overs, chasing 104. You lead Northlight Ridge in the field: choose bowlers, plans and fields for the last five overs.",checkpoint:{inningsIndex:1,legalBalls:90,revision:98,battingTeamId:"team-06",runs:49,wickets:4,targetToWin:104}},{schemaId:le,scenarioId:"t20-defend-19",title:"Nineteen to defend",format:"T20",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-1",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-03",objective:"WIN",objectiveSummary:"Stop Silver Fen scoring 19 from the last 30 balls.",briefing:"Silver Fen are 52 for 4 after 15 overs, chasing 71. Northlight Ridge need six wickets, or to keep the runs below 19, in the last five overs.",checkpoint:{inningsIndex:1,legalBalls:90,revision:99,battingTeamId:"team-06",runs:52,wickets:4,targetToWin:71}},{schemaId:le,scenarioId:"odi-tail-rescue",title:"Lower-order rescue",format:"ODI",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-odi-8",matchId:"human-odi",teamIds:["team-02","team-05"],groundId:"ground-02",playerTeamId:"team-02",objective:"WIN",objectiveSummary:"Score 32 more runs with 3 wickets in hand.",briefing:"Copper Vale are 59 for 7 after 17 overs, chasing 91 against Ember Plains at Copperfield. There is plenty of time and very little batting left. Nurse the tail to the target.",checkpoint:{inningsIndex:1,legalBalls:102,revision:133,battingTeamId:"team-02",runs:59,wickets:7,targetToWin:91}},{schemaId:le,scenarioId:"odi-last-ten",title:"Ten runs, two wickets",format:"ODI",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-odi-2",matchId:"human-odi",teamIds:["team-02","team-05"],groundId:"ground-02",playerTeamId:"team-05",objective:"WIN",objectiveSummary:"Take 2 wickets before Copper Vale score 10.",briefing:"Copper Vale are 134 for 8 after 40 overs, chasing 144. Ember Plains have 60 balls to take the last two wickets before the final 10 runs come.",checkpoint:{inningsIndex:1,legalBalls:240,revision:187,battingTeamId:"team-02",runs:134,wickets:8,targetToWin:144}},{schemaId:le,scenarioId:"red-fourth-innings-chase",title:"Fourth-innings chase",format:"RED_BALL",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-red-4",matchId:"human-red5",teamIds:["team-04","team-07"],groundId:"ground-04",playerTeamId:"team-07",objective:"WIN",objectiveSummary:"Score 63 more in the fourth innings with 4 wickets in hand.",briefing:"Larchwood are 41 for 6 in the fourth innings, chasing 104 against Westmere Isles at Westmere Oval. Time is not the problem; wickets are.",checkpoint:{inningsIndex:3,legalBalls:114,revision:293,battingTeamId:"team-07",runs:41,wickets:6,targetToWin:104}},{schemaId:le,scenarioId:"red-fourth-innings-defence",title:"Bowl them out",format:"RED_BALL",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-red-5",matchId:"human-red5",teamIds:["team-04","team-07"],groundId:"ground-04",playerTeamId:"team-04",objective:"WIN",objectiveSummary:"Take 7 wickets before Larchwood score 63.",briefing:"Larchwood are 28 for 3 in the fourth innings, chasing 91 at Westmere Oval. Westmere Isles must bowl them out to win.",checkpoint:{inningsIndex:3,legalBalls:84,revision:301,battingTeamId:"team-07",runs:28,wickets:3,targetToWin:91}},{schemaId:le,scenarioId:"t20-super-over-decider",title:"Level at the death",format:"T20",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-tie-469",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-06",objective:"WIN",objectiveSummary:"Score 12 from the last 12 balls with 2 wickets in hand.",briefing:"Silver Fen are 71 for 8 after 18 overs, chasing 83 against Northlight Ridge. Left to the engine, this match finishes level. Finish it level and it goes to a super over; only an outright win completes the challenge.",checkpoint:{inningsIndex:1,legalBalls:108,revision:109,battingTeamId:"team-06",runs:71,wickets:8,targetToWin:83}},{schemaId:le,scenarioId:"t20-six-to-defend",title:"Six to defend",format:"T20",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-tie-555",matchId:"human-t20",teamIds:["team-01","team-02"],groundId:"ground-01",playerTeamId:"team-01",objective:"WIN",objectiveSummary:"Stop Copper Vale scoring 6 from the last 18 balls.",briefing:"Copper Vale are 70 for 5 after 17 overs, chasing 76 at Aster Quay. Left to the engine, this match ends in a tie. Aster Harbour need five wickets, or to keep the last six runs out, to win outright.",checkpoint:{inningsIndex:1,legalBalls:102,revision:98,battingTeamId:"team-02",runs:70,wickets:5,targetToWin:76}},{schemaId:le,scenarioId:"odi-cup-final-defence",title:"Cup final: three wickets",format:"ODI",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-odi-tie-8",matchId:"human-odi",teamIds:["team-01","team-02"],groundId:"ground-01",playerTeamId:"team-01",objective:"WIN",objectiveSummary:"Take 3 wickets before Copper Vale score 10.",briefing:"A one-day cup final at Aster Quay. Copper Vale are 65 for 7 after 22 overs, chasing 75. Left to the engine, this final ends in a tie. Aster Harbour need three wickets before the last ten runs come.",checkpoint:{inningsIndex:1,legalBalls:132,revision:125,battingTeamId:"team-02",runs:65,wickets:7,targetToWin:75}},{schemaId:le,scenarioId:"odi-cup-final-chase",title:"Cup final: the tail's turn",format:"ODI",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-odi-tie-95",matchId:"human-odi",teamIds:["team-05","team-08"],groundId:"ground-05",playerTeamId:"team-08",objective:"WIN",objectiveSummary:"Score 21 more with 3 wickets in hand.",briefing:"A one-day cup final at Ember Meadow. Moonstone Bay are 45 for 7 after 11 overs, chasing 66 against Ember Plains. Left to the engine, this final ends in a tie. Find 21 runs before the last three wickets fall.",checkpoint:{inningsIndex:1,legalBalls:66,revision:106,battingTeamId:"team-08",runs:45,wickets:7,targetToWin:66}}].map(n=>Object.freeze(Zh.parse(n)))),a2.parse({schemaId:Ms,packId:"fictional-eight-tournaments-01",competitions:[{competitionId:"eight-nations-cup",title:"Eight Nations Cup",format:"T20",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-01","team-02","team-03","team-04","team-05","team-06","team-07","team-08"],groundIds:["ground-01","ground-02","ground-03","ground-04","ground-05","ground-06","ground-07","ground-08"],structure:{kind:"GROUPS_KNOCKOUT",groups:[["team-01","team-03","team-05","team-07"],["team-02","team-04","team-06","team-08"]]},points:{win:2,tie:1,loss:0},summary:"All eight sides in two T20 groups of four. The top two in each group reach the semi-finals, then a final. A tied knockout match goes to a super over."},{competitionId:"harbour-tri-series",title:"Harbour Tri-Series",format:"ODI",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-02","team-04","team-05"],groundIds:["ground-02","ground-04","ground-05"],structure:{kind:"ROUND_ROBIN",legs:2,finalTopTwo:!0},points:{win:4,tie:2,loss:0},summary:"Copper Vale, Westmere Isles and Ember Plains play each other twice in one-day matches. The top two meet in the final."},{competitionId:"larchwood-westmere-series",title:"Larchwood v Westmere one-day series",format:"ODI",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-07","team-04"],groundIds:["ground-07","ground-04"],structure:{kind:"SERIES",matches:5},points:{win:1,tie:0,loss:0},summary:"A five-match one-day series, home and away. It ends as soon as one side has won three."},{competitionId:"northern-t20-league",title:"Northern T20 League",format:"T20",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-01","team-03","team-06","team-08"],groundIds:["ground-01","ground-03","ground-06","ground-08"],structure:{kind:"ROUND_ROBIN",legs:2,finalTopTwo:!1},points:{win:2,tie:1,loss:0},summary:"Four sides play each other home and away in T20s. Top of the table wins."}]});const Ac=BigInt(St),R1=10000n,Lc=-80000n,Oc=80000n,A1=100n;function $t(n,e){if(e<=0n)throw new Error("INVALID_DIVISOR: must be positive");const t=n<0n?-1n:1n,i=n<0n?-n:n;return t*((i*2n+e)/(2n*e))}function L1(n){let e=BigInt(n.interceptBp);for(const t of n.terms)e+=$t(BigInt(t.coefficientBp)*BigInt(t.featureBp),R1);return e<Lc?Number(Lc):e>Oc?Number(Oc):Number(e)}function O1(n){In(n);const e=Rg.parse(n);if(Kn(Qn(e))!==Bn)throw new Error("UNSUPPORTED_MODEL_HASH: model pack bytes do not match pinned version");if(e.manifest.modelId!==ge||e.probabilityVersion!==zn||e.lutVersion!==Se||e.manifest.expLutHash!==Ae)throw new Error("UNSUPPORTED_MODEL_VERSION");const t={version:e.lutVersion,stepBp:e.lutStepBp,minDeltaBp:e.lutMinDeltaBp,maxDeltaBp:e.lutMaxDeltaBp,scale:e.lutScale,values:e.expLutValues};if(Kn(Qn(t))!==e.manifest.expLutHash)throw new Error("UNSUPPORTED_LUT_HASH: lookup table checksum mismatch");if(Kn(Qn(e.featureSpec))!==e.manifest.featureSpecHash)throw new Error("UNSUPPORTED_FEATURE_SPEC_HASH");if(e.expLutValues[0]!==1e12||e.expLutValues.at(-1)<=0||e.expLutValues.some((a,r,o)=>r>0&&a>o[r-1]))throw new Error("INVALID_LUT: nonpositive or non-monotone exponential table");const i=[e.baselines.legality,...Object.values(e.baselines.contact)];if(Object.keys(e.baselines.contact).length!==7||i.some(a=>a.reduce((r,o)=>r+o.baseWeight,0)!==1e4||new Set(a.map(r=>r.id)).size!==a.length))throw new Error("INVALID_SYNTHETIC_BASELINES");return e}function wc(n,e){if(!Number.isInteger(e)||e<0||e>=St)throw new Error("INVALID_UINT32: draw outside [0, 2^32)");if(n.length===0||n.length>32)throw new Error("INVALID_CUMULATIVE_MASS");let t=0,i=-1;for(let a=0;a<n.length;a++){const r=n[a];if(!Number.isSafeInteger(r.mass)||!Number.isSafeInteger(r.cumulative)||r.mass<0||r.cumulative!==t+r.mass||!r.allowed&&r.mass!==0||r.cumulative>St)throw new Error("INVALID_CUMULATIVE_MASS");i<0&&r.mass>0&&e<r.cumulative&&(i=a),t=r.cumulative}if(t!==St||i===-1)throw new Error("INVALID_CUMULATIVE_MASS: exact 2^32 coverage required");return{index:i,id:n[i].id}}function Nc(n=ne){const e=O1(n),t=Object.freeze(e.expLutValues.slice()),i=Ye($n);function a(o){In(o);const s=ga.parse(o);if(s.modelHash!==Bn||s.lutHash!==Ae)throw new Error("UNSUPPORTED_MODEL_OR_LUT_HASH");const d=s.categories.map(S=>S.id);if(new Set(d).size!==d.length)throw new Error("DUPLICATE_CATEGORY_ID: canonical category order requires unique IDs");const g=s.categories.map(S=>S.allowed&&S.baseWeight>0?L1(S):null),E=g.filter(S=>S!==null);if(!E.length)throw new Error("EMPTY_POSITIVE_MASK: no allowed category has positive weight");const h=E.reduce((S,R)=>S>R?S:R),f=g.map(S=>{if(S===null)return null;const R=BigInt(S)-BigInt(h),V=Number(-$t(R,A1));if(V<0||V>=t.length)throw new Error("INVALID_LUT_INDEX");return V}),A=s.categories.map((S,R)=>f[R]===null?0n:BigInt(S.baseWeight)*BigInt(t[f[R]])),N=A.reduce((S,R)=>S+R,0n);if(N<=0n)throw new Error("INVALID_PROBABILITY_TOTAL");const b=A.map(S=>S*Ac),w=b.map(S=>S/N),D=b.map(S=>S%N),p=Ac-w.reduce((S,R)=>S+R,0n);if(p<0n||p>=BigInt(A.length))throw new Error("INVALID_REMAINDER_ALLOCATION");const I=A.map((S,R)=>R).sort((S,R)=>{const V=D[S]-D[R];return V>0n?-1:V<0n?1:S-R});for(let S=0;S<Number(p);S++)w[I[S]]+=1n;let v=0;const y=s.categories.map((S,R)=>{const V=Number(w[R]);return v+=V,Object.freeze({id:S.id,allowed:S.allowed,logitBp:g[R],lutIndex:f[R],mass:V,cumulative:v})});if(v!==St)throw new Error("MASS_NOT_NORMALISED");return Object.freeze({probabilityVersion:zn,modelId:ge,modelHash:Bn,lutVersion:Se,lutHash:Ae,totalMass:St,categories:Object.freeze(y)})}function r(o){In(o);const s=vg.parse(o),d=a({probabilityVersion:s.probabilityVersion,modelId:s.modelId,modelHash:s.modelHash,lutVersion:s.lutVersion,lutHash:s.lutHash,categories:s.categories});if(s.kind==="NORMALISE_CATEGORIES")return{kind:s.kind,...d};if(s.address.stageName!==s.stageName)throw new Error("STAGE_ADDRESS_MISMATCH: draw address must name its probability stage");const g=i.uint32(s.address),E=wc(d.categories,g);return{kind:s.kind,...d,draw:g,selectedIndex:E.index,selectedCategoryId:E.id}}return Object.freeze({version:zn,modelId:ge,modelHash:Bn,lutHash:Ae,normalise:a,execute:r})}Nc();function w1(n){In(n);const e=Ag.parse(n),t={CONTROL:(e.controlRating-50)*200,FATIGUE:e.fatigueBp,LEG_LINE:e.line==="LEG"?1e4:0,MAXIMUM_EFFORT:e.effort==="MAXIMUM"?1e4:0,CONSERVE_EFFORT:e.effort==="CONSERVE"?1e4:0};return ne.baselines.legality.map(i=>{const a=Object.entries(ne.coefficients.legality).find(([o])=>o===i.id)?.[1],r=a?Object.entries(a).map(([o,s])=>{const d=t[o];if(d===void 0)throw new Error("UNKNOWN_LEGALITY_FEATURE");return{coefficientBp:s,featureBp:d}}):[];return{id:i.id,baseWeight:i.baseWeight,allowed:!0,interceptBp:0,terms:r}})}function N1(n){In(n);const e=Lg.parse(n),t={DEFENCE:(e.defenceRating-50)*200,TIMING:(e.timingRating-50)*200,POWER:(e.powerRating-50)*200,AGGRESSION:(e.aggression-2)*1e4,MOVEMENT:e.effectiveMovementBp};return ne.baselines.contact[e.phase].map(i=>{const a=Object.entries(ne.coefficients.contact).find(([o])=>o===i.id)?.[1];if(!a)throw new Error("MISSING_CONTACT_COEFFICIENT");const r=Object.entries(a).map(([o,s])=>{const d=t[o];if(d===void 0)throw new Error("UNKNOWN_CONTACT_FEATURE");return{coefficientBp:s,featureBp:d}});return{id:i.id,baseWeight:i.baseWeight,allowed:!0,interceptBp:0,terms:r}})}class no extends Error{code;constructor(e,t){super(`${e}: ${t}`),this.code=e,this.name="ResolutionValidationError"}}const sn=(n,e,t)=>{if(!n)throw new no(e,t)};function eo(n,e){const t=ft.safeParse(n),i=pi.safeParse(e);if(!t.success||!i.success)throw new no("INVALID_STRUCTURE","Context or resolution failed strict schema validation");const a=t.data,r=i.data,o=r.extras,s=r.dismissal;sn(a.deliveryIndex>=a.legalBalls,"INVALID_CONTEXT","Global delivery attempt index precedes legal-ball count"),sn(a.rulesId==="LC_RED5_01"?a.allocatedBalls===null&&a.inningsIndex<=3:a.allocatedBalls===(a.rulesId==="LC_T20_01"?120:300)&&a.inningsIndex<=1,"INVALID_CONTEXT","Base profile allocation or innings index invalid");const d=[a.strikerId,a.nonStrikerId,a.bowlerId,a.keeperId,...a.outfieldIds];sn(new Set(d).size===d.length&&a.battingTeamId!==a.bowlingTeamId,"INVALID_CONTEXT","IDs must be distinct"),sn(a.endsBefore[a.strikerEnd==="NORTH"?"north":"south"]===a.strikerId&&a.endsBefore[a.strikerEnd==="NORTH"?"south":"north"]===a.nonStrikerId,"INVALID_CONTEXT","Starting ends must identify both batters"),sn((a.allocatedBalls===null||a.legalBalls<a.allocatedBalls)&&(a.targetToWin===null||a.runs<a.targetToWin),"INVALID_CONTEXT","Innings already ended"),sn(a.rulesId!=="LC_RED5_01"||!a.freeHitPending,"INVALID_CONTEXT","Red-ball profile has no free hit"),sn(o.penalties===0,"UNSUPPORTED_PENALTY","Penalty scoring requires a later administrative contract");const g=r.batRuns+o.wides+o.noBalls+o.byes+o.legByes;if(sn(Number.isSafeInteger(g)&&Number.isSafeInteger(a.runs+g)&&Number.isSafeInteger(a.legalBalls+1)&&Number.isSafeInteger(a.deliveryIndex+1)&&Number.isSafeInteger(a.ballAgeLegalBalls+1),"UNSAFE_TOTAL","Counter arithmetic must remain safe"),sn(!(o.byes>0&&o.legByes>0)&&!(r.batRuns>0&&(o.byes>0||o.legByes>0)),"INVALID_EXTRAS","Conflicting run channels"),sn(!(r.batContact&&(o.byes>0||o.legByes>0))&&(o.legByes===0||r.attemptedStroke)&&(r.batRuns===0||r.batContact),"INVALID_EXTRAS","Contact/stroke evidence inconsistent"),r.legality==="LEGAL"&&sn(o.wides===0&&o.noBalls===0,"INVALID_EXTRAS","Legal ball cannot charge wide/no-ball"),r.legality==="NO_BALL"&&sn(o.noBalls===1&&o.wides===0,"INVALID_EXTRAS","No-ball overrides wide and carries one automatic run"),r.legality==="WIDE"&&sn(o.wides>=1&&o.noBalls===0&&o.byes===0&&o.legByes===0&&r.batRuns===0&&!r.batContact,"INVALID_EXTRAS","Wide channel is exclusive"),r.legality==="DEAD"&&sn(g===0&&s===null&&r.completedRuns===0&&r.attemptedRuns===0&&!r.batContact&&r.boundary==="NONE"&&r.fieldOutcome==="NONE","INVALID_EXTRAS","Early dead ball cannot score or dismiss"),r.boundary!=="NONE"?sn(r.completedRuns===0&&r.attemptedRuns===0&&s===null&&g-o.noBalls-(r.legality==="WIDE"?1:0)===(r.boundary==="FOUR"?4:6)&&(r.boundary!=="SIX"||r.batRuns===6&&r.batContact),"INVALID_BOUNDARY","Boundary allowance incompatible with running/dismissal"):sn(r.completedRuns===r.batRuns+o.byes+o.legByes+Math.max(0,o.wides-1),"INVALID_RUNNING","Completed runs exclude automatic penalties"),sn(r.attemptedRuns===r.completedRuns+(s?.kind==="RUN_OUT"?1:0),"INVALID_RUNNING","Only the failed run-out attempt remains uncompleted"),r.stage==="IMMEDIATE_PENALTY")sn((r.legality==="WIDE"||r.legality==="NO_BALL")&&a.targetToWin!==null&&a.runs+1>=a.targetToWin&&g===1&&r.batRuns===0&&r.completedRuns===0&&r.attemptedRuns===0&&s===null&&r.boundary==="NONE"&&!r.batContact&&r.trajectory===null&&r.shotSector===null&&r.fieldOutcome==="NONE","INVALID_IMMEDIATE_PENALTY","Winning automatic extra must terminate before contact or dismissal");else if((r.legality==="WIDE"||r.legality==="NO_BALL")&&a.targetToWin!==null&&a.runs+1>=a.targetToWin)throw new no("INVALID_IMMEDIATE_PENALTY","Immediate winning extra requires truncated resolution");sn(!(a.targetToWin!==null&&a.runs+g>=a.targetToWin&&s!==null),"INVALID_DISMISSAL","Result achieved before a later dismissal"),sn(!(a.targetToWin!==null&&r.boundary==="NONE"&&a.runs+g>a.targetToWin),"INVALID_RUNNING","Running cannot continue past the winning run"),s&&(sn(s.playerId===a.strikerId||s.playerId===a.nonStrikerId,"INVALID_DISMISSAL","Dismissed player must be active"),sn(s.kind==="RUN_OUT"||s.playerId===a.strikerId,"INVALID_DISMISSAL","Only a run-out may dismiss the non-striker"),sn(!(r.legality==="NO_BALL"||a.freeHitPending)||s.kind==="RUN_OUT","INVALID_DISMISSAL","No-ball/free-hit mask"),sn(r.legality!=="WIDE"||["RUN_OUT","STUMPED","HIT_WICKET"].includes(s.kind),"INVALID_DISMISSAL","Wide dismissal mask"),sn(r.legality!=="DEAD","INVALID_DISMISSAL","Dead-ball dismissal"),sn(s.fielderId===null||[a.bowlerId,a.keeperId,...a.outfieldIds].includes(s.fielderId),"INVALID_DISMISSAL","Unknown fielder"),s.kind==="CAUGHT"&&sn(r.batContact&&["AERIAL","EDGE"].includes(r.trajectory??"")&&s.fielderId!==null&&r.fieldOutcome==="CATCH"&&r.batRuns===0,"INVALID_DISMISSAL","Catch requires bat contact, fielder and zero bat runs"),s.kind==="STUMPED"&&sn(s.fielderId===a.keeperId&&!r.batContact&&r.attemptedRuns===0,"INVALID_DISMISSAL","Stumping requires keeper and no run attempted"),s.kind==="RUN_OUT"&&sn(s.fielderId!==null&&r.fieldOutcome==="RUN_OUT","INVALID_DISMISSAL","Run-out needs a fielder and outcome"),["BOWLED","LBW","HIT_WICKET"].includes(s.kind)&&sn(s.fielderId===null,"INVALID_DISMISSAL","Unassisted dismissal"),s.kind==="LBW"&&sn(!r.batContact,"INVALID_DISMISSAL","LBW cannot follow bat contact"),s.kind!=="RUN_OUT"&&sn(s.wicketEnd===a.strikerEnd&&r.completedRuns===0,"INVALID_DISMISSAL","Supported non-run-out dismissal is at striker end without completed runs")),sn(r.fieldOutcome!=="CATCH"||s?.kind==="CAUGHT","INVALID_DISMISSAL","Ineligible catch must be a stop, not a credited catch"),sn(r.fieldOutcome!=="RUN_OUT"||s?.kind==="RUN_OUT","INVALID_DISMISSAL","Run-out outcome requires a dismissal");const E=[r.endsAfter.north,r.endsAfter.south].filter(h=>h!==null);if(s)sn(E.length===1&&E[0]===(s.playerId===a.strikerId?a.nonStrikerId:a.strikerId),"INVALID_ENDS","Exactly the surviving batter occupies an end");else{const h=r.completedRuns%2===1;sn(r.endsAfter.north===a.endsBefore[h?"south":"north"]&&r.endsAfter.south===a.endsBefore[h?"north":"south"],"INVALID_ENDS","Physical running determines ends")}return s&&s.kind!=="RUN_OUT"&&sn(r.endsAfter[a.strikerEnd==="NORTH"?"north":"south"]===null,"INVALID_ENDS","Incoming batter belongs at dismissed striker end"),{context:a,resolution:r}}class D1 extends Error{code;constructor(e,t){super(`${e}: ${t}`),this.code=e,this.name="ScoringInvariantError"}}function an(n,e,t){if(!n)throw new D1(e,t)}function Rn(...n){let e=0;for(const t of n)an(Number.isSafeInteger(t)&&t>=0,"UNSAFE_COUNTER","Counter is not a safe non-negative integer"),e+=t,an(Number.isSafeInteger(e),"UNSAFE_COUNTER","Counter overflow");return e}function to(n,e){const{context:t,resolution:i}=eo(n,e);return ui.parse({type:"DELIVERY_RECORDED",inningsIndex:t.inningsIndex,deliveryIndex:t.deliveryIndex,strikerId:t.strikerId,nonStrikerId:t.nonStrikerId,bowlerId:t.bowlerId,legality:i.legality,legalBall:i.legality==="LEGAL",countsAsBallFaced:i.legality==="LEGAL"||i.legality==="NO_BALL",batRuns:i.batRuns,extras:i.extras,completedRuns:i.completedRuns,boundary:i.boundary,dismissal:i.dismissal?{...i.dismissal,creditedBowlerId:i.dismissal.kind==="RUN_OUT"?null:t.bowlerId}:null,endsAfter:i.endsAfter,shotSector:i.shotSector,trajectory:i.trajectory,executedLength:i.executedLength,fieldOutcome:i.fieldOutcome,elapsedSeconds:i.elapsedSeconds,freeHitNext:t.rulesId!=="LC_RED5_01"&&(i.legality==="NO_BALL"||t.freeHitPending&&i.legality!=="LEGAL")})}function y1(n,e){const t=ft.parse(n),i=ui.parse(e);for(const s of["inningsIndex","deliveryIndex","strikerId","nonStrikerId","bowlerId"])an(i[s]===t[s],"EVENT_CONTEXT_MISMATCH",s);an(i.legalBall===(i.legality==="LEGAL"),"INVALID_EVENT_FLAGS","legalBall"),an(i.countsAsBallFaced===(i.legality==="LEGAL"||i.legality==="NO_BALL"),"INVALID_EVENT_FLAGS","countsAsBallFaced");const a=t.rulesId!=="LC_RED5_01"&&(i.legality==="NO_BALL"||t.freeHitPending&&i.legality!=="LEGAL");an(i.freeHitNext===a,"INVALID_EVENT_FLAGS","freeHitNext"),i.dismissal&&an(i.dismissal.creditedBowlerId===(i.dismissal.kind==="RUN_OUT"?null:t.bowlerId),"INVALID_WICKET_CREDIT","Dismissal credit differs from its kind");const{creditedBowlerId:r,...o}=i.dismissal??{creditedBowlerId:null};return eo(t,{stage:(i.legality==="WIDE"||i.legality==="NO_BALL")&&t.targetToWin!==null&&t.runs+1>=t.targetToWin?"IMMEDIATE_PENALTY":"DELIVERY",legality:i.legality,batRuns:i.batRuns,extras:i.extras,completedRuns:i.completedRuns,attemptedRuns:i.completedRuns+(i.dismissal?.kind==="RUN_OUT"?1:0),boundary:i.boundary,dismissal:i.dismissal?o:null,endsAfter:i.endsAfter,batContact:i.batRuns>0||i.dismissal?.kind==="CAUGHT",attemptedStroke:!0,shotSector:i.shotSector,trajectory:i.trajectory,executedLength:i.executedLength,fieldOutcome:i.fieldOutcome,elapsedSeconds:i.elapsedSeconds}),{context:t,event:i}}function C1(n,e){const{context:t,event:i}=y1(n,e),a=i.extras,r={teamRuns:Rn(i.batRuns,a.wides,a.noBalls,a.byes,a.legByes,a.penalties),batterRuns:i.batRuns,bowlerRuns:Rn(i.batRuns,a.wides,a.noBalls),legalBalls:Number(i.legalBall),ballsFaced:Number(i.countsAsBallFaced),wickets:+(i.dismissal!==null),bowlerWickets:+(i.dismissal?.creditedBowlerId!==null&&i.dismissal!==null),deliveryAttempts:1},o={runs:Rn(t.runs,r.teamRuns),wickets:Rn(t.wickets,r.wickets),legalBalls:Rn(t.legalBalls,r.legalBalls),ballAgeLegalBalls:Rn(t.ballAgeLegalBalls,r.legalBalls)},s=i.legalBall&&o.legalBalls%6===0,d=s?t.strikerEnd==="NORTH"?"SOUTH":"NORTH":t.strikerEnd,g=t.targetToWin!==null&&o.runs>=t.targetToWin,E=g||o.wickets===10||t.allocatedBalls!==null&&o.legalBalls>=t.allocatedBalls;let h=null;g?h={kind:"WIN",winnerTeamId:t.battingTeamId,marginType:"WICKETS",marginRuns:null,marginWickets:10-o.wickets,completionReason:"TARGET_REACHED"}:E&&t.targetToWin!==null&&(o.runs===t.targetToWin-1?h={kind:"TIE",winnerTeamId:null,marginType:null,marginRuns:null,marginWickets:null,completionReason:"CHASE_COMPLETE_LEVEL"}:h={kind:"WIN",winnerTeamId:t.bowlingTeamId,marginType:"RUNS",marginRuns:t.targetToWin-1-o.runs,marginWickets:null,completionReason:"CHASE_COMPLETE_SHORT"});const f=E||!i.dismissal?null:i.endsAfter.north===null?"NORTH":"SOUTH",A=E?null:i.endsAfter[d==="NORTH"?"north":"south"],N=h?"NONE":E?"START_NEXT_INNINGS":f?"SELECT_BATTER":s?"SELECT_BOWLER":"ADVANCE",b=["DELIVERY_RECORDED"];return s&&b.push("OVER_COMPLETED"),E&&b.push("INNINGS_COMPLETED"),h&&b.push("MATCH_COMPLETED"),Nr.parse({event:i,delta:r,totals:o,strikerEndAfter:d,nextStrikerId:A,requiredBatterEnd:f,freeHitPending:i.freeHitNext,overCompleted:s,inningsComplete:E,result:h,events:b,nextAction:N})}function ee(n){const e=Ig.parse(n),t=e.innings,i=Object.keys(e.batting),a=Object.keys(e.bowling);an(t.battingTeamId!==t.bowlingTeamId,"INVALID_LEDGER","Teams must differ"),an(t.battingOrder.length===11&&new Set(t.battingOrder).size===11&&i.length===11&&t.battingOrder.every(s=>Object.hasOwn(e.batting,s)),"INVALID_LEDGER","Batting order must identify eleven ledger players"),an(a.length===11&&[e.keeperId,...e.outfieldIds,...t.bowlerId?[t.bowlerId]:[]].every(s=>Object.hasOwn(e.bowling,s)),"INVALID_LEDGER","Bowling references missing"),an(new Set([e.keeperId,...e.outfieldIds]).size===10&&!a.some(s=>Object.hasOwn(e.batting,s)),"INVALID_LEDGER","Field identities overlap"),an(new Set(t.dismissed).size===t.dismissed.length&&t.dismissed.length===t.wickets&&t.dismissed.every(s=>e.batting[s]?.dismissed),"INVALID_LEDGER","Dismissed identities mismatch"),an(i.filter(s=>e.batting[s].dismissed).length===t.wickets,"INVALID_LEDGER","Dismissal flags mismatch"),an(t.complete||!(t.wickets===10||t.allocatedBalls!==null&&t.legalBalls>=t.allocatedBalls||t.targetToWin!==null&&t.runs>=t.targetToWin),"INVALID_LEDGER","Terminal innings must be marked complete");const r=e.rulesId==="LC_T20_01"?24:e.rulesId==="LC_ODI_01"?60:null;an(r===null||Object.values(e.bowling).every(s=>s.legalBalls<=r),"BOWLER_QUOTA","Stored quota exceeded");const o=[t.northBatterId,t.southBatterId].filter(s=>s!==null);an(new Set(o).size===o.length&&o.every(s=>Object.hasOwn(e.batting,s)&&!e.batting[s].dismissed),"INVALID_LEDGER","Invalid end occupancy"),an(Rn(...Object.values(e.batting).map(s=>s.runs),...Object.values(t.extras))===t.runs,"SCORE_RECONCILIATION","Bat runs plus extras must equal innings runs"),an(Rn(...Object.values(e.bowling).map(s=>s.legalBalls))===t.legalBalls,"BALL_RECONCILIATION","Bowler legal-ball counts must reconcile"),an(Rn(...Object.values(e.bowling).map(s=>s.runsConceded))===t.runs-t.extras.byes-t.extras.legByes-t.extras.penalties,"SCORE_RECONCILIATION","Bowler conceded runs mismatch"),an(Object.keys(e.dismissals).length===t.wickets&&t.dismissed.every(s=>e.dismissals[s]?.playerId===s),"WICKET_RECONCILIATION","Dismissal records missing");for(const s of a)an(e.bowling[s].wickets===Object.values(e.dismissals).filter(d=>d.creditedBowlerId===s).length,"WICKET_RECONCILIATION","Bowler credits must match dismissal records");for(const s of Object.values(e.dismissals))an((s.kind==="RUN_OUT"?s.creditedBowlerId===null:s.creditedBowlerId!==null&&Object.hasOwn(e.bowling,s.creditedBowlerId))&&(s.fielderId===null||Object.hasOwn(e.bowling,s.fielderId)),"WICKET_RECONCILIATION","Invalid historical dismissal credit");an(Rn(...Object.values(e.batting).map(s=>s.ballsFaced))===Rn(t.legalBalls,t.extras.noBalls),"BALL_RECONCILIATION","Batter balls faced must equal legal deliveries plus delivered no-balls"),an(Object.keys(t.bowlerLegalBalls).length===a.length&&a.every(s=>t.bowlerLegalBalls[s]===e.bowling[s].legalBalls),"BALL_RECONCILIATION","Bowler quota map mismatch"),an(t.deliveryAttempts>=t.legalBalls&&e.nextDeliveryIndex>=t.deliveryAttempts&&t.ballAgeLegalBalls<=t.legalBalls,"INVALID_LEDGER","Delivery/ball-age counters inconsistent"),an(t.bowlerId!==null||e.currentOverRuns===0,"INVALID_LEDGER","No active bowler for unfinished over runs"),t.bowlerId&&an(t.bowlerId!==e.keeperId&&!e.outfieldIds.includes(t.bowlerId),"INVALID_LEDGER","Bowler cannot occupy keeper/outfield slot"),t.previousOverBowlerId!==null&&an(Object.hasOwn(e.bowling,t.previousOverBowlerId),"INVALID_LEDGER","Previous bowler absent");for(const s of Object.values(e.batting))an(Rn(s.fours*4,s.sixes*6)<=s.runs,"INVALID_LEDGER","Boundary counters exceed bat runs");for(const s of Object.values(e.bowling))an(s.maidens<=Math.floor(s.legalBalls/6),"INVALID_LEDGER","Maiden counter exceeds completed overs");return an(e.rulesId==="LC_RED5_01"?t.allocatedBalls===null&&t.index<=3:t.allocatedBalls===(e.rulesId==="LC_T20_01"?120:300)&&t.index<=1,"INVALID_LEDGER","Unsupported profile allocation/index"),an(e.rulesId!=="LC_RED5_01"||!t.freeHitPending,"INVALID_LEDGER","Red-ball free hit"),e}function Oe(n){const e=ee(n),t=e.innings;an(!t.complete,"INNINGS_COMPLETE","No more delivery after completion"),an(t.northBatterId!==null&&t.southBatterId!==null,"BATTER_REQUIRED","Both ends need selected batters"),an(t.bowlerId!==null,"BOWLER_REQUIRED","Select a bowler");const i=e.rulesId==="LC_T20_01"?24:e.rulesId==="LC_ODI_01"?60:null;return an(i===null||e.bowling[t.bowlerId].legalBalls<i,"BOWLER_QUOTA","Active bowler exhausted"),ft.parse({rulesId:e.rulesId,inningsIndex:t.index,deliveryIndex:e.nextDeliveryIndex,battingTeamId:t.battingTeamId,bowlingTeamId:t.bowlingTeamId,strikerId:t.strikerEnd==="NORTH"?t.northBatterId:t.southBatterId,nonStrikerId:t.strikerEnd==="NORTH"?t.southBatterId:t.northBatterId,bowlerId:t.bowlerId,keeperId:e.keeperId,outfieldIds:e.outfieldIds,endsBefore:{north:t.northBatterId,south:t.southBatterId},strikerEnd:t.strikerEnd,runs:t.runs,wickets:t.wickets,legalBalls:t.legalBalls,allocatedBalls:t.allocatedBalls,targetToWin:t.targetToWin,freeHitPending:t.freeHitPending,ballAgeLegalBalls:t.ballAgeLegalBalls})}function io(n,e){const t=ee(n),i=Oe(t),a=C1(i,e),r=a.event,o=t.innings,s=t.rulesId==="LC_T20_01"?24:t.rulesId==="LC_ODI_01"?60:null;an(s===null||t.bowling[r.bowlerId].legalBalls+a.delta.legalBalls<=s,"BOWLER_QUOTA","Bowler quota exceeded"),an(o.previousOverBowlerId!==r.bowlerId,"CONSECUTIVE_OVERS","Previous over bowler cannot bowl this over");const d=t.batting[r.strikerId],g=t.bowling[r.bowlerId];d.runs=Rn(d.runs,a.delta.batterRuns),d.ballsFaced=Rn(d.ballsFaced,a.delta.ballsFaced),r.boundary==="FOUR"&&r.batRuns===4&&(d.fours=Rn(d.fours,1)),r.boundary==="SIX"&&r.batRuns===6&&(d.sixes=Rn(d.sixes,1)),r.dismissal&&(t.batting[r.dismissal.playerId].dismissed=!0,t.dismissals[r.dismissal.playerId]=r.dismissal,o.dismissed.push(r.dismissal.playerId)),g.runsConceded=Rn(g.runsConceded,a.delta.bowlerRuns),g.legalBalls=Rn(g.legalBalls,a.delta.legalBalls),g.wickets=Rn(g.wickets,a.delta.bowlerWickets),t.currentOverRuns=Rn(t.currentOverRuns,a.delta.bowlerRuns),a.overCompleted&&(t.currentOverRuns===0&&(g.maidens=Rn(g.maidens,1)),t.currentOverRuns=0,o.previousOverBowlerId=r.bowlerId,o.bowlerId=null),o.runs=a.totals.runs,o.wickets=a.totals.wickets,o.legalBalls=a.totals.legalBalls,o.ballAgeLegalBalls=a.totals.ballAgeLegalBalls,o.deliveryAttempts=Rn(o.deliveryAttempts,1),o.strikerEnd=a.strikerEndAfter,o.northBatterId=r.endsAfter.north,o.southBatterId=r.endsAfter.south,o.freeHitPending=a.freeHitPending,o.complete=a.inningsComplete;for(const E of["wides","noBalls","byes","legByes","penalties"])o.extras[E]=Rn(o.extras[E],r.extras[E]);return o.bowlerLegalBalls[r.bowlerId]=g.legalBalls,t.nextDeliveryIndex=Rn(t.nextDeliveryIndex,1),{ledger:ee(t),observation:a}}function wi(n,e){const t=ee(n),i=t.innings;return an(!i.complete,"INNINGS_COMPLETE","Cannot select after completion"),an(Object.hasOwn(t.batting,e)&&!t.batting[e].dismissed&&![i.northBatterId,i.southBatterId].includes(e),"ILLEGAL_BATTER","Player must be available and not already at an end"),an(i.northBatterId===null!=(i.southBatterId===null),"ILLEGAL_SELECTION","Exactly one replacement end must be empty"),i.northBatterId===null?i.northBatterId=e:i.southBatterId=e,ee(t)}function ao(n,e,t){const i=ee(n),a=i.innings;an(!a.complete,"INNINGS_COMPLETE","Cannot select after completion"),an(a.northBatterId!==null&&a.southBatterId!==null,"BATTER_REQUIRED","Batter decision has priority"),an(a.bowlerId===null&&a.legalBalls%6===0,"ILLEGAL_SELECTION","Bowler selection only at an over boundary"),an(Object.hasOwn(i.bowling,e)&&e!==i.keeperId&&e!==a.previousOverBowlerId,"ILLEGAL_BOWLER","Unknown, keeping or consecutive bowler");const r=i.rulesId==="LC_T20_01"?24:i.rulesId==="LC_ODI_01"?60:null;return an(r===null||i.bowling[e].legalBalls<r,"BOWLER_QUOTA","Quota exhausted"),a.bowlerId=e,i.outfieldIds=[...t],ee(i)}const k1=Object.freeze({EXECUTED_LENGTH:Object.freeze({stageName:"length",drawIndex:0}),LEGALITY:Object.freeze({stageName:"legality",drawIndex:0}),CONTACT:Object.freeze({stageName:"contact",drawIndex:0}),SECTOR:Object.freeze({stageName:"sector",drawIndex:0}),IMMEDIATE_DISMISSAL:Object.freeze({stageName:"dismissal",drawIndex:0}),STUMPING:Object.freeze({stageName:"dismissal",drawIndex:1}),FIELD_CHANCE:Object.freeze({stageName:"fielding",drawIndex:0}),FIELD_CONVERSION:Object.freeze({stageName:"fielding",drawIndex:1}),RUNS:Object.freeze({stageName:"running",drawIndex:0}),RUN_OUT:Object.freeze({stageName:"running",drawIndex:1}),RUN_OUT_END:Object.freeze({stageName:"running",drawIndex:2})}),Dc=Nc(),B1=Ye($n),P1=["0","1","2","3","4","6"],Ni=["YORKER","FULL","GOOD","SHORT"],yc=10000n;function Cc(n){if(n&&typeof n=="object"&&!Object.isFrozen(n)){for(const e of Object.values(n))Cc(e);Object.freeze(n)}return n}function x1(n,e,t){return n<e?e:n>t?t:n}function Di(n,e){return Number($t(BigInt(n)*BigInt(e),yc))}function Te(n){return(n-50)*200}function yn(n,e,t=0,i=[],a=!0){return{id:n,baseWeight:e,interceptBp:t,terms:[...i],allowed:a}}function yi(n,e){return n==="RED_BALL"?"RED_BALL":n==="T20"?e<36?"T20_EARLY":e<90?"T20_MIDDLE":"T20_LATE":e<60?"ODI_EARLY":e<240?"ODI_MIDDLE":"ODI_LATE"}function oo(n){const e=ke.find(t=>t.rulesId===n);if(!e)throw new Error("UNSUPPORTED_GENERATOR_RULES");return Kn(Qn(e))}function F1(n){In(n);const e=Cg.parse(n);if(e.stagePackHash!==jn||Kn(Qn(ln))!==jn||e.modelHash!==Bn||e.lutHash!==Ae||e.stagePackId!==yr||e.generatorVersion!==Ii||e.probabilityVersion!==zn||e.modelId!==ge||e.lutVersion!==Se||e.randomVersion!==$n)throw new Error("UNSUPPORTED_GENERATOR_PACK_OR_VERSION");if(e.rulesHash!==oo(e.context.rulesId))throw new Error("UNSUPPORTED_RULES_HASH");const t=e.context.rulesId==="LC_T20_01"?"T20":e.context.rulesId==="LC_ODI_01"?"ODI":"RED_BALL";if(e.format!==t||e.phase!==yi(t,e.context.legalBalls))throw new Error("INCONSISTENT_FORMAT_OR_PHASE");if(e.attemptOrdinal!==e.context.deliveryIndex)throw new Error("ATTEMPT_ORDINAL_MISMATCH");if(`${e.matchId}:${e.context.inningsIndex}`.length>128)throw new Error("RANDOM_ENTITY_ID_TOO_LONG");if(e.context.bowlerId===e.context.strikerId||e.context.bowlerId===e.context.nonStrikerId||e.context.strikerId===e.context.nonStrikerId||e.context.endsBefore[e.context.strikerEnd==="NORTH"?"north":"south"]!==e.context.strikerId||e.context.endsBefore[e.context.strikerEnd==="NORTH"?"south":"north"]!==e.context.nonStrikerId)throw new Error("INCONSISTENT_BATTER_ENDS");if(e.context.runs>=(e.context.targetToWin??Number.MAX_SAFE_INTEGER)||e.context.allocatedBalls!==(t==="T20"?120:t==="ODI"?300:null)||e.context.allocatedBalls!==null&&e.context.legalBalls>=e.context.allocatedBalls||t==="RED_BALL"&&e.context.freeHitPending||e.context.wickets>=10||e.attemptOrdinal<e.context.legalBalls)throw new Error("INNINGS_NOT_READY_FOR_GENERATOR");const i=e.field.slots.map(a=>a.playerId);if(new Set(i).size!==9||[...i].sort().join("\0")!==[...e.context.outfieldIds].sort().join("\0")||new Set([e.context.strikerId,e.context.nonStrikerId,e.context.bowlerId,e.context.keeperId,...i]).size!==13||e.batting.shotSectorWeights.every(a=>a===0))throw new Error("INVALID_GENERATOR_FIELD_OR_SECTORS");return e}function H1(n){const i=((!["FAST","MEDIUM"].includes(n.bowling.bowlingStyle)?n.conditions.turnBp:n.conditions.seamBp)-5e3)*2;return x1(Te(n.bowling.movementRating)+Di(2500,i)-Di(2500,n.bowling.fatigueBp),-1e4,1e4)}function M1(n){const e=n.bowling.intendedLength,t=Ni.indexOf(e),i=new Map([[e,ln.length.intended]]),a=[Ni[t-1],Ni[t+1]].filter(d=>d!==void 0),r=ln.length.neighboursTotal/a.length;for(const d of a)i.set(d,(i.get(d)??0)+r);const o=t<2?"FULL_TOSS":"FULL";i.set(o,(i.get(o)??0)+ln.length.gross);const s=[{coefficientBp:ln.length.intendedControlBp,featureBp:Te(n.bowling.controlRating)},{coefficientBp:ln.length.intendedFatigueBp,featureBp:n.bowling.fatigueBp}];return[...Ni,"FULL_TOSS"].filter(d=>(i.get(d)??0)>0).map(d=>yn(d,i.get(d),0,d===e?s:[]))}function V1(n,e,t){const i=N1({phase:n.phase,defenceRating:n.batting.defenceRating,timingRating:n.batting.timingRating,powerRating:n.batting.powerRating,effectiveMovementBp:H1(n),aggression:n.batting.aggression}),a=Te(["FAST","MEDIUM"].includes(n.bowling.bowlingStyle)?n.batting.vsPaceRating:n.batting.vsSpinRating);return i.map(r=>{const o=[];function s(d){o.push({coefficientBp:d,featureBp:1e4})}return e==="YORKER"&&r.id==="MISS"&&s(2e3),e==="YORKER"&&r.id==="AERIAL"&&s(-1e3),e==="FULL_TOSS"&&r.id==="AERIAL"&&s(5e3),e==="FULL_TOSS"&&r.id==="GROUND"&&s(2e3),e==="SHORT"&&(r.id==="AERIAL"||r.id==="EDGE")&&s(1500),(r.id==="MISS"||r.id==="EDGE")&&o.push({coefficientBp:-2e3,featureBp:a}),r.id==="GROUND"&&o.push({coefficientBp:2e3,featureBp:a}),{...r,allowed:!(t&&r.id==="HIT_WICKET"),terms:[...r.terms,...o]}})}function W1(n){return n.batting.shotSectorWeights.map((t,i)=>{const r=(n.bowling.line==="OFF"?i<=2:n.bowling.line==="STUMPS"?i===3||i===4:i>=5)?Number($t(BigInt(t)*BigInt(ln.sectorLineMultiplierBp),yc)):t;return yn(`SECTOR_${i}`,r)})}function $1(n,e,t){const i=n.field.slots.map(a=>{const r=(a.sector-e+8)%8,o=r===0?1e4:r===1||r===7?ln.coverage.neighbourBp:0,s=t==="GROUND"?ln.coverage.ground[a.depth]:ln.coverage.aerial[a.depth],d=t==="EDGE"?a.role==="SLIP"?1e4:a.role==="GULLY"?6e3:1e3:Di(s,o);return{playerId:a.playerId,coverageBp:d,catchingRating:a.catchingRating,throwingRating:a.throwingRating,role:a.role}});return t==="EDGE"&&i.push({playerId:n.context.keeperId,coverageBp:1e4,catchingRating:n.field.keeper.catchingRating,throwingRating:n.field.keeper.throwingRating,role:"KEEPER"}),i.sort((a,r)=>r.coverageBp-a.coverageBp||(a.playerId<r.playerId?-1:a.playerId>r.playerId?1:0)),i[0]}function U1(n,e,t){const i=e==="MISS",a=i?ln.bowled:ln.lbw,r=!t&&(i||n.bowling.line!=="LEG");return[yn(i?"BOWLED":"LBW",1,a.interceptBp,[{coefficientBp:a.controlBp,featureBp:Te(n.bowling.controlRating)},{coefficientBp:a.defenceBp,featureBp:Te(n.batting.defenceRating)},...i&&n.bowling.line==="STUMPS"?[{coefficientBp:ln.bowled.stumpsBp,featureBp:1e4}]:[]],r),yn("NONE",1)]}function G1(n,e,t){const i=ln.runs[e],a=Te(n.batting.timingRating),r=Te(n.batting.powerRating),o=Te(n.batting.rotationRating);return P1.map((s,d)=>{const g=[];s==="0"&&g.push({coefficientBp:5e3,featureBp:t},{coefficientBp:-3e3,featureBp:o}),s==="1"&&n.batting.intent!=="NORMAL"&&g.push({coefficientBp:n.batting.intent==="ROTATE"?3500:-5e3,featureBp:1e4}),(s==="4"||s==="6")&&g.push({coefficientBp:4e3,featureBp:a},{coefficientBp:5e3,featureBp:r},{coefficientBp:-7e3,featureBp:t});const E=Number(s),h=n.context.targetToWin===null?null:n.context.targetToWin-n.context.runs;return yn(s,i[d],0,g,h===null||E<=h||E>=4)})}function z1(n,e,t,i){const a=n.context.targetToWin===null?null:n.context.targetToWin-n.context.runs-i,r=a===null||t-1<a;return[yn("RUN_OUT",1,ln.running.interceptBp,[{coefficientBp:ln.running.throwingBp,featureBp:Te(e.throwingRating)},{coefficientBp:ln.running.coverageBp,featureBp:e.coverageBp},{coefficientBp:ln.running.rotateBp,featureBp:n.batting.intent==="ROTATE"?1e4:0}],r),yn("SAFE",1)]}function ro(n){const e=F1(n),t=[],i=new Set;function a(S,R){const V=k1[S],U={seed:e.seed,domain:"MATCH_DELIVERY",entityId:`${e.matchId}:${e.context.inningsIndex}`,eventOrdinal:e.attemptOrdinal,stageName:V.stageName,drawIndex:V.drawIndex},H=JSON.stringify(U);if(i.has(H))throw new Error("DUPLICATE_DELIVERY_DRAW_ADDRESS");i.add(H);const en=Dc.normalise({probabilityVersion:zn,modelId:ge,modelHash:Bn,lutVersion:Se,lutHash:Ae,categories:R}),P=B1.uint32(U),x=wc(en.categories,P);return t.push({stageName:V.stageName,address:U,draw:P,selectedCategoryId:x.id,categories:en.categories}),x.id}const r=a("EXECUTED_LENGTH",M1(e)),o=a("LEGALITY",w1({controlRating:e.bowling.controlRating,fatigueBp:e.bowling.fatigueBp,line:e.bowling.line,effort:e.bowling.effort})),s=e.context,d={wides:0,noBalls:0,byes:0,legByes:0,penalties:0},g={stage:"DELIVERY",legality:o,batRuns:0,extras:d,completedRuns:0,attemptedRuns:0,boundary:"NONE",dismissal:null,endsAfter:{...s.endsBefore},batContact:!1,attemptedStroke:e.batting.attemptedStroke,shotSector:null,trajectory:null,executedLength:r,fieldOutcome:"NONE",elapsedSeconds:ln.elapsedSeconds};function E(S){const R=eo(s,S).resolution;return Cc(Bg.parse({kind:"GENERATED_DELIVERY",generatorVersion:Ii,modelHash:Bn,stagePackHash:jn,internalOnly:!0,trace:t,resolution:R}))}if(o==="WIDE"&&(d.wides=1),o==="NO_BALL"&&(d.noBalls=1),(o==="WIDE"||o==="NO_BALL")&&s.targetToWin!==null&&s.runs+1>=s.targetToWin)return E({...g,stage:"IMMEDIATE_PENALTY",batContact:!1,attemptedStroke:!1});const h=o==="NO_BALL"||s.freeHitPending,f=o==="WIDE"?"WIDE":a("CONTACT",V1(e,r,h));if(f==="HIT_WICKET")return g.dismissal={kind:"HIT_WICKET",playerId:s.strikerId,fielderId:null,wicketEnd:s.strikerEnd},g.endsAfter[s.strikerEnd==="NORTH"?"north":"south"]=null,E(g);if(f==="MISS"||f==="PAD"){const S=a("IMMEDIATE_DISMISSAL",U1(e,f,h));if(S!=="NONE")return g.dismissal={kind:S,playerId:s.strikerId,fielderId:null,wicketEnd:s.strikerEnd},g.endsAfter[s.strikerEnd==="NORTH"?"north":"south"]=null,E(g)}let A={playerId:s.keeperId,coverageBp:0,catchingRating:e.field.keeper.catchingRating,throwingRating:e.field.keeper.throwingRating};if(f==="GROUND"||f==="AERIAL"||f==="EDGE")if(g.batContact=!0,g.trajectory=f,g.shotSector=Number(a("SECTOR",W1(e)).split("_")[1]),A=$1(e,g.shotSector,f),f==="AERIAL"||f==="EDGE")if(!h&&A.coverageBp>0){const S=Di(ln.catchOpportunityBp[f],A.coverageBp);if(a("FIELD_CHANCE",[yn("CHANCE",S),yn("NO_CHANCE",1e4-S)])==="CHANCE"){if(a("FIELD_CONVERSION",[yn("CATCH",1,ln.catchConversion.interceptBp,[{coefficientBp:ln.catchConversion.catchingBp,featureBp:Te(A.catchingRating)}]),yn("DROP",1)])==="CATCH")return g.fieldOutcome="CATCH",g.dismissal={kind:"CAUGHT",playerId:s.strikerId,fielderId:A.playerId,wicketEnd:s.strikerEnd},g.endsAfter[s.strikerEnd==="NORTH"?"north":"south"]=null,E(g);g.fieldOutcome="DROP"}else g.fieldOutcome=A.coverageBp>0?"STOP":"NONE"}else g.fieldOutcome=A.coverageBp>0?"STOP":"NONE";else g.fieldOutcome=A.coverageBp>0?"STOP":"NONE";const N=f==="WIDE",b=f==="MISS"||f==="PAD",w=N?[yn("1",ln.runs.WIDE[0]),yn("2",ln.runs.WIDE[1]),yn("5",ln.runs.WIDE[2])]:b?[yn("0",ln.runs.NONE[0]),yn("1",ln.runs.NONE[1],0,[],f==="MISS"||e.batting.attemptedStroke),yn("4",ln.runs.NONE[4],0,[],f==="MISS"||e.batting.attemptedStroke)]:G1(e,f,A.coverageBp),D=s.targetToWin===null?null:s.targetToWin-s.runs-(o==="WIDE"||o==="NO_BALL"?1:0),p=w.map(S=>{const R=Number(S.id),V=N?R===5:b?R===4:R>=4,U=N?R-1:R;return D!==null&&!V&&U>D?{...S,allowed:!1}:S}),I=Number(a("RUNS",p)),v=o==="WIDE"||o==="NO_BALL"?1:0;N?(d.wides=I,I===5?g.boundary="FOUR":g.completedRuns=I-1,g.attemptedStroke=!1):b?(f==="MISS"?d.byes=I:d.legByes=I,I===4?g.boundary="FOUR":g.completedRuns=I):(g.batRuns=I,I>=4?g.boundary=I===4?"FOUR":"SIX":g.completedRuns=I),g.boundary!=="NONE"&&g.fieldOutcome==="STOP"&&(g.fieldOutcome="NONE");const y=!["FAST","MEDIUM"].includes(e.bowling.bowlingStyle);if((f==="MISS"&&o==="LEGAL"||N)&&y&&!h&&e.batting.aggression>2&&g.completedRuns===0&&g.boundary==="NONE"){const S=Dc.normalise({probabilityVersion:zn,modelId:ge,modelHash:Bn,lutVersion:Se,lutHash:Ae,categories:[yn("SUCCESS",1,0,[{coefficientBp:1e4,featureBp:Te(e.field.keeper.keepingRating)}]),yn("FAILURE",1)]}),V=BigInt(S.categories[0].mass)*BigInt(ln.stumping.numerator)/BigInt(ln.stumping.denominator),U=Number($t(V*1000000000n,4294967296n));if(a("STUMPING",[yn("STUMPED",U),yn("NONE",1e9-U)])==="STUMPED")return g.dismissal={kind:"STUMPED",playerId:s.strikerId,fielderId:s.keeperId,wicketEnd:s.strikerEnd},g.endsAfter[s.strikerEnd==="NORTH"?"north":"south"]=null,E(g)}if(g.completedRuns>0&&g.completedRuns<=3&&g.boundary==="NONE"&&a("RUN_OUT",z1(e,A,g.completedRuns,v))==="RUN_OUT"){const R=a("RUN_OUT_END",[yn("NORTH",1),yn("SOUTH",1)]),V=g.completedRuns,U=V-1,H=s.endsBefore.north,en=s.endsBefore.south,P=R==="NORTH"?V%2===0?H:en:V%2===0?en:H,x=P===H?en:H;return g.completedRuns=U,g.attemptedRuns=V,g.fieldOutcome="RUN_OUT",g.dismissal={kind:"RUN_OUT",playerId:P,fielderId:A.playerId,wicketEnd:R},g.endsAfter={north:R==="NORTH"?null:x,south:R==="SOUTH"?null:x},N?d.wides=U+1:f==="MISS"?d.byes=U:f==="PAD"?d.legByes=U:g.batRuns=U,E(g)}return g.attemptedRuns=g.completedRuns,g.completedRuns%2===1&&(g.endsAfter={north:s.endsBefore.south,south:s.endsBefore.north}),E(g)}const kc=new WeakSet,Bc=new WeakSet;function Y1(n){return!!n&&typeof n=="object"&&kc.has(n)}const Pc=In(ne),xc=In(ln),so=ke.find(n=>n.rulesId==="LC_T20_01");if(!so)throw new Error("INVALID_SETUP: frozen T20 rule manifest missing");const K1=In(so),co=ke.find(n=>n.rulesId==="LC_ODI_01");if(!co)throw new Error("INVALID_SETUP: frozen ODI rule manifest missing");const j1=In(co),Fc=ke.find(n=>n.rulesId==="LC_RED5_01");if(!Fc)throw new Error("INVALID_SETUP: frozen red-ball rule manifest missing");In(Fc);function J(n,e){if(!n)throw new Error(`INVALID_T20_SETUP: ${e}`)}function Ut(n){if(n!==null&&typeof n=="object"){for(const e of Object.values(n))Ut(e);Object.freeze(n)}return n}function Ci(n,e){J(n instanceof Uint8Array&&n.byteLength>0,"world bytes missing");const t=Kn(n);J(t===Mn.worldFileSha256,"world file bytes are not the frozen published world");let i;try{i=JSON.parse(new TextDecoder("utf-8",{fatal:!0}).decode(n))}catch{throw new Error("INVALID_T20_SETUP: world bytes are not strict UTF-8 JSON")}const a=T1(i,e);J(n.byteLength===a.manifest.worldByteLength,"world file length mismatch"),J(t===a.manifest.worldFileSha256,"world file manifest hash mismatch");const r=Kn(Qn(a.world));return J(r===a.manifest.worldCanonicalSha256,"canonical world manifest hash mismatch"),J(r===Mn.worldCanonicalSha256,"published canonical world pin mismatch"),a}function Hc(n,e,t,i=so,a=ne,r=ln){const o=Cr.parse(n),{world:s,manifest:d}=Ci(e,t);J(o.setup.format==="T20","only T20 setup is supported"),J(o.setup.worldPackId===s.packId,"wrong world ID"),J(o.setup.randomId===d.randomId,"unsupported random ID"),J(o.setup.modelId===d.modelId,"unsupported model ID"),J(o.setup.rulesId==="LC_T20_01"&&s.rulesIds.includes(o.setup.rulesId),"unsupported T20 rules"),J(!o.setup.capabilities.limitedOversRain&&!o.setup.capabilities.superOver&&!o.setup.capabilities.injuries&&!o.setup.capabilities.prediction,"unsupported gameplay capability enabled"),J(o.worldFileSha256===d.worldFileSha256&&o.worldCanonicalSha256===d.worldCanonicalSha256,"setup world hash mismatch"),J(In(i)===K1,"non-pinned T20 rule manifest"),J(In(a)===Pc,"non-pinned probability pack"),J(In(r)===xc,"non-pinned conditional-delivery stage pack");const g=Kn(Qn(i));J(o.rulesHash===g,"T20 rules hash mismatch"),J(o.modelHash===Bn&&o.modelHash===d.modelHash,"probability model hash mismatch"),J(o.stagePackHash===jn&&o.stagePackHash===d.stagePackHash,"stage pack hash mismatch"),J(i.format==="T20"&&i.allocatedBalls===120&&i.bowlerMaxBalls===24&&r.noLiveMatchOrCalibration,"T20 setup cannot enable unsupported game rules or live play"),J(new Set(o.setup.teamIds).size===2,"teams must differ"),J(o.selectedTeams.every((w,D)=>w.teamId===o.setup.teamIds[D]),"selection order must equal match team order");const E=new Map(s.players.map(w=>[w.playerId,w])),h=o.selectedTeams.map(w=>{const D=s.teams.find(v=>v.teamId===w.teamId);J(!!D,`unknown team ${w.teamId}`),J(new Set(w.playerIds).size===11,`duplicate player in XI ${w.teamId}`);const p=new Set(D.squadIds);J(w.playerIds.every(v=>p.has(v)&&E.has(v)),`XI player not in own squad ${w.teamId}`),J(w.playerIds.includes(w.captainId),`captain not selected ${w.teamId}`),J(w.playerIds.includes(w.keeperId),`keeper not selected ${w.teamId}`);const I=w.playerIds.map(v=>E.get(v));return J(I.find(v=>v.playerId===w.keeperId)?.role==="KEEPER",`designated keeper ineligible ${w.teamId}`),J(I.filter(Le).length>=5,`XI lacks five bowling-capable players ${w.teamId}`),Ut({teamId:D.teamId,name:D.name,playerIds:[...w.playerIds],xi:I.map(v=>structuredClone(v)),captainId:w.captainId,keeperId:w.keeperId})}),f=h.flatMap(w=>w.playerIds);J(new Set(f).size===22,"teams cannot share XI players");const A=s.grounds.find(w=>w.groundId===o.setup.groundId);J(!!A,"unknown match ground");const N={schema:"1.0.0",engine:"LC_T20_SETUP_V1",random:d.randomId,rules:o.setup.rulesId,rulesHash:g,model:d.modelId,modelHash:Bn,worldHash:d.worldCanonicalSha256},b=Ut({setupVersion:"LC_T20_SETUP_V1",gameId:o.setup.gameId,matchId:o.setup.matchId,seed:o.setup.seed,format:"T20",teams:h,ground:structuredClone(A),versions:N,stagePackHash:jn,modelStatus:"SYNTHETIC_ALPHA",worldSeed:d.worldSeed,fixtureOnly:!0});return kc.add(b),b}function q1(n){return!!n&&typeof n=="object"&&Bc.has(n)}function Mc(n,e,t,i=co,a=ne,r=ln){const o=xg.parse(n),{world:s,manifest:d}=Ci(e,t);J(o.setup.format==="ODI","only ODI setup is supported"),J(o.setup.worldPackId===s.packId,"wrong world ID"),J(o.setup.randomId===d.randomId,"unsupported random ID"),J(o.setup.modelId===d.modelId,"unsupported model ID"),J(o.setup.rulesId==="LC_ODI_01"&&s.rulesIds.includes(o.setup.rulesId),"unsupported ODI rules"),J(!o.setup.capabilities.limitedOversRain&&!o.setup.capabilities.superOver&&!o.setup.capabilities.injuries&&!o.setup.capabilities.prediction,"unsupported gameplay capability enabled"),J(o.worldFileSha256===d.worldFileSha256&&o.worldCanonicalSha256===d.worldCanonicalSha256,"setup world hash mismatch"),J(In(i)===j1,"non-pinned ODI rule manifest"),J(In(a)===Pc,"non-pinned probability pack"),J(In(r)===xc,"non-pinned conditional-delivery stage pack");const g=Kn(Qn(i));J(o.rulesHash===g,"ODI rules hash mismatch"),J(o.modelHash===Bn&&o.modelHash===d.modelHash,"probability model hash mismatch"),J(o.stagePackHash===jn&&o.stagePackHash===d.stagePackHash,"stage pack hash mismatch"),J(i.format==="ODI"&&i.allocatedBalls===300&&i.bowlerMaxBalls===60&&r.noLiveMatchOrCalibration,"ODI setup cannot enable unsupported game rules or live play"),J(new Set(o.setup.teamIds).size===2,"teams must differ"),J(o.selectedTeams.every((w,D)=>w.teamId===o.setup.teamIds[D]),"selection order must equal match team order");const E=new Map(s.players.map(w=>[w.playerId,w])),h=o.selectedTeams.map(w=>{const D=s.teams.find(v=>v.teamId===w.teamId);J(!!D,`unknown team ${w.teamId}`),J(new Set(w.playerIds).size===11,`duplicate player in XI ${w.teamId}`);const p=new Set(D.squadIds);J(w.playerIds.every(v=>p.has(v)&&E.has(v)),`XI player not in own squad ${w.teamId}`),J(w.playerIds.includes(w.captainId),`captain not selected ${w.teamId}`),J(w.playerIds.includes(w.keeperId),`keeper not selected ${w.teamId}`);const I=w.playerIds.map(v=>E.get(v));return J(I.find(v=>v.playerId===w.keeperId)?.role==="KEEPER",`designated keeper ineligible ${w.teamId}`),J(I.filter(Le).length>=5,`XI lacks five bowling-capable players ${w.teamId}`),Ut({teamId:D.teamId,name:D.name,playerIds:[...w.playerIds],xi:I.map(v=>structuredClone(v)),captainId:w.captainId,keeperId:w.keeperId})}),f=h.flatMap(w=>w.playerIds);J(new Set(f).size===22,"teams cannot share XI players");const A=s.grounds.find(w=>w.groundId===o.setup.groundId);J(!!A,"unknown match ground");const N={schema:"1.0.0",engine:"LC_ODI_SETUP_V1",random:d.randomId,rules:o.setup.rulesId,rulesHash:g,model:d.modelId,modelHash:Bn,worldHash:d.worldCanonicalSha256},b=Ut({setupVersion:"LC_ODI_SETUP_V1",gameId:o.setup.gameId,matchId:o.setup.matchId,seed:o.setup.seed,format:"ODI",teams:h,ground:structuredClone(A),versions:N,stagePackHash:jn,modelStatus:"SYNTHETIC_ALPHA",worldSeed:d.worldSeed,fixtureOnly:!0});return Bc.add(b),b}const Z1=kn(),X1=Ye(),An=n=>Z1.hash(n),Be=n=>structuredClone(n),ki=n=>{throw new Error(`LC_T20_${n}`)};function z(n,e){n||ki(e)}const Vc=An(Oi),J1=Vc,Q1={line:"STUMPS",length:"GOOD",variationId:"stock",effort:"NORMAL"};function Gt(n,e){const t=n.setup.teams.find(i=>i.teamId===e);return z(t,"UNKNOWN_TEAM"),t}function Pe(n,e){const t=n.setup.teams.flatMap(i=>i.xi).find(i=>i.playerId===e);return z(t,"UNKNOWN_PLAYER"),t}function zt(n,e){const t=n.setup.teams.find(i=>i.teamId!==e);return z(t,"UNKNOWN_OPPONENT"),t.teamId}function Fn(n){const e=n.core.innings[n.core.activeInningsIndex];return z(e,"NO_ACTIVE_INNINGS"),e}function Bi(n){return Gt(n,Fn(n).innings.battingTeamId)}function Ke(n){return Gt(n,Fn(n).innings.bowlingTeamId)}function Wc(n){const e=Li.positions.find(t=>t.slotId===n);return z(e,"UNKNOWN_FIELD_POSITION"),e}function nf(n,e){const t=e<36?Ja:_c;return[...n].sort().map((i,a)=>({slotId:t[a],playerId:i}))}function bt(n,e,t,i){z(n.length===9&&new Set(n.map(s=>s.playerId)).size===9&&new Set(n.map(s=>s.slotId)).size===9,"INVALID_FIELD_DUPLICATES"),z([...n.map(s=>s.playerId)].sort().join("|")===[...e].sort().join("|"),"INVALID_FIELD_IDENTITIES");const a=n.map(s=>Wc(s.slotId)),r=a.filter(s=>t==="R"?s.legSide:!s.legSide),o=a.filter(s=>!s.insideCircle).length;z(o<=(i<36?2:5),"INVALID_FIELD_POWERPLAY"),z(r.length<=5,"INVALID_FIELD_LEG_SIDE"),z(r.filter(s=>s.behindSquare).length<=2,"INVALID_FIELD_BEHIND_SQUARE")}function ef(n,e,t){const i=Gt(n,e),a=Gt(n,zt(n,e)),r=Object.fromEntries(i.playerIds.map(g=>[g,{runs:0,ballsFaced:0,fours:0,sixes:0,dismissed:!1}])),o=Object.fromEntries(a.playerIds.map(g=>[g,{runsConceded:0,legalBalls:0,wickets:0,maidens:0}])),s=Object.fromEntries(a.playerIds.map(g=>[g,0])),d=a.playerIds.filter(g=>g!==a.keeperId).slice(0,9);return ee({engineVersion:$e,rulesId:"LC_T20_01",nextDeliveryIndex:n.core.globalAttemptOrdinal,batting:r,bowling:o,dismissals:{},keeperId:a.keeperId,outfieldIds:d,currentOverRuns:0,innings:{index:t,battingTeamId:e,bowlingTeamId:a.teamId,runs:0,wickets:0,legalBalls:0,deliveryAttempts:0,targetToWin:t===1?n.core.innings[0].innings.runs+1:null,allocatedBalls:120,extras:{wides:0,noBalls:0,byes:0,legByes:0,penalties:0},northBatterId:null,southBatterId:null,strikerEnd:"NORTH",battingOrder:[...i.playerIds],dismissed:[],bowlerId:null,previousOverBowlerId:null,bowlerLegalBalls:s,freeHitPending:!1,ballAgeLegalBalls:0,complete:!1}})}function tf(n){return z(Y1(n)&&Object.isFrozen(n)&&n.setupVersion==="LC_T20_SETUP_V1"&&n.teams.length===2&&n.fixtureOnly,"INVALID_FROZEN_SETUP"),z(n.versions.worldHash===Mn.worldCanonicalSha256&&n.versions.modelHash===Bn&&n.stagePackHash===jn&&n.versions.rulesHash===oo("LC_T20_01")&&n.versions.random===$n&&n.versions.rules==="LC_T20_01","UNSUPPORTED_PINNED_SETUP"),Br.parse({engine:kr,eventChain:pe,conditionPolicy:pa,conditionPolicyHash:Vc,setupHash:An(n),worldHash:n.versions.worldHash,rulesHash:n.versions.rulesHash,modelHash:n.versions.modelHash,stagePackHash:n.stagePackHash,randomVersion:$n,scoringVersion:$e,probabilityVersion:zn})}function Pi(n){const e=tf(n),t=An(n),i={phase:"SETUP",setupHash:t,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:Be(n.ground.pitchPrior),fatigueBp:Object.fromEntries(n.teams.flatMap(r=>r.playerIds).map(r=>[r,0]))},a=An([pe,t,An(e)]);return{setup:n,executionManifest:e,core:i,revision:0,events:[],receipts:{},commands:[],genesisHash:a,lastEventHash:a}}function af(n,e,t){const i=Pe(n,e.bowlerId),r=!["FAST","MEDIUM"].includes(i.bowlingStyle??"")?12:20,o=Oi.effortFactorBp[t],s=Math.floor((r*o+5e3)/1e4);if(n.core.fatigueBp[e.bowlerId]=Math.min(1e4,n.core.fatigueBp[e.bowlerId]+s),e.legalBall){const d=Be(n.core.pitch);d.wearPoints+=1,d.wearPoints%100===0&&(d.turnBp=Math.min(1e4,d.turnBp+20),d.variabilityBp=Math.min(1e4,d.variabilityBp+10),d.seamBp=Math.max(0,d.seamBp-10)),n.core.pitch=d}}function $c(n,e,t){const i=n.core;switch(e){case"TEAMS_CONFIRMED":z(i.phase==="SETUP","WRONG_PHASE"),i.phase="TOSS";break;case"TOSS_RESOLVED":z(i.phase==="TOSS","WRONG_PHASE"),z(Gt(n,t.winnerId),"INVALID_TOSS"),i.tossWinnerId=t.winnerId,i.tossCallerId=t.callerId,i.phase="AWAITING_INNINGS";break;case"INNINGS_STARTED":{const a=t.inningsIndex,r=t.battingTeamId;z(i.phase==="AWAITING_INNINGS"||i.phase==="INTERVAL","WRONG_PHASE"),z(a===i.innings.length&&a<2,"INNINGS_ORDER"),a===0?i.battingFirstId=r:z(zt(n,i.battingFirstId)===r,"INNINGS_ORDER");const o=ef(n,r,a);i.innings.push(o),i.activeInningsIndex=a,i.fieldSlots=[],i.bowlingPlan=null,i.phase="AWAITING_BATTER";break}case"BATTER_SELECTED":{z(i.phase==="AWAITING_BATTER","WRONG_PHASE");const a=Fn(n),r=t.playerId;if(z(Bi(n).playerIds.includes(r),"INVALID_BATTER_TEAM"),a.innings.northBatterId===null&&a.innings.southBatterId===null){z(!a.batting[r].dismissed,"DISMISSED_BATTER");const s=Be(a);s.innings.northBatterId=r,i.innings[i.activeInningsIndex]=ee(s)}else i.innings[i.activeInningsIndex]=wi(a,r);const o=Fn(n).innings;i.phase=o.northBatterId===null||o.southBatterId===null?"AWAITING_BATTER":o.bowlerId===null?"AWAITING_BOWLER":"READY";break}case"BOWLER_SELECTED":{z(i.phase==="AWAITING_BOWLER","WRONG_PHASE");const a=Fn(n),r=t.playerId;z(Ke(n).playerIds.includes(r)&&Pe(n,r).bowlingStyle!==null,"INELIGIBLE_BOWLER");const o=Ke(n).playerIds.filter(d=>d!==Ke(n).keeperId&&d!==r);i.innings[i.activeInningsIndex]=ao(a,r,o),i.bowlingPlan={...Q1,bowlerId:r},i.fieldSlots=nf(o,a.innings.legalBalls);const s=Oe(Fn(n)).strikerId;bt(i.fieldSlots,o,Pe(n,s).batHand,a.innings.legalBalls),i.phase="READY";break}case"FIELD_CHANGED":{z(i.phase==="READY","WRONG_PHASE");const a=Fn(n),r=Oe(a).strikerId,o=t.fieldSlots;bt(o,a.outfieldIds,Pe(n,r).batHand,a.innings.legalBalls),i.fieldSlots=Be(o);break}case"BATTING_PLAN_CHANGED":{z(i.phase==="READY","WRONG_PHASE");const a=t.playerId;z([Fn(n).innings.northBatterId,Fn(n).innings.southBatterId].includes(a),"BATTER_NOT_ACTIVE"),i.battingPlans[a]={aggression:t.aggression,intent:t.intent};break}case"BOWLING_PLAN_CHANGED":{z(i.phase==="READY","WRONG_PHASE"),z(t.bowlerId===Fn(n).innings.bowlerId,"BOWLER_NOT_ACTIVE"),z(t.variationId==="stock","UNSUPPORTED_VARIATION"),i.bowlingPlan=Be(t);break}case"DELIVERY_RECORDED":{z(i.phase==="READY","WRONG_PHASE");const a=Fn(n),r=t.event;z(t.attemptOrdinal===i.globalAttemptOrdinal&&r.deliveryIndex===i.globalAttemptOrdinal,"GLOBAL_ATTEMPT_MISMATCH"),bt(i.fieldSlots,a.outfieldIds,Pe(n,Oe(a).strikerId).batHand,a.innings.legalBalls);const o=io(a,r);i.innings[i.activeInningsIndex]=o.ledger,i.globalAttemptOrdinal++,af(n,r,i.bowlingPlan.effort),o.observation.result&&(i.result=o.observation.result),o.observation.inningsComplete?i.phase="INTERVAL":o.observation.requiredBatterEnd?i.phase="AWAITING_BATTER":o.observation.overCompleted?i.phase="AWAITING_BOWLER":i.phase="READY";break}case"OVER_COMPLETED":{z(Fn(n).innings.legalBalls%6===0,"INVALID_OVER_MARKER");const a=t.bowlerId;z(Fn(n).innings.previousOverBowlerId===a,"OVER_BOWLER_MISMATCH");for(const r of Ke(n).playerIds)r!==a&&(i.fatigueBp[r]=Math.max(0,i.fatigueBp[r]-15));break}case"INNINGS_COMPLETED":z(Fn(n).innings.complete,"INVALID_INNINGS_MARKER"),i.phase=i.activeInningsIndex===0?"INTERVAL":i.phase;break;case"MATCH_COMPLETED":z(i.activeInningsIndex===1&&Fn(n).innings.complete&&i.result!==null,"INVALID_RESULT_MARKER"),i.phase="COMPLETE";break;default:ki("UNKNOWN_EVENT")}}function de(n,e,t,i){$c(n,t,i);const a=n.events.length+1,r=n.lastEventHash,o=An(n.core),s=An([pe,a,e,t,i,r,o]),d=hi.parse({version:pe,sequence:a,commandId:e,type:t,payload:i,previousHash:r,stateHash:o,eventHash:s});n.events.push(d),n.lastEventHash=s}function of(n){const e=Fn(n),t=Oe(e),i=Pe(n,t.strikerId),a=Pe(n,t.bowlerId),r=Pe(n,t.keeperId),o=i.skills.T20,s=a.skills.T20;bt(n.core.fieldSlots,e.outfieldIds,i.batHand,e.innings.legalBalls);const d={kind:"GENERATE_DELIVERY",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:jn,randomVersion:$n,probabilityVersion:zn,modelId:ge,modelHash:Bn,lutVersion:Se,lutHash:Ae,rulesHash:n.setup.versions.rulesHash,matchId:n.setup.matchId,seed:n.setup.seed,attemptOrdinal:n.core.globalAttemptOrdinal,format:"T20",phase:yi("T20",e.innings.legalBalls),context:t,bowling:{bowlingStyle:a.bowlingStyle,controlRating:s.control,movementRating:s.movement,fatigueBp:n.core.fatigueBp[a.playerId],line:n.core.bowlingPlan.line,intendedLength:n.core.bowlingPlan.length,effort:n.core.bowlingPlan.effort,variationId:"stock"},batting:{defenceRating:o.defence,timingRating:o.timing,powerRating:o.power,rotationRating:o.rotation,vsPaceRating:o.vsPace,vsSpinRating:o.vsSpin,aggression:n.core.battingPlans[i.playerId]?.aggression??2,intent:n.core.battingPlans[i.playerId]?.intent??"NORMAL",attemptedStroke:!0,shotSectorWeights:[...i.shotSectorWeights]},conditions:{seamBp:n.core.pitch.seamBp,turnBp:n.core.pitch.turnBp},field:{keeper:{keepingRating:r.skills.T20.keeping,catchingRating:r.skills.T20.catching,throwingRating:r.skills.T20.throwing},slots:n.core.fieldSlots.map(h=>{const f=Pe(n,h.playerId),A=Wc(h.slotId);return{playerId:h.playerId,sector:A.sector,depth:A.depth,role:h.slotId.startsWith("slip")?"SLIP":"NORMAL",catchingRating:f.skills.T20.catching,throwingRating:f.skills.T20.throwing}})}},g=ro(d);return{event:to(t,g.resolution),traceHash:An(g.trace)}}function rf(n,e,t,i){const a=n.core.globalAttemptOrdinal;de(n,e,"DELIVERY_RECORDED",{type:"DELIVERY_RECORDED",event:t,attemptOrdinal:a,traceHash:i});const r=Fn(n);t.legalBall&&r.innings.legalBalls%6===0&&de(n,e,"OVER_COMPLETED",{type:"OVER_COMPLETED",bowlerId:t.bowlerId}),r.innings.complete&&(de(n,e,"INNINGS_COMPLETED",{type:"INNINGS_COMPLETED",inningsIndex:n.core.activeInningsIndex}),n.core.activeInningsIndex===1?de(n,e,"MATCH_COMPLETED",{type:"MATCH_COMPLETED",result:n.core.result}):de(n,e,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:1,battingTeamId:zt(n,r.innings.battingTeamId)}))}function sf(n,e,t){z(n.core.phase==="READY","WRONG_PHASE");const i=Math.floor(Fn(n).innings.legalBalls/6);let a=0;for(;n.core.phase==="READY"&&a<60;){const{event:r,traceHash:o}=of(n);rf(n,e,r,o),a++;const s=Fn(n);if(t==="DELIVERY"||Math.floor(s.innings.legalBalls/6)!==i)break}z(a<60,"ADVANCE_ATTEMPT_LIMIT")}function vt(n,e){const t=Pr.parse(e),i=n.receipts[t.commandId];if(i)return{session:n,receipt:i};z(t.expectedRevision===n.revision,"STALE_REVISION");const a={...n,core:Be(n.core),events:[...n.events],receipts:{...n.receipts},commands:[...n.commands]},r=a.events.length+1,o=t.commandId,s=g=>{z(a.setup.teams.some(E=>E.teamId===g),"ACTOR_TEAM_UNKNOWN"),z(t.actorId===`USER:${g}`||t.actorId===`AI:${g}`||t.actorId==="SYSTEM","ACTOR_UNAUTHORISED")};switch(t.kind){case"CONFIRM_TEAMS":z(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),de(a,o,"TEAMS_CONFIRMED",{type:"TEAMS_CONFIRMED"});break;case"CALL_TOSS":{s(t.payload.teamId),z(a.core.phase==="TOSS","WRONG_PHASE");const g=X1.uint32({seed:a.setup.seed,domain:"TOSS",entityId:a.setup.matchId,eventOrdinal:0,stageName:"coin",drawIndex:0})%2===0?"HEADS":"TAILS",E=t.payload.call===g?t.payload.teamId:zt(a,t.payload.teamId);de(a,o,"TOSS_RESOLVED",{type:"TOSS_RESOLVED",callerId:t.payload.teamId,winnerId:E,call:t.payload.call,coin:g});break}case"CHOOSE_INNINGS":{s(t.payload.teamId),z(t.payload.teamId===a.core.tossWinnerId,"NOT_TOSS_WINNER"),z(a.core.phase==="AWAITING_INNINGS","WRONG_PHASE");const g=t.payload.choice==="BAT"?t.payload.teamId:zt(a,t.payload.teamId);de(a,o,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:0,battingTeamId:g});break}case"SET_BATTER":s(t.payload.teamId),z(a.core.phase==="AWAITING_BATTER"&&t.payload.teamId===Bi(a).teamId,"WRONG_TEAM_OR_PHASE"),de(a,o,"BATTER_SELECTED",{type:"BATTER_SELECTED",playerId:t.payload.playerId});break;case"SET_BOWLER":s(t.payload.teamId),z(a.core.phase==="AWAITING_BOWLER"&&t.payload.teamId===Ke(a).teamId,"WRONG_TEAM_OR_PHASE"),de(a,o,"BOWLER_SELECTED",{type:"BOWLER_SELECTED",playerId:t.payload.bowlerId});break;case"SET_FIELD":s(t.payload.teamId),z(a.core.phase==="READY"&&t.payload.teamId===Ke(a).teamId,"WRONG_TEAM_OR_PHASE"),de(a,o,"FIELD_CHANGED",{type:"FIELD_CHANGED",fieldSlots:t.payload.fieldSlots});break;case"SET_BATTING_PLAN":{const g=Bi(a);s(g.teamId),de(a,o,"BATTING_PLAN_CHANGED",{type:"BATTING_PLAN_CHANGED",...t.payload});break}case"SET_BOWLING_PLAN":{const g=Ke(a);s(g.teamId),de(a,o,"BOWLING_PLAN_CHANGED",{type:"BOWLING_PLAN_CHANGED",...t.payload});break}case"ADVANCE":z(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),sf(a,o,t.payload.scope);break;default:ki("UNKNOWN_COMMAND")}z(a.events.length>=r,"COMMAND_WITH_NO_EVENT"),a.revision=n.revision+1;const d=Fg.parse({commandId:o,committedRevision:a.revision,fromSequence:r,toSequence:a.events.length,lastEventHash:a.lastEventHash});return a.receipts[o]=d,a.commands.push(t),{session:a,receipt:d}}function cf(n,e,t){return Uc(Pi(n),e,t)}function Uc(n,e,t){z(n.revision===0&&n.events.length===0&&n.core.phase==="SETUP","REPLAY_INITIAL_STATE");for(const[i,a]of e.entries()){const r=hi.parse(a);z(r.sequence===i+1&&r.previousHash===n.lastEventHash,"REPLAY_CHAIN_GAP"),z(r.eventHash===An([pe,r.sequence,r.commandId,r.type,r.payload,r.previousHash,r.stateHash]),"REPLAY_EVENT_HASH"),$c(n,r.type,r.payload),r.stateHash!==An(n.core)&&ki("REPLAY_STATE_HASH"),n.events.push(r),n.lastEventHash=r.eventHash}if(t){const i=xt.parse(t);z(i.version===pe&&i.genesisHash===n.genesisHash&&i.finalEventHash===n.lastEventHash&&i.finalStateHash===An(n.core)&&i.eventCount===e.length&&i.executionManifestHash===An(n.executionManifest),"REPLAY_MANIFEST_MISMATCH")}return n}function Gc(n){return xt.parse({version:pe,genesisHash:n.genesisHash,finalEventHash:n.lastEventHash,finalStateHash:An(n.core),eventCount:n.events.length,executionManifestHash:An(n.executionManifest)})}function lf(n){let e=Pi(n.setup);for(const t of n.commands)e=vt(e,t).session;z(e.events.length===n.events.length,"RESIMULATION_LENGTH");for(let t=0;t<n.events.length;t++)z(Kn(Qn(e.events[t]))===Kn(Qn(n.events[t])),`RESIMULATION_MISMATCH_${t}`);z(An(e.core)===An(n.core),"RESIMULATION_FINAL_STATE")}function zc(n){const t={commandId:`auto-${String(n.revision+1).padStart(6,"0")}`,expectedRevision:n.revision};if(n.core.phase==="SETUP")return{...t,actorId:"SYSTEM",kind:"CONFIRM_TEAMS",payload:{}};if(n.core.phase==="TOSS")return{...t,actorId:`AI:${n.setup.teams[0].teamId}`,kind:"CALL_TOSS",payload:{teamId:n.setup.teams[0].teamId,call:"HEADS"}};if(n.core.phase==="AWAITING_INNINGS")return{...t,actorId:`AI:${n.core.tossWinnerId}`,kind:"CHOOSE_INNINGS",payload:{teamId:n.core.tossWinnerId,choice:"BAT"}};const i=Fn(n);if(n.core.phase==="AWAITING_BATTER"){const a=Bi(n),r=new Set([i.innings.northBatterId,i.innings.southBatterId,...i.innings.dismissed]),o=a.playerIds.find(s=>!r.has(s));return z(o,"NO_ELIGIBLE_BATTER"),{...t,actorId:`AI:${a.teamId}`,kind:"SET_BATTER",payload:{teamId:a.teamId,playerId:o}}}if(n.core.phase==="AWAITING_BOWLER"){const a=Ke(n),r=a.xi.filter(o=>o.bowlingStyle!==null&&o.playerId!==a.keeperId&&o.playerId!==i.innings.previousOverBowlerId&&i.bowling[o.playerId].legalBalls<24).sort((o,s)=>i.bowling[o.playerId].legalBalls-i.bowling[s.playerId].legalBalls||o.playerId.localeCompare(s.playerId));return z(r.length,"NO_ELIGIBLE_BOWLER"),{...t,actorId:`AI:${a.teamId}`,kind:"SET_BOWLER",payload:{teamId:a.teamId,bowlerId:r[0].playerId}}}return z(n.core.phase==="READY","INVALID_AUTOPILOT_PHASE"),{...t,actorId:"SYSTEM",kind:"ADVANCE",payload:{scope:"OVER"}}}function xi(n){z(n.core.phase==="COMPLETE"&&n.core.innings.length===2&&n.core.result,"SCORECARD_NOT_COMPLETE");const e=n.core.innings.map((t,i)=>{ee(t);const a=n.events.filter(g=>g.type==="DELIVERY_RECORDED"&&g.payload.event.inningsIndex===i);let r=0,o=0;const s=[];for(const g of a){const E=g.payload.event;r+=E.batRuns+Object.values(E.extras).reduce((h,f)=>h+f,0),o+=Number(E.legalBall),E.dismissal&&s.push({playerId:E.dismissal.playerId,runs:r,legalBalls:o,sequence:g.sequence})}z(r===t.innings.runs&&o===t.innings.legalBalls&&a.length===t.innings.deliveryAttempts,"PROJECTED_SCORE_MISMATCH");const d=t.innings;return{battingTeamId:d.battingTeamId,bowlingTeamId:d.bowlingTeamId,runs:d.runs,wickets:d.wickets,legalBalls:d.legalBalls,overs:`${Math.floor(d.legalBalls/6)}.${d.legalBalls%6}`,extras:Be(d.extras),batting:Be(t.batting),bowling:Be(t.bowling),fallOfWickets:s,targetToWin:d.targetToWin}});return Ia.parse({matchId:n.setup.matchId,innings:e,result:n.core.result})}function df(n,e,t){z(!!n&&typeof n=="object"&&!Array.isArray(n),"SAVE_SHAPE");const i=n,a=i.setup;z(!!a&&a.setupVersion==="LC_T20_SETUP_V1","SAVE_SETUP"),z(Array.isArray(a.teams)&&a.teams.length===2,"SAVE_TEAMS");const r=Hc({setupVersion:"LC_T20_SETUP_V1",setup:{schemaVersion:"1.0.0",gameId:a.gameId,matchId:a.matchId,format:"T20",worldPackId:Mn.worldPackId,rulesId:a.versions.rules,modelId:a.versions.model,randomId:a.versions.random,seed:a.seed,teamIds:a.teams.map(s=>s.teamId),groundId:a.ground.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:Mn.worldFileSha256,worldCanonicalSha256:a.versions.worldHash,rulesHash:a.versions.rulesHash,modelHash:a.versions.modelHash,stagePackHash:a.stagePackHash,selectedTeams:a.teams.map(s=>({teamId:s.teamId,playerIds:[...s.playerIds],captainId:s.captainId,keeperId:s.keeperId}))},e,t);z(Array.isArray(i.commands),"SAVE_COMMANDS");let o=Pi(r);for(const s of i.commands)o=vt(o,s).session;return z(typeof i.revision=="number"&&o.revision===i.revision,"SAVE_REVISION"),z(Array.isArray(i.events)&&An(o.events)===An(i.events),"SAVE_EVENTS"),z(i.core!==void 0&&An(o.core)===An(i.core),"SAVE_CORE"),z(i.receipts!==void 0&&An(o.receipts)===An(i.receipts),"SAVE_RECEIPTS"),z(i.executionManifest!==void 0&&An(o.executionManifest)===An(i.executionManifest),"SAVE_MANIFEST"),z(i.genesisHash===o.genesisHash&&i.lastEventHash===o.lastEventHash,"SAVE_CHAIN"),o}const uf=kn(),mf=Ye(),Ln=n=>uf.hash(n),xe=n=>structuredClone(n),Fi=n=>{throw new Error(`LC_ODI_${n}`)};function Y(n,e){n||Fi(e)}const Yc=Ln(Rc),gf=Yc,pf={line:"STUMPS",length:"GOOD",variationId:"stock",effort:"NORMAL"};function Yt(n,e){const t=n.setup.teams.find(i=>i.teamId===e);return Y(t,"UNKNOWN_TEAM"),t}function Fe(n,e){const t=n.setup.teams.flatMap(i=>i.xi).find(i=>i.playerId===e);return Y(t,"UNKNOWN_PLAYER"),t}function Kt(n,e){const t=n.setup.teams.find(i=>i.teamId!==e);return Y(t,"UNKNOWN_OPPONENT"),t.teamId}function Hn(n){const e=n.core.innings[n.core.activeInningsIndex];return Y(e,"NO_ACTIVE_INNINGS"),e}function Hi(n){return Yt(n,Hn(n).innings.battingTeamId)}function je(n){return Yt(n,Hn(n).innings.bowlingTeamId)}function Kc(n){const e=Tc.positions.find(t=>t.slotId===n);return Y(e,"UNKNOWN_FIELD_POSITION"),e}function If(n,e){const t=e<60?bc:e<240?S1:_1;return[...n].sort().map((i,a)=>({slotId:t[a],playerId:i}))}function Rt(n,e,t,i){Y(n.length===9&&new Set(n.map(s=>s.playerId)).size===9&&new Set(n.map(s=>s.slotId)).size===9,"INVALID_FIELD_DUPLICATES"),Y([...n.map(s=>s.playerId)].sort().join("|")===[...e].sort().join("|"),"INVALID_FIELD_IDENTITIES");const a=n.map(s=>Kc(s.slotId)),r=a.filter(s=>t==="R"?s.legSide:!s.legSide),o=a.filter(s=>!s.insideCircle).length;Y(o<=(i<60?2:i<240?4:5),"INVALID_FIELD_POWERPLAY"),Y(r.length<=5,"INVALID_FIELD_LEG_SIDE"),Y(r.filter(s=>s.behindSquare).length<=2,"INVALID_FIELD_BEHIND_SQUARE")}function hf(n,e,t){const i=Yt(n,e),a=Yt(n,Kt(n,e)),r=Object.fromEntries(i.playerIds.map(g=>[g,{runs:0,ballsFaced:0,fours:0,sixes:0,dismissed:!1}])),o=Object.fromEntries(a.playerIds.map(g=>[g,{runsConceded:0,legalBalls:0,wickets:0,maidens:0}])),s=Object.fromEntries(a.playerIds.map(g=>[g,0])),d=a.playerIds.filter(g=>g!==a.keeperId).slice(0,9);return ee({engineVersion:$e,rulesId:"LC_ODI_01",nextDeliveryIndex:n.core.globalAttemptOrdinal,batting:r,bowling:o,dismissals:{},keeperId:a.keeperId,outfieldIds:d,currentOverRuns:0,innings:{index:t,battingTeamId:e,bowlingTeamId:a.teamId,runs:0,wickets:0,legalBalls:0,deliveryAttempts:0,targetToWin:t===1?n.core.innings[0].innings.runs+1:null,allocatedBalls:300,extras:{wides:0,noBalls:0,byes:0,legByes:0,penalties:0},northBatterId:null,southBatterId:null,strikerEnd:"NORTH",battingOrder:[...i.playerIds],dismissed:[],bowlerId:null,previousOverBowlerId:null,bowlerLegalBalls:s,freeHitPending:!1,ballAgeLegalBalls:0,complete:!1}})}function ff(n){return Y(q1(n)&&Object.isFrozen(n)&&n.setupVersion==="LC_ODI_SETUP_V1"&&n.teams.length===2&&n.fixtureOnly,"INVALID_FROZEN_SETUP"),Y(n.versions.worldHash===Mn.worldCanonicalSha256&&n.versions.modelHash===Bn&&n.stagePackHash===jn&&n.versions.rulesHash===oo("LC_ODI_01")&&n.versions.random===$n&&n.versions.rules==="LC_ODI_01","UNSUPPORTED_PINNED_SETUP"),Fr.parse({engine:xr,eventChain:Ie,conditionPolicy:ha,conditionPolicyHash:Yc,setupHash:Ln(n),worldHash:n.versions.worldHash,rulesHash:n.versions.rulesHash,modelHash:n.versions.modelHash,stagePackHash:n.stagePackHash,randomVersion:$n,scoringVersion:$e,probabilityVersion:zn})}function Mi(n){const e=ff(n),t=Ln(n),i={phase:"SETUP",setupHash:t,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:xe(n.ground.pitchPrior),fatigueBp:Object.fromEntries(n.teams.flatMap(r=>r.playerIds).map(r=>[r,0]))},a=Ln([Ie,t,Ln(e)]);return{setup:n,executionManifest:e,core:i,revision:0,events:[],receipts:{},commands:[],genesisHash:a,lastEventHash:a}}function Ef(n,e,t){const i=Fe(n,e.bowlerId),r=!["FAST","MEDIUM"].includes(i.bowlingStyle??"")?12:20,o=Rc.effortFactorBp[t],s=Math.floor((r*o+5e3)/1e4);if(n.core.fatigueBp[e.bowlerId]=Math.min(1e4,n.core.fatigueBp[e.bowlerId]+s),e.legalBall){const d=xe(n.core.pitch);d.wearPoints+=1,d.wearPoints%100===0&&(d.turnBp=Math.min(1e4,d.turnBp+20),d.variabilityBp=Math.min(1e4,d.variabilityBp+10),d.seamBp=Math.max(0,d.seamBp-10)),n.core.pitch=d}}function jc(n,e,t){const i=n.core;switch(e){case"TEAMS_CONFIRMED":Y(i.phase==="SETUP","WRONG_PHASE"),i.phase="TOSS";break;case"TOSS_RESOLVED":Y(i.phase==="TOSS","WRONG_PHASE"),Y(Yt(n,t.winnerId),"INVALID_TOSS"),i.tossWinnerId=t.winnerId,i.tossCallerId=t.callerId,i.phase="AWAITING_INNINGS";break;case"INNINGS_STARTED":{const a=t.inningsIndex,r=t.battingTeamId;Y(i.phase==="AWAITING_INNINGS"||i.phase==="INTERVAL","WRONG_PHASE"),Y(a===i.innings.length&&a<2,"INNINGS_ORDER"),a===0?i.battingFirstId=r:Y(Kt(n,i.battingFirstId)===r,"INNINGS_ORDER");const o=hf(n,r,a);i.innings.push(o),i.activeInningsIndex=a,i.fieldSlots=[],i.bowlingPlan=null,i.phase="AWAITING_BATTER";break}case"BATTER_SELECTED":{Y(i.phase==="AWAITING_BATTER","WRONG_PHASE");const a=Hn(n),r=t.playerId;if(Y(Hi(n).playerIds.includes(r),"INVALID_BATTER_TEAM"),a.innings.northBatterId===null&&a.innings.southBatterId===null){Y(!a.batting[r].dismissed,"DISMISSED_BATTER");const s=xe(a);s.innings.northBatterId=r,i.innings[i.activeInningsIndex]=ee(s)}else i.innings[i.activeInningsIndex]=wi(a,r);const o=Hn(n).innings;i.phase=o.northBatterId===null||o.southBatterId===null?"AWAITING_BATTER":o.bowlerId===null?"AWAITING_BOWLER":"READY";break}case"BOWLER_SELECTED":{Y(i.phase==="AWAITING_BOWLER","WRONG_PHASE");const a=Hn(n),r=t.playerId;Y(je(n).playerIds.includes(r)&&Fe(n,r).bowlingStyle!==null,"INELIGIBLE_BOWLER");const o=je(n).playerIds.filter(d=>d!==je(n).keeperId&&d!==r);i.innings[i.activeInningsIndex]=ao(a,r,o),i.bowlingPlan={...pf,bowlerId:r},i.fieldSlots=If(o,a.innings.legalBalls);const s=Oe(Hn(n)).strikerId;Rt(i.fieldSlots,o,Fe(n,s).batHand,a.innings.legalBalls),i.phase="READY";break}case"FIELD_CHANGED":{Y(i.phase==="READY","WRONG_PHASE");const a=Hn(n),r=Oe(a).strikerId,o=t.fieldSlots;Rt(o,a.outfieldIds,Fe(n,r).batHand,a.innings.legalBalls),i.fieldSlots=xe(o);break}case"BATTING_PLAN_CHANGED":{Y(i.phase==="READY","WRONG_PHASE");const a=t.playerId;Y([Hn(n).innings.northBatterId,Hn(n).innings.southBatterId].includes(a),"BATTER_NOT_ACTIVE"),i.battingPlans[a]={aggression:t.aggression,intent:t.intent};break}case"BOWLING_PLAN_CHANGED":{Y(i.phase==="READY","WRONG_PHASE"),Y(t.bowlerId===Hn(n).innings.bowlerId,"BOWLER_NOT_ACTIVE"),Y(t.variationId==="stock","UNSUPPORTED_VARIATION"),i.bowlingPlan=xe(t);break}case"DELIVERY_RECORDED":{Y(i.phase==="READY","WRONG_PHASE");const a=Hn(n),r=t.event;Y(t.attemptOrdinal===i.globalAttemptOrdinal&&r.deliveryIndex===i.globalAttemptOrdinal,"GLOBAL_ATTEMPT_MISMATCH"),Rt(i.fieldSlots,a.outfieldIds,Fe(n,Oe(a).strikerId).batHand,a.innings.legalBalls);const o=io(a,r);i.innings[i.activeInningsIndex]=o.ledger,i.globalAttemptOrdinal++,Ef(n,r,i.bowlingPlan.effort),o.observation.result&&(i.result=o.observation.result),o.observation.inningsComplete?i.phase="INTERVAL":o.observation.requiredBatterEnd?i.phase="AWAITING_BATTER":o.observation.overCompleted?i.phase="AWAITING_BOWLER":i.phase="READY";break}case"OVER_COMPLETED":{Y(Hn(n).innings.legalBalls%6===0,"INVALID_OVER_MARKER");const a=t.bowlerId;Y(Hn(n).innings.previousOverBowlerId===a,"OVER_BOWLER_MISMATCH");for(const r of je(n).playerIds)r!==a&&(i.fatigueBp[r]=Math.max(0,i.fatigueBp[r]-15));break}case"INNINGS_COMPLETED":Y(Hn(n).innings.complete,"INVALID_INNINGS_MARKER"),i.phase=i.activeInningsIndex===0?"INTERVAL":i.phase;break;case"MATCH_COMPLETED":Y(i.activeInningsIndex===1&&Hn(n).innings.complete&&i.result!==null,"INVALID_RESULT_MARKER"),i.phase="COMPLETE";break;default:Fi("UNKNOWN_EVENT")}}function ue(n,e,t,i){jc(n,t,i);const a=n.events.length+1,r=n.lastEventHash,o=Ln(n.core),s=Ln([Ie,a,e,t,i,r,o]),d=Mr.parse({version:Ie,sequence:a,commandId:e,type:t,payload:i,previousHash:r,stateHash:o,eventHash:s});n.events.push(d),n.lastEventHash=s}function Sf(n){const e=Hn(n),t=Oe(e),i=Fe(n,t.strikerId),a=Fe(n,t.bowlerId),r=Fe(n,t.keeperId),o=i.skills.ODI,s=a.skills.ODI;Rt(n.core.fieldSlots,e.outfieldIds,i.batHand,e.innings.legalBalls);const d={kind:"GENERATE_DELIVERY",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:jn,randomVersion:$n,probabilityVersion:zn,modelId:ge,modelHash:Bn,lutVersion:Se,lutHash:Ae,rulesHash:n.setup.versions.rulesHash,matchId:n.setup.matchId,seed:n.setup.seed,attemptOrdinal:n.core.globalAttemptOrdinal,format:"ODI",phase:yi("ODI",e.innings.legalBalls),context:t,bowling:{bowlingStyle:a.bowlingStyle,controlRating:s.control,movementRating:s.movement,fatigueBp:n.core.fatigueBp[a.playerId],line:n.core.bowlingPlan.line,intendedLength:n.core.bowlingPlan.length,effort:n.core.bowlingPlan.effort,variationId:"stock"},batting:{defenceRating:o.defence,timingRating:o.timing,powerRating:o.power,rotationRating:o.rotation,vsPaceRating:o.vsPace,vsSpinRating:o.vsSpin,aggression:n.core.battingPlans[i.playerId]?.aggression??2,intent:n.core.battingPlans[i.playerId]?.intent??"NORMAL",attemptedStroke:!0,shotSectorWeights:[...i.shotSectorWeights]},conditions:{seamBp:n.core.pitch.seamBp,turnBp:n.core.pitch.turnBp},field:{keeper:{keepingRating:r.skills.ODI.keeping,catchingRating:r.skills.ODI.catching,throwingRating:r.skills.ODI.throwing},slots:n.core.fieldSlots.map(h=>{const f=Fe(n,h.playerId),A=Kc(h.slotId);return{playerId:h.playerId,sector:A.sector,depth:A.depth,role:h.slotId.startsWith("slip")?"SLIP":"NORMAL",catchingRating:f.skills.ODI.catching,throwingRating:f.skills.ODI.throwing}})}},g=ro(d);return{event:to(t,g.resolution),traceHash:Ln(g.trace)}}function _f(n,e,t,i){const a=n.core.globalAttemptOrdinal;ue(n,e,"DELIVERY_RECORDED",{type:"DELIVERY_RECORDED",event:t,attemptOrdinal:a,traceHash:i});const r=Hn(n);t.legalBall&&r.innings.legalBalls%6===0&&ue(n,e,"OVER_COMPLETED",{type:"OVER_COMPLETED",bowlerId:t.bowlerId}),r.innings.complete&&(ue(n,e,"INNINGS_COMPLETED",{type:"INNINGS_COMPLETED",inningsIndex:n.core.activeInningsIndex}),n.core.activeInningsIndex===1?ue(n,e,"MATCH_COMPLETED",{type:"MATCH_COMPLETED",result:n.core.result}):ue(n,e,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:1,battingTeamId:Kt(n,r.innings.battingTeamId)}))}function Tf(n,e,t){Y(n.core.phase==="READY","WRONG_PHASE");const i=Math.floor(Hn(n).innings.legalBalls/6);let a=0;for(;n.core.phase==="READY"&&a<60;){const{event:r,traceHash:o}=Sf(n);_f(n,e,r,o),a++;const s=Hn(n);if(t==="DELIVERY"||Math.floor(s.innings.legalBalls/6)!==i)break}Y(a<60,"ADVANCE_ATTEMPT_LIMIT")}function At(n,e){const t=Hr.parse(e),i=n.receipts[t.commandId];if(i)return{session:n,receipt:i};Y(t.expectedRevision===n.revision,"STALE_REVISION");const a={...n,core:xe(n.core),events:[...n.events],receipts:{...n.receipts},commands:[...n.commands]},r=a.events.length+1,o=t.commandId,s=g=>{Y(a.setup.teams.some(E=>E.teamId===g),"ACTOR_TEAM_UNKNOWN"),Y(t.actorId===`USER:${g}`||t.actorId===`AI:${g}`||t.actorId==="SYSTEM","ACTOR_UNAUTHORISED")};switch(t.kind){case"CONFIRM_TEAMS":Y(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),ue(a,o,"TEAMS_CONFIRMED",{type:"TEAMS_CONFIRMED"});break;case"CALL_TOSS":{s(t.payload.teamId),Y(a.core.phase==="TOSS","WRONG_PHASE");const g=mf.uint32({seed:a.setup.seed,domain:"TOSS",entityId:a.setup.matchId,eventOrdinal:0,stageName:"coin",drawIndex:0})%2===0?"HEADS":"TAILS",E=t.payload.call===g?t.payload.teamId:Kt(a,t.payload.teamId);ue(a,o,"TOSS_RESOLVED",{type:"TOSS_RESOLVED",callerId:t.payload.teamId,winnerId:E,call:t.payload.call,coin:g});break}case"CHOOSE_INNINGS":{s(t.payload.teamId),Y(t.payload.teamId===a.core.tossWinnerId,"NOT_TOSS_WINNER"),Y(a.core.phase==="AWAITING_INNINGS","WRONG_PHASE");const g=t.payload.choice==="BAT"?t.payload.teamId:Kt(a,t.payload.teamId);ue(a,o,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:0,battingTeamId:g});break}case"SET_BATTER":s(t.payload.teamId),Y(a.core.phase==="AWAITING_BATTER"&&t.payload.teamId===Hi(a).teamId,"WRONG_TEAM_OR_PHASE"),ue(a,o,"BATTER_SELECTED",{type:"BATTER_SELECTED",playerId:t.payload.playerId});break;case"SET_BOWLER":s(t.payload.teamId),Y(a.core.phase==="AWAITING_BOWLER"&&t.payload.teamId===je(a).teamId,"WRONG_TEAM_OR_PHASE"),ue(a,o,"BOWLER_SELECTED",{type:"BOWLER_SELECTED",playerId:t.payload.bowlerId});break;case"SET_FIELD":s(t.payload.teamId),Y(a.core.phase==="READY"&&t.payload.teamId===je(a).teamId,"WRONG_TEAM_OR_PHASE"),ue(a,o,"FIELD_CHANGED",{type:"FIELD_CHANGED",fieldSlots:t.payload.fieldSlots});break;case"SET_BATTING_PLAN":{const g=Hi(a);s(g.teamId),ue(a,o,"BATTING_PLAN_CHANGED",{type:"BATTING_PLAN_CHANGED",...t.payload});break}case"SET_BOWLING_PLAN":{const g=je(a);s(g.teamId),ue(a,o,"BOWLING_PLAN_CHANGED",{type:"BOWLING_PLAN_CHANGED",...t.payload});break}case"ADVANCE":Y(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),Tf(a,o,t.payload.scope);break;default:Fi("UNKNOWN_COMMAND")}Y(a.events.length>=r,"COMMAND_WITH_NO_EVENT"),a.revision=n.revision+1;const d=Hg.parse({commandId:o,committedRevision:a.revision,fromSequence:r,toSequence:a.events.length,lastEventHash:a.lastEventHash});return a.receipts[o]=d,a.commands.push(t),{session:a,receipt:d}}function bf(n,e,t){return qc(Mi(n),e,t)}function qc(n,e,t){Y(n.revision===0&&n.events.length===0&&n.core.phase==="SETUP","REPLAY_INITIAL_STATE");for(const[i,a]of e.entries()){const r=Mr.parse(a);Y(r.sequence===i+1&&r.previousHash===n.lastEventHash,"REPLAY_CHAIN_GAP"),Y(r.eventHash===Ln([Ie,r.sequence,r.commandId,r.type,r.payload,r.previousHash,r.stateHash]),"REPLAY_EVENT_HASH"),jc(n,r.type,r.payload),r.stateHash!==Ln(n.core)&&Fi("REPLAY_STATE_HASH"),n.events.push(r),n.lastEventHash=r.eventHash}if(t){const i=Vr.parse(t);Y(i.version===Ie&&i.genesisHash===n.genesisHash&&i.finalEventHash===n.lastEventHash&&i.finalStateHash===Ln(n.core)&&i.eventCount===e.length&&i.executionManifestHash===Ln(n.executionManifest),"REPLAY_MANIFEST_MISMATCH")}return n}function Zc(n){return Vr.parse({version:Ie,genesisHash:n.genesisHash,finalEventHash:n.lastEventHash,finalStateHash:Ln(n.core),eventCount:n.events.length,executionManifestHash:Ln(n.executionManifest)})}function vf(n){let e=Mi(n.setup);for(const t of n.commands)e=At(e,t).session;Y(e.events.length===n.events.length,"RESIMULATION_LENGTH");for(let t=0;t<n.events.length;t++)Y(Kn(Qn(e.events[t]))===Kn(Qn(n.events[t])),`RESIMULATION_MISMATCH_${t}`);Y(Ln(e.core)===Ln(n.core),"RESIMULATION_FINAL_STATE")}function Xc(n){const t={commandId:`auto-${String(n.revision+1).padStart(6,"0")}`,expectedRevision:n.revision};if(n.core.phase==="SETUP")return{...t,actorId:"SYSTEM",kind:"CONFIRM_TEAMS",payload:{}};if(n.core.phase==="TOSS")return{...t,actorId:`AI:${n.setup.teams[0].teamId}`,kind:"CALL_TOSS",payload:{teamId:n.setup.teams[0].teamId,call:"HEADS"}};if(n.core.phase==="AWAITING_INNINGS")return{...t,actorId:`AI:${n.core.tossWinnerId}`,kind:"CHOOSE_INNINGS",payload:{teamId:n.core.tossWinnerId,choice:"BAT"}};const i=Hn(n);if(n.core.phase==="AWAITING_BATTER"){const a=Hi(n),r=new Set([i.innings.northBatterId,i.innings.southBatterId,...i.innings.dismissed]),o=a.playerIds.find(s=>!r.has(s));return Y(o,"NO_ELIGIBLE_BATTER"),{...t,actorId:`AI:${a.teamId}`,kind:"SET_BATTER",payload:{teamId:a.teamId,playerId:o}}}if(n.core.phase==="AWAITING_BOWLER"){const a=je(n),r=a.xi.filter(o=>o.bowlingStyle!==null&&o.playerId!==a.keeperId&&o.playerId!==i.innings.previousOverBowlerId&&i.bowling[o.playerId].legalBalls<60).sort((o,s)=>i.bowling[o.playerId].legalBalls-i.bowling[s.playerId].legalBalls||o.playerId.localeCompare(s.playerId));return Y(r.length,"NO_ELIGIBLE_BOWLER"),{...t,actorId:`AI:${a.teamId}`,kind:"SET_BOWLER",payload:{teamId:a.teamId,bowlerId:r[0].playerId}}}return Y(n.core.phase==="READY","INVALID_AUTOPILOT_PHASE"),{...t,actorId:"SYSTEM",kind:"ADVANCE",payload:{scope:"OVER"}}}function lo(n){Y(n.core.phase==="COMPLETE"&&n.core.innings.length===2&&n.core.result,"SCORECARD_NOT_COMPLETE");const e=n.core.innings.map((t,i)=>{ee(t);const a=n.events.filter(g=>g.type==="DELIVERY_RECORDED"&&g.payload.event.inningsIndex===i);let r=0,o=0;const s=[];for(const g of a){const E=g.payload.event;r+=E.batRuns+Object.values(E.extras).reduce((h,f)=>h+f,0),o+=Number(E.legalBall),E.dismissal&&s.push({playerId:E.dismissal.playerId,runs:r,legalBalls:o,sequence:g.sequence})}Y(r===t.innings.runs&&o===t.innings.legalBalls&&a.length===t.innings.deliveryAttempts,"PROJECTED_SCORE_MISMATCH");const d=t.innings;return{battingTeamId:d.battingTeamId,bowlingTeamId:d.bowlingTeamId,runs:d.runs,wickets:d.wickets,legalBalls:d.legalBalls,overs:`${Math.floor(d.legalBalls/6)}.${d.legalBalls%6}`,extras:xe(d.extras),batting:xe(t.batting),bowling:xe(t.bowling),fallOfWickets:s,targetToWin:d.targetToWin}});return Mg.parse({matchId:n.setup.matchId,innings:e,result:n.core.result})}function Rf(n,e,t){Y(!!n&&typeof n=="object"&&!Array.isArray(n),"SAVE_SHAPE");const i=n,a=i.setup;Y(!!a&&a.setupVersion==="LC_ODI_SETUP_V1","SAVE_SETUP"),Y(Array.isArray(a.teams)&&a.teams.length===2,"SAVE_TEAMS");const r=Mc({setupVersion:"LC_ODI_SETUP_V1",setup:{schemaVersion:"1.0.0",gameId:a.gameId,matchId:a.matchId,format:"ODI",worldPackId:Mn.worldPackId,rulesId:a.versions.rules,modelId:a.versions.model,randomId:a.versions.random,seed:a.seed,teamIds:a.teams.map(s=>s.teamId),groundId:a.ground.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:Mn.worldFileSha256,worldCanonicalSha256:a.versions.worldHash,rulesHash:a.versions.rulesHash,modelHash:a.versions.modelHash,stagePackHash:a.stagePackHash,selectedTeams:a.teams.map(s=>({teamId:s.teamId,playerIds:[...s.playerIds],captainId:s.captainId,keeperId:s.keeperId}))},e,t);Y(Array.isArray(i.commands),"SAVE_COMMANDS");let o=Mi(r);for(const s of i.commands)o=At(o,s).session;return Y(typeof i.revision=="number"&&o.revision===i.revision,"SAVE_REVISION"),Y(Array.isArray(i.events)&&Ln(o.events)===Ln(i.events),"SAVE_EVENTS"),Y(i.core!==void 0&&Ln(o.core)===Ln(i.core),"SAVE_CORE"),Y(i.receipts!==void 0&&Ln(o.receipts)===Ln(i.receipts),"SAVE_RECEIPTS"),Y(i.executionManifest!==void 0&&Ln(o.executionManifest)===Ln(i.executionManifest),"SAVE_MANIFEST"),Y(i.genesisHash===o.genesisHash&&i.lastEventHash===o.lastEventHash,"SAVE_CHAIN"),o}const Af=kn().hash;Ye(),Af(Oi),kn(),kn(),new Set(v1),new Map(Object.entries(b1).flatMap(([n,e])=>e.map(t=>[t,n]))),kn();function Jc(n,e){if(!n)throw new Error(`LC_T20_OFFSCREEN_${e}`)}function Lf(n){const{seasonId:e,fixtureId:t,matchId:i,matchDayDate:a,session:r}=n;Jc(r.core.phase==="COMPLETE","CONDITION_DELTA_REQUIRES_COMPLETE_MATCH"),Jc(r.setup.matchId===i,"CONDITION_DELTA_MATCH_ID_MISMATCH");const o=r.setup.teams.flatMap(d=>[...d.playerIds]).sort(),s=Object.fromEntries(o.map(d=>[d,r.core.fatigueBp[d]??0]).filter(([,d])=>d>0));return _a.parse({deltaVersion:"LC_T20_MATCH_CONDITION_DELTA_V1",matchCompletionKey:`complete-${e}-${t}`,matchId:i,matchDayDate:a,playerFatigueDeltaBp:s})}const Qc=Object.fromEntries(Object.keys(gt.shape).map(n=>[n,50])),Of=8*1024*1024;function wf(n,e,t){if(new TextEncoder().encode(n).byteLength>ts)throw new Error("Roster import exceeds 25 MB.");const i=Op.parse(JSON.parse(n)),a=kn().hash(i),r=[],o=i.world.players.map(h=>{const f={},A={};for(const N of Na){const b=h.skills?.[N]??{},w=Object.keys(Qc).filter(p=>!(p in b)),D=h.exposureBalls?.[N]===void 0;(w.length||D)&&r.push({playerId:h.playerId,format:N,fields:w,exposureMissing:D}),f[N]=gt.parse({...Qc,...b}),A[N]=h.exposureBalls?.[N]??0}return{...h,skills:f,exposureBalls:A,provenance:{kind:"USER_SUPPLIED",sourceId:i.sourceId,sourceHash:a,confidenceBp:1e3}}}),s=ua({...i.world,packId:`world-import-${a}`,provenance:`User-supplied roster ${i.sourceId}; source ${a}`,players:o},t,e);if([...s.players,...s.teams,...s.grounds].map(h=>h.name).some(h=>h!==h.trim()||[...h].some(f=>{const A=f.codePointAt(0);return A<32||A>=127&&A<=159})))throw new Error("Names cannot contain control characters or surrounding spaces.");const g=new Map(s.players.map(h=>[h.playerId,h])),E=new Set;for(const h of s.teams){const f=h.squadIds.map(A=>g.get(A));if(!f.some(A=>A.role==="KEEPER")||f.filter(A=>A.bowlingStyle!==null&&["BOWLER","ALLROUNDER"].includes(A.role)).length<5)throw new Error(`Roster cannot form a valid XI: ${h.teamId}`);for(const A of f){if(E.has(A.playerId))throw new Error(`Player belongs to multiple squads: ${A.playerId}`);E.add(A.playerId)}}if(E.size!==s.players.length)throw new Error("Every imported player must belong to one squad.");return{world:s,sourceHash:a,priorFields:r}}const uo=new WeakMap,nl=new WeakMap,el=new Map;function tl(n,e){return`${n.join(",")}|${e.join(",")}`}function il(n,e){mo(n);let t=uo.get(n);return t||(t=new Set,uo.set(n,t)),t.add(e),n}function al(n,e,t){return ye.parse({version:"LC_STAGED_ROSTER_PACK_V1",sourceText:n,...wf(n,e,t)})}function Nf(n,e,t){const i=al(n,e,t);if(new TextEncoder().encode(In(i)).byteLength>Of)throw new Error("Roster pack exceeds the 8 MiB limit for new games.");return il(i,tl(e,t))}function Df(n,e,t){const i=tl(e,t);if(n!==null&&typeof n=="object"&&Object.isFrozen(n)&&uo.get(n)?.has(i))return n;const a=ye.parse(n),r=al(a.sourceText,e,t);if(In(a)!==In(r))throw new Error("Roster pack contents do not match the staged source and priors.");return il(a,i)}function yf(n,e,t,i){const a=Df(n,t,i),r=as.parse(e);if(!a.world.grounds.some(d=>d.groundId===r.groundId))throw new Error("Unknown match ground.");if(r.teams[0].teamId===r.teams[1].teamId)throw new Error("Match teams must differ.");const o=new Map(a.world.players.map(d=>[d.playerId,d])),s=new Set;for(const d of r.teams){const g=a.world.teams.find(E=>E.teamId===d.teamId);if(!g||new Set(d.playerIds).size!==11||d.playerIds.some(E=>!g.squadIds.includes(E)))throw new Error("Invalid team or XI membership.");if(!d.playerIds.includes(d.captainId)||!d.playerIds.includes(d.keeperId)||o.get(d.keeperId)?.role!=="KEEPER")throw new Error("Select an eligible captain and keeper.");if(d.playerIds.filter(E=>{const h=o.get(E);return h.bowlingStyle!==null&&["BOWLER","ALLROUNDER"].includes(h.role)}).length<5)throw new Error("The XI needs five bowling-capable players.");for(const E of d.playerIds){if(s.has(E))throw new Error("An XI player cannot play for both sides.");s.add(E)}}return{pack:a,selection:r}}function mo(n){return n!==null&&typeof n=="object"&&(Object.values(n).forEach(mo),Object.freeze(n)),n}function ol(n,e){const t=os.parse(e),{pack:i,selection:a}=yf(n,t.selection,ke.map(h=>h.rulesId),ne.manifest.variationIds),r=ke.find(h=>h.format===t.format&&i.world.rulesIds.includes(h.rulesId));if(!r)throw new Error("The roster does not support this match format.");const o=new Map(i.world.players.map(h=>[h.playerId,h])),s=a.teams.map(h=>{const f=i.world.teams.find(A=>A.teamId===h.teamId);return{teamId:f.teamId,name:f.name,colours:f.colours,playerIds:h.playerIds,xi:h.playerIds.map(A=>o.get(A)),captainId:h.captainId,keeperId:h.keeperId}});let d=nl.get(i);if(!d){const h=kn().hash;d={worldHash:h(i.world),rosterPackHash:h(i)},Object.isFrozen(i)&&nl.set(i,d)}let g=el.get(r.rulesId);g||(g=kn().hash(r),el.set(r.rulesId,g));const E=structuredClone({version:"LC_ROSTER_MATCH_PREPARATION_V1",gameId:t.gameId,matchId:t.matchId,seed:t.seed,format:t.format,worldHash:d.worldHash,rosterPackHash:d.rosterPackHash,rulesId:r.rulesId,rulesHash:g,modelHash:Bn,stagePackHash:jn,ground:i.world.grounds.find(h=>h.groundId===a.groundId),teams:s});return mo(E)}const se=kn().hash,go=new WeakMap,qe=n=>{throw new Error(`LC_ROSTER_T20_${n}`)};function po(n){const e=n.events.at(-1),t=n.events[0];return se({setupVersion:n.setup.setupVersion,rosterPackHash:n.setup.rosterPackHash,manifestEngine:n.executionManifest.engine,manifestSetupHash:n.executionManifest.setupHash,revision:n.revision,genesisHash:n.genesisHash,lastEventHash:n.lastEventHash,eventCount:n.events.length,firstEventHash:t?t.eventHash:null,tailEventHash:e?e.eventHash:null,commandCount:n.commands.length,core:n.core})}function Cf(n,e){(n.format!=="T20"||n.teams.length!==2)&&qe("FORMAT");const t={setupVersion:"LC_T20_ROSTER_SETUP_V2",gameId:n.gameId,matchId:n.matchId,seed:n.seed,format:"T20",teams:n.teams,ground:n.ground,versions:{schema:"1.0.0",engine:"LC_T20_ROSTER_SETUP_V2",random:$n,rules:n.rulesId,rulesHash:n.rulesHash,model:ne.manifest.modelId,modelHash:n.modelHash,worldHash:n.worldHash},stagePackHash:n.stagePackHash,modelStatus:"SYNTHETIC_ALPHA",worldSeed:e,fixtureOnly:!0,rosterPackHash:n.rosterPackHash};return Object.freeze(t.versions),Object.freeze(t)}function Vi(n,e){const t=ol(n,e),i=Cf(t,n.sourceHash),a=se(i),r=rs.parse({engine:"LC_T20_MATCH_ROSTER_V2",eventChain:pe,conditionPolicy:pa,conditionPolicyHash:J1,setupHash:a,worldHash:i.versions.worldHash,rulesHash:i.versions.rulesHash,modelHash:i.versions.modelHash,stagePackHash:i.stagePackHash,randomVersion:$n,scoringVersion:$e,probabilityVersion:zn}),o={phase:"SETUP",setupHash:a,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:structuredClone(i.ground.pitchPrior),fatigueBp:Object.fromEntries(i.teams.flatMap(g=>g.playerIds).map(g=>[g,0]))},s=se([pe,a,se(r)]),d={setup:i,executionManifest:r,core:o,revision:0,events:[],receipts:{},commands:[],genesisHash:s,lastEventHash:s};return go.set(d,po(d)),d}function Wi(n,e){const t=go.get(n);t||qe("SESSION_UNVERIFIED"),po(n)!==t&&qe("SESSION_TAMPERED");const i=vt(n,e),a=i.session;return go.set(a,po(a)),{session:a,receipt:i.receipt}}function rl(n,e){(!n||typeof n!="object"||Array.isArray(n))&&qe("SAVE_SHAPE");const t=n,i=t.setup;if(!i)throw new Error("LC_ROSTER_T20_SAVE_SETUP");(i.setupVersion!=="LC_T20_ROSTER_SETUP_V2"||!Array.isArray(i.teams)||i.teams.length!==2)&&qe("SAVE_SETUP");let a=Vi(e,{gameId:i.gameId,matchId:i.matchId,seed:i.seed,format:"T20",selection:{groundId:i.ground.groundId,teams:i.teams.map(r=>({teamId:r.teamId,playerIds:[...r.playerIds],captainId:r.captainId,keeperId:r.keeperId}))}});In(a.setup)!==In(i)&&qe("SAVE_SETUP_MISMATCH"),Array.isArray(t.commands)||qe("SAVE_COMMANDS");for(const r of t.commands)a=Wi(a,r).session;return(t.revision!==a.revision||se(t.core)!==se(a.core)||se(t.events)!==se(a.events)||se(t.commands)!==se(a.commands)||se(t.receipts)!==se(a.receipts)||se(t.executionManifest)!==se(a.executionManifest)||t.genesisHash!==a.genesisHash||t.lastEventHash!==a.lastEventHash)&&qe("SAVE_REPLAY_MISMATCH"),a}function kf(n,e){const t=rl(n,e),i=t.setup,a=Vi(e,{gameId:i.gameId,matchId:i.matchId,seed:i.seed,format:"T20",selection:{groundId:i.ground.groundId,teams:i.teams.map(r=>({teamId:r.teamId,playerIds:[...r.playerIds],captainId:r.captainId,keeperId:r.keeperId}))}});return Uc(a,t.events,Gc(t))}const qn=kn().hash,Io=new WeakMap,Ze=n=>{throw new Error(`LC_ROSTER_ODI_${n}`)};function Bf(n,e){(n.format!=="ODI"||n.teams.length!==2)&&Ze("FORMAT");const t={setupVersion:"LC_ODI_ROSTER_SETUP_V2",gameId:n.gameId,matchId:n.matchId,seed:n.seed,format:"ODI",teams:n.teams,ground:n.ground,versions:{schema:"1.0.0",engine:"LC_ODI_ROSTER_SETUP_V2",random:$n,rules:n.rulesId,rulesHash:n.rulesHash,model:ne.manifest.modelId,modelHash:n.modelHash,worldHash:n.worldHash},stagePackHash:n.stagePackHash,modelStatus:"SYNTHETIC_ALPHA",worldSeed:e,fixtureOnly:!0,rosterPackHash:n.rosterPackHash};return Object.freeze(t.versions),Object.freeze(t)}function $i(n,e){const t=ol(n,e),i=Bf(t,n.sourceHash),a=qn(i),r=wp.parse({engine:"LC_ODI_MATCH_ROSTER_V2",eventChain:Ie,conditionPolicy:ha,conditionPolicyHash:gf,setupHash:a,worldHash:i.versions.worldHash,rulesHash:i.versions.rulesHash,modelHash:i.versions.modelHash,stagePackHash:i.stagePackHash,randomVersion:$n,scoringVersion:$e,probabilityVersion:zn}),o={phase:"SETUP",setupHash:a,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:structuredClone(i.ground.pitchPrior),fatigueBp:Object.fromEntries(i.teams.flatMap(g=>g.playerIds).map(g=>[g,0]))},s=qn([Ie,a,qn(r)]),d={setup:i,executionManifest:r,core:o,revision:0,events:[],receipts:{},commands:[],genesisHash:s,lastEventHash:s};return Io.set(d,qn(d)),d}function Ui(n,e){const t=Io.get(n);t||Ze("SESSION_UNVERIFIED"),qn(n)!==t&&Ze("SESSION_TAMPERED");const i=At(n,e),a=i.session;return Io.set(a,qn(a)),{session:a,receipt:i.receipt}}function sl(n,e){(!n||typeof n!="object"||Array.isArray(n))&&Ze("SAVE_SHAPE");const t=n,i=t.setup;if(!i)throw new Error("LC_ROSTER_ODI_SAVE_SETUP");(i.setupVersion!=="LC_ODI_ROSTER_SETUP_V2"||!Array.isArray(i.teams)||i.teams.length!==2)&&Ze("SAVE_SETUP");let a=$i(e,{gameId:i.gameId,matchId:i.matchId,seed:i.seed,format:"ODI",selection:{groundId:i.ground.groundId,teams:i.teams.map(r=>({teamId:r.teamId,playerIds:[...r.playerIds],captainId:r.captainId,keeperId:r.keeperId}))}});In(a.setup)!==In(i)&&Ze("SAVE_SETUP_MISMATCH"),Array.isArray(t.commands)||Ze("SAVE_COMMANDS");for(const r of t.commands)a=Ui(a,r).session;return(t.revision!==a.revision||qn(t.core)!==qn(a.core)||qn(t.events)!==qn(a.events)||qn(t.commands)!==qn(a.commands)||qn(t.receipts)!==qn(a.receipts)||qn(t.executionManifest)!==qn(a.executionManifest)||t.genesisHash!==a.genesisHash||t.lastEventHash!==a.lastEventHash)&&Ze("SAVE_REPLAY_MISMATCH"),a}function Pf(n,e){const t=sl(n,e),i=t.setup,a=$i(e,{gameId:i.gameId,matchId:i.matchId,seed:i.seed,format:"ODI",selection:{groundId:i.ground.groundId,teams:i.teams.map(r=>({teamId:r.teamId,playerIds:[...r.playerIds],captainId:r.captainId,keeperId:r.keeperId}))}});return qc(a,t.events,Zc(t))}kn().hash,kn().hash,kn().hash,kn().hash,kn(),kn(),kn(),ke.map(n=>n.rulesId),ne.manifest.variationIds,us.parse({modelVersion:ds,calibrationStatus:"FICTIONAL_PLACEHOLDER",disclaimer:"Fictional player lifecycle parameters (v1): permanent skill development, ageing, retirement, and youth intake use deterministic gameplay curves and are not empirically calibrated. Contracts and budgets are excluded.",minPermanentSkill:18,maxPermanentSkill:86,youthMinAgeYears:17,youthMaxAgeYears:19,growthWindowMaxAgeYears:25,primeWindowMaxAgeYears:30,earliestVoluntaryRetirementAgeYears:34,mandatoryRetirementAgeYears:40,minSquadKeepers:2,minSquadBowlingCapable:7}),Ss.parse({modelVersion:fs,calibrationStatus:"FICTIONAL_PLACEHOLDER",disclaimer:"Fictional domestic contract system (v1): symmetrical club wage budgets, player market valuations, persistent negotiation rounds, and buyout dead-cap rules use deterministic gameplay parameters. Auctions and international release rules are deferred.",annualClubWageBudgetK:II,minAnnualWageK:hI,maxAnnualWageK:fI,youthRookieAnnualWageK:EI,minContractTermSeasons:Es,maxContractTermSeasons:at,maxNegotiationRounds:ot,releaseBuyoutPercent:SI,minFreeAgentPoolSize:_I,maxFreeAgentPoolSize:TI}),Ye(),kn();const cl=n=>structuredClone(n),xf=n=>{throw new Error(`LC_SUPER_OVER_${n}`)};function Pn(n,e){n||xf(e)}const ll=3,Ff=6,Hf={T20:{ledgerRulesId:"LC_T20_01",allocatedBalls:120,slots:Ja,validateField:bt,rulesId:Ps,recordSchemaId:xs},ODI:{ledgerRulesId:"LC_ODI_01",allocatedBalls:300,slots:bc,validateField:Rt,rulesId:Fs,recordSchemaId:Hs}};function jt(n){return Hf[n.setup.format]}function qt(n,e){const t=n.setup.teams.find(i=>i.teamId===e);return Pn(t,"UNKNOWN_TEAM"),t}function dl(n,e){const t=n.setup.teams.find(i=>i.teamId!==e);return Pn(t,"UNKNOWN_TEAM"),t.teamId}function Lt(n,e){const t=n.setup.teams.flatMap(i=>i.xi).find(i=>i.playerId===e);return Pn(t,"UNKNOWN_PLAYER"),t}function Mf(n){const e=Li.positions.find(t=>t.slotId===n);return Pn(e,"UNKNOWN_FIELD_POSITION"),e}function Vf(n){return(n.setup.format==="T20"||n.setup.format==="ODI")&&n.core.phase==="COMPLETE"&&n.core.result?.kind==="TIE"}function ho(n,e,t){const i=new Set(e.excludedBatters[t]??[]);return qt(n,t).playerIds.filter(a=>!i.has(a))}function fo(n,e,t){const i=qt(n,t),a=new Set(e.excludedBowlers[t]??[]);return i.playerIds.filter(r=>r!==i.keeperId&&Lt(n,r).bowlingStyle!==null&&!a.has(r))}function Zt(n){const e=n.rounds[n.rounds.length-1];Pn(e,"NO_ROUND");const t=e.innings[e.innings.length-1];return Pn(t,"NO_INNINGS"),t}function Wf(n){return n.rounds[n.rounds.length-1].innings.length===1?0:1}function $f(n,e,t){return ho(n,e,t).length>=2&&fo(n,e,dl(n,t)).length>=1}function Eo(n,e,t){const i=e.rounds[e.rounds.length-1];if(!$f(n,e,t)){e.phase="COMPLETE",e.completionReason="NO_ELIGIBLE_PLAYERS";return}i.innings.push({battingTeamId:t,bowlingTeamId:dl(n,t),batterIds:null,bowlerId:null,ledger:null,complete:!1}),e.phase="AWAITING_LINEUP"}function Uf(n){Pn(Vf(n),"MATCH_NOT_TIED");const e=n.core.innings[1]?.innings.battingTeamId;Pn(e,"NO_SECOND_INNINGS");const t={rulesId:jt(n).rulesId,gameId:n.setup.gameId,baseLastEventHash:n.lastEventHash,rounds:[{roundNumber:1,innings:[]}],phase:"AWAITING_LINEUP",attemptOrdinal:n.core.globalAttemptOrdinal,firstBattingTeamId:e,excludedBatters:Object.fromEntries(n.setup.teams.map(i=>[i.teamId,[]])),excludedBowlers:Object.fromEntries(n.setup.teams.map(i=>[i.teamId,[]])),aggression:{},deliveries:[],winnerTeamId:null,completionReason:null};return Eo(n,t,e),t}function Gf(n,e,t,i){const a=qt(n,t.battingTeamId),r=qt(n,t.bowlingTeamId),o=[...t.batterIds,...a.playerIds.filter(s=>!t.batterIds.includes(s))];return ee({engineVersion:$e,rulesId:jt(n).ledgerRulesId,nextDeliveryIndex:e.attemptOrdinal,batting:Object.fromEntries(a.playerIds.map(s=>[s,{runs:0,ballsFaced:0,fours:0,sixes:0,dismissed:!1}])),bowling:Object.fromEntries(r.playerIds.map(s=>[s,{runsConceded:0,legalBalls:0,wickets:0,maidens:0}])),dismissals:{},keeperId:r.keeperId,outfieldIds:r.playerIds.filter(s=>s!==r.keeperId).slice(0,9),currentOverRuns:0,innings:{index:Wf(e),battingTeamId:a.teamId,bowlingTeamId:r.teamId,runs:0,wickets:0,legalBalls:0,deliveryAttempts:0,targetToWin:i,allocatedBalls:jt(n).allocatedBalls,extras:{wides:0,noBalls:0,byes:0,legByes:0,penalties:0},northBatterId:null,southBatterId:null,strikerEnd:"NORTH",battingOrder:o,dismissed:[],bowlerId:null,previousOverBowlerId:null,bowlerLegalBalls:Object.fromEntries(r.playerIds.map(s=>[s,0])),freeHitPending:!1,ballAgeLegalBalls:0,complete:!1}})}function ul(n,e){const t=Zt(e);if(!t.batterIds||!t.bowlerId)return;const i=e.rounds[e.rounds.length-1],a=i.innings.length===2?i.innings[0].ledger.innings.runs+1:null;let r=Gf(n,e,t,a);const o=cl(r);o.innings.northBatterId=t.batterIds[0],r=wi(ee(o),t.batterIds[1]);const s=qt(n,t.bowlingTeamId),d=s.playerIds.filter(g=>g!==s.keeperId&&g!==t.bowlerId);r=ao(r,t.bowlerId,d),t.ledger=r,e.phase="READY"}function zf(n,e){const t=jt(n).slots;return[...e.outfieldIds].sort().map((i,a)=>({slotId:t[a],playerId:i}))}function Yf(n,e){const t=Zt(e),i=t.ledger,a=Oe(i),r=Lt(n,a.strikerId),o=Lt(n,a.bowlerId),s=Lt(n,a.keeperId),d=n.setup.format,g=zf(n,i);jt(n).validateField(g,i.outfieldIds,r.batHand,i.innings.legalBalls);const E=ro({kind:"GENERATE_DELIVERY",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:jn,randomVersion:$n,probabilityVersion:zn,modelId:ge,modelHash:Bn,lutVersion:Se,lutHash:Ae,rulesHash:n.setup.versions.rulesHash,matchId:n.setup.matchId,seed:n.setup.seed,attemptOrdinal:e.attemptOrdinal,format:d,phase:yi(d,i.innings.legalBalls),context:a,bowling:{bowlingStyle:o.bowlingStyle,controlRating:o.skills[d].control,movementRating:o.skills[d].movement,fatigueBp:n.core.fatigueBp[o.playerId]??0,line:"STUMPS",intendedLength:"GOOD",effort:"NORMAL",variationId:"stock"},batting:{defenceRating:r.skills[d].defence,timingRating:r.skills[d].timing,powerRating:r.skills[d].power,rotationRating:r.skills[d].rotation,vsPaceRating:r.skills[d].vsPace,vsSpinRating:r.skills[d].vsSpin,aggression:e.aggression[r.playerId]??3,intent:"NORMAL",attemptedStroke:!0,shotSectorWeights:[...r.shotSectorWeights]},conditions:{seamBp:n.core.pitch.seamBp,turnBp:n.core.pitch.turnBp},field:{keeper:{keepingRating:s.skills[d].keeping,catchingRating:s.skills[d].catching,throwingRating:s.skills[d].throwing},slots:g.map(w=>{const D=Lt(n,w.playerId),p=Mf(w.slotId);return{playerId:w.playerId,sector:p.sector,depth:p.depth,role:w.slotId.startsWith("slip")?"SLIP":"NORMAL",catchingRating:D.skills[d].catching,throwingRating:D.skills[d].throwing}})}}),h=to(a,E.resolution),f=io(i,h);t.ledger=f.ledger,e.attemptOrdinal+=1,e.deliveries.push(h);const A=f.ledger.innings,N=t.batterIds.length-1,b=A.targetToWin!==null&&A.runs>=A.targetToWin;if(A.legalBalls>=Ff||A.wickets>=N||b||A.complete)Kf(n,e);else if(f.observation.requiredBatterEnd){const w=t.batterIds.find(D=>!A.dismissed.includes(D)&&D!==A.northBatterId&&D!==A.southBatterId);Pn(w,"NO_NEXT_BATTER"),t.ledger=wi(f.ledger,w)}}function Kf(n,e){const t=Zt(e);t.complete=!0;const i=t.ledger.innings;e.excludedBatters[t.battingTeamId]=[...new Set([...e.excludedBatters[t.battingTeamId]??[],...i.dismissed])],e.excludedBowlers[t.bowlingTeamId]=[...new Set([...e.excludedBowlers[t.bowlingTeamId]??[],t.bowlerId])];const a=e.rounds[e.rounds.length-1];if(a.innings.length===1){Eo(n,e,t.bowlingTeamId);return}const r=a.innings[0].ledger.innings.runs,o=i.runs;if(r!==o){e.winnerTeamId=o>r?t.battingTeamId:t.bowlingTeamId,e.completionReason="WON",e.phase="COMPLETE";return}e.rounds.push({roundNumber:a.roundNumber+1,innings:[]}),Eo(n,e,t.battingTeamId)}function jf(n,e,t){const i=Ti.parse(t),a=cl(e);Pn(a.phase!=="COMPLETE","COMPLETE");const r=Zt(a);switch(i.kind){case"SET_SUPER_OVER_BATTERS":{Pn(a.phase==="AWAITING_LINEUP"&&r.batterIds===null,"WRONG_PHASE"),Pn(i.teamId===r.battingTeamId,"NOT_BATTING_TEAM");const o=new Set(ho(n,a,i.teamId));Pn(new Set(i.playerIds).size===i.playerIds.length,"DUPLICATE_BATTER"),Pn(i.playerIds.every(s=>o.has(s)),"INELIGIBLE_BATTER"),Pn(i.playerIds.length===Math.min(ll,o.size),"BATTER_COUNT"),r.batterIds=[...i.playerIds],ul(n,a);break}case"SET_SUPER_OVER_BOWLER":{Pn(a.phase==="AWAITING_LINEUP"&&r.bowlerId===null,"WRONG_PHASE"),Pn(i.teamId===r.bowlingTeamId,"NOT_BOWLING_TEAM"),Pn(fo(n,a,i.teamId).includes(i.playerId),"INELIGIBLE_BOWLER"),r.bowlerId=i.playerId,ul(n,a);break}case"SET_SUPER_OVER_AGGRESSION":{Pn(a.phase==="READY","WRONG_PHASE");const o=r.ledger.innings;Pn([o.northBatterId,o.southBatterId].includes(i.playerId),"BATTER_NOT_ACTIVE"),a.aggression[i.playerId]=i.aggression;break}case"BOWL_SUPER_OVER_BALL":{Pn(a.phase==="READY","WRONG_PHASE"),Yf(n,a);break}}return a}function qf(n,e){if(e.phase==="COMPLETE")return null;if(e.phase==="READY")return{kind:"BOWL_SUPER_OVER_BALL"};const t=Zt(e);if(t.batterIds===null){const a=ho(n,e,t.battingTeamId);return{kind:"SET_SUPER_OVER_BATTERS",teamId:t.battingTeamId,playerIds:a.slice(0,ll)}}const i=fo(n,e,t.bowlingTeamId).map(a=>Lt(n,a)).sort((a,r)=>r.skills[n.setup.format].control-a.skills[n.setup.format].control||(a.playerId<r.playerId?-1:1));return{kind:"SET_SUPER_OVER_BOWLER",teamId:t.bowlingTeamId,playerId:i[0].playerId}}Ye(),kn(),Ye();function Zf(n,e,t,i){const a=d=>d.eligible?Math.max(0,Math.ceil((i-d.legalBalls)/6)):0,r=e.find(d=>d.id===n);if(!r||a(r)<1)return!1;const o=t-1;if(o<=0)return!0;let s=0;for(const d of e){const g=d.id===n?a(d)-1:a(d);s+=Math.min(g,d.id===n?Math.floor(o/2):Math.ceil(o/2))}return s>=o}function ml(n,e,t){const i=n.filter(o=>o.eligible),a=new Set(i.filter(o=>Zf(o.id,n,e,t)).map(o=>o.id)),r=new Map;if(a.size===0)return r;for(const o of i)a.has(o.id)||r.set(o.id,"Would leave overs that no one could bowl");return r}const So="LC_NEW_GAME_WORLD_COPY_V1",Gi=kn();function Xf(n,e){if(Gi.hash(e)!==Mn.worldCanonicalSha256)throw new Error("The original world does not match its accepted hash.");const t=ua(n,["stock"],e.rulesIds);if([...t.players,...t.teams,...t.grounds].map(r=>r.name).some(r=>r.trim()!==r||r.length===0||[...r].some(o=>{const s=o.codePointAt(0);return s<32||s>=127&&s<=159})))throw new Error("Names must have 1 to 80 characters, with no control characters or surrounding spaces.");const a=structuredClone(t);if(a.packId=e.packId,a.players.length!==e.players.length||a.teams.length!==e.teams.length||a.grounds.length!==e.grounds.length)throw new Error("This editor cannot add or remove players, teams or grounds.");if(a.players.forEach((r,o)=>{r.name=e.players[o].name}),a.teams.forEach((r,o)=>{r.name=e.teams[o].name,r.colours=[...e.teams[o].colours]}),a.grounds.forEach((r,o)=>{r.name=e.grounds[o].name}),In(a)!==In(e))throw new Error("Only names and team colours can change in this editor.");return t}function Jf(n,e){const t=Xf(n,e);t.packId=e.packId;const i=Gi.hash({copyVersion:So,baseWorldCanonicalSha256:Mn.worldCanonicalSha256,world:t});return t.packId=`world-edit-${i}`,Bt.parse({copyVersion:So,baseWorldCanonicalSha256:Mn.worldCanonicalSha256,worldCanonicalSha256:Gi.hash(t),world:t})}function _o(n,e){if(!n||typeof n!="object"||!("copyVersion"in n)||n.copyVersion!==So)throw new Error("Unsupported world copy version.");const t=Bt.parse(n);if(t.baseWorldCanonicalSha256!==Mn.worldCanonicalSha256)throw new Error("The world copy has an unsupported base world.");if(Gi.hash(t.world)!==t.worldCanonicalSha256)throw new Error("The world copy hash does not match its contents.");const i=Jf(t.world,e);if(In(t)!==In(i))throw new Error("The world copy identity does not match its contents.");return t}const Ot="LC_T20_UI_V2",Un=Object.freeze({engine:"LC_T20_MATCH_V1",eventChain:"LC_T20_EVENT_CHAIN_V1",worldHash:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",rulesHash:"7c67aec8e3aef8be7b849775d83bad64847338e03326848ec1f1d0d99c6fa745",modelHash:"d47d5caca955b7a374b0052d712b1674bca6d855e222194ce9f0587d8580b7ab",stagePackHash:"34efa3037702e44a134ea38b414eab3e97c6f79f10b3e5458bc2ab05412e5d7a"}),Xe=Object.freeze({engine:"LC_ODI_MATCH_V1",eventChain:"LC_ODI_EVENT_CHAIN_V1",worldHash:Un.worldHash,rulesHash:"81f8ec39a793e3761dac2d477a7fc7d4981df2e69b262e88160cb93141c28ee5",modelHash:Un.modelHash,stagePackHash:Un.stagePackHash}),Xt=Object.freeze({engine:"LC_RED5_MATCH_V1",eventChain:"LC_RED5_EVENT_CHAIN_V1",worldHash:Un.worldHash,rulesHash:"819b388b1947f71c6228b21680687472760bfcf4a872f0f41cc9508e65928800",modelHash:Un.modelHash,stagePackHash:Un.stagePackHash});Object.freeze({engine:Xt.engine,eventChain:Xt.eventChain,random:"SHA256_COUNTER_V1",model:"synthetic-alpha-01",modelHash:Xt.modelHash,rules:"LC_RED5_01",rulesHash:Xt.rulesHash,worldHash:Xt.worldHash}),Object.freeze({engine:Un.engine,eventChain:Un.eventChain,random:"SHA256_COUNTER_V1",model:"synthetic-alpha-01",modelHash:Un.modelHash,rules:"LC_T20_01",rulesHash:Un.rulesHash,worldHash:Un.worldHash}),Object.freeze({engine:Xe.engine,eventChain:Xe.eventChain,random:"SHA256_COUNTER_V1",model:"synthetic-alpha-01",modelHash:Xe.modelHash,rules:"LC_ODI_01",rulesHash:Xe.rulesHash,worldHash:Xe.worldHash});const On={version:m(Ot),requestId:O().regex(/^ui-[0-9]+$/),expectedRevision:k().int().nonnegative()},zi={saveId:O().min(1).max(160),seasonId:O().min(1).max(128),scheduleSha256:O().regex(/^[a-f0-9]{64}$/),fixtureId:O().min(1).max(128),fixtureOrdinal:k().int().min(0).max(55),roundNumber:k().int().min(1).max(14),matchDayDate:tn(),homeTeamId:O().min(1).max(128),awayTeamId:O().min(1).max(128),groundId:O().min(1).max(128),matchId:O().min(1).max(128),matchGameId:O().min(1).max(128),matchSeed:O().min(1).max(256),selections:Cn([Yn,Yn]),careerStateSha256:O().regex(/^[a-f0-9]{64}$/),managedTeamId:O().min(1).max(128).optional()},gl=Dn("launchVersion",[u({...zi,launchVersion:m("LC_CAREER_USER_MATCH_LAUNCH_V1")}),u({...zi,launchVersion:m("LC_CAREER_USER_MATCH_LAUNCH_V2"),worldCopy:Bt}),u({...zi,launchVersion:m("LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"),rosterPack:ye}),u({...zi,launchVersion:m("LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"),rosterPack:ye,worldCopy:Bt.optional()})]),pl=Dn("type",[u({...On,type:m("BOOT"),fresh:W().optional(),careerFixture:gl.nullable().optional()}),u({...On,type:m("START"),format:L(["T20","ODI","RED_BALL"]).default("T20"),selections:Cn([Yn,Yn]),groundId:O().min(1),careerFixture:gl.nullable().optional(),worldCopy:Bt.nullable().optional(),rosterPack:ye.nullable().optional()}),u({...On,type:m("COMMAND"),origin:L(["HUMAN","AI"]),command:Zn([Pr,Hr,Gg])}),u({...On,type:m("AI_STEP"),clubStyle:W().optional(),matchAware:W().optional(),teamId:O().min(1).max(128),delegated:W().optional(),redBallProfile:ka.optional()}),u({...On,type:m("SET_DELEGATION"),teamId:O().min(1).max(128),expectedDelegationRevision:k().int().nonnegative(),categories:_(vs).max(10).refine(n=>new Set(n).size===n.length),redBallProfile:ka.optional()}),u({...On,type:m("VERIFY")}),u({...On,type:m("CHECK_SEEDED_WEATHER")}),u({...On,type:m("REBUILD_ANALYTICS")}),u({...On,type:m("CANCEL_ANALYTICS"),targetRequestId:O().regex(/^ui-[0-9]+$/)}),u({...On,type:m("PREVIEW_DIAGNOSTIC"),includeSeed:W().optional()}),u({...On,type:m("EXPORT_DIAGNOSTIC"),sha256:O().regex(/^[a-f0-9]{64}$/)}),u({...On,type:m("LIST_SAVES")}),u({...On,type:m("MANUAL_SAVE"),title:O().trim().min(1).max(80)}),u({...On,type:m("LOAD_SAVE"),saveId:O().min(1).max(160)}),u({...On,type:m("DELETE_SAVE"),saveId:O().min(1).max(160)}),u({...On,type:m("EXPORT_SAVE"),saveId:O().min(1).max(160).nullable()}),u({...On,type:m("IMPORT_SAVE"),archive:Hm(Uint8Array)}),u({...On,type:m("SUPER_OVER"),action:Dn("kind",[u({kind:m("START")}),u({kind:m("COMMAND"),command:Ti}),u({kind:m("AI"),teamId:O().min(1).max(128)})])}),u({...On,type:m("TOURNAMENT_START"),format:L(["T20","ODI"]),runId:O().min(1).max(128),runSeed:O().min(1).max(128),fixture:r2,rosterPack:ye.optional(),selections:Cn([Yn,Yn]).optional()}),u({...On,type:m("SCENARIO_START"),scenarioId:O().min(1).max(128)}),u({...On,type:m("RECOVER_MANAGED")}),u({...On,type:m("ABANDON_MANAGED")}),u({...On,type:m("RETRY_WRITER")}),u({...On,type:m("RELEASE_WRITER")})]);function Qf(n,e,t,i=()=>({gameId:"human-exhibition",matchId:"human-t20"})){const{world:a}=Ci(n,e),r={teams:a.teams.map(F=>{const C=F.squadIds.map(Z=>a.players.find(pn=>pn.playerId===Z)),$=C.find(Z=>Z.role==="KEEPER"),q=C.filter(Z=>Z.playerId!==$.playerId&&Le(Z)).slice(0,6),G=[$,...q,...C.filter(Z=>Z!==$&&!q.includes(Z))].slice(0,11);return{id:F.teamId,name:F.name,players:C.map(Z=>({id:Z.playerId,name:Z.name,role:Z.role,style:Z.bowlingStyle,canBowl:Le(Z),batHand:Z.batHand})),suggested:{teamId:F.teamId,playerIds:G.map(Z=>Z.playerId),captainId:G[0].playerId,keeperId:$.playerId}}}),grounds:a.grounds.map(F=>({id:F.groundId,name:F.name,seamBp:F.pitchPrior.seamBp,turnBp:F.pitchPrior.turnBp}))};let o=null,s=null,d=null,g=a;function E(F){if(s&&F){const C=_o(F,a).world,$=new Map(C.teams.map(Z=>[Z.teamId,Z.name])),q=new Map(C.grounds.map(Z=>[Z.groundId,Z.name])),G=new Map(C.players.map(Z=>[Z.playerId,Z.name]));g={...s.world,teams:s.world.teams.map(Z=>{const pn=$.get(Z.teamId);return pn?{...Z,name:pn}:Z}),grounds:s.world.grounds.map(Z=>{const pn=q.get(Z.groundId);return pn?{...Z,name:pn}:Z}),players:s.world.players.map(Z=>{const pn=G.get(Z.playerId);return pn?{...Z,name:pn}:Z})};return}g=s?.world??(F?_o(F,a).world:a)}function h(F){const C=F?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V2"?F.worldCopy:F?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"?F.worldCopy??null:null;E(C),d=F}const f=new Map,A=[],N=F=>Kn(Qn(F)),b=qs(2);let w=null,D=-1,p=null,I=null,v=null,y=null,S=[],R=[];function V(){if(!o)return null;const F=o,C=F.core,$=C.innings[C.activeInningsIndex],q=$?.innings;b.update(F.events);const G=C.phase==="COMPLETE"?xi(F):null,Z=Object.fromEntries(F.setup.teams.flatMap(Q=>Q.xi.map(En=>[En.playerId,g.players.find(wn=>wn.playerId===En.playerId)?.name??En.name]))),pn=Q=>g.teams.find(En=>En.teamId===Q)?.name??"",gn=C.phase==="TOSS"?F.setup.teams[0].teamId:C.phase==="AWAITING_INNINGS"?C.tossWinnerId:C.phase==="AWAITING_BATTER"?q.battingTeamId:C.phase==="AWAITING_BOWLER"?q.bowlingTeamId:null,Gn={TOSS:`${pn(gn)}: call the toss`,AWAITING_INNINGS:`${pn(C.tossWinnerId)} won the toss: choose bat or bowl`,AWAITING_BATTER:`${pn(gn)}: select ${q?.northBatterId===null&&q.southBatterId===null?"the opening batter":"the next batter"}`,AWAITING_BOWLER:`${pn(gn)}: select a bowler`,READY:"Ready: set tactics or advance play",COMPLETE:"Match complete: review the scorecard"},fe=(F.setup.teams.find(Q=>Q.teamId===gn)?.xi??[]).map(Q=>{let En="";C.phase==="AWAITING_BATTER"&&(En=$.batting[Q.playerId].dismissed?"Already dismissed":[q.northBatterId,q.southBatterId].includes(Q.playerId)?"Already batting":""),C.phase==="AWAITING_BOWLER"&&(En=Q.playerId===$.keeperId?"Designated keeper":Q.bowlingStyle===null?"Not a bowler":q.previousOverBowlerId===Q.playerId?"Bowled the previous over":$.bowling[Q.playerId].legalBalls>=24?"Four-over limit reached":"");const{power:wn,rotation:Yi,defence:Qe}=Q.skills.T20;return{id:Q.playerId,name:Z[Q.playerId]??Q.name,reason:En,...C.phase==="AWAITING_BATTER"?{batting:{power:wn,rotation:Yi,defence:Qe}}:{}}});if(C.phase==="AWAITING_BOWLER"&&$&&q){const Q=F.setup.teams.find(wn=>wn.teamId===gn)?.xi??[],En=ml(Q.map(wn=>({id:wn.playerId,eligible:wn.playerId!==$.keeperId&&wn.bowlingStyle!==null,legalBalls:$.bowling[wn.playerId]?.legalBalls??0})),Math.ceil((120-q.legalBalls)/6),24);for(const wn of fe)!wn.reason&&En.has(wn.id)&&(wn.reason=En.get(wn.id))}let Ee=C.phase==="COMPLETE"?"Match complete":C.phase!=="READY"?"Complete the next decision first":"";if(C.phase==="READY"&&$)try{const Q=q.strikerEnd==="NORTH"?q.northBatterId:q.southBatterId,En=F.setup.teams.flatMap(wn=>wn.xi).find(wn=>wn.playerId===Q);bt(C.fieldSlots,$.outfieldIds,En.batHand,q.legalBalls)}catch{Ee="Field is invalid for this striker. Apply a legal named field before advancing."}const be=C.result,Tn=Object.fromEntries(F.setup.teams.flatMap(Q=>Q.xi.map(En=>[En.playerId,En.batHand]))),nn=g.grounds.find(Q=>Q.groundId===F.setup.ground.groundId)?.name??F.setup.ground.name;if(w!==F||D!==F.revision||p!==g){const Q=Object.fromEntries(F.setup.teams.map(En=>[En.teamId,pn(En.teamId)]));S=cc({format:"T20",events:F.events,playerNames:Z,teamNames:Q,teamIds:[F.setup.teams[0].teamId,F.setup.teams[1].teamId],groundName:nn,presentationKey:`lcxxvi-commentary:T20:${F.setup.matchId}`}).entries,R=lc({format:"T20",matchId:F.setup.matchId,commentaryEntries:S}).cues,I=Js({format:"T20",phase:C.phase,innings:C.innings,activeIndex:C.activeInningsIndex,events:F.events,names:Z,pitch:C.pitch,fatigueBpByPlayerId:C.fatigueBp,activeBattingPlans:C.battingPlans,activeBowlingPlan:C.bowlingPlan,activeFieldSlots:C.fieldSlots,outfieldIds:$?.outfieldIds??[],bowlerVariationsByPlayerId:Object.fromEntries(F.setup.teams.flatMap(En=>En.xi.map(wn=>[wn.playerId,wn.variations])))}),v=rc({format:"T20",phase:C.phase,innings:C.innings,activeIndex:C.activeInningsIndex,fieldSlots:C.fieldSlots,events:F.events,names:Z,hands:Tn}),w=F,D=F.revision,p=g}const cn=S,rn=C.phase==="COMPLETE"&&be?be.kind==="TIE"?"Match tied":`${pn(be.winnerTeamId)} won by ${be.marginRuns??be.marginWickets} ${be.marginType?.toLowerCase()}`:null;return{format:"T20",fatigueBp:{...C.fatigueBp},captainNotes:Object.fromEntries(F.setup.teams.map(Q=>[Q.teamId,n3(F.commands,Q.teamId,Z)])),revision:F.revision,phase:C.phase,nextDecision:Gn[C.phase]??C.phase,decisionTeamId:gn,teams:F.setup.teams.map(Q=>({id:Q.teamId,name:pn(Q.teamId),captainId:Q.captainId,keeperId:Q.keeperId,playerIds:[...Q.playerIds],...g.packId!==a.packId?{colours:[...g.teams.find(En=>En.teamId===Q.teamId).colours]}:{}})),names:Z,hands:Tn,ground:g.grounds.find(Q=>Q.groundId===F.setup.ground.groundId)?.name??F.setup.ground.name,innings:structuredClone(C.innings),activeIndex:C.activeInningsIndex,candidates:fe,bowlingPlan:structuredClone(C.bowlingPlan),battingPlans:structuredClone(C.battingPlans),fieldSlots:structuredClone(C.fieldSlots),positions:Li.positions.map(Q=>Q.slotId),matchId:F.setup.matchId,advanceReason:Ee,commentary:cn,audioCues:R,scorecard:G,analytics:G?b.snapshot(G):null,tacticalAssistant:I,fieldPresentation:v,matchAward:C.phase==="COMPLETE"&&G?y??=mc({format:"T20",scorecard:G,events:F.events,playerNames:Z,teamNames:Object.fromEntries(g.teams.map(Q=>[Q.teamId,Q.name]))}):null,resultText:rn,eventCount:F.events.length,lastEventHash:F.lastEventHash}}function U(){if(!d||d.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"||!o||o.core.phase!=="COMPLETE")return null;const F=xi(o),C=N(F),$=Lf({seasonId:d.seasonId,fixtureId:d.fixtureId,matchId:d.matchId,matchDayDate:d.matchDayDate,session:o}),q=N({source:"USER_MATCH",seasonId:d.seasonId,fixtureId:d.fixtureId,matchId:d.matchId,scorecardSha256:C,finalEventHash:o.lastEventHash});return{resultVersion:"LC_CAREER_USER_MATCH_RESULT_V1",seasonId:d.seasonId,scheduleSha256:d.scheduleSha256,fixtureId:d.fixtureId,matchId:d.matchId,fixtureOrdinal:d.fixtureOrdinal,roundNumber:d.roundNumber,matchDayDate:d.matchDayDate,homeTeamId:d.homeTeamId,awayTeamId:d.awayTeamId,selectedTeams:[structuredClone(d.selections[0]),structuredClone(d.selections[1])],scorecard:F,scorecardSha256:C,finalEventHash:o.lastEventHash,sourceCompletionSha256:q,conditionDelta:$,completedSession:structuredClone(o)}}function H(){if(!o||o.core.phase!=="COMPLETE")throw new Error("Complete the match before verifying its final scorecard.");const F=s?kf(o,s):cf(o.setup,o.events,Gc(o)),C=xi(o);if(N(xi(F))!==N(C))throw new Error("Replay scorecard mismatch.");return s||lf(o),{revision:o.revision,eventsSha256:N(o.events),scorecardSha256:N(C),eventCount:o.events.length,replay:!0,resimulation:!0,humanRequests:A.filter($=>$.origin==="HUMAN").length,systemAutopilotRequests:A.filter($=>$.origin==="AI").length}}function en(F){if(!o)throw new Error("Start a match first.");const C=F.command;if(C.kind==="CONFIRM_TEAMS")throw new Error("Team confirmation is only available through match setup.");if(C.commandId!==F.requestId||C.expectedRevision!==F.expectedRevision)throw new Error("Command envelope mismatch.");const $=o.core.innings[o.core.activeInningsIndex],q="teamId"in C.payload?C.payload.teamId:C.kind==="SET_BATTING_PLAN"?$?.innings.battingTeamId:$?.innings.bowlingTeamId,G=C.kind==="ADVANCE"?"SYSTEM":`USER:${q}`;if(C.actorId!==(F.origin==="AI"?C.kind==="ADVANCE"?"SYSTEM":`AI:${q}`:G))throw new Error("Only human-owned or explicitly delegated AI-owned commands may change the team decision.");o=s?Wi(o,C).session:vt(o,C).session,A.push({requestId:F.requestId,origin:F.origin,commandKind:C.kind,engineActorId:C.actorId})}function P(F,C=null){s=C,o=s?rl(F,s):df(F,n,e),h(null),f.clear(),A.splice(0,A.length,...o.commands.map($=>({requestId:$.commandId,origin:$.actorId.startsWith("AI:")?"AI":"HUMAN",commandKind:$.kind,engineActorId:$.actorId})))}function x(){return o?structuredClone(o):null}function K(F,C=null){return{version:Ot,requestId:F,revision:o?.revision??0,pins:Un,catalog:o?null:structuredClone(r),view:V(),error:C,verification:null,careerResult:U(),...d?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"&&o?.core.phase==="COMPLETE"?{rosterCareerSession:structuredClone(o)}:{}}}return{restore:P,setWorldCopy:E,snapshot:x,boundFixture:()=>d,currentResponse:K,handle(F){let C="invalid",$=null,q=null,G;try{G=pl.parse(F),C=G.requestId;const pn=f.get(C);if(pn){if(pn.request!==JSON.stringify(G))throw new Error("Request ID already used with different content.");return structuredClone(pn.response)}if(G.type==="BOOT"&&G.careerFixture){if(o&&(o.setup.gameId!==G.careerFixture.matchGameId||o.setup.matchId!==G.careerFixture.matchId))throw new Error("Recovered match does not match the scheduled career fixture.");h(G.careerFixture)}if(G.type!=="BOOT"&&G.expectedRevision!==(o?.revision??0))throw new Error("Stale revision. Review the current decision and try again.");if(G.type==="START"){if(G.format!=="T20")throw new Error("T20 controller received a non-T20 start.");if(o)throw new Error("A match is already in progress.");if(G.careerFixture&&G.worldCopy)throw new Error("A career match cannot replace its world copy.");const gn=G.careerFixture&&(G.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"||G.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE")?G.careerFixture:null;if(G.rosterPack&&(G.worldCopy||G.careerFixture&&!gn))throw new Error("An imported roster cannot replace a career or edited world.");if(gn&&JSON.stringify(G.rosterPack)!==JSON.stringify(gn.rosterPack))throw new Error("Career roster binding mismatch.");if(s=G.rosterPack??null,h(G.careerFixture??null),G.careerFixture||E(G.worldCopy??null),d){if(d.matchId!==G.careerFixture?.matchId||d.groundId!==G.groundId)throw new Error("Career fixture binding mismatch.");if(d.homeTeamId!==G.selections[0].teamId||d.awayTeamId!==G.selections[1].teamId)throw new Error("Career fixture team order mismatch.");if(JSON.stringify(d.selections)!==JSON.stringify(G.selections))throw new Error("Career fixture XI snapshot mismatch.")}const Gn=d?{gameId:d.matchGameId,matchId:d.matchId}:i();if(s){const fe=Vi(s,{...Gn,seed:d?d.matchSeed:t(),format:"T20",selection:{groundId:G.groundId,teams:G.selections}});o=Wi(fe,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:C,expectedRevision:0}).session,h(G.careerFixture??null),G.careerFixture||(g=s.world),A.push({requestId:C,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}else{const fe=Hc({setupVersion:"LC_T20_SETUP_V1",setup:{schemaVersion:"1.0.0",...Gn,format:"T20",worldPackId:Mn.worldPackId,rulesId:"LC_T20_01",modelId:"synthetic-alpha-01",randomId:"SHA256_COUNTER_V1",seed:d?d.matchSeed:t(),teamIds:G.selections.map(Tn=>Tn.teamId),groundId:G.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:Mn.worldFileSha256,worldCanonicalSha256:Un.worldHash,rulesHash:Un.rulesHash,modelHash:Bn,stagePackHash:jn,selectedTeams:G.selections},n,e),Ee=Pi(fe);for(const[Tn,nn]of Object.entries(Un))if(Ee.executionManifest[Tn]!==nn)throw new Error("Worker build identity mismatch.");o=vt(Ee,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:C,expectedRevision:0}).session,A.push({requestId:C,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}}else G.type==="COMMAND"?en(G):G.type==="VERIFY"&&(q=H())}catch(pn){$=pn instanceof Error&&pn.name!=="ZodError"?pn.message:"Invalid request. Check selections, required fields and supported settings."}const Z={version:Ot,requestId:C,revision:o?.revision??0,pins:Un,catalog:o?null:structuredClone(r),view:V(),error:$,verification:q,careerResult:U(),...d?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"&&o?.core.phase==="COMPLETE"?{rosterCareerSession:structuredClone(o)}:{}};return G&&!$&&f.set(C,{request:JSON.stringify(G),response:structuredClone(Z)}),Z}}}function n3(n,e,t){const i=n.filter(g=>g.actorId===`AI:${e}`),a=i.filter(g=>g.kind==="SET_BOWLING_PLAN").slice(-5),r=a.filter(g=>g.payload.length==="YORKER").length;if(r>=2)return`Called for yorkers in ${r} of the last ${a.length} bowling plan changes.`;const o=i.filter(g=>g.kind==="SET_BOWLER").slice(-6),s=o.at(-1)?.payload.bowlerId,d=o.filter(g=>g.payload.bowlerId===s).length;return s&&d>=2?`Picked ${t[s]} for ${d} of the last ${o.length} overs assigned.`:""}function e3(n,e,t,i=()=>({gameId:"human-exhibition",matchId:"human-odi"})){const{world:a}=Ci(n,e),r={teams:a.teams.map(P=>{const x=P.squadIds.map($=>a.players.find(q=>q.playerId===$)),K=x.find($=>$.role==="KEEPER"),F=x.filter($=>$.playerId!==K.playerId&&Le($)).slice(0,6),C=[K,...F,...x.filter($=>$!==K&&!F.includes($))].slice(0,11);return{id:P.teamId,name:P.name,players:x.map($=>({id:$.playerId,name:$.name,role:$.role,style:$.bowlingStyle,canBowl:Le($),batHand:$.batHand})),suggested:{teamId:P.teamId,playerIds:C.map($=>$.playerId),captainId:C[0].playerId,keeperId:K.playerId}}}),grounds:a.grounds.map(P=>({id:P.groundId,name:P.name,seamBp:P.pitchPrior.seamBp,turnBp:P.pitchPrior.turnBp}))};let o=null,s=null,d=a;function g(P){d=s?.world??(P?_o(P,a).world:a)}const E=new Map,h=[],f=P=>Kn(Qn(P)),A=qs(2);let N=null,b=-1,w=null,D=null,p=null,I=null,v=[],y=[];function S(){if(!o)return null;const P=o,x=P.core,K=x.innings[x.activeInningsIndex],F=K?.innings;A.update(P.events);const C=x.phase==="COMPLETE"?lo(P):null,$=Object.fromEntries(P.setup.teams.flatMap(nn=>nn.xi.map(cn=>[cn.playerId,d.players.find(rn=>rn.playerId===cn.playerId)?.name??cn.name]))),q=nn=>d.teams.find(cn=>cn.teamId===nn)?.name??"",G=x.phase==="TOSS"?P.setup.teams[0].teamId:x.phase==="AWAITING_INNINGS"?x.tossWinnerId:x.phase==="AWAITING_BATTER"?F.battingTeamId:x.phase==="AWAITING_BOWLER"?F.bowlingTeamId:null,Z={TOSS:`${q(G)}: call the toss`,AWAITING_INNINGS:`${q(x.tossWinnerId)} won the toss: choose bat or bowl`,AWAITING_BATTER:`${q(G)}: select ${F?.northBatterId===null&&F.southBatterId===null?"the opening batter":"the next batter"}`,AWAITING_BOWLER:`${q(G)}: select a bowler`,READY:"Ready: set tactics or advance play",COMPLETE:"Match complete: review the scorecard"},pn=(P.setup.teams.find(nn=>nn.teamId===G)?.xi??[]).map(nn=>{let cn="";x.phase==="AWAITING_BATTER"&&(cn=K.batting[nn.playerId].dismissed?"Already dismissed":[F.northBatterId,F.southBatterId].includes(nn.playerId)?"Already batting":""),x.phase==="AWAITING_BOWLER"&&(cn=nn.playerId===K.keeperId?"Designated keeper":nn.bowlingStyle===null?"Not a bowler":F.previousOverBowlerId===nn.playerId?"Bowled the previous over":K.bowling[nn.playerId].legalBalls>=60?"Ten-over limit reached":"");const{power:rn,rotation:Q,defence:En}=nn.skills.ODI;return{id:nn.playerId,name:$[nn.playerId]??nn.name,reason:cn,...x.phase==="AWAITING_BATTER"?{batting:{power:rn,rotation:Q,defence:En}}:{}}});if(x.phase==="AWAITING_BOWLER"&&K&&F){const nn=P.setup.teams.find(rn=>rn.teamId===G)?.xi??[],cn=ml(nn.map(rn=>({id:rn.playerId,eligible:rn.playerId!==K.keeperId&&rn.bowlingStyle!==null,legalBalls:K.bowling[rn.playerId]?.legalBalls??0})),Math.ceil((300-F.legalBalls)/6),60);for(const rn of pn)!rn.reason&&cn.has(rn.id)&&(rn.reason=cn.get(rn.id))}let gn=x.phase==="COMPLETE"?"Match complete":x.phase!=="READY"?"Complete the next decision first":"";if(x.phase==="READY"&&K)try{const nn=F.strikerEnd==="NORTH"?F.northBatterId:F.southBatterId,cn=P.setup.teams.flatMap(rn=>rn.xi).find(rn=>rn.playerId===nn);Rt(x.fieldSlots,K.outfieldIds,cn.batHand,F.legalBalls)}catch{gn="Field is invalid for this striker. Apply a legal named field before advancing."}const Gn=x.result,fe=Object.fromEntries(P.setup.teams.flatMap(nn=>nn.xi.map(cn=>[cn.playerId,cn.batHand]))),Ee=d.grounds.find(nn=>nn.groundId===P.setup.ground.groundId)?.name??P.setup.ground.name;if(N!==P||b!==P.revision||w!==d){const nn=Object.fromEntries(P.setup.teams.map(cn=>[cn.teamId,q(cn.teamId)]));v=cc({format:"ODI",events:P.events,playerNames:$,teamNames:nn,teamIds:[P.setup.teams[0].teamId,P.setup.teams[1].teamId],groundName:Ee,presentationKey:`lcxxvi-commentary:ODI:${P.setup.matchId}`}).entries,y=lc({format:"ODI",matchId:P.setup.matchId,commentaryEntries:v}).cues,D=Js({format:"ODI",phase:x.phase,innings:x.innings,activeIndex:x.activeInningsIndex,events:P.events,names:$,pitch:x.pitch,fatigueBpByPlayerId:x.fatigueBp,activeBattingPlans:x.battingPlans,activeBowlingPlan:x.bowlingPlan,activeFieldSlots:x.fieldSlots,outfieldIds:K?.outfieldIds??[],bowlerVariationsByPlayerId:Object.fromEntries(P.setup.teams.flatMap(cn=>cn.xi.map(rn=>[rn.playerId,rn.variations])))}),p=rc({format:"ODI",phase:x.phase,innings:x.innings,activeIndex:x.activeInningsIndex,fieldSlots:x.fieldSlots,events:P.events,names:$,hands:fe}),N=P,b=P.revision,w=d}const be=v,Tn=x.phase==="COMPLETE"&&Gn?Gn.kind==="TIE"?"Match tied":`${q(Gn.winnerTeamId)} won by ${Gn.marginRuns??Gn.marginWickets} ${Gn.marginType?.toLowerCase()}`:null;return{format:"ODI",revision:P.revision,phase:x.phase,nextDecision:Z[x.phase]??x.phase,decisionTeamId:G,teams:P.setup.teams.map(nn=>({id:nn.teamId,name:q(nn.teamId),captainId:nn.captainId,keeperId:nn.keeperId,playerIds:[...nn.playerIds],...d.packId!==a.packId?{colours:[...d.teams.find(cn=>cn.teamId===nn.teamId).colours]}:{}})),names:$,hands:fe,ground:d.grounds.find(nn=>nn.groundId===P.setup.ground.groundId)?.name??P.setup.ground.name,innings:structuredClone(x.innings),activeIndex:x.activeInningsIndex,candidates:pn,bowlingPlan:structuredClone(x.bowlingPlan),battingPlans:structuredClone(x.battingPlans),fieldSlots:structuredClone(x.fieldSlots),positions:Tc.positions.map(nn=>nn.slotId),matchId:P.setup.matchId,advanceReason:gn,commentary:be,audioCues:y,scorecard:C,analytics:C?A.snapshot(C):null,tacticalAssistant:D,fieldPresentation:p,matchAward:x.phase==="COMPLETE"&&C?I??=mc({format:"ODI",scorecard:C,events:P.events,playerNames:$,teamNames:Object.fromEntries(d.teams.map(nn=>[nn.teamId,nn.name]))}):null,resultText:Tn,eventCount:P.events.length,lastEventHash:P.lastEventHash}}function R(){if(!o||o.core.phase!=="COMPLETE")throw new Error("Complete the match before verifying its final scorecard.");const P=s?Pf(o,s):bf(o.setup,o.events,Zc(o)),x=lo(o);if(f(lo(P))!==f(x))throw new Error("Replay scorecard mismatch.");return s||vf(o),{revision:o.revision,eventsSha256:f(o.events),scorecardSha256:f(x),eventCount:o.events.length,replay:!0,resimulation:!0,humanRequests:h.filter(K=>K.origin==="HUMAN").length,systemAutopilotRequests:h.filter(K=>K.origin==="AI").length}}function V(P){if(!o)throw new Error("Start a match first.");const x=P.command;if(x.kind==="CONFIRM_TEAMS")throw new Error("Team confirmation is only available through match setup.");if(x.commandId!==P.requestId||x.expectedRevision!==P.expectedRevision)throw new Error("Command envelope mismatch.");const K=o.core.innings[o.core.activeInningsIndex],F="teamId"in x.payload?x.payload.teamId:x.kind==="SET_BATTING_PLAN"?K?.innings.battingTeamId:K?.innings.bowlingTeamId,C=P.origin==="AI"?x.kind==="ADVANCE"?"SYSTEM":`AI:${F}`:x.kind==="ADVANCE"?"SYSTEM":`USER:${F}`;if(x.actorId!==C)throw new Error("Only valid human or tactical-captain commands are accepted by this match interface.");o=s?Ui(o,x).session:At(o,x).session,h.push({requestId:P.requestId,origin:P.origin,commandKind:x.kind,engineActorId:x.actorId})}function U(P,x=null){s=x,o=s?sl(P,s):Rf(P,n,e),g(null),E.clear(),h.splice(0,h.length,...o.commands.map(K=>({requestId:K.commandId,origin:K.actorId.startsWith("AI:")?"AI":"HUMAN",commandKind:K.kind,engineActorId:K.actorId})))}function H(){return o?structuredClone(o):null}function en(P,x=null){return{version:Ot,requestId:P,revision:o?.revision??0,pins:Un,catalog:o?null:structuredClone(r),view:S(),error:x,verification:null}}return{restore:U,setWorldCopy:g,snapshot:H,currentResponse:en,handle(P){let x="invalid",K=null,F=null,C;try{C=pl.parse(P),x=C.requestId;const q=E.get(x);if(q){if(q.request!==JSON.stringify(C))throw new Error("Request ID already used with different content.");return structuredClone(q.response)}if(C.type!=="BOOT"&&C.expectedRevision!==(o?.revision??0))throw new Error("Stale revision. Review the current decision and try again.");if(C.type==="START"){if(C.format!=="ODI")throw new Error("ODI controller received a non-ODI start.");if(o)throw new Error("A match is already in progress.");if(C.careerFixture)throw new Error("Career fixtures require T20.");if(C.rosterPack&&C.worldCopy)throw new Error("Choose either a roster or an edited world.");if(s=C.rosterPack??null,g(C.worldCopy??null),s){const G=$i(s,{...i(),seed:t(),format:"ODI",selection:{groundId:C.groundId,teams:C.selections}});o=Ui(G,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:x,expectedRevision:0}).session,d=s.world,h.push({requestId:x,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}else{const G=Mc({setupVersion:"LC_ODI_SETUP_V1",setup:{schemaVersion:"1.0.0",...i(),format:"ODI",worldPackId:Mn.worldPackId,rulesId:"LC_ODI_01",modelId:"synthetic-alpha-01",randomId:"SHA256_COUNTER_V1",seed:t(),teamIds:C.selections.map(gn=>gn.teamId),groundId:C.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:Mn.worldFileSha256,worldCanonicalSha256:Xe.worldHash,rulesHash:Xe.rulesHash,modelHash:Bn,stagePackHash:jn,selectedTeams:C.selections},n,e),Z=Mi(G);for(const[gn,Gn]of Object.entries(Xe))if(Z.executionManifest[gn]!==Gn)throw new Error("Worker build identity mismatch.");o=At(Z,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:x,expectedRevision:0}).session,h.push({requestId:x,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}}else C.type==="COMMAND"?V(C):C.type==="VERIFY"&&(F=R())}catch(q){K=q instanceof Error&&q.name!=="ZodError"?q.message:"Invalid request. Check selections, required fields and supported settings."}const $={version:Ot,requestId:x,revision:o?.revision??0,pins:Un,catalog:o?null:structuredClone(r),view:S(),error:K,verification:F};return C&&!K&&E.set(x,{request:JSON.stringify(C),response:structuredClone($)}),$}}}function To(n,e){return`${n}:${e}`}function t3(n){return`${Math.floor(n/6)}.${n%6}`}function bo(n,e){return{gameId:`tour-${n}-m${e}`.slice(0,128),matchId:`tour-m${e}`}}function Il(n){return n==="SEMI_FINAL"||n==="FINAL"}function hl(n){const{fixture:e,session:t}=n,i=bo(n.runId,e.matchNumber),a=t.setup.teams.map(A=>A.teamId);if(t.setup.format!==n.competition.format||t.setup.seed!==To(n.runSeed,e.fixtureId)||t.setup.matchId!==i.matchId||t.setup.gameId!==i.gameId||a[0]!==e.homeTeamId||a[1]!==e.awayTeamId||t.setup.ground.groundId!==e.groundId)throw new Error("TOURNAMENT_MATCH_MISMATCH");if(t.core.phase!=="COMPLETE"||!t.core.result)throw new Error("TOURNAMENT_MATCH_NOT_COMPLETE");const r=t.core.result;if(r.kind!=="WIN"&&r.kind!=="TIE")throw new Error("TOURNAMENT_RESULT_UNSUPPORTED");const o=A=>t.core.innings.find(N=>N.innings.battingTeamId===A).innings,s=o(e.homeTeamId),d=o(e.awayTeamId),g=r.kind==="TIE"&&Il(e.stage)?n.superOverWinnerTeamId:null,E=(A,N)=>`${n.teamName(A)} ${N.runs}/${N.wickets} (${t3(N.legalBalls)})`,h=r.kind==="WIN"?r.marginType==="WICKETS"?`by ${r.marginWickets} wicket${r.marginWickets===1?"":"s"}`:`by ${r.marginRuns} run${r.marginRuns===1?"":"s"}`:"",f=r.kind==="WIN"?`${n.teamName(r.winnerTeamId)} won ${h}`:g?`Tied; ${n.teamName(g)} won the super over`:"Tied";return{fixtureId:e.fixtureId,homeTeamId:e.homeTeamId,awayTeamId:e.awayTeamId,resultKind:r.kind,winnerTeamId:r.kind==="WIN"?r.winnerTeamId:null,superOverWinnerTeamId:g,homeRuns:s.runs,homeWickets:s.wickets,homeLegalBalls:s.legalBalls,awayRuns:d.runs,awayWickets:d.wickets,awayLegalBalls:d.legalBalls,resultText:`${f}. ${E(e.homeTeamId,s)}; ${E(e.awayTeamId,d)}.`.slice(0,160),lastEventHash:t.lastEventHash}}function i3(n){const{competition:e,fixture:t}=n,i=To(n.runSeed,t.fixtureId),a=()=>bo(n.runId,t.matchNumber),r=e.format==="T20"?Qf(n.worldBytes,n.worldManifest,()=>i,a):e3(n.worldBytes,n.worldManifest,()=>i,a),o=r.currentResponse("ui-0").catalog;if(!o)throw new Error("TOURNAMENT_CATALOGUE_UNAVAILABLE");const s=h=>{const f=o.teams.find(A=>A.id===h);if(!f)throw new Error("TOURNAMENT_TEAM_UNKNOWN");return f.suggested},d=r.handle({version:Ot,requestId:"ui-1",expectedRevision:0,type:"START",format:e.format,selections:[s(t.homeTeamId),s(t.awayTeamId)],groundId:t.groundId});if(d.error)throw new Error(d.error);let g=r.snapshot();for(;g.core.phase!=="COMPLETE";)g=g.setup.format==="T20"?vt(g,zc(g)).session:At(g,Xc(g)).session;let E=null;if(g.core.result?.kind==="TIE"&&Il(t.stage)){let h=Uf(g);for(;h.phase!=="COMPLETE";)h=jf(g,h,qf(g,h));E=h.winnerTeamId}return hl({...n,session:g,superOverWinnerTeamId:E})}const a3=["#1F2937","#E5E7EB"];function fl(n){return`xi-${n.tourId.slice(10)}`}const vo=n=>(e,t)=>n(t)-n(e)||(e.playerId<t.playerId?-1:1);function o3(n,e,t){const i=n.teams.find(f=>f.teamId===e);if(!i)throw new Error("Unknown host team.");const a=new Set(i.squadIds),r=n.players.filter(f=>!a.has(f.playerId)),o=f=>f.skills[t],s=f=>o(f).timing+o(f).power+o(f).defence+o(f).rotation,d=r.filter(f=>f.role==="KEEPER").sort(vo(f=>o(f).keeping+o(f).timing+o(f).defence))[0];if(!d)throw new Error("No keeper is available for the touring side.");const g=r.filter(f=>Le(f)&&f.playerId!==d.playerId).sort(vo(f=>o(f).control+o(f).movement)).slice(0,6),E=new Set([d.playerId,...g.map(f=>f.playerId)]),h=r.filter(f=>!E.has(f.playerId)&&f.role!=="KEEPER").sort(vo(s)).slice(0,4);if(g.length<6||h.length<4)throw new Error("Not enough players for a touring side.");return{squadIds:[...h,d,...g].map(f=>f.playerId),captainId:h[0].playerId,keeperId:d.playerId}}function r3(n,e,t){const i=e.map(d=>n.players.find(g=>g.playerId===d)),a=i.find(d=>d.role==="KEEPER");if(!a)throw new Error("A squad needs a keeper.");const r=i.filter(d=>d.playerId!==a.playerId&&Le(d)).slice(0,6),s=[a,...r,...i.filter(d=>d!==a&&!r.includes(d))].slice(0,11).map(d=>d.playerId);return{playerIds:s,captainId:t&&s.includes(t)?t:s[0],keeperId:a.playerId}}function El(n,e,t){const i=new Set(t.flatMap(o=>o.squadIds)),a=n.players.filter(o=>i.has(o.playerId)).map(o=>{const s={...o};return delete s.provenance,s}),r={version:"LC_ROSTER_IMPORT_V1",sourceId:e,world:{packId:n.packId,schemaVersion:n.schemaVersion,provenance:n.provenance,rulesIds:n.rulesIds,grounds:n.grounds,teams:t.map(o=>({teamId:o.teamId,name:o.name,squadIds:o.squadIds,colours:o.colours})),players:a}};return Nf(JSON.stringify(r),ke.map(o=>o.rulesId),ne.manifest.variationIds)}function s3(n,e){const t=n.teams.find(a=>a.teamId===e.hostTeamId);if(!t)throw new Error("Unknown host team.");const i=o3(n,e.hostTeamId,e.format);return[{teamId:t.teamId,name:t.name,colours:[t.colours[0],t.colours[1]],squadIds:[...t.squadIds]},{teamId:fl(e),name:e.touringName,colours:a3,squadIds:i.squadIds}]}function c3(n){return{competitionId:n.tourId,title:n.title,format:n.format,sourceType:"USER_AUTHORED",worldPackId:"fictional-eight-01",teamIds:[n.hostTeamId,fl(n)],groundIds:[...n.groundIds],structure:{kind:"SERIES",matches:n.matches},points:{win:2,tie:1,loss:0},summary:`${n.touringName}, picked from the other seven clubs, tour for a ${n.matches}-match ${n.format==="T20"?"T20":"one-day"} series.`}}function l3(n,e,t){const i=a=>{const r=e.find(o=>o.teamId===a);if(!r)throw new Error("TOURNAMENT_TEAM_UNKNOWN");return{teamId:a,...r3(n,r.squadIds)}};return[i(t.homeTeamId),i(t.awayTeamId)]}function Sl(n,e){if("tour"in e){const i=s3(n,e.tour);return{squads:i,pack:El(n,e.tour.tourId,i)}}const t=e.squads.map(i=>({...i,colours:[i.colours[0],i.colours[1]],squadIds:[...i.squadIds]}));return{squads:t,pack:El(n,`auction-${e.runId}`,t)}}function _l(n){const{fixture:e,competition:t}=n,i=bo(n.runId,e.matchNumber),a={gameId:i.gameId,matchId:i.matchId,seed:To(n.runSeed,e.fixtureId),format:t.format,selection:{groundId:e.groundId,teams:l3(n.world,n.squads,e)}};let r;if(t.format==="T20"){let o=Vi(n.pack,a);for(;o.core.phase!=="COMPLETE";)o=Wi(o,zc(o)).session;r=o}else{let o=$i(n.pack,a);for(;o.core.phase!=="COMPLETE";)o=Ui(o,Xc(o)).session;r=o}return hl({competition:t,fixture:e,runId:n.runId,runSeed:n.runSeed,session:r,superOverWinnerTeamId:null,teamName:n.teamName})}const d3=new TextEncoder().encode(Lo),Jt=JSON.parse(Lo),Ro=Object.fromEntries(Jt.teams.map(n=>[n.teamId,n.name]));let Je=null;self.onmessage=n=>{const e=n.data;let t;try{const i=e.results.map(d=>Us.parse(d));if(e.tour!==void 0){const d=Gs.parse(e.tour),g=c3(d),E=hc(g,i).next;if(!E)throw new Error("The tour is already finished.");const h=JSON.stringify(d);Je?.key!==h&&(Je={key:h,...Sl(Jt,{tour:d})});const f=Je.squads,A=_l({world:Jt,pack:Je.pack,squads:f,competition:g,fixture:E,runId:e.runId,runSeed:e.runSeed,teamName:N=>f.find(b=>b.teamId===N)?.name??Ro[N]??N});self.postMessage({id:e.id,result:A,error:null});return}const a=m2.safeParse(e.competition);if(!a.success)throw new Error("Unknown tournament.");const r=a.data,o=hc(r,i).next;if(!o)throw new Error("The tournament is already finished.");if(e.squads!==void 0){const d=JSON.stringify(["auction",e.runId,e.squads]);Je?.key!==d&&(Je={key:d,...Sl(Jt,{runId:e.runId,squads:e.squads})});const g=_l({world:Jt,pack:Je.pack,squads:Je.squads,competition:r,fixture:o,runId:e.runId,runSeed:e.runSeed,teamName:E=>Ro[E]??E});self.postMessage({id:e.id,result:g,error:null});return}const s=i3({competition:r,fixture:o,runId:e.runId,runSeed:e.runSeed,worldBytes:d3,worldManifest:bl,teamName:d=>Ro[d]??d});t={id:e.id,result:s,error:null}}catch(i){t={id:e.id,result:null,error:i instanceof Error?i.message:"The match could not be played."}}self.postMessage(t)}})();
