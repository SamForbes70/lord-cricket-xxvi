(function(){"use strict";var $m=`{
  "packId": "fictional-eight-01",
  "schemaVersion": "1.0.0",
  "players": [
    {
      "playerId": "p001",
      "name": "Ulen Elmcroft",
      "birthDate": "2006-01-24",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 55,
          "timing": 53,
          "power": 49,
          "rotation": 35,
          "vsPace": 58,
          "vsSpin": 47,
          "control": 23,
          "movement": 20,
          "variation": 40,
          "stamina": 35,
          "catching": 63,
          "groundFielding": 48,
          "throwing": 50,
          "keeping": 78
        },
        "ODI": {
          "defence": 42,
          "timing": 39,
          "power": 53,
          "rotation": 55,
          "vsPace": 46,
          "vsSpin": 54,
          "control": 16,
          "movement": 42,
          "variation": 23,
          "stamina": 37,
          "catching": 57,
          "groundFielding": 64,
          "throwing": 71,
          "keeping": 82
        },
        "RED_BALL": {
          "defence": 68,
          "timing": 59,
          "power": 41,
          "rotation": 57,
          "vsPace": 57,
          "vsSpin": 43,
          "control": 33,
          "movement": 20,
          "variation": 37,
          "stamina": 23,
          "catching": 41,
          "groundFielding": 54,
          "throwing": 52,
          "keeping": 78
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        769,
        543,
        812,
        249,
        256,
        943,
        996,
        930
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p002",
      "name": "Caro Harden",
      "birthDate": "1999-12-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 47,
          "power": 39,
          "rotation": 45,
          "vsPace": 40,
          "vsSpin": 40,
          "control": 15,
          "movement": 24,
          "variation": 38,
          "stamina": 36,
          "catching": 70,
          "groundFielding": 47,
          "throwing": 67,
          "keeping": 70
        },
        "ODI": {
          "defence": 56,
          "timing": 54,
          "power": 61,
          "rotation": 45,
          "vsPace": 35,
          "vsSpin": 36,
          "control": 26,
          "movement": 23,
          "variation": 32,
          "stamina": 22,
          "catching": 46,
          "groundFielding": 48,
          "throwing": 69,
          "keeping": 70
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 54,
          "power": 52,
          "rotation": 34,
          "vsPace": 50,
          "vsSpin": 37,
          "control": 19,
          "movement": 24,
          "variation": 13,
          "stamina": 31,
          "catching": 55,
          "groundFielding": 50,
          "throwing": 71,
          "keeping": 80
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        626,
        792,
        596,
        535,
        453,
        701,
        994,
        207
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p003",
      "name": "Talor Elmholt",
      "birthDate": "1988-07-28",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 49,
          "timing": 31,
          "power": 34,
          "rotation": 36,
          "vsPace": 30,
          "vsSpin": 34,
          "control": 64,
          "movement": 73,
          "variation": 62,
          "stamina": 56,
          "catching": 49,
          "groundFielding": 45,
          "throwing": 62,
          "keeping": 27
        },
        "ODI": {
          "defence": 30,
          "timing": 25,
          "power": 27,
          "rotation": 46,
          "vsPace": 36,
          "vsSpin": 40,
          "control": 64,
          "movement": 64,
          "variation": 69,
          "stamina": 78,
          "catching": 63,
          "groundFielding": 64,
          "throwing": 67,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 36,
          "timing": 43,
          "power": 26,
          "rotation": 41,
          "vsPace": 20,
          "vsSpin": 22,
          "control": 55,
          "movement": 58,
          "variation": 77,
          "stamina": 68,
          "catching": 68,
          "groundFielding": 42,
          "throwing": 56,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        650,
        907,
        747,
        833,
        478,
        405,
        619,
        846
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p004",
      "name": "Fenn Glenthorne",
      "birthDate": "1999-08-07",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 32,
          "timing": 40,
          "power": 29,
          "rotation": 19,
          "vsPace": 29,
          "vsSpin": 33,
          "control": 62,
          "movement": 79,
          "variation": 51,
          "stamina": 71,
          "catching": 58,
          "groundFielding": 62,
          "throwing": 69,
          "keeping": 34
        },
        "ODI": {
          "defence": 22,
          "timing": 46,
          "power": 34,
          "rotation": 19,
          "vsPace": 30,
          "vsSpin": 34,
          "control": 73,
          "movement": 56,
          "variation": 50,
          "stamina": 61,
          "catching": 49,
          "groundFielding": 54,
          "throwing": 60,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 50,
          "timing": 35,
          "power": 18,
          "rotation": 25,
          "vsPace": 39,
          "vsSpin": 37,
          "control": 63,
          "movement": 61,
          "variation": 74,
          "stamina": 60,
          "catching": 47,
          "groundFielding": 43,
          "throwing": 64,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        757,
        461,
        833,
        706,
        622,
        326,
        818,
        927
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p005",
      "name": "Arven Valebridge",
      "birthDate": "2007-07-01",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 28,
          "timing": 21,
          "power": 53,
          "rotation": 45,
          "vsPace": 45,
          "vsSpin": 37,
          "control": 80,
          "movement": 74,
          "variation": 69,
          "stamina": 50,
          "catching": 40,
          "groundFielding": 58,
          "throwing": 55,
          "keeping": 11
        },
        "ODI": {
          "defence": 35,
          "timing": 45,
          "power": 39,
          "rotation": 38,
          "vsPace": 24,
          "vsSpin": 47,
          "control": 76,
          "movement": 79,
          "variation": 54,
          "stamina": 61,
          "catching": 47,
          "groundFielding": 40,
          "throwing": 47,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 28,
          "timing": 45,
          "power": 20,
          "rotation": 37,
          "vsPace": 49,
          "vsSpin": 26,
          "control": 73,
          "movement": 77,
          "variation": 61,
          "stamina": 77,
          "catching": 66,
          "groundFielding": 62,
          "throwing": 62,
          "keeping": 12
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        307,
        372,
        469,
        256,
        638,
        703,
        520,
        273
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p006",
      "name": "Halen Normere",
      "birthDate": "1995-05-07",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 22,
          "timing": 46,
          "power": 42,
          "rotation": 49,
          "vsPace": 39,
          "vsSpin": 35,
          "control": 62,
          "movement": 69,
          "variation": 62,
          "stamina": 69,
          "catching": 41,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 29
        },
        "ODI": {
          "defence": 38,
          "timing": 23,
          "power": 49,
          "rotation": 26,
          "vsPace": 30,
          "vsSpin": 31,
          "control": 54,
          "movement": 66,
          "variation": 60,
          "stamina": 69,
          "catching": 61,
          "groundFielding": 41,
          "throwing": 53,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 41,
          "timing": 28,
          "power": 20,
          "rotation": 28,
          "vsPace": 45,
          "vsSpin": 33,
          "control": 60,
          "movement": 66,
          "variation": 60,
          "stamina": 65,
          "catching": 51,
          "groundFielding": 65,
          "throwing": 69,
          "keeping": 30
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        906,
        645,
        484,
        377,
        657,
        740,
        737,
        339
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p007",
      "name": "Sela Sablestone",
      "birthDate": "2002-06-18",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 46,
          "timing": 38,
          "power": 46,
          "rotation": 34,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 75,
          "movement": 71,
          "variation": 64,
          "stamina": 73,
          "catching": 59,
          "groundFielding": 39,
          "throwing": 61,
          "keeping": 12
        },
        "ODI": {
          "defence": 29,
          "timing": 32,
          "power": 40,
          "rotation": 27,
          "vsPace": 24,
          "vsSpin": 26,
          "control": 78,
          "movement": 54,
          "variation": 56,
          "stamina": 70,
          "catching": 56,
          "groundFielding": 48,
          "throwing": 48,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 46,
          "timing": 48,
          "power": 35,
          "rotation": 35,
          "vsPace": 43,
          "vsSpin": 42,
          "control": 60,
          "movement": 60,
          "variation": 51,
          "stamina": 63,
          "catching": 52,
          "groundFielding": 42,
          "throwing": 49,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        435,
        439,
        593,
        453,
        422,
        720,
        912,
        250
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p008",
      "name": "Isen Kelholt",
      "birthDate": "1996-07-10",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 29,
          "timing": 33,
          "power": 35,
          "rotation": 23,
          "vsPace": 31,
          "vsSpin": 23,
          "control": 74,
          "movement": 75,
          "variation": 80,
          "stamina": 76,
          "catching": 42,
          "groundFielding": 40,
          "throwing": 55,
          "keeping": 25
        },
        "ODI": {
          "defence": 34,
          "timing": 22,
          "power": 20,
          "rotation": 40,
          "vsPace": 36,
          "vsSpin": 30,
          "control": 62,
          "movement": 77,
          "variation": 61,
          "stamina": 50,
          "catching": 58,
          "groundFielding": 63,
          "throwing": 64,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 22,
          "power": 24,
          "rotation": 36,
          "vsPace": 24,
          "vsSpin": 41,
          "control": 79,
          "movement": 52,
          "variation": 57,
          "stamina": 53,
          "catching": 54,
          "groundFielding": 39,
          "throwing": 62,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        301,
        977,
        683,
        544,
        561,
        755,
        997,
        769
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p009",
      "name": "Nerin Orinbridge",
      "birthDate": "1988-03-08",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 38,
          "timing": 46,
          "power": 64,
          "rotation": 48,
          "vsPace": 56,
          "vsSpin": 52,
          "control": 55,
          "movement": 58,
          "variation": 53,
          "stamina": 43,
          "catching": 52,
          "groundFielding": 44,
          "throwing": 70,
          "keeping": 40
        },
        "ODI": {
          "defence": 39,
          "timing": 53,
          "power": 59,
          "rotation": 43,
          "vsPace": 48,
          "vsSpin": 52,
          "control": 61,
          "movement": 67,
          "variation": 43,
          "stamina": 47,
          "catching": 45,
          "groundFielding": 72,
          "throwing": 63,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 51,
          "power": 46,
          "rotation": 47,
          "vsPace": 41,
          "vsSpin": 43,
          "control": 63,
          "movement": 51,
          "variation": 51,
          "stamina": 62,
          "catching": 52,
          "groundFielding": 56,
          "throwing": 56,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        760,
        392,
        574,
        472,
        422,
        243,
        293,
        872
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p010",
      "name": "Zerin Sablebrook",
      "birthDate": "2003-05-22",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 38,
          "timing": 38,
          "power": 68,
          "rotation": 42,
          "vsPace": 48,
          "vsSpin": 53,
          "control": 55,
          "movement": 60,
          "variation": 52,
          "stamina": 56,
          "catching": 71,
          "groundFielding": 54,
          "throwing": 43,
          "keeping": 40
        },
        "ODI": {
          "defence": 68,
          "timing": 49,
          "power": 51,
          "rotation": 40,
          "vsPace": 54,
          "vsSpin": 48,
          "control": 62,
          "movement": 37,
          "variation": 38,
          "stamina": 48,
          "catching": 65,
          "groundFielding": 72,
          "throwing": 42,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 54,
          "timing": 51,
          "power": 39,
          "rotation": 56,
          "vsPace": 64,
          "vsSpin": 47,
          "control": 57,
          "movement": 48,
          "variation": 37,
          "stamina": 54,
          "catching": 67,
          "groundFielding": 71,
          "throwing": 61,
          "keeping": 25
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        763,
        267,
        604,
        292,
        768,
        345,
        424,
        560
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p011",
      "name": "Fenn Jorthorne",
      "birthDate": "2007-11-18",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 43,
          "power": 58,
          "rotation": 41,
          "vsPace": 38,
          "vsSpin": 65,
          "control": 45,
          "movement": 58,
          "variation": 59,
          "stamina": 37,
          "catching": 72,
          "groundFielding": 69,
          "throwing": 51,
          "keeping": 12
        },
        "ODI": {
          "defence": 49,
          "timing": 39,
          "power": 67,
          "rotation": 46,
          "vsPace": 61,
          "vsSpin": 55,
          "control": 37,
          "movement": 61,
          "variation": 41,
          "stamina": 46,
          "catching": 62,
          "groundFielding": 60,
          "throwing": 66,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 46,
          "power": 35,
          "rotation": 50,
          "vsPace": 45,
          "vsSpin": 39,
          "control": 53,
          "movement": 45,
          "variation": 49,
          "stamina": 37,
          "catching": 51,
          "groundFielding": 59,
          "throwing": 68,
          "keeping": 32
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        610,
        352,
        658,
        987,
        637,
        873,
        208,
        224
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p012",
      "name": "Elio Ashbrook",
      "birthDate": "1997-12-28",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 58,
          "timing": 63,
          "power": 59,
          "rotation": 53,
          "vsPace": 61,
          "vsSpin": 54,
          "control": 43,
          "movement": 19,
          "variation": 28,
          "stamina": 19,
          "catching": 58,
          "groundFielding": 43,
          "throwing": 41,
          "keeping": 17
        },
        "ODI": {
          "defence": 54,
          "timing": 69,
          "power": 58,
          "rotation": 66,
          "vsPace": 55,
          "vsSpin": 62,
          "control": 30,
          "movement": 33,
          "variation": 17,
          "stamina": 27,
          "catching": 54,
          "groundFielding": 45,
          "throwing": 63,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 66,
          "timing": 70,
          "power": 71,
          "rotation": 74,
          "vsPace": 61,
          "vsSpin": 51,
          "control": 14,
          "movement": 39,
          "variation": 32,
          "stamina": 35,
          "catching": 62,
          "groundFielding": 51,
          "throwing": 38,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        809,
        987,
        357,
        874,
        249,
        843,
        813,
        950
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p013",
      "name": "Quill Sablebridge",
      "birthDate": "1994-04-18",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 75,
          "timing": 64,
          "power": 55,
          "rotation": 59,
          "vsPace": 64,
          "vsSpin": 76,
          "control": 16,
          "movement": 29,
          "variation": 28,
          "stamina": 23,
          "catching": 65,
          "groundFielding": 64,
          "throwing": 46,
          "keeping": 26
        },
        "ODI": {
          "defence": 77,
          "timing": 57,
          "power": 76,
          "rotation": 72,
          "vsPace": 68,
          "vsSpin": 52,
          "control": 19,
          "movement": 17,
          "variation": 26,
          "stamina": 30,
          "catching": 46,
          "groundFielding": 51,
          "throwing": 43,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 71,
          "power": 55,
          "rotation": 54,
          "vsPace": 74,
          "vsSpin": 67,
          "control": 21,
          "movement": 38,
          "variation": 38,
          "stamina": 25,
          "catching": 60,
          "groundFielding": 57,
          "throwing": 60,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        552,
        929,
        640,
        875,
        271,
        354,
        860,
        670
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p014",
      "name": "Nave Elmford",
      "birthDate": "1991-01-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 70,
          "timing": 80,
          "power": 74,
          "rotation": 67,
          "vsPace": 68,
          "vsSpin": 77,
          "control": 32,
          "movement": 21,
          "variation": 27,
          "stamina": 29,
          "catching": 40,
          "groundFielding": 48,
          "throwing": 53,
          "keeping": 15
        },
        "ODI": {
          "defence": 74,
          "timing": 78,
          "power": 64,
          "rotation": 74,
          "vsPace": 80,
          "vsSpin": 73,
          "control": 23,
          "movement": 24,
          "variation": 44,
          "stamina": 41,
          "catching": 43,
          "groundFielding": 57,
          "throwing": 66,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 59,
          "power": 65,
          "rotation": 63,
          "vsPace": 56,
          "vsSpin": 68,
          "control": 38,
          "movement": 33,
          "variation": 26,
          "stamina": 41,
          "catching": 64,
          "groundFielding": 41,
          "throwing": 38,
          "keeping": 25
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        249,
        795,
        989,
        996,
        471,
        606,
        638,
        740
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p015",
      "name": "Eren Ashstead",
      "birthDate": "1988-05-06",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 55,
          "power": 59,
          "rotation": 52,
          "vsPace": 65,
          "vsSpin": 60,
          "control": 40,
          "movement": 34,
          "variation": 27,
          "stamina": 38,
          "catching": 51,
          "groundFielding": 59,
          "throwing": 59,
          "keeping": 19
        },
        "ODI": {
          "defence": 61,
          "timing": 56,
          "power": 64,
          "rotation": 52,
          "vsPace": 54,
          "vsSpin": 67,
          "control": 36,
          "movement": 37,
          "variation": 26,
          "stamina": 42,
          "catching": 63,
          "groundFielding": 40,
          "throwing": 56,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 50,
          "power": 55,
          "rotation": 63,
          "vsPace": 79,
          "vsSpin": 62,
          "control": 29,
          "movement": 18,
          "variation": 40,
          "stamina": 29,
          "catching": 37,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        305,
        339,
        390,
        487,
        867,
        724,
        327,
        533
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p016",
      "name": "Eren Rookholt",
      "birthDate": "2007-10-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 54,
          "power": 62,
          "rotation": 76,
          "vsPace": 78,
          "vsSpin": 69,
          "control": 24,
          "movement": 23,
          "variation": 40,
          "stamina": 19,
          "catching": 54,
          "groundFielding": 59,
          "throwing": 39,
          "keeping": 21
        },
        "ODI": {
          "defence": 50,
          "timing": 71,
          "power": 59,
          "rotation": 62,
          "vsPace": 51,
          "vsSpin": 69,
          "control": 37,
          "movement": 29,
          "variation": 19,
          "stamina": 34,
          "catching": 38,
          "groundFielding": 45,
          "throwing": 57,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 77,
          "power": 60,
          "rotation": 76,
          "vsPace": 77,
          "vsSpin": 51,
          "control": 30,
          "movement": 31,
          "variation": 22,
          "stamina": 34,
          "catching": 38,
          "groundFielding": 55,
          "throwing": 50,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        254,
        646,
        361,
        756,
        972,
        341,
        803,
        293
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p017",
      "name": "Nerin Elmcroft",
      "birthDate": "1996-01-18",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 58,
          "timing": 74,
          "power": 56,
          "rotation": 53,
          "vsPace": 73,
          "vsSpin": 73,
          "control": 26,
          "movement": 36,
          "variation": 21,
          "stamina": 21,
          "catching": 49,
          "groundFielding": 52,
          "throwing": 62,
          "keeping": 30
        },
        "ODI": {
          "defence": 58,
          "timing": 79,
          "power": 55,
          "rotation": 60,
          "vsPace": 77,
          "vsSpin": 52,
          "control": 37,
          "movement": 39,
          "variation": 18,
          "stamina": 34,
          "catching": 40,
          "groundFielding": 62,
          "throwing": 47,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 75,
          "timing": 67,
          "power": 61,
          "rotation": 67,
          "vsPace": 74,
          "vsSpin": 69,
          "control": 43,
          "movement": 42,
          "variation": 30,
          "stamina": 14,
          "catching": 45,
          "groundFielding": 54,
          "throwing": 61,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        470,
        461,
        260,
        560,
        430,
        410,
        792,
        532
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p018",
      "name": "Yoran Pellbrook",
      "birthDate": "1994-01-23",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 63,
          "power": 59,
          "rotation": 67,
          "vsPace": 74,
          "vsSpin": 79,
          "control": 25,
          "movement": 33,
          "variation": 40,
          "stamina": 26,
          "catching": 53,
          "groundFielding": 51,
          "throwing": 45,
          "keeping": 16
        },
        "ODI": {
          "defence": 68,
          "timing": 58,
          "power": 50,
          "rotation": 50,
          "vsPace": 73,
          "vsSpin": 66,
          "control": 25,
          "movement": 41,
          "variation": 29,
          "stamina": 44,
          "catching": 48,
          "groundFielding": 48,
          "throwing": 39,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 52,
          "power": 53,
          "rotation": 77,
          "vsPace": 75,
          "vsSpin": 64,
          "control": 27,
          "movement": 15,
          "variation": 21,
          "stamina": 26,
          "catching": 44,
          "groundFielding": 50,
          "throwing": 40,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        738,
        743,
        243,
        780,
        627,
        438,
        793,
        662
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p019",
      "name": "Yoran Harridge",
      "birthDate": "2004-12-01",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 70,
          "timing": 50,
          "power": 56,
          "rotation": 58,
          "vsPace": 59,
          "vsSpin": 50,
          "control": 30,
          "movement": 18,
          "variation": 20,
          "stamina": 44,
          "catching": 53,
          "groundFielding": 50,
          "throwing": 48,
          "keeping": 16
        },
        "ODI": {
          "defence": 51,
          "timing": 78,
          "power": 69,
          "rotation": 76,
          "vsPace": 77,
          "vsSpin": 50,
          "control": 24,
          "movement": 20,
          "variation": 28,
          "stamina": 32,
          "catching": 62,
          "groundFielding": 54,
          "throwing": 67,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 57,
          "timing": 79,
          "power": 54,
          "rotation": 65,
          "vsPace": 63,
          "vsSpin": 74,
          "control": 27,
          "movement": 44,
          "variation": 23,
          "stamina": 16,
          "catching": 59,
          "groundFielding": 57,
          "throwing": 51,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        829,
        413,
        737,
        576,
        955,
        951,
        844,
        913
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p020",
      "name": "Galen Zornden",
      "birthDate": "2002-08-20",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 53,
          "power": 80,
          "rotation": 73,
          "vsPace": 76,
          "vsSpin": 80,
          "control": 38,
          "movement": 41,
          "variation": 37,
          "stamina": 33,
          "catching": 50,
          "groundFielding": 45,
          "throwing": 50,
          "keeping": 31
        },
        "ODI": {
          "defence": 56,
          "timing": 80,
          "power": 74,
          "rotation": 80,
          "vsPace": 78,
          "vsSpin": 51,
          "control": 31,
          "movement": 34,
          "variation": 37,
          "stamina": 28,
          "catching": 60,
          "groundFielding": 49,
          "throwing": 48,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 78,
          "timing": 76,
          "power": 63,
          "rotation": 64,
          "vsPace": 57,
          "vsSpin": 68,
          "control": 31,
          "movement": 30,
          "variation": 14,
          "stamina": 32,
          "catching": 44,
          "groundFielding": 40,
          "throwing": 61,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        437,
        997,
        413,
        917,
        402,
        660,
        705,
        463
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p021",
      "name": "Walen Sableholt",
      "birthDate": "1997-12-15",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 36,
          "power": 41,
          "rotation": 56,
          "vsPace": 51,
          "vsSpin": 58,
          "control": 42,
          "movement": 31,
          "variation": 29,
          "stamina": 12,
          "catching": 56,
          "groundFielding": 58,
          "throwing": 57,
          "keeping": 73
        },
        "ODI": {
          "defence": 61,
          "timing": 37,
          "power": 63,
          "rotation": 53,
          "vsPace": 39,
          "vsSpin": 64,
          "control": 35,
          "movement": 42,
          "variation": 13,
          "stamina": 41,
          "catching": 69,
          "groundFielding": 65,
          "throwing": 45,
          "keeping": 80
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 55,
          "power": 43,
          "rotation": 42,
          "vsPace": 55,
          "vsSpin": 45,
          "control": 19,
          "movement": 14,
          "variation": 17,
          "stamina": 20,
          "catching": 48,
          "groundFielding": 66,
          "throwing": 52,
          "keeping": 76
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        691,
        484,
        492,
        590,
        991,
        255,
        476,
        877
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p022",
      "name": "Ulen Wrenthorne",
      "birthDate": "1998-06-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 54,
          "power": 60,
          "rotation": 40,
          "vsPace": 64,
          "vsSpin": 55,
          "control": 42,
          "movement": 13,
          "variation": 26,
          "stamina": 20,
          "catching": 45,
          "groundFielding": 62,
          "throwing": 41,
          "keeping": 56
        },
        "ODI": {
          "defence": 41,
          "timing": 58,
          "power": 48,
          "rotation": 34,
          "vsPace": 60,
          "vsSpin": 35,
          "control": 21,
          "movement": 38,
          "variation": 13,
          "stamina": 31,
          "catching": 66,
          "groundFielding": 44,
          "throwing": 44,
          "keeping": 59
        },
        "RED_BALL": {
          "defence": 51,
          "timing": 41,
          "power": 56,
          "rotation": 40,
          "vsPace": 60,
          "vsSpin": 54,
          "control": 25,
          "movement": 17,
          "variation": 17,
          "stamina": 13,
          "catching": 48,
          "groundFielding": 69,
          "throwing": 51,
          "keeping": 78
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        598,
        605,
        697,
        615,
        410,
        240,
        621,
        805
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p023",
      "name": "Pavan Zornstone",
      "birthDate": "2003-11-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 39,
          "timing": 48,
          "power": 39,
          "rotation": 32,
          "vsPace": 47,
          "vsSpin": 30,
          "control": 66,
          "movement": 77,
          "variation": 67,
          "stamina": 60,
          "catching": 65,
          "groundFielding": 52,
          "throwing": 62,
          "keeping": 24
        },
        "ODI": {
          "defence": 28,
          "timing": 29,
          "power": 24,
          "rotation": 36,
          "vsPace": 45,
          "vsSpin": 31,
          "control": 73,
          "movement": 74,
          "variation": 52,
          "stamina": 78,
          "catching": 63,
          "groundFielding": 52,
          "throwing": 68,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 27,
          "timing": 19,
          "power": 32,
          "rotation": 40,
          "vsPace": 24,
          "vsSpin": 48,
          "control": 64,
          "movement": 67,
          "variation": 61,
          "stamina": 76,
          "catching": 67,
          "groundFielding": 42,
          "throwing": 49,
          "keeping": 18
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        708,
        357,
        237,
        752,
        382,
        449,
        761,
        542
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p024",
      "name": "Rilan Rookfield",
      "birthDate": "2005-05-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 25,
          "timing": 37,
          "power": 30,
          "rotation": 22,
          "vsPace": 28,
          "vsSpin": 48,
          "control": 72,
          "movement": 65,
          "variation": 57,
          "stamina": 70,
          "catching": 65,
          "groundFielding": 58,
          "throwing": 42,
          "keeping": 21
        },
        "ODI": {
          "defence": 45,
          "timing": 24,
          "power": 34,
          "rotation": 47,
          "vsPace": 19,
          "vsSpin": 48,
          "control": 64,
          "movement": 52,
          "variation": 77,
          "stamina": 65,
          "catching": 64,
          "groundFielding": 40,
          "throwing": 69,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 27,
          "timing": 40,
          "power": 27,
          "rotation": 46,
          "vsPace": 48,
          "vsSpin": 19,
          "control": 55,
          "movement": 53,
          "variation": 50,
          "stamina": 80,
          "catching": 63,
          "groundFielding": 55,
          "throwing": 48,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        584,
        917,
        279,
        473,
        646,
        402,
        706,
        403
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p025",
      "name": "Zerin Wrenbrook",
      "birthDate": "1990-07-28",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 32,
          "timing": 20,
          "power": 34,
          "rotation": 35,
          "vsPace": 35,
          "vsSpin": 48,
          "control": 57,
          "movement": 65,
          "variation": 67,
          "stamina": 52,
          "catching": 50,
          "groundFielding": 45,
          "throwing": 40,
          "keeping": 29
        },
        "ODI": {
          "defence": 31,
          "timing": 37,
          "power": 42,
          "rotation": 19,
          "vsPace": 31,
          "vsSpin": 39,
          "control": 70,
          "movement": 69,
          "variation": 53,
          "stamina": 73,
          "catching": 41,
          "groundFielding": 55,
          "throwing": 52,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 31,
          "timing": 23,
          "power": 29,
          "rotation": 40,
          "vsPace": 40,
          "vsSpin": 39,
          "control": 56,
          "movement": 50,
          "variation": 71,
          "stamina": 50,
          "catching": 42,
          "groundFielding": 65,
          "throwing": 53,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        657,
        773,
        958,
        885,
        245,
        815,
        766,
        513
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p026",
      "name": "Borin Zornbrook",
      "birthDate": "1998-06-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 27,
          "timing": 36,
          "power": 25,
          "rotation": 49,
          "vsPace": 37,
          "vsSpin": 27,
          "control": 50,
          "movement": 78,
          "variation": 53,
          "stamina": 56,
          "catching": 65,
          "groundFielding": 42,
          "throwing": 49,
          "keeping": 41
        },
        "ODI": {
          "defence": 46,
          "timing": 43,
          "power": 33,
          "rotation": 25,
          "vsPace": 20,
          "vsSpin": 31,
          "control": 68,
          "movement": 54,
          "variation": 77,
          "stamina": 59,
          "catching": 48,
          "groundFielding": 57,
          "throwing": 56,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 28,
          "timing": 35,
          "power": 38,
          "rotation": 23,
          "vsPace": 28,
          "vsSpin": 33,
          "control": 63,
          "movement": 67,
          "variation": 55,
          "stamina": 63,
          "catching": 53,
          "groundFielding": 63,
          "throwing": 60,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        230,
        311,
        805,
        559,
        449,
        768,
        803,
        604
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p027",
      "name": "Jora Mossridge",
      "birthDate": "1988-08-21",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 44,
          "power": 41,
          "rotation": 22,
          "vsPace": 42,
          "vsSpin": 32,
          "control": 52,
          "movement": 76,
          "variation": 70,
          "stamina": 60,
          "catching": 55,
          "groundFielding": 59,
          "throwing": 51,
          "keeping": 31
        },
        "ODI": {
          "defence": 27,
          "timing": 39,
          "power": 47,
          "rotation": 26,
          "vsPace": 49,
          "vsSpin": 44,
          "control": 55,
          "movement": 58,
          "variation": 53,
          "stamina": 50,
          "catching": 49,
          "groundFielding": 60,
          "throwing": 47,
          "keeping": 34
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 34,
          "power": 36,
          "rotation": 38,
          "vsPace": 30,
          "vsSpin": 37,
          "control": 63,
          "movement": 76,
          "variation": 75,
          "stamina": 63,
          "catching": 42,
          "groundFielding": 45,
          "throwing": 43,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        685,
        344,
        907,
        538,
        521,
        813,
        493,
        981
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p028",
      "name": "Quill Ternstead",
      "birthDate": "1992-12-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 20,
          "timing": 28,
          "power": 41,
          "rotation": 33,
          "vsPace": 38,
          "vsSpin": 19,
          "control": 58,
          "movement": 69,
          "variation": 76,
          "stamina": 67,
          "catching": 46,
          "groundFielding": 60,
          "throwing": 58,
          "keeping": 38
        },
        "ODI": {
          "defence": 47,
          "timing": 31,
          "power": 25,
          "rotation": 40,
          "vsPace": 26,
          "vsSpin": 40,
          "control": 50,
          "movement": 78,
          "variation": 72,
          "stamina": 75,
          "catching": 48,
          "groundFielding": 52,
          "throwing": 65,
          "keeping": 27
        },
        "RED_BALL": {
          "defence": 44,
          "timing": 47,
          "power": 37,
          "rotation": 24,
          "vsPace": 19,
          "vsSpin": 22,
          "control": 69,
          "movement": 68,
          "variation": 54,
          "stamina": 54,
          "catching": 68,
          "groundFielding": 42,
          "throwing": 59,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        736,
        772,
        877,
        718,
        401,
        406,
        386,
        736
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p029",
      "name": "Leron Briarstone",
      "birthDate": "2003-01-02",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 47,
          "power": 49,
          "rotation": 59,
          "vsPace": 48,
          "vsSpin": 49,
          "control": 41,
          "movement": 64,
          "variation": 60,
          "stamina": 64,
          "catching": 54,
          "groundFielding": 49,
          "throwing": 54,
          "keeping": 32
        },
        "ODI": {
          "defence": 66,
          "timing": 51,
          "power": 45,
          "rotation": 43,
          "vsPace": 54,
          "vsSpin": 62,
          "control": 45,
          "movement": 44,
          "variation": 50,
          "stamina": 47,
          "catching": 53,
          "groundFielding": 51,
          "throwing": 55,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 55,
          "timing": 65,
          "power": 48,
          "rotation": 49,
          "vsPace": 46,
          "vsSpin": 56,
          "control": 50,
          "movement": 57,
          "variation": 67,
          "stamina": 58,
          "catching": 55,
          "groundFielding": 64,
          "throwing": 66,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        904,
        606,
        465,
        429,
        811,
        658,
        919,
        529
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p030",
      "name": "Rilan Jorfield",
      "birthDate": "1999-05-05",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 48,
          "timing": 38,
          "power": 61,
          "rotation": 46,
          "vsPace": 50,
          "vsSpin": 58,
          "control": 46,
          "movement": 58,
          "variation": 65,
          "stamina": 52,
          "catching": 68,
          "groundFielding": 44,
          "throwing": 59,
          "keeping": 18
        },
        "ODI": {
          "defence": 57,
          "timing": 48,
          "power": 49,
          "rotation": 66,
          "vsPace": 58,
          "vsSpin": 41,
          "control": 65,
          "movement": 54,
          "variation": 60,
          "stamina": 47,
          "catching": 63,
          "groundFielding": 67,
          "throwing": 55,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 49,
          "timing": 65,
          "power": 35,
          "rotation": 44,
          "vsPace": 52,
          "vsSpin": 50,
          "control": 52,
          "movement": 53,
          "variation": 50,
          "stamina": 58,
          "catching": 62,
          "groundFielding": 55,
          "throwing": 58,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        842,
        423,
        606,
        680,
        454,
        661,
        759,
        226
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p031",
      "name": "Elio Valethorne",
      "birthDate": "1995-08-25",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 45,
          "power": 46,
          "rotation": 58,
          "vsPace": 38,
          "vsSpin": 38,
          "control": 62,
          "movement": 66,
          "variation": 67,
          "stamina": 58,
          "catching": 45,
          "groundFielding": 69,
          "throwing": 57,
          "keeping": 21
        },
        "ODI": {
          "defence": 65,
          "timing": 63,
          "power": 65,
          "rotation": 41,
          "vsPace": 40,
          "vsSpin": 60,
          "control": 52,
          "movement": 57,
          "variation": 45,
          "stamina": 43,
          "catching": 65,
          "groundFielding": 48,
          "throwing": 65,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 68,
          "timing": 38,
          "power": 59,
          "rotation": 62,
          "vsPace": 64,
          "vsSpin": 66,
          "control": 58,
          "movement": 44,
          "variation": 54,
          "stamina": 52,
          "catching": 45,
          "groundFielding": 68,
          "throwing": 53,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        806,
        641,
        284,
        837,
        960,
        505,
        380,
        216
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p032",
      "name": "Ari Mossbridge",
      "birthDate": "1992-04-18",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 63,
          "power": 62,
          "rotation": 60,
          "vsPace": 51,
          "vsSpin": 50,
          "control": 18,
          "movement": 33,
          "variation": 35,
          "stamina": 30,
          "catching": 58,
          "groundFielding": 56,
          "throwing": 61,
          "keeping": 18
        },
        "ODI": {
          "defence": 58,
          "timing": 72,
          "power": 68,
          "rotation": 60,
          "vsPace": 62,
          "vsSpin": 60,
          "control": 19,
          "movement": 34,
          "variation": 15,
          "stamina": 22,
          "catching": 51,
          "groundFielding": 65,
          "throwing": 45,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 66,
          "power": 52,
          "rotation": 77,
          "vsPace": 80,
          "vsSpin": 57,
          "control": 15,
          "movement": 41,
          "variation": 33,
          "stamina": 18,
          "catching": 60,
          "groundFielding": 58,
          "throwing": 47,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        627,
        857,
        373,
        300,
        225,
        798,
        405,
        627
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p033",
      "name": "Vero Glenthorne",
      "birthDate": "1991-04-10",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 76,
          "timing": 62,
          "power": 68,
          "rotation": 73,
          "vsPace": 57,
          "vsSpin": 74,
          "control": 29,
          "movement": 20,
          "variation": 43,
          "stamina": 25,
          "catching": 57,
          "groundFielding": 59,
          "throwing": 61,
          "keeping": 25
        },
        "ODI": {
          "defence": 53,
          "timing": 76,
          "power": 77,
          "rotation": 70,
          "vsPace": 63,
          "vsSpin": 58,
          "control": 29,
          "movement": 20,
          "variation": 42,
          "stamina": 44,
          "catching": 44,
          "groundFielding": 42,
          "throwing": 50,
          "keeping": 41
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 67,
          "power": 75,
          "rotation": 57,
          "vsPace": 62,
          "vsSpin": 64,
          "control": 24,
          "movement": 21,
          "variation": 37,
          "stamina": 28,
          "catching": 48,
          "groundFielding": 54,
          "throwing": 66,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        362,
        821,
        415,
        466,
        660,
        589,
        420,
        203
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p034",
      "name": "Isen Ternfell",
      "birthDate": "2001-07-20",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 64,
          "power": 68,
          "rotation": 54,
          "vsPace": 67,
          "vsSpin": 78,
          "control": 15,
          "movement": 33,
          "variation": 31,
          "stamina": 39,
          "catching": 50,
          "groundFielding": 56,
          "throwing": 53,
          "keeping": 11
        },
        "ODI": {
          "defence": 60,
          "timing": 68,
          "power": 54,
          "rotation": 52,
          "vsPace": 72,
          "vsSpin": 62,
          "control": 34,
          "movement": 23,
          "variation": 16,
          "stamina": 17,
          "catching": 48,
          "groundFielding": 46,
          "throwing": 59,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 59,
          "timing": 66,
          "power": 72,
          "rotation": 51,
          "vsPace": 65,
          "vsSpin": 80,
          "control": 16,
          "movement": 30,
          "variation": 18,
          "stamina": 33,
          "catching": 61,
          "groundFielding": 48,
          "throwing": 48,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        561,
        842,
        1000,
        382,
        426,
        520,
        249,
        916
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p035",
      "name": "Talor Pellbridge",
      "birthDate": "1996-03-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 58,
          "power": 61,
          "rotation": 63,
          "vsPace": 53,
          "vsSpin": 68,
          "control": 40,
          "movement": 23,
          "variation": 15,
          "stamina": 18,
          "catching": 38,
          "groundFielding": 42,
          "throwing": 47,
          "keeping": 13
        },
        "ODI": {
          "defence": 57,
          "timing": 70,
          "power": 55,
          "rotation": 66,
          "vsPace": 57,
          "vsSpin": 72,
          "control": 35,
          "movement": 38,
          "variation": 15,
          "stamina": 36,
          "catching": 46,
          "groundFielding": 44,
          "throwing": 50,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 53,
          "power": 66,
          "rotation": 71,
          "vsPace": 73,
          "vsSpin": 53,
          "control": 16,
          "movement": 17,
          "variation": 29,
          "stamina": 42,
          "catching": 59,
          "groundFielding": 64,
          "throwing": 46,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        276,
        713,
        500,
        665,
        875,
        299,
        367,
        263
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p036",
      "name": "Vero Jorcroft",
      "birthDate": "2007-12-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 71,
          "power": 54,
          "rotation": 77,
          "vsPace": 53,
          "vsSpin": 76,
          "control": 39,
          "movement": 40,
          "variation": 44,
          "stamina": 28,
          "catching": 37,
          "groundFielding": 44,
          "throwing": 57,
          "keeping": 21
        },
        "ODI": {
          "defence": 70,
          "timing": 68,
          "power": 73,
          "rotation": 53,
          "vsPace": 66,
          "vsSpin": 58,
          "control": 18,
          "movement": 19,
          "variation": 39,
          "stamina": 14,
          "catching": 44,
          "groundFielding": 54,
          "throwing": 44,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 64,
          "timing": 73,
          "power": 62,
          "rotation": 64,
          "vsPace": 63,
          "vsSpin": 69,
          "control": 43,
          "movement": 29,
          "variation": 20,
          "stamina": 39,
          "catching": 57,
          "groundFielding": 51,
          "throwing": 39,
          "keeping": 32
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        850,
        339,
        912,
        540,
        951,
        924,
        338,
        394
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p037",
      "name": "Walen Mosswell",
      "birthDate": "2001-09-28",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 61,
          "power": 73,
          "rotation": 62,
          "vsPace": 67,
          "vsSpin": 57,
          "control": 34,
          "movement": 43,
          "variation": 21,
          "stamina": 35,
          "catching": 42,
          "groundFielding": 39,
          "throwing": 51,
          "keeping": 34
        },
        "ODI": {
          "defence": 59,
          "timing": 61,
          "power": 51,
          "rotation": 69,
          "vsPace": 79,
          "vsSpin": 63,
          "control": 18,
          "movement": 28,
          "variation": 43,
          "stamina": 14,
          "catching": 63,
          "groundFielding": 59,
          "throwing": 63,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 83,
          "timing": 63,
          "power": 64,
          "rotation": 54,
          "vsPace": 60,
          "vsSpin": 62,
          "control": 23,
          "movement": 38,
          "variation": 21,
          "stamina": 27,
          "catching": 59,
          "groundFielding": 59,
          "throwing": 37,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        214,
        200,
        732,
        547,
        844,
        659,
        331,
        523
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p038",
      "name": "Nalo Rookfield",
      "birthDate": "1998-05-04",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 63,
          "power": 83,
          "rotation": 58,
          "vsPace": 68,
          "vsSpin": 74,
          "control": 38,
          "movement": 33,
          "variation": 14,
          "stamina": 26,
          "catching": 41,
          "groundFielding": 58,
          "throwing": 50,
          "keeping": 13
        },
        "ODI": {
          "defence": 70,
          "timing": 61,
          "power": 78,
          "rotation": 67,
          "vsPace": 76,
          "vsSpin": 73,
          "control": 18,
          "movement": 16,
          "variation": 20,
          "stamina": 21,
          "catching": 66,
          "groundFielding": 62,
          "throwing": 61,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 79,
          "timing": 70,
          "power": 72,
          "rotation": 65,
          "vsPace": 62,
          "vsSpin": 64,
          "control": 32,
          "movement": 17,
          "variation": 31,
          "stamina": 33,
          "catching": 50,
          "groundFielding": 62,
          "throwing": 42,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        896,
        650,
        511,
        581,
        589,
        936,
        411,
        727
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p039",
      "name": "Arven Rookridge",
      "birthDate": "2002-12-12",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 52,
          "power": 67,
          "rotation": 53,
          "vsPace": 58,
          "vsSpin": 55,
          "control": 39,
          "movement": 31,
          "variation": 23,
          "stamina": 33,
          "catching": 51,
          "groundFielding": 57,
          "throwing": 37,
          "keeping": 14
        },
        "ODI": {
          "defence": 66,
          "timing": 62,
          "power": 50,
          "rotation": 53,
          "vsPace": 78,
          "vsSpin": 67,
          "control": 29,
          "movement": 43,
          "variation": 32,
          "stamina": 34,
          "catching": 42,
          "groundFielding": 63,
          "throwing": 59,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 83,
          "timing": 60,
          "power": 68,
          "rotation": 56,
          "vsPace": 77,
          "vsSpin": 75,
          "control": 40,
          "movement": 42,
          "variation": 39,
          "stamina": 21,
          "catching": 40,
          "groundFielding": 44,
          "throwing": 53,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        834,
        749,
        746,
        898,
        334,
        726,
        623,
        341
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p040",
      "name": "Jora Ashholt",
      "birthDate": "1996-09-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 67,
          "power": 55,
          "rotation": 66,
          "vsPace": 58,
          "vsSpin": 62,
          "control": 27,
          "movement": 14,
          "variation": 41,
          "stamina": 21,
          "catching": 48,
          "groundFielding": 48,
          "throwing": 57,
          "keeping": 31
        },
        "ODI": {
          "defence": 62,
          "timing": 78,
          "power": 79,
          "rotation": 52,
          "vsPace": 66,
          "vsSpin": 75,
          "control": 42,
          "movement": 30,
          "variation": 20,
          "stamina": 25,
          "catching": 67,
          "groundFielding": 40,
          "throwing": 66,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 76,
          "power": 64,
          "rotation": 62,
          "vsPace": 58,
          "vsSpin": 57,
          "control": 43,
          "movement": 43,
          "variation": 28,
          "stamina": 42,
          "catching": 46,
          "groundFielding": 64,
          "throwing": 41,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        930,
        412,
        455,
        976,
        691,
        811,
        208,
        872
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p041",
      "name": "Nave Glenthorne",
      "birthDate": "1988-01-02",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 47,
          "timing": 42,
          "power": 51,
          "rotation": 60,
          "vsPace": 38,
          "vsSpin": 40,
          "control": 12,
          "movement": 39,
          "variation": 26,
          "stamina": 14,
          "catching": 57,
          "groundFielding": 48,
          "throwing": 49,
          "keeping": 60
        },
        "ODI": {
          "defence": 37,
          "timing": 47,
          "power": 49,
          "rotation": 43,
          "vsPace": 63,
          "vsSpin": 44,
          "control": 28,
          "movement": 32,
          "variation": 40,
          "stamina": 28,
          "catching": 69,
          "groundFielding": 54,
          "throwing": 55,
          "keeping": 82
        },
        "RED_BALL": {
          "defence": 60,
          "timing": 45,
          "power": 45,
          "rotation": 34,
          "vsPace": 58,
          "vsSpin": 62,
          "control": 12,
          "movement": 34,
          "variation": 13,
          "stamina": 12,
          "catching": 71,
          "groundFielding": 66,
          "throwing": 43,
          "keeping": 71
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        554,
        322,
        981,
        809,
        689,
        395,
        238,
        434
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p042",
      "name": "Nave Harridge",
      "birthDate": "2007-03-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 54,
          "power": 60,
          "rotation": 45,
          "vsPace": 62,
          "vsSpin": 54,
          "control": 32,
          "movement": 27,
          "variation": 32,
          "stamina": 37,
          "catching": 58,
          "groundFielding": 56,
          "throwing": 70,
          "keeping": 61
        },
        "ODI": {
          "defence": 38,
          "timing": 45,
          "power": 52,
          "rotation": 55,
          "vsPace": 49,
          "vsSpin": 51,
          "control": 23,
          "movement": 18,
          "variation": 35,
          "stamina": 38,
          "catching": 48,
          "groundFielding": 56,
          "throwing": 49,
          "keeping": 71
        },
        "RED_BALL": {
          "defence": 55,
          "timing": 36,
          "power": 51,
          "rotation": 49,
          "vsPace": 60,
          "vsSpin": 43,
          "control": 15,
          "movement": 39,
          "variation": 30,
          "stamina": 18,
          "catching": 67,
          "groundFielding": 48,
          "throwing": 44,
          "keeping": 86
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        467,
        662,
        323,
        598,
        678,
        252,
        722,
        607
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p043",
      "name": "Isen Harbrook",
      "birthDate": "1991-01-10",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 28,
          "timing": 49,
          "power": 51,
          "rotation": 39,
          "vsPace": 36,
          "vsSpin": 34,
          "control": 68,
          "movement": 63,
          "variation": 78,
          "stamina": 58,
          "catching": 57,
          "groundFielding": 44,
          "throwing": 45,
          "keeping": 26
        },
        "ODI": {
          "defence": 42,
          "timing": 21,
          "power": 24,
          "rotation": 45,
          "vsPace": 37,
          "vsSpin": 39,
          "control": 75,
          "movement": 58,
          "variation": 75,
          "stamina": 60,
          "catching": 65,
          "groundFielding": 55,
          "throwing": 68,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 35,
          "timing": 48,
          "power": 32,
          "rotation": 38,
          "vsPace": 35,
          "vsSpin": 19,
          "control": 58,
          "movement": 78,
          "variation": 66,
          "stamina": 50,
          "catching": 66,
          "groundFielding": 48,
          "throwing": 53,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        861,
        505,
        271,
        974,
        891,
        585,
        230,
        505
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p044",
      "name": "Ari Mossthorne",
      "birthDate": "1991-07-12",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 19,
          "power": 32,
          "rotation": 36,
          "vsPace": 48,
          "vsSpin": 35,
          "control": 53,
          "movement": 63,
          "variation": 67,
          "stamina": 64,
          "catching": 42,
          "groundFielding": 39,
          "throwing": 57,
          "keeping": 19
        },
        "ODI": {
          "defence": 49,
          "timing": 49,
          "power": 45,
          "rotation": 36,
          "vsPace": 20,
          "vsSpin": 49,
          "control": 77,
          "movement": 79,
          "variation": 59,
          "stamina": 76,
          "catching": 64,
          "groundFielding": 41,
          "throwing": 55,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 39,
          "timing": 44,
          "power": 35,
          "rotation": 45,
          "vsPace": 36,
          "vsSpin": 49,
          "control": 79,
          "movement": 51,
          "variation": 73,
          "stamina": 67,
          "catching": 40,
          "groundFielding": 51,
          "throwing": 48,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        302,
        488,
        563,
        996,
        469,
        245,
        404,
        226
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p045",
      "name": "Belan Falkholt",
      "birthDate": "2007-08-02",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 47,
          "power": 34,
          "rotation": 43,
          "vsPace": 26,
          "vsSpin": 41,
          "control": 71,
          "movement": 56,
          "variation": 59,
          "stamina": 73,
          "catching": 65,
          "groundFielding": 68,
          "throwing": 67,
          "keeping": 26
        },
        "ODI": {
          "defence": 48,
          "timing": 24,
          "power": 19,
          "rotation": 22,
          "vsPace": 29,
          "vsSpin": 43,
          "control": 60,
          "movement": 75,
          "variation": 67,
          "stamina": 72,
          "catching": 46,
          "groundFielding": 59,
          "throwing": 45,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 30,
          "timing": 38,
          "power": 36,
          "rotation": 26,
          "vsPace": 37,
          "vsSpin": 30,
          "control": 74,
          "movement": 54,
          "variation": 66,
          "stamina": 62,
          "catching": 40,
          "groundFielding": 40,
          "throwing": 44,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        774,
        414,
        657,
        220,
        485,
        974,
        483,
        405
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p046",
      "name": "Borin Jorbridge",
      "birthDate": "2006-04-20",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 27,
          "power": 33,
          "rotation": 20,
          "vsPace": 44,
          "vsSpin": 35,
          "control": 78,
          "movement": 67,
          "variation": 70,
          "stamina": 68,
          "catching": 66,
          "groundFielding": 59,
          "throwing": 39,
          "keeping": 26
        },
        "ODI": {
          "defence": 28,
          "timing": 25,
          "power": 34,
          "rotation": 24,
          "vsPace": 32,
          "vsSpin": 46,
          "control": 65,
          "movement": 76,
          "variation": 77,
          "stamina": 73,
          "catching": 44,
          "groundFielding": 49,
          "throwing": 60,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 42,
          "timing": 31,
          "power": 45,
          "rotation": 30,
          "vsPace": 43,
          "vsSpin": 41,
          "control": 77,
          "movement": 55,
          "variation": 55,
          "stamina": 74,
          "catching": 61,
          "groundFielding": 43,
          "throwing": 61,
          "keeping": 31
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        461,
        201,
        894,
        586,
        504,
        767,
        306,
        799
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p047",
      "name": "Eren Corwell",
      "birthDate": "1988-02-20",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 25,
          "timing": 37,
          "power": 51,
          "rotation": 40,
          "vsPace": 22,
          "vsSpin": 42,
          "control": 66,
          "movement": 73,
          "variation": 54,
          "stamina": 59,
          "catching": 57,
          "groundFielding": 49,
          "throwing": 64,
          "keeping": 16
        },
        "ODI": {
          "defence": 30,
          "timing": 25,
          "power": 25,
          "rotation": 46,
          "vsPace": 37,
          "vsSpin": 19,
          "control": 56,
          "movement": 67,
          "variation": 50,
          "stamina": 62,
          "catching": 60,
          "groundFielding": 40,
          "throwing": 45,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 35,
          "timing": 21,
          "power": 45,
          "rotation": 41,
          "vsPace": 33,
          "vsSpin": 46,
          "control": 50,
          "movement": 57,
          "variation": 73,
          "stamina": 68,
          "catching": 59,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        226,
        331,
        974,
        685,
        901,
        851,
        617,
        250
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p048",
      "name": "Galen Dunstone",
      "birthDate": "1996-03-09",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 30,
          "timing": 27,
          "power": 36,
          "rotation": 45,
          "vsPace": 20,
          "vsSpin": 22,
          "control": 51,
          "movement": 50,
          "variation": 55,
          "stamina": 57,
          "catching": 64,
          "groundFielding": 46,
          "throwing": 53,
          "keeping": 14
        },
        "ODI": {
          "defence": 34,
          "timing": 28,
          "power": 36,
          "rotation": 39,
          "vsPace": 41,
          "vsSpin": 42,
          "control": 76,
          "movement": 59,
          "variation": 78,
          "stamina": 68,
          "catching": 59,
          "groundFielding": 42,
          "throwing": 47,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 33,
          "timing": 23,
          "power": 17,
          "rotation": 23,
          "vsPace": 39,
          "vsSpin": 34,
          "control": 77,
          "movement": 75,
          "variation": 67,
          "stamina": 53,
          "catching": 64,
          "groundFielding": 52,
          "throwing": 44,
          "keeping": 16
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        571,
        939,
        491,
        529,
        224,
        842,
        965,
        567
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p049",
      "name": "Isen Harfield",
      "birthDate": "1997-11-23",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 62,
          "power": 55,
          "rotation": 43,
          "vsPace": 47,
          "vsSpin": 56,
          "control": 51,
          "movement": 60,
          "variation": 42,
          "stamina": 55,
          "catching": 54,
          "groundFielding": 55,
          "throwing": 44,
          "keeping": 38
        },
        "ODI": {
          "defence": 52,
          "timing": 42,
          "power": 39,
          "rotation": 48,
          "vsPace": 57,
          "vsSpin": 39,
          "control": 39,
          "movement": 61,
          "variation": 62,
          "stamina": 60,
          "catching": 65,
          "groundFielding": 45,
          "throwing": 56,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 60,
          "timing": 64,
          "power": 51,
          "rotation": 46,
          "vsPace": 47,
          "vsSpin": 65,
          "control": 52,
          "movement": 59,
          "variation": 50,
          "stamina": 50,
          "catching": 48,
          "groundFielding": 51,
          "throwing": 46,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        259,
        933,
        283,
        687,
        986,
        262,
        696,
        458
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p050",
      "name": "Deren Norbridge",
      "birthDate": "2002-10-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 53,
          "power": 60,
          "rotation": 51,
          "vsPace": 38,
          "vsSpin": 68,
          "control": 64,
          "movement": 38,
          "variation": 53,
          "stamina": 37,
          "catching": 70,
          "groundFielding": 45,
          "throwing": 50,
          "keeping": 37
        },
        "ODI": {
          "defence": 55,
          "timing": 58,
          "power": 50,
          "rotation": 42,
          "vsPace": 39,
          "vsSpin": 67,
          "control": 65,
          "movement": 60,
          "variation": 62,
          "stamina": 56,
          "catching": 66,
          "groundFielding": 66,
          "throwing": 64,
          "keeping": 30
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 44,
          "power": 58,
          "rotation": 61,
          "vsPace": 66,
          "vsSpin": 50,
          "control": 45,
          "movement": 64,
          "variation": 52,
          "stamina": 57,
          "catching": 66,
          "groundFielding": 64,
          "throwing": 60,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        369,
        933,
        321,
        900,
        474,
        819,
        831,
        971
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p051",
      "name": "Vero Mossridge",
      "birthDate": "2001-12-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 66,
          "power": 51,
          "rotation": 52,
          "vsPace": 47,
          "vsSpin": 41,
          "control": 43,
          "movement": 44,
          "variation": 39,
          "stamina": 40,
          "catching": 47,
          "groundFielding": 54,
          "throwing": 66,
          "keeping": 40
        },
        "ODI": {
          "defence": 43,
          "timing": 47,
          "power": 68,
          "rotation": 42,
          "vsPace": 59,
          "vsSpin": 46,
          "control": 55,
          "movement": 63,
          "variation": 38,
          "stamina": 48,
          "catching": 46,
          "groundFielding": 54,
          "throwing": 51,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 51,
          "power": 40,
          "rotation": 60,
          "vsPace": 46,
          "vsSpin": 67,
          "control": 54,
          "movement": 65,
          "variation": 58,
          "stamina": 58,
          "catching": 47,
          "groundFielding": 53,
          "throwing": 44,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        902,
        350,
        646,
        728,
        370,
        419,
        256,
        623
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p052",
      "name": "Leron Zornfell",
      "birthDate": "1995-01-23",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 73,
          "power": 84,
          "rotation": 72,
          "vsPace": 69,
          "vsSpin": 79,
          "control": 20,
          "movement": 31,
          "variation": 30,
          "stamina": 23,
          "catching": 65,
          "groundFielding": 61,
          "throwing": 41,
          "keeping": 15
        },
        "ODI": {
          "defence": 79,
          "timing": 57,
          "power": 62,
          "rotation": 75,
          "vsPace": 79,
          "vsSpin": 77,
          "control": 32,
          "movement": 35,
          "variation": 35,
          "stamina": 39,
          "catching": 50,
          "groundFielding": 40,
          "throwing": 62,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 52,
          "power": 50,
          "rotation": 76,
          "vsPace": 62,
          "vsSpin": 60,
          "control": 21,
          "movement": 31,
          "variation": 44,
          "stamina": 36,
          "catching": 60,
          "groundFielding": 64,
          "throwing": 41,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        985,
        472,
        867,
        797,
        859,
        932,
        300,
        671
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p053",
      "name": "Galen Valecombe",
      "birthDate": "1991-06-02",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 70,
          "power": 71,
          "rotation": 68,
          "vsPace": 65,
          "vsSpin": 71,
          "control": 34,
          "movement": 25,
          "variation": 26,
          "stamina": 39,
          "catching": 48,
          "groundFielding": 62,
          "throwing": 62,
          "keeping": 40
        },
        "ODI": {
          "defence": 75,
          "timing": 73,
          "power": 74,
          "rotation": 60,
          "vsPace": 65,
          "vsSpin": 77,
          "control": 14,
          "movement": 29,
          "variation": 35,
          "stamina": 41,
          "catching": 62,
          "groundFielding": 63,
          "throwing": 60,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 71,
          "power": 76,
          "rotation": 59,
          "vsPace": 51,
          "vsSpin": 50,
          "control": 26,
          "movement": 25,
          "variation": 15,
          "stamina": 17,
          "catching": 61,
          "groundFielding": 52,
          "throwing": 63,
          "keeping": 25
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        548,
        406,
        572,
        896,
        960,
        888,
        453,
        993
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p054",
      "name": "Jora Ternstone",
      "birthDate": "1996-01-23",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 72,
          "power": 55,
          "rotation": 72,
          "vsPace": 70,
          "vsSpin": 63,
          "control": 25,
          "movement": 35,
          "variation": 36,
          "stamina": 37,
          "catching": 64,
          "groundFielding": 63,
          "throwing": 62,
          "keeping": 30
        },
        "ODI": {
          "defence": 56,
          "timing": 70,
          "power": 53,
          "rotation": 75,
          "vsPace": 66,
          "vsSpin": 78,
          "control": 14,
          "movement": 36,
          "variation": 26,
          "stamina": 18,
          "catching": 41,
          "groundFielding": 38,
          "throwing": 59,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 85,
          "timing": 55,
          "power": 70,
          "rotation": 56,
          "vsPace": 51,
          "vsSpin": 51,
          "control": 27,
          "movement": 38,
          "variation": 22,
          "stamina": 21,
          "catching": 61,
          "groundFielding": 48,
          "throwing": 37,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        210,
        865,
        602,
        871,
        522,
        207,
        801,
        940
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p055",
      "name": "Fenn Iverthorne",
      "birthDate": "1993-05-03",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 72,
          "timing": 52,
          "power": 62,
          "rotation": 54,
          "vsPace": 79,
          "vsSpin": 71,
          "control": 33,
          "movement": 26,
          "variation": 42,
          "stamina": 38,
          "catching": 63,
          "groundFielding": 55,
          "throwing": 54,
          "keeping": 13
        },
        "ODI": {
          "defence": 63,
          "timing": 72,
          "power": 61,
          "rotation": 54,
          "vsPace": 53,
          "vsSpin": 52,
          "control": 19,
          "movement": 20,
          "variation": 15,
          "stamina": 15,
          "catching": 63,
          "groundFielding": 38,
          "throwing": 45,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 85,
          "timing": 56,
          "power": 56,
          "rotation": 79,
          "vsPace": 77,
          "vsSpin": 78,
          "control": 15,
          "movement": 33,
          "variation": 22,
          "stamina": 20,
          "catching": 45,
          "groundFielding": 38,
          "throwing": 42,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        877,
        672,
        503,
        606,
        984,
        625,
        959,
        266
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p056",
      "name": "Nalo Mossridge",
      "birthDate": "1999-12-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 75,
          "timing": 67,
          "power": 76,
          "rotation": 50,
          "vsPace": 72,
          "vsSpin": 79,
          "control": 33,
          "movement": 32,
          "variation": 25,
          "stamina": 25,
          "catching": 53,
          "groundFielding": 47,
          "throwing": 52,
          "keeping": 17
        },
        "ODI": {
          "defence": 73,
          "timing": 53,
          "power": 64,
          "rotation": 72,
          "vsPace": 57,
          "vsSpin": 53,
          "control": 29,
          "movement": 20,
          "variation": 22,
          "stamina": 30,
          "catching": 64,
          "groundFielding": 48,
          "throwing": 38,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 78,
          "power": 50,
          "rotation": 71,
          "vsPace": 76,
          "vsSpin": 54,
          "control": 32,
          "movement": 25,
          "variation": 19,
          "stamina": 43,
          "catching": 54,
          "groundFielding": 51,
          "throwing": 47,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        420,
        716,
        754,
        455,
        911,
        204,
        557,
        978
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p057",
      "name": "Ulen Iverwick",
      "birthDate": "1997-04-13",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 61,
          "power": 80,
          "rotation": 68,
          "vsPace": 71,
          "vsSpin": 75,
          "control": 15,
          "movement": 42,
          "variation": 30,
          "stamina": 41,
          "catching": 63,
          "groundFielding": 64,
          "throwing": 43,
          "keeping": 31
        },
        "ODI": {
          "defence": 74,
          "timing": 70,
          "power": 56,
          "rotation": 54,
          "vsPace": 51,
          "vsSpin": 79,
          "control": 24,
          "movement": 22,
          "variation": 37,
          "stamina": 23,
          "catching": 37,
          "groundFielding": 58,
          "throwing": 54,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 64,
          "power": 54,
          "rotation": 61,
          "vsPace": 65,
          "vsSpin": 51,
          "control": 26,
          "movement": 40,
          "variation": 17,
          "stamina": 25,
          "catching": 50,
          "groundFielding": 41,
          "throwing": 57,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        906,
        466,
        610,
        991,
        441,
        743,
        358,
        236
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p058",
      "name": "Halen Briarmere",
      "birthDate": "1995-01-05",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 66,
          "power": 77,
          "rotation": 73,
          "vsPace": 58,
          "vsSpin": 51,
          "control": 17,
          "movement": 21,
          "variation": 33,
          "stamina": 39,
          "catching": 64,
          "groundFielding": 40,
          "throwing": 38,
          "keeping": 36
        },
        "ODI": {
          "defence": 51,
          "timing": 80,
          "power": 63,
          "rotation": 53,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 18,
          "movement": 22,
          "variation": 21,
          "stamina": 29,
          "catching": 47,
          "groundFielding": 44,
          "throwing": 39,
          "keeping": 19
        },
        "RED_BALL": {
          "defence": 78,
          "timing": 77,
          "power": 63,
          "rotation": 75,
          "vsPace": 80,
          "vsSpin": 51,
          "control": 34,
          "movement": 29,
          "variation": 37,
          "stamina": 29,
          "catching": 38,
          "groundFielding": 46,
          "throwing": 57,
          "keeping": 32
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        681,
        756,
        973,
        589,
        574,
        521,
        390,
        269
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p059",
      "name": "Walen Sablecombe",
      "birthDate": "1994-09-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 51,
          "timing": 77,
          "power": 83,
          "rotation": 78,
          "vsPace": 77,
          "vsSpin": 57,
          "control": 32,
          "movement": 26,
          "variation": 37,
          "stamina": 24,
          "catching": 49,
          "groundFielding": 46,
          "throwing": 54,
          "keeping": 28
        },
        "ODI": {
          "defence": 72,
          "timing": 75,
          "power": 72,
          "rotation": 59,
          "vsPace": 69,
          "vsSpin": 54,
          "control": 38,
          "movement": 26,
          "variation": 38,
          "stamina": 19,
          "catching": 44,
          "groundFielding": 53,
          "throwing": 61,
          "keeping": 39
        },
        "RED_BALL": {
          "defence": 69,
          "timing": 55,
          "power": 61,
          "rotation": 60,
          "vsPace": 58,
          "vsSpin": 67,
          "control": 27,
          "movement": 41,
          "variation": 16,
          "stamina": 17,
          "catching": 45,
          "groundFielding": 51,
          "throwing": 54,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        828,
        229,
        562,
        337,
        391,
        316,
        398,
        315
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p060",
      "name": "Sela Mossford",
      "birthDate": "1998-12-16",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 75,
          "timing": 61,
          "power": 73,
          "rotation": 52,
          "vsPace": 57,
          "vsSpin": 63,
          "control": 31,
          "movement": 18,
          "variation": 22,
          "stamina": 15,
          "catching": 60,
          "groundFielding": 44,
          "throwing": 42,
          "keeping": 37
        },
        "ODI": {
          "defence": 50,
          "timing": 51,
          "power": 61,
          "rotation": 59,
          "vsPace": 55,
          "vsSpin": 71,
          "control": 42,
          "movement": 38,
          "variation": 34,
          "stamina": 44,
          "catching": 39,
          "groundFielding": 55,
          "throwing": 59,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 68,
          "timing": 73,
          "power": 63,
          "rotation": 74,
          "vsPace": 54,
          "vsSpin": 71,
          "control": 23,
          "movement": 30,
          "variation": 42,
          "stamina": 41,
          "catching": 64,
          "groundFielding": 53,
          "throwing": 61,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        670,
        375,
        899,
        406,
        877,
        435,
        790,
        223
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p061",
      "name": "Vero Wrenford",
      "birthDate": "1995-12-12",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 51,
          "timing": 53,
          "power": 65,
          "rotation": 53,
          "vsPace": 62,
          "vsSpin": 47,
          "control": 26,
          "movement": 23,
          "variation": 23,
          "stamina": 22,
          "catching": 62,
          "groundFielding": 60,
          "throwing": 67,
          "keeping": 80
        },
        "ODI": {
          "defence": 53,
          "timing": 39,
          "power": 55,
          "rotation": 42,
          "vsPace": 44,
          "vsSpin": 44,
          "control": 21,
          "movement": 13,
          "variation": 33,
          "stamina": 33,
          "catching": 71,
          "groundFielding": 49,
          "throwing": 60,
          "keeping": 59
        },
        "RED_BALL": {
          "defence": 54,
          "timing": 47,
          "power": 45,
          "rotation": 51,
          "vsPace": 52,
          "vsSpin": 38,
          "control": 18,
          "movement": 38,
          "variation": 12,
          "stamina": 28,
          "catching": 46,
          "groundFielding": 67,
          "throwing": 67,
          "keeping": 59
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        371,
        981,
        638,
        488,
        314,
        344,
        429,
        265
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p062",
      "name": "Kaelen Iverridge",
      "birthDate": "2007-07-02",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 53,
          "power": 61,
          "rotation": 63,
          "vsPace": 54,
          "vsSpin": 38,
          "control": 24,
          "movement": 20,
          "variation": 42,
          "stamina": 38,
          "catching": 65,
          "groundFielding": 47,
          "throwing": 48,
          "keeping": 72
        },
        "ODI": {
          "defence": 41,
          "timing": 50,
          "power": 37,
          "rotation": 58,
          "vsPace": 64,
          "vsSpin": 53,
          "control": 28,
          "movement": 31,
          "variation": 22,
          "stamina": 36,
          "catching": 56,
          "groundFielding": 71,
          "throwing": 49,
          "keeping": 76
        },
        "RED_BALL": {
          "defence": 39,
          "timing": 57,
          "power": 46,
          "rotation": 44,
          "vsPace": 43,
          "vsSpin": 60,
          "control": 37,
          "movement": 38,
          "variation": 20,
          "stamina": 32,
          "catching": 45,
          "groundFielding": 45,
          "throwing": 47,
          "keeping": 65
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        795,
        405,
        427,
        863,
        786,
        596,
        544,
        896
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p063",
      "name": "Vero Rookcombe",
      "birthDate": "2007-10-16",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 45,
          "power": 41,
          "rotation": 21,
          "vsPace": 45,
          "vsSpin": 33,
          "control": 67,
          "movement": 78,
          "variation": 64,
          "stamina": 80,
          "catching": 53,
          "groundFielding": 58,
          "throwing": 56,
          "keeping": 37
        },
        "ODI": {
          "defence": 40,
          "timing": 33,
          "power": 42,
          "rotation": 26,
          "vsPace": 48,
          "vsSpin": 20,
          "control": 76,
          "movement": 53,
          "variation": 57,
          "stamina": 72,
          "catching": 53,
          "groundFielding": 61,
          "throwing": 54,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 43,
          "power": 36,
          "rotation": 49,
          "vsPace": 49,
          "vsSpin": 27,
          "control": 62,
          "movement": 62,
          "variation": 66,
          "stamina": 70,
          "catching": 46,
          "groundFielding": 52,
          "throwing": 48,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        266,
        669,
        587,
        706,
        581,
        623,
        982,
        646
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p064",
      "name": "Talor Zornbrook",
      "birthDate": "1988-02-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 40,
          "power": 35,
          "rotation": 41,
          "vsPace": 35,
          "vsSpin": 24,
          "control": 56,
          "movement": 71,
          "variation": 77,
          "stamina": 67,
          "catching": 53,
          "groundFielding": 62,
          "throwing": 51,
          "keeping": 37
        },
        "ODI": {
          "defence": 32,
          "timing": 39,
          "power": 43,
          "rotation": 49,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 55,
          "movement": 74,
          "variation": 59,
          "stamina": 52,
          "catching": 41,
          "groundFielding": 46,
          "throwing": 68,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 22,
          "power": 44,
          "rotation": 39,
          "vsPace": 45,
          "vsSpin": 43,
          "control": 77,
          "movement": 57,
          "variation": 50,
          "stamina": 64,
          "catching": 65,
          "groundFielding": 66,
          "throwing": 47,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        594,
        235,
        994,
        438,
        965,
        915,
        510,
        668
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p065",
      "name": "Miran Ashford",
      "birthDate": "1998-08-04",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 19,
          "timing": 44,
          "power": 39,
          "rotation": 26,
          "vsPace": 46,
          "vsSpin": 26,
          "control": 71,
          "movement": 58,
          "variation": 68,
          "stamina": 78,
          "catching": 56,
          "groundFielding": 60,
          "throwing": 40,
          "keeping": 40
        },
        "ODI": {
          "defence": 45,
          "timing": 48,
          "power": 28,
          "rotation": 29,
          "vsPace": 45,
          "vsSpin": 21,
          "control": 79,
          "movement": 53,
          "variation": 74,
          "stamina": 67,
          "catching": 64,
          "groundFielding": 66,
          "throwing": 41,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 41,
          "timing": 22,
          "power": 37,
          "rotation": 22,
          "vsPace": 35,
          "vsSpin": 23,
          "control": 57,
          "movement": 73,
          "variation": 72,
          "stamina": 69,
          "catching": 55,
          "groundFielding": 42,
          "throwing": 59,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        458,
        404,
        543,
        534,
        606,
        925,
        259,
        838
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p066",
      "name": "Deren Kelwick",
      "birthDate": "2006-03-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 23,
          "power": 32,
          "rotation": 42,
          "vsPace": 30,
          "vsSpin": 27,
          "control": 54,
          "movement": 69,
          "variation": 67,
          "stamina": 70,
          "catching": 47,
          "groundFielding": 67,
          "throwing": 67,
          "keeping": 21
        },
        "ODI": {
          "defence": 22,
          "timing": 37,
          "power": 23,
          "rotation": 33,
          "vsPace": 21,
          "vsSpin": 51,
          "control": 55,
          "movement": 62,
          "variation": 53,
          "stamina": 52,
          "catching": 64,
          "groundFielding": 42,
          "throwing": 47,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 34,
          "timing": 40,
          "power": 38,
          "rotation": 27,
          "vsPace": 42,
          "vsSpin": 46,
          "control": 74,
          "movement": 78,
          "variation": 50,
          "stamina": 68,
          "catching": 65,
          "groundFielding": 56,
          "throwing": 41,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        974,
        595,
        981,
        599,
        699,
        634,
        494,
        745
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p067",
      "name": "Saren Elmstead",
      "birthDate": "1992-03-17",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 34,
          "timing": 41,
          "power": 41,
          "rotation": 46,
          "vsPace": 36,
          "vsSpin": 20,
          "control": 79,
          "movement": 61,
          "variation": 59,
          "stamina": 61,
          "catching": 63,
          "groundFielding": 55,
          "throwing": 66,
          "keeping": 29
        },
        "ODI": {
          "defence": 36,
          "timing": 21,
          "power": 35,
          "rotation": 49,
          "vsPace": 45,
          "vsSpin": 37,
          "control": 58,
          "movement": 69,
          "variation": 75,
          "stamina": 69,
          "catching": 67,
          "groundFielding": 41,
          "throwing": 46,
          "keeping": 41
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 39,
          "power": 35,
          "rotation": 29,
          "vsPace": 20,
          "vsSpin": 31,
          "control": 56,
          "movement": 68,
          "variation": 71,
          "stamina": 74,
          "catching": 53,
          "groundFielding": 55,
          "throwing": 46,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        406,
        721,
        505,
        304,
        766,
        827,
        835,
        643
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p068",
      "name": "Galen Pellthorne",
      "birthDate": "2002-05-01",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 22,
          "timing": 25,
          "power": 27,
          "rotation": 21,
          "vsPace": 19,
          "vsSpin": 26,
          "control": 71,
          "movement": 53,
          "variation": 69,
          "stamina": 59,
          "catching": 57,
          "groundFielding": 56,
          "throwing": 40,
          "keeping": 39
        },
        "ODI": {
          "defence": 41,
          "timing": 25,
          "power": 31,
          "rotation": 33,
          "vsPace": 38,
          "vsSpin": 48,
          "control": 74,
          "movement": 68,
          "variation": 79,
          "stamina": 75,
          "catching": 56,
          "groundFielding": 48,
          "throwing": 42,
          "keeping": 17
        },
        "RED_BALL": {
          "defence": 44,
          "timing": 25,
          "power": 46,
          "rotation": 29,
          "vsPace": 39,
          "vsSpin": 28,
          "control": 79,
          "movement": 56,
          "variation": 57,
          "stamina": 58,
          "catching": 64,
          "groundFielding": 61,
          "throwing": 59,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        983,
        685,
        772,
        337,
        674,
        819,
        297,
        499
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p069",
      "name": "Nerin Wrenstone",
      "birthDate": "2000-11-04",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 68,
          "power": 64,
          "rotation": 61,
          "vsPace": 38,
          "vsSpin": 50,
          "control": 37,
          "movement": 54,
          "variation": 38,
          "stamina": 46,
          "catching": 59,
          "groundFielding": 64,
          "throwing": 60,
          "keeping": 36
        },
        "ODI": {
          "defence": 56,
          "timing": 47,
          "power": 51,
          "rotation": 68,
          "vsPace": 65,
          "vsSpin": 40,
          "control": 67,
          "movement": 60,
          "variation": 60,
          "stamina": 65,
          "catching": 70,
          "groundFielding": 59,
          "throwing": 50,
          "keeping": 34
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 63,
          "power": 57,
          "rotation": 51,
          "vsPace": 55,
          "vsSpin": 43,
          "control": 64,
          "movement": 63,
          "variation": 62,
          "stamina": 63,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 52,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        311,
        258,
        414,
        904,
        662,
        231,
        496,
        665
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p070",
      "name": "Talor Pellfell",
      "birthDate": "1989-01-28",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 45,
          "timing": 59,
          "power": 47,
          "rotation": 60,
          "vsPace": 50,
          "vsSpin": 59,
          "control": 44,
          "movement": 62,
          "variation": 66,
          "stamina": 52,
          "catching": 69,
          "groundFielding": 43,
          "throwing": 61,
          "keeping": 16
        },
        "ODI": {
          "defence": 52,
          "timing": 68,
          "power": 47,
          "rotation": 39,
          "vsPace": 45,
          "vsSpin": 63,
          "control": 58,
          "movement": 53,
          "variation": 40,
          "stamina": 48,
          "catching": 70,
          "groundFielding": 54,
          "throwing": 53,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 73,
          "timing": 54,
          "power": 37,
          "rotation": 43,
          "vsPace": 52,
          "vsSpin": 59,
          "control": 37,
          "movement": 46,
          "variation": 47,
          "stamina": 42,
          "catching": 70,
          "groundFielding": 61,
          "throwing": 59,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        512,
        329,
        726,
        590,
        711,
        697,
        478,
        615
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p071",
      "name": "Ari Ashford",
      "birthDate": "1990-08-16",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 49,
          "power": 67,
          "rotation": 51,
          "vsPace": 62,
          "vsSpin": 61,
          "control": 37,
          "movement": 46,
          "variation": 48,
          "stamina": 58,
          "catching": 49,
          "groundFielding": 50,
          "throwing": 63,
          "keeping": 24
        },
        "ODI": {
          "defence": 56,
          "timing": 38,
          "power": 58,
          "rotation": 63,
          "vsPace": 47,
          "vsSpin": 58,
          "control": 49,
          "movement": 51,
          "variation": 67,
          "stamina": 48,
          "catching": 50,
          "groundFielding": 52,
          "throwing": 71,
          "keeping": 17
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 50,
          "power": 63,
          "rotation": 39,
          "vsPace": 63,
          "vsSpin": 58,
          "control": 60,
          "movement": 58,
          "variation": 43,
          "stamina": 46,
          "catching": 44,
          "groundFielding": 50,
          "throwing": 66,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        462,
        507,
        226,
        870,
        491,
        965,
        356,
        812
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p072",
      "name": "Caro Pellwick",
      "birthDate": "1997-11-21",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 64,
          "timing": 59,
          "power": 77,
          "rotation": 69,
          "vsPace": 60,
          "vsSpin": 55,
          "control": 44,
          "movement": 21,
          "variation": 30,
          "stamina": 28,
          "catching": 46,
          "groundFielding": 43,
          "throwing": 45,
          "keeping": 11
        },
        "ODI": {
          "defence": 68,
          "timing": 78,
          "power": 78,
          "rotation": 60,
          "vsPace": 69,
          "vsSpin": 54,
          "control": 40,
          "movement": 32,
          "variation": 24,
          "stamina": 20,
          "catching": 46,
          "groundFielding": 46,
          "throwing": 41,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 63,
          "power": 68,
          "rotation": 56,
          "vsPace": 63,
          "vsSpin": 74,
          "control": 25,
          "movement": 31,
          "variation": 41,
          "stamina": 19,
          "catching": 56,
          "groundFielding": 41,
          "throwing": 38,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        249,
        441,
        328,
        399,
        390,
        509,
        968,
        742
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p073",
      "name": "Galen Lornford",
      "birthDate": "2007-01-13",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 72,
          "timing": 56,
          "power": 71,
          "rotation": 73,
          "vsPace": 76,
          "vsSpin": 72,
          "control": 16,
          "movement": 25,
          "variation": 42,
          "stamina": 35,
          "catching": 39,
          "groundFielding": 38,
          "throwing": 52,
          "keeping": 37
        },
        "ODI": {
          "defence": 66,
          "timing": 53,
          "power": 67,
          "rotation": 55,
          "vsPace": 78,
          "vsSpin": 71,
          "control": 40,
          "movement": 30,
          "variation": 18,
          "stamina": 44,
          "catching": 43,
          "groundFielding": 43,
          "throwing": 61,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 65,
          "power": 76,
          "rotation": 52,
          "vsPace": 67,
          "vsSpin": 56,
          "control": 16,
          "movement": 38,
          "variation": 32,
          "stamina": 24,
          "catching": 37,
          "groundFielding": 66,
          "throwing": 48,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        284,
        506,
        652,
        805,
        305,
        993,
        333,
        368
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p074",
      "name": "Isen Sablefield",
      "birthDate": "1997-09-09",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 64,
          "power": 72,
          "rotation": 61,
          "vsPace": 72,
          "vsSpin": 60,
          "control": 21,
          "movement": 31,
          "variation": 39,
          "stamina": 33,
          "catching": 44,
          "groundFielding": 58,
          "throwing": 48,
          "keeping": 32
        },
        "ODI": {
          "defence": 51,
          "timing": 67,
          "power": 63,
          "rotation": 68,
          "vsPace": 69,
          "vsSpin": 52,
          "control": 42,
          "movement": 18,
          "variation": 17,
          "stamina": 22,
          "catching": 43,
          "groundFielding": 67,
          "throwing": 48,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 70,
          "power": 75,
          "rotation": 63,
          "vsPace": 56,
          "vsSpin": 50,
          "control": 19,
          "movement": 37,
          "variation": 24,
          "stamina": 43,
          "catching": 49,
          "groundFielding": 43,
          "throwing": 52,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        753,
        977,
        988,
        677,
        304,
        288,
        916,
        488
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p075",
      "name": "Yoran Pellbrook 15",
      "birthDate": "1994-11-24",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 73,
          "power": 59,
          "rotation": 57,
          "vsPace": 58,
          "vsSpin": 75,
          "control": 40,
          "movement": 17,
          "variation": 31,
          "stamina": 21,
          "catching": 50,
          "groundFielding": 62,
          "throwing": 57,
          "keeping": 20
        },
        "ODI": {
          "defence": 56,
          "timing": 70,
          "power": 68,
          "rotation": 61,
          "vsPace": 51,
          "vsSpin": 62,
          "control": 21,
          "movement": 19,
          "variation": 25,
          "stamina": 35,
          "catching": 40,
          "groundFielding": 45,
          "throwing": 53,
          "keeping": 41
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 50,
          "power": 70,
          "rotation": 70,
          "vsPace": 57,
          "vsSpin": 65,
          "control": 30,
          "movement": 16,
          "variation": 21,
          "stamina": 34,
          "catching": 67,
          "groundFielding": 65,
          "throwing": 39,
          "keeping": 16
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        220,
        817,
        910,
        584,
        429,
        541,
        263,
        319
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p076",
      "name": "Pavan Sableford",
      "birthDate": "1996-09-21",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 61,
          "power": 59,
          "rotation": 55,
          "vsPace": 64,
          "vsSpin": 64,
          "control": 33,
          "movement": 28,
          "variation": 42,
          "stamina": 14,
          "catching": 61,
          "groundFielding": 43,
          "throwing": 48,
          "keeping": 28
        },
        "ODI": {
          "defence": 69,
          "timing": 53,
          "power": 67,
          "rotation": 74,
          "vsPace": 54,
          "vsSpin": 54,
          "control": 38,
          "movement": 22,
          "variation": 27,
          "stamina": 20,
          "catching": 39,
          "groundFielding": 56,
          "throwing": 47,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 83,
          "timing": 52,
          "power": 60,
          "rotation": 51,
          "vsPace": 57,
          "vsSpin": 66,
          "control": 18,
          "movement": 39,
          "variation": 19,
          "stamina": 21,
          "catching": 49,
          "groundFielding": 67,
          "throwing": 53,
          "keeping": 30
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        474,
        282,
        203,
        857,
        595,
        507,
        245,
        548
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p077",
      "name": "Saren Briarstone",
      "birthDate": "2007-04-03",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 73,
          "power": 62,
          "rotation": 54,
          "vsPace": 71,
          "vsSpin": 69,
          "control": 32,
          "movement": 41,
          "variation": 42,
          "stamina": 32,
          "catching": 61,
          "groundFielding": 57,
          "throwing": 55,
          "keeping": 27
        },
        "ODI": {
          "defence": 60,
          "timing": 53,
          "power": 59,
          "rotation": 76,
          "vsPace": 80,
          "vsSpin": 74,
          "control": 44,
          "movement": 16,
          "variation": 43,
          "stamina": 24,
          "catching": 60,
          "groundFielding": 64,
          "throwing": 40,
          "keeping": 17
        },
        "RED_BALL": {
          "defence": 76,
          "timing": 72,
          "power": 51,
          "rotation": 52,
          "vsPace": 72,
          "vsSpin": 80,
          "control": 21,
          "movement": 36,
          "variation": 24,
          "stamina": 21,
          "catching": 67,
          "groundFielding": 46,
          "throwing": 45,
          "keeping": 13
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        966,
        686,
        370,
        626,
        443,
        253,
        963,
        426
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p078",
      "name": "Borin Kelholt",
      "birthDate": "1992-05-26",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 60,
          "timing": 63,
          "power": 54,
          "rotation": 75,
          "vsPace": 66,
          "vsSpin": 76,
          "control": 17,
          "movement": 19,
          "variation": 19,
          "stamina": 43,
          "catching": 63,
          "groundFielding": 53,
          "throwing": 42,
          "keeping": 14
        },
        "ODI": {
          "defence": 65,
          "timing": 69,
          "power": 69,
          "rotation": 71,
          "vsPace": 78,
          "vsSpin": 54,
          "control": 27,
          "movement": 39,
          "variation": 27,
          "stamina": 43,
          "catching": 39,
          "groundFielding": 45,
          "throwing": 46,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 59,
          "timing": 55,
          "power": 65,
          "rotation": 54,
          "vsPace": 52,
          "vsSpin": 66,
          "control": 17,
          "movement": 35,
          "variation": 27,
          "stamina": 22,
          "catching": 50,
          "groundFielding": 51,
          "throwing": 47,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        487,
        677,
        900,
        418,
        222,
        507,
        879,
        887
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p079",
      "name": "Rilan Iverbridge",
      "birthDate": "2007-05-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 58,
          "timing": 75,
          "power": 72,
          "rotation": 64,
          "vsPace": 59,
          "vsSpin": 60,
          "control": 41,
          "movement": 31,
          "variation": 31,
          "stamina": 33,
          "catching": 46,
          "groundFielding": 56,
          "throwing": 47,
          "keeping": 19
        },
        "ODI": {
          "defence": 70,
          "timing": 75,
          "power": 51,
          "rotation": 50,
          "vsPace": 57,
          "vsSpin": 75,
          "control": 39,
          "movement": 17,
          "variation": 28,
          "stamina": 32,
          "catching": 59,
          "groundFielding": 38,
          "throwing": 56,
          "keeping": 33
        },
        "RED_BALL": {
          "defence": 79,
          "timing": 57,
          "power": 54,
          "rotation": 63,
          "vsPace": 56,
          "vsSpin": 75,
          "control": 27,
          "movement": 43,
          "variation": 17,
          "stamina": 34,
          "catching": 49,
          "groundFielding": 48,
          "throwing": 45,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        608,
        223,
        973,
        216,
        304,
        949,
        257,
        544
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p080",
      "name": "Galen Ashcombe",
      "birthDate": "1991-09-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 70,
          "power": 77,
          "rotation": 80,
          "vsPace": 76,
          "vsSpin": 51,
          "control": 31,
          "movement": 27,
          "variation": 44,
          "stamina": 31,
          "catching": 59,
          "groundFielding": 52,
          "throwing": 44,
          "keeping": 39
        },
        "ODI": {
          "defence": 67,
          "timing": 55,
          "power": 75,
          "rotation": 64,
          "vsPace": 72,
          "vsSpin": 51,
          "control": 15,
          "movement": 16,
          "variation": 27,
          "stamina": 38,
          "catching": 59,
          "groundFielding": 63,
          "throwing": 38,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 69,
          "power": 57,
          "rotation": 80,
          "vsPace": 70,
          "vsSpin": 58,
          "control": 23,
          "movement": 38,
          "variation": 14,
          "stamina": 16,
          "catching": 41,
          "groundFielding": 46,
          "throwing": 37,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        252,
        830,
        574,
        985,
        267,
        995,
        394,
        371
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p081",
      "name": "Rilan Jorfield 1",
      "birthDate": "2005-10-18",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 48,
          "power": 59,
          "rotation": 38,
          "vsPace": 37,
          "vsSpin": 52,
          "control": 20,
          "movement": 12,
          "variation": 19,
          "stamina": 40,
          "catching": 61,
          "groundFielding": 43,
          "throwing": 50,
          "keeping": 62
        },
        "ODI": {
          "defence": 44,
          "timing": 43,
          "power": 37,
          "rotation": 36,
          "vsPace": 49,
          "vsSpin": 41,
          "control": 16,
          "movement": 42,
          "variation": 42,
          "stamina": 28,
          "catching": 70,
          "groundFielding": 57,
          "throwing": 59,
          "keeping": 62
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 63,
          "power": 32,
          "rotation": 39,
          "vsPace": 55,
          "vsSpin": 35,
          "control": 14,
          "movement": 19,
          "variation": 41,
          "stamina": 19,
          "catching": 61,
          "groundFielding": 58,
          "throwing": 46,
          "keeping": 67
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        693,
        966,
        272,
        820,
        972,
        832,
        990,
        890
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p082",
      "name": "Fenn Quenbridge",
      "birthDate": "1992-09-16",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 38,
          "timing": 39,
          "power": 51,
          "rotation": 60,
          "vsPace": 35,
          "vsSpin": 37,
          "control": 31,
          "movement": 15,
          "variation": 40,
          "stamina": 27,
          "catching": 66,
          "groundFielding": 56,
          "throwing": 69,
          "keeping": 63
        },
        "ODI": {
          "defence": 60,
          "timing": 58,
          "power": 39,
          "rotation": 62,
          "vsPace": 40,
          "vsSpin": 56,
          "control": 40,
          "movement": 42,
          "variation": 18,
          "stamina": 25,
          "catching": 51,
          "groundFielding": 57,
          "throwing": 52,
          "keeping": 76
        },
        "RED_BALL": {
          "defence": 59,
          "timing": 51,
          "power": 31,
          "rotation": 43,
          "vsPace": 39,
          "vsSpin": 43,
          "control": 18,
          "movement": 41,
          "variation": 20,
          "stamina": 31,
          "catching": 53,
          "groundFielding": 68,
          "throwing": 48,
          "keeping": 63
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        700,
        527,
        702,
        320,
        843,
        322,
        308,
        496
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p083",
      "name": "Belan Sablestone",
      "birthDate": "1993-01-10",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 23,
          "timing": 29,
          "power": 34,
          "rotation": 22,
          "vsPace": 30,
          "vsSpin": 24,
          "control": 67,
          "movement": 77,
          "variation": 56,
          "stamina": 67,
          "catching": 43,
          "groundFielding": 56,
          "throwing": 54,
          "keeping": 28
        },
        "ODI": {
          "defence": 28,
          "timing": 34,
          "power": 21,
          "rotation": 40,
          "vsPace": 39,
          "vsSpin": 22,
          "control": 62,
          "movement": 59,
          "variation": 78,
          "stamina": 75,
          "catching": 46,
          "groundFielding": 52,
          "throwing": 49,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 51,
          "timing": 30,
          "power": 40,
          "rotation": 46,
          "vsPace": 28,
          "vsSpin": 31,
          "control": 77,
          "movement": 74,
          "variation": 56,
          "stamina": 77,
          "catching": 46,
          "groundFielding": 50,
          "throwing": 55,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        636,
        699,
        683,
        546,
        932,
        404,
        687,
        325
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p084",
      "name": "Deren Falkholt",
      "birthDate": "2005-01-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 24,
          "timing": 26,
          "power": 40,
          "rotation": 41,
          "vsPace": 25,
          "vsSpin": 45,
          "control": 72,
          "movement": 62,
          "variation": 63,
          "stamina": 67,
          "catching": 69,
          "groundFielding": 66,
          "throwing": 66,
          "keeping": 39
        },
        "ODI": {
          "defence": 40,
          "timing": 41,
          "power": 30,
          "rotation": 31,
          "vsPace": 32,
          "vsSpin": 46,
          "control": 54,
          "movement": 62,
          "variation": 55,
          "stamina": 73,
          "catching": 67,
          "groundFielding": 54,
          "throwing": 39,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 33,
          "power": 29,
          "rotation": 45,
          "vsPace": 44,
          "vsSpin": 22,
          "control": 51,
          "movement": 64,
          "variation": 69,
          "stamina": 72,
          "catching": 57,
          "groundFielding": 49,
          "throwing": 65,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        366,
        275,
        515,
        637,
        604,
        429,
        381,
        650
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p085",
      "name": "Oren Elmwell",
      "birthDate": "2007-01-07",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 34,
          "timing": 41,
          "power": 36,
          "rotation": 37,
          "vsPace": 40,
          "vsSpin": 31,
          "control": 74,
          "movement": 71,
          "variation": 64,
          "stamina": 52,
          "catching": 68,
          "groundFielding": 46,
          "throwing": 46,
          "keeping": 37
        },
        "ODI": {
          "defence": 30,
          "timing": 49,
          "power": 39,
          "rotation": 22,
          "vsPace": 41,
          "vsSpin": 33,
          "control": 79,
          "movement": 59,
          "variation": 61,
          "stamina": 57,
          "catching": 50,
          "groundFielding": 67,
          "throwing": 47,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 28,
          "timing": 28,
          "power": 45,
          "rotation": 48,
          "vsPace": 34,
          "vsSpin": 31,
          "control": 58,
          "movement": 57,
          "variation": 67,
          "stamina": 77,
          "catching": 53,
          "groundFielding": 62,
          "throwing": 42,
          "keeping": 12
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        805,
        520,
        568,
        739,
        572,
        870,
        421,
        649
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p086",
      "name": "Nalo Zornfell",
      "birthDate": "2001-02-03",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 40,
          "timing": 47,
          "power": 53,
          "rotation": 28,
          "vsPace": 36,
          "vsSpin": 48,
          "control": 72,
          "movement": 68,
          "variation": 78,
          "stamina": 51,
          "catching": 45,
          "groundFielding": 50,
          "throwing": 51,
          "keeping": 22
        },
        "ODI": {
          "defence": 35,
          "timing": 45,
          "power": 49,
          "rotation": 20,
          "vsPace": 41,
          "vsSpin": 49,
          "control": 67,
          "movement": 79,
          "variation": 68,
          "stamina": 66,
          "catching": 61,
          "groundFielding": 66,
          "throwing": 60,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 23,
          "power": 43,
          "rotation": 47,
          "vsPace": 23,
          "vsSpin": 32,
          "control": 65,
          "movement": 63,
          "variation": 51,
          "stamina": 71,
          "catching": 62,
          "groundFielding": 65,
          "throwing": 46,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        367,
        952,
        234,
        774,
        996,
        934,
        265,
        805
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p087",
      "name": "Nalo Rookstead",
      "birthDate": "1991-09-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 32,
          "power": 43,
          "rotation": 39,
          "vsPace": 47,
          "vsSpin": 49,
          "control": 51,
          "movement": 64,
          "variation": 54,
          "stamina": 53,
          "catching": 67,
          "groundFielding": 41,
          "throwing": 51,
          "keeping": 32
        },
        "ODI": {
          "defence": 43,
          "timing": 46,
          "power": 23,
          "rotation": 35,
          "vsPace": 26,
          "vsSpin": 38,
          "control": 62,
          "movement": 54,
          "variation": 58,
          "stamina": 60,
          "catching": 58,
          "groundFielding": 39,
          "throwing": 39,
          "keeping": 19
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 30,
          "power": 45,
          "rotation": 21,
          "vsPace": 29,
          "vsSpin": 43,
          "control": 52,
          "movement": 74,
          "variation": 57,
          "stamina": 73,
          "catching": 50,
          "groundFielding": 42,
          "throwing": 63,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        781,
        457,
        433,
        387,
        473,
        645,
        245,
        716
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p088",
      "name": "Belan Briarstead",
      "birthDate": "1993-07-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 49,
          "timing": 35,
          "power": 49,
          "rotation": 35,
          "vsPace": 42,
          "vsSpin": 40,
          "control": 79,
          "movement": 56,
          "variation": 62,
          "stamina": 72,
          "catching": 53,
          "groundFielding": 60,
          "throwing": 58,
          "keeping": 29
        },
        "ODI": {
          "defence": 37,
          "timing": 33,
          "power": 26,
          "rotation": 47,
          "vsPace": 46,
          "vsSpin": 35,
          "control": 64,
          "movement": 52,
          "variation": 60,
          "stamina": 53,
          "catching": 51,
          "groundFielding": 46,
          "throwing": 48,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 33,
          "timing": 24,
          "power": 43,
          "rotation": 30,
          "vsPace": 38,
          "vsSpin": 37,
          "control": 55,
          "movement": 55,
          "variation": 65,
          "stamina": 56,
          "catching": 43,
          "groundFielding": 59,
          "throwing": 52,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        512,
        538,
        669,
        697,
        635,
        741,
        656,
        313
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p089",
      "name": "Ari Zornstead",
      "birthDate": "1997-09-12",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "FAST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 63,
          "power": 66,
          "rotation": 51,
          "vsPace": 54,
          "vsSpin": 50,
          "control": 46,
          "movement": 56,
          "variation": 65,
          "stamina": 55,
          "catching": 47,
          "groundFielding": 62,
          "throwing": 53,
          "keeping": 12
        },
        "ODI": {
          "defence": 41,
          "timing": 43,
          "power": 49,
          "rotation": 51,
          "vsPace": 63,
          "vsSpin": 63,
          "control": 41,
          "movement": 44,
          "variation": 39,
          "stamina": 66,
          "catching": 42,
          "groundFielding": 60,
          "throwing": 54,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 48,
          "timing": 68,
          "power": 64,
          "rotation": 41,
          "vsPace": 41,
          "vsSpin": 65,
          "control": 53,
          "movement": 58,
          "variation": 57,
          "stamina": 65,
          "catching": 56,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        992,
        249,
        689,
        675,
        942,
        205,
        830,
        984
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p090",
      "name": "Kaelen Quenthorne",
      "birthDate": "2007-06-24",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 59,
          "power": 69,
          "rotation": 55,
          "vsPace": 39,
          "vsSpin": 47,
          "control": 50,
          "movement": 57,
          "variation": 57,
          "stamina": 52,
          "catching": 60,
          "groundFielding": 57,
          "throwing": 72,
          "keeping": 11
        },
        "ODI": {
          "defence": 58,
          "timing": 40,
          "power": 59,
          "rotation": 55,
          "vsPace": 48,
          "vsSpin": 60,
          "control": 45,
          "movement": 52,
          "variation": 63,
          "stamina": 61,
          "catching": 52,
          "groundFielding": 61,
          "throwing": 62,
          "keeping": 34
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 54,
          "power": 39,
          "rotation": 57,
          "vsPace": 62,
          "vsSpin": 55,
          "control": 52,
          "movement": 48,
          "variation": 63,
          "stamina": 39,
          "catching": 43,
          "groundFielding": 55,
          "throwing": 66,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        762,
        675,
        915,
        758,
        723,
        372,
        280,
        570
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p091",
      "name": "Leron Ashcroft",
      "birthDate": "1999-04-20",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 38,
          "power": 49,
          "rotation": 66,
          "vsPace": 38,
          "vsSpin": 54,
          "control": 56,
          "movement": 55,
          "variation": 48,
          "stamina": 54,
          "catching": 59,
          "groundFielding": 42,
          "throwing": 42,
          "keeping": 25
        },
        "ODI": {
          "defence": 57,
          "timing": 48,
          "power": 51,
          "rotation": 53,
          "vsPace": 60,
          "vsSpin": 67,
          "control": 67,
          "movement": 39,
          "variation": 56,
          "stamina": 39,
          "catching": 54,
          "groundFielding": 64,
          "throwing": 48,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 57,
          "timing": 56,
          "power": 51,
          "rotation": 65,
          "vsPace": 39,
          "vsSpin": 58,
          "control": 60,
          "movement": 64,
          "variation": 48,
          "stamina": 38,
          "catching": 65,
          "groundFielding": 43,
          "throwing": 60,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        512,
        970,
        378,
        262,
        892,
        763,
        288,
        657
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p092",
      "name": "Kaelen Norden",
      "birthDate": "1990-06-06",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 63,
          "power": 72,
          "rotation": 63,
          "vsPace": 58,
          "vsSpin": 50,
          "control": 21,
          "movement": 18,
          "variation": 24,
          "stamina": 24,
          "catching": 43,
          "groundFielding": 60,
          "throwing": 55,
          "keeping": 25
        },
        "ODI": {
          "defence": 68,
          "timing": 71,
          "power": 77,
          "rotation": 79,
          "vsPace": 73,
          "vsSpin": 61,
          "control": 39,
          "movement": 23,
          "variation": 27,
          "stamina": 32,
          "catching": 50,
          "groundFielding": 67,
          "throwing": 56,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 84,
          "timing": 54,
          "power": 73,
          "rotation": 52,
          "vsPace": 80,
          "vsSpin": 60,
          "control": 37,
          "movement": 35,
          "variation": 42,
          "stamina": 41,
          "catching": 41,
          "groundFielding": 62,
          "throwing": 65,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        749,
        462,
        236,
        845,
        885,
        256,
        793,
        713
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p093",
      "name": "Eren Falkfield",
      "birthDate": "2003-04-11",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 80,
          "timing": 77,
          "power": 56,
          "rotation": 69,
          "vsPace": 67,
          "vsSpin": 78,
          "control": 40,
          "movement": 27,
          "variation": 36,
          "stamina": 22,
          "catching": 38,
          "groundFielding": 62,
          "throwing": 46,
          "keeping": 35
        },
        "ODI": {
          "defence": 74,
          "timing": 60,
          "power": 58,
          "rotation": 63,
          "vsPace": 59,
          "vsSpin": 57,
          "control": 14,
          "movement": 21,
          "variation": 31,
          "stamina": 24,
          "catching": 59,
          "groundFielding": 54,
          "throwing": 62,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 75,
          "power": 48,
          "rotation": 68,
          "vsPace": 78,
          "vsSpin": 57,
          "control": 33,
          "movement": 26,
          "variation": 20,
          "stamina": 21,
          "catching": 41,
          "groundFielding": 57,
          "throwing": 62,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        683,
        271,
        412,
        334,
        822,
        353,
        718,
        316
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p094",
      "name": "Galen Yewfell",
      "birthDate": "2007-01-25",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 61,
          "timing": 70,
          "power": 69,
          "rotation": 62,
          "vsPace": 57,
          "vsSpin": 65,
          "control": 27,
          "movement": 19,
          "variation": 44,
          "stamina": 30,
          "catching": 57,
          "groundFielding": 53,
          "throwing": 53,
          "keeping": 26
        },
        "ODI": {
          "defence": 80,
          "timing": 76,
          "power": 75,
          "rotation": 63,
          "vsPace": 67,
          "vsSpin": 71,
          "control": 35,
          "movement": 36,
          "variation": 21,
          "stamina": 34,
          "catching": 47,
          "groundFielding": 48,
          "throwing": 44,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 74,
          "power": 70,
          "rotation": 78,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 35,
          "movement": 32,
          "variation": 34,
          "stamina": 27,
          "catching": 57,
          "groundFielding": 65,
          "throwing": 54,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        818,
        846,
        709,
        603,
        275,
        679,
        496,
        911
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p095",
      "name": "Miran Mosscroft",
      "birthDate": "2005-11-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 57,
          "power": 82,
          "rotation": 64,
          "vsPace": 69,
          "vsSpin": 78,
          "control": 23,
          "movement": 29,
          "variation": 22,
          "stamina": 33,
          "catching": 61,
          "groundFielding": 48,
          "throwing": 56,
          "keeping": 29
        },
        "ODI": {
          "defence": 63,
          "timing": 79,
          "power": 68,
          "rotation": 56,
          "vsPace": 78,
          "vsSpin": 65,
          "control": 24,
          "movement": 22,
          "variation": 37,
          "stamina": 22,
          "catching": 42,
          "groundFielding": 57,
          "throwing": 53,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 58,
          "power": 72,
          "rotation": 53,
          "vsPace": 53,
          "vsSpin": 65,
          "control": 31,
          "movement": 23,
          "variation": 17,
          "stamina": 40,
          "catching": 39,
          "groundFielding": 51,
          "throwing": 38,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        876,
        822,
        379,
        875,
        305,
        352,
        616,
        890
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p096",
      "name": "Kaelen Pellcroft",
      "birthDate": "1998-05-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 68,
          "timing": 61,
          "power": 82,
          "rotation": 74,
          "vsPace": 73,
          "vsSpin": 59,
          "control": 24,
          "movement": 36,
          "variation": 35,
          "stamina": 28,
          "catching": 53,
          "groundFielding": 66,
          "throwing": 61,
          "keeping": 33
        },
        "ODI": {
          "defence": 56,
          "timing": 65,
          "power": 76,
          "rotation": 76,
          "vsPace": 51,
          "vsSpin": 55,
          "control": 16,
          "movement": 22,
          "variation": 33,
          "stamina": 36,
          "catching": 62,
          "groundFielding": 40,
          "throwing": 64,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 66,
          "timing": 58,
          "power": 63,
          "rotation": 68,
          "vsPace": 76,
          "vsSpin": 70,
          "control": 24,
          "movement": 28,
          "variation": 29,
          "stamina": 34,
          "catching": 49,
          "groundFielding": 58,
          "throwing": 67,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        690,
        360,
        957,
        592,
        239,
        721,
        208,
        431
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p097",
      "name": "Jora Orinstead",
      "birthDate": "2005-09-09",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 63,
          "timing": 64,
          "power": 77,
          "rotation": 55,
          "vsPace": 74,
          "vsSpin": 78,
          "control": 35,
          "movement": 21,
          "variation": 40,
          "stamina": 40,
          "catching": 60,
          "groundFielding": 66,
          "throwing": 55,
          "keeping": 38
        },
        "ODI": {
          "defence": 56,
          "timing": 57,
          "power": 53,
          "rotation": 73,
          "vsPace": 71,
          "vsSpin": 69,
          "control": 27,
          "movement": 18,
          "variation": 39,
          "stamina": 39,
          "catching": 55,
          "groundFielding": 56,
          "throwing": 42,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 60,
          "power": 73,
          "rotation": 52,
          "vsPace": 58,
          "vsSpin": 62,
          "control": 20,
          "movement": 36,
          "variation": 15,
          "stamina": 21,
          "catching": 44,
          "groundFielding": 41,
          "throwing": 65,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        213,
        408,
        467,
        537,
        464,
        282,
        634,
        886
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p098",
      "name": "Sela Iverwick",
      "birthDate": "1992-08-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 74,
          "power": 54,
          "rotation": 73,
          "vsPace": 68,
          "vsSpin": 77,
          "control": 14,
          "movement": 22,
          "variation": 44,
          "stamina": 26,
          "catching": 50,
          "groundFielding": 47,
          "throwing": 66,
          "keeping": 31
        },
        "ODI": {
          "defence": 63,
          "timing": 76,
          "power": 58,
          "rotation": 63,
          "vsPace": 53,
          "vsSpin": 52,
          "control": 35,
          "movement": 19,
          "variation": 16,
          "stamina": 17,
          "catching": 49,
          "groundFielding": 61,
          "throwing": 58,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 74,
          "timing": 68,
          "power": 48,
          "rotation": 79,
          "vsPace": 76,
          "vsSpin": 54,
          "control": 24,
          "movement": 44,
          "variation": 33,
          "stamina": 35,
          "catching": 47,
          "groundFielding": 40,
          "throwing": 58,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        773,
        492,
        637,
        590,
        524,
        460,
        823,
        857
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p099",
      "name": "Zerin Sablestone",
      "birthDate": "2007-08-17",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 63,
          "timing": 51,
          "power": 80,
          "rotation": 62,
          "vsPace": 66,
          "vsSpin": 76,
          "control": 25,
          "movement": 41,
          "variation": 43,
          "stamina": 30,
          "catching": 48,
          "groundFielding": 67,
          "throwing": 67,
          "keeping": 31
        },
        "ODI": {
          "defence": 63,
          "timing": 69,
          "power": 76,
          "rotation": 77,
          "vsPace": 59,
          "vsSpin": 69,
          "control": 15,
          "movement": 19,
          "variation": 20,
          "stamina": 28,
          "catching": 59,
          "groundFielding": 40,
          "throwing": 44,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 77,
          "power": 48,
          "rotation": 50,
          "vsPace": 67,
          "vsSpin": 75,
          "control": 37,
          "movement": 18,
          "variation": 40,
          "stamina": 27,
          "catching": 67,
          "groundFielding": 38,
          "throwing": 43,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        845,
        992,
        983,
        206,
        503,
        659,
        699,
        707
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p100",
      "name": "Fenn Terncombe",
      "birthDate": "2002-08-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 70,
          "timing": 63,
          "power": 80,
          "rotation": 72,
          "vsPace": 66,
          "vsSpin": 73,
          "control": 42,
          "movement": 28,
          "variation": 25,
          "stamina": 44,
          "catching": 64,
          "groundFielding": 57,
          "throwing": 39,
          "keeping": 21
        },
        "ODI": {
          "defence": 54,
          "timing": 77,
          "power": 80,
          "rotation": 58,
          "vsPace": 59,
          "vsSpin": 80,
          "control": 43,
          "movement": 19,
          "variation": 34,
          "stamina": 19,
          "catching": 59,
          "groundFielding": 53,
          "throwing": 37,
          "keeping": 27
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 70,
          "power": 67,
          "rotation": 53,
          "vsPace": 73,
          "vsSpin": 56,
          "control": 34,
          "movement": 36,
          "variation": 37,
          "stamina": 30,
          "catching": 41,
          "groundFielding": 59,
          "throwing": 53,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        710,
        482,
        639,
        749,
        530,
        928,
        474,
        647
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p101",
      "name": "Eren Briarridge",
      "birthDate": "2005-02-14",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 47,
          "power": 54,
          "rotation": 60,
          "vsPace": 49,
          "vsSpin": 45,
          "control": 30,
          "movement": 20,
          "variation": 18,
          "stamina": 21,
          "catching": 41,
          "groundFielding": 46,
          "throwing": 65,
          "keeping": 68
        },
        "ODI": {
          "defence": 51,
          "timing": 60,
          "power": 50,
          "rotation": 56,
          "vsPace": 50,
          "vsSpin": 35,
          "control": 32,
          "movement": 16,
          "variation": 33,
          "stamina": 26,
          "catching": 47,
          "groundFielding": 46,
          "throwing": 63,
          "keeping": 74
        },
        "RED_BALL": {
          "defence": 48,
          "timing": 36,
          "power": 49,
          "rotation": 51,
          "vsPace": 52,
          "vsSpin": 43,
          "control": 35,
          "movement": 19,
          "variation": 17,
          "stamina": 13,
          "catching": 49,
          "groundFielding": 63,
          "throwing": 48,
          "keeping": 69
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        238,
        504,
        324,
        935,
        256,
        871,
        597,
        419
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p102",
      "name": "Nerin Harridge",
      "birthDate": "2007-09-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 38,
          "power": 53,
          "rotation": 42,
          "vsPace": 48,
          "vsSpin": 51,
          "control": 13,
          "movement": 24,
          "variation": 31,
          "stamina": 39,
          "catching": 55,
          "groundFielding": 61,
          "throwing": 46,
          "keeping": 77
        },
        "ODI": {
          "defence": 50,
          "timing": 49,
          "power": 59,
          "rotation": 52,
          "vsPace": 39,
          "vsSpin": 60,
          "control": 19,
          "movement": 29,
          "variation": 28,
          "stamina": 14,
          "catching": 70,
          "groundFielding": 70,
          "throwing": 57,
          "keeping": 61
        },
        "RED_BALL": {
          "defence": 49,
          "timing": 49,
          "power": 37,
          "rotation": 54,
          "vsPace": 60,
          "vsSpin": 38,
          "control": 38,
          "movement": 42,
          "variation": 14,
          "stamina": 27,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 52,
          "keeping": 63
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        271,
        223,
        930,
        377,
        298,
        674,
        440,
        757
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p103",
      "name": "Galen Briarcombe",
      "birthDate": "2001-09-24",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 37,
          "timing": 23,
          "power": 44,
          "rotation": 33,
          "vsPace": 35,
          "vsSpin": 24,
          "control": 61,
          "movement": 56,
          "variation": 65,
          "stamina": 52,
          "catching": 69,
          "groundFielding": 58,
          "throwing": 61,
          "keeping": 34
        },
        "ODI": {
          "defence": 27,
          "timing": 48,
          "power": 22,
          "rotation": 22,
          "vsPace": 29,
          "vsSpin": 24,
          "control": 61,
          "movement": 61,
          "variation": 76,
          "stamina": 71,
          "catching": 56,
          "groundFielding": 59,
          "throwing": 49,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 39,
          "timing": 35,
          "power": 23,
          "rotation": 20,
          "vsPace": 26,
          "vsSpin": 30,
          "control": 77,
          "movement": 55,
          "variation": 72,
          "stamina": 58,
          "catching": 60,
          "groundFielding": 45,
          "throwing": 42,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        290,
        448,
        335,
        206,
        964,
        566,
        323,
        698
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p104",
      "name": "Arven Terncroft",
      "birthDate": "1992-09-04",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 37,
          "power": 25,
          "rotation": 22,
          "vsPace": 41,
          "vsSpin": 21,
          "control": 65,
          "movement": 78,
          "variation": 53,
          "stamina": 66,
          "catching": 58,
          "groundFielding": 50,
          "throwing": 40,
          "keeping": 40
        },
        "ODI": {
          "defence": 19,
          "timing": 25,
          "power": 40,
          "rotation": 25,
          "vsPace": 49,
          "vsSpin": 43,
          "control": 61,
          "movement": 67,
          "variation": 54,
          "stamina": 63,
          "catching": 44,
          "groundFielding": 63,
          "throwing": 57,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 49,
          "power": 28,
          "rotation": 22,
          "vsPace": 31,
          "vsSpin": 24,
          "control": 54,
          "movement": 53,
          "variation": 77,
          "stamina": 51,
          "catching": 68,
          "groundFielding": 45,
          "throwing": 66,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        633,
        226,
        543,
        739,
        927,
        325,
        434,
        642
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p105",
      "name": "Nerin Jorwick",
      "birthDate": "1994-10-17",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 22,
          "timing": 47,
          "power": 28,
          "rotation": 44,
          "vsPace": 37,
          "vsSpin": 37,
          "control": 69,
          "movement": 77,
          "variation": 61,
          "stamina": 56,
          "catching": 47,
          "groundFielding": 64,
          "throwing": 46,
          "keeping": 30
        },
        "ODI": {
          "defence": 43,
          "timing": 45,
          "power": 23,
          "rotation": 47,
          "vsPace": 43,
          "vsSpin": 47,
          "control": 76,
          "movement": 54,
          "variation": 55,
          "stamina": 69,
          "catching": 47,
          "groundFielding": 40,
          "throwing": 50,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 37,
          "timing": 30,
          "power": 27,
          "rotation": 25,
          "vsPace": 25,
          "vsSpin": 22,
          "control": 59,
          "movement": 69,
          "variation": 54,
          "stamina": 70,
          "catching": 63,
          "groundFielding": 61,
          "throwing": 61,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        633,
        714,
        491,
        836,
        838,
        601,
        767,
        692
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p106",
      "name": "Elio Rookmere",
      "birthDate": "1990-12-18",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 34,
          "timing": 25,
          "power": 45,
          "rotation": 24,
          "vsPace": 21,
          "vsSpin": 35,
          "control": 66,
          "movement": 56,
          "variation": 70,
          "stamina": 72,
          "catching": 47,
          "groundFielding": 52,
          "throwing": 64,
          "keeping": 40
        },
        "ODI": {
          "defence": 44,
          "timing": 42,
          "power": 37,
          "rotation": 26,
          "vsPace": 39,
          "vsSpin": 25,
          "control": 77,
          "movement": 70,
          "variation": 65,
          "stamina": 76,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 49,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 51,
          "timing": 33,
          "power": 38,
          "rotation": 47,
          "vsPace": 43,
          "vsSpin": 51,
          "control": 50,
          "movement": 61,
          "variation": 62,
          "stamina": 77,
          "catching": 57,
          "groundFielding": 65,
          "throwing": 45,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        245,
        755,
        575,
        424,
        755,
        839,
        280,
        259
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p107",
      "name": "Walen Glenmere",
      "birthDate": "1989-06-11",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 49,
          "timing": 42,
          "power": 31,
          "rotation": 46,
          "vsPace": 39,
          "vsSpin": 43,
          "control": 58,
          "movement": 63,
          "variation": 69,
          "stamina": 74,
          "catching": 57,
          "groundFielding": 42,
          "throwing": 41,
          "keeping": 23
        },
        "ODI": {
          "defence": 42,
          "timing": 22,
          "power": 33,
          "rotation": 28,
          "vsPace": 44,
          "vsSpin": 42,
          "control": 58,
          "movement": 58,
          "variation": 68,
          "stamina": 62,
          "catching": 65,
          "groundFielding": 49,
          "throwing": 47,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 48,
          "power": 17,
          "rotation": 30,
          "vsPace": 19,
          "vsSpin": 33,
          "control": 56,
          "movement": 52,
          "variation": 60,
          "stamina": 77,
          "catching": 58,
          "groundFielding": 68,
          "throwing": 50,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        620,
        798,
        355,
        506,
        651,
        582,
        438,
        323
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p108",
      "name": "Isen Jorden",
      "birthDate": "1996-07-11",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 48,
          "timing": 27,
          "power": 32,
          "rotation": 49,
          "vsPace": 26,
          "vsSpin": 32,
          "control": 50,
          "movement": 62,
          "variation": 54,
          "stamina": 62,
          "catching": 50,
          "groundFielding": 56,
          "throwing": 57,
          "keeping": 31
        },
        "ODI": {
          "defence": 45,
          "timing": 40,
          "power": 40,
          "rotation": 30,
          "vsPace": 42,
          "vsSpin": 21,
          "control": 65,
          "movement": 60,
          "variation": 60,
          "stamina": 62,
          "catching": 65,
          "groundFielding": 57,
          "throwing": 62,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 32,
          "timing": 37,
          "power": 46,
          "rotation": 30,
          "vsPace": 40,
          "vsSpin": 47,
          "control": 71,
          "movement": 60,
          "variation": 59,
          "stamina": 64,
          "catching": 54,
          "groundFielding": 62,
          "throwing": 46,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        709,
        759,
        438,
        577,
        847,
        335,
        228,
        860
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p109",
      "name": "Arven Lornford",
      "birthDate": "2005-12-03",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "MEDIUM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 68,
          "power": 54,
          "rotation": 43,
          "vsPace": 51,
          "vsSpin": 65,
          "control": 62,
          "movement": 55,
          "variation": 52,
          "stamina": 63,
          "catching": 46,
          "groundFielding": 61,
          "throwing": 66,
          "keeping": 31
        },
        "ODI": {
          "defence": 54,
          "timing": 63,
          "power": 40,
          "rotation": 45,
          "vsPace": 62,
          "vsSpin": 40,
          "control": 40,
          "movement": 39,
          "variation": 43,
          "stamina": 47,
          "catching": 47,
          "groundFielding": 51,
          "throwing": 50,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 69,
          "timing": 45,
          "power": 45,
          "rotation": 55,
          "vsPace": 39,
          "vsSpin": 48,
          "control": 53,
          "movement": 38,
          "variation": 59,
          "stamina": 59,
          "catching": 45,
          "groundFielding": 70,
          "throwing": 69,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        863,
        784,
        391,
        964,
        521,
        604,
        457,
        926
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p110",
      "name": "Arven Ternholt",
      "birthDate": "2005-01-17",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 68,
          "power": 67,
          "rotation": 57,
          "vsPace": 54,
          "vsSpin": 61,
          "control": 45,
          "movement": 41,
          "variation": 53,
          "stamina": 52,
          "catching": 71,
          "groundFielding": 66,
          "throwing": 44,
          "keeping": 32
        },
        "ODI": {
          "defence": 48,
          "timing": 45,
          "power": 41,
          "rotation": 56,
          "vsPace": 48,
          "vsSpin": 57,
          "control": 55,
          "movement": 64,
          "variation": 52,
          "stamina": 44,
          "catching": 65,
          "groundFielding": 69,
          "throwing": 44,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 41,
          "power": 59,
          "rotation": 38,
          "vsPace": 57,
          "vsSpin": 48,
          "control": 55,
          "movement": 52,
          "variation": 59,
          "stamina": 59,
          "catching": 65,
          "groundFielding": 72,
          "throwing": 56,
          "keeping": 18
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        420,
        938,
        616,
        266,
        696,
        540,
        594,
        757
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p111",
      "name": "Walen Wrenden",
      "birthDate": "1996-05-03",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 41,
          "timing": 41,
          "power": 53,
          "rotation": 68,
          "vsPace": 64,
          "vsSpin": 60,
          "control": 51,
          "movement": 64,
          "variation": 66,
          "stamina": 46,
          "catching": 42,
          "groundFielding": 46,
          "throwing": 52,
          "keeping": 15
        },
        "ODI": {
          "defence": 52,
          "timing": 61,
          "power": 53,
          "rotation": 60,
          "vsPace": 61,
          "vsSpin": 45,
          "control": 53,
          "movement": 52,
          "variation": 43,
          "stamina": 45,
          "catching": 72,
          "groundFielding": 57,
          "throwing": 53,
          "keeping": 39
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 59,
          "power": 44,
          "rotation": 49,
          "vsPace": 55,
          "vsSpin": 68,
          "control": 63,
          "movement": 45,
          "variation": 41,
          "stamina": 61,
          "catching": 42,
          "groundFielding": 47,
          "throwing": 46,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        933,
        816,
        732,
        351,
        375,
        655,
        289,
        495
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p112",
      "name": "Walen Mossstead",
      "birthDate": "2002-07-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 79,
          "timing": 70,
          "power": 68,
          "rotation": 66,
          "vsPace": 77,
          "vsSpin": 54,
          "control": 40,
          "movement": 16,
          "variation": 32,
          "stamina": 43,
          "catching": 44,
          "groundFielding": 61,
          "throwing": 50,
          "keeping": 28
        },
        "ODI": {
          "defence": 52,
          "timing": 79,
          "power": 55,
          "rotation": 78,
          "vsPace": 61,
          "vsSpin": 64,
          "control": 34,
          "movement": 38,
          "variation": 44,
          "stamina": 34,
          "catching": 39,
          "groundFielding": 47,
          "throwing": 56,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 71,
          "power": 77,
          "rotation": 71,
          "vsPace": 66,
          "vsSpin": 75,
          "control": 14,
          "movement": 28,
          "variation": 36,
          "stamina": 27,
          "catching": 39,
          "groundFielding": 50,
          "throwing": 57,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        836,
        815,
        207,
        925,
        531,
        827,
        438,
        278
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p113",
      "name": "Vero Yewfield",
      "birthDate": "2003-05-15",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 59,
          "power": 63,
          "rotation": 67,
          "vsPace": 72,
          "vsSpin": 72,
          "control": 32,
          "movement": 27,
          "variation": 33,
          "stamina": 14,
          "catching": 51,
          "groundFielding": 63,
          "throwing": 59,
          "keeping": 28
        },
        "ODI": {
          "defence": 55,
          "timing": 64,
          "power": 57,
          "rotation": 59,
          "vsPace": 68,
          "vsSpin": 65,
          "control": 41,
          "movement": 33,
          "variation": 26,
          "stamina": 33,
          "catching": 52,
          "groundFielding": 63,
          "throwing": 39,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 52,
          "power": 74,
          "rotation": 69,
          "vsPace": 79,
          "vsSpin": 75,
          "control": 44,
          "movement": 43,
          "variation": 26,
          "stamina": 32,
          "catching": 60,
          "groundFielding": 52,
          "throwing": 64,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        629,
        278,
        209,
        824,
        698,
        273,
        715,
        223
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p114",
      "name": "Miran Elmden",
      "birthDate": "1990-09-19",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 69,
          "timing": 64,
          "power": 77,
          "rotation": 66,
          "vsPace": 76,
          "vsSpin": 69,
          "control": 39,
          "movement": 18,
          "variation": 20,
          "stamina": 22,
          "catching": 49,
          "groundFielding": 57,
          "throwing": 52,
          "keeping": 27
        },
        "ODI": {
          "defence": 80,
          "timing": 65,
          "power": 60,
          "rotation": 77,
          "vsPace": 67,
          "vsSpin": 60,
          "control": 38,
          "movement": 19,
          "variation": 28,
          "stamina": 21,
          "catching": 65,
          "groundFielding": 38,
          "throwing": 48,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 67,
          "power": 63,
          "rotation": 75,
          "vsPace": 55,
          "vsSpin": 73,
          "control": 37,
          "movement": 23,
          "variation": 34,
          "stamina": 41,
          "catching": 65,
          "groundFielding": 64,
          "throwing": 50,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        864,
        450,
        886,
        902,
        237,
        488,
        472,
        992
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p115",
      "name": "Halen Briarfell",
      "birthDate": "2003-07-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 52,
          "timing": 50,
          "power": 60,
          "rotation": 70,
          "vsPace": 73,
          "vsSpin": 51,
          "control": 34,
          "movement": 35,
          "variation": 36,
          "stamina": 44,
          "catching": 66,
          "groundFielding": 51,
          "throwing": 42,
          "keeping": 35
        },
        "ODI": {
          "defence": 79,
          "timing": 61,
          "power": 77,
          "rotation": 59,
          "vsPace": 67,
          "vsSpin": 57,
          "control": 38,
          "movement": 15,
          "variation": 41,
          "stamina": 16,
          "catching": 65,
          "groundFielding": 60,
          "throwing": 46,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 75,
          "timing": 72,
          "power": 67,
          "rotation": 53,
          "vsPace": 61,
          "vsSpin": 67,
          "control": 32,
          "movement": 19,
          "variation": 24,
          "stamina": 26,
          "catching": 62,
          "groundFielding": 63,
          "throwing": 44,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        818,
        779,
        876,
        255,
        612,
        682,
        399,
        656
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p116",
      "name": "Arven Quenholt",
      "birthDate": "2001-11-17",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 78,
          "timing": 57,
          "power": 75,
          "rotation": 57,
          "vsPace": 78,
          "vsSpin": 50,
          "control": 32,
          "movement": 40,
          "variation": 18,
          "stamina": 41,
          "catching": 38,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 11
        },
        "ODI": {
          "defence": 80,
          "timing": 61,
          "power": 77,
          "rotation": 70,
          "vsPace": 63,
          "vsSpin": 58,
          "control": 17,
          "movement": 32,
          "variation": 15,
          "stamina": 43,
          "catching": 53,
          "groundFielding": 60,
          "throwing": 50,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 57,
          "power": 48,
          "rotation": 63,
          "vsPace": 65,
          "vsSpin": 56,
          "control": 39,
          "movement": 28,
          "variation": 14,
          "stamina": 44,
          "catching": 65,
          "groundFielding": 40,
          "throwing": 54,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        680,
        565,
        749,
        875,
        221,
        982,
        852,
        925
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p117",
      "name": "Elio Elmwick",
      "birthDate": "2007-03-25",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 76,
          "timing": 74,
          "power": 79,
          "rotation": 56,
          "vsPace": 64,
          "vsSpin": 52,
          "control": 36,
          "movement": 18,
          "variation": 32,
          "stamina": 37,
          "catching": 41,
          "groundFielding": 66,
          "throwing": 58,
          "keeping": 23
        },
        "ODI": {
          "defence": 63,
          "timing": 76,
          "power": 66,
          "rotation": 80,
          "vsPace": 74,
          "vsSpin": 65,
          "control": 27,
          "movement": 25,
          "variation": 27,
          "stamina": 30,
          "catching": 56,
          "groundFielding": 59,
          "throwing": 44,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 76,
          "timing": 53,
          "power": 74,
          "rotation": 78,
          "vsPace": 74,
          "vsSpin": 78,
          "control": 20,
          "movement": 25,
          "variation": 16,
          "stamina": 32,
          "catching": 38,
          "groundFielding": 51,
          "throwing": 66,
          "keeping": 31
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        786,
        207,
        474,
        679,
        262,
        934,
        781,
        450
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p118",
      "name": "Jora Wrenthorne",
      "birthDate": "2004-02-11",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 68,
          "timing": 76,
          "power": 60,
          "rotation": 71,
          "vsPace": 73,
          "vsSpin": 57,
          "control": 23,
          "movement": 24,
          "variation": 30,
          "stamina": 20,
          "catching": 41,
          "groundFielding": 63,
          "throwing": 43,
          "keeping": 23
        },
        "ODI": {
          "defence": 51,
          "timing": 71,
          "power": 77,
          "rotation": 67,
          "vsPace": 71,
          "vsSpin": 57,
          "control": 33,
          "movement": 44,
          "variation": 26,
          "stamina": 41,
          "catching": 42,
          "groundFielding": 60,
          "throwing": 60,
          "keeping": 39
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 59,
          "power": 70,
          "rotation": 78,
          "vsPace": 78,
          "vsSpin": 64,
          "control": 39,
          "movement": 35,
          "variation": 41,
          "stamina": 44,
          "catching": 63,
          "groundFielding": 44,
          "throwing": 63,
          "keeping": 16
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        256,
        689,
        269,
        609,
        376,
        223,
        732,
        367
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p119",
      "name": "Saren Zornbrook",
      "birthDate": "1994-11-27",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 77,
          "power": 57,
          "rotation": 71,
          "vsPace": 62,
          "vsSpin": 80,
          "control": 36,
          "movement": 23,
          "variation": 29,
          "stamina": 28,
          "catching": 39,
          "groundFielding": 65,
          "throwing": 54,
          "keeping": 32
        },
        "ODI": {
          "defence": 65,
          "timing": 75,
          "power": 69,
          "rotation": 56,
          "vsPace": 72,
          "vsSpin": 79,
          "control": 31,
          "movement": 16,
          "variation": 38,
          "stamina": 40,
          "catching": 49,
          "groundFielding": 52,
          "throwing": 45,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 66,
          "timing": 54,
          "power": 54,
          "rotation": 54,
          "vsPace": 56,
          "vsSpin": 71,
          "control": 23,
          "movement": 20,
          "variation": 41,
          "stamina": 43,
          "catching": 62,
          "groundFielding": 61,
          "throwing": 56,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        692,
        284,
        435,
        758,
        933,
        595,
        399,
        565
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p120",
      "name": "Kaelen Corcombe",
      "birthDate": "2007-09-27",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 52,
          "power": 80,
          "rotation": 53,
          "vsPace": 74,
          "vsSpin": 68,
          "control": 24,
          "movement": 15,
          "variation": 20,
          "stamina": 44,
          "catching": 50,
          "groundFielding": 65,
          "throwing": 65,
          "keeping": 35
        },
        "ODI": {
          "defence": 55,
          "timing": 57,
          "power": 62,
          "rotation": 63,
          "vsPace": 72,
          "vsSpin": 50,
          "control": 25,
          "movement": 36,
          "variation": 44,
          "stamina": 16,
          "catching": 66,
          "groundFielding": 66,
          "throwing": 58,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 84,
          "timing": 56,
          "power": 49,
          "rotation": 74,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 15,
          "movement": 35,
          "variation": 14,
          "stamina": 29,
          "catching": 59,
          "groundFielding": 58,
          "throwing": 37,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        289,
        410,
        376,
        829,
        514,
        297,
        236,
        244
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p121",
      "name": "Yoran Jorcroft",
      "birthDate": "1987-01-08",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 64,
          "timing": 53,
          "power": 56,
          "rotation": 36,
          "vsPace": 49,
          "vsSpin": 50,
          "control": 36,
          "movement": 32,
          "variation": 18,
          "stamina": 25,
          "catching": 52,
          "groundFielding": 45,
          "throwing": 61,
          "keeping": 83
        },
        "ODI": {
          "defence": 47,
          "timing": 43,
          "power": 35,
          "rotation": 47,
          "vsPace": 45,
          "vsSpin": 63,
          "control": 32,
          "movement": 16,
          "variation": 15,
          "stamina": 37,
          "catching": 41,
          "groundFielding": 68,
          "throwing": 59,
          "keeping": 61
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 44,
          "power": 38,
          "rotation": 59,
          "vsPace": 62,
          "vsSpin": 59,
          "control": 39,
          "movement": 28,
          "variation": 39,
          "stamina": 22,
          "catching": 67,
          "groundFielding": 45,
          "throwing": 71,
          "keeping": 82
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        638,
        501,
        1000,
        644,
        893,
        299,
        485,
        623
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p122",
      "name": "Nave Jorthorne",
      "birthDate": "2000-06-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 64,
          "power": 57,
          "rotation": 63,
          "vsPace": 48,
          "vsSpin": 40,
          "control": 18,
          "movement": 40,
          "variation": 18,
          "stamina": 32,
          "catching": 55,
          "groundFielding": 57,
          "throwing": 49,
          "keeping": 60
        },
        "ODI": {
          "defence": 52,
          "timing": 40,
          "power": 58,
          "rotation": 50,
          "vsPace": 43,
          "vsSpin": 46,
          "control": 37,
          "movement": 33,
          "variation": 19,
          "stamina": 15,
          "catching": 57,
          "groundFielding": 53,
          "throwing": 62,
          "keeping": 69
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 64,
          "power": 42,
          "rotation": 60,
          "vsPace": 64,
          "vsSpin": 41,
          "control": 31,
          "movement": 17,
          "variation": 14,
          "stamina": 24,
          "catching": 48,
          "groundFielding": 50,
          "throwing": 70,
          "keeping": 60
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        664,
        755,
        466,
        620,
        755,
        878,
        668,
        533
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p123",
      "name": "Caro Mossholt",
      "birthDate": "1990-11-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 37,
          "timing": 26,
          "power": 49,
          "rotation": 21,
          "vsPace": 25,
          "vsSpin": 34,
          "control": 61,
          "movement": 57,
          "variation": 69,
          "stamina": 66,
          "catching": 64,
          "groundFielding": 64,
          "throwing": 39,
          "keeping": 16
        },
        "ODI": {
          "defence": 21,
          "timing": 24,
          "power": 41,
          "rotation": 36,
          "vsPace": 38,
          "vsSpin": 35,
          "control": 77,
          "movement": 51,
          "variation": 65,
          "stamina": 64,
          "catching": 68,
          "groundFielding": 39,
          "throwing": 39,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 46,
          "timing": 44,
          "power": 37,
          "rotation": 49,
          "vsPace": 26,
          "vsSpin": 30,
          "control": 54,
          "movement": 77,
          "variation": 54,
          "stamina": 75,
          "catching": 46,
          "groundFielding": 41,
          "throwing": 48,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        769,
        727,
        297,
        726,
        387,
        726,
        891,
        218
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p124",
      "name": "Caro Sablefield",
      "birthDate": "2000-06-22",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 25,
          "timing": 36,
          "power": 41,
          "rotation": 37,
          "vsPace": 44,
          "vsSpin": 43,
          "control": 67,
          "movement": 58,
          "variation": 52,
          "stamina": 77,
          "catching": 39,
          "groundFielding": 46,
          "throwing": 54,
          "keeping": 30
        },
        "ODI": {
          "defence": 45,
          "timing": 31,
          "power": 40,
          "rotation": 20,
          "vsPace": 43,
          "vsSpin": 29,
          "control": 66,
          "movement": 54,
          "variation": 70,
          "stamina": 71,
          "catching": 67,
          "groundFielding": 44,
          "throwing": 66,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 37,
          "timing": 33,
          "power": 37,
          "rotation": 49,
          "vsPace": 49,
          "vsSpin": 38,
          "control": 56,
          "movement": 50,
          "variation": 56,
          "stamina": 66,
          "catching": 42,
          "groundFielding": 53,
          "throwing": 43,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        761,
        450,
        302,
        206,
        781,
        942,
        708,
        456
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p125",
      "name": "Nave Mossbridge",
      "birthDate": "1997-10-15",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 26,
          "timing": 29,
          "power": 41,
          "rotation": 19,
          "vsPace": 31,
          "vsSpin": 38,
          "control": 59,
          "movement": 57,
          "variation": 76,
          "stamina": 65,
          "catching": 54,
          "groundFielding": 41,
          "throwing": 55,
          "keeping": 32
        },
        "ODI": {
          "defence": 24,
          "timing": 25,
          "power": 37,
          "rotation": 39,
          "vsPace": 42,
          "vsSpin": 45,
          "control": 50,
          "movement": 57,
          "variation": 54,
          "stamina": 51,
          "catching": 67,
          "groundFielding": 66,
          "throwing": 48,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 30,
          "timing": 48,
          "power": 22,
          "rotation": 34,
          "vsPace": 24,
          "vsSpin": 47,
          "control": 77,
          "movement": 68,
          "variation": 76,
          "stamina": 64,
          "catching": 40,
          "groundFielding": 48,
          "throwing": 63,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        754,
        590,
        861,
        924,
        563,
        348,
        580,
        222
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p126",
      "name": "Leron Corwick",
      "birthDate": "1993-07-17",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 32,
          "power": 27,
          "rotation": 44,
          "vsPace": 44,
          "vsSpin": 51,
          "control": 60,
          "movement": 58,
          "variation": 72,
          "stamina": 54,
          "catching": 55,
          "groundFielding": 43,
          "throwing": 58,
          "keeping": 19
        },
        "ODI": {
          "defence": 43,
          "timing": 47,
          "power": 25,
          "rotation": 28,
          "vsPace": 26,
          "vsSpin": 47,
          "control": 68,
          "movement": 64,
          "variation": 79,
          "stamina": 53,
          "catching": 40,
          "groundFielding": 55,
          "throwing": 51,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 23,
          "power": 44,
          "rotation": 44,
          "vsPace": 27,
          "vsSpin": 39,
          "control": 62,
          "movement": 68,
          "variation": 65,
          "stamina": 65,
          "catching": 58,
          "groundFielding": 51,
          "throwing": 66,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        620,
        974,
        396,
        563,
        285,
        542,
        825,
        244
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p127",
      "name": "Tavin Lornbridge",
      "birthDate": "2007-10-03",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 21,
          "power": 47,
          "rotation": 32,
          "vsPace": 34,
          "vsSpin": 38,
          "control": 61,
          "movement": 53,
          "variation": 62,
          "stamina": 52,
          "catching": 66,
          "groundFielding": 45,
          "throwing": 64,
          "keeping": 25
        },
        "ODI": {
          "defence": 36,
          "timing": 28,
          "power": 44,
          "rotation": 38,
          "vsPace": 36,
          "vsSpin": 41,
          "control": 72,
          "movement": 72,
          "variation": 58,
          "stamina": 56,
          "catching": 63,
          "groundFielding": 69,
          "throwing": 68,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 32,
          "timing": 27,
          "power": 41,
          "rotation": 38,
          "vsPace": 31,
          "vsSpin": 19,
          "control": 69,
          "movement": 78,
          "variation": 77,
          "stamina": 68,
          "catching": 41,
          "groundFielding": 50,
          "throwing": 41,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        886,
        525,
        590,
        668,
        623,
        326,
        631,
        916
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p128",
      "name": "Saren Orinwick",
      "birthDate": "2000-02-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 23,
          "timing": 22,
          "power": 42,
          "rotation": 32,
          "vsPace": 24,
          "vsSpin": 43,
          "control": 55,
          "movement": 57,
          "variation": 55,
          "stamina": 75,
          "catching": 58,
          "groundFielding": 43,
          "throwing": 69,
          "keeping": 25
        },
        "ODI": {
          "defence": 20,
          "timing": 32,
          "power": 34,
          "rotation": 31,
          "vsPace": 39,
          "vsSpin": 34,
          "control": 62,
          "movement": 77,
          "variation": 56,
          "stamina": 77,
          "catching": 53,
          "groundFielding": 63,
          "throwing": 61,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 35,
          "timing": 20,
          "power": 25,
          "rotation": 44,
          "vsPace": 26,
          "vsSpin": 29,
          "control": 57,
          "movement": 67,
          "variation": 79,
          "stamina": 80,
          "catching": 48,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        872,
        778,
        656,
        586,
        911,
        353,
        420,
        823
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p129",
      "name": "Oren Norford",
      "birthDate": "1987-04-23",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 60,
          "power": 56,
          "rotation": 58,
          "vsPace": 55,
          "vsSpin": 46,
          "control": 47,
          "movement": 54,
          "variation": 46,
          "stamina": 63,
          "catching": 69,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 25
        },
        "ODI": {
          "defence": 65,
          "timing": 53,
          "power": 42,
          "rotation": 63,
          "vsPace": 38,
          "vsSpin": 67,
          "control": 55,
          "movement": 54,
          "variation": 53,
          "stamina": 39,
          "catching": 54,
          "groundFielding": 56,
          "throwing": 64,
          "keeping": 27
        },
        "RED_BALL": {
          "defence": 48,
          "timing": 45,
          "power": 54,
          "rotation": 54,
          "vsPace": 41,
          "vsSpin": 54,
          "control": 45,
          "movement": 45,
          "variation": 54,
          "stamina": 64,
          "catching": 52,
          "groundFielding": 55,
          "throwing": 42,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        669,
        720,
        482,
        852,
        422,
        390,
        982,
        367
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p130",
      "name": "Walen Jorbridge",
      "birthDate": "2000-05-06",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 47,
          "timing": 60,
          "power": 53,
          "rotation": 60,
          "vsPace": 52,
          "vsSpin": 61,
          "control": 55,
          "movement": 48,
          "variation": 43,
          "stamina": 42,
          "catching": 50,
          "groundFielding": 71,
          "throwing": 67,
          "keeping": 26
        },
        "ODI": {
          "defence": 48,
          "timing": 45,
          "power": 38,
          "rotation": 44,
          "vsPace": 53,
          "vsSpin": 54,
          "control": 46,
          "movement": 40,
          "variation": 57,
          "stamina": 45,
          "catching": 71,
          "groundFielding": 72,
          "throwing": 49,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 58,
          "power": 44,
          "rotation": 43,
          "vsPace": 65,
          "vsSpin": 55,
          "control": 62,
          "movement": 46,
          "variation": 57,
          "stamina": 37,
          "catching": 57,
          "groundFielding": 59,
          "throwing": 56,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        549,
        245,
        719,
        699,
        624,
        266,
        958,
        326
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p131",
      "name": "Quill Harcombe",
      "birthDate": "1987-01-22",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 63,
          "timing": 48,
          "power": 48,
          "rotation": 49,
          "vsPace": 63,
          "vsSpin": 39,
          "control": 59,
          "movement": 56,
          "variation": 38,
          "stamina": 65,
          "catching": 51,
          "groundFielding": 42,
          "throwing": 58,
          "keeping": 38
        },
        "ODI": {
          "defence": 44,
          "timing": 43,
          "power": 47,
          "rotation": 45,
          "vsPace": 47,
          "vsSpin": 49,
          "control": 40,
          "movement": 59,
          "variation": 39,
          "stamina": 42,
          "catching": 46,
          "groundFielding": 66,
          "throwing": 43,
          "keeping": 19
        },
        "RED_BALL": {
          "defence": 60,
          "timing": 66,
          "power": 61,
          "rotation": 67,
          "vsPace": 59,
          "vsSpin": 42,
          "control": 49,
          "movement": 47,
          "variation": 65,
          "stamina": 47,
          "catching": 57,
          "groundFielding": 61,
          "throwing": 46,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        599,
        839,
        878,
        997,
        263,
        270,
        289,
        426
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p132",
      "name": "Halen Quenstone",
      "birthDate": "2003-01-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 51,
          "power": 73,
          "rotation": 56,
          "vsPace": 76,
          "vsSpin": 63,
          "control": 30,
          "movement": 30,
          "variation": 38,
          "stamina": 36,
          "catching": 56,
          "groundFielding": 63,
          "throwing": 57,
          "keeping": 23
        },
        "ODI": {
          "defence": 51,
          "timing": 71,
          "power": 78,
          "rotation": 50,
          "vsPace": 59,
          "vsSpin": 67,
          "control": 15,
          "movement": 29,
          "variation": 44,
          "stamina": 15,
          "catching": 39,
          "groundFielding": 57,
          "throwing": 67,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 74,
          "timing": 67,
          "power": 52,
          "rotation": 67,
          "vsPace": 52,
          "vsSpin": 63,
          "control": 17,
          "movement": 23,
          "variation": 14,
          "stamina": 42,
          "catching": 64,
          "groundFielding": 40,
          "throwing": 58,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        325,
        666,
        348,
        648,
        538,
        960,
        677,
        963
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p133",
      "name": "Miran Falkridge",
      "birthDate": "2005-11-18",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 51,
          "timing": 54,
          "power": 63,
          "rotation": 66,
          "vsPace": 76,
          "vsSpin": 60,
          "control": 14,
          "movement": 24,
          "variation": 34,
          "stamina": 18,
          "catching": 55,
          "groundFielding": 59,
          "throwing": 53,
          "keeping": 19
        },
        "ODI": {
          "defence": 78,
          "timing": 54,
          "power": 66,
          "rotation": 63,
          "vsPace": 79,
          "vsSpin": 74,
          "control": 39,
          "movement": 15,
          "variation": 14,
          "stamina": 21,
          "catching": 65,
          "groundFielding": 50,
          "throwing": 51,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 58,
          "power": 70,
          "rotation": 50,
          "vsPace": 77,
          "vsSpin": 78,
          "control": 27,
          "movement": 24,
          "variation": 22,
          "stamina": 17,
          "catching": 44,
          "groundFielding": 50,
          "throwing": 47,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        551,
        297,
        340,
        522,
        690,
        919,
        670,
        493
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p134",
      "name": "Elio Dunfell",
      "birthDate": "1989-03-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 52,
          "timing": 77,
          "power": 77,
          "rotation": 56,
          "vsPace": 65,
          "vsSpin": 58,
          "control": 21,
          "movement": 26,
          "variation": 17,
          "stamina": 19,
          "catching": 67,
          "groundFielding": 58,
          "throwing": 48,
          "keeping": 11
        },
        "ODI": {
          "defence": 50,
          "timing": 58,
          "power": 76,
          "rotation": 69,
          "vsPace": 77,
          "vsSpin": 72,
          "control": 39,
          "movement": 33,
          "variation": 41,
          "stamina": 32,
          "catching": 57,
          "groundFielding": 50,
          "throwing": 63,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 66,
          "power": 57,
          "rotation": 72,
          "vsPace": 67,
          "vsSpin": 72,
          "control": 44,
          "movement": 40,
          "variation": 30,
          "stamina": 43,
          "catching": 48,
          "groundFielding": 61,
          "throwing": 60,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        978,
        452,
        353,
        480,
        940,
        708,
        433,
        349
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p135",
      "name": "Eren Quenstead",
      "birthDate": "2007-02-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 58,
          "power": 73,
          "rotation": 53,
          "vsPace": 71,
          "vsSpin": 75,
          "control": 34,
          "movement": 23,
          "variation": 44,
          "stamina": 25,
          "catching": 54,
          "groundFielding": 55,
          "throwing": 48,
          "keeping": 23
        },
        "ODI": {
          "defence": 54,
          "timing": 67,
          "power": 58,
          "rotation": 76,
          "vsPace": 61,
          "vsSpin": 56,
          "control": 27,
          "movement": 37,
          "variation": 26,
          "stamina": 42,
          "catching": 50,
          "groundFielding": 37,
          "throwing": 58,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 57,
          "timing": 65,
          "power": 51,
          "rotation": 73,
          "vsPace": 60,
          "vsSpin": 78,
          "control": 34,
          "movement": 23,
          "variation": 30,
          "stamina": 31,
          "catching": 43,
          "groundFielding": 60,
          "throwing": 39,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        658,
        275,
        311,
        699,
        207,
        341,
        556,
        672
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p136",
      "name": "Eren Rookmere",
      "birthDate": "1990-02-19",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 53,
          "power": 74,
          "rotation": 65,
          "vsPace": 70,
          "vsSpin": 63,
          "control": 37,
          "movement": 22,
          "variation": 30,
          "stamina": 27,
          "catching": 60,
          "groundFielding": 40,
          "throwing": 39,
          "keeping": 20
        },
        "ODI": {
          "defence": 57,
          "timing": 79,
          "power": 80,
          "rotation": 75,
          "vsPace": 73,
          "vsSpin": 73,
          "control": 25,
          "movement": 35,
          "variation": 16,
          "stamina": 42,
          "catching": 59,
          "groundFielding": 64,
          "throwing": 38,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 50,
          "power": 50,
          "rotation": 68,
          "vsPace": 72,
          "vsSpin": 58,
          "control": 16,
          "movement": 36,
          "variation": 24,
          "stamina": 44,
          "catching": 43,
          "groundFielding": 67,
          "throwing": 61,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        446,
        685,
        661,
        273,
        675,
        361,
        355,
        794
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p137",
      "name": "Elio Norbrook",
      "birthDate": "2004-01-14",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 53,
          "power": 80,
          "rotation": 52,
          "vsPace": 79,
          "vsSpin": 63,
          "control": 20,
          "movement": 33,
          "variation": 17,
          "stamina": 28,
          "catching": 64,
          "groundFielding": 65,
          "throwing": 43,
          "keeping": 35
        },
        "ODI": {
          "defence": 57,
          "timing": 54,
          "power": 68,
          "rotation": 58,
          "vsPace": 65,
          "vsSpin": 72,
          "control": 29,
          "movement": 26,
          "variation": 27,
          "stamina": 42,
          "catching": 56,
          "groundFielding": 40,
          "throwing": 38,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 64,
          "timing": 52,
          "power": 62,
          "rotation": 72,
          "vsPace": 56,
          "vsSpin": 79,
          "control": 27,
          "movement": 17,
          "variation": 38,
          "stamina": 22,
          "catching": 66,
          "groundFielding": 63,
          "throwing": 54,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        539,
        482,
        812,
        800,
        952,
        836,
        992,
        706
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p138",
      "name": "Belan Quencroft",
      "birthDate": "1998-04-18",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 61,
          "timing": 60,
          "power": 58,
          "rotation": 68,
          "vsPace": 73,
          "vsSpin": 57,
          "control": 35,
          "movement": 26,
          "variation": 21,
          "stamina": 20,
          "catching": 64,
          "groundFielding": 57,
          "throwing": 55,
          "keeping": 32
        },
        "ODI": {
          "defence": 65,
          "timing": 67,
          "power": 65,
          "rotation": 70,
          "vsPace": 71,
          "vsSpin": 78,
          "control": 32,
          "movement": 37,
          "variation": 30,
          "stamina": 26,
          "catching": 42,
          "groundFielding": 53,
          "throwing": 51,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 73,
          "timing": 61,
          "power": 72,
          "rotation": 52,
          "vsPace": 75,
          "vsSpin": 78,
          "control": 25,
          "movement": 35,
          "variation": 42,
          "stamina": 42,
          "catching": 47,
          "groundFielding": 48,
          "throwing": 50,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        673,
        756,
        695,
        641,
        702,
        640,
        408,
        285
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p139",
      "name": "Caro Sablefield 19",
      "birthDate": "2007-10-10",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 55,
          "timing": 74,
          "power": 65,
          "rotation": 53,
          "vsPace": 53,
          "vsSpin": 75,
          "control": 23,
          "movement": 31,
          "variation": 21,
          "stamina": 27,
          "catching": 54,
          "groundFielding": 53,
          "throwing": 43,
          "keeping": 12
        },
        "ODI": {
          "defence": 71,
          "timing": 74,
          "power": 56,
          "rotation": 66,
          "vsPace": 68,
          "vsSpin": 54,
          "control": 24,
          "movement": 31,
          "variation": 17,
          "stamina": 39,
          "catching": 56,
          "groundFielding": 48,
          "throwing": 49,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 57,
          "power": 47,
          "rotation": 71,
          "vsPace": 63,
          "vsSpin": 72,
          "control": 41,
          "movement": 15,
          "variation": 35,
          "stamina": 29,
          "catching": 49,
          "groundFielding": 49,
          "throwing": 55,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        941,
        779,
        733,
        649,
        702,
        652,
        544,
        240
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p140",
      "name": "Rilan Dunwick",
      "birthDate": "1995-01-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 63,
          "power": 74,
          "rotation": 76,
          "vsPace": 65,
          "vsSpin": 76,
          "control": 44,
          "movement": 42,
          "variation": 23,
          "stamina": 28,
          "catching": 52,
          "groundFielding": 51,
          "throwing": 51,
          "keeping": 21
        },
        "ODI": {
          "defence": 77,
          "timing": 69,
          "power": 54,
          "rotation": 71,
          "vsPace": 74,
          "vsSpin": 78,
          "control": 44,
          "movement": 22,
          "variation": 21,
          "stamina": 23,
          "catching": 44,
          "groundFielding": 67,
          "throwing": 38,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 58,
          "power": 56,
          "rotation": 59,
          "vsPace": 79,
          "vsSpin": 53,
          "control": 28,
          "movement": 24,
          "variation": 31,
          "stamina": 23,
          "catching": 52,
          "groundFielding": 49,
          "throwing": 56,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        529,
        773,
        309,
        938,
        794,
        980,
        712,
        855
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p141",
      "name": "Rilan Sablecroft",
      "birthDate": "2006-06-16",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 50,
          "power": 53,
          "rotation": 53,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 28,
          "movement": 20,
          "variation": 12,
          "stamina": 34,
          "catching": 48,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 56
        },
        "ODI": {
          "defence": 55,
          "timing": 46,
          "power": 53,
          "rotation": 53,
          "vsPace": 55,
          "vsSpin": 59,
          "control": 31,
          "movement": 41,
          "variation": 12,
          "stamina": 41,
          "catching": 71,
          "groundFielding": 70,
          "throwing": 67,
          "keeping": 72
        },
        "RED_BALL": {
          "defence": 69,
          "timing": 45,
          "power": 31,
          "rotation": 41,
          "vsPace": 43,
          "vsSpin": 51,
          "control": 21,
          "movement": 38,
          "variation": 36,
          "stamina": 19,
          "catching": 46,
          "groundFielding": 53,
          "throwing": 65,
          "keeping": 76
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        206,
        622,
        342,
        507,
        501,
        476,
        388,
        614
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p142",
      "name": "Pavan Jorstone",
      "birthDate": "1999-11-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 42,
          "power": 66,
          "rotation": 49,
          "vsPace": 53,
          "vsSpin": 41,
          "control": 36,
          "movement": 38,
          "variation": 37,
          "stamina": 41,
          "catching": 51,
          "groundFielding": 41,
          "throwing": 71,
          "keeping": 63
        },
        "ODI": {
          "defence": 51,
          "timing": 59,
          "power": 50,
          "rotation": 43,
          "vsPace": 50,
          "vsSpin": 53,
          "control": 27,
          "movement": 37,
          "variation": 18,
          "stamina": 36,
          "catching": 43,
          "groundFielding": 48,
          "throwing": 45,
          "keeping": 60
        },
        "RED_BALL": {
          "defence": 64,
          "timing": 51,
          "power": 39,
          "rotation": 38,
          "vsPace": 41,
          "vsSpin": 52,
          "control": 27,
          "movement": 26,
          "variation": 15,
          "stamina": 33,
          "catching": 42,
          "groundFielding": 56,
          "throwing": 43,
          "keeping": 75
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        526,
        434,
        275,
        985,
        273,
        445,
        577,
        521
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p143",
      "name": "Halen Orinmere",
      "birthDate": "1995-05-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 24,
          "timing": 22,
          "power": 43,
          "rotation": 30,
          "vsPace": 34,
          "vsSpin": 40,
          "control": 76,
          "movement": 52,
          "variation": 50,
          "stamina": 56,
          "catching": 47,
          "groundFielding": 62,
          "throwing": 67,
          "keeping": 30
        },
        "ODI": {
          "defence": 40,
          "timing": 23,
          "power": 28,
          "rotation": 25,
          "vsPace": 48,
          "vsSpin": 32,
          "control": 50,
          "movement": 55,
          "variation": 71,
          "stamina": 63,
          "catching": 67,
          "groundFielding": 69,
          "throwing": 55,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 35,
          "power": 31,
          "rotation": 19,
          "vsPace": 26,
          "vsSpin": 27,
          "control": 72,
          "movement": 61,
          "variation": 68,
          "stamina": 56,
          "catching": 56,
          "groundFielding": 64,
          "throwing": 50,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        895,
        882,
        998,
        602,
        488,
        751,
        508,
        379
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p144",
      "name": "Rilan Ternford",
      "birthDate": "1995-11-04",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 45,
          "power": 29,
          "rotation": 35,
          "vsPace": 48,
          "vsSpin": 47,
          "control": 58,
          "movement": 72,
          "variation": 58,
          "stamina": 53,
          "catching": 44,
          "groundFielding": 46,
          "throwing": 47,
          "keeping": 40
        },
        "ODI": {
          "defence": 23,
          "timing": 48,
          "power": 27,
          "rotation": 34,
          "vsPace": 47,
          "vsSpin": 37,
          "control": 69,
          "movement": 50,
          "variation": 60,
          "stamina": 51,
          "catching": 44,
          "groundFielding": 55,
          "throwing": 45,
          "keeping": 33
        },
        "RED_BALL": {
          "defence": 40,
          "timing": 27,
          "power": 29,
          "rotation": 32,
          "vsPace": 44,
          "vsSpin": 20,
          "control": 66,
          "movement": 66,
          "variation": 69,
          "stamina": 65,
          "catching": 61,
          "groundFielding": 64,
          "throwing": 47,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        397,
        792,
        913,
        206,
        591,
        888,
        479,
        844
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p145",
      "name": "Caro Jorwell",
      "birthDate": "2003-04-05",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 41,
          "power": 48,
          "rotation": 23,
          "vsPace": 30,
          "vsSpin": 27,
          "control": 71,
          "movement": 50,
          "variation": 61,
          "stamina": 79,
          "catching": 54,
          "groundFielding": 48,
          "throwing": 62,
          "keeping": 35
        },
        "ODI": {
          "defence": 24,
          "timing": 40,
          "power": 31,
          "rotation": 24,
          "vsPace": 45,
          "vsSpin": 41,
          "control": 62,
          "movement": 70,
          "variation": 75,
          "stamina": 75,
          "catching": 54,
          "groundFielding": 59,
          "throwing": 66,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 49,
          "power": 27,
          "rotation": 21,
          "vsPace": 23,
          "vsSpin": 26,
          "control": 66,
          "movement": 74,
          "variation": 56,
          "stamina": 61,
          "catching": 47,
          "groundFielding": 58,
          "throwing": 45,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        873,
        213,
        669,
        741,
        604,
        688,
        678,
        674
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p146",
      "name": "Nave Orincombe",
      "birthDate": "1992-10-23",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 39,
          "timing": 37,
          "power": 45,
          "rotation": 35,
          "vsPace": 30,
          "vsSpin": 30,
          "control": 70,
          "movement": 64,
          "variation": 54,
          "stamina": 54,
          "catching": 43,
          "groundFielding": 49,
          "throwing": 53,
          "keeping": 25
        },
        "ODI": {
          "defence": 45,
          "timing": 43,
          "power": 35,
          "rotation": 44,
          "vsPace": 39,
          "vsSpin": 49,
          "control": 58,
          "movement": 70,
          "variation": 70,
          "stamina": 67,
          "catching": 41,
          "groundFielding": 61,
          "throwing": 58,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 48,
          "power": 41,
          "rotation": 30,
          "vsPace": 19,
          "vsSpin": 22,
          "control": 71,
          "movement": 56,
          "variation": 77,
          "stamina": 72,
          "catching": 59,
          "groundFielding": 59,
          "throwing": 65,
          "keeping": 18
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        301,
        506,
        311,
        999,
        880,
        420,
        945,
        213
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p147",
      "name": "Elio Yewwell",
      "birthDate": "2001-11-22",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 31,
          "timing": 34,
          "power": 49,
          "rotation": 33,
          "vsPace": 30,
          "vsSpin": 37,
          "control": 55,
          "movement": 59,
          "variation": 71,
          "stamina": 76,
          "catching": 50,
          "groundFielding": 53,
          "throwing": 52,
          "keeping": 12
        },
        "ODI": {
          "defence": 47,
          "timing": 34,
          "power": 46,
          "rotation": 30,
          "vsPace": 22,
          "vsSpin": 34,
          "control": 75,
          "movement": 51,
          "variation": 53,
          "stamina": 60,
          "catching": 39,
          "groundFielding": 60,
          "throwing": 57,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 54,
          "timing": 26,
          "power": 29,
          "rotation": 30,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 62,
          "movement": 60,
          "variation": 52,
          "stamina": 69,
          "catching": 69,
          "groundFielding": 63,
          "throwing": 65,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        882,
        373,
        542,
        439,
        374,
        374,
        736,
        266
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p148",
      "name": "Deren Norwick",
      "birthDate": "1992-11-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 34,
          "power": 25,
          "rotation": 35,
          "vsPace": 39,
          "vsSpin": 25,
          "control": 79,
          "movement": 78,
          "variation": 53,
          "stamina": 70,
          "catching": 69,
          "groundFielding": 56,
          "throwing": 60,
          "keeping": 33
        },
        "ODI": {
          "defence": 37,
          "timing": 44,
          "power": 24,
          "rotation": 41,
          "vsPace": 38,
          "vsSpin": 21,
          "control": 50,
          "movement": 51,
          "variation": 55,
          "stamina": 67,
          "catching": 41,
          "groundFielding": 64,
          "throwing": 68,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 42,
          "timing": 45,
          "power": 26,
          "rotation": 30,
          "vsPace": 46,
          "vsSpin": 31,
          "control": 79,
          "movement": 76,
          "variation": 64,
          "stamina": 54,
          "catching": 51,
          "groundFielding": 66,
          "throwing": 53,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        200,
        823,
        328,
        585,
        951,
        503,
        696,
        715
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p149",
      "name": "Galen Zornwick",
      "birthDate": "1998-07-01",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 60,
          "timing": 57,
          "power": 70,
          "rotation": 64,
          "vsPace": 48,
          "vsSpin": 45,
          "control": 41,
          "movement": 60,
          "variation": 58,
          "stamina": 63,
          "catching": 55,
          "groundFielding": 72,
          "throwing": 48,
          "keeping": 36
        },
        "ODI": {
          "defence": 50,
          "timing": 55,
          "power": 39,
          "rotation": 48,
          "vsPace": 47,
          "vsSpin": 58,
          "control": 59,
          "movement": 46,
          "variation": 51,
          "stamina": 52,
          "catching": 51,
          "groundFielding": 43,
          "throwing": 47,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 68,
          "power": 56,
          "rotation": 57,
          "vsPace": 67,
          "vsSpin": 52,
          "control": 49,
          "movement": 64,
          "variation": 60,
          "stamina": 46,
          "catching": 59,
          "groundFielding": 56,
          "throwing": 49,
          "keeping": 30
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        450,
        480,
        658,
        273,
        913,
        577,
        543,
        670
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p150",
      "name": "Borin Jorfield",
      "birthDate": "2007-08-03",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 67,
          "power": 46,
          "rotation": 49,
          "vsPace": 41,
          "vsSpin": 61,
          "control": 65,
          "movement": 58,
          "variation": 42,
          "stamina": 40,
          "catching": 49,
          "groundFielding": 71,
          "throwing": 47,
          "keeping": 12
        },
        "ODI": {
          "defence": 58,
          "timing": 56,
          "power": 56,
          "rotation": 40,
          "vsPace": 61,
          "vsSpin": 51,
          "control": 49,
          "movement": 42,
          "variation": 38,
          "stamina": 57,
          "catching": 51,
          "groundFielding": 44,
          "throwing": 66,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 67,
          "power": 42,
          "rotation": 42,
          "vsPace": 66,
          "vsSpin": 51,
          "control": 58,
          "movement": 45,
          "variation": 56,
          "stamina": 40,
          "catching": 68,
          "groundFielding": 55,
          "throwing": 42,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        501,
        429,
        592,
        335,
        549,
        786,
        997,
        258
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p151",
      "name": "Zerin Harridge",
      "birthDate": "2000-05-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 41,
          "timing": 53,
          "power": 50,
          "rotation": 43,
          "vsPace": 53,
          "vsSpin": 56,
          "control": 64,
          "movement": 51,
          "variation": 53,
          "stamina": 50,
          "catching": 68,
          "groundFielding": 59,
          "throwing": 67,
          "keeping": 13
        },
        "ODI": {
          "defence": 41,
          "timing": 67,
          "power": 38,
          "rotation": 38,
          "vsPace": 40,
          "vsSpin": 56,
          "control": 47,
          "movement": 65,
          "variation": 54,
          "stamina": 39,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 66,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 50,
          "timing": 44,
          "power": 55,
          "rotation": 57,
          "vsPace": 38,
          "vsSpin": 57,
          "control": 47,
          "movement": 59,
          "variation": 51,
          "stamina": 61,
          "catching": 47,
          "groundFielding": 45,
          "throwing": 49,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        584,
        570,
        841,
        998,
        767,
        814,
        270,
        238
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p152",
      "name": "Oren Lornmere",
      "birthDate": "2004-05-27",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 69,
          "power": 75,
          "rotation": 52,
          "vsPace": 71,
          "vsSpin": 67,
          "control": 27,
          "movement": 32,
          "variation": 35,
          "stamina": 44,
          "catching": 52,
          "groundFielding": 44,
          "throwing": 55,
          "keeping": 27
        },
        "ODI": {
          "defence": 50,
          "timing": 61,
          "power": 74,
          "rotation": 50,
          "vsPace": 65,
          "vsSpin": 54,
          "control": 24,
          "movement": 24,
          "variation": 22,
          "stamina": 17,
          "catching": 46,
          "groundFielding": 47,
          "throwing": 67,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 53,
          "power": 70,
          "rotation": 64,
          "vsPace": 62,
          "vsSpin": 56,
          "control": 28,
          "movement": 42,
          "variation": 15,
          "stamina": 25,
          "catching": 47,
          "groundFielding": 37,
          "throwing": 52,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        539,
        300,
        203,
        819,
        329,
        944,
        559,
        506
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p153",
      "name": "Oren Kelwell",
      "birthDate": "1991-11-14",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 79,
          "timing": 55,
          "power": 61,
          "rotation": 68,
          "vsPace": 64,
          "vsSpin": 57,
          "control": 27,
          "movement": 24,
          "variation": 36,
          "stamina": 17,
          "catching": 58,
          "groundFielding": 54,
          "throwing": 50,
          "keeping": 11
        },
        "ODI": {
          "defence": 60,
          "timing": 61,
          "power": 69,
          "rotation": 65,
          "vsPace": 79,
          "vsSpin": 59,
          "control": 22,
          "movement": 16,
          "variation": 23,
          "stamina": 17,
          "catching": 58,
          "groundFielding": 49,
          "throwing": 62,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 54,
          "power": 56,
          "rotation": 78,
          "vsPace": 70,
          "vsSpin": 68,
          "control": 43,
          "movement": 16,
          "variation": 37,
          "stamina": 38,
          "catching": 51,
          "groundFielding": 49,
          "throwing": 51,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        821,
        868,
        333,
        281,
        290,
        743,
        728,
        855
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p154",
      "name": "Nerin Ashwell",
      "birthDate": "1995-08-15",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 76,
          "timing": 72,
          "power": 72,
          "rotation": 73,
          "vsPace": 79,
          "vsSpin": 51,
          "control": 41,
          "movement": 38,
          "variation": 25,
          "stamina": 23,
          "catching": 43,
          "groundFielding": 62,
          "throwing": 57,
          "keeping": 22
        },
        "ODI": {
          "defence": 65,
          "timing": 78,
          "power": 65,
          "rotation": 69,
          "vsPace": 61,
          "vsSpin": 67,
          "control": 21,
          "movement": 18,
          "variation": 40,
          "stamina": 24,
          "catching": 51,
          "groundFielding": 67,
          "throwing": 56,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 65,
          "power": 55,
          "rotation": 74,
          "vsPace": 50,
          "vsSpin": 73,
          "control": 19,
          "movement": 33,
          "variation": 37,
          "stamina": 25,
          "catching": 48,
          "groundFielding": 55,
          "throwing": 61,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        721,
        440,
        724,
        668,
        257,
        352,
        452,
        353
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p155",
      "name": "Eren Orinthorne",
      "birthDate": "1996-03-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 77,
          "power": 58,
          "rotation": 69,
          "vsPace": 71,
          "vsSpin": 63,
          "control": 24,
          "movement": 42,
          "variation": 17,
          "stamina": 28,
          "catching": 56,
          "groundFielding": 51,
          "throwing": 64,
          "keeping": 12
        },
        "ODI": {
          "defence": 66,
          "timing": 52,
          "power": 64,
          "rotation": 62,
          "vsPace": 50,
          "vsSpin": 78,
          "control": 23,
          "movement": 27,
          "variation": 15,
          "stamina": 18,
          "catching": 38,
          "groundFielding": 49,
          "throwing": 58,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 78,
          "power": 63,
          "rotation": 53,
          "vsPace": 62,
          "vsSpin": 54,
          "control": 25,
          "movement": 19,
          "variation": 36,
          "stamina": 17,
          "catching": 42,
          "groundFielding": 63,
          "throwing": 65,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        358,
        605,
        607,
        969,
        946,
        475,
        718,
        325
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p156",
      "name": "Miran Quenfell",
      "birthDate": "1989-02-22",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 66,
          "power": 77,
          "rotation": 63,
          "vsPace": 55,
          "vsSpin": 51,
          "control": 24,
          "movement": 30,
          "variation": 41,
          "stamina": 34,
          "catching": 39,
          "groundFielding": 45,
          "throwing": 65,
          "keeping": 35
        },
        "ODI": {
          "defence": 64,
          "timing": 54,
          "power": 54,
          "rotation": 62,
          "vsPace": 57,
          "vsSpin": 63,
          "control": 18,
          "movement": 31,
          "variation": 22,
          "stamina": 30,
          "catching": 48,
          "groundFielding": 64,
          "throwing": 58,
          "keeping": 30
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 59,
          "power": 47,
          "rotation": 79,
          "vsPace": 77,
          "vsSpin": 61,
          "control": 25,
          "movement": 20,
          "variation": 42,
          "stamina": 33,
          "catching": 46,
          "groundFielding": 55,
          "throwing": 54,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        754,
        345,
        805,
        911,
        635,
        821,
        904,
        868
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p157",
      "name": "Vero Norfield",
      "birthDate": "1997-02-07",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 61,
          "timing": 62,
          "power": 70,
          "rotation": 70,
          "vsPace": 58,
          "vsSpin": 55,
          "control": 32,
          "movement": 20,
          "variation": 19,
          "stamina": 14,
          "catching": 38,
          "groundFielding": 49,
          "throwing": 55,
          "keeping": 19
        },
        "ODI": {
          "defence": 50,
          "timing": 71,
          "power": 60,
          "rotation": 59,
          "vsPace": 71,
          "vsSpin": 60,
          "control": 34,
          "movement": 22,
          "variation": 31,
          "stamina": 42,
          "catching": 66,
          "groundFielding": 60,
          "throwing": 66,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 79,
          "timing": 63,
          "power": 63,
          "rotation": 75,
          "vsPace": 76,
          "vsSpin": 55,
          "control": 30,
          "movement": 36,
          "variation": 40,
          "stamina": 34,
          "catching": 41,
          "groundFielding": 43,
          "throwing": 50,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        243,
        968,
        635,
        930,
        759,
        338,
        318,
        426
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p158",
      "name": "Walen Norbridge",
      "birthDate": "1998-10-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 66,
          "power": 84,
          "rotation": 68,
          "vsPace": 80,
          "vsSpin": 66,
          "control": 27,
          "movement": 36,
          "variation": 18,
          "stamina": 23,
          "catching": 52,
          "groundFielding": 65,
          "throwing": 54,
          "keeping": 19
        },
        "ODI": {
          "defence": 60,
          "timing": 67,
          "power": 62,
          "rotation": 71,
          "vsPace": 75,
          "vsSpin": 57,
          "control": 31,
          "movement": 33,
          "variation": 27,
          "stamina": 33,
          "catching": 43,
          "groundFielding": 64,
          "throwing": 45,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 79,
          "power": 64,
          "rotation": 52,
          "vsPace": 79,
          "vsSpin": 75,
          "control": 40,
          "movement": 34,
          "variation": 36,
          "stamina": 42,
          "catching": 56,
          "groundFielding": 40,
          "throwing": 54,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        404,
        994,
        500,
        710,
        410,
        410,
        893,
        935
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p159",
      "name": "Nerin Yewfield",
      "birthDate": "1993-12-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 80,
          "power": 81,
          "rotation": 65,
          "vsPace": 65,
          "vsSpin": 69,
          "control": 44,
          "movement": 15,
          "variation": 39,
          "stamina": 16,
          "catching": 67,
          "groundFielding": 49,
          "throwing": 46,
          "keeping": 41
        },
        "ODI": {
          "defence": 68,
          "timing": 59,
          "power": 52,
          "rotation": 57,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 42,
          "movement": 33,
          "variation": 42,
          "stamina": 29,
          "catching": 64,
          "groundFielding": 57,
          "throwing": 45,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 58,
          "power": 73,
          "rotation": 80,
          "vsPace": 64,
          "vsSpin": 53,
          "control": 39,
          "movement": 23,
          "variation": 26,
          "stamina": 40,
          "catching": 56,
          "groundFielding": 50,
          "throwing": 60,
          "keeping": 12
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        403,
        914,
        988,
        266,
        785,
        607,
        522,
        395
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p160",
      "name": "Rilan Yewbridge",
      "birthDate": "1998-02-04",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 52,
          "power": 69,
          "rotation": 57,
          "vsPace": 53,
          "vsSpin": 70,
          "control": 33,
          "movement": 44,
          "variation": 41,
          "stamina": 18,
          "catching": 67,
          "groundFielding": 59,
          "throwing": 57,
          "keeping": 29
        },
        "ODI": {
          "defence": 52,
          "timing": 80,
          "power": 76,
          "rotation": 77,
          "vsPace": 58,
          "vsSpin": 59,
          "control": 39,
          "movement": 42,
          "variation": 38,
          "stamina": 27,
          "catching": 52,
          "groundFielding": 66,
          "throwing": 50,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 75,
          "power": 60,
          "rotation": 54,
          "vsPace": 70,
          "vsSpin": 63,
          "control": 18,
          "movement": 31,
          "variation": 42,
          "stamina": 43,
          "catching": 40,
          "groundFielding": 41,
          "throwing": 61,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        651,
        392,
        434,
        495,
        242,
        984,
        898,
        624
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    }
  ],
  "teams": [
    {
      "teamId": "team-01",
      "name": "Aster Harbour",
      "squadIds": [
        "p001",
        "p002",
        "p003",
        "p004",
        "p005",
        "p006",
        "p007",
        "p008",
        "p009",
        "p010",
        "p011",
        "p012",
        "p013",
        "p014",
        "p015",
        "p016",
        "p017",
        "p018",
        "p019",
        "p020"
      ],
      "colours": [
        "#254B69",
        "#E6C97D"
      ]
    },
    {
      "teamId": "team-02",
      "name": "Copper Vale",
      "squadIds": [
        "p021",
        "p022",
        "p023",
        "p024",
        "p025",
        "p026",
        "p027",
        "p028",
        "p029",
        "p030",
        "p031",
        "p032",
        "p033",
        "p034",
        "p035",
        "p036",
        "p037",
        "p038",
        "p039",
        "p040"
      ],
      "colours": [
        "#9B4A32",
        "#EEE5D1"
      ]
    },
    {
      "teamId": "team-03",
      "name": "Northlight Ridge",
      "squadIds": [
        "p041",
        "p042",
        "p043",
        "p044",
        "p045",
        "p046",
        "p047",
        "p048",
        "p049",
        "p050",
        "p051",
        "p052",
        "p053",
        "p054",
        "p055",
        "p056",
        "p057",
        "p058",
        "p059",
        "p060"
      ],
      "colours": [
        "#254A3D",
        "#D1DBDC"
      ]
    },
    {
      "teamId": "team-04",
      "name": "Westmere Isles",
      "squadIds": [
        "p061",
        "p062",
        "p063",
        "p064",
        "p065",
        "p066",
        "p067",
        "p068",
        "p069",
        "p070",
        "p071",
        "p072",
        "p073",
        "p074",
        "p075",
        "p076",
        "p077",
        "p078",
        "p079",
        "p080"
      ],
      "colours": [
        "#433E79",
        "#E7CBE5"
      ]
    },
    {
      "teamId": "team-05",
      "name": "Ember Plains",
      "squadIds": [
        "p081",
        "p082",
        "p083",
        "p084",
        "p085",
        "p086",
        "p087",
        "p088",
        "p089",
        "p090",
        "p091",
        "p092",
        "p093",
        "p094",
        "p095",
        "p096",
        "p097",
        "p098",
        "p099",
        "p100"
      ],
      "colours": [
        "#A43D38",
        "#27282E"
      ]
    },
    {
      "teamId": "team-06",
      "name": "Silver Fen",
      "squadIds": [
        "p101",
        "p102",
        "p103",
        "p104",
        "p105",
        "p106",
        "p107",
        "p108",
        "p109",
        "p110",
        "p111",
        "p112",
        "p113",
        "p114",
        "p115",
        "p116",
        "p117",
        "p118",
        "p119",
        "p120"
      ],
      "colours": [
        "#5F7480",
        "#F3E6CA"
      ]
    },
    {
      "teamId": "team-07",
      "name": "Larchwood",
      "squadIds": [
        "p121",
        "p122",
        "p123",
        "p124",
        "p125",
        "p126",
        "p127",
        "p128",
        "p129",
        "p130",
        "p131",
        "p132",
        "p133",
        "p134",
        "p135",
        "p136",
        "p137",
        "p138",
        "p139",
        "p140"
      ],
      "colours": [
        "#395431",
        "#F3B76D"
      ]
    },
    {
      "teamId": "team-08",
      "name": "Moonstone Bay",
      "squadIds": [
        "p141",
        "p142",
        "p143",
        "p144",
        "p145",
        "p146",
        "p147",
        "p148",
        "p149",
        "p150",
        "p151",
        "p152",
        "p153",
        "p154",
        "p155",
        "p156",
        "p157",
        "p158",
        "p159",
        "p160"
      ],
      "colours": [
        "#2A5B69",
        "#D9DDEA"
      ]
    }
  ],
  "grounds": [
    {
      "groundId": "ground-01",
      "name": "Aster Quay",
      "pitchPrior": {
        "seamBp": 6177,
        "turnBp": 6532,
        "variabilityBp": 4835,
        "moistureBp": 5963,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        8098,
        7182,
        7420,
        8266,
        7479,
        7978,
        8045,
        6931
      ],
      "outfieldSpeedBp": 5243
    },
    {
      "groundId": "ground-02",
      "name": "Copperfield",
      "pitchPrior": {
        "seamBp": 3946,
        "turnBp": 5277,
        "variabilityBp": 3840,
        "moistureBp": 4647,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7475,
        8038,
        7893,
        7532,
        7948,
        7349,
        7019,
        7213
      ],
      "outfieldSpeedBp": 4077
    },
    {
      "groundId": "ground-03",
      "name": "Northlight Park",
      "pitchPrior": {
        "seamBp": 5887,
        "turnBp": 6027,
        "variabilityBp": 5931,
        "moistureBp": 5222,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7204,
        7872,
        7641,
        8200,
        7538,
        8077,
        7936,
        6875
      ],
      "outfieldSpeedBp": 4303
    },
    {
      "groundId": "ground-04",
      "name": "Westmere Oval",
      "pitchPrior": {
        "seamBp": 4070,
        "turnBp": 4899,
        "variabilityBp": 6441,
        "moistureBp": 4496,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7587,
        7191,
        8208,
        6975,
        8011,
        6864,
        8345,
        7383
      ],
      "outfieldSpeedBp": 4457
    },
    {
      "groundId": "ground-05",
      "name": "Ember Meadow",
      "pitchPrior": {
        "seamBp": 6866,
        "turnBp": 6651,
        "variabilityBp": 5198,
        "moistureBp": 5995,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7972,
        6928,
        7231,
        7988,
        7989,
        8065,
        7220,
        6729
      ],
      "outfieldSpeedBp": 4302
    },
    {
      "groundId": "ground-06",
      "name": "Silverfen",
      "pitchPrior": {
        "seamBp": 7299,
        "turnBp": 3602,
        "variabilityBp": 6252,
        "moistureBp": 4016,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        8174,
        7699,
        7499,
        7502,
        7661,
        8045,
        8337,
        7332
      ],
      "outfieldSpeedBp": 5892
    },
    {
      "groundId": "ground-07",
      "name": "Larchwood Ground",
      "pitchPrior": {
        "seamBp": 4864,
        "turnBp": 6232,
        "variabilityBp": 6003,
        "moistureBp": 4907,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7244,
        7584,
        7976,
        7439,
        8089,
        8236,
        7218,
        7782
      ],
      "outfieldSpeedBp": 4289
    },
    {
      "groundId": "ground-08",
      "name": "Moonstone Fields",
      "pitchPrior": {
        "seamBp": 4567,
        "turnBp": 4791,
        "variabilityBp": 3999,
        "moistureBp": 4992,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        8089,
        6702,
        7226,
        7499,
        8292,
        7176,
        6829,
        7070
      ],
      "outfieldSpeedBp": 5114
    }
  ],
  "rulesIds": [
    "LC_T20_01",
    "LC_ODI_01",
    "LC_RED5_01"
  ],
  "provenance": "FICTIONAL: One-time offline SHA256_COUNTER_V1 WORLD_GENERATION seed; provisional SYNTHETIC_ALPHA skills, not empirical cricket."
}
`,Rt={worldPackId:"fictional-eight-01",schemaVersion:"1.0.0",worldGeneratorVersion:"LC_FICTIONAL_WORLD_GENERATOR_V1",worldSeed:"lcxxvi-fictional-eight-v1-20260927",generatorSourceSha256:"a3aaa4b64926ad9859f84222eb51274e7881df750308c2e9ae8fd1fa66e2f4da",provenanceSourceSha256:"97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",worldFileSha256:"0136173903ba42a199c84a17407cf711c2caf1b57c52472abb52e9be7a6d8257",worldCanonicalSha256:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",worldByteLength:310033,rulesIds:["LC_T20_01","LC_ODI_01","LC_RED5_01"],modelId:"synthetic-alpha-01",modelHash:"d47d5caca955b7a374b0052d712b1674bca6d855e222194ce9f0587d8580b7ab",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:"34efa3037702e44a134ea38b414eab3e97c6f79f10b3e5458bc2ab05412e5d7a",randomId:"SHA256_COUNTER_V1",variationIds:["stock"],provenance:"FICTIONAL",modelStatus:"SYNTHETIC_ALPHA",teamIds:["team-01","team-02","team-03","team-04","team-05","team-06","team-07","team-08"],groundIds:["ground-01","ground-02","ground-03","ground-04","ground-05","ground-06","ground-07","ground-08"],homeGroundIds:{"team-01":"ground-01","team-02":"ground-02","team-03":"ground-03","team-04":"ground-04","team-05":"ground-05","team-06":"ground-06","team-07":"ground-07","team-08":"ground-08"}};function V(n,e,t){function a(s,c){var u;Object.defineProperty(s,"_zod",{value:s._zod??{},enumerable:!1}),(u=s._zod).traits??(u.traits=new Set),s._zod.traits.add(n),e(s,c);for(const h in r.prototype)h in s||Object.defineProperty(s,h,{value:r.prototype[h].bind(s)});s._zod.constr=r,s._zod.def=c}const o=t?.Parent??Object;class i extends o{}Object.defineProperty(i,"name",{value:n});function r(s){var c;const u=t?.Parent?new i:this;a(u,s),(c=u._zod).deferred??(c.deferred=[]);for(const h of u._zod.deferred)h();return u}return Object.defineProperty(r,"init",{value:a}),Object.defineProperty(r,Symbol.hasInstance,{value:s=>t?.Parent&&s instanceof t.Parent?!0:s?._zod?.traits?.has(n)}),Object.defineProperty(r,"name",{value:n}),r}class ga extends Error{constructor(){super("Encountered Promise during synchronous parse. Use .parseAsync() instead.")}}class cc extends Error{constructor(e){super(`Encountered unidirectional transform during encode: ${e}`),this.name="ZodEncodeError"}}const Ki={};function It(n){return n&&Object.assign(Ki,n),Ki}function Gm(n){const e=Object.values(n).filter(a=>typeof a=="number");return Object.entries(n).filter(([a,o])=>e.indexOf(+a)===-1).map(([a,o])=>o)}function qi(n,e){return typeof e=="bigint"?e.toString():e}function No(n){return{get value(){{const e=n();return Object.defineProperty(this,"value",{value:e}),e}}}}function Zi(n){return n==null}function Xi(n){const e=n.startsWith("^")?1:0,t=n.endsWith("$")?n.length-1:n.length;return n.slice(e,t)}function jm(n,e){const t=(n.toString().split(".")[1]||"").length,a=e.toString();let o=(a.split(".")[1]||"").length;if(o===0&&/\d?e-\d?/.test(a)){const c=a.match(/\d?e-(\d?)/);c?.[1]&&(o=Number.parseInt(c[1]))}const i=t>o?t:o,r=Number.parseInt(n.toFixed(i).replace(".","")),s=Number.parseInt(e.toFixed(i).replace(".",""));return r%s/10**i}const lc=Symbol("evaluating");function vn(n,e,t){let a;Object.defineProperty(n,e,{get(){if(a!==lc)return a===void 0&&(a=lc,a=t()),a},set(o){Object.defineProperty(n,e,{value:o})},configurable:!0})}function Zt(n,e,t){Object.defineProperty(n,e,{value:t,writable:!0,enumerable:!0,configurable:!0})}function Xt(...n){const e={};for(const t of n){const a=Object.getOwnPropertyDescriptors(t);Object.assign(e,a)}return Object.defineProperties({},e)}function dc(n){return JSON.stringify(n)}const uc="captureStackTrace"in Error?Error.captureStackTrace:(...n)=>{};function za(n){return typeof n=="object"&&n!==null&&!Array.isArray(n)}const Ym=No(()=>{if(typeof navigator<"u"&&navigator?.userAgent?.includes("Cloudflare"))return!1;try{const n=Function;return new n(""),!0}catch{return!1}});function Ia(n){if(za(n)===!1)return!1;const e=n.constructor;if(e===void 0)return!0;const t=e.prototype;return!(za(t)===!1||Object.prototype.hasOwnProperty.call(t,"isPrototypeOf")===!1)}function mc(n){return Ia(n)?{...n}:Array.isArray(n)?[...n]:n}const zm=new Set(["string","number","symbol"]);function pa(n){return n.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function vt(n,e,t){const a=new n._zod.constr(e??n._zod.def);return(!e||t?.parent)&&(a._zod.parent=n),a}function sn(n){const e=n;if(!e)return{};if(typeof e=="string")return{error:()=>e};if(e?.message!==void 0){if(e?.error!==void 0)throw new Error("Cannot specify both `message` and `error` params");e.error=e.message}return delete e.message,typeof e.error=="string"?{...e,error:()=>e.error}:e}function Km(n){return Object.keys(n).filter(e=>n[e]._zod.optin==="optional"&&n[e]._zod.optout==="optional")}const qm={safeint:[Number.MIN_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],int32:[-2147483648,2147483647],uint32:[0,4294967295],float32:[-34028234663852886e22,34028234663852886e22],float64:[-Number.MAX_VALUE,Number.MAX_VALUE]};function Zm(n,e){const t=n._zod.def,a=Xt(n._zod.def,{get shape(){const o={};for(const i in e){if(!(i in t.shape))throw new Error(`Unrecognized key: "${i}"`);e[i]&&(o[i]=t.shape[i])}return Zt(this,"shape",o),o},checks:[]});return vt(n,a)}function Xm(n,e){const t=n._zod.def,a=Xt(n._zod.def,{get shape(){const o={...n._zod.def.shape};for(const i in e){if(!(i in t.shape))throw new Error(`Unrecognized key: "${i}"`);e[i]&&delete o[i]}return Zt(this,"shape",o),o},checks:[]});return vt(n,a)}function Jm(n,e){if(!Ia(e))throw new Error("Invalid input to extend: expected a plain object");const t=n._zod.def.checks;if(t&&t.length>0)throw new Error("Object schemas containing refinements cannot be extended. Use `.safeExtend()` instead.");const o=Xt(n._zod.def,{get shape(){const i={...n._zod.def.shape,...e};return Zt(this,"shape",i),i},checks:[]});return vt(n,o)}function Qm(n,e){if(!Ia(e))throw new Error("Invalid input to safeExtend: expected a plain object");const t={...n._zod.def,get shape(){const a={...n._zod.def.shape,...e};return Zt(this,"shape",a),a},checks:n._zod.def.checks};return vt(n,t)}function ng(n,e){const t=Xt(n._zod.def,{get shape(){const a={...n._zod.def.shape,...e._zod.def.shape};return Zt(this,"shape",a),a},get catchall(){return e._zod.def.catchall},checks:[]});return vt(n,t)}function eg(n,e,t){const a=Xt(e._zod.def,{get shape(){const o=e._zod.def.shape,i={...o};if(t)for(const r in t){if(!(r in o))throw new Error(`Unrecognized key: "${r}"`);t[r]&&(i[r]=n?new n({type:"optional",innerType:o[r]}):o[r])}else for(const r in o)i[r]=n?new n({type:"optional",innerType:o[r]}):o[r];return Zt(this,"shape",i),i},checks:[]});return vt(e,a)}function tg(n,e,t){const a=Xt(e._zod.def,{get shape(){const o=e._zod.def.shape,i={...o};if(t)for(const r in t){if(!(r in i))throw new Error(`Unrecognized key: "${r}"`);t[r]&&(i[r]=new n({type:"nonoptional",innerType:o[r]}))}else for(const r in o)i[r]=new n({type:"nonoptional",innerType:o[r]});return Zt(this,"shape",i),i},checks:[]});return vt(e,a)}function ha(n,e=0){if(n.aborted===!0)return!0;for(let t=e;t<n.issues.length;t++)if(n.issues[t]?.continue!==!0)return!0;return!1}function Jt(n,e){return e.map(t=>{var a;return(a=t).path??(a.path=[]),t.path.unshift(n),t})}function yo(n){return typeof n=="string"?n:n?.message}function At(n,e,t){const a={...n,path:n.path??[]};if(!n.message){const o=yo(n.inst?._zod.def?.error?.(n))??yo(e?.error?.(n))??yo(t.customError?.(n))??yo(t.localeError?.(n))??"Invalid input";a.message=o}return delete a.inst,delete a.continue,e?.reportInput||delete a.input,a}function Ji(n){return Array.isArray(n)?"array":typeof n=="string"?"string":"unknown"}function Ka(...n){const[e,t,a]=n;return typeof e=="string"?{message:e,code:"custom",input:t,inst:a}:{...e}}const gc=(n,e)=>{n.name="$ZodError",Object.defineProperty(n,"_zod",{value:n._zod,enumerable:!1}),Object.defineProperty(n,"issues",{value:e,enumerable:!1}),n.message=JSON.stringify(e,qi,2),Object.defineProperty(n,"toString",{value:()=>n.message,enumerable:!1})},Ic=V("$ZodError",gc),pc=V("$ZodError",gc,{Parent:Error});function ag(n,e=t=>t.message){const t={},a=[];for(const o of n.issues)o.path.length>0?(t[o.path[0]]=t[o.path[0]]||[],t[o.path[0]].push(e(o))):a.push(e(o));return{formErrors:a,fieldErrors:t}}function og(n,e=t=>t.message){const t={_errors:[]},a=o=>{for(const i of o.issues)if(i.code==="invalid_union"&&i.errors.length)i.errors.map(r=>a({issues:r}));else if(i.code==="invalid_key")a({issues:i.issues});else if(i.code==="invalid_element")a({issues:i.issues});else if(i.path.length===0)t._errors.push(e(i));else{let r=t,s=0;for(;s<i.path.length;){const c=i.path[s];s===i.path.length-1?(r[c]=r[c]||{_errors:[]},r[c]._errors.push(e(i))):r[c]=r[c]||{_errors:[]},r=r[c],s++}}};return a(n),t}const Qi=n=>(e,t,a,o)=>{const i=a?Object.assign(a,{async:!1}):{async:!1},r=e._zod.run({value:t,issues:[]},i);if(r instanceof Promise)throw new ga;if(r.issues.length){const s=new(o?.Err??n)(r.issues.map(c=>At(c,i,It())));throw uc(s,o?.callee),s}return r.value},nr=n=>async(e,t,a,o)=>{const i=a?Object.assign(a,{async:!0}):{async:!0};let r=e._zod.run({value:t,issues:[]},i);if(r instanceof Promise&&(r=await r),r.issues.length){const s=new(o?.Err??n)(r.issues.map(c=>At(c,i,It())));throw uc(s,o?.callee),s}return r.value},Do=n=>(e,t,a)=>{const o=a?{...a,async:!1}:{async:!1},i=e._zod.run({value:t,issues:[]},o);if(i instanceof Promise)throw new ga;return i.issues.length?{success:!1,error:new(n??Ic)(i.issues.map(r=>At(r,o,It())))}:{success:!0,data:i.value}},ig=Do(pc),Co=n=>async(e,t,a)=>{const o=a?Object.assign(a,{async:!0}):{async:!0};let i=e._zod.run({value:t,issues:[]},o);return i instanceof Promise&&(i=await i),i.issues.length?{success:!1,error:new n(i.issues.map(r=>At(r,o,It())))}:{success:!0,data:i.value}},rg=Co(pc),sg=n=>(e,t,a)=>{const o=a?Object.assign(a,{direction:"backward"}):{direction:"backward"};return Qi(n)(e,t,o)},cg=n=>(e,t,a)=>Qi(n)(e,t,a),lg=n=>async(e,t,a)=>{const o=a?Object.assign(a,{direction:"backward"}):{direction:"backward"};return nr(n)(e,t,o)},dg=n=>async(e,t,a)=>nr(n)(e,t,a),ug=n=>(e,t,a)=>{const o=a?Object.assign(a,{direction:"backward"}):{direction:"backward"};return Do(n)(e,t,o)},mg=n=>(e,t,a)=>Do(n)(e,t,a),gg=n=>async(e,t,a)=>{const o=a?Object.assign(a,{direction:"backward"}):{direction:"backward"};return Co(n)(e,t,o)},Ig=n=>async(e,t,a)=>Co(n)(e,t,a),pg=/^[cC][^\s-]{8,}$/,hg=/^[0-9a-z]+$/,fg=/^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/,Eg=/^[0-9a-vA-V]{20}$/,Sg=/^[A-Za-z0-9]{27}$/,_g=/^[a-zA-Z0-9_-]{21}$/,Tg=/^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/,Rg=/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/,hc=n=>n?new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${n}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`):/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/,vg=/^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/,Ag="^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";function bg(){return new RegExp(Ag,"u")}const wg=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,Og=/^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/,Lg=/^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/,Ng=/^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,yg=/^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/,fc=/^[A-Za-z0-9_-]*$/,Dg=/^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/,Cg=/^\+(?:[0-9]){6,14}[0-9]$/,Ec="(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))",kg=new RegExp(`^${Ec}$`);function Sc(n){const e="(?:[01]\\d|2[0-3]):[0-5]\\d";return typeof n.precision=="number"?n.precision===-1?`${e}`:n.precision===0?`${e}:[0-5]\\d`:`${e}:[0-5]\\d\\.\\d{${n.precision}}`:`${e}(?::[0-5]\\d(?:\\.\\d+)?)?`}function Bg(n){return new RegExp(`^${Sc(n)}$`)}function Pg(n){const e=Sc({precision:n.precision}),t=["Z"];n.local&&t.push(""),n.offset&&t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");const a=`${e}(?:${t.join("|")})`;return new RegExp(`^${Ec}T(?:${a})$`)}const xg=n=>{const e=n?`[\\s\\S]{${n?.minimum??0},${n?.maximum??""}}`:"[\\s\\S]*";return new RegExp(`^${e}$`)},Hg=/^-?\d+$/,Fg=/^-?\d+(?:\.\d+)?/,Mg=/^(?:true|false)$/i,Vg=/^null$/i,Wg=/^[^A-Z]*$/,Ug=/^[^a-z]*$/,Oe=V("$ZodCheck",(n,e)=>{var t;n._zod??(n._zod={}),n._zod.def=e,(t=n._zod).onattach??(t.onattach=[])}),_c={number:"number",bigint:"bigint",object:"date"},Tc=V("$ZodCheckLessThan",(n,e)=>{Oe.init(n,e);const t=_c[typeof e.value];n._zod.onattach.push(a=>{const o=a._zod.bag,i=(e.inclusive?o.maximum:o.exclusiveMaximum)??Number.POSITIVE_INFINITY;e.value<i&&(e.inclusive?o.maximum=e.value:o.exclusiveMaximum=e.value)}),n._zod.check=a=>{(e.inclusive?a.value<=e.value:a.value<e.value)||a.issues.push({origin:t,code:"too_big",maximum:e.value,input:a.value,inclusive:e.inclusive,inst:n,continue:!e.abort})}}),Rc=V("$ZodCheckGreaterThan",(n,e)=>{Oe.init(n,e);const t=_c[typeof e.value];n._zod.onattach.push(a=>{const o=a._zod.bag,i=(e.inclusive?o.minimum:o.exclusiveMinimum)??Number.NEGATIVE_INFINITY;e.value>i&&(e.inclusive?o.minimum=e.value:o.exclusiveMinimum=e.value)}),n._zod.check=a=>{(e.inclusive?a.value>=e.value:a.value>e.value)||a.issues.push({origin:t,code:"too_small",minimum:e.value,input:a.value,inclusive:e.inclusive,inst:n,continue:!e.abort})}}),$g=V("$ZodCheckMultipleOf",(n,e)=>{Oe.init(n,e),n._zod.onattach.push(t=>{var a;(a=t._zod.bag).multipleOf??(a.multipleOf=e.value)}),n._zod.check=t=>{if(typeof t.value!=typeof e.value)throw new Error("Cannot mix number and bigint in multiple_of check.");(typeof t.value=="bigint"?t.value%e.value===BigInt(0):jm(t.value,e.value)===0)||t.issues.push({origin:typeof t.value,code:"not_multiple_of",divisor:e.value,input:t.value,inst:n,continue:!e.abort})}}),Gg=V("$ZodCheckNumberFormat",(n,e)=>{Oe.init(n,e),e.format=e.format||"float64";const t=e.format?.includes("int"),a=t?"int":"number",[o,i]=qm[e.format];n._zod.onattach.push(r=>{const s=r._zod.bag;s.format=e.format,s.minimum=o,s.maximum=i,t&&(s.pattern=Hg)}),n._zod.check=r=>{const s=r.value;if(t){if(!Number.isInteger(s)){r.issues.push({expected:a,format:e.format,code:"invalid_type",continue:!1,input:s,inst:n});return}if(!Number.isSafeInteger(s)){s>0?r.issues.push({input:s,code:"too_big",maximum:Number.MAX_SAFE_INTEGER,note:"Integers must be within the safe integer range.",inst:n,origin:a,continue:!e.abort}):r.issues.push({input:s,code:"too_small",minimum:Number.MIN_SAFE_INTEGER,note:"Integers must be within the safe integer range.",inst:n,origin:a,continue:!e.abort});return}}s<o&&r.issues.push({origin:"number",input:s,code:"too_small",minimum:o,inclusive:!0,inst:n,continue:!e.abort}),s>i&&r.issues.push({origin:"number",input:s,code:"too_big",maximum:i,inst:n})}}),jg=V("$ZodCheckMaxLength",(n,e)=>{var t;Oe.init(n,e),(t=n._zod.def).when??(t.when=a=>{const o=a.value;return!Zi(o)&&o.length!==void 0}),n._zod.onattach.push(a=>{const o=a._zod.bag.maximum??Number.POSITIVE_INFINITY;e.maximum<o&&(a._zod.bag.maximum=e.maximum)}),n._zod.check=a=>{const o=a.value;if(o.length<=e.maximum)return;const r=Ji(o);a.issues.push({origin:r,code:"too_big",maximum:e.maximum,inclusive:!0,input:o,inst:n,continue:!e.abort})}}),Yg=V("$ZodCheckMinLength",(n,e)=>{var t;Oe.init(n,e),(t=n._zod.def).when??(t.when=a=>{const o=a.value;return!Zi(o)&&o.length!==void 0}),n._zod.onattach.push(a=>{const o=a._zod.bag.minimum??Number.NEGATIVE_INFINITY;e.minimum>o&&(a._zod.bag.minimum=e.minimum)}),n._zod.check=a=>{const o=a.value;if(o.length>=e.minimum)return;const r=Ji(o);a.issues.push({origin:r,code:"too_small",minimum:e.minimum,inclusive:!0,input:o,inst:n,continue:!e.abort})}}),zg=V("$ZodCheckLengthEquals",(n,e)=>{var t;Oe.init(n,e),(t=n._zod.def).when??(t.when=a=>{const o=a.value;return!Zi(o)&&o.length!==void 0}),n._zod.onattach.push(a=>{const o=a._zod.bag;o.minimum=e.length,o.maximum=e.length,o.length=e.length}),n._zod.check=a=>{const o=a.value,i=o.length;if(i===e.length)return;const r=Ji(o),s=i>e.length;a.issues.push({origin:r,...s?{code:"too_big",maximum:e.length}:{code:"too_small",minimum:e.length},inclusive:!0,exact:!0,input:a.value,inst:n,continue:!e.abort})}}),ko=V("$ZodCheckStringFormat",(n,e)=>{var t,a;Oe.init(n,e),n._zod.onattach.push(o=>{const i=o._zod.bag;i.format=e.format,e.pattern&&(i.patterns??(i.patterns=new Set),i.patterns.add(e.pattern))}),e.pattern?(t=n._zod).check??(t.check=o=>{e.pattern.lastIndex=0,!e.pattern.test(o.value)&&o.issues.push({origin:"string",code:"invalid_format",format:e.format,input:o.value,...e.pattern?{pattern:e.pattern.toString()}:{},inst:n,continue:!e.abort})}):(a=n._zod).check??(a.check=()=>{})}),Kg=V("$ZodCheckRegex",(n,e)=>{ko.init(n,e),n._zod.check=t=>{e.pattern.lastIndex=0,!e.pattern.test(t.value)&&t.issues.push({origin:"string",code:"invalid_format",format:"regex",input:t.value,pattern:e.pattern.toString(),inst:n,continue:!e.abort})}}),qg=V("$ZodCheckLowerCase",(n,e)=>{e.pattern??(e.pattern=Wg),ko.init(n,e)}),Zg=V("$ZodCheckUpperCase",(n,e)=>{e.pattern??(e.pattern=Ug),ko.init(n,e)}),Xg=V("$ZodCheckIncludes",(n,e)=>{Oe.init(n,e);const t=pa(e.includes),a=new RegExp(typeof e.position=="number"?`^.{${e.position}}${t}`:t);e.pattern=a,n._zod.onattach.push(o=>{const i=o._zod.bag;i.patterns??(i.patterns=new Set),i.patterns.add(a)}),n._zod.check=o=>{o.value.includes(e.includes,e.position)||o.issues.push({origin:"string",code:"invalid_format",format:"includes",includes:e.includes,input:o.value,inst:n,continue:!e.abort})}}),Jg=V("$ZodCheckStartsWith",(n,e)=>{Oe.init(n,e);const t=new RegExp(`^${pa(e.prefix)}.*`);e.pattern??(e.pattern=t),n._zod.onattach.push(a=>{const o=a._zod.bag;o.patterns??(o.patterns=new Set),o.patterns.add(t)}),n._zod.check=a=>{a.value.startsWith(e.prefix)||a.issues.push({origin:"string",code:"invalid_format",format:"starts_with",prefix:e.prefix,input:a.value,inst:n,continue:!e.abort})}}),Qg=V("$ZodCheckEndsWith",(n,e)=>{Oe.init(n,e);const t=new RegExp(`.*${pa(e.suffix)}$`);e.pattern??(e.pattern=t),n._zod.onattach.push(a=>{const o=a._zod.bag;o.patterns??(o.patterns=new Set),o.patterns.add(t)}),n._zod.check=a=>{a.value.endsWith(e.suffix)||a.issues.push({origin:"string",code:"invalid_format",format:"ends_with",suffix:e.suffix,input:a.value,inst:n,continue:!e.abort})}}),n0=V("$ZodCheckOverwrite",(n,e)=>{Oe.init(n,e),n._zod.check=t=>{t.value=e.tx(t.value)}});class e0{constructor(e=[]){this.content=[],this.indent=0,this&&(this.args=e)}indented(e){this.indent+=1,e(this),this.indent-=1}write(e){if(typeof e=="function"){e(this,{execution:"sync"}),e(this,{execution:"async"});return}const a=e.split(`
`).filter(r=>r),o=Math.min(...a.map(r=>r.length-r.trimStart().length)),i=a.map(r=>r.slice(o)).map(r=>" ".repeat(this.indent*2)+r);for(const r of i)this.content.push(r)}compile(){const e=Function,t=this?.args,o=[...(this?.content??[""]).map(i=>`  ${i}`)];return new e(...t,o.join(`
`))}}const t0={major:4,minor:1,patch:12},Nn=V("$ZodType",(n,e)=>{var t;n??(n={}),n._zod.def=e,n._zod.bag=n._zod.bag||{},n._zod.version=t0;const a=[...n._zod.def.checks??[]];n._zod.traits.has("$ZodCheck")&&a.unshift(n);for(const o of a)for(const i of o._zod.onattach)i(n);if(a.length===0)(t=n._zod).deferred??(t.deferred=[]),n._zod.deferred?.push(()=>{n._zod.run=n._zod.parse});else{const o=(r,s,c)=>{let u=ha(r),h;for(const p of s){if(p._zod.def.when){if(!p._zod.def.when(r))continue}else if(u)continue;const E=r.issues.length,b=p._zod.check(r);if(b instanceof Promise&&c?.async===!1)throw new ga;if(h||b instanceof Promise)h=(h??Promise.resolve()).then(async()=>{await b,r.issues.length!==E&&(u||(u=ha(r,E)))});else{if(r.issues.length===E)continue;u||(u=ha(r,E))}}return h?h.then(()=>r):r},i=(r,s,c)=>{if(ha(r))return r.aborted=!0,r;const u=o(s,a,c);if(u instanceof Promise){if(c.async===!1)throw new ga;return u.then(h=>n._zod.parse(h,c))}return n._zod.parse(u,c)};n._zod.run=(r,s)=>{if(s.skipChecks)return n._zod.parse(r,s);if(s.direction==="backward"){const u=n._zod.parse({value:r.value,issues:[]},{...s,skipChecks:!0});return u instanceof Promise?u.then(h=>i(h,r,s)):i(u,r,s)}const c=n._zod.parse(r,s);if(c instanceof Promise){if(s.async===!1)throw new ga;return c.then(u=>o(u,a,s))}return o(c,a,s)}}n["~standard"]={validate:o=>{try{const i=ig(n,o);return i.success?{value:i.data}:{issues:i.error?.issues}}catch{return rg(n,o).then(r=>r.success?{value:r.data}:{issues:r.error?.issues})}},vendor:"zod",version:1}}),er=V("$ZodString",(n,e)=>{Nn.init(n,e),n._zod.pattern=[...n?._zod.bag?.patterns??[]].pop()??xg(n._zod.bag),n._zod.parse=(t,a)=>{if(e.coerce)try{t.value=String(t.value)}catch{}return typeof t.value=="string"||t.issues.push({expected:"string",code:"invalid_type",input:t.value,inst:n}),t}}),Pn=V("$ZodStringFormat",(n,e)=>{ko.init(n,e),er.init(n,e)}),a0=V("$ZodGUID",(n,e)=>{e.pattern??(e.pattern=Rg),Pn.init(n,e)}),o0=V("$ZodUUID",(n,e)=>{if(e.version){const a={v1:1,v2:2,v3:3,v4:4,v5:5,v6:6,v7:7,v8:8}[e.version];if(a===void 0)throw new Error(`Invalid UUID version: "${e.version}"`);e.pattern??(e.pattern=hc(a))}else e.pattern??(e.pattern=hc());Pn.init(n,e)}),i0=V("$ZodEmail",(n,e)=>{e.pattern??(e.pattern=vg),Pn.init(n,e)}),r0=V("$ZodURL",(n,e)=>{Pn.init(n,e),n._zod.check=t=>{try{const a=t.value.trim(),o=new URL(a);e.hostname&&(e.hostname.lastIndex=0,e.hostname.test(o.hostname)||t.issues.push({code:"invalid_format",format:"url",note:"Invalid hostname",pattern:Dg.source,input:t.value,inst:n,continue:!e.abort})),e.protocol&&(e.protocol.lastIndex=0,e.protocol.test(o.protocol.endsWith(":")?o.protocol.slice(0,-1):o.protocol)||t.issues.push({code:"invalid_format",format:"url",note:"Invalid protocol",pattern:e.protocol.source,input:t.value,inst:n,continue:!e.abort})),e.normalize?t.value=o.href:t.value=a;return}catch{t.issues.push({code:"invalid_format",format:"url",input:t.value,inst:n,continue:!e.abort})}}}),s0=V("$ZodEmoji",(n,e)=>{e.pattern??(e.pattern=bg()),Pn.init(n,e)}),c0=V("$ZodNanoID",(n,e)=>{e.pattern??(e.pattern=_g),Pn.init(n,e)}),l0=V("$ZodCUID",(n,e)=>{e.pattern??(e.pattern=pg),Pn.init(n,e)}),d0=V("$ZodCUID2",(n,e)=>{e.pattern??(e.pattern=hg),Pn.init(n,e)}),u0=V("$ZodULID",(n,e)=>{e.pattern??(e.pattern=fg),Pn.init(n,e)}),m0=V("$ZodXID",(n,e)=>{e.pattern??(e.pattern=Eg),Pn.init(n,e)}),g0=V("$ZodKSUID",(n,e)=>{e.pattern??(e.pattern=Sg),Pn.init(n,e)}),I0=V("$ZodISODateTime",(n,e)=>{e.pattern??(e.pattern=Pg(e)),Pn.init(n,e)}),p0=V("$ZodISODate",(n,e)=>{e.pattern??(e.pattern=kg),Pn.init(n,e)}),h0=V("$ZodISOTime",(n,e)=>{e.pattern??(e.pattern=Bg(e)),Pn.init(n,e)}),f0=V("$ZodISODuration",(n,e)=>{e.pattern??(e.pattern=Tg),Pn.init(n,e)}),E0=V("$ZodIPv4",(n,e)=>{e.pattern??(e.pattern=wg),Pn.init(n,e),n._zod.onattach.push(t=>{const a=t._zod.bag;a.format="ipv4"})}),S0=V("$ZodIPv6",(n,e)=>{e.pattern??(e.pattern=Og),Pn.init(n,e),n._zod.onattach.push(t=>{const a=t._zod.bag;a.format="ipv6"}),n._zod.check=t=>{try{new URL(`http://[${t.value}]`)}catch{t.issues.push({code:"invalid_format",format:"ipv6",input:t.value,inst:n,continue:!e.abort})}}}),_0=V("$ZodCIDRv4",(n,e)=>{e.pattern??(e.pattern=Lg),Pn.init(n,e)}),T0=V("$ZodCIDRv6",(n,e)=>{e.pattern??(e.pattern=Ng),Pn.init(n,e),n._zod.check=t=>{const a=t.value.split("/");try{if(a.length!==2)throw new Error;const[o,i]=a;if(!i)throw new Error;const r=Number(i);if(`${r}`!==i)throw new Error;if(r<0||r>128)throw new Error;new URL(`http://[${o}]`)}catch{t.issues.push({code:"invalid_format",format:"cidrv6",input:t.value,inst:n,continue:!e.abort})}}});function vc(n){if(n==="")return!0;if(n.length%4!==0)return!1;try{return atob(n),!0}catch{return!1}}const R0=V("$ZodBase64",(n,e)=>{e.pattern??(e.pattern=yg),Pn.init(n,e),n._zod.onattach.push(t=>{t._zod.bag.contentEncoding="base64"}),n._zod.check=t=>{vc(t.value)||t.issues.push({code:"invalid_format",format:"base64",input:t.value,inst:n,continue:!e.abort})}});function v0(n){if(!fc.test(n))return!1;const e=n.replace(/[-_]/g,a=>a==="-"?"+":"/"),t=e.padEnd(Math.ceil(e.length/4)*4,"=");return vc(t)}const A0=V("$ZodBase64URL",(n,e)=>{e.pattern??(e.pattern=fc),Pn.init(n,e),n._zod.onattach.push(t=>{t._zod.bag.contentEncoding="base64url"}),n._zod.check=t=>{v0(t.value)||t.issues.push({code:"invalid_format",format:"base64url",input:t.value,inst:n,continue:!e.abort})}}),b0=V("$ZodE164",(n,e)=>{e.pattern??(e.pattern=Cg),Pn.init(n,e)});function w0(n,e=null){try{const t=n.split(".");if(t.length!==3)return!1;const[a]=t;if(!a)return!1;const o=JSON.parse(atob(a));return!("typ"in o&&o?.typ!=="JWT"||!o.alg||e&&(!("alg"in o)||o.alg!==e))}catch{return!1}}const O0=V("$ZodJWT",(n,e)=>{Pn.init(n,e),n._zod.check=t=>{w0(t.value,e.alg)||t.issues.push({code:"invalid_format",format:"jwt",input:t.value,inst:n,continue:!e.abort})}}),Ac=V("$ZodNumber",(n,e)=>{Nn.init(n,e),n._zod.pattern=n._zod.bag.pattern??Fg,n._zod.parse=(t,a)=>{if(e.coerce)try{t.value=Number(t.value)}catch{}const o=t.value;if(typeof o=="number"&&!Number.isNaN(o)&&Number.isFinite(o))return t;const i=typeof o=="number"?Number.isNaN(o)?"NaN":Number.isFinite(o)?void 0:"Infinity":void 0;return t.issues.push({expected:"number",code:"invalid_type",input:o,inst:n,...i?{received:i}:{}}),t}}),L0=V("$ZodNumber",(n,e)=>{Gg.init(n,e),Ac.init(n,e)}),N0=V("$ZodBoolean",(n,e)=>{Nn.init(n,e),n._zod.pattern=Mg,n._zod.parse=(t,a)=>{if(e.coerce)try{t.value=!!t.value}catch{}const o=t.value;return typeof o=="boolean"||t.issues.push({expected:"boolean",code:"invalid_type",input:o,inst:n}),t}}),y0=V("$ZodNull",(n,e)=>{Nn.init(n,e),n._zod.pattern=Vg,n._zod.values=new Set([null]),n._zod.parse=(t,a)=>{const o=t.value;return o===null||t.issues.push({expected:"null",code:"invalid_type",input:o,inst:n}),t}}),D0=V("$ZodUnknown",(n,e)=>{Nn.init(n,e),n._zod.parse=t=>t}),C0=V("$ZodNever",(n,e)=>{Nn.init(n,e),n._zod.parse=(t,a)=>(t.issues.push({expected:"never",code:"invalid_type",input:t.value,inst:n}),t)});function bc(n,e,t){n.issues.length&&e.issues.push(...Jt(t,n.issues)),e.value[t]=n.value}const k0=V("$ZodArray",(n,e)=>{Nn.init(n,e),n._zod.parse=(t,a)=>{const o=t.value;if(!Array.isArray(o))return t.issues.push({expected:"array",code:"invalid_type",input:o,inst:n}),t;t.value=Array(o.length);const i=[];for(let r=0;r<o.length;r++){const s=o[r],c=e.element._zod.run({value:s,issues:[]},a);c instanceof Promise?i.push(c.then(u=>bc(u,t,r))):bc(c,t,r)}return i.length?Promise.all(i).then(()=>t):t}});function Bo(n,e,t,a){n.issues.length&&e.issues.push(...Jt(t,n.issues)),n.value===void 0?t in a&&(e.value[t]=void 0):e.value[t]=n.value}function wc(n){const e=Object.keys(n.shape);for(const a of e)if(!n.shape?.[a]?._zod?.traits?.has("$ZodType"))throw new Error(`Invalid element at key "${a}": expected a Zod schema`);const t=Km(n.shape);return{...n,keys:e,keySet:new Set(e),numKeys:e.length,optionalKeys:new Set(t)}}function Oc(n,e,t,a,o,i){const r=[],s=o.keySet,c=o.catchall._zod,u=c.def.type;for(const h of Object.keys(e)){if(s.has(h))continue;if(u==="never"){r.push(h);continue}const p=c.run({value:e[h],issues:[]},a);p instanceof Promise?n.push(p.then(E=>Bo(E,t,h,e))):Bo(p,t,h,e)}return r.length&&t.issues.push({code:"unrecognized_keys",keys:r,input:e,inst:i}),n.length?Promise.all(n).then(()=>t):t}const B0=V("$ZodObject",(n,e)=>{if(Nn.init(n,e),!Object.getOwnPropertyDescriptor(e,"shape")?.get){const s=e.shape;Object.defineProperty(e,"shape",{get:()=>{const c={...s};return Object.defineProperty(e,"shape",{value:c}),c}})}const a=No(()=>wc(e));vn(n._zod,"propValues",()=>{const s=e.shape,c={};for(const u in s){const h=s[u]._zod;if(h.values){c[u]??(c[u]=new Set);for(const p of h.values)c[u].add(p)}}return c});const o=za,i=e.catchall;let r;n._zod.parse=(s,c)=>{r??(r=a.value);const u=s.value;if(!o(u))return s.issues.push({expected:"object",code:"invalid_type",input:u,inst:n}),s;s.value={};const h=[],p=r.shape;for(const E of r.keys){const w=p[E]._zod.run({value:u[E],issues:[]},c);w instanceof Promise?h.push(w.then(v=>Bo(v,s,E,u))):Bo(w,s,E,u)}return i?Oc(h,u,s,c,a.value,n):h.length?Promise.all(h).then(()=>s):s}}),P0=V("$ZodObjectJIT",(n,e)=>{B0.init(n,e);const t=n._zod.parse,a=No(()=>wc(e)),o=E=>{const b=new e0(["shape","payload","ctx"]),w=a.value,v=f=>{const S=dc(f);return`shape[${S}]._zod.run({ value: input[${S}], issues: [] }, ctx)`};b.write("const input = payload.value;");const T=Object.create(null);let A=0;for(const f of w.keys)T[f]=`key_${A++}`;b.write("const newResult = {};");for(const f of w.keys){const S=T[f],k=dc(f);b.write(`const ${S} = ${v(f)};`),b.write(`
        if (${S}.issues.length) {
          payload.issues = payload.issues.concat(${S}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${k}, ...iss.path] : [${k}]
          })));
        }
        
        
        if (${S}.value === undefined) {
          if (${k} in input) {
            newResult[${k}] = undefined;
          }
        } else {
          newResult[${k}] = ${S}.value;
        }
        
      `)}b.write("payload.value = newResult;"),b.write("return payload;");const I=b.compile();return(f,S)=>I(E,f,S)};let i;const r=za,s=!Ki.jitless,u=s&&Ym.value,h=e.catchall;let p;n._zod.parse=(E,b)=>{p??(p=a.value);const w=E.value;return r(w)?s&&u&&b?.async===!1&&b.jitless!==!0?(i||(i=o(e.shape)),E=i(E,b),h?Oc([],w,E,b,p,n):E):t(E,b):(E.issues.push({expected:"object",code:"invalid_type",input:w,inst:n}),E)}});function Lc(n,e,t,a){for(const i of n)if(i.issues.length===0)return e.value=i.value,e;const o=n.filter(i=>!ha(i));return o.length===1?(e.value=o[0].value,o[0]):(e.issues.push({code:"invalid_union",input:e.value,inst:t,errors:n.map(i=>i.issues.map(r=>At(r,a,It())))}),e)}const Nc=V("$ZodUnion",(n,e)=>{Nn.init(n,e),vn(n._zod,"optin",()=>e.options.some(o=>o._zod.optin==="optional")?"optional":void 0),vn(n._zod,"optout",()=>e.options.some(o=>o._zod.optout==="optional")?"optional":void 0),vn(n._zod,"values",()=>{if(e.options.every(o=>o._zod.values))return new Set(e.options.flatMap(o=>Array.from(o._zod.values)))}),vn(n._zod,"pattern",()=>{if(e.options.every(o=>o._zod.pattern)){const o=e.options.map(i=>i._zod.pattern);return new RegExp(`^(${o.map(i=>Xi(i.source)).join("|")})$`)}});const t=e.options.length===1,a=e.options[0]._zod.run;n._zod.parse=(o,i)=>{if(t)return a(o,i);let r=!1;const s=[];for(const c of e.options){const u=c._zod.run({value:o.value,issues:[]},i);if(u instanceof Promise)s.push(u),r=!0;else{if(u.issues.length===0)return u;s.push(u)}}return r?Promise.all(s).then(c=>Lc(c,o,n,i)):Lc(s,o,n,i)}}),x0=V("$ZodDiscriminatedUnion",(n,e)=>{Nc.init(n,e);const t=n._zod.parse;vn(n._zod,"propValues",()=>{const o={};for(const i of e.options){const r=i._zod.propValues;if(!r||Object.keys(r).length===0)throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(i)}"`);for(const[s,c]of Object.entries(r)){o[s]||(o[s]=new Set);for(const u of c)o[s].add(u)}}return o});const a=No(()=>{const o=e.options,i=new Map;for(const r of o){const s=r._zod.propValues?.[e.discriminator];if(!s||s.size===0)throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(r)}"`);for(const c of s){if(i.has(c))throw new Error(`Duplicate discriminator value "${String(c)}"`);i.set(c,r)}}return i});n._zod.parse=(o,i)=>{const r=o.value;if(!za(r))return o.issues.push({code:"invalid_type",expected:"object",input:r,inst:n}),o;const s=a.value.get(r?.[e.discriminator]);return s?s._zod.run(o,i):e.unionFallback?t(o,i):(o.issues.push({code:"invalid_union",errors:[],note:"No matching discriminator",discriminator:e.discriminator,input:r,path:[e.discriminator],inst:n}),o)}}),H0=V("$ZodIntersection",(n,e)=>{Nn.init(n,e),n._zod.parse=(t,a)=>{const o=t.value,i=e.left._zod.run({value:o,issues:[]},a),r=e.right._zod.run({value:o,issues:[]},a);return i instanceof Promise||r instanceof Promise?Promise.all([i,r]).then(([c,u])=>yc(t,c,u)):yc(t,i,r)}});function tr(n,e){if(n===e)return{valid:!0,data:n};if(n instanceof Date&&e instanceof Date&&+n==+e)return{valid:!0,data:n};if(Ia(n)&&Ia(e)){const t=Object.keys(e),a=Object.keys(n).filter(i=>t.indexOf(i)!==-1),o={...n,...e};for(const i of a){const r=tr(n[i],e[i]);if(!r.valid)return{valid:!1,mergeErrorPath:[i,...r.mergeErrorPath]};o[i]=r.data}return{valid:!0,data:o}}if(Array.isArray(n)&&Array.isArray(e)){if(n.length!==e.length)return{valid:!1,mergeErrorPath:[]};const t=[];for(let a=0;a<n.length;a++){const o=n[a],i=e[a],r=tr(o,i);if(!r.valid)return{valid:!1,mergeErrorPath:[a,...r.mergeErrorPath]};t.push(r.data)}return{valid:!0,data:t}}return{valid:!1,mergeErrorPath:[]}}function yc(n,e,t){if(e.issues.length&&n.issues.push(...e.issues),t.issues.length&&n.issues.push(...t.issues),ha(n))return n;const a=tr(e.value,t.value);if(!a.valid)throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(a.mergeErrorPath)}`);return n.value=a.data,n}const F0=V("$ZodTuple",(n,e)=>{Nn.init(n,e);const t=e.items,a=t.length-[...t].reverse().findIndex(o=>o._zod.optin!=="optional");n._zod.parse=(o,i)=>{const r=o.value;if(!Array.isArray(r))return o.issues.push({input:r,inst:n,expected:"tuple",code:"invalid_type"}),o;o.value=[];const s=[];if(!e.rest){const u=r.length>t.length,h=r.length<a-1;if(u||h)return o.issues.push({...u?{code:"too_big",maximum:t.length}:{code:"too_small",minimum:t.length},input:r,inst:n,origin:"array"}),o}let c=-1;for(const u of t){if(c++,c>=r.length&&c>=a)continue;const h=u._zod.run({value:r[c],issues:[]},i);h instanceof Promise?s.push(h.then(p=>Po(p,o,c))):Po(h,o,c)}if(e.rest){const u=r.slice(t.length);for(const h of u){c++;const p=e.rest._zod.run({value:h,issues:[]},i);p instanceof Promise?s.push(p.then(E=>Po(E,o,c))):Po(p,o,c)}}return s.length?Promise.all(s).then(()=>o):o}});function Po(n,e,t){n.issues.length&&e.issues.push(...Jt(t,n.issues)),e.value[t]=n.value}const M0=V("$ZodRecord",(n,e)=>{Nn.init(n,e),n._zod.parse=(t,a)=>{const o=t.value;if(!Ia(o))return t.issues.push({expected:"record",code:"invalid_type",input:o,inst:n}),t;const i=[];if(e.keyType._zod.values){const r=e.keyType._zod.values;t.value={};for(const c of r)if(typeof c=="string"||typeof c=="number"||typeof c=="symbol"){const u=e.valueType._zod.run({value:o[c],issues:[]},a);u instanceof Promise?i.push(u.then(h=>{h.issues.length&&t.issues.push(...Jt(c,h.issues)),t.value[c]=h.value})):(u.issues.length&&t.issues.push(...Jt(c,u.issues)),t.value[c]=u.value)}let s;for(const c in o)r.has(c)||(s=s??[],s.push(c));s&&s.length>0&&t.issues.push({code:"unrecognized_keys",input:o,inst:n,keys:s})}else{t.value={};for(const r of Reflect.ownKeys(o)){if(r==="__proto__")continue;const s=e.keyType._zod.run({value:r,issues:[]},a);if(s instanceof Promise)throw new Error("Async schemas not supported in object keys currently");if(s.issues.length){t.issues.push({code:"invalid_key",origin:"record",issues:s.issues.map(u=>At(u,a,It())),input:r,path:[r],inst:n}),t.value[s.value]=s.value;continue}const c=e.valueType._zod.run({value:o[r],issues:[]},a);c instanceof Promise?i.push(c.then(u=>{u.issues.length&&t.issues.push(...Jt(r,u.issues)),t.value[s.value]=u.value})):(c.issues.length&&t.issues.push(...Jt(r,c.issues)),t.value[s.value]=c.value)}}return i.length?Promise.all(i).then(()=>t):t}}),V0=V("$ZodEnum",(n,e)=>{Nn.init(n,e);const t=Gm(e.entries),a=new Set(t);n._zod.values=a,n._zod.pattern=new RegExp(`^(${t.filter(o=>zm.has(typeof o)).map(o=>typeof o=="string"?pa(o):o.toString()).join("|")})$`),n._zod.parse=(o,i)=>{const r=o.value;return a.has(r)||o.issues.push({code:"invalid_value",values:t,input:r,inst:n}),o}}),W0=V("$ZodLiteral",(n,e)=>{if(Nn.init(n,e),e.values.length===0)throw new Error("Cannot create literal schema with no valid values");n._zod.values=new Set(e.values),n._zod.pattern=new RegExp(`^(${e.values.map(t=>typeof t=="string"?pa(t):t?pa(t.toString()):String(t)).join("|")})$`),n._zod.parse=(t,a)=>{const o=t.value;return n._zod.values.has(o)||t.issues.push({code:"invalid_value",values:e.values,input:o,inst:n}),t}}),U0=V("$ZodTransform",(n,e)=>{Nn.init(n,e),n._zod.parse=(t,a)=>{if(a.direction==="backward")throw new cc(n.constructor.name);const o=e.transform(t.value,t);if(a.async)return(o instanceof Promise?o:Promise.resolve(o)).then(r=>(t.value=r,t));if(o instanceof Promise)throw new ga;return t.value=o,t}});function Dc(n,e){return n.issues.length&&e===void 0?{issues:[],value:void 0}:n}const $0=V("$ZodOptional",(n,e)=>{Nn.init(n,e),n._zod.optin="optional",n._zod.optout="optional",vn(n._zod,"values",()=>e.innerType._zod.values?new Set([...e.innerType._zod.values,void 0]):void 0),vn(n._zod,"pattern",()=>{const t=e.innerType._zod.pattern;return t?new RegExp(`^(${Xi(t.source)})?$`):void 0}),n._zod.parse=(t,a)=>{if(e.innerType._zod.optin==="optional"){const o=e.innerType._zod.run(t,a);return o instanceof Promise?o.then(i=>Dc(i,t.value)):Dc(o,t.value)}return t.value===void 0?t:e.innerType._zod.run(t,a)}}),G0=V("$ZodNullable",(n,e)=>{Nn.init(n,e),vn(n._zod,"optin",()=>e.innerType._zod.optin),vn(n._zod,"optout",()=>e.innerType._zod.optout),vn(n._zod,"pattern",()=>{const t=e.innerType._zod.pattern;return t?new RegExp(`^(${Xi(t.source)}|null)$`):void 0}),vn(n._zod,"values",()=>e.innerType._zod.values?new Set([...e.innerType._zod.values,null]):void 0),n._zod.parse=(t,a)=>t.value===null?t:e.innerType._zod.run(t,a)}),j0=V("$ZodDefault",(n,e)=>{Nn.init(n,e),n._zod.optin="optional",vn(n._zod,"values",()=>e.innerType._zod.values),n._zod.parse=(t,a)=>{if(a.direction==="backward")return e.innerType._zod.run(t,a);if(t.value===void 0)return t.value=e.defaultValue,t;const o=e.innerType._zod.run(t,a);return o instanceof Promise?o.then(i=>Cc(i,e)):Cc(o,e)}});function Cc(n,e){return n.value===void 0&&(n.value=e.defaultValue),n}const Y0=V("$ZodPrefault",(n,e)=>{Nn.init(n,e),n._zod.optin="optional",vn(n._zod,"values",()=>e.innerType._zod.values),n._zod.parse=(t,a)=>(a.direction==="backward"||t.value===void 0&&(t.value=e.defaultValue),e.innerType._zod.run(t,a))}),z0=V("$ZodNonOptional",(n,e)=>{Nn.init(n,e),vn(n._zod,"values",()=>{const t=e.innerType._zod.values;return t?new Set([...t].filter(a=>a!==void 0)):void 0}),n._zod.parse=(t,a)=>{const o=e.innerType._zod.run(t,a);return o instanceof Promise?o.then(i=>kc(i,n)):kc(o,n)}});function kc(n,e){return!n.issues.length&&n.value===void 0&&n.issues.push({code:"invalid_type",expected:"nonoptional",input:n.value,inst:e}),n}const K0=V("$ZodCatch",(n,e)=>{Nn.init(n,e),vn(n._zod,"optin",()=>e.innerType._zod.optin),vn(n._zod,"optout",()=>e.innerType._zod.optout),vn(n._zod,"values",()=>e.innerType._zod.values),n._zod.parse=(t,a)=>{if(a.direction==="backward")return e.innerType._zod.run(t,a);const o=e.innerType._zod.run(t,a);return o instanceof Promise?o.then(i=>(t.value=i.value,i.issues.length&&(t.value=e.catchValue({...t,error:{issues:i.issues.map(r=>At(r,a,It()))},input:t.value}),t.issues=[]),t)):(t.value=o.value,o.issues.length&&(t.value=e.catchValue({...t,error:{issues:o.issues.map(i=>At(i,a,It()))},input:t.value}),t.issues=[]),t)}}),q0=V("$ZodPipe",(n,e)=>{Nn.init(n,e),vn(n._zod,"values",()=>e.in._zod.values),vn(n._zod,"optin",()=>e.in._zod.optin),vn(n._zod,"optout",()=>e.out._zod.optout),vn(n._zod,"propValues",()=>e.in._zod.propValues),n._zod.parse=(t,a)=>{if(a.direction==="backward"){const i=e.out._zod.run(t,a);return i instanceof Promise?i.then(r=>xo(r,e.in,a)):xo(i,e.in,a)}const o=e.in._zod.run(t,a);return o instanceof Promise?o.then(i=>xo(i,e.out,a)):xo(o,e.out,a)}});function xo(n,e,t){return n.issues.length?(n.aborted=!0,n):e._zod.run({value:n.value,issues:n.issues},t)}const Z0=V("$ZodReadonly",(n,e)=>{Nn.init(n,e),vn(n._zod,"propValues",()=>e.innerType._zod.propValues),vn(n._zod,"values",()=>e.innerType._zod.values),vn(n._zod,"optin",()=>e.innerType._zod.optin),vn(n._zod,"optout",()=>e.innerType._zod.optout),n._zod.parse=(t,a)=>{if(a.direction==="backward")return e.innerType._zod.run(t,a);const o=e.innerType._zod.run(t,a);return o instanceof Promise?o.then(Bc):Bc(o)}});function Bc(n){return n.value=Object.freeze(n.value),n}const X0=V("$ZodLazy",(n,e)=>{Nn.init(n,e),vn(n._zod,"innerType",()=>e.getter()),vn(n._zod,"pattern",()=>n._zod.innerType._zod.pattern),vn(n._zod,"propValues",()=>n._zod.innerType._zod.propValues),vn(n._zod,"optin",()=>n._zod.innerType._zod.optin??void 0),vn(n._zod,"optout",()=>n._zod.innerType._zod.optout??void 0),n._zod.parse=(t,a)=>n._zod.innerType._zod.run(t,a)}),J0=V("$ZodCustom",(n,e)=>{Oe.init(n,e),Nn.init(n,e),n._zod.parse=(t,a)=>t,n._zod.check=t=>{const a=t.value,o=e.fn(a);if(o instanceof Promise)return o.then(i=>Pc(i,t,a,n));Pc(o,t,a,n)}});function Pc(n,e,t,a){if(!n){const o={code:"custom",input:t,inst:a,path:[...a._zod.def.path??[]],continue:!a._zod.def.abort};a._zod.def.params&&(o.params=a._zod.def.params),e.issues.push(Ka(o))}}class Q0{constructor(){this._map=new WeakMap,this._idmap=new Map}add(e,...t){const a=t[0];if(this._map.set(e,a),a&&typeof a=="object"&&"id"in a){if(this._idmap.has(a.id))throw new Error(`ID ${a.id} already exists in the registry`);this._idmap.set(a.id,e)}return this}clear(){return this._map=new WeakMap,this._idmap=new Map,this}remove(e){const t=this._map.get(e);return t&&typeof t=="object"&&"id"in t&&this._idmap.delete(t.id),this._map.delete(e),this}get(e){const t=e._zod.parent;if(t){const a={...this.get(t)??{}};delete a.id;const o={...a,...this._map.get(e)};return Object.keys(o).length?o:void 0}return this._map.get(e)}has(e){return this._map.has(e)}}function nI(){return new Q0}const Ho=nI();function eI(n,e){return new n({type:"string",...sn(e)})}function tI(n,e){return new n({type:"string",format:"email",check:"string_format",abort:!1,...sn(e)})}function xc(n,e){return new n({type:"string",format:"guid",check:"string_format",abort:!1,...sn(e)})}function aI(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,...sn(e)})}function oI(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,version:"v4",...sn(e)})}function iI(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,version:"v6",...sn(e)})}function rI(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,version:"v7",...sn(e)})}function sI(n,e){return new n({type:"string",format:"url",check:"string_format",abort:!1,...sn(e)})}function cI(n,e){return new n({type:"string",format:"emoji",check:"string_format",abort:!1,...sn(e)})}function lI(n,e){return new n({type:"string",format:"nanoid",check:"string_format",abort:!1,...sn(e)})}function dI(n,e){return new n({type:"string",format:"cuid",check:"string_format",abort:!1,...sn(e)})}function uI(n,e){return new n({type:"string",format:"cuid2",check:"string_format",abort:!1,...sn(e)})}function mI(n,e){return new n({type:"string",format:"ulid",check:"string_format",abort:!1,...sn(e)})}function gI(n,e){return new n({type:"string",format:"xid",check:"string_format",abort:!1,...sn(e)})}function II(n,e){return new n({type:"string",format:"ksuid",check:"string_format",abort:!1,...sn(e)})}function pI(n,e){return new n({type:"string",format:"ipv4",check:"string_format",abort:!1,...sn(e)})}function hI(n,e){return new n({type:"string",format:"ipv6",check:"string_format",abort:!1,...sn(e)})}function fI(n,e){return new n({type:"string",format:"cidrv4",check:"string_format",abort:!1,...sn(e)})}function EI(n,e){return new n({type:"string",format:"cidrv6",check:"string_format",abort:!1,...sn(e)})}function SI(n,e){return new n({type:"string",format:"base64",check:"string_format",abort:!1,...sn(e)})}function _I(n,e){return new n({type:"string",format:"base64url",check:"string_format",abort:!1,...sn(e)})}function TI(n,e){return new n({type:"string",format:"e164",check:"string_format",abort:!1,...sn(e)})}function RI(n,e){return new n({type:"string",format:"jwt",check:"string_format",abort:!1,...sn(e)})}function vI(n,e){return new n({type:"string",format:"datetime",check:"string_format",offset:!1,local:!1,precision:null,...sn(e)})}function AI(n,e){return new n({type:"string",format:"date",check:"string_format",...sn(e)})}function bI(n,e){return new n({type:"string",format:"time",check:"string_format",precision:null,...sn(e)})}function wI(n,e){return new n({type:"string",format:"duration",check:"string_format",...sn(e)})}function OI(n,e){return new n({type:"number",checks:[],...sn(e)})}function LI(n,e){return new n({type:"number",check:"number_format",abort:!1,format:"safeint",...sn(e)})}function NI(n,e){return new n({type:"boolean",...sn(e)})}function yI(n,e){return new n({type:"null",...sn(e)})}function DI(n){return new n({type:"unknown"})}function CI(n,e){return new n({type:"never",...sn(e)})}function Hc(n,e){return new Tc({check:"less_than",...sn(e),value:n,inclusive:!1})}function ar(n,e){return new Tc({check:"less_than",...sn(e),value:n,inclusive:!0})}function Fc(n,e){return new Rc({check:"greater_than",...sn(e),value:n,inclusive:!1})}function or(n,e){return new Rc({check:"greater_than",...sn(e),value:n,inclusive:!0})}function Mc(n,e){return new $g({check:"multiple_of",...sn(e),value:n})}function Vc(n,e){return new jg({check:"max_length",...sn(e),maximum:n})}function Fo(n,e){return new Yg({check:"min_length",...sn(e),minimum:n})}function Wc(n,e){return new zg({check:"length_equals",...sn(e),length:n})}function kI(n,e){return new Kg({check:"string_format",format:"regex",...sn(e),pattern:n})}function BI(n){return new qg({check:"string_format",format:"lowercase",...sn(n)})}function PI(n){return new Zg({check:"string_format",format:"uppercase",...sn(n)})}function xI(n,e){return new Xg({check:"string_format",format:"includes",...sn(e),includes:n})}function HI(n,e){return new Jg({check:"string_format",format:"starts_with",...sn(e),prefix:n})}function FI(n,e){return new Qg({check:"string_format",format:"ends_with",...sn(e),suffix:n})}function qa(n){return new n0({check:"overwrite",tx:n})}function MI(n){return qa(e=>e.normalize(n))}function VI(){return qa(n=>n.trim())}function WI(){return qa(n=>n.toLowerCase())}function UI(){return qa(n=>n.toUpperCase())}function $I(n,e,t){return new n({type:"array",element:e,...sn(t)})}function GI(n,e,t){return new n({type:"custom",check:"custom",fn:e,...sn(t)})}function jI(n){const e=YI(t=>(t.addIssue=a=>{if(typeof a=="string")t.issues.push(Ka(a,t.value,e._zod.def));else{const o=a;o.fatal&&(o.continue=!1),o.code??(o.code="custom"),o.input??(o.input=t.value),o.inst??(o.inst=e),o.continue??(o.continue=!e._zod.def.abort),t.issues.push(Ka(o))}},n(t.value,t)));return e}function YI(n,e){const t=new Oe({check:"custom",...sn(e)});return t._zod.check=n,t}const zI=V("ZodISODateTime",(n,e)=>{I0.init(n,e),$n.init(n,e)});function pt(n){return vI(zI,n)}const KI=V("ZodISODate",(n,e)=>{p0.init(n,e),$n.init(n,e)});function gn(n){return AI(KI,n)}const qI=V("ZodISOTime",(n,e)=>{h0.init(n,e),$n.init(n,e)});function ZI(n){return bI(qI,n)}const XI=V("ZodISODuration",(n,e)=>{f0.init(n,e),$n.init(n,e)});function JI(n){return wI(XI,n)}const Ye=V("ZodError",(n,e)=>{Ic.init(n,e),n.name="ZodError",Object.defineProperties(n,{format:{value:t=>og(n,t)},flatten:{value:t=>ag(n,t)},addIssue:{value:t=>{n.issues.push(t),n.message=JSON.stringify(n.issues,qi,2)}},addIssues:{value:t=>{n.issues.push(...t),n.message=JSON.stringify(n.issues,qi,2)}},isEmpty:{get(){return n.issues.length===0}}})},{Parent:Error}),QI=Qi(Ye),np=nr(Ye),ep=Do(Ye),tp=Co(Ye),ap=sg(Ye),op=cg(Ye),ip=lg(Ye),rp=dg(Ye),sp=ug(Ye),cp=mg(Ye),lp=gg(Ye),dp=Ig(Ye),Bn=V("ZodType",(n,e)=>(Nn.init(n,e),n.def=e,n.type=e.type,Object.defineProperty(n,"_def",{value:e}),n.check=(...t)=>n.clone(Xt(e,{checks:[...e.checks??[],...t.map(a=>typeof a=="function"?{_zod:{check:a,def:{check:"custom"},onattach:[]}}:a)]})),n.clone=(t,a)=>vt(n,t,a),n.brand=()=>n,n.register=((t,a)=>(t.add(n,a),n)),n.parse=(t,a)=>QI(n,t,a,{callee:n.parse}),n.safeParse=(t,a)=>ep(n,t,a),n.parseAsync=async(t,a)=>np(n,t,a,{callee:n.parseAsync}),n.safeParseAsync=async(t,a)=>tp(n,t,a),n.spa=n.safeParseAsync,n.encode=(t,a)=>ap(n,t,a),n.decode=(t,a)=>op(n,t,a),n.encodeAsync=async(t,a)=>ip(n,t,a),n.decodeAsync=async(t,a)=>rp(n,t,a),n.safeEncode=(t,a)=>sp(n,t,a),n.safeDecode=(t,a)=>cp(n,t,a),n.safeEncodeAsync=async(t,a)=>lp(n,t,a),n.safeDecodeAsync=async(t,a)=>dp(n,t,a),n.refine=(t,a)=>n.check(ah(t,a)),n.superRefine=t=>n.check(oh(t)),n.overwrite=t=>n.check(qa(t)),n.optional=()=>Zc(n),n.nullable=()=>Xc(n),n.nullish=()=>Zc(Xc(n)),n.nonoptional=t=>qp(n,t),n.array=()=>O(n),n.or=t=>_e([n,t]),n.and=t=>Fp(n,t),n.transform=t=>Qc(n,$p(t)),n.default=t=>Yp(n,t),n.prefault=t=>Kp(n,t),n.catch=t=>Xp(n,t),n.pipe=t=>Qc(n,t),n.readonly=()=>nh(n),n.describe=t=>{const a=n.clone();return Ho.add(a,{description:t}),a},Object.defineProperty(n,"description",{get(){return Ho.get(n)?.description},configurable:!0}),n.meta=(...t)=>{if(t.length===0)return Ho.get(n);const a=n.clone();return Ho.add(a,t[0]),a},n.isOptional=()=>n.safeParse(void 0).success,n.isNullable=()=>n.safeParse(null).success,n)),Uc=V("_ZodString",(n,e)=>{er.init(n,e),Bn.init(n,e);const t=n._zod.bag;n.format=t.format??null,n.minLength=t.minimum??null,n.maxLength=t.maximum??null,n.regex=(...a)=>n.check(kI(...a)),n.includes=(...a)=>n.check(xI(...a)),n.startsWith=(...a)=>n.check(HI(...a)),n.endsWith=(...a)=>n.check(FI(...a)),n.min=(...a)=>n.check(Fo(...a)),n.max=(...a)=>n.check(Vc(...a)),n.length=(...a)=>n.check(Wc(...a)),n.nonempty=(...a)=>n.check(Fo(1,...a)),n.lowercase=a=>n.check(BI(a)),n.uppercase=a=>n.check(PI(a)),n.trim=()=>n.check(VI()),n.normalize=(...a)=>n.check(MI(...a)),n.toLowerCase=()=>n.check(WI()),n.toUpperCase=()=>n.check(UI())}),up=V("ZodString",(n,e)=>{er.init(n,e),Uc.init(n,e),n.email=t=>n.check(tI(mp,t)),n.url=t=>n.check(sI(gp,t)),n.jwt=t=>n.check(RI(Lp,t)),n.emoji=t=>n.check(cI(Ip,t)),n.guid=t=>n.check(xc($c,t)),n.uuid=t=>n.check(aI(Mo,t)),n.uuidv4=t=>n.check(oI(Mo,t)),n.uuidv6=t=>n.check(iI(Mo,t)),n.uuidv7=t=>n.check(rI(Mo,t)),n.nanoid=t=>n.check(lI(pp,t)),n.guid=t=>n.check(xc($c,t)),n.cuid=t=>n.check(dI(hp,t)),n.cuid2=t=>n.check(uI(fp,t)),n.ulid=t=>n.check(mI(Ep,t)),n.base64=t=>n.check(SI(bp,t)),n.base64url=t=>n.check(_I(wp,t)),n.xid=t=>n.check(gI(Sp,t)),n.ksuid=t=>n.check(II(_p,t)),n.ipv4=t=>n.check(pI(Tp,t)),n.ipv6=t=>n.check(hI(Rp,t)),n.cidrv4=t=>n.check(fI(vp,t)),n.cidrv6=t=>n.check(EI(Ap,t)),n.e164=t=>n.check(TI(Op,t)),n.datetime=t=>n.check(pt(t)),n.date=t=>n.check(gn(t)),n.time=t=>n.check(ZI(t)),n.duration=t=>n.check(JI(t))});function C(n){return eI(up,n)}const $n=V("ZodStringFormat",(n,e)=>{Pn.init(n,e),Uc.init(n,e)}),mp=V("ZodEmail",(n,e)=>{i0.init(n,e),$n.init(n,e)}),$c=V("ZodGUID",(n,e)=>{a0.init(n,e),$n.init(n,e)}),Mo=V("ZodUUID",(n,e)=>{o0.init(n,e),$n.init(n,e)}),gp=V("ZodURL",(n,e)=>{r0.init(n,e),$n.init(n,e)}),Ip=V("ZodEmoji",(n,e)=>{s0.init(n,e),$n.init(n,e)}),pp=V("ZodNanoID",(n,e)=>{c0.init(n,e),$n.init(n,e)}),hp=V("ZodCUID",(n,e)=>{l0.init(n,e),$n.init(n,e)}),fp=V("ZodCUID2",(n,e)=>{d0.init(n,e),$n.init(n,e)}),Ep=V("ZodULID",(n,e)=>{u0.init(n,e),$n.init(n,e)}),Sp=V("ZodXID",(n,e)=>{m0.init(n,e),$n.init(n,e)}),_p=V("ZodKSUID",(n,e)=>{g0.init(n,e),$n.init(n,e)}),Tp=V("ZodIPv4",(n,e)=>{E0.init(n,e),$n.init(n,e)}),Rp=V("ZodIPv6",(n,e)=>{S0.init(n,e),$n.init(n,e)}),vp=V("ZodCIDRv4",(n,e)=>{_0.init(n,e),$n.init(n,e)}),Ap=V("ZodCIDRv6",(n,e)=>{T0.init(n,e),$n.init(n,e)}),bp=V("ZodBase64",(n,e)=>{R0.init(n,e),$n.init(n,e)}),wp=V("ZodBase64URL",(n,e)=>{A0.init(n,e),$n.init(n,e)}),Op=V("ZodE164",(n,e)=>{b0.init(n,e),$n.init(n,e)}),Lp=V("ZodJWT",(n,e)=>{O0.init(n,e),$n.init(n,e)}),Gc=V("ZodNumber",(n,e)=>{Ac.init(n,e),Bn.init(n,e),n.gt=(a,o)=>n.check(Fc(a,o)),n.gte=(a,o)=>n.check(or(a,o)),n.min=(a,o)=>n.check(or(a,o)),n.lt=(a,o)=>n.check(Hc(a,o)),n.lte=(a,o)=>n.check(ar(a,o)),n.max=(a,o)=>n.check(ar(a,o)),n.int=a=>n.check(jc(a)),n.safe=a=>n.check(jc(a)),n.positive=a=>n.check(Fc(0,a)),n.nonnegative=a=>n.check(or(0,a)),n.negative=a=>n.check(Hc(0,a)),n.nonpositive=a=>n.check(ar(0,a)),n.multipleOf=(a,o)=>n.check(Mc(a,o)),n.step=(a,o)=>n.check(Mc(a,o)),n.finite=()=>n;const t=n._zod.bag;n.minValue=Math.max(t.minimum??Number.NEGATIVE_INFINITY,t.exclusiveMinimum??Number.NEGATIVE_INFINITY)??null,n.maxValue=Math.min(t.maximum??Number.POSITIVE_INFINITY,t.exclusiveMaximum??Number.POSITIVE_INFINITY)??null,n.isInt=(t.format??"").includes("int")||Number.isSafeInteger(t.multipleOf??.5),n.isFinite=!0,n.format=t.format??null});function F(n){return OI(Gc,n)}const Np=V("ZodNumberFormat",(n,e)=>{L0.init(n,e),Gc.init(n,e)});function jc(n){return LI(Np,n)}const yp=V("ZodBoolean",(n,e)=>{N0.init(n,e),Bn.init(n,e)});function z(n){return NI(yp,n)}const Dp=V("ZodNull",(n,e)=>{y0.init(n,e),Bn.init(n,e)});function bt(n){return yI(Dp,n)}const Cp=V("ZodUnknown",(n,e)=>{D0.init(n,e),Bn.init(n,e)});function Yc(){return DI(Cp)}const kp=V("ZodNever",(n,e)=>{C0.init(n,e),Bn.init(n,e)});function zc(n){return CI(kp,n)}const Bp=V("ZodArray",(n,e)=>{k0.init(n,e),Bn.init(n,e),n.element=e.element,n.min=(t,a)=>n.check(Fo(t,a)),n.nonempty=t=>n.check(Fo(1,t)),n.max=(t,a)=>n.check(Vc(t,a)),n.length=(t,a)=>n.check(Wc(t,a)),n.unwrap=()=>n.element});function O(n,e){return $I(Bp,n,e)}const Pp=V("ZodObject",(n,e)=>{P0.init(n,e),Bn.init(n,e),vn(n,"shape",()=>e.shape),n.keyof=()=>D(Object.keys(n._zod.def.shape)),n.catchall=t=>n.clone({...n._zod.def,catchall:t}),n.passthrough=()=>n.clone({...n._zod.def,catchall:Yc()}),n.loose=()=>n.clone({...n._zod.def,catchall:Yc()}),n.strict=()=>n.clone({...n._zod.def,catchall:zc()}),n.strip=()=>n.clone({...n._zod.def,catchall:void 0}),n.extend=t=>Jm(n,t),n.safeExtend=t=>Qm(n,t),n.merge=t=>ng(n,t),n.pick=t=>Zm(n,t),n.omit=t=>Xm(n,t),n.partial=(...t)=>eg(qc,n,t[0]),n.required=(...t)=>tg(Jc,n,t[0])});function m(n,e){return new Pp({type:"object",shape:n,catchall:zc(),...sn(e)})}const Kc=V("ZodUnion",(n,e)=>{Nc.init(n,e),Bn.init(n,e),n.options=e.options});function _e(n,e){return new Kc({type:"union",options:n,...sn(e)})}const xp=V("ZodDiscriminatedUnion",(n,e)=>{Kc.init(n,e),x0.init(n,e)});function Gn(n,e,t){return new xp({type:"union",options:e,discriminator:n,...sn(t)})}const Hp=V("ZodIntersection",(n,e)=>{H0.init(n,e),Bn.init(n,e)});function Fp(n,e){return new Hp({type:"intersection",left:n,right:e})}const Mp=V("ZodTuple",(n,e)=>{F0.init(n,e),Bn.init(n,e),n.rest=t=>n.clone({...n._zod.def,rest:t})});function Kn(n,e,t){const a=e instanceof Nn,o=a?t:e,i=a?e:null;return new Mp({type:"tuple",items:n,rest:i,...sn(o)})}const Vp=V("ZodRecord",(n,e)=>{M0.init(n,e),Bn.init(n,e),n.keyType=e.keyType,n.valueType=e.valueType});function An(n,e,t){return new Vp({type:"record",keyType:n,valueType:e,...sn(t)})}const ir=V("ZodEnum",(n,e)=>{V0.init(n,e),Bn.init(n,e),n.enum=e.entries,n.options=Object.values(e.entries);const t=new Set(Object.keys(e.entries));n.extract=(a,o)=>{const i={};for(const r of a)if(t.has(r))i[r]=e.entries[r];else throw new Error(`Key ${r} not found in enum`);return new ir({...e,checks:[],...sn(o),entries:i})},n.exclude=(a,o)=>{const i={...e.entries};for(const r of a)if(t.has(r))delete i[r];else throw new Error(`Key ${r} not found in enum`);return new ir({...e,checks:[],...sn(o),entries:i})}});function D(n,e){const t=Array.isArray(n)?Object.fromEntries(n.map(a=>[a,a])):n;return new ir({type:"enum",entries:t,...sn(e)})}const Wp=V("ZodLiteral",(n,e)=>{W0.init(n,e),Bn.init(n,e),n.values=new Set(e.values),Object.defineProperty(n,"value",{get(){if(e.values.length>1)throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");return e.values[0]}})});function g(n,e){return new Wp({type:"literal",values:Array.isArray(n)?n:[n],...sn(e)})}const Up=V("ZodTransform",(n,e)=>{U0.init(n,e),Bn.init(n,e),n._zod.parse=(t,a)=>{if(a.direction==="backward")throw new cc(n.constructor.name);t.addIssue=i=>{if(typeof i=="string")t.issues.push(Ka(i,t.value,e));else{const r=i;r.fatal&&(r.continue=!1),r.code??(r.code="custom"),r.input??(r.input=t.value),r.inst??(r.inst=n),t.issues.push(Ka(r))}};const o=e.transform(t.value,t);return o instanceof Promise?o.then(i=>(t.value=i,t)):(t.value=o,t)}});function $p(n){return new Up({type:"transform",transform:n})}const qc=V("ZodOptional",(n,e)=>{$0.init(n,e),Bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function Zc(n){return new qc({type:"optional",innerType:n})}const Gp=V("ZodNullable",(n,e)=>{G0.init(n,e),Bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function Xc(n){return new Gp({type:"nullable",innerType:n})}const jp=V("ZodDefault",(n,e)=>{j0.init(n,e),Bn.init(n,e),n.unwrap=()=>n._zod.def.innerType,n.removeDefault=n.unwrap});function Yp(n,e){return new jp({type:"default",innerType:n,get defaultValue(){return typeof e=="function"?e():mc(e)}})}const zp=V("ZodPrefault",(n,e)=>{Y0.init(n,e),Bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function Kp(n,e){return new zp({type:"prefault",innerType:n,get defaultValue(){return typeof e=="function"?e():mc(e)}})}const Jc=V("ZodNonOptional",(n,e)=>{z0.init(n,e),Bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function qp(n,e){return new Jc({type:"nonoptional",innerType:n,...sn(e)})}const Zp=V("ZodCatch",(n,e)=>{K0.init(n,e),Bn.init(n,e),n.unwrap=()=>n._zod.def.innerType,n.removeCatch=n.unwrap});function Xp(n,e){return new Zp({type:"catch",innerType:n,catchValue:typeof e=="function"?e:()=>e})}const Jp=V("ZodPipe",(n,e)=>{q0.init(n,e),Bn.init(n,e),n.in=e.in,n.out=e.out});function Qc(n,e){return new Jp({type:"pipe",in:n,out:e})}const Qp=V("ZodReadonly",(n,e)=>{Z0.init(n,e),Bn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function nh(n){return new Qp({type:"readonly",innerType:n})}const eh=V("ZodLazy",(n,e)=>{X0.init(n,e),Bn.init(n,e),n.unwrap=()=>n._zod.def.getter()});function th(n){return new eh({type:"lazy",getter:n})}const nl=V("ZodCustom",(n,e)=>{J0.init(n,e),Bn.init(n,e)});function ah(n,e={}){return GI(nl,n,e)}function oh(n){return jI(n)}function ih(n,e={error:`Input not instance of ${n.name}`}){const t=new nl({type:"custom",check:"custom",fn:a=>a instanceof n,abort:!0,...sn(e)});return t._zod.bag.Class=n,t}function fa(n){const e=th(()=>_e([C(n),F(),z(),bt(),O(e),An(C(),e)]));return e}const rh=typeof globalThis<"u"&&"document"in globalThis,sh=typeof globalThis<"u"&&"importScripts"in globalThis;(rh||sh)&&It({jitless:!0});const d=F().int().min(0).max(Number.MAX_SAFE_INTEGER),Y=d.min(1),l=C().min(1).max(128).regex(/^(?!(?:constructor|prototype)$)[A-Za-z0-9][A-Za-z0-9_.:-]*$/),N=C().regex(/^[a-f0-9]{64}$/),el=C().min(1).max(128),Te=D(["T20","ODI","RED_BALL"]),yn=d.max(100),de=d.max(1e4),Ea=D(["R","L"]),Vo=D(["FAST","MEDIUM","OFF_SPIN","LEG_SPIN","SLOW_LEFT_ARM","LEFT_ARM_WRIST"]),ue=C().regex(/^[\s\S]{1,80}$/u),ch=m({kind:D(["FICTIONAL","LICENSED","USER_SUPPLIED"]),sourceId:l,sourceHash:N,confidenceBp:de}),Sa=m({defence:yn,timing:yn,power:yn,rotation:yn,vsPace:yn,vsSpin:yn,control:yn,movement:yn,variation:yn,stamina:yn,catching:yn,groundFielding:yn,throwing:yn,keeping:yn}),wt=m({playerId:l,name:ue,birthDate:gn(),batHand:Ea,bowlHand:Ea,bowlingStyle:Vo.nullable(),role:D(["BATTER","BOWLER","ALLROUNDER","KEEPER"]),skills:An(Te,Sa),variations:O(l),shotSectorWeights:O(d).length(8),exposureBalls:An(Te,d),provenance:ch}),tl=m({schema:g("1.0.0"),engine:el,random:el,rules:l,rulesHash:N,model:l,modelHash:N,worldHash:N}),Za=m({playerId:l,aggression:d.max(4),intent:D(["NORMAL","ROTATE","PROTECT"])}),Xa=m({bowlerId:l,line:D(["OFF","STUMPS","LEG"]),length:D(["YORKER","FULL","GOOD","SHORT"]),variationId:l,effort:D(["CONSERVE","NORMAL","MAXIMUM"])}),rr=m({slotId:l,playerId:l}),al=m({battingOrder:z(),bowlerSelection:z(),battingTactics:z(),bowlingTactics:z(),declarations:z(),followOn:z()}),ol=m({battingPlans:An(l,Za),bowlingPlan:Xa,fieldSlots:O(rr).length(9),nextBatterId:l.nullable(),delegation:al}),il=m({seamBp:de,turnBp:de,variabilityBp:de,moistureBp:de,wearPoints:d}),lh=D(["DRY","OVERCAST","RAIN","UNSAFE_LIGHT"]),rl=m({pitch:il,weather:lh,outfieldSpeedBp:de,ballId:l,ballAgeLegalBalls:d,weatherScheduleId:l}),sr=m({wides:d,noBalls:d,byes:d,legByes:d,penalties:d}),_a=D(["NORTH","SOUTH"]),sl=m({kind:D(["BOWLED","LBW","CAUGHT","RUN_OUT","STUMPED","HIT_WICKET"]),playerId:l,creditedBowlerId:l.nullable(),fielderId:l.nullable(),wicketEnd:_a}),Wo=m({type:g("DELIVERY_RECORDED"),inningsIndex:d,deliveryIndex:d,strikerId:l,nonStrikerId:l,bowlerId:l,legality:D(["LEGAL","WIDE","NO_BALL","DEAD"]),legalBall:z(),countsAsBallFaced:z(),batRuns:d,extras:sr,completedRuns:d,boundary:D(["NONE","FOUR","SIX"]),dismissal:sl.nullable(),endsAfter:m({north:l.nullable(),south:l.nullable()}),shotSector:d.max(7).nullable(),trajectory:D(["GROUND","AERIAL","EDGE"]).nullable(),executedLength:D(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"]).nullable(),fieldOutcome:D(["NONE","STOP","DROP","CATCH","MISS","RUN_OUT"]),elapsedSeconds:d,freeHitNext:z()}),cr=m({index:d,battingTeamId:l,bowlingTeamId:l,runs:d,wickets:d.max(10),legalBalls:d,deliveryAttempts:d,targetToWin:Y.nullable(),allocatedBalls:Y.nullable(),extras:sr,northBatterId:l.nullable(),southBatterId:l.nullable(),strikerEnd:_a,battingOrder:O(l),dismissed:O(l),bowlerId:l.nullable(),previousOverBowlerId:l.nullable(),bowlerLegalBalls:An(l,d),freeHitPending:z(),ballAgeLegalBalls:d,complete:z()});D(["LUNCH","TEA","STUMPS","INNINGS"]);const Ta=m({day:Y.max(5),localSeconds:d.max(86399),dayLegalBalls:d,finalHourActive:z(),finalHourBallsRequired:d,finalHourBallsDelivered:d,pendingInterval:D(["LUNCH","TEA","STUMPS"]).nullable()}),dh={winnerTeamId:bt(),marginType:bt(),marginRuns:bt(),marginWickets:bt(),completionReason:C().min(1).max(240)},Qt=_e([m({kind:g("WIN"),winnerTeamId:l,marginType:g("RUNS"),marginRuns:Y,marginWickets:bt(),completionReason:C().min(1).max(240)}),m({kind:g("WIN"),winnerTeamId:l,marginType:g("WICKETS"),marginRuns:bt(),marginWickets:Y.max(10),completionReason:C().min(1).max(240)}),m({kind:g("WIN"),winnerTeamId:l,marginType:g("INNINGS"),marginRuns:Y,marginWickets:bt(),completionReason:C().min(1).max(240)}),m({kind:D(["TIE","DRAW","NO_RESULT"]),...dh})]),lr=D(["SETUP","TOSS","AWAITING_INNINGS","READY","AWAITING_BATTER","AWAITING_BOWLER","INTERVAL","WEATHER_DELAY","COMPLETE"]);m({matchId:l,revision:d,versions:tl,seed:C().min(1).max(256),format:Te,phase:lr,teamIds:Kn([l,l]),xi:An(l,O(wt).length(11)),inningsOrder:O(l).max(4),innings:O(cr).max(4),activeInningsIndex:d.max(3),clock:Ta,tactics:An(l,ol),conditions:rl,fatigueBp:An(l,de),result:Qt.nullable()});function cl(n,e){return n<e?-1:n>e?1:0}const uh=m({limitedOversRain:g(!1),superOver:g(!1),injuries:g(!1),prediction:z()}),dr=m({schemaVersion:g("1.0.0"),gameId:l,matchId:l,format:Te,worldPackId:l,rulesId:l,modelId:l,randomId:g("SHA256_COUNTER_V1"),seed:C().min(1).max(256),teamIds:Kn([l,l]),groundId:l,capabilities:uh}),mh=m({teamId:l,name:ue,squadIds:O(l).min(11).max(100),colours:Kn([C().regex(/^#[a-fA-F0-9]{6}$/),C().regex(/^#[a-fA-F0-9]{6}$/)])}),gh=m({groundId:l,name:ue,pitchPrior:il,sectorRadiiCm:O(Y).length(8),outfieldSpeedBp:de}),Ih=m({slotId:l,sector:d.max(7),angleDegrees:d.max(359),depth:D(["INNER","MIDDLE","DEEP"]),insideCircle:z(),legSide:z(),behindSquare:z()}),ll=m({registryId:l,referenceHand:g("R"),positions:O(Ih).min(9)}),ph=m({fromLegalBall:d,maxOutside:d.max(9)}),hh=m({rulesId:l,schemaVersion:g("1.0.0"),format:Te,referenceEdition:g("MCC_2017_FOURTH_EDITION_2026"),effectiveDate:g("2026-10-01"),customProfile:g(!0),ballsPerOver:g(6),playersPerXI:g(11),wicketsToAllOut:g(10),inningsPerTeam:_e([g(1),g(2)]),allocatedBalls:Y.nullable(),bowlerMaxBalls:Y.nullable(),consecutiveOvers:g(!1),freeHitAfterNoBall:z(),declarations:z(),followOnLead:Y.nullable(),newBallAfterLegalBalls:Y.nullable(),fieldPhases:O(ph),maxLegSide:g(5),maxBehindSquareLegSide:g(2),limitedOversRain:g(!1),superOver:g(!1),supportedClauses:O(C().min(1)),localVariations:O(C().min(1)),fixtureIds:O(l),validationStatus:g("CONTRACT_ONLY")});m({modelId:l,schemaVersion:g("1.0.0"),status:D(["SYNTHETIC_ALPHA","EMPIRICALLY_VALIDATED"]),randomId:g("SHA256_COUNTER_V1"),fixedPointScale:g(1e4),expLutHash:N,featureSpecHash:N,variationIds:O(l),effects:m({overAroundWicket:g(!1),individualVariations:g(!1),moisture:g(!1),geometryEffects:g(!1),outfieldSpeed:g(!1)})});const Ja=m({packId:l,schemaVersion:g("1.0.0"),players:O(wt).min(1).max(1e4),teams:O(mh).min(2).max(500),grounds:O(gh).min(1),rulesIds:O(l).min(1),provenance:C().min(1).max(2e3)}),fh=m({path:C().min(1).max(240).regex(/^(?!\/)(?!.*(?:^|\/)\.\.(?:\/|$))(?!.*\\)[A-Za-z0-9_./-]+$/),bytes:d.max(1e8),sha256:N});m({schemaVersion:g("1.0.0"),gameId:l,versions:tl,entries:O(fh).min(1).max(2e3)});const Ra=m({copyVersion:g("LC_NEW_GAME_WORLD_COPY_V1"),baseWorldCanonicalSha256:N,worldCanonicalSha256:N,world:Ja}),ur={commandId:l,aggregateId:l,expectedRevision:d,actorId:C().regex(/^(?:(?:USER|AI):[A-Za-z0-9][A-Za-z0-9_.:-]*|SYSTEM)$/)},Le=(n,e)=>m({...ur,kind:g(n),payload:m(e)}),Eh=Gn("kind",[Le("SELECT_XI",{teamId:l,playerIds:O(l).length(11),captainId:l,keeperId:l}),Le("CONFIRM_TEAMS",{}),Le("CALL_TOSS",{teamId:l,call:D(["HEADS","TAILS"])}),Le("CHOOSE_INNINGS",{teamId:l,choice:D(["BAT","BOWL"])}),Le("SET_BATTER",{teamId:l,playerId:l}),Le("SET_BOWLER",{teamId:l,bowlerId:l}),m({...ur,kind:g("SET_BATTING_PLAN"),payload:Za}),m({...ur,kind:g("SET_BOWLING_PLAN"),payload:Xa}),Le("SET_FIELD",{teamId:l,fieldSlots:O(rr).length(9)}),Le("SET_DELEGATION",{teamId:l,delegation:al}),Le("ADVANCE",{scope:D(["DELIVERY","OVER","NEXT_DECISION","INNINGS","MATCH"])}),Le("DECLARE",{teamId:l}),Le("CHOOSE_FOLLOW_ON",{teamId:l,enforce:z()}),Le("TAKE_NEW_BALL",{teamId:l}),Le("RESUME_AFTER_DELAY",{}),Le("FINISH_MATCH",{})]),Re=(n,e)=>m({type:g(n),...e}),Sh=Gn("type",[Re("TEAMS_CONFIRMED",{teams:O(m({teamId:l,players:O(wt).length(11),captainId:l,keeperId:l})).length(2)}),Re("TOSS_RESOLVED",{callingTeamId:l,call:D(["HEADS","TAILS"]),outcome:D(["HEADS","TAILS"]),winnerTeamId:l}),Re("INNINGS_STARTED",{innings:cr}),Re("BATTER_SELECTED",{inningsIndex:d,teamId:l,playerId:l,end:D(["NORTH","SOUTH"])}),Re("BOWLER_SELECTED",{inningsIndex:d,teamId:l,bowlerId:l}),Re("TACTICS_CHANGED",{teamId:l,tactics:ol}),Re("OVER_COMPLETED",{inningsIndex:d,bowlerId:l,overIndex:d}),Re("INNINGS_COMPLETED",{inningsIndex:d,reason:D(["ALL_OUT","ALLOCATION","TARGET","DECLARATION","TIME","ABANDONMENT"])}),Re("INTERVAL_STARTED",{kind:D(["LUNCH","TEA","STUMPS","INNINGS"]),clock:Ta}),Re("INTERVAL_ENDED",{clock:Ta}),Re("WEATHER_CHANGED",{conditions:rl,clock:Ta}),Re("RULES_ADJUSTED",{calculationSequence:Y,providerId:l,providerVersion:l,auditHash:N,targetToWin:Y.nullable(),allocations:O(Y),resultEligible:z()}),Re("FOLLOW_ON_CHOSEN",{teamId:l,enforced:z(),inningsOrder:O(l).length(4)}),Re("BALL_REPLACED",{inningsIndex:d,ballId:l,ballAgeLegalBalls:g(0)}),Re("MATCH_COMPLETED",{result:Qt})]),_h=_e([Wo,Sh]),Th=m({gameId:l,matchId:l,sequence:Y,commandId:l,previousHash:N,stateHash:N,payload:_h}),Rh=m({commandId:l,committedRevision:d,eventRange:m({first:Y,last:Y}).nullable()}),vh=D(["STALE_REVISION","ILLEGAL_ACTION","INVALID_DATA","UNSUPPORTED_VERSION","PERSISTENCE_FAILED","INTERNAL_INVARIANT"]);Gn("type",[m({type:g("COMMAND"),command:Eh}),m({type:g("CANCEL_BATCH"),commandId:l})]),Gn("type",[m({type:g("ACK"),receipt:Rh}),m({type:g("STATE_DELTA"),fromRevision:d,toRevision:d,events:O(Th)}),m({type:g("ERROR"),commandId:l.nullable(),code:vh,message:C().min(1).max(1e3)})]);const jn="SHA256_COUNTER_V1",Uo="LC_CANONICAL_JSON_V1_SHA256",$o=m({seed:C().min(1).max(256),domain:D(["MATCH_DELIVERY","TOSS","WEATHER","AI_TIE_BREAK","CAREER_TRAINING","WORLD_GENERATION","PREDICTION"]),entityId:l,eventOrdinal:d,stageName:l,drawIndex:d}),Ah=m({kind:g("RANDOM"),version:g(jn),address:$o}),bh=m({kind:g("HASH_STATE"),version:g(Uo),value:fa()});Gn("kind",[Ah,bh]);function wh(n){const e=$o.parse(n);return JSON.stringify([e.seed,e.domain,e.entityId,e.eventOrdinal,e.stageName,e.drawIndex])}function G(n){const e=new Set,t=a=>{if(a===null)return"null";if(typeof a=="string"||typeof a=="boolean")return JSON.stringify(a);if(typeof a=="number"){if(!Number.isFinite(a))throw new Error("Non-finite JSON number");return JSON.stringify(a)}if(typeof a!="object")throw new Error("Non-JSON value");if(e.has(a))throw new Error("Cyclic JSON");e.add(a);let o;if(Array.isArray(a)){if(Object.getOwnPropertyNames(a).length!==a.length+1||Object.keys(a).length!==a.length)throw new Error("Sparse or decorated array");if(Object.getOwnPropertySymbols(a).length)throw new Error("Symbol keys");const i=[];for(let r=0;r<a.length;r++){const s=Object.getOwnPropertyDescriptor(a,String(r));if(!s||!("value"in s))throw new Error("Sparse array or JSON accessor");i.push(t(s.value))}o="["+i.join(",")+"]"}else{if(Object.getPrototypeOf(a)!==Object.prototype&&Object.getPrototypeOf(a)!==null)throw new Error("Non-plain JSON object");if(Object.getOwnPropertySymbols(a).length)throw new Error("Symbol keys");if(Object.getOwnPropertyNames(a).length!==Object.keys(a).length)throw new Error("Non-enumerable JSON property");const i=a;o="{"+Object.keys(i).sort().map(r=>{const s=Object.getOwnPropertyDescriptor(i,r);if(!s||!("value"in s))throw new Error("JSON accessors forbidden");return JSON.stringify(r)+":"+t(s.value)}).join(",")+"}"}return e.delete(a),o};return t(n)}function Qa(n,e){if(!n)throw new Error(`INVALID_DATA: ${e}`)}const va=n=>new Set(n).size===n.length;function Oh(n,e){const t=wt.parse(n);return Qa(t.shotSectorWeights.some(a=>a>0),"shot sector total must be positive"),Qa(va(t.variations)&&t.variations.every(a=>e.includes(a)),"unknown or duplicate variation"),t}function mr(n,e,t){const a=Ja.parse(n);Qa(va(a.players.map(i=>i.playerId))&&va(a.teams.map(i=>i.teamId))&&va(a.grounds.map(i=>i.groundId)),"duplicate world IDs"),a.players.forEach(i=>Oh(i,e));const o=new Set(a.players.map(i=>i.playerId));return Qa(a.teams.every(i=>va(i.squadIds)&&i.squadIds.every(r=>o.has(r))),"invalid squad references"),Qa(va(a.rulesIds)&&a.rulesIds.every(i=>t.includes(i)),"unknown rule references"),a}const Aa=m({rulesId:D(["LC_T20_01","LC_ODI_01","LC_RED5_01"]),inningsIndex:d,deliveryIndex:d,battingTeamId:l,bowlingTeamId:l,strikerId:l,nonStrikerId:l,bowlerId:l,keeperId:l,outfieldIds:O(l).length(9),endsBefore:m({north:l,south:l}),strikerEnd:_a,runs:d,wickets:d.max(9),legalBalls:d,allocatedBalls:Y.nullable(),targetToWin:Y.nullable(),freeHitPending:z(),ballAgeLegalBalls:d}),Go=m({stage:D(["DELIVERY","IMMEDIATE_PENALTY"]),legality:D(["LEGAL","WIDE","NO_BALL","DEAD"]),batRuns:d,extras:sr,completedRuns:d,attemptedRuns:d,boundary:D(["NONE","FOUR","SIX"]),dismissal:m({kind:D(["BOWLED","LBW","CAUGHT","RUN_OUT","STUMPED","HIT_WICKET"]),playerId:l,fielderId:l.nullable(),wicketEnd:_a}).nullable(),endsAfter:m({north:l.nullable(),south:l.nullable()}),batContact:z(),attemptedStroke:z(),shotSector:d.max(7).nullable(),trajectory:D(["GROUND","AERIAL","EDGE"]).nullable(),executedLength:D(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"]).nullable(),fieldOutcome:D(["NONE","STOP","DROP","CATCH","MISS","RUN_OUT"]),elapsedSeconds:d}),Lh=D(["INVALID_STRUCTURE","INVALID_CONTEXT","UNSUPPORTED_PENALTY","INVALID_EXTRAS","INVALID_BOUNDARY","INVALID_RUNNING","INVALID_DISMISSAL","INVALID_ENDS","INVALID_IMMEDIATE_PENALTY","UNSAFE_TOTAL"]),dl=m({event:Wo,delta:m({teamRuns:d,batterRuns:d,bowlerRuns:d,legalBalls:d.max(1),ballsFaced:d.max(1),wickets:d.max(1),bowlerWickets:d.max(1),deliveryAttempts:g(1)}),totals:m({runs:d,wickets:d.max(10),legalBalls:d,ballAgeLegalBalls:d}),strikerEndAfter:_a,nextStrikerId:l.nullable(),requiredBatterEnd:_a.nullable(),freeHitPending:z(),overCompleted:z(),inningsComplete:z(),result:Qt.nullable(),events:O(D(["DELIVERY_RECORDED","OVER_COMPLETED","INNINGS_COMPLETED","MATCH_COMPLETED"])).min(1),nextAction:D(["ADVANCE","SELECT_BATTER","SELECT_BOWLER","START_NEXT_INNINGS","NONE"])}),ba={id:l,source:C().min(1),description:C().min(1),reasoning:C().min(1),tags:O(l).min(1)},Nh=m({...ba,context:Aa,resolution:Go,expected:dl}),yh=m({...ba,context:fa(),resolution:fa(),expectedError:Lh}),Dh=m({...ba,rulesId:D(["LC_T20_01","LC_ODI_01","LC_RED5_01"]),teamIds:Kn([l,l]),innings:O(m({teamId:l,runs:d,wickets:d.max(10),legalBalls:d,complete:z()})).min(1).max(4),timeExpired:z(),expected:m({result:Qt.nullable(),targetToWin:Y.nullable(),phase:lr,nextAction:D(["ADVANCE","START_NEXT_INNINGS","NONE"])})}),Ch=m({...ba,trigger:D(["WICKET","INNINGS_COMPLETED","RAIN_DELAY","NEW_BALL","TARGET_REACHED"]),before:m({clock:Ta,inningsLegalBalls:d,ballAgeLegalBalls:d,runs:d,targetToWin:Y.nullable()}),input:m({attemptSeconds:d,wicketSeconds:d,overSeconds:d,delaySeconds:d,replacementSeconds:d,batRuns:d}),expected:m({clock:Ta,inningsLegalBalls:d,ballAgeLegalBalls:d,phase:lr,nextAction:D(["SELECT_BATTER","START_NEXT_INNINGS","ADVANCE","NONE"]),intervalSeconds:d,events:O(l)})}),kh=Gn("category",[m({...ba,category:g("PERSISTENCE"),before:m({durableRevision:d,lastSequence:d}),input:m({commandId:l,retryCommitted:z(),provisionalEvents:d,abortWrite:z()}),expected:m({durableRevision:d,lastSequence:d,extraCommittedEvents:d,returnOriginalReceipt:z(),resumeFromPreviousCheckpoint:z()})}),m({...ba,category:g("NRR"),input:m({runs:d,legalBalls:d,allocatedBalls:Y,allOut:z(),successfulChase:z()}),expected:m({battingDenominatorBalls:Y})})]);m({fixtureVersion:g("1.0.0"),authority:g("Lord_Cricket_XXVI_Technical_Design_V0_1(1).docx"),scorerImplemented:g(!1),deliveries:O(Nh).min(1),invalid:O(yh).min(1),terminal:O(Dh).min(1),clock:O(Ch).min(1),deferred:O(kh).min(1)}),m({context:Aa,resolution:Go});const Qe="LC_SCORING_V1",Bh=m({runs:d,ballsFaced:d,fours:d,sixes:d,dismissed:z()}),Ph=m({runsConceded:d,legalBalls:d,wickets:d,maidens:d}),xh=m({engineVersion:g(Qe),rulesId:D(["LC_T20_01","LC_ODI_01","LC_RED5_01"]),innings:cr,nextDeliveryIndex:d,batting:An(l,Bh),dismissals:An(l,sl),bowling:An(l,Ph),keeperId:l,outfieldIds:O(l).length(9),currentOverRuns:d}),se="LC_INTEGER_PROBABILITY_V1",ze="LC_EXP_LUT_V1",Be="synthetic-alpha-01",Hh=1e4,wa=4294967296,Fh=F().int().min(-2e4).max(2e4),gr=F().int().min(-1e5).max(1e5),Mh=F().int().min(-2e5).max(2e5),Vh=m({coefficientBp:gr,featureBp:Fh}),Wh=m({id:l,baseWeight:F().int().min(0).max(1e9),allowed:z(),interceptBp:Mh,terms:O(Vh).max(32)}),Ir=m({probabilityVersion:g(se),modelId:g(Be),modelHash:N,lutVersion:g(ze),lutHash:N,categories:O(Wh).min(1).max(32)}),Uh=Ir.extend({kind:g("NORMALISE_CATEGORIES")}),$h=Ir.extend({kind:g("SAMPLE_CATEGORY"),stageName:l,randomVersion:g("SHA256_COUNTER_V1"),address:$o}),Gh=Gn("kind",[Uh,$h]),ul=m({id:l,baseWeight:F().int().min(0).max(1e4)}),jh=m({manifest:m({modelId:g(Be),schemaVersion:g("1.0.0"),status:g("SYNTHETIC_ALPHA"),randomId:g("SHA256_COUNTER_V1"),fixedPointScale:g(Hh),expLutHash:N,featureSpecHash:N,variationIds:O(l),effects:m({overAroundWicket:g(!1),individualVariations:g(!1),moisture:g(!1),geometryEffects:g(!1),outfieldSpeed:g(!1)})}),probabilityVersion:g(se),lutVersion:g(ze),lutScale:g("1000000000000"),lutStepBp:g(100),lutMinDeltaBp:g(-16e4),lutMaxDeltaBp:g(0),logitMinBp:g(-8e4),logitMaxBp:g(8e4),coefficients:m({legality:An(l,An(l,gr)),contact:An(l,An(l,gr))}),featureSpec:m({maxTerms:g(32),fixedPointScale:g(1e4),termMultiplyRounding:g("NEAREST_TIES_AWAY_FROM_ZERO"),accumulationOrder:g("INTERCEPT_TERMS_IN_ARRAY_ORDER"),clipTiming:g("AFTER_SUM"),lutDeltaRounding:g("NEAREST_TIES_AWAY_FROM_ZERO"),categoryOrder:g("AS_SUPPLIED"),massAllocation:g("LARGEST_REMAINDER_CATEGORY_INDEX")}),expLutValues:O(F().int().min(1).max(1e12)).length(1601),baselines:m({legality:O(ul).length(3),contact:An(l,O(ul).length(6))})}),Yh=m({controlRating:F().int().min(0).max(100),fatigueBp:F().int().min(0).max(1e4),line:D(["OFF","STUMPS","LEG"]),effort:D(["CONSERVE","NORMAL","MAXIMUM"])}),zh=m({phase:D(["T20_EARLY","T20_MIDDLE","T20_LATE","ODI_EARLY","ODI_MIDDLE","ODI_LATE","RED_BALL"]),defenceRating:F().int().min(0).max(100),timingRating:F().int().min(0).max(100),powerRating:F().int().min(0).max(100),effectiveMovementBp:F().int().min(-1e4).max(1e4),aggression:F().int().min(0).max(4)}),jo="LC_CONDITIONAL_DELIVERY_V1",ml="synthetic-alpha-01-delivery-v1",Kh=D(["OFF","STUMPS","LEG"]),qh=D(["YORKER","FULL","GOOD","SHORT"]),Zh=D(["CONSERVE","NORMAL","MAXIMUM"]),Xh=D(["INNER","MIDDLE","DEEP"]),Jh=m({playerId:l,sector:d.max(7),depth:Xh,role:D(["NORMAL","SLIP","GULLY"]),catchingRating:yn,throwingRating:yn}),Qh=m({kind:g("GENERATE_DELIVERY"),generatorVersion:g(jo),stagePackId:g(ml),stagePackHash:N,randomVersion:g("SHA256_COUNTER_V1"),probabilityVersion:g(se),modelId:g(Be),modelHash:N,lutVersion:g(ze),lutHash:N,rulesHash:N,matchId:l,seed:C().min(1).max(256),attemptOrdinal:d,format:Te,phase:D(["T20_EARLY","T20_MIDDLE","T20_LATE","ODI_EARLY","ODI_MIDDLE","ODI_LATE","RED_BALL"]),context:Aa,bowling:m({bowlingStyle:Vo,controlRating:yn,movementRating:yn,fatigueBp:de,line:Kh,intendedLength:qh,effort:Zh,variationId:g("stock")}),batting:m({defenceRating:yn,timingRating:yn,powerRating:yn,rotationRating:yn,vsPaceRating:yn,vsSpinRating:yn,aggression:F().int().min(0).max(4),intent:D(["NORMAL","ROTATE","PROTECT"]),attemptedStroke:z(),shotSectorWeights:O(F().int().min(0).max(1e4)).length(8)}),conditions:m({seamBp:de,turnBp:de}),field:m({keeper:m({keepingRating:yn,catchingRating:yn,throwingRating:yn}),slots:O(Jh).length(9)})}),nf=m({stageName:l,address:$o,draw:F().int().min(0).max(4294967295),selectedCategoryId:l,categories:O(m({id:l,allowed:z(),logitBp:F().int().nullable(),lutIndex:F().int().nullable(),mass:d,cumulative:d})).min(1)}),ef=m({kind:g("GENERATED_DELIVERY"),generatorVersion:g(jo),modelHash:N,stagePackHash:N,internalOnly:g(!0),trace:O(nf).min(2),resolution:Go}),tf=m({worldPackId:g("fictional-eight-01"),schemaVersion:g("1.0.0"),worldGeneratorVersion:g("LC_FICTIONAL_WORLD_GENERATOR_V1"),worldSeed:C().min(1).max(256),generatorSourceSha256:N,provenanceSourceSha256:N,worldFileSha256:N,worldCanonicalSha256:N,worldByteLength:F().int().min(1).max(25e6),rulesIds:O(l).length(3),modelId:g("synthetic-alpha-01"),modelHash:N,stagePackId:g("synthetic-alpha-01-delivery-v1"),stagePackHash:N,randomId:g("SHA256_COUNTER_V1"),variationIds:O(l).min(1),provenance:g("FICTIONAL"),modelStatus:g("SYNTHETIC_ALPHA"),teamIds:O(l).length(8),groundIds:O(l).length(8),homeGroundIds:An(l,l)}),Ie=m({teamId:l,playerIds:O(l).length(11),captainId:l,keeperId:l}),gl=m({setup:dr,worldFileSha256:N,worldCanonicalSha256:N,rulesHash:N,modelHash:N,stagePackHash:N,setupVersion:g("LC_T20_SETUP_V1"),selectedTeams:Kn([Ie,Ie])}),af=m({setup:dr,worldFileSha256:N,worldCanonicalSha256:N,rulesHash:N,modelHash:N,stagePackHash:N,setupVersion:g("LC_ODI_SETUP_V1"),selectedTeams:Kn([Ie,Ie])}),of=m({setup:dr,worldFileSha256:N,worldCanonicalSha256:N,rulesHash:N,modelHash:N,stagePackHash:N,setupVersion:g("LC_RED5_SETUP_V1"),selectedTeams:Kn([Ie,Ie])}),Il="LC_T20_MATCH_V1",Ke="LC_T20_EVENT_CHAIN_V1",pr="LC_T20_CONDITIONS_V1",pl=m({engine:g(Il),eventChain:g(Ke),conditionPolicy:g(pr),conditionPolicyHash:N,setupHash:N,worldHash:N,rulesHash:N,modelHash:N,stagePackHash:N,randomVersion:g("SHA256_COUNTER_V1"),scoringVersion:g("LC_SCORING_V1"),probabilityVersion:g("LC_INTEGER_PROBABILITY_V1")}),hl=Gn("kind",[m({commandId:l,expectedRevision:d,actorId:l,kind:g("CONFIRM_TEAMS"),payload:m({})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("CALL_TOSS"),payload:m({teamId:l,call:D(["HEADS","TAILS"])})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("CHOOSE_INNINGS"),payload:m({teamId:l,choice:D(["BAT","BOWL"])})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_BATTER"),payload:m({teamId:l,playerId:l})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_BOWLER"),payload:m({teamId:l,bowlerId:l})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_FIELD"),payload:m({teamId:l,fieldSlots:O(m({slotId:l,playerId:l})).length(9)})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_BATTING_PLAN"),payload:Za}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_BOWLING_PLAN"),payload:Xa}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("ADVANCE"),payload:m({scope:D(["DELIVERY","OVER"])})})]),Yo=m({version:g(Ke),sequence:d.min(1),commandId:l,type:l,payload:fa(),previousHash:N,stateHash:N,eventHash:N}),rf=m({commandId:l,committedRevision:d.min(1),fromSequence:d.min(1),toSequence:d.min(1),lastEventHash:N}),no=m({version:g(Ke),genesisHash:N,finalEventHash:N,finalStateHash:N,eventCount:d,executionManifestHash:N}),hr=m({matchId:l,innings:O(m({battingTeamId:l,bowlingTeamId:l,runs:d,wickets:d,legalBalls:d,overs:C(),extras:m({wides:d,noBalls:d,byes:d,legByes:d,penalties:d}),batting:An(l,m({runs:d,ballsFaced:d,fours:d,sixes:d,dismissed:z()})),bowling:An(l,m({runsConceded:d,legalBalls:d,wickets:d,maidens:d})),fallOfWickets:O(m({playerId:l,runs:d,legalBalls:d,sequence:d})),targetToWin:d.nullable()})).length(2),result:Qt});m({caseId:l,seed:C().min(1).max(256),teamIds:Kn([l,l]),groundId:l,modelId:g("synthetic-alpha-01"),rulesId:g("LC_T20_01"),stagePackId:g("synthetic-alpha-01-delivery-v1"),fixtureCaptainPolicyId:g("LC_FIXTURE_CAPTAIN_V1"),expectedFinalEventHash:N.nullable(),expectedScorecardSha256:N.nullable(),oracleStatus:D(["NOT_AUTHORED_UNTIL_PASS_07B","GENERATED_FROM_PRODUCTION_NOT_INDEPENDENT"])});const fl="LC_ODI_MATCH_V1",qe="LC_ODI_EVENT_CHAIN_V1",fr="LC_ODI_CONDITIONS_V1",El=m({engine:g(fl),eventChain:g(qe),conditionPolicy:g(fr),conditionPolicyHash:N,setupHash:N,worldHash:N,rulesHash:N,modelHash:N,stagePackHash:N,randomVersion:g("SHA256_COUNTER_V1"),scoringVersion:g("LC_SCORING_V1"),probabilityVersion:g("LC_INTEGER_PROBABILITY_V1")}),Sl=Gn("kind",[m({commandId:l,expectedRevision:d,actorId:l,kind:g("CONFIRM_TEAMS"),payload:m({})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("CALL_TOSS"),payload:m({teamId:l,call:D(["HEADS","TAILS"])})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("CHOOSE_INNINGS"),payload:m({teamId:l,choice:D(["BAT","BOWL"])})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_BATTER"),payload:m({teamId:l,playerId:l})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_BOWLER"),payload:m({teamId:l,bowlerId:l})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_FIELD"),payload:m({teamId:l,fieldSlots:O(m({slotId:l,playerId:l})).length(9)})}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_BATTING_PLAN"),payload:Za}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("SET_BOWLING_PLAN"),payload:Xa}),m({commandId:l,expectedRevision:d,actorId:l,kind:g("ADVANCE"),payload:m({scope:D(["DELIVERY","OVER"])})})]),_l=m({version:g(qe),sequence:d.min(1),commandId:l,type:l,payload:fa(),previousHash:N,stateHash:N,eventHash:N}),sf=m({commandId:l,committedRevision:d.min(1),fromSequence:d.min(1),toSequence:d.min(1),lastEventHash:N}),Tl=m({version:g(qe),genesisHash:N,finalEventHash:N,finalStateHash:N,eventCount:d,executionManifestHash:N}),cf=m({matchId:l,innings:O(m({battingTeamId:l,bowlingTeamId:l,runs:d,wickets:d,legalBalls:d,overs:C(),extras:m({wides:d,noBalls:d,byes:d,legByes:d,penalties:d}),batting:An(l,m({runs:d,ballsFaced:d,fours:d,sixes:d,dismissed:z()})),bowling:An(l,m({runsConceded:d,legalBalls:d,wickets:d,maidens:d})),fallOfWickets:O(m({playerId:l,runs:d,legalBalls:d,sequence:d})),targetToWin:d.nullable()})).length(2),result:Qt});m({caseId:l,seed:C().min(1).max(256),teamIds:Kn([l,l]),groundId:l,modelId:g("synthetic-alpha-01"),rulesId:g("LC_ODI_01"),stagePackId:g("synthetic-alpha-01-delivery-v1"),fixtureCaptainPolicyId:g("LC_FIXTURE_CAPTAIN_V1"),expectedFinalEventHash:N.nullable(),expectedScorecardSha256:N.nullable(),oracleStatus:D(["NOT_AUTHORED_UNTIL_PASS_07B","GENERATED_FROM_PRODUCTION_NOT_INDEPENDENT"])});const Rl="LC_RED5_MATCH_V1",nt="LC_RED5_EVENT_CHAIN_V1",Er="LC_RED5_CONDITIONS_V1",lf=m({day:F().int().min(1).max(5),localSeconds:F().int().min(0).max(24*3600),phase:D(["PLAY","LUNCH","TEA","INNINGS_INTERVAL","STUMPS","RAIN","COMPLETE"]),dayLegalBalls:d,finalHourActive:z(),finalHourBallsRemaining:d,overMustFinish:z(),delaySecondsToday:d}),vl=m({engine:g(Rl),eventChain:g(nt),conditionPolicy:g(Er),conditionPolicyHash:N,setupHash:N,worldHash:N,rulesHash:N,modelHash:N,stagePackHash:N,randomVersion:g("SHA256_COUNTER_V1"),scoringVersion:g("LC_SCORING_V1"),probabilityVersion:g("LC_INTEGER_PROBABILITY_V1")}),Pe=(n,e)=>m({commandId:l,expectedRevision:d,actorId:l,kind:g(n),payload:e}),Al=Gn("kind",[Pe("CONFIRM_TEAMS",m({})),Pe("CALL_TOSS",m({teamId:l,call:D(["HEADS","TAILS"])})),Pe("CHOOSE_INNINGS",m({teamId:l,choice:D(["BAT","BOWL"])})),Pe("SET_BATTER",m({teamId:l,playerId:l})),Pe("SET_BOWLER",m({teamId:l,bowlerId:l})),Pe("SET_FIELD",m({teamId:l,fieldSlots:O(m({slotId:l,playerId:l})).length(9)})),Pe("SET_BATTING_PLAN",Za),Pe("SET_BOWLING_PLAN",Xa),Pe("ADVANCE",m({scope:D(["DELIVERY","OVER"])})),Pe("DECLARE",m({teamId:l})),Pe("CHOOSE_FOLLOW_ON",m({teamId:l,enforce:z()})),Pe("TAKE_NEW_BALL",m({teamId:l})),Pe("ADD_RAIN_DELAY",m({seconds:F().int().min(60).max(6*3600)}))]),bl=m({version:g(nt),sequence:d.min(1),commandId:l,type:l,payload:fa(),previousHash:N,stateHash:N,eventHash:N}),df=m({commandId:l,committedRevision:d.min(1),fromSequence:d.min(1),toSequence:d.min(1),lastEventHash:N}),wl=m({version:g(nt),genesisHash:N,finalEventHash:N,finalStateHash:N,eventCount:d,executionManifestHash:N}),uf=m({battingTeamId:l,bowlingTeamId:l,runs:d,wickets:d,legalBalls:d,overs:C(),declared:z(),batting:An(l,m({runs:d,ballsFaced:d,fours:d,sixes:d,dismissed:z()})),bowling:An(l,m({runsConceded:d,legalBalls:d,wickets:d,maidens:d}))}),mf=m({matchId:l,innings:O(uf).max(4),result:Qt,clock:lf,followOnEnforced:z()}),gf=m({competitionVersion:g("LC_T20_LEAGUE_COMPETITION_V1"),competitionId:g("LC_T20_LEAGUE_01"),format:g("T20"),worldPackId:g("fictional-eight-01"),worldCanonicalSha256:N,teamIds:O(l).length(8),groundIds:O(l).length(8),homeGroundIds:An(l,l),teamCount:g(8),rounds:g(14),matchesPerRound:g(4),totalFixtures:g(56),roundSpacingDays:g(3),playoffs:g(!1),points:m({win:g(2),tie:g(1),noResult:g(1),loss:g(0)}),tableOrder:Kn([g("POINTS"),g("WINS"),g("NET_RUN_RATE"),g("HEAD_TO_HEAD_POINTS"),g("TEAM_ID")]),rainAdjustedNrr:g(!1),schedulerAlgorithm:g("CIRCLE_REVERSE_VENUES_V1")});m({scheduleVersion:g("LC_T20_SEASON_SCHEDULE_V1"),seasonId:l,gameId:l,competitionId:g("LC_T20_LEAGUE_01"),worldPackId:g("fictional-eight-01"),worldCanonicalSha256:N,seasonSeed:C().min(1).max(256),startDate:gn(),teamIds:O(l).length(8),groundIds:O(l).length(8),homeGroundIds:An(l,l)});const Ol=m({fixtureId:l,matchId:l,ordinal:F().int().min(0).max(55),roundNumber:Y.max(14),roundFixtureIndex:Y.max(4),matchDayDate:gn(),homeTeamId:l,awayTeamId:l,groundId:l,matchSeed:N,status:g("SCHEDULED")}),Ll=m({roundNumber:Y.max(14),matchDayDate:gn(),fixtureIds:O(l).length(4)}),Nl={scheduleVersion:g("LC_T20_SEASON_SCHEDULE_V1"),schedulerAlgorithm:g("CIRCLE_REVERSE_VENUES_V1"),seasonId:l,gameId:l,competitionId:g("LC_T20_LEAGUE_01"),worldPackId:g("fictional-eight-01"),worldCanonicalSha256:N,seasonSeedHash:N,startDate:gn(),teamIds:O(l).length(8),groundIds:O(l).length(8),homeGroundIds:An(l,l),rounds:O(Ll).length(14),fixtures:O(Ol).length(56)};m(Nl);const If=m({...Nl,scheduleSha256:N}),pf=m({conditionPolicyVersion:g("LC_T20_CAREER_CONDITION_V1"),maxFatigueBp:g(1e4),restRecoveryPerDayBp:g(2e3),practiceRecoveryPerDayBp:g(1400),noRandomInjuries:g(!0)}),hf=m({playerId:l,startDate:gn(),endDate:gn(),reason:C().min(1).max(240),source:g("MANUAL_FIXTURE_PACK")}),ff=m({availabilityVersion:g("LC_T20_AVAILABILITY_PACK_V1"),packId:l,worldPackId:g("fictional-eight-01"),worldCanonicalSha256:N,entries:O(hf).max(320)}),Sr=m({playerId:l,fatigueBp:de,lastUpdatedDate:gn()}),_r=m({matchCompletionKey:l,matchId:l,matchDayDate:gn(),payloadSha256:N}),Tr=m({deltaVersion:g("LC_T20_MATCH_CONDITION_DELTA_V1"),matchCompletionKey:l,matchId:l,matchDayDate:gn(),playerFatigueDeltaBp:An(l,de)}),yl={careerStateVersion:g("LC_T20_CAREER_DAY_STATE_V1"),conditionPolicyVersion:g("LC_T20_CAREER_CONDITION_V1"),careerId:l,gameId:l,seasonId:l,competitionId:g("LC_T20_LEAGUE_01"),scheduleVersion:g("LC_T20_SEASON_SCHEDULE_V1"),scheduleSha256:N,worldPackId:g("fictional-eight-01"),worldCanonicalSha256:N,availabilityPackId:l,availabilityPackSha256:N,startDate:gn(),finalScheduledDate:gn(),currentDate:gn(),revision:F().int().min(0).max(Number.MAX_SAFE_INTEGER),playerConditions:O(Sr).length(160),appliedMatchConditions:O(_r).max(56)};m(yl),m({...yl,stateSha256:N});const Ef=m({playerId:l,fatigueBp:de,availability:D(["AVAILABLE","UNAVAILABLE"]),availabilityReason:C().min(1).max(240).nullable(),unavailableThrough:gn().nullable()});m({teamId:l,date:gn(),players:O(Ef).length(20)}),m({command:g("ADVANCE_DAY"),previousDate:gn(),currentDate:gn(),recoveredPlayers:d,recoveryPerPlayerBp:g(2e3),revision:F().int().min(1).max(Number.MAX_SAFE_INTEGER),stateSha256:N});const Sf=m({trainingPolicyVersion:g("LC_T20_CAREER_TRAINING_V1"),readinessMinRatingDelta:g(-3),readinessMaxRatingDelta:g(3),readinessPracticeGainPerDay:g(1),readinessDecayPerDay:g(1),restRecoveryPerDayBp:g(2e3),practiceRecoveryPerDayBp:g(1400),noPermanentAttributeGrowth:g(!0)}),Oa=D(["REST","BATTING_PRACTICE","BOWLING_PRACTICE","FIELDING_PRACTICE"]),Dl=m({playerId:l,batting:F().int().min(-3).max(3),bowling:F().int().min(-3).max(3),fielding:F().int().min(-3).max(3),lastUpdatedDate:gn()}),Cl=m({playerId:l,directive:Oa}),kl={careerStateVersion:g("LC_T20_CAREER_DAY_STATE_V2"),conditionPolicyVersion:g("LC_T20_CAREER_CONDITION_V1"),trainingPolicyVersion:g("LC_T20_CAREER_TRAINING_V1"),careerId:l,gameId:l,seasonId:l,competitionId:g("LC_T20_LEAGUE_01"),scheduleVersion:g("LC_T20_SEASON_SCHEDULE_V1"),scheduleSha256:N,worldPackId:g("fictional-eight-01"),worldCanonicalSha256:N,availabilityPackId:l,availabilityPackSha256:N,startDate:gn(),finalScheduledDate:gn(),currentDate:gn(),revision:F().int().min(0).max(Number.MAX_SAFE_INTEGER),playerConditions:O(Sr).length(160),playerReadiness:O(Dl).length(160),trainingAssignments:O(Cl).length(160),appliedMatchConditions:O(_r).max(56)};m(kl);const _f=m({...kl,stateSha256:N});m({command:g("SET_TRAINING_DIRECTIVE"),playerId:l,directive:Oa,effectiveDate:gn(),expectedRevision:F().int().min(0).max(Number.MAX_SAFE_INTEGER)}),m({command:g("SET_TRAINING_DIRECTIVE"),playerId:l,previousDirective:Oa,directive:Oa,changed:z(),revision:F().int().min(0).max(Number.MAX_SAFE_INTEGER),stateSha256:N}),m({command:g("ADVANCE_DAY"),previousDate:gn(),currentDate:gn(),restPlayers:d,practicePlayers:d,recoveredPlayers:d,readinessChangedPlayers:d,restRecoveryPerPlayerBp:g(2e3),practiceRecoveryPerPlayerBp:g(1400),revision:F().int().min(1).max(Number.MAX_SAFE_INTEGER),stateSha256:N});const Bl=m({playerId:l,fatigueBp:de,availability:D(["AVAILABLE","UNAVAILABLE"]),availabilityReason:C().min(1).max(240).nullable(),unavailableThrough:gn().nullable(),directive:Oa,battingReadiness:F().int().min(-3).max(3),bowlingReadiness:F().int().min(-3).max(3),fieldingReadiness:F().int().min(-3).max(3)});m({teamId:l,date:gn(),players:O(Bl).length(20)});const Tf=m({policyVersion:g("LC_T20_OFFSCREEN_POLICY_V1"),executionVersion:g("LC_T20_OFFSCREEN_FIXTURE_V1"),selectionPolicyId:g("LC_SEASON_XI_BASELINE_V1"),captainPolicyId:g("LC_FIXTURE_CAPTAIN_V1"),conditionDeltaPolicyId:g("LC_ENGINE_FINAL_FATIGUE_DELTA_V1"),matchEngineVersion:g("LC_T20_MATCH_V1"),selectionScorePolicy:g("SUM_SUPPORTED_T20_SKILLS_PLUS_AREA_READINESS_V1"),unavailablePlayersExcluded:g(!0),fatigueSelectionEffect:g("LOWER_FATIGUE_STABLE_TIEBREAK_ONLY"),minimumNonKeeperBowlingCapable:g(5),requiresKeeper:g(!0),noFutureRandomAccess:g(!0),noAlternateMatchSimulator:g(!0)}),Pl={executionVersion:g("LC_T20_OFFSCREEN_FIXTURE_V1"),policyVersion:g("LC_T20_OFFSCREEN_POLICY_V1"),fixtureId:l,matchId:l,roundNumber:F().int().min(1).max(14),roundFixtureIndex:F().int().min(1).max(4),matchDayDate:gn(),homeTeamId:l,awayTeamId:l,groundId:l,scheduleSha256:N,matchSeedHash:N,careerRevisionBefore:d,careerRevisionAfter:d,careerStateSha256Before:N,careerStateSha256After:N,selectionPolicyId:g("LC_SEASON_XI_BASELINE_V1"),captainPolicyId:g("LC_FIXTURE_CAPTAIN_V1"),conditionDeltaPolicyId:g("LC_ENGINE_FINAL_FATIGUE_DELTA_V1"),selectedTeams:Kn([Ie,Ie]),eventChain:no,eventLogSha256:N,commandLogSha256:N,scorecard:hr,scorecardSha256:N,conditionDelta:Tr,conditionDeltaSha256:N};m(Pl);const xl=m({...Pl,outcomeSha256:N}),Hl={executionVersion:g("LC_T20_OFFSCREEN_ROUND_V1"),seasonId:l,roundNumber:F().int().min(1).max(14),matchDayDate:gn(),scheduleSha256:N,userTeamId:l.nullable(),skippedUserFixtureId:l.nullable(),executedFixtureIds:O(l).max(4),outcomes:O(xl).max(4),careerRevisionBefore:d,careerRevisionAfter:d,careerStateSha256Before:N,careerStateSha256After:N};m(Hl),m({...Hl,executionSha256:N});const Fl=F().int().min(Number.MIN_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),zo=m({completionVersion:g("LC_T20_SEASON_MATCH_COMPLETION_V1"),seasonId:l,scheduleSha256:N,fixtureId:l,matchId:l,fixtureOrdinal:F().int().min(0).max(55),roundNumber:Y.max(14),matchDayDate:gn(),homeTeamId:l,awayTeamId:l,source:D(["OFFSCREEN","USER_MATCH"]),sourceCompletionSha256:N,selectedTeams:Kn([Ie,Ie]),scorecard:hr,scorecardSha256:N}),Rf=m({fixtureId:l,matchId:l,fixtureOrdinal:F().int().min(0).max(55),roundNumber:Y.max(14),homeTeamId:l,awayTeamId:l,sourceCompletionSha256:N,resultKind:D(["WIN","TIE","NO_RESULT"]),winnerTeamId:l.nullable(),homePoints:d.max(2),awayPoints:d.max(2),nrrEligible:z(),homeRuns:d,homeBalls:d,awayRuns:d,awayBalls:d}),Rr=m({rank:Y.max(8),teamId:l,played:d.max(14),wins:d.max(14),losses:d.max(14),ties:d.max(14),noResults:d.max(14),points:d.max(28),runsFor:d,ballsFor:d,runsAgainst:d,ballsAgainst:d,nrrNumerator:Fl,nrrDenominator:Y.nullable(),nrrX1000:Fl.nullable(),headToHeadPoints:d.max(28)}),vr=m({playerId:l,teamId:l,matches:d.max(14),runs:d,dismissals:d.max(14),ballsFaced:d,fours:d,sixes:d,battingAverageX100:d.nullable(),strikeRateX100:d.nullable(),bowlingRunsConceded:d,bowlingLegalBalls:d,bowlingWickets:d,maidens:d,bowlingAverageX100:d.nullable(),economyX100:d.nullable(),bowlingStrikeRateX100:d.nullable()}),Ko=m({playerId:l,teamId:l,value:d}),qo=m({runs:O(Ko).max(10),wickets:O(Ko).max(10)}),vf=m({appliedCount:d.max(56),highestAppliedFixtureOrdinal:F().int().min(0).max(55).nullable(),missingFixtureOrdinals:O(F().int().min(0).max(55)).max(56)}),Ml=m({projectionVersion:g("LC_T20_SEASON_PROJECTION_V1"),seasonId:l,scheduleSha256:N,competitionId:g("LC_T20_LEAGUE_01"),revision:d.max(56),cursor:vf,appliedMatches:O(Rf).max(56),table:O(Rr).length(8),players:O(vr).max(160),leaders:qo}),Af=1e6,bf="LC_COMPLETED_CAREER_MATCH_EVENT_ARCHIVE_V1",Vl={seasonStateVersion:g("LC_T20_SEASON_STATE_V1"),seasonId:l,gameId:l,careerId:l,controlledTeamId:l.nullable(),schedule:If,careerState:_f,projection:Ml,completedMatches:O(zo).max(56),revision:d,phase:D(["ACTIVE","COMPLETE"])};m(Vl);const Wl=m({...Vl,stateSha256:N}),wf=m({saveId:l,kind:D(["AUTO","MANUAL","IMPORTED"]),title:C().min(1).max(240),seasonId:l,careerId:l,controlledTeamId:l.nullable(),currentDate:gn(),revision:d,completedFixtures:d.max(56),phase:D(["ACTIVE","COMPLETE"]),stateSha256:N,updatedAt:pt()});m({commandId:l,requestCanonical:C(),responseJson:C(),committedRevision:d});const Of=m({archiveVersion:g("LC_T20_SEASON_ARCHIVE_V1"),seasonId:l,careerId:l,scheduleSha256:N,stateSha256:N,projectionRevision:g(56),fixtureCount:g(56),completedAt:pt(),championTeamId:l,finalTable:O(Rr).length(8),leaders:qo,completionKeys:O(l).length(56)}),Lf=m({...Of.shape,archiveSha256:N});m({saveId:l,requestedGeneration:F().int().min(0).max(2).nullable(),recoveredGeneration:F().int().min(0).max(2).nullable(),recoveredCheckpointSerial:d.nullable(),recoveredRevision:d.nullable(),corruptedGenerations:O(F().int().min(0).max(2)).max(3)});const Ar=m({archiveVersion:g("LC_T20_SEASON_PORTABLE_V1"),saveSchema:g("LC_SEASON_SAVE_V1"),exportedAt:pt(),summary:wf,files:An(C().min(1),m({bytes:d,sha256:N}))});Ar.extend({archiveVersion:g("LC_T20_SEASON_PORTABLE_V2"),saveSchema:g("LC_SEASON_SAVE_V2_PRESENTATION"),worldCopySha256:N});const Nf=m({archiveVersion:g(bf),seasonId:l,scheduleSha256:N,fixtureId:l,matchId:l,fixtureOrdinal:d.max(55),roundNumber:F().int().min(1).max(14),matchDayDate:gn(),source:D(["OFFSCREEN","USER_MATCH"]),sourceCompletionSha256:N,scorecardSha256:N,setupRequest:gl,eventChain:no,eventCount:d.min(1).max(600),finalEventHash:N,eventsSha256:N,events:O(Yo).min(1).max(600),byteLength:d.min(1).max(Af)});m({...Nf.shape,archiveSha256:N});const yf=m({generation:F().int().min(0).max(2),checkpointSerial:d,revision:d,completedFixtures:d.max(56),currentDate:gn(),phase:D(["ACTIVE","COMPLETE"]),stateSha256:N,createdAt:pt()});m({saveId:l,title:C().min(1).max(240),currentSerial:d,currentGeneration:F().int().min(0).max(2),corruptedGenerations:O(F().int().min(0).max(2)).max(3),validGenerations:O(yf).max(3)}),Ar.extend({archiveVersion:g("LC_T20_SEASON_PORTABLE_V3_EVENT_ARCHIVES"),saveSchema:D(["LC_SEASON_SAVE_V1","LC_SEASON_SAVE_V2_PRESENTATION"]),worldCopySha256:N.optional(),matchEventArchiveCount:d.min(1).max(56)});const ln=200,Df="LC_PERSISTENT_WORLD_IDENTITY_V1",Cf="LC_COMPLETED_SEASON_RECORD_V1",kf="LC_PERSISTENT_CAREER_PROJECTION_V1",Bf="LC_PERSISTENT_WORLD_ROLLOVER_RECEIPT_V1",Pf="LC_PERSISTENT_WORLD_STATE_V1",xf="LC_PERSISTENT_WORLD_SAVE_V1",Hf="LC_PERSISTENT_WORLD_SAVE_V1_PRESENTATION",Ff="LC_PERSISTENT_WORLD_PORTABLE_V1",br=m({worldIdentityVersion:g(Df),worldId:l,worldPackId:l,worldCanonicalSha256:N,baseSeed:C().min(1).max(256),originKind:D(["NEW_PERSISTENT_CAREER","COPIED_FROM_SINGLE_SEASON_V1"]),sourceSingleSeasonSaveId:l.nullable(),sourceSingleSeasonFinalStateSha256:N.nullable()}),Mf=m({completedSeasonVersion:g(Cf),seasonNumber:Y.max(ln),calendarYear:F().int().min(1900).max(9999),seasonId:l,gameId:l,competitionId:g("LC_T20_LEAGUE_01"),startDate:gn(),endDate:gn(),scheduleSha256:N,finalSeasonStateSha256:N,championTeamId:l,runnerUpTeamId:l,seasonArchive:Lf,table:O(Rr).length(8),players:O(vr).max(1e4),leaders:qo,completedMatches:O(zo).length(56)}),wr=m({...Mf.shape,recordSha256:N}),Vf=m({playerId:l,teamId:l,seasonsPlayed:d.max(ln),matches:d,battingInnings:d,notOuts:d,runs:d,dismissals:d,ballsFaced:d,fours:d,sixes:d,fifties:d,hundreds:d,ducks:d,highScoreRuns:d,highScoreNotOut:z(),battingAverageX100:d.nullable(),strikeRateX100:d.nullable(),bowlingInnings:d,bowlingRunsConceded:d,bowlingLegalBalls:d,bowlingWickets:d,maidens:d,bestBowlingWickets:d,bestBowlingRuns:d.nullable(),bowlingAverageX100:d.nullable(),economyX100:d.nullable(),bowlingStrikeRateX100:d.nullable()}),Wf=m({teamId:l,seasonsCompleted:d.max(ln),titles:d.max(ln),runnerUpFinishes:d.max(ln),played:d,wins:d,losses:d,ties:d,noResults:d,points:d,runsFor:d,ballsFor:d,runsAgainst:d,ballsAgainst:d}),Uf=m({seasonNumber:Y.max(ln),calendarYear:F().int().min(1900).max(9999),seasonId:l,championTeamId:l,runnerUpTeamId:l,leadingRunScorer:Ko.nullable(),leadingWicketTaker:Ko.nullable(),finalSeasonStateSha256:N}),$f=m({careerProjectionVersion:g(kf),worldId:l,completedSeasonCount:d.max(ln),activeSeasonNumber:Y.max(ln),activeSeasonMatchesApplied:d.max(56),totalMatchesApplied:d,rollOfHonour:O(Uf).max(ln),teamHistory:O(Wf).length(8),players:O(Vf).max(1e4),leaders:qo}),Or=m({...$f.shape,projectionSha256:N}),Lr=m({receiptVersion:g(Bf),fromSeasonNumber:Y.max(ln-1),toSeasonNumber:Y.max(ln),closedSeasonId:l,closedSeasonStateSha256:N,closedSeasonRecordSha256:N,nextSeasonId:l,nextStartDate:gn(),nextScheduleSha256:N}),Gf=m({worldStateVersion:g(Pf),worldIdentity:br,careerId:l,controlledTeamId:l.nullable(),currentSeasonNumber:Y.max(ln),currentCalendarYear:F().int().min(1900).max(9999),currentSeason:Wl,completedSeasons:O(wr).max(ln-1),careerProjection:Or,lastRolloverReceipt:Lr.nullable(),revision:d});m({...Gf.shape,stateSha256:N});const Nr=m({saveId:l,kind:D(["AUTO","MANUAL","IMPORTED"]),title:C().min(1).max(240),worldId:l,careerId:l,controlledTeamId:l.nullable(),currentSeasonNumber:Y.max(ln),currentCalendarYear:F().int().min(1900).max(9999),completedSeasonCount:d.max(ln-1),seasonId:l,currentDate:gn(),revision:d,completedFixtures:d.max(56),phase:D(["ACTIVE","COMPLETE"]),stateSha256:N,updatedAt:pt()});m({archiveVersion:g(Ff),saveSchema:D([xf,Hf]),exportedAt:pt(),summary:Nr,careerProjectionSha256:N,worldCopySha256:N.optional(),matchEventArchiveCount:d.max(ln*56),files:An(C().min(1),m({bytes:d,sha256:N}))});const Ul=25e6,yr=["T20","ODI","RED_BALL"],Dr=Sa.partial(),jf=m({T20:Dr.optional(),ODI:Dr.optional(),RED_BALL:Dr.optional()}),Yf=m({T20:d.optional(),ODI:d.optional(),RED_BALL:d.optional()}),zf=wt.omit({skills:!0,exposureBalls:!0,provenance:!0}).extend({skills:jf.optional(),exposureBalls:Yf.optional()}),Kf=m({version:g("LC_ROSTER_IMPORT_V1"),sourceId:l,world:Ja.omit({players:!0}).extend({players:O(zf).min(1).max(1e4)})}),xe=m({version:g("LC_STAGED_ROSTER_PACK_V1"),sourceText:C().max(Ul),sourceHash:N,world:Ja,priorFields:O(m({playerId:l,format:D(yr),fields:O(C()),exposureMissing:z()}))}),$l=m({teamId:l,playerIds:O(l).length(11),captainId:l,keeperId:l}),Gl=m({groundId:l,teams:Kn([$l,$l])}),jl=m({gameId:l,matchId:l,seed:C().min(1).max(256),format:D(yr),selection:Gl}),Yl=pl.extend({engine:g("LC_T20_MATCH_ROSTER_V2")}),qf=El.extend({engine:g("LC_ODI_MATCH_ROSTER_V2")}),Zf=vl.extend({engine:g("LC_RED5_MATCH_ROSTER_V2")}),Xf=m({seasonId:l,gameId:l,seasonSeed:C().min(1).max(256),startDate:gn()}),zl=m({version:g("LC_T20_ROSTER_SCHEDULE_V2"),request:Xf,rosterPackHash:N,worldHash:N,teamIds:O(l).length(8),groundIds:O(l).length(8),homeGroundIds:An(l,l),rounds:O(Ll).length(14),fixtures:O(Ol).length(56),scheduleSha256:N}),Kl=m({version:g("LC_T20_ROSTER_CAREER_DAY_V3"),careerId:l,scheduleSha256:N,rosterPackHash:N,worldHash:N,startDate:gn(),finalScheduledDate:gn(),currentDate:gn(),revision:d,playerConditions:O(Sr).min(22).max(1e4),playerReadiness:O(Dl).min(22).max(1e4),trainingAssignments:O(Cl).min(22).max(1e4),appliedMatchConditions:O(_r).max(56),stateSha256:N}),Jf=xl.extend({executionVersion:g("LC_T20_ROSTER_OFFSCREEN_FIXTURE_V2"),policyVersion:g("LC_T20_ROSTER_OFFSCREEN_POLICY_V2"),engineManifest:Yl}),Qf=zo.extend({completionVersion:g("LC_T20_ROSTER_SEASON_COMPLETION_V2")}),ql=Ml.extend({projectionVersion:g("LC_T20_ROSTER_SEASON_PROJECTION_V2"),players:O(vr).max(1e4)}),nE=m({version:g("LC_T20_ROSTER_MANAGED_FIXTURE_V1"),completion:Qf,conditionDelta:Tr,outcomeSha256:N});m({version:g("LC_T20_ROSTER_SEASON_STATE_V2"),careerId:l,controlledTeamId:l,schedule:zl,careerState:Kl,projection:ql,outcomes:O(_e([Jf,nE])).max(56),revision:d,phase:D(["ACTIVE","COMPLETE"]),stateSha256:N}),Ar.extend({archiveVersion:g("LC_T20_ROSTER_SEASON_PORTABLE_V1"),saveSchema:g("LC_SEASON_SAVE_V3_ROSTER"),rosterPackSha256:N});const Zl="LC_PLAYER_LIFECYCLE_MODEL_FICTIONAL_V1",eE="LC_PLAYER_LIFECYCLE_STATE_V1",tE="LC_PLAYER_LIFECYCLE_STATE_V2_BOUNDED_PACKS",aE=2,oE="LC_T20_LIFECYCLE_SEASON_STATE_V1",iE="LC_COMPLETED_CAREER_MATCH_EVENT_ARCHIVE_V2_LIFECYCLE",rE="LC_PERSISTENT_WORLD_STATE_V2",sE="LC_PERSISTENT_WORLD_SAVE_V2",cE="LC_PERSISTENT_WORLD_SAVE_V2_PRESENTATION",lE="LC_PERSISTENT_WORLD_PORTABLE_V2_LIFECYCLE",dE=18,uE=22,mE=3,Xl=m({modelVersion:g(Zl),calibrationStatus:g("FICTIONAL_PLACEHOLDER"),disclaimer:C().min(1).max(400),minPermanentSkill:F().int().min(10).max(40),maxPermanentSkill:F().int().min(80).max(100),youthMinAgeYears:F().int().min(16).max(20),youthMaxAgeYears:F().int().min(17).max(22),growthWindowMaxAgeYears:F().int().min(22).max(28),primeWindowMaxAgeYears:F().int().min(27).max(33),earliestVoluntaryRetirementAgeYears:F().int().min(32).max(38),mandatoryRetirementAgeYears:F().int().min(37).max(45),minSquadKeepers:F().int().min(1).max(4),minSquadBowlingCapable:F().int().min(5).max(12)}),gE=m({playerId:l,battingPracticeDays:d.max(366),bowlingPracticeDays:d.max(366),fieldingPracticeDays:d.max(366),restDays:d.max(366)}),eo=F().int().min(-25).max(25),Jl=m({battingDelta:eo,bowlingDelta:eo,fieldingDelta:eo,keepingDelta:eo,staminaDelta:eo}),IE=m({playerId:l,teamId:l,ageBefore:F().int().min(15).max(60),ageAfter:F().int().min(16).max(61),matchesPlayed:d.max(56),ballsFaced:d,ballsBowled:d,battingPracticeDays:d.max(366),bowlingPracticeDays:d.max(366),fieldingPracticeDays:d.max(366),restDays:d.max(366),deltas:Jl,phaseLabel:D(["YOUTH_GROWTH","EARLY_DEVELOPMENT","PRIME_MAINTENANCE","VETERAN_DECLINE"])}),pE=m({playerId:l,player:wt,debutSeasonNumber:Y.max(ln),retiredAfterSeasonNumber:Y.max(ln),retiredCalendarYear:F().int().min(1900).max(9999),ageAtRetirement:F().int().min(18).max(65),lastTeamId:l,careerTeamIds:O(l).min(1).max(8),retirementReason:D(["AGE_AND_WORKLOAD","VETERAN_TRANSITION","MANDATORY_AGE_LIMIT"])}),hE=D(["ACADEMY_GRADUATE","FIRST_TEAM_PROSPECT","HIGH_CEILING_PROSPECT"]),Ql=D(["BALANCED","BATTING_PRACTICE","BOWLING_PRACTICE","FIELDING_PRACTICE"]),fE=m({prospectId:l,teamId:l,generatedInSeasonNumber:Y.max(ln),generatedCalendarYear:F().int().min(1900).max(9999),intakeRank:F().int().min(1).max(mE),fictionalCeilingTier:hE,academyFocus:Ql,queuedForPromotion:z(),promotedInSeasonNumber:Y.max(ln).nullable(),player:wt}),EE=m({fromSeasonNumber:Y.max(ln-1),toSeasonNumber:Y.max(ln),calendarYear:F().int().min(1900).max(9999),agedPlayerCount:d.max(1e4),developedPlayers:O(IE).max(1e4),retiredPlayerIds:O(l).max(1e4),promotedYouthIds:O(l).max(1e4),generatedYouthIds:O(l).max(1e4)}),SE=m({...EE.shape,transitionSha256:N}),_E=m({playerId:l,debutSeasonNumber:Y.max(ln),careerEntryT20Skills:Sa,priorSeasonT20Skills:Sa,lastSeasonDelta:Jl}),Cr=m({lifecycleVersion:g(eE),model:Xl,activeWorld:Ja,activeRosterPack:xe.nullable(),historicalRosterPacks:O(xe).max(ln*4),skillLedger:O(_E).min(22).max(1e4),seasonTrainingExposure:O(gE).min(22).max(1e4),retiredPlayers:O(pE).max(1e4),youthAcademy:O(fE).max(1e4),transitions:O(SE).max(ln),squadRegistrationRevision:d}),kr=m({...Cr.shape,lifecycleSha256:N}),nd=Cr.extend({lifecycleVersion:g(tE),historicalRosterPacks:O(xe).max(aE)}),ed=m({...nd.shape,lifecycleSha256:N});Gn("lifecycleVersion",[Cr,nd]),Gn("lifecycleVersion",[kr,ed]);const TE=m({seasonStateVersion:g(oE),seasonId:l,gameId:l,careerId:l,controlledTeamId:l.nullable(),rosterPackSha256:N,schedule:zl,careerState:Kl,projection:ql,completedMatches:O(zo).max(56),revision:d,phase:D(["ACTIVE","COMPLETE"])}),RE=m({...TE.shape,stateSha256:N}),td=Gn("seasonStateVersion",[Wl,RE]),vE=m({archiveVersion:g(iE),seasonId:l,scheduleSha256:N,fixtureId:l,matchId:l,fixtureOrdinal:F().int().min(0).max(55),roundNumber:Y.max(14),matchDayDate:gn(),source:D(["OFFSCREEN","USER_MATCH"]),sourceCompletionSha256:N,rosterPackSha256:N,preparation:jl,eventChain:no,events:O(Yo).min(1).max(2e3),scorecardSha256:N});m({...vE.shape,archiveSha256:N});const AE=m({worldStateVersion:g(rE),worldIdentity:br,careerId:l,controlledTeamId:l.nullable(),currentSeasonNumber:Y.max(ln),currentCalendarYear:F().int().min(1900).max(9999),currentSeason:td,completedSeasons:O(wr).max(ln-1),careerProjection:Or,lifecycle:kr,lastRolloverReceipt:Lr.nullable(),revision:d});m({...AE.shape,stateSha256:N}),m({archiveVersion:g(lE),saveSchema:D([sE,cE]),exportedAt:pt(),summary:Nr,careerProjectionSha256:N,lifecycleSha256:N,worldCopySha256:N.optional(),rosterPackHashes:O(N).max(ln),matchEventArchiveCount:d.max(ln*56),files:An(C().min(1),m({bytes:d,sha256:N}))}),m({command:g("SET_ACADEMY_PROSPECT_FOCUS"),prospectId:l,academyFocus:Ql}),m({command:g("SET_ACADEMY_PROSPECT_QUEUE"),prospectId:l,queuedForPromotion:z()}),m({command:g("PROMOTE_YOUTH_PROSPECT"),prospectId:l,seasonNumber:Y.max(ln)});const to=m({min:F().int().min(0).max(100),p10:F().int().min(0).max(100),median:F().int().min(0).max(100),meanX10:F().int().min(0).max(1e3),p90:F().int().min(0).max(100),max:F().int().min(0).max(100)});m({seasonNumber:Y.max(ln),calendarYear:F().int().min(1900).max(9999),activePlayerCount:d,cumulativeRetiredCount:d,cumulativeYouthPromotedCount:d,minClubSquadSize:d,maxClubSquadSize:d,minClubKeepers:d,minClubBowlingCapable:d,clubsWithRoleShortage:d,meanAgeX10:d,battingAbility:to,bowlingAbility:to,fieldingAbility:to,keepingAbility:to,roleCounts:m({BATTER:d,BOWLER:d,ALLROUNDER:d,KEEPER:d}),directiveSampleCheck:Oa.optional()}),m({teamId:l,date:gn(),players:O(Bl).min(dE).max(uE)});const ad="LC_SQUAD_ECONOMY_MODEL_FICTIONAL_V1",bE="LC_SQUAD_ECONOMY_STATE_V1",wE="LC_ECONOMY_LEDGER_ENTRY_V1",OE="LC_PERSISTENT_WORLD_STATE_V3",LE="LC_PERSISTENT_WORLD_SAVE_V3",NE="LC_PERSISTENT_WORLD_SAVE_V3_PRESENTATION",yE="LC_PERSISTENT_WORLD_PORTABLE_V3_ECONOMY",DE="LC_PERSISTENT_WORLD_STATE_V4",CE="LC_PERSISTENT_WORLD_SAVE_V4",kE="LC_PERSISTENT_WORLD_SAVE_V4_PRESENTATION",BE="LC_PERSISTENT_WORLD_STATE_V5",PE="LC_PERSISTENT_WORLD_SAVE_V5",xE="LC_PERSISTENT_WORLD_SAVE_V5_PRESENTATION",HE=2500,FE=35,ME=450,VE=40,od=1,na=3,ea=3,WE=50,UE=16,$E=40,id=m({modelVersion:g(ad),calibrationStatus:g("FICTIONAL_PLACEHOLDER"),disclaimer:C().min(1).max(400),annualClubWageBudgetK:F().int().min(1e3).max(1e4),minAnnualWageK:F().int().min(20).max(100),maxAnnualWageK:F().int().min(200).max(1e3),youthRookieAnnualWageK:F().int().min(25).max(100),minContractTermSeasons:g(od),maxContractTermSeasons:g(na),maxNegotiationRounds:g(ea),releaseBuyoutPercent:F().int().min(0).max(100),minFreeAgentPoolSize:F().int().min(8).max(64),maxFreeAgentPoolSize:F().int().min(16).max(128)}),GE=D(["INITIAL_SQUAD","RENEWAL","FREE_AGENT_SIGNING","YOUTH_GRADUATE","EMERGENCY_MINIMUM"]),jE=m({contractId:l,playerId:l,teamId:l,signedSeasonNumber:Y.max(ln),startsSeasonNumber:Y.max(ln+1),expiresAfterSeasonNumber:Y.max(ln+5),annualWageK:F().int().min(20).max(1e3),origin:GE,careerTeamIds:O(l).min(1).max(8)}),YE=D(["UNATTACHED_POOL","CONTRACT_EXPIRED","CLUB_RELEASED"]),zE=m({playerId:l,player:wt,enteredMarketSeasonNumber:Y.max(ln),enteredReason:YE,previousTeamId:l.nullable(),careerTeamIds:O(l).max(8),restrictedFromSigningTeamId:l.nullable(),restrictedSeasonNumber:Y.max(ln).nullable(),askingAnnualWageK:F().int().min(20).max(1e3),preferredTermSeasons:F().int().min(1).max(na)}),KE=m({teamId:l,seasonNumber:Y.max(ln),annualWageBudgetK:F().int().min(500).max(2e4),committedWagesK:d.max(2e4),deadCapWagesK:d.max(2e4),pendingOfferReservedWagesK:d.max(2e4),availableWageSpaceK:d.max(2e4)}),rd=D(["FREE_AGENT","RENEWAL"]),qE=D(["PENDING_ROUND","COUNTERED","SIGNED","REJECTED","WITHDRAWN"]),ZE=D(["AWAITING_ROUND_RESOLUTION","PLAYER_ACCEPTED_BEST_OFFER","PLAYER_COUNTERED_TERMS","WAGE_BELOW_RESERVATION","SIGNED_WITH_COMPETING_CLUB","CLUB_WITHDREW_OFFER","PLAYER_NO_LONGER_ELIGIBLE","CAP_OR_ROSTER_LIMIT"]),XE=m({offerId:l,commandId:l,seasonNumber:Y.max(ln),roundSubmitted:F().int().min(1).max(ea),roundResolved:F().int().min(1).max(ea).nullable(),offeringTeamId:l,submittedBy:D(["HUMAN_MANAGER","AI_CLUB"]),playerId:l,offerKind:rd,annualWageK:F().int().min(20).max(1e3),termSeasons:F().int().min(1).max(na),status:qE,reason:ZE,counterAnnualWageK:F().int().min(20).max(1e3).nullable(),counterTermSeasons:F().int().min(1).max(na).nullable(),rationale:C().min(1).max(280)}),JE=m({seasonNumber:Y.max(ln),windowPhase:D(["OPEN","CLOSED"]),currentRound:F().int().min(1).max(ea),maxRounds:g(ea),offers:O(XE).max(2e3)}),QE=D(["INITIAL_CONTRACT_REGISTERED","CONTRACT_RENEWED","FREE_AGENT_SIGNED","YOUTH_ROOKIE_CONTRACT_SIGNED","CONTRACT_EXPIRED_TO_FREE_AGENCY","CONTRACT_RELEASE_BUYOUT","CONTRACT_ENDED_ON_RETIREMENT","MINIMUM_SQUAD_TOPUP_SIGNED"]),n2=m({ledgerEntryVersion:g(wE),sequence:Y,transactionId:l,seasonNumber:Y.max(ln),calendarYear:F().int().min(1900).max(9999),date:gn(),type:QE,teamId:l,playerId:l,contractId:l.nullable(),offerId:l.nullable(),annualWageK:d.max(2e3),deadCapDeltaK:d.max(2e3),termSeasons:d.max(na),teamCommittedWagesAfterK:d.max(2e4),teamDeadCapAfterK:d.max(2e4),teamBudgetLimitK:F().int().min(500).max(2e4),summary:C().min(1).max(320),prevEntrySha256:N.nullable()}),e2=m({...n2.shape,entrySha256:N}),t2=m({fromSeasonNumber:Y.max(ln-1),toSeasonNumber:Y.max(ln),calendarYear:F().int().min(1900).max(9999),humanRenewedCount:d.max(1e3),aiRenewedCount:d.max(1e3),expiredToFreeAgencyIds:O(l).max(1e3),retiredContractClosedIds:O(l).max(1e3),youthContractsSignedIds:O(l).max(1e3),aiOffseasonFreeAgentSigningsIds:O(l).max(1e3),minimumTopupSignedIds:O(l).max(1e3)}),a2=m({economyVersion:g(bE),model:id,contracts:O(jE).min(22).max(1e4),freeAgents:O(zE).max(2e3),clubBudgets:O(KE).length(8),negotiationWindow:JE,ledger:O(e2).min(1).max(5e4),appliedCommandIds:O(l).max(1e4),transitions:O(t2).max(ln)}),o2=m({...a2.shape,economySha256:N}),sd=m({worldStateVersion:g(OE),worldIdentity:br,careerId:l,controlledTeamId:l.nullable(),currentSeasonNumber:Y.max(ln),currentCalendarYear:F().int().min(1900).max(9999),currentSeason:td,completedSeasons:O(wr).max(ln-1),careerProjection:Or,lifecycle:kr,economy:o2,lastRolloverReceipt:Lr.nullable(),revision:d});m({...sd.shape,stateSha256:N});const cd=sd.extend({worldStateVersion:g(DE),lifecycle:ed});m({...cd.shape,stateSha256:N});const ld=cd.extend({worldStateVersion:g(BE)}),dd=m({...ld.shape,stateSha256:N}),i2=m({seasonId:l,recordSha256:N});m({...dd.shape,completedSeasons:O(i2).max(ln-1)});const r2=m({archiveVersion:g(yE),saveSchema:D([LE,NE]),exportedAt:pt(),summary:Nr,careerProjectionSha256:N,lifecycleSha256:N,economySha256:N,worldCopySha256:N.optional(),rosterPackHashes:O(N).max(ln*4),matchEventArchiveCount:d.max(ln*56),files:An(C().min(1),m({bytes:d,sha256:N}))});m({command:g("SUBMIT_CONTRACT_OFFER"),commandId:l,offeringTeamId:l,playerId:l,offerKind:rd,annualWageK:F().int().min(20).max(1e3),termSeasons:F().int().min(1).max(na)}),m({command:g("WITHDRAW_CONTRACT_OFFER"),commandId:l,offeringTeamId:l,offerId:l}),m({command:g("ACCEPT_COUNTER_OFFER"),commandId:l,offeringTeamId:l,offerId:l}),m({command:g("RESOLVE_NEGOTIATION_ROUND"),commandId:l,seasonNumber:Y.max(ln),expectedRound:F().int().min(1).max(ea)}),m({command:g("RELEASE_CONTRACTED_PLAYER"),commandId:l,teamId:l,playerId:l}),m({seasonNumber:Y.max(ln),calendarYear:F().int().min(1900).max(9999),activeContractCount:d,freeAgentPoolCount:d,minClubPayrollUsedK:d,medianClubPayrollUsedK:d,maxClubPayrollUsedK:d,clubWageBudgetK:F().int().min(500).max(2e4),clubsOverspentCount:d,clubsWithRoleShortageCount:d,seasonFreeAgentSigningsCount:d,seasonRenewalsCount:d,seasonExpiredToFreeAgencyCount:d,seasonReleaseBuyoutsCount:d,wageDistributionK:to,aiHiddenFutureAbilityReads:g(0)});const ud=D(["TOSS","INNINGS","BATTER","BOWLER","BATTING_PLAN","BOWLING_PLAN","FIELD","DECLARATION","FOLLOW_ON","NEW_BALL"]),Br=D(["CONSERVATIVE","BALANCED","AGGRESSIVE"]),s2=O(ud).max(10).refine(n=>new Set(n).size===n.length).meta({uniqueItems:!0}),md=m({commandId:C().min(1).max(128),expectedRevision:F().int().nonnegative(),matchRevision:F().int().nonnegative(),teamId:C().min(1).max(128),categories:s2,redBallProfile:Br.optional()}),c2=m({version:g("LC_DELEGATION_JOURNAL_V1"),changes:O(md)});function ta(n){const e=c2.parse(n),t=new Set;let a=0;return e.changes.forEach((o,i)=>{if(o.expectedRevision!==i||o.matchRevision<a||t.has(o.commandId))throw new Error("DELEGATION_JOURNAL_INVALID");t.add(o.commandId),a=o.matchRevision}),e}function l2(n,e){const t=ta(n),a=md.parse(e),o=t.changes.find(i=>i.commandId===a.commandId);if(o){if(JSON.stringify(o)!==JSON.stringify(a))throw new Error("DELEGATION_DUPLICATE_CONFLICT");return t}if(a.expectedRevision!==t.changes.length)throw new Error("DELEGATION_STALE_REVISION");if(a.matchRevision<(t.changes.at(-1)?.matchRevision??0))throw new Error("DELEGATION_STALE_MATCH");return{...t,changes:[...t.changes,a]}}function d2(n,e){return ta(n).changes.filter(t=>t.teamId===e).at(-1)?.categories??[]}function u2(n,e){return ta(n).changes.filter(t=>t.teamId===e&&t.redBallProfile!==void 0).at(-1)?.redBallProfile??"BALANCED"}const Pr="LC_TACTICAL_BRIEFING_V1",m2=D(["SEAM_FRIENDLY","SPIN_FRIENDLY","LIVE_BOTH","BALANCED","FLAT"]),g2=D(["FRESH","READY","WORKED","TIRED"]),I2=m({playerId:l,name:ue,role:D(["BATTER","BOWLER","ALLROUNDER","KEEPER"]),batHand:Ea,bowlingStyle:Vo.nullable(),canBowl:z(),selectedInXI:z(),fatigueBp:de,readinessDelta:F().int().min(-20).max(20),conditionBand:g2}),gd=m({teamId:l,teamName:ue,squadSize:Y,selectedCount:d.max(11),selectedKeepers:d.max(11),selectedBowlingOptions:d.max(11),selectedPaceOptions:d.max(11),selectedSpinOptions:d.max(11),selectedLeftHandBatters:d.max(11),freshInXI:d.max(11),tiredInXI:d.max(11),balanceSummary:C().min(1).max(320),players:O(I2).min(11).max(30)}),Id=m({opponentTeamId:l,opponentTeamName:ue,poolLabel:D(["SELECTED_XI","AVAILABLE_SQUAD"]),leftHandBatters:d.max(30),rightHandBatters:d.max(30),keepers:d.max(30),paceOptions:d.max(30),spinOptions:d.max(30),bowlingStyles:O(Vo).max(6),observations:O(C().min(1).max(280)).min(1).max(6)}),p2=m({groundId:l,groundName:ue,seamBp:de,turnBp:de,pitchTendency:m2,pitchSummary:C().min(1).max(320),formatRulesSummary:C().min(1).max(320),modelLimitsDisclosure:C().min(1).max(320)});m({version:g(Pr),format:Te,ground:p2,teams:Kn([gd,gd]),opponentObservations:Kn([Id,Id])});const h2=D(["BATTING_AGGRESSION","BATTING_INTENT","BOWLING_LINE","BOWLING_LENGTH","BOWLING_EFFORT","BOWLING_VARIATION","FIELD_PLACEMENT"]),f2=m({controlId:h2,side:D(["BATTING","BOWLING","FIELDING"]),label:C().min(1).max(80),currentSetting:C().min(1).max(160),upside:C().min(1).max(280),tradeOff:C().min(1).max(280)}),E2=D(["BAT_CONSOLIDATE","BAT_ROTATE_STRIKE","BAT_BALANCED_TEMPO","BAT_BOUNDARY_PUSH","BOWL_DISCIPLINED_CHANNEL","BOWL_ATTACK_STUMPS","BOWL_CONSERVE_SPELL","BOWL_YORKER_CLOSE","BOWL_SHORT_TEST","FIELD_SLIP_ATTACK","FIELD_BALANCED_RING","FIELD_BOUNDARY_PROTECT"]),S2=m({presetId:E2,commandKind:D(["SET_BATTING_PLAN","SET_BOWLING_PLAN","SET_FIELD"]),label:C().min(1).max(80),whenToUse:C().min(1).max(240),tradeOff:C().min(1).max(240),contextualMatch:z(),contextualReason:C().max(200),activeNow:z(),battingPatch:m({aggression:d.max(4),intent:D(["NORMAL","ROTATE","PROTECT"])}).optional(),bowlingPatch:m({line:D(["OFF","STUMPS","LEG"]),length:D(["YORKER","FULL","GOOD","SHORT"]),effort:D(["CONSERVE","NORMAL","MAXIMUM"]),variationId:l}).optional(),fieldSlots:O(rr).length(9).optional()}),_2=m({primaryLine:D(["OFF","STUMPS","LEG"]),primaryLength:D(["YORKER","FULL","GOOD","SHORT"]),primaryEffort:D(["CONSERVE","NORMAL","MAXIMUM"]),primaryVariationId:l,latestRingFielders:d.max(9),latestBoundaryFielders:d.max(9),latestCloseCatchers:d.max(9),planChangesCount:d,fieldChangesCount:d}),T2=m({YORKER:d,FULL:d,GOOD:d,SHORT:d,FULL_TOSS:d}),R2=m({GROUND:d,AERIAL:d,EDGE:d,NO_CONTACT:d}),v2=m({STOP:d,CATCH:d,DROP:d,MISS:d,RUN_OUT:d}),A2=m({legalBalls:d,oversDisplay:C().regex(/^[0-9]+\.[0-5]$/),deliveryAttempts:d,runsConceded:d,wickets:d,dots:d,singles:d,boundaries:d,fours:d,sixes:d,wides:d,noBalls:d,economyX100:d.nullable(),intendedLengthMatches:d,intendedLengthEvaluatedBalls:d,executedLengths:T2,trajectories:R2,fieldOutcomes:v2}),b2=m({spellId:C().min(1).max(160),inningsIndex:d,spellNumberInInnings:Y,bowlerId:l,bowlerName:ue,status:D(["IN_PROGRESS","BETWEEN_OVERS","COMPLETED"]),startOver:d,endOver:d,acceptedPlan:_2,outcomes:A2,factualSummary:C().min(1).max(420)}),w2=m({stintId:C().min(1).max(160),inningsIndex:d,playerId:l,playerName:ue,dismissed:z(),acceptedPlan:m({primaryAggression:d.max(4),primaryIntent:D(["NORMAL","ROTATE","PROTECT"]),planChangesCount:d}),outcomes:m({ballsFaced:d,runs:d,dots:d,singles:d,boundaries:d,strikeRateX100:d.nullable()}),factualSummary:C().min(1).max(360)}),O2=m({phaseLabel:C().min(1).max(120),fieldRestrictionLabel:C().min(1).max(160),scoreContextLabel:C().min(1).max(200),pitchSummaryLabel:C().min(1).max(200),activeBowlerWorkloadLabel:C().max(200)}),L2=m({version:g(Pr),format:Te,situation:O2,controlGuide:O(f2).length(7),presets:O(S2).max(16),spellReviews:O(b2),battingStintReviews:O(w2)}),pd="LC_FIELD_PRESENTATION_V1";D(["EVERY_BALL","KEY_MOMENT","FAST"]),D(["AUTO","REDUCED"]);const N2=D(["WICKET","SIX","FOUR","FREE_HIT","EXTRA","RUNS","DOT"]),y2=D(["RECORDED_SECTOR","PITCH_CHANNEL_ONLY"]),D2=D(["SLOT_COUNT","UNIQUE_PLAYERS","DUPLICATE_POSITION","UNSUPPORTED_POSITION","CIRCLE_RESTRICTION","LEG_SIDE_LIMIT","BEHIND_SQUARE_LEG_LIMIT"]),C2=m({code:D2,message:C().min(1).max(240),affectedSlotIds:O(l).max(9)}),hd=m({isLegal:z(),format:Te,strikerHand:Ea,phaseLabel:C().min(1).max(120),outsideCircleCount:d.max(9),maxOutsideCircle:d.max(9),legSideCount:d.max(9),maxLegSide:g(5),behindSquareLegCount:d.max(9),maxBehindSquareLeg:g(2),duplicateSlotIds:O(l).max(9),violations:O(C2).max(16),summaryText:C().min(1).max(320)}),ht=m({x10:d.max(2e3),y10:d.max(2e3)}),k2=m({slotId:l,label:ue,sector:d.max(7),displaySector:d.max(7),depth:D(["INNER","MIDDLE","DEEP"]),insideCircle:z(),legSideForStriker:z(),behindSquare:z(),point:ht,occupiedByPlayerId:l.nullable(),occupiedByName:ue.nullable()}),xr=m({sequence:Y,eventHash:N,inningsIndex:d.max(3),deliveryIndex:d,overBallLabel:C().min(1).max(24),strikerId:l,strikerName:ue,strikerHand:Ea,bowlerId:l,bowlerName:ue,momentKind:N2,isKeyMoment:z(),runsScored:d,batRuns:d,boundary:D(["NONE","FOUR","SIX"]),legality:D(["LEGAL","WIDE","NO_BALL","DEAD"]),dismissalKind:D(["BOWLED","LBW","CAUGHT","RUN_OUT","STUMPED","HIT_WICKET"]).nullable(),dismissedPlayerName:ue.nullable(),fieldOutcome:D(["NONE","STOP","DROP","CATCH","MISS","RUN_OUT"]),executedLength:D(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"]).nullable(),trajectory:D(["GROUND","AERIAL","EDGE"]).nullable(),recordedSector:d.max(7).nullable(),displaySector:d.max(7).nullable(),sectorStatus:y2,releasePoint:ht,pitchBouncePoint:ht,strikerCreasePoint:ht,targetPoint:ht,headline:C().min(1).max(160),detailText:C().min(1).max(280),trackingDisclaimer:C().min(1).max(220)}),B2=m({version:g(pd),format:Te,phase:C().min(1).max(64),activeInningsIndex:d.max(3),strikerId:l.nullable(),strikerName:ue.nullable(),strikerHand:Ea,nonStrikerId:l.nullable(),nonStrikerName:ue.nullable(),bowlerId:l.nullable(),bowlerName:ue.nullable(),keeperId:l.nullable(),keeperName:ue.nullable(),keeperPoint:ht,bowlerReleasePoint:ht,strikerPoint:ht,nonStrikerPoint:ht,boundaryRadiusX10:g(840),circleRadiusX10:g(480),positions:O(k2).min(11).max(12),legality:hd,recentHighlights:O(xr).max(24),latestHighlight:xr.nullable(),orientationNote:C().min(1).max(200),trackingDisclaimer:C().min(1).max(220)}),ee="LC_COMMENTARY_ADAPTER_V1";D(["BRIEF","STANDARD","DETAILED","OFF"]);const P2=D(["DELIVERY","OVER","PARTNERSHIP","MILESTONE","DISMISSAL","TACTICAL","CONDITIONS","INNINGS","RESULT","SELECTION"]),x2=D(["EVENT_FIELD","INNINGS_PROJECTION","BATTER_PROJECTION","BOWLER_PROJECTION","PARTNERSHIP_PROJECTION","CHASE_PROJECTION","MATCH_RESULT","FORMAT_RULE"]),H2=m({slot:l,value:C().min(1).max(160),sourceKind:x2,sourceRef:C().min(1).max(160)}),F2=D(["BATTER_FIFTY","BATTER_CENTURY","BATTER_150","BATTER_DOUBLE_CENTURY","PARTNERSHIP_FIFTY","PARTNERSHIP_CENTURY","PARTNERSHIP_150","BOWLER_THREE_FOR","BOWLER_FIVE_FOR","MAIDEN_OVER","ALL_OUT","WINNING_DELIVERY"]),M2=m({adapterVersion:g(ee),sequence:Y,eventType:l,category:P2,templateId:l,templateFamily:l,cooldownApplied:z(),presentationDigest:C().regex(/^[a-f0-9]{8}$/),milestoneTags:O(F2).max(6),short:C().min(1).max(240),text:C().min(1).max(640),detailed:C().min(1).max(960),factSlots:O(H2).min(1).max(24)});m({adapterVersion:g(ee),format:Te,presentationKeyDigest:C().regex(/^[a-f0-9]{8}$/),repetitionCooldownWindow:Y.max(12),entries:O(M2)});const Hr="LC_AUDIO_PRESENTATION_V1",fd="LC_AUDIO_PROVENANCE_V1",Ed=D(["CROWD","EFFECTS","COMMENTARY","INTERFACE"]),Sd=D(["BAT_BALL_DOT","BAT_BALL_SINGLE","BOUNDARY_FOUR","BOUNDARY_SIX","WICKET_FALL","MILESTONE_CHIME","OVER_BELL","INNINGS_CHANGE","MATCH_COMPLETE","UI_CLICK"]),V2=D(["ORIGINAL_PROCEDURAL_SYNTH","ORIGINAL_IN_REPO_PCM"]);D(["PLAYED","QUEUED_AWAITING_GESTURE","DEDUP_SKIPPED","EXPIRED_FAST_FORWARD","MUTED_OR_ZERO_VOLUME","BACKGROUND_TAB_SUPPRESSED","MISSING_ASSET_FALLBACK","DECODE_FAILED_FALLBACK"]);const Zo=F().int().min(0).max(100);m({version:g(Hr),muted:z(),crowdVolume:Zo,effectsVolume:Zo,commentaryVolume:Zo,interfaceVolume:Zo,narrationEnabled:z(),captionsEnabled:z()});const W2=m({assetId:l,cueKind:Sd,channel:Ed,title:C().min(1).max(120),author:C().min(1).max(120),license:g("MIT_ORIGINAL_LORD_CRICKET_XXVI"),origin:V2,synthesisProfile:C().min(1).max(200),durationMs:Y.max(1e4),sha256:N});m({manifestVersion:g(fd),attributionNotice:C().min(1).max(320),networkCallsAllowed:g(!1),assets:O(W2).min(1).max(64)});const U2=m({cueId:l,sequence:Y,channel:Ed,cueKind:Sd,assetId:l,priority:F().int().min(1).max(100),caption:C().min(1).max(280),narrationText:C().min(1).max(360).optional(),ttlMs:Y.max(3e4)});m({adapterVersion:g(Hr),matchId:l,format:Te,cues:O(U2)});const $2="LC_HISTORICAL_STATISTICS_PROJECTION_V1",G2=D(["CAREER"]),_d=D(["ALL","OPENER","TOP_ORDER","MIDDLE_ORDER","LOWER_ORDER"]),j2=D(["ALL","ACTIVE","RETIRED"]),Y2=_e([g("ALL"),g("ACTIVE"),Y.max(ln)]),z2=m({seasonScope:Y2,format:g("T20"),competitionId:C().min(1).max(64),opponentTeamId:C().min(1).max(64),venueGroundId:C().min(1).max(64),battingPositionBand:_d,battingPositionExact:Y.max(11).nullable(),playerStatus:j2,teamId:C().min(1).max(64)}),K2=m({seasonNumber:Y.max(ln),calendarYear:F().int().min(1900).max(9999),phase:D(["ACTIVE","COMPLETE"]),matchesCount:d}),q2=m({competitionId:l,label:C().min(1).max(120),format:Te}),Z2=m({formats:O(Te).min(1).max(3),unsupportedFormatsNote:C().min(1).max(240),competitions:O(q2).max(32),seasons:O(K2).max(ln),opponents:O(l).max(64),teams:O(l).max(64),venues:m({available:z(),coverage:D(["ALL_RESOLVED","PARTIAL","UNAVAILABLE"]),groundIds:O(l).max(64),note:C().min(1).max(240)}),battingPosition:m({available:g(!0),bands:O(_d).min(1),note:C().min(1).max(240)}),fielding:m({available:z(),archiveCoverageCount:d,totalMatchesCount:d,coverage:D(["ALL_ARCHIVED","PARTIAL_ARCHIVES","UNAVAILABLE"]),note:C().min(1).max(240)})}),X2=m({fixtureId:l,matchId:l,seasonNumber:Y.max(ln),calendarYear:F().int().min(1900).max(9999),roundNumber:Y.max(14),matchDayDate:gn(),competitionId:l,format:g("T20"),groundId:l.nullable(),homeTeamId:l,awayTeamId:l,teamId:l,opponentTeamId:l,battedInnings:Y.max(2).nullable(),battingPosition:Y.max(11).nullable(),runsScored:d.nullable(),ballsFaced:d.nullable(),fours:d.nullable(),sixes:d.nullable(),notOut:z().nullable(),bowledLegalBalls:d.nullable(),bowlingRunsConceded:d.nullable(),bowlingWickets:d.max(10).nullable(),maidens:d.max(4).nullable(),catches:d.nullable(),stumpings:d.nullable(),runOuts:d.nullable(),archiveEvaluated:z(),archiveReplayAvailable:z(),resultSummary:C().min(1).max(240),sourceCompletionSha256:N}),J2=m({playerId:l,status:D(["ACTIVE","RETIRED"]),currentTeamId:l,careerTeamIds:O(l).min(1).max(64),retiredAfterSeasonNumber:Y.max(ln).nullable(),retiredCalendarYear:F().int().min(1900).max(9999).nullable(),seasonsPlayed:d.max(ln),matches:d,battingInnings:d,notOuts:d,runs:d,dismissals:d,ballsFaced:d,fours:d,sixes:d,fifties:d,hundreds:d,ducks:d,highScoreRuns:d,highScoreNotOut:z(),highScoreFixtureId:l.nullable(),battingAverageX100:d.nullable(),strikeRateX100:d.nullable(),boundaryRunsPercentX100:d.nullable(),bowlingInnings:d,bowlingRunsConceded:d,bowlingLegalBalls:d,bowlingWickets:d,maidens:d,threeWicketHauls:d,fourWicketHauls:d,fiveWicketHauls:d,bestBowlingWickets:d.max(10),bestBowlingRuns:d.nullable(),bestBowlingFixtureId:l.nullable(),bowlingAverageX100:d.nullable(),economyX100:d.nullable(),bowlingStrikeRateX100:d.nullable(),fieldingMatchesArchived:d,catches:d,stumpings:d,runOuts:d,totalFieldingDismissals:d,bestMatchCatches:d,bestMatchFieldingDismissals:d,bestFieldingFixtureId:l.nullable(),contributingMatches:O(X2).max(ln*14)}),Q2=D(["RUNS","BATTING_AVERAGE","BATTING_STRIKE_RATE","HIGH_SCORE","SIXES","WICKETS","BOWLING_AVERAGE","ECONOMY","BOWLING_STRIKE_RATE","BEST_BOWLING","FIELDING_DISMISSALS","CATCHES"]),n1=m({rank:Y,tied:z(),playerId:l,teamId:l,status:D(["ACTIVE","RETIRED"]),qualified:z(),primaryDisplay:C().min(1).max(64),primaryValueX100:d,secondaryDisplay:C().min(1).max(96),denominatorCount:d,denominatorLabel:C().min(1).max(64),contributingFixtureIds:O(l).min(1).max(ln*14)}),e1=m({summary:C().min(1).max(200),minDenominator:d,denominatorField:C().min(1).max(64),secondaryRule:C().min(1).max(160).nullable()}),Ze=m({metric:Q2,title:C().min(1).max(80),sortDirection:D(["DESC","ASC"]),qualificationRule:e1,denominatorDefinition:C().min(1).max(160),nullPolicy:C().min(1).max(160),tieRule:C().min(1).max(160),entries:O(n1).max(200),qualifiedCount:d,totalCandidatesCount:d}),t1=m({teamId:l,played:d,wins:d,losses:d,ties:d,noResults:d,points:d,runsFor:d,ballsFor:d,runsAgainst:d,ballsAgainst:d});m({projectionVersion:g($2),sourceClass:G2,separationNotice:C().min(1).max(240),filterQuery:z2,filterSupport:Z2,totalSourceMatches:d,filteredMatchesCount:d,players:O(J2).max(1e4),leaderboards:m({RUNS:Ze,BATTING_AVERAGE:Ze,BATTING_STRIKE_RATE:Ze,HIGH_SCORE:Ze,SIXES:Ze,WICKETS:Ze,BOWLING_AVERAGE:Ze,ECONOMY:Ze,BOWLING_STRIKE_RATE:Ze,BEST_BOWLING:Ze,FIELDING_DISMISSALS:Ze,CATCHES:Ze}),teamStandings:O(t1).max(64),projectionDigest:C().regex(/^[0-9a-f]{32}$/)});const ao="LC_AWARDS_HEURISTIC_GAME_V1",a1="LC_CAREER_AWARDS_LEDGER_V1",aa=F().int().min(Number.MIN_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),o1=D(["T20","ODI","RED_BALL"]),i1=m({battingPointsX100:aa,bowlingPointsX100:aa,fieldingPointsX100:d,resultBonusX100:d}),r1=m({playerId:l,teamId:l,battingPointsX100:aa,bowlingPointsX100:aa,fieldingPointsX100:d,resultBonusX100:d,totalPointsX100:aa,fromWinningTeam:z(),summaryLine:C().min(1).max(240)}),Fr=m({awardVersion:g(ao),awardCategory:g("PLAYER_OF_THE_MATCH"),awardProvenance:g("GAME_AWARD"),format:o1,matchId:l,fixtureId:l.nullable(),seasonNumber:Y.nullable(),sourceCompletionSha256:N.nullable(),status:D(["AWARDED","NO_RESULT_NOT_AWARDED"]),winnerPlayerId:l.nullable(),winnerTeamId:l.nullable(),fromWinningTeam:z().nullable(),fromLosingTeam:z(),scoreTotalX100:aa.nullable(),components:i1.nullable(),fieldingSourceStatus:D(["ARCHIVE_EVENTS","SCORECARD_NOT_ATTRIBUTABLE"]),explanationText:C().min(1).max(400),formulaSummary:C().min(1).max(400),candidates:O(r1).max(5)}),s1=D(["PLAYER_OF_THE_SEASON","LEADING_RUN_SCORER","LEADING_WICKET_TAKER","BEST_FIELDER","EMERGING_YOUTH_PLAYER"]),c1=m({awardVersion:g(ao),category:s1,label:C().min(1).max(120),awardProvenance:g("GAME_AWARD"),status:D(["AWARDED","UNAVAILABLE"]),unavailableReason:C().min(1).max(240).nullable(),qualificationRule:C().min(1).max(240),formulaSummary:C().min(1).max(320),winnerPlayerId:l.nullable(),winnerTeamId:l.nullable(),headlineStat:C().min(1).max(160).nullable(),scoreX100:aa.nullable(),tieBroken:z(),runnerUpPlayerId:l.nullable(),explanationText:C().min(1).max(400)}),l1=m({awardVersion:g(ao),seasonNumber:Y,calendarYear:F().int().min(1900).max(9999),competitionId:g("LC_T20_LEAGUE_01"),sealedAtSeasonSha256:N.nullable(),provenanceNotice:C().min(1).max(320),awards:O(c1).length(5)}),d1=m({key:C().min(1).max(256),seasonNumber:Y,fixtureId:l,matchId:l,sourceCompletionSha256:N,award:Fr});m({ledgerVersion:g(a1),worldOrCareerId:l,matchAwards:O(d1).max(2e4),seasonAwards:O(l1).max(200),ledgerSha256:N});const u1="LC_CAREER_MATCH_DIGEST_V1",Mr=F().int().min(0).max(1e3);m({digestVersion:g(u1),fixtureId:l,groundId:l.nullable(),creaseOrder:Kn([O(l).max(64),O(l).max(64)]),fielding:O(m({playerId:l,teamId:l,catches:Mr,stumpings:Mr,runOuts:Mr})).max(64)});const Td=r2.extend({archiveVersion:g("LC_PERSISTENT_WORLD_PORTABLE_V4_GZIP"),compression:g("gzip")});Td.extend({archiveVersion:g("LC_PERSISTENT_WORLD_PORTABLE_V5_WORLD_V4"),saveSchema:D([CE,kE])}),Td.extend({archiveVersion:g("LC_PERSISTENT_WORLD_PORTABLE_V6_WORLD_V5"),saveSchema:D([PE,xE])});const m1="LC_CAREER_STORIES_PROJECTION_V1",g1=D(["MILESTONE_BATTING","MILESTONE_BOWLING","MILESTONE_FIELDING","FORM_STREAK","YOUTH_BREAKTHROUGH","CONTRACT_TENSION","RETIREMENT_WATCH","AWARD_RECOGNITION","CLUB_BOARD_REVIEW"]),I1=m({key:C().min(1).max(80),value:_e([C().min(1).max(200),F().int()])}),p1=m({storyId:C().min(1).max(256),seasonNumber:Y,roundNumber:F().int().min(1).max(99),category:g1,headline:C().min(1).max(160),summaryText:C().min(1).max(480),subjectPlayerId:l.nullable(),subjectTeamId:l.nullable(),linkedMatchKey:C().min(1).max(160).nullable(),factProvenance:O(I1).min(1).max(20)});m({schemaId:g(m1),worldOrCareerId:l,stories:O(p1).max(2e4)});const He="LC_SCENARIO_CHALLENGE_V1",Rd="LC_SCENARIO_RECORD_LEDGER_V1",h1=D(["STANDARD","HARD","ELITE"]),vd=D(["WIN","AVOID_DEFEAT"]),f1=m({inningsIndex:d.max(3),legalBalls:d.max(3e3),revision:Y,battingTeamId:l,runs:d.max(2e3),wickets:d.max(10),targetToWin:Y.max(2e3).nullable()}),E1=m({schemaId:g(He),scenarioId:l,title:C().min(1).max(80),format:Te,difficulty:h1,sourceType:g("FICTIONAL_CURATED"),seed:C().min(1).max(256),matchId:l,teamIds:Kn([l,l]),groundId:l,playerTeamId:l,objective:vd,objectiveSummary:C().min(1).max(160),briefing:C().min(1).max(480),checkpoint:f1}),Ad=D(["COMPLETED","FAILED"]),S1=m({scenarioId:l,challengeSha256:N,attempts:Y,completions:d,failures:d,bestMarginType:D(["RUNS","WICKETS","INNINGS"]).nullable(),bestMarginValue:Y.nullable(),lastOutcome:Ad.nullable()}),_1=m({gameId:l,scenarioId:l,challengeSha256:N,playerTeamId:l,objective:vd,outcome:Ad.nullable(),resultText:C().min(1).max(160).nullable()}),La=m({schemaId:g(Rd),records:O(S1).max(256),attempts:O(_1).max(64)}).superRefine((n,e)=>{new Set(n.records.map(a=>`${a.scenarioId}:${a.challengeSha256}`)).size!==n.records.length&&e.addIssue({code:"custom",message:"SCENARIO_RECORD_DUPLICATE"}),new Set(n.attempts.map(a=>a.gameId)).size!==n.attempts.length&&e.addIssue({code:"custom",message:"SCENARIO_ATTEMPT_DUPLICATE"});for(const a of n.records)a.completions+a.failures>a.attempts&&e.addIssue({code:"custom",message:"SCENARIO_RECORD_COUNTS"});for(const a of n.attempts)a.outcome===null!=(a.resultText===null)&&e.addIssue({code:"custom",message:"SCENARIO_ATTEMPT_RESULT"})}),bd="LC_T20_SUPER_OVER_01",Vr="LC_T20_SUPER_OVER_RECORD_V1",Wr="LC_ODI_SUPER_OVER_01",Ur="LC_ODI_SUPER_OVER_RECORD_V1",Xo=Gn("kind",[m({kind:g("SET_SUPER_OVER_BATTERS"),teamId:l,playerIds:O(l).min(2).max(3)}),m({kind:g("SET_SUPER_OVER_BOWLER"),teamId:l,playerId:l}),m({kind:g("SET_SUPER_OVER_AGGRESSION"),playerId:l,aggression:d.max(4)}),m({kind:g("BOWL_SUPER_OVER_BALL")})]),T1=m({schemaId:g(Vr),rulesId:g(bd),gameId:l,baseLastEventHash:N,commands:O(Xo).max(2e3),stateSha256:N}),R1=m({schemaId:g(Ur),rulesId:g(Wr),gameId:l,baseLastEventHash:N,commands:O(Xo).max(2e3),stateSha256:N}),oa=Gn("schemaId",[T1,R1]),v1=m({battingTeamId:l,runs:d,wickets:d.max(2),legalBalls:d.max(6)});m({roundNumber:Y,innings:O(v1).max(2)});const wd="LC_CUSTOM_COMPETITION_PACK_V1",A1="LC_TOURNAMENT_RUN_V1",b1=Gn("kind",[m({kind:g("ROUND_ROBIN"),legs:_e([g(1),g(2)]),finalTopTwo:z()}),m({kind:g("GROUPS_KNOCKOUT"),groups:Kn([O(l).min(3).max(4),O(l).min(3).max(4)])}),m({kind:g("SERIES"),matches:_e([g(1),g(3),g(5),g(7)])})]);function Od(n,e){new Set(n.teamIds).size!==n.teamIds.length&&e.addIssue({code:"custom",message:"COMPETITION_DUPLICATE_TEAM"}),new Set(n.groundIds).size!==n.groundIds.length&&e.addIssue({code:"custom",message:"COMPETITION_DUPLICATE_GROUND"});const t=n.structure;if(t.kind==="SERIES"&&n.teamIds.length!==2&&e.addIssue({code:"custom",message:"SERIES_NEEDS_TWO_TEAMS"}),t.kind==="ROUND_ROBIN"&&n.teamIds.length<(t.finalTopTwo?3:2)&&e.addIssue({code:"custom",message:"ROUND_ROBIN_TOO_FEW_TEAMS"}),t.kind==="GROUPS_KNOCKOUT"){const a=[...t.groups[0],...t.groups[1]];(new Set(a).size!==a.length||a.length!==n.teamIds.length||!a.every(o=>n.teamIds.includes(o)))&&e.addIssue({code:"custom",message:"GROUPS_MUST_PARTITION_TEAMS"})}}function Ld(n){return m({competitionId:l,title:C().min(1).max(80),format:D(["T20","ODI"]),sourceType:g(n),worldPackId:g("fictional-eight-01"),teamIds:O(l).min(2).max(8),groundIds:O(l).min(1).max(8),structure:b1,points:m({win:d.max(10),tie:d.max(10),loss:d.max(10)}),summary:C().min(1).max(320)})}const Nd=Ld("FICTIONAL_CURATED").superRefine(Od),w1=m({schemaId:g(wd),packId:l,competitions:O(Nd).min(1).max(32)}),O1=D(["LEAGUE","GROUP_A","GROUP_B","SEMI_FINAL","FINAL","SERIES"]),L1=m({fixtureId:l,matchNumber:Y,stage:O1,homeTeamId:l,awayTeamId:l,groundId:l}),N1=m({fixtureId:l,homeTeamId:l,awayTeamId:l,resultKind:D(["WIN","TIE"]),winnerTeamId:l.nullable(),superOverWinnerTeamId:l.nullable(),homeRuns:d,homeWickets:d.max(10),homeLegalBalls:d,awayRuns:d,awayWickets:d.max(10),awayLegalBalls:d,resultText:C().min(1).max(160),lastEventHash:N}),Jo=m({schemaId:g(A1),runId:l,competitionId:l,competitionSha256:N,seed:C().min(1).max(128),results:O(N1).max(64)}),yd="LC_USER_COMPETITION_V1",y1="LC_USER_COMPETITION_PACK_V1",$r=Ld("USER_AUTHORED").superRefine((n,e)=>{Od(n,e),n.competitionId.startsWith("user-")||e.addIssue({code:"custom",message:"USER_COMPETITION_ID_PREFIX"})}),Dd=m({schemaId:g(yd),competition:$r});m({schemaId:g(y1),competitions:O($r).min(1).max(32)});const Cd="LC_USER_TOUR_V1",D1=m({tourId:l.refine(n=>n.startsWith("user-tour-"),"USER_TOUR_ID_PREFIX"),title:C().min(1).max(80),format:D(["T20","ODI"]),hostTeamId:l,touringName:C().min(1).max(40),matches:_e([g(1),g(3),g(5),g(7)]),groundIds:O(l).min(1).max(8)}),kd=m({schemaId:g(Cd),tour:D1}),C1="LC_TOURNAMENT_AUCTION_V1",k1=Gn("kind",[m({kind:g("BID"),max:Y.max(1e3)}),m({kind:g("PASS")}),m({kind:g("AUTO")})]),Bd=m({schemaId:g(C1),runId:l,competitionId:l,seed:C().min(1).max(160),playerTeamId:l.nullable(),decisions:O(k1).max(400),squadsSha256:N});_e([Nd,$r]);const Pd="LC_T20_RAIN_01",xd="LC_ODI_RAIN_01",B1="LC_RAIN_MATCH_RECORD_V1",Hd=Gn("kind",[m({kind:g("CALL_TOSS"),teamId:l,call:D(["HEADS","TAILS"])}),m({kind:g("CHOOSE_INNINGS"),teamId:l,choice:D(["BAT","BOWL"])}),m({kind:g("SET_BATTER"),teamId:l,playerId:l}),m({kind:g("SET_BOWLER"),teamId:l,playerId:l}),m({kind:g("SET_AGGRESSION"),playerId:l,aggression:d.max(4)}),m({kind:g("BOWL"),scope:D(["BALL","OVER"])})]),P1=m({inningsIndex:_e([g(0),g(1)]),atLegalBall:Y,oversLost:Y,terminal:z()});m({stoppages:O(P1).min(1).max(2)}),m({inningsIndex:_e([g(0),g(1)]),legalBalls:d,wickets:d.max(10),runs:d,ballsLost:d,allocations:Kn([d,d]),terminal:z(),targetAfter:Y.nullable()}),m({kind:D(["WIN","TIE","NO_RESULT"]),winnerTeamId:l.nullable(),marginType:D(["RUNS","WICKETS"]).nullable(),margin:d.nullable(),method:D(["STANDARD","RESOURCE_TABLE"])});const x1=m({schemaId:g(B1),rulesId:D([Pd,xd]),gameId:l,matchId:l,seed:C().min(1).max(256),groundId:l,selectedTeams:O(m({teamId:l,playerIds:O(l).length(11),captainId:l,keeperId:l})).length(2),commands:O(Hd).max(4e3),stateSha256:N}),H1="LC_T20_DRS_01",F1="LC_ODI_DRS_01",M1="LC_EXTRA_RULES_RECORD_V1",V1=Gn("kind",[...Hd.options,m({kind:g("REVIEW_DECISION"),teamId:l,review:z()})]),Gr=D(["IN","UMPIRES_CALL","OUT"]);m({pitching:Gr,impact:Gr,wickets:Gr});const W1=m({schemaId:g(M1),rulesId:D([Pd,xd]),rain:z(),reviewRulesId:D([H1,F1]).nullable(),gameId:l,matchId:l,seed:C().min(1).max(256),groundId:l,selectedTeams:O(m({teamId:l,playerIds:O(l).length(11),captainId:l,keeperId:l})).length(2),commands:O(V1).max(6e3),stateSha256:N}),jr=Gn("schemaId",[x1,W1]);function et(n,e){if(!n)throw new Error(`LC_MATCH_ANALYTICS_${e}`)}function U1(n){return n.batRuns+n.extras.wides+n.extras.noBalls+n.extras.byes+n.extras.legByes+n.extras.penalties}function Yr(n){et(Number.isInteger(n)&&n>=0&&n<=4,"INNINGS_COUNT");const e=new Map,t=[],a=new Map,o=[],i=[],r=new Map,s=Array(n).fill(0),c=Array(n).fill(0),u=Array(n).fill(0);let h=0,p=0,E=0;function b(v){if(et(v.sequence===E+1,"SEQUENCE_ORDER"),v.type!=="DELIVERY_RECORDED"){E=v.sequence;return}const T=v.payload.event,A=T.inningsIndex;et(Number.isInteger(A)&&A>=0&&A<n,"INNINGS_INDEX");const I=U1(T);et(Number.isSafeInteger(I)&&I>=0,"INVALID_RUNS"),T.shotSector!==null&&et(Number.isInteger(T.shotSector)&&T.shotSector>=0&&T.shotSector<8,"SHOT_SECTOR"),T.executedLength!==null&&et(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"].includes(T.executedLength),"PITCH_LENGTH");const f=Math.floor(u[A]/6)+1,S=`${A}:${f}`,k=e.get(S)??{inningsIndex:A,overNumber:f,runs:0,wickets:0,legalBalls:0,attempts:0};k.runs+=I,k.wickets+=+(T.dismissal!==null),k.legalBalls+=Number(T.legalBall),k.attempts+=1,e.set(S,k);const R=[T.strikerId,T.nonStrikerId].sort();let _=t.at(-1);if((!_||_.inningsIndex!==A||_.players[0]!==R[0]||_.players[1]!==R[1])&&(_={inningsIndex:A,players:R,runs:0,legalBalls:0,fromSequence:v.sequence,toSequence:v.sequence},t.push(_)),_.runs+=I,_.legalBalls+=Number(T.legalBall),_.toSequence=v.sequence,T.shotSector!==null){const U=`${A}:${T.strikerId}:${T.shotSector}`,M=a.get(U)??{inningsIndex:A,batterId:T.strikerId,sector:T.shotSector,attempts:0,batRuns:0,fours:0,sixes:0};M.attempts++,M.batRuns+=T.batRuns,M.fours+=+(T.boundary==="FOUR"),M.sixes+=+(T.boundary==="SIX"),a.set(U,M)}else T.batRuns>0&&h++;s[A]+=I,c[A]+=+(T.dismissal!==null),u[A]+=Number(T.legalBall),T.executedLength===null?p++:r.set(T.executedLength,(r.get(T.executedLength)??0)+1),T.dismissal&&i.push({inningsIndex:A,sequence:v.sequence,playerId:T.dismissal.playerId,runs:s[A],wickets:c[A],legalBalls:u[A]}),o.push({inningsIndex:A,sequence:v.sequence,legalBalls:u[A],totalRuns:s[A],wickets:c[A]}),E=v.sequence}function w(v){const T=v?.innings.length??n;if(et(T<=n,"INNINGS_COUNT"),v){for(let A=0;A<T;A++){const I=v.innings[A];et(!!I&&s[A]===I.runs,`RUN_RECONCILIATION_${A}`),et(c[A]===I.wickets,`WICKET_RECONCILIATION_${A}`),et(u[A]===I.legalBalls,`BALL_RECONCILIATION_${A}`)}for(let A=T;A<n;A++)et(s[A]===0&&c[A]===0&&u[A]===0,`INNINGS_RECONCILIATION_${A}`)}return{overSummaries:[...e.values()].map(A=>({...A})),worm:o.map(A=>({...A})),partnerships:t.map(A=>({...A,players:[...A.players]})),shotSectors:[...a.values()].map(A=>({...A})).sort((A,I)=>A.inningsIndex-I.inningsIndex||A.batterId.localeCompare(I.batterId)||A.sector-I.sector),unlocatedShots:h,finalRuns:s.slice(0,T),finalLegalBalls:u.slice(0,T),finalWickets:c.slice(0,T),fallOfWickets:i.map(A=>({...A})),pitchLengths:["YORKER","FULL","GOOD","SHORT","FULL_TOSS"].filter(A=>r.has(A)).map(A=>({length:A,attempts:r.get(A)})),unrecordedLengths:p}}return{append:b,snapshot:w,get appliedSequence(){return E}}}function zr(n){let e=Yr(n),t=null;function a(o){const i=e.appliedSequence;(o.length<i||i>0&&o[i-1]?.eventHash!==t)&&(e=Yr(n),t=null);for(const r of o.slice(e.appliedSequence))e.append(r),t=r.eventHash}return{update:a,snapshot:o=>e.snapshot(o),get appliedSequence(){return e.appliedSequence}}}const $1=new Set(["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket"]),G1=new Set(["slip-1","slip-2"]);function oo(n){return`${Math.floor(n/6)}.${n%6}`}function Fd(n){let e=0,t=0,a=0;for(const o of n)$1.has(o.slotId)?e+=1:t+=1,G1.has(o.slotId)&&(a+=1);return{ring:e,boundary:t,closeCatchers:a}}function Kr(n,e,t){const a=n==="T20"&&e<36||n==="ODI"&&e<60;return t==="SLIP_ATTACK"?["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"]:a?["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","long-on"]:t==="BALANCED_RING"?["slip-1","point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","long-on"]:n==="ODI"&&e>=240?["point","cover","deep-cover","long-off","mid-on","midwicket","deep-square-leg","fine-leg","long-on"]:["point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","fine-leg","long-on"]}function qr(n,e){return[...n].sort().map((a,o)=>({slotId:e[o],playerId:a}))}function Zr(n,e){if(n.length!==e.length)return!1;const t=a=>[...a].sort((o,i)=>cl(o.playerId,i.playerId)).map(o=>`${o.playerId}:${o.slotId}`).join("|");return t(n)===t(e)}function j1(n,e,t){const a=Fd(t);return[{controlId:"BATTING_AGGRESSION",side:"BATTING",label:"Batting aggression (0–4)",currentSetting:n?`Level ${n.aggression} / 4`:"Awaiting striker",upside:"Higher aggression shifts contact toward scoring strokes and boundaries when chasing or accelerating late.",tradeOff:"Higher aggression increases aerial, edge, and miss contact; lower levels lean on defence at a slower scoring rate."},{controlId:"BATTING_INTENT",side:"BATTING",label:"Batting intent",currentSetting:n?n.intent:"Awaiting striker",upside:"ROTATE boosts single-taking to turn strike over; PROTECT suppresses risky singles to shield a partner or survive a spell.",tradeOff:"ROTATE adds run-out exposure against sharp ring fielders; PROTECT passes up singles and can stall scoreboard momentum."},{controlId:"BOWLING_LINE",side:"BOWLING",label:"Bowling line",currentSetting:e?e.line:"Awaiting bowler",upside:"STUMPS brings bowled and LBW into play and narrows straight sectors; OFF channels strokes into off-side catchers and ring stops.",tradeOff:"LEG line disables LBW dismissals and raises wide risk under the legality model."},{controlId:"BOWLING_LENGTH",side:"BOWLING",label:"Intended bowling length",currentSetting:e?e.length:"Awaiting bowler",upside:"GOOD balances control; YORKER raises misses and suppresses lofted contact; SHORT tests batters with higher aerial and edge rates.",tradeOff:"Execution depends on control and low fatigue: missed YORKER or FULL balls spill into high-scoring full tosses."},{controlId:"BOWLING_EFFORT",side:"BOWLING",label:"Bowling effort",currentSetting:e?e.effort:"Awaiting bowler",upside:"CONSERVE lowers wide/no-ball risk and slows fatigue across longer spells; MAXIMUM pushes effort in short bursts.",tradeOff:"MAXIMUM raises wide/no-ball risk and accelerates bowler fatigue, degrading movement and length accuracy later in the spell."},{controlId:"BOWLING_VARIATION",side:"BOWLING",label:"Delivery variation",currentSetting:e?e.variationId:"Awaiting bowler",upside:"Stock ball uses baseline control; selecting a bowler's supported variation changes pace or turn mix when batters settle.",tradeOff:"Only variations listed on the active bowler are legal; overusing effort alongside variations still accumulates spell fatigue."},{controlId:"FIELD_PLACEMENT",side:"FIELDING",label:"Named 9-man field",currentSetting:t.length===9?`${a.ring} in ring · ${a.boundary} outside · ${a.closeCatchers} slip${a.closeCatchers===1?"":"s"}`:"Awaiting innings",upside:"Slips maximize edge catches; ring fielders cut singles and create run-out pressure; deep riders suppress fours and sixes.",tradeOff:"Pushing fielders to the boundary opens single-taking gaps in the ring; circle and leg-side limits apply by format and striker hand."}]}const Xr={line:"STUMPS",length:"GOOD",variationId:"stock",effort:"NORMAL"},Md={aggression:2,intent:"NORMAL"},Y1=new Set(["BOWLED","LBW","CAUGHT","STUMPED","HIT_WICKET"]);function z1(n,e,t=[]){let a=0,o=0,i=0,r={...Xr},s=[...t];const c=new Map,u=[],h={0:null,1:null};let p=null;const E=[],b=new Map;function w(I,f){const S=`${I}:${f}`,k=b.get(S);if(k)return k;const R=c.get(f)??{...Md},_={inningsIndex:I,playerId:f,dismissed:!1,initialPlan:{...R},planCounts:new Map,planChangesCount:0,ballsFaced:0,runs:0,dots:0,singles:0,boundaries:0};return b.set(S,_),E.push(_),_}function v(){for(const I of[0,1])h[I]&&(h[I].status="COMPLETED",h[I]=null);p&&(p.status="COMPLETED",p=null)}for(const I of n){const f=typeof I.payload=="object"&&I.payload!==null&&!Array.isArray(I.payload)?I.payload:{};if(I.type==="INNINGS_STARTED"){v(),a=typeof f.inningsIndex=="number"?f.inningsIndex:a+1,o=0,i=0,r={...Xr},c.clear();continue}if(I.type==="INNINGS_COMPLETED"||I.type==="DECLARED"||I.type==="MATCH_COMPLETED"){v();continue}if(I.type==="BATTER_SELECTED"){const S=String(f.playerId??"");S&&w(a,S);continue}if(I.type==="BATTING_PLAN_CHANGED"){const S=String(f.playerId??""),k=typeof f.aggression=="number"?f.aggression:2,R=f.intent==="ROTATE"||f.intent==="PROTECT"?f.intent:"NORMAL";if(S){c.set(S,{aggression:k,intent:R});const _=w(a,S);_.planChangesCount+=1,_.ballsFaced===0&&(_.initialPlan={aggression:k,intent:R})}continue}if(I.type==="BOWLER_SELECTED"){const S=String(f.playerId??""),k=Math.floor(o/6),R=k%2;r={...Xr};const _=h[R];if(_&&_.bowlerId===S)_.status="IN_PROGRESS",_.endOver=k+1,p=_;else{_&&(_.status="COMPLETED");const U=1-R;h[U]?.bowlerId===S&&(h[U].status="COMPLETED",h[U]=null),i+=1;const M={inningsIndex:a,spellNumberInInnings:i,endParity:R,bowlerId:S,status:"IN_PROGRESS",startOver:k+1,endOver:k+1,planCounts:new Map,initialPlan:{...r},planChangesCount:0,fieldChangesCount:0,latestFieldSlots:[...s],legalBalls:0,deliveryAttempts:0,runsConceded:0,wickets:0,dots:0,singles:0,boundaries:0,fours:0,sixes:0,wides:0,noBalls:0,intendedLengthMatches:0,intendedLengthEvaluatedBalls:0,executedLengths:{YORKER:0,FULL:0,GOOD:0,SHORT:0,FULL_TOSS:0},trajectories:{GROUND:0,AERIAL:0,EDGE:0,NO_CONTACT:0},fieldOutcomes:{STOP:0,CATCH:0,DROP:0,MISS:0,RUN_OUT:0}};h[R]=M,p=M,u.push(M)}continue}if(I.type==="BOWLING_PLAN_CHANGED"){const S=f.line==="OFF"||f.line==="LEG"?f.line:"STUMPS",k=f.length==="YORKER"||f.length==="FULL"||f.length==="SHORT"?f.length:"GOOD",R=f.effort==="CONSERVE"||f.effort==="MAXIMUM"?f.effort:"NORMAL",_=typeof f.variationId=="string"&&f.variationId.length>0?f.variationId:"stock";r={line:S,length:k,variationId:_,effort:R},p&&(p.planChangesCount+=1,p.deliveryAttempts===0&&(p.initialPlan={...r}));continue}if(I.type==="FIELD_CHANGED"){Array.isArray(f.fieldSlots)&&(s=f.fieldSlots.map(S=>({slotId:S.slotId,playerId:S.playerId})),p&&(p.fieldChangesCount+=1,p.latestFieldSlots=[...s]));continue}if(I.type==="OVER_COMPLETED"){p&&p.status==="IN_PROGRESS"&&(p.status="BETWEEN_OVERS");continue}if(I.type==="DELIVERY_RECORDED"){const S=f.event;if(!S)continue;const k=Math.floor(o/6);(!p||p.bowlerId!==S.bowlerId)&&(i+=1,p={inningsIndex:S.inningsIndex,spellNumberInInnings:i,endParity:k%2,bowlerId:S.bowlerId,status:"IN_PROGRESS",startOver:k+1,endOver:k+1,planCounts:new Map,initialPlan:{...r},planChangesCount:0,fieldChangesCount:0,latestFieldSlots:[...s],legalBalls:0,deliveryAttempts:0,runsConceded:0,wickets:0,dots:0,singles:0,boundaries:0,fours:0,sixes:0,wides:0,noBalls:0,intendedLengthMatches:0,intendedLengthEvaluatedBalls:0,executedLengths:{YORKER:0,FULL:0,GOOD:0,SHORT:0,FULL_TOSS:0},trajectories:{GROUND:0,AERIAL:0,EDGE:0,NO_CONTACT:0},fieldOutcomes:{STOP:0,CATCH:0,DROP:0,MISS:0,RUN_OUT:0}},u.push(p)),p.endOver=Math.max(p.endOver,k+1),p.latestFieldSlots=s.length===9?[...s]:p.latestFieldSlots,p.deliveryAttempts+=1;const R=`${r.line}|${r.length}|${r.effort}|${r.variationId}`,_=p.planCounts.get(R);_?_.balls+=1:p.planCounts.set(R,{plan:{...r},balls:1}),S.legalBall&&(p.legalBalls+=1,o+=1);const U=S.batRuns+S.extras.wides+S.extras.noBalls;p.runsConceded+=U,S.legality==="WIDE"&&(p.wides+=S.extras.wides),S.legality==="NO_BALL"&&(p.noBalls+=S.extras.noBalls),S.legalBall&&S.batRuns===0&&S.extras.wides===0&&S.extras.noBalls===0&&S.extras.byes===0&&S.extras.legByes===0&&(p.dots+=1),S.batRuns===1&&S.boundary==="NONE"&&(p.singles+=1),S.boundary==="FOUR"?(p.boundaries+=1,p.fours+=1):S.boundary==="SIX"&&(p.boundaries+=1,p.sixes+=1),S.dismissal&&Y1.has(S.dismissal.kind)&&(p.wickets+=1),S.executedLength&&(p.executedLengths[S.executedLength]+=1,p.intendedLengthEvaluatedBalls+=1,S.executedLength===r.length&&(p.intendedLengthMatches+=1)),S.trajectory?p.trajectories[S.trajectory]+=1:p.trajectories.NO_CONTACT+=1,S.fieldOutcome!=="NONE"&&(p.fieldOutcomes[S.fieldOutcome]+=1);const M=w(S.inningsIndex,S.strikerId),H=c.get(S.strikerId)??{...Md},an=`${H.aggression}|${H.intent}`;if(S.countsAsBallFaced){M.ballsFaced+=1;const y=M.planCounts.get(an);y?y.balls+=1:M.planCounts.set(an,{plan:{...H},balls:1}),S.batRuns===0&&(M.dots+=1)}if(M.runs+=S.batRuns,S.batRuns===1&&S.boundary==="NONE"&&(M.singles+=1),(S.boundary==="FOUR"||S.boundary==="SIX")&&(M.boundaries+=1),S.dismissal){const y=w(S.inningsIndex,S.dismissal.playerId);y.dismissed=!0}}}const T=u.filter(I=>I.deliveryAttempts>0).map(I=>{let f=I.initialPlan,S=-1;for(const y of I.planCounts.values())y.balls>S&&(S=y.balls,f=y.plan);const k=Fd(I.latestFieldSlots),R=oo(I.legalBalls),_=I.legalBalls>0?Math.round(I.runsConceded*600/I.legalBalls):null,U=_===null?"—":(_/100).toFixed(2),M=e[I.bowlerId]??I.bowlerId,an=`${I.status==="COMPLETED"?"Completed spell":I.status==="BETWEEN_OVERS"?"Spell between overs":"Current over"} (overs ${I.startOver}–${I.endOver}): accepted plan targeted ${f.length} length on ${f.line} (${f.effort} effort, ${f.variationId}, ${k.ring} in ring / ${k.boundary} deep). Recorded ${R} overs, ${I.wickets}/${I.runsConceded} (econ ${U}), ${I.intendedLengthMatches}/${I.intendedLengthEvaluatedBalls} on intended length, ${I.dots} dots, ${I.boundaries} boundaries.`;return{spellId:`inn${I.inningsIndex}-spell${I.spellNumberInInnings}-${I.bowlerId}`,inningsIndex:I.inningsIndex,spellNumberInInnings:I.spellNumberInInnings,bowlerId:I.bowlerId,bowlerName:M,status:I.status,startOver:I.startOver,endOver:I.endOver,acceptedPlan:{primaryLine:f.line,primaryLength:f.length,primaryEffort:f.effort,primaryVariationId:f.variationId,latestRingFielders:k.ring,latestBoundaryFielders:k.boundary,latestCloseCatchers:k.closeCatchers,planChangesCount:I.planChangesCount,fieldChangesCount:I.fieldChangesCount},outcomes:{legalBalls:I.legalBalls,oversDisplay:R,deliveryAttempts:I.deliveryAttempts,runsConceded:I.runsConceded,wickets:I.wickets,dots:I.dots,singles:I.singles,boundaries:I.boundaries,fours:I.fours,sixes:I.sixes,wides:I.wides,noBalls:I.noBalls,economyX100:_,intendedLengthMatches:I.intendedLengthMatches,intendedLengthEvaluatedBalls:I.intendedLengthEvaluatedBalls,executedLengths:{...I.executedLengths},trajectories:{...I.trajectories},fieldOutcomes:{...I.fieldOutcomes}},factualSummary:an}}).reverse(),A=E.filter(I=>I.ballsFaced>0||I.runs>0||I.dismissed).map(I=>{let f=I.initialPlan,S=-1;for(const M of I.planCounts.values())M.balls>S&&(S=M.balls,f=M.plan);const k=I.ballsFaced>0?Math.round(I.runs*1e4/I.ballsFaced):null,R=k===null?"—":(k/100).toFixed(2),_=e[I.playerId]??I.playerId,U=`Accepted plan: aggression ${f.aggression}/4 (${f.intent}). Recorded ${I.runs}${I.dismissed?"":"*"} (${I.ballsFaced}b, SR ${R}), ${I.dots} dots, ${I.singles} singles, ${I.boundaries} boundaries.`;return{stintId:`inn${I.inningsIndex}-bat-${I.playerId}`,inningsIndex:I.inningsIndex,playerId:I.playerId,playerName:_,dismissed:I.dismissed,acceptedPlan:{primaryAggression:f.aggression,primaryIntent:f.intent,planChangesCount:I.planChangesCount},outcomes:{ballsFaced:I.ballsFaced,runs:I.runs,dots:I.dots,singles:I.singles,boundaries:I.boundaries,strikeRateX100:k},factualSummary:U}}).reverse();return{spellReviews:T,battingStintReviews:A}}function Jr(n){const e=n.innings[n.activeIndex],t=e?.innings,a=t?.legalBalls??0,o=t?.runs??0,i=t?.wickets??0,r=t?.targetToWin??null,s=t==null?null:t.strikerEnd==="NORTH"?t.northBatterId:t.southBatterId,c=s!=null?n.activeBattingPlans[s]??{aggression:2,intent:"NORMAL"}:null;let u=`${n.format} · ${n.phase}`,h="Named 9-man field · max 5 leg-side · max 2 behind square leg.";n.format==="T20"?a<36?(u="T20 Powerplay (Overs 0.0–5.5)",h="Max 2 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):a<90?(u="T20 Middle Overs (Overs 6.0–14.5)",h="Max 5 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):(u="T20 Late Overs (Overs 15.0–19.5)",h="Max 5 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):n.format==="ODI"?a<60?(u="ODI Powerplay 1 (Overs 0.0–9.5)",h="Max 2 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):a<240?(u="ODI Middle Overs (Overs 10.0–39.5)",h="Max 4 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):(u="ODI Late Overs (Overs 40.0–49.5)",h="Max 5 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):(u=`Five-day Red-ball · Day ${n.redBallDay??1} · Innings ${n.activeIndex+1}`,h="No circle limit · max 5 leg-side · max 2 behind square leg · new ball at 80.0 overs.");const p=n.format==="T20"?120:n.format==="ODI"?300:null,E=p===null?null:Math.max(0,p-a),b=a>0?(o*6/a).toFixed(2):"0.00",w=r!==null&&E!==null&&E>0?(Math.max(0,r-o)*6/E).toFixed(2):null;let v=t?`${o}/${i} (${oo(a)} ov, CRR ${b}) · ${10-i} wicket${10-i===1?"":"s"} in hand.`:"Match setup complete; awaiting opening innings.";if(t&&r!==null){const H=Math.max(0,r-o);v=E!==null?`Chasing ${r}: need ${H} from ${E} balls (RRR ${w??"—"}, CRR ${b}, ${10-i} wkts in hand).`:`Fourth-innings target ${r}: need ${H} more runs (${10-i} wkts in hand).`}else if(t&&n.format==="RED_BALL"&&n.innings.length>1){const H=t.battingTeamId,an=n.innings.filter($=>$.innings.battingTeamId===H).reduce(($,P)=>$+P.innings.runs,0),y=n.innings.filter($=>$.innings.battingTeamId!==H).reduce(($,P)=>$+P.innings.runs,0),L=an-y;v=`${o}/${i} (${oo(a)} ov) · batting side ${L>=0?`leads by ${L}`:`trails by ${Math.abs(L)}`} overall.`}const T=`Seam ${(n.pitch.seamBp/100).toFixed(2)}/100 · Spin ${(n.pitch.turnBp/100).toFixed(2)}/100 · Wear ${n.pitch.wearPoints} pts.`;let A="No active bowler selected.";const I=t?.bowlerId??n.activeBowlingPlan?.bowlerId??null;if(I&&e){const H=e.bowling[I],an=H?.legalBalls??0,y=n.fatigueBpByPlayerId[I]??0,L=n.format==="T20"?24:n.format==="ODI"?60:null,$=L===null?"no over cap":`${oo(Math.max(0,L-an))} ov left in quota`;A=`${n.names[I]??I}: ${oo(an)} ov, ${H?.wickets??0}/${H?.runsConceded??0} · Fatigue ${Math.round(y/100)}% · ${$}.`}const f=j1(c,n.activeBowlingPlan,n.activeFieldSlots),S=[],k=n.format==="T20"&&a>=90||n.format==="ODI"&&a>=240,R=n.format==="T20"&&a>=36&&a<90||n.format==="ODI"&&a>=60&&a<240,_=w===null?null:Number(w);if(s&&c){const H=i>=4&&(E===null||E>24);S.push({presetId:"BAT_CONSOLIDATE",commandKind:"SET_BATTING_PLAN",label:"Consolidate & protect wicket",whenToUse:"Rebuild after early wickets, survive a testing spell, or bat time in red-ball.",tradeOff:"Lowers boundary frequency and passes up tight singles (aggression 1, PROTECT).",contextualMatch:H||n.format==="RED_BALL"&&i>=5,contextualReason:H?`${i} wickets down with overs remaining.`:"",activeNow:c.aggression===1&&c.intent==="PROTECT",battingPatch:{aggression:1,intent:"PROTECT"}},{presetId:"BAT_ROTATE_STRIKE",commandKind:"SET_BATTING_PLAN",label:"Work singles & rotate strike",whenToUse:"Keep the scoreboard moving in middle overs or a measured chase.",tradeOff:"Increases single attempts and run-out exposure against inner-ring fielders (aggression 2, ROTATE).",contextualMatch:R||_!==null&&_>=5&&_<=8,contextualReason:R?"Middle-overs spread field leaves single-taking pockets.":_!==null&&_>=5&&_<=8?`Measured required rate (${w}).`:"",activeNow:c.aggression===2&&c.intent==="ROTATE",battingPatch:{aggression:2,intent:"ROTATE"}},{presetId:"BAT_BALANCED_TEMPO",commandKind:"SET_BATTING_PLAN",label:"Balanced tempo",whenToUse:"Default tempo when building an innings platform without extra run-out risk.",tradeOff:"Neutral contact and running weights (aggression 2, NORMAL).",contextualMatch:!H&&!R&&!k&&(_===null||_<=8),contextualReason:!H&&!R&&!k?"Opening phase platform.":"",activeNow:c.aggression===2&&c.intent==="NORMAL",battingPatch:{aggression:2,intent:"NORMAL"}},{presetId:"BAT_BOUNDARY_PUSH",commandKind:"SET_BATTING_PLAN",label:"Boundary push",whenToUse:"Accelerate in death overs or chase a steep required rate with wickets in hand.",tradeOff:"Sharply increases aerial, edge, and miss dismissal exposure (aggression 4, NORMAL).",contextualMatch:k&&i<=6||_!==null&&_>8.5,contextualReason:_!==null&&_>8.5?`Required rate is ${w} per over.`:k?"Death-overs acceleration window.":"",activeNow:c.aggression===4&&c.intent==="NORMAL",battingPatch:{aggression:4,intent:"NORMAL"}})}if(n.activeBowlingPlan){const H=n.activeBowlingPlan,an=n.fatigueBpByPlayerId[H.bowlerId]??0,y=n.bowlerVariationsByPlayerId[H.bowlerId]??["stock"],L=y.includes("stock")?"stock":y[0]??"stock",$=n.format==="T20"&&a<36||n.format==="ODI"&&a<60;S.push({presetId:"BOWL_DISCIPLINED_CHANNEL",commandKind:"SET_BOWLING_PLAN",label:"Disciplined off-stump channel",whenToUse:"Standard containing and wicket-hunting plan feeding off-side ring and slip fielders.",tradeOff:"Missed lengths spill to FULL rather than yorkers (OFF, GOOD, NORMAL).",contextualMatch:!k&&an<4500,contextualReason:!k&&an<4500?"Controlled channel with fresh bowler.":"",activeNow:H.line==="OFF"&&H.length==="GOOD"&&H.effort==="NORMAL"&&H.variationId===L,bowlingPatch:{line:"OFF",length:"GOOD",effort:"NORMAL",variationId:L}},{presetId:"BOWL_ATTACK_STUMPS",commandKind:"SET_BOWLING_PLAN",label:"Pitch full at the stumps",whenToUse:"Search for bowled/LBW with a new ball, seam/spin movement, or against lower-order batters.",tradeOff:"Length errors become high-scoring full tosses (STUMPS, FULL, NORMAL).",contextualMatch:$||i>=7||n.pitch.seamBp>=5600,contextualReason:i>=7?"Lower order exposed.":$?"Powerplay / new-ball wicket window.":n.pitch.seamBp>=5600?"Above-neutral seam assistance.":"",activeNow:H.line==="STUMPS"&&H.length==="FULL"&&H.effort==="NORMAL"&&H.variationId===L,bowlingPatch:{line:"STUMPS",length:"FULL",effort:"NORMAL",variationId:L}},{presetId:"BOWL_CONSERVE_SPELL",commandKind:"SET_BOWLING_PLAN",label:"Conserve spell accuracy",whenToUse:"Extend a tired bowler's spell or cut extras when fatigue rises above 40%.",tradeOff:"Uses CONSERVE effort rather than maximum pace effort (OFF, GOOD, CONSERVE).",contextualMatch:an>=4e3,contextualReason:an>=4e3?`Active bowler fatigue is ${Math.round(an/100)}%.`:"",activeNow:H.line==="OFF"&&H.length==="GOOD"&&H.effort==="CONSERVE"&&H.variationId===L,bowlingPatch:{line:"OFF",length:"GOOD",effort:"CONSERVE",variationId:L}},{presetId:"BOWL_YORKER_CLOSE",commandKind:"SET_BOWLING_PLAN",label:"Death-overs yorker plan",whenToUse:"Suppress lofted boundaries in the closing overs with a high-control, rested bowler.",tradeOff:"Missed yorkers become full tosses, and MAXIMUM effort adds wide/no-ball and fatigue risk.",contextualMatch:k&&an<4500,contextualReason:k&&an<4500?"Late overs with rested bowler.":"",activeNow:H.line==="STUMPS"&&H.length==="YORKER"&&H.effort==="MAXIMUM"&&H.variationId===L,bowlingPatch:{line:"STUMPS",length:"YORKER",effort:"MAXIMUM",variationId:L}},{presetId:"BOWL_SHORT_TEST",commandKind:"SET_BOWLING_PLAN",label:"Short-ball examination",whenToUse:"Force aerial and edge contact for a short burst when catchers are in place.",tradeOff:"Raises aerial boundary risk plus MAXIMUM effort extras and faster fatigue.",contextualMatch:n.format==="RED_BALL"&&i>=6&&an<3500,contextualReason:n.format==="RED_BALL"&&i>=6&&an<3500?"Rested bowler testing lower order.":"",activeNow:H.line==="OFF"&&H.length==="SHORT"&&H.effort==="MAXIMUM"&&H.variationId===L,bowlingPatch:{line:"OFF",length:"SHORT",effort:"MAXIMUM",variationId:L}})}if(n.outfieldIds.length===9){const H=qr(n.outfieldIds,Kr(n.format,a,"SLIP_ATTACK")),an=qr(n.outfieldIds,Kr(n.format,a,"BALANCED_RING")),y=qr(n.outfieldIds,Kr(n.format,a,"BOUNDARY_PROTECT")),L=n.format==="T20"&&a<36||n.format==="ODI"&&a<60;S.push({presetId:"FIELD_SLIP_ATTACK",commandKind:"SET_FIELD",label:"Attacking two-slip cordon",whenToUse:"Convert edges with a new ball, live seam/spin pitch, or exposed lower order.",tradeOff:"Leaves fewer boundary sweepers if batters clear the infield (7 in ring, 2 slips, 2 deep).",contextualMatch:L||i>=7||n.format==="RED_BALL",contextualReason:L?"Legal 2-out powerplay cordon.":i>=7?"Catching cordon for lower order.":"",activeNow:Zr(n.activeFieldSlots,H),fieldSlots:H},{presetId:"FIELD_BALANCED_RING",commandKind:"SET_FIELD",label:"Balanced slip & ring",whenToUse:"Keep 1 slip and ring single-saving cover while posting phase-legal sweepers.",tradeOff:"Splits protection between edge catching and deep boundary cover.",contextualMatch:R,contextualReason:R?"Middle-overs ring + sweeper balance.":"",activeNow:Zr(n.activeFieldSlots,an),fieldSlots:an},{presetId:"FIELD_BOUNDARY_PROTECT",commandKind:"SET_FIELD",label:"Boundary rider defence",whenToUse:"Defend a total in late overs or against high-aggression boundary hitting.",tradeOff:"Removes slips and opens single-taking space inside the circle.",contextualMatch:k||_!==null&&_>8,contextualReason:k?"Maximum phase-legal boundary protection.":_!==null&&_>8?"Chasing side needs boundaries.":"",activeNow:Zr(n.activeFieldSlots,y),fieldSlots:y})}const{spellReviews:U,battingStintReviews:M}=z1(n.events,n.names,n.activeFieldSlots);return L2.parse({version:Pr,format:n.format,situation:{phaseLabel:u,fieldRestrictionLabel:h,scoreContextLabel:v,pitchSummaryLabel:T,activeBowlerWorkloadLabel:A},controlGuide:f,presets:S,spellReviews:U,battingStintReviews:M})}const Vd="Illustrative highlight from committed event categories — no measured ball speed, distance, or tracking coordinates.",Qr=[{slotId:"slip-1",label:"First slip",sector:7,depth:"INNER",insideCircle:!0,legSideRhb:!1,behindSquare:!0,rhbPoint:{x10:1135,y10:1315}},{slotId:"slip-2",label:"Second slip",sector:7,depth:"INNER",insideCircle:!0,legSideRhb:!1,behindSquare:!0,rhbPoint:{x10:1225,y10:1275}},{slotId:"point",label:"Point",sector:6,depth:"MIDDLE",insideCircle:!0,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1380,y10:1080}},{slotId:"cover",label:"Cover",sector:5,depth:"MIDDLE",insideCircle:!0,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1320,y10:820}},{slotId:"mid-off",label:"Mid-off",sector:4,depth:"MIDDLE",insideCircle:!0,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1145,y10:650}},{slotId:"mid-on",label:"Mid-on",sector:4,depth:"MIDDLE",insideCircle:!0,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:855,y10:650}},{slotId:"midwicket",label:"Midwicket",sector:3,depth:"MIDDLE",insideCircle:!0,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:680,y10:820}},{slotId:"deep-square-leg",label:"Deep square leg",sector:2,depth:"DEEP",insideCircle:!1,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:245,y10:1050}},{slotId:"fine-leg",label:"Fine leg",sector:1,depth:"DEEP",insideCircle:!1,legSideRhb:!0,behindSquare:!0,rhbPoint:{x10:460,y10:1530}},{slotId:"deep-cover",label:"Deep cover",sector:5,depth:"DEEP",insideCircle:!1,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1560,y10:480}},{slotId:"long-on",label:"Long-on",sector:4,depth:"DEEP",insideCircle:!1,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:790,y10:240}},{slotId:"long-off",label:"Long-off",sector:4,depth:"DEEP",insideCircle:!1,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1210,y10:240},odiOnly:!0}],Wd=new Map(Qr.map(n=>[n.slotId,n])),Ud={x10:1e3,y10:740},$d={x10:1e3,y10:1180},K1={x10:1e3,y10:1340};function Gd(n,e){if(!Number.isInteger(n)||n<0||n>7)throw new Error("INVALID_PRESENTATION_SECTOR");return e==="L"?7-n:n}function jd(n,e){return{x10:e==="L"?2e3-n.x10:n.x10,y10:n.y10}}function Yd(n){return n==="ODI"?Qr:Qr.filter(e=>!e.odiOnly)}function q1(n,e){return n==="T20"?e<36?{maxOutsideCircle:2,phaseLabel:"T20 Powerplay (overs 1–6): max 2 outside circle"}:{maxOutsideCircle:5,phaseLabel:"T20 Overs 7–20: max 5 outside circle"}:n==="ODI"?e<60?{maxOutsideCircle:2,phaseLabel:"ODI Powerplay 1 (overs 1–10): max 2 outside circle"}:e<240?{maxOutsideCircle:4,phaseLabel:"ODI Powerplay 2 (overs 11–40): max 4 outside circle"}:{maxOutsideCircle:5,phaseLabel:"ODI Powerplay 3 (overs 41–50): max 5 outside circle"}:{maxOutsideCircle:9,phaseLabel:"Five-day red-ball: outer circle unrestricted, max 5 leg side, max 2 behind square leg"}}function Z1(n){const{format:e,strikerHand:t,legalBalls:a,fieldSlots:o,outfieldIds:i}=n,{maxOutsideCircle:r,phaseLabel:s}=q1(e,a),c=new Set(Yd(e).map(k=>k.slotId)),u=[];if(o.length!==9&&u.push({code:"SLOT_COUNT",message:`Exactly 9 outfielders must be placed (currently ${o.length}).`,affectedSlotIds:[]}),i.length===9){const k=[...o.map(_=>_.playerId)].sort().join("|"),R=[...i].sort().join("|");k!==R&&u.push({code:"UNIQUE_PLAYERS",message:"Every active outfielder must be assigned to exactly one field position.",affectedSlotIds:[]})}else new Set(o.map(k=>k.playerId)).size!==o.length&&u.push({code:"UNIQUE_PLAYERS",message:"Each outfielder may occupy only one position.",affectedSlotIds:[]});const h=new Map;for(const k of o)h.set(k.slotId,(h.get(k.slotId)??0)+1);const p=[...h.entries()].filter(([,k])=>k>1).map(([k])=>k);if(p.length>0){const k=p.map(R=>Wd.get(R)?.label??R);u.push({code:"DUPLICATE_POSITION",message:`Duplicate field position${p.length>1?"s":""}: ${k.join(", ")}.`,affectedSlotIds:p.slice(0,9)})}const E=[...new Set(o.map(k=>k.slotId).filter(k=>!c.has(k)))];E.length>0&&u.push({code:"UNSUPPORTED_POSITION",message:`Unsupported position for ${e}: ${E.join(", ")}.`,affectedSlotIds:E.slice(0,9)});let b=0,w=0,v=0;const T=[],A=[],I=[];for(const k of o){const R=Wd.get(k.slotId);if(!R)continue;R.insideCircle||(b+=1,T.push(k.slotId)),(t==="R"?R.legSideRhb:!R.legSideRhb)&&(w+=1,A.push(k.slotId),R.behindSquare&&(v+=1,I.push(k.slotId)))}b>r&&u.push({code:"CIRCLE_RESTRICTION",message:`Too many fielders outside the 30-yard circle (${b}/${r} allowed in this phase).`,affectedSlotIds:[...new Set(T)].slice(0,9)}),w>5&&u.push({code:"LEG_SIDE_LIMIT",message:`Too many leg-side fielders for ${t==="L"?"left-hand":"right-hand"} striker (${w}/5 maximum).`,affectedSlotIds:[...new Set(A)].slice(0,9)}),v>2&&u.push({code:"BEHIND_SQUARE_LEG_LIMIT",message:`Too many fielders behind square on the leg side (${v}/2 maximum).`,affectedSlotIds:[...new Set(I)].slice(0,9)});const f=u.length===0,S=f?`Legal field (${t}HB): ${b}/${r} outside circle · ${w}/5 leg side · ${v}/2 behind square leg.`:u.map(k=>k.message).join(" ");return hd.parse({isLegal:f,format:e,strikerHand:t,phaseLabel:s,outsideCircleCount:b,maxOutsideCircle:r,legSideCount:w,maxLegSide:5,behindSquareLegCount:v,maxBehindSquareLeg:2,duplicateSlotIds:p,violations:u,summaryText:S.slice(0,320)})}function X1(n,e){const t=n.slice(0,8),a=Number.parseInt(t,16);return((Number.isFinite(a)?a:0)^Math.imul(e,2654435761))>>>0&255}function J1(n,e){const t=(e%5-2)*5,a=n==="YORKER"?1155:n==="FULL_TOSS"?1170:n==="FULL"?1095:n==="SHORT"?925:1020;return{x10:1e3+t,y10:a}}function Q1(n){const{displaySector:e,boundary:t,fieldOutcome:a,runsScored:o,variationByte:i}=n,s=((i>>3)%7-3)*.045,c=(e-3.5)*(Math.PI/4)+s,u=t==="SIX"?895:t==="FOUR"?840:a==="CATCH"?530+i%150:a==="STOP"||o===0?370+i%70:o===1?520+i%80:670+i%90,h=Math.round(1e3+Math.sin(c)*u),p=Math.round(1e3-Math.cos(c)*u);return{x10:Math.max(40,Math.min(1960,h)),y10:Math.max(40,Math.min(1960,p))}}function nS(n){if(n.dismissal)return{momentKind:"WICKET",isKeyMoment:!0};if(n.boundary==="SIX")return{momentKind:"SIX",isKeyMoment:!0};if(n.boundary==="FOUR")return{momentKind:"FOUR",isKeyMoment:!0};if(n.freeHitNext)return{momentKind:"FREE_HIT",isKeyMoment:!0};const e=n.extras.wides+n.extras.noBalls+n.extras.byes+n.extras.legByes+n.extras.penalties;return n.legality!=="LEGAL"||e>0?{momentKind:"EXTRA",isKeyMoment:!1}:n.batRuns+n.completedRuns>0?{momentKind:"RUNS",isKeyMoment:!1}:{momentKind:"DOT",isKeyMoment:!1}}function eS(n){const{events:e,names:t,hands:a}=n,o=new Map,i=[];for(const r of e){if(r.type!=="DELIVERY_RECORDED")continue;const c=r.payload?.event;if(!c||c.type!=="DELIVERY_RECORDED")continue;const u=o.get(c.inningsIndex)??0,h=c.legalBall?u+1:u;o.set(c.inningsIndex,h);const p=Math.floor((c.legalBall?h-1:u)/6),E=c.legalBall?(h-1)%6+1:u%6+1,b=c.legality==="WIDE"?`${p}.${E}wd`:c.legality==="NO_BALL"?`${p}.${E}nb`:`${p}.${E}`,w=a[c.strikerId]??"R",v=t[c.strikerId]??c.strikerId,T=t[c.bowlerId]??c.bowlerId,A=c.dismissal?t[c.dismissal.playerId]??c.dismissal.playerId:null,I=c.extras.wides+c.extras.noBalls+c.extras.byes+c.extras.legByes+c.extras.penalties,f=c.batRuns+I,{momentKind:S,isKeyMoment:k}=nS(c),R=X1(r.eventHash,r.sequence),_=J1(c.executedLength,R),M=typeof c.shotSector=="number"&&Number.isInteger(c.shotSector)&&c.shotSector>=0&&c.shotSector<=7?c.shotSector:null,H=M!==null?Gd(M,w):null,an=H!==null?"RECORDED_SECTOR":"PITCH_CHANNEL_ONLY",y=H!==null?Q1({displaySector:H,boundary:c.boundary,fieldOutcome:c.fieldOutcome,runsScored:f,variationByte:R}):c.dismissal&&["BOWLED","LBW","HIT_WICKET"].includes(c.dismissal.kind)?{x10:1e3,y10:1190}:{x10:1e3,y10:1330},L=c.dismissal?`WICKET · ${A} (${c.dismissal.kind.toLowerCase().replaceAll("_"," ")})`:c.boundary==="SIX"?`SIX · ${v} off ${T}`:c.boundary==="FOUR"?`FOUR · ${v} off ${T}`:c.freeHitNext?`NO-BALL (Free hit next) · ${f} run${f===1?"":"s"}`:`${b} · ${T} to ${v}: ${f} run${f===1?"":"s"}`,$=M!==null?`Recorded sector ${M+1} (${w}HB display sector ${(H??M)+1})`:"No shot sector recorded (pitch/keeper channel only)",P=c.executedLength?`${c.executedLength.toLowerCase().replaceAll("_"," ")} length`:"unrecorded length",B=c.trajectory?`, ${c.trajectory.toLowerCase()} trajectory`:"",W=`${b}: ${P}${B}. ${$}.`;i.push(xr.parse({sequence:r.sequence,eventHash:r.eventHash,inningsIndex:c.inningsIndex,deliveryIndex:c.deliveryIndex,overBallLabel:b,strikerId:c.strikerId,strikerName:v,strikerHand:w,bowlerId:c.bowlerId,bowlerName:T,momentKind:S,isKeyMoment:k,runsScored:f,batRuns:c.batRuns,boundary:c.boundary,legality:c.legality,dismissalKind:c.dismissal?c.dismissal.kind:null,dismissedPlayerName:A,fieldOutcome:c.fieldOutcome,executedLength:c.executedLength,trajectory:c.trajectory,recordedSector:M,displaySector:H,sectorStatus:an,releasePoint:Ud,pitchBouncePoint:_,strikerCreasePoint:$d,targetPoint:y,headline:L.slice(0,160),detailText:W.slice(0,280),trackingDisclaimer:Vd}))}return i.slice(-24)}function ns(n){const{format:e,phase:t,innings:a,activeIndex:o,fieldSlots:i,events:r,names:s,hands:c}=n,u=a[o]??a[a.length-1]??null,h=u?.innings??null,p=h===null?null:h.strikerEnd==="NORTH"?h.northBatterId:h.southBatterId,E=h===null?null:h.strikerEnd==="NORTH"?h.southBatterId:h.northBatterId,b=h?.bowlerId??null,w=u?.keeperId??null,v=p&&c[p]||"R",T=new Map(i.map(R=>[R.slotId,R.playerId])),A=Yd(e).map(R=>{const _=T.get(R.slotId)??null;return{slotId:R.slotId,label:R.label,sector:R.sector,displaySector:Gd(R.sector,v),depth:R.depth,insideCircle:R.insideCircle,legSideForStriker:v==="R"?R.legSideRhb:!R.legSideRhb,behindSquare:R.behindSquare,point:jd(R.rhbPoint,v),occupiedByPlayerId:_,occupiedByName:_?s[_]??_:null}}),I=Z1({format:e,strikerHand:v,legalBalls:h?.legalBalls??0,fieldSlots:i,outfieldIds:u?.outfieldIds??i.map(R=>R.playerId)}),f=eS({events:r,names:s,hands:c}),S=f.length>0?f[f.length-1]:null,k=v==="L"?"Left-hand batter on strike: off side is on the left, leg side is on the right.":"Right-hand batter on strike: off side is on the right, leg side is on the left.";return B2.parse({version:pd,format:e,phase:t,activeInningsIndex:Math.min(3,Math.max(0,o)),strikerId:p,strikerName:p?s[p]??p:null,strikerHand:v,nonStrikerId:E,nonStrikerName:E?s[E]??E:null,bowlerId:b,bowlerName:b?s[b]??b:null,keeperId:w,keeperName:w?s[w]??w:null,keeperPoint:K1,bowlerReleasePoint:Ud,strikerPoint:$d,nonStrikerPoint:jd({x10:935,y10:755},v),boundaryRadiusX10:840,circleRadiusX10:480,positions:A,legality:I,recentHighlights:f,latestHighlight:S,orientationNote:k,trackingDisclaimer:Vd})}const tS=3,zd=["third man","point","cover","mid-off","mid-on","mid-wicket","square leg","fine leg"],aS={YORKER:"yorker",FULL:"full",GOOD:"good-length",SHORT:"short",FULL_TOSS:"full-toss"},oS={GROUND:"along the turf",AERIAL:"in the air",EDGE:"off the edge"};function Ne(n){let e=2166136261;for(let t=0;t<n.length;t+=1)e^=n.charCodeAt(t),e=Math.imul(e,16777619);return e>>>0}function ye(n){return(n>>>0).toString(16).padStart(8,"0")}function Na(n){return`${Math.floor(n/6)}.${n%6}`}function iS(n){return`${Math.floor(n/6)}.${n%6+1}`}function Qo(n){return`${Na(n.legalBalls)}-${n.maidens}-${n.runsConceded}-${n.wickets}`}function rS(n){return n==="T20"?120:n==="ODI"?300:null}function io(n,e,t,a,o,i,r){const s=Ne(`${t}|${a}|${o}|${n}`),c=ye(s),u=s%e.length;let h=u,p=!1;if(e.length>1&&r>0){const b=i.slice(-r);if(b.includes(e[u].id))for(let w=1;w<e.length;w+=1){const v=(u+w)%e.length;if(!b.includes(e[v].id)){h=v,p=!0;break}}}const E=e[h];return i.push(E.id),{selected:E,cooldownApplied:p,digest:c}}function sS(n,e,t,a){if(n==="T20"||n==="ODI")return e===1&&a[0]?a[0].runs+1:null;if(e===3&&a.length>=3){let o=0,i=0;for(const s of a)s.battingTeamId===t?o+=s.runs:i+=s.runs;const r=i-o;return r>=0?r+1:null}return null}function es(n){const e=Math.max(1,Math.min(12,n.repetitionCooldownWindow??tS)),t=n.presentationKey??`lcxxvi-commentary:${n.format}:${n.teamIds[0]}:${n.teamIds[1]}:${n.groundName??"ground"}`,a=ye(Ne(t)),o=[],i=w=>w?n.playerNames[w]??w:"Unknown player",r=w=>w?n.teamNames[w]??w:"Unknown team",s=w=>w===n.teamIds[0]?n.teamIds[1]:n.teamIds[0],c=new Map;let u=0;const h=(w,v)=>{const T=c.get(w);if(T)return T;const A=v??n.teamIds[w%2],I=[...c.values()].filter(S=>S.inningsIndex<w),f={inningsIndex:w,battingTeamId:A,bowlingTeamId:s(A),runs:0,wickets:0,legalBalls:0,declared:!1,targetToWin:sS(n.format,w,A,I),allocatedBalls:rS(n.format),overTeamRuns:0,overWickets:0,overLegalBalls:0,pendingFreeHit:!1,partnershipRuns:0,partnershipBalls:0,batters:new Map,bowlers:new Map};return c.set(w,f),f},p=(w,v)=>{let T=w.batters.get(v);return T||(T={runs:0,ballsFaced:0,fours:0,sixes:0},w.batters.set(v,T)),T},E=(w,v)=>{let T=w.bowlers.get(v);return T||(T={legalBalls:0,maidens:0,runsConceded:0,wickets:0,currentOverBowlerRuns:0,currentOverLegalBalls:0},w.bowlers.set(v,T)),T},b=[];for(let w=0;w<n.events.length;w+=1){const v=n.events[w],T=v.eventHash??`seq-${v.sequence}`;if(v.type==="DELIVERY_RECORDED"){const I=v.payload.event;u=I.inningsIndex;const f=h(I.inningsIndex),S=(n.format==="T20"||n.format==="ODI")&&f.pendingFreeHit,k=iS(f.legalBalls),R=i(I.bowlerId),_=i(I.strikerId),U=i(I.nonStrikerId),M=I.extras.wides+I.extras.noBalls+I.extras.byes+I.extras.legByes+I.extras.penalties,H=I.batRuns+M,an=I.batRuns+I.extras.wides+I.extras.noBalls,y=p(f,I.strikerId),L=y.runs;I.countsAsBallFaced&&(y.ballsFaced+=1),y.runs+=I.batRuns,I.boundary==="FOUR"&&(y.fours+=1),I.boundary==="SIX"&&(y.sixes+=1);const $=E(f,I.bowlerId),P=$.wickets;$.runsConceded+=an,$.currentOverBowlerRuns+=an,I.legalBall&&($.legalBalls+=1,$.currentOverLegalBalls+=1),I.dismissal&&I.dismissal.creditedBowlerId===I.bowlerId&&($.wickets+=1);const B=f.partnershipRuns;f.runs+=H,f.overTeamRuns+=H,I.legalBall&&(f.legalBalls+=1,f.overLegalBalls+=1),f.partnershipRuns+=H,(I.legalBall||I.legality==="NO_BALL")&&(f.partnershipBalls+=1);const W=[],Z=[],j=[{slot:"inningsNumber",value:String(I.inningsIndex+1),sourceKind:"EVENT_FIELD",sourceRef:"delivery.inningsIndex"},{slot:"ballCoord",value:k,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.legalBallsBefore"},{slot:"bowlerName",value:R,sourceKind:"EVENT_FIELD",sourceRef:"delivery.bowlerId"},{slot:"strikerName",value:_,sourceKind:"EVENT_FIELD",sourceRef:"delivery.strikerId"},{slot:"teamRuns",value:`${f.runs}/${I.dismissal?f.wickets+1:f.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"}];I.batRuns>0&&(L<200&&y.runs>=200?(W.push("BATTER_DOUBLE_CENTURY"),Z.push(`${_} reaches a double century (${y.runs} off ${y.ballsFaced} balls).`)):L<150&&y.runs>=150?(W.push("BATTER_150"),Z.push(`${_} brings up 150 (${y.runs} off ${y.ballsFaced} balls).`)):L<100&&y.runs>=100?(W.push("BATTER_CENTURY"),Z.push(`Century for ${_} (${y.runs} off ${y.ballsFaced} balls).`)):L<50&&y.runs>=50&&(W.push("BATTER_FIFTY"),Z.push(`Fifty for ${_} (${y.runs} off ${y.ballsFaced} balls).`))),!I.dismissal&&H>0&&(B<150&&f.partnershipRuns>=150?(W.push("PARTNERSHIP_150"),Z.push(`150-run partnership (${f.partnershipRuns} off ${f.partnershipBalls} balls).`)):B<100&&f.partnershipRuns>=100?(W.push("PARTNERSHIP_CENTURY"),Z.push(`100-run stand (${f.partnershipRuns} off ${f.partnershipBalls} balls).`)):B<50&&f.partnershipRuns>=50&&(W.push("PARTNERSHIP_FIFTY"),Z.push(`50-run partnership (${f.partnershipRuns} off ${f.partnershipBalls} balls).`))),P<5&&$.wickets>=5?(W.push("BOWLER_FIVE_FOR"),Z.push(`Five-wicket haul for ${R} (${$.wickets}/${$.runsConceded}).`)):P<3&&$.wickets>=3&&(W.push("BOWLER_THREE_FOR"),Z.push(`Third wicket for ${R} (${$.wickets}/${$.runsConceded}).`));const Q={runs:f.partnershipRuns,balls:f.partnershipBalls};I.dismissal&&(f.wickets+=1,f.overWickets+=1,f.partnershipRuns=0,f.partnershipBalls=0,f.wickets===10&&(W.push("ALL_OUT"),Z.push(`${r(f.battingTeamId)} are all out for ${f.runs}.`))),f.targetToWin!==null&&f.runs>=f.targetToWin&&(W.push("WINNING_DELIVERY"),Z.push(`Winning runs! ${r(f.battingTeamId)} reach ${f.runs}/${f.wickets} to pass the target of ${f.targetToWin}.`),j.push({slot:"targetToWin",value:String(f.targetToWin),sourceKind:"CHASE_PROJECTION",sourceRef:"innings.targetToWin"}));const J=I.shotSector!==null&&zd[I.shotSector]?zd[I.shotSector]:null,pn=I.executedLength!==null?aS[I.executedLength]??I.executedLength.toLowerCase():null,be=I.trajectory!==null?oS[I.trajectory]??I.trajectory.toLowerCase():null;J&&j.push({slot:"shotSector",value:J,sourceKind:"EVENT_FIELD",sourceRef:"delivery.shotSector"}),pn&&j.push({slot:"executedLength",value:pn,sourceKind:"EVENT_FIELD",sourceRef:"delivery.executedLength"}),j.push({slot:"batterScore",value:`${y.runs} (${y.ballsFaced})`,sourceKind:"BATTER_PROJECTION",sourceRef:`batter.${I.strikerId}`},{slot:"bowlerFigures",value:Qo($),sourceKind:"BOWLER_PROJECTION",sourceRef:`bowler.${I.bowlerId}`});const ke=(n.format==="T20"||n.format==="ODI")&&(I.freeHitNext||I.legality==="NO_BALL");S&&j.push({slot:"isFreeHit",value:"true",sourceKind:"FORMAT_RULE",sourceRef:`${n.format}.freeHitDelivery`}),ke?(f.pendingFreeHit=!0,j.push({slot:"freeHitNext",value:"FREE_HIT",sourceKind:"FORMAT_RULE",sourceRef:`${n.format}.freeHitNext`})):I.legalBall&&(f.pendingFreeHit=!1);const je=n.events[w+1]?.type==="OVER_COMPLETED";I.legalBall&&f.overLegalBalls===6&&!je&&($.currentOverLegalBalls===6&&$.currentOverBowlerRuns===0&&($.maidens+=1,W.push("MAIDEN_OVER"),Z.push(`Maiden over completed by ${R}.`)),f.overTeamRuns=0,f.overWickets=0,f.overLegalBalls=0,$.currentOverBowlerRuns=0,$.currentOverLegalBalls=0);let On="DELIVERY_DOT",K="DELIVERY",cn=String(H),un=[];if(I.dismissal){K="DISMISSAL";const Rn=I.dismissal.playerId,bn=i(Rn),hn=p(f,Rn),Um=Rn===I.nonStrikerId,gt=I.dismissal.fielderId?i(I.dismissal.fielderId):null;if(cn=Um?"W (run out NS)":"W",j.push({slot:"dismissedBatter",value:bn,sourceKind:"EVENT_FIELD",sourceRef:"delivery.dismissal.playerId"},{slot:"dismissalKind",value:I.dismissal.kind,sourceKind:"EVENT_FIELD",sourceRef:"delivery.dismissal.kind"},{slot:"dismissedScore",value:`${hn.runs} (${hn.ballsFaced})`,sourceKind:"BATTER_PROJECTION",sourceRef:`batter.${Rn}`}),gt&&j.push({slot:"fielderName",value:gt,sourceKind:"EVENT_FIELD",sourceRef:"delivery.dismissal.fielderId"}),I.dismissal.kind==="RUN_OUT"&&Um){On="WICKET_RUN_OUT_NON_STRIKER";const we=gt?` by ${gt}`:"",sc=I.dismissal.wicketEnd.toLowerCase();un=[{id:"W_RO_NS_1",render:()=>`${R} to ${_}. Non-striker ${bn} is run out${we} at the ${sc} end for ${hn.runs} (${hn.ballsFaced})!`},{id:"W_RO_NS_2",render:()=>`${R} to ${_}. Mix-up in the running — non-striker ${bn} caught short${we} at the ${sc} end, out for ${hn.runs} (${hn.ballsFaced}).`},{id:"W_RO_NS_3",render:()=>`${R} to ${_}. Direct trouble at the ${sc} end: non-striker ${bn} run out${we} for ${hn.runs} (${hn.ballsFaced}).`}]}else if(I.dismissal.kind==="BOWLED")On="WICKET_BOWLED",un=[{id:"W_BWL_1",render:()=>`${R} bowls ${bn} for ${hn.runs} (${hn.ballsFaced})!`},{id:"W_BWL_2",render:()=>`${R} to ${_} — through the defence, ${bn} bowled for ${hn.runs} (${hn.ballsFaced})!`},{id:"W_BWL_3",render:()=>`${R} hits the stumps! ${bn} departs bowled for ${hn.runs} (${hn.ballsFaced}).`}];else if(I.dismissal.kind==="LBW")On="WICKET_LBW",un=[{id:"W_LBW_1",render:()=>`${R} traps ${bn} lbw for ${hn.runs} (${hn.ballsFaced})!`},{id:"W_LBW_2",render:()=>`${R} to ${_} — pinned in front, ${bn} out lbw for ${hn.runs} (${hn.ballsFaced}).`},{id:"W_LBW_3",render:()=>`Up goes the finger! ${R} strikes as ${bn} falls lbw for ${hn.runs} (${hn.ballsFaced}).`}];else if(I.dismissal.kind==="CAUGHT"){On="WICKET_CAUGHT";const we=gt?`caught by ${gt}`:"caught";un=[{id:"W_CT_1",render:()=>`${R} to ${_} — ${bn} ${we} for ${hn.runs} (${hn.ballsFaced})!`},{id:"W_CT_2",render:()=>`Taken! ${R} induces the mistake and ${bn} is ${we} for ${hn.runs} (${hn.ballsFaced}).`},{id:"W_CT_3",render:()=>`Wicket for ${R}: ${bn} departs, ${we}, for ${hn.runs} (${hn.ballsFaced}).`}]}else if(I.dismissal.kind==="STUMPED"){On="WICKET_STUMPED";const we=gt?`stumped by ${gt}`:"stumped";un=[{id:"W_ST_1",render:()=>`${R} deceives ${bn} — ${we} for ${hn.runs} (${hn.ballsFaced})!`},{id:"W_ST_2",render:()=>`Sharp work behind the stumps! ${bn} is ${we} off ${R} for ${hn.runs} (${hn.ballsFaced}).`},{id:"W_ST_3",render:()=>`${R} draws ${bn} out of the crease, ${we} for ${hn.runs} (${hn.ballsFaced}).`}]}else if(I.dismissal.kind==="RUN_OUT"){On="WICKET_RUN_OUT_STRIKER";const we=gt?` (${gt})`:"";un=[{id:"W_RO_S_1",render:()=>`${R} to ${_} — ${bn} run out${we} for ${hn.runs} (${hn.ballsFaced})!`},{id:"W_RO_S_2",render:()=>`Quick throw${we}! ${bn} is run out for ${hn.runs} (${hn.ballsFaced}).`},{id:"W_RO_S_3",render:()=>`Short of the ground! ${bn} departs run out${we} for ${hn.runs} (${hn.ballsFaced}).`}]}else On="WICKET_HIT_WICKET",un=[{id:"W_HW_1",render:()=>`${R} to ${_} — ${bn} is out hit wicket for ${hn.runs} (${hn.ballsFaced})!`},{id:"W_HW_2",render:()=>`Unfortunate dismissal: ${bn} disturbs the stumps, out hit wicket off ${R} for ${hn.runs} (${hn.ballsFaced}).`},{id:"W_HW_3",render:()=>`${bn} falls hit wicket to ${R} for ${hn.runs} (${hn.ballsFaced}).`}]}else if(I.legality==="WIDE")On="DELIVERY_WIDE",cn=`${H}wd`,j.push({slot:"wides",value:String(I.extras.wides),sourceKind:"EVENT_FIELD",sourceRef:"delivery.extras.wides"}),un=[{id:"DLV_WD_1",render:()=>`${R} strays wide to ${_}; ${H} wide${H===1?"":"s"} added, ball to be re-bowled.`},{id:"DLV_WD_2",render:()=>`${R} misses the radar against ${_} — called wide (${H} extra${H===1?"":"s"}).`},{id:"DLV_WD_3",render:()=>`Wide signalled off ${R} to ${_}: ${H} run${H===1?"":"s"} to the total.`}];else if(I.legality==="NO_BALL"){On="DELIVERY_NO_BALL",cn=ke?`${H}nb (FH)`:`${H}nb`,j.push({slot:"noBalls",value:String(I.extras.noBalls),sourceKind:"EVENT_FIELD",sourceRef:"delivery.extras.noBalls"});const Rn=ke?" Free Hit coming up next.":"",bn=I.batRuns>0?` plus ${I.batRuns} off the bat`:M>I.extras.noBalls?` plus ${M-I.extras.noBalls} extra${M-I.extras.noBalls===1?"":"s"}`:"";un=[{id:"DLV_NB_1",render:()=>`No-ball called on ${R} to ${_} (${H} run${H===1?"":"s"}${bn}).${Rn}`},{id:"DLV_NB_2",render:()=>`${R} oversteps against ${_}: no-ball costs ${H} run${H===1?"":"s"}${bn}.${Rn}`},{id:"DLV_NB_3",render:()=>`Front-foot no-ball from ${R} to ${_}, ${H} added${bn}.${Rn}`}]}else if(I.boundary==="SIX"){On="DELIVERY_SIX",cn="6";const Rn=J?` over ${J}`:"";un=[{id:"DLV_SIX_1",render:()=>`${R} to ${_} — launched${Rn} for SIX!`},{id:"DLV_SIX_2",render:()=>`SIX! ${_} clears the rope${Rn} off ${R}.`},{id:"DLV_SIX_3",render:()=>`${_} gets hold of ${R} and sends it sailing${Rn} for 6.`},{id:"DLV_SIX_4",render:()=>`Maximum! Clean strike by ${_}${Rn} off ${R} for six runs.`}]}else if(I.boundary==="FOUR"){On="DELIVERY_FOUR",cn="4";const Rn=J?` through ${J}`:"";un=[{id:"DLV_FOUR_1",render:()=>`${R} to ${_} — crisp stroke${Rn} for FOUR!`},{id:"DLV_FOUR_2",render:()=>`FOUR! ${_} pierces the gap${Rn} off ${R}.`},{id:"DLV_FOUR_3",render:()=>`${_} leans on ${R} and races it away${Rn} to the boundary for 4.`},{id:"DLV_FOUR_4",render:()=>`Boundary for ${_}! Timed neatly${Rn} off ${R}.`}]}else if(H===0){On="DELIVERY_DOT",cn="0";const Rn=I.fieldOutcome==="STOP"?J?`, tidy stop at ${J}`:", tidy stop in the ring":"";un=[{id:"DLV_DOT_1",render:()=>`${R} to ${_}, defended solidly — no run${Rn}.`},{id:"DLV_DOT_2",render:()=>`Dot ball from ${R}; ${_} watchful at the crease${Rn}.`},{id:"DLV_DOT_3",render:()=>`${R} hits the spot to ${_}, no scoring opportunity${Rn}.`},{id:"DLV_DOT_4",render:()=>`${_} plays ${R} back safely — dot ball${Rn}.`}]}else if(I.batRuns===0&&(I.extras.byes>0||I.extras.legByes>0)){On="DELIVERY_BYES_LEGBYES";const Rn=I.extras.legByes>0?"lb":"b",bn=I.extras.legByes>0?"leg-bye":"bye";cn=`${H}${Rn}`,un=[{id:"DLV_BLB_1",render:()=>`${R} to ${_}: ${H} ${bn}${H===1?"":"s"} scampered through.`},{id:"DLV_BLB_2",render:()=>`Past the bat off ${R}; ${_} and ${U} cross for ${H} ${bn}${H===1?"":"s"}.`},{id:"DLV_BLB_3",render:()=>`${H} ${bn}${H===1?"":"s"} signalled as ${R} goes past ${_}.`}]}else if(H===1){On="DELIVERY_SINGLE",cn="1";const Rn=J?` toward ${J}`:"";un=[{id:"DLV_ONE_1",render:()=>`${R} to ${_}, worked${Rn} for a single.`},{id:"DLV_ONE_2",render:()=>`${_} nudges ${R}${Rn} to rotate the strike — 1 run.`},{id:"DLV_ONE_3",render:()=>`Quick single taken by ${_}${Rn} off ${R}.`},{id:"DLV_ONE_4",render:()=>`${_} taps ${R}${Rn} and crosses cleanly for 1.`}]}else{On="DELIVERY_MULTI_RUN",cn=String(H);const Rn=J?` into ${J}`:"";un=[{id:"DLV_MULTI_1",render:()=>`${R} to ${_}, placed${Rn} and they come back for ${H} runs.`},{id:"DLV_MULTI_2",render:()=>`Good running between ${_} and ${U}${Rn} off ${R} — ${H} runs.`},{id:"DLV_MULTI_3",render:()=>`${_} works ${R}${Rn} in the gap for ${H} runs.`}]}W.length>0&&K==="DELIVERY"&&(K="MILESTONE");const mn=io(On,un,t,v.sequence,T,o,e),Ln=!I.dismissal&&I.fieldOutcome==="DROP"?" Dropped chance in the field!":!I.dismissal&&I.fieldOutcome==="MISS"?" Misfield concedes extra ground.":"",Un=Z.length>0?` ${Z.join(" ")}`:"",zi=`Innings ${I.inningsIndex+1}, ${k}: ${mn.selected.render()}${Ln}${Un}`,qt=[];S&&qt.push("free-hit delivery"),pn&&qt.push(`${pn} length`),be&&qt.push(be),J&&qt.push(`sector: ${J}`);const ER=qt.length>0?` [${qt.join(", ")}]`:"",SR=I.dismissal?`Stand ended on ${Q.runs} (${Q.balls}b)`:`Stand ${f.partnershipRuns} (${f.partnershipBalls}b)`,_R=f.targetToWin!==null&&f.runs<f.targetToWin?f.allocatedBalls!==null?` · Need ${f.targetToWin-f.runs} off ${Math.max(0,f.allocatedBalls-f.legalBalls)}b`:` · Need ${f.targetToWin-f.runs} more to win`:"",TR=`${zi}${ER} — Score ${f.runs}/${f.wickets}; ${_} ${y.runs} (${y.ballsFaced}), ${R} ${Qo($)}, ${SR}${_R}.`;b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:K,templateId:mn.selected.id,templateFamily:On,cooldownApplied:mn.cooldownApplied,presentationDigest:mn.digest,milestoneTags:W,short:`${k} · ${cn}`,text:zi,detailed:TR,factSlots:j});continue}if(v.type==="OVER_COMPLETED"){const I=v.payload,f=h(u),S=Math.floor(f.legalBalls/6),k=i(I.bowlerId),R=E(f,I.bowlerId),_=R.currentOverLegalBalls===6&&R.currentOverBowlerRuns===0;_&&(R.maidens+=1);const U=f.overTeamRuns,M=f.overWickets;f.overTeamRuns=0,f.overWickets=0,f.overLegalBalls=0,R.currentOverBowlerRuns=0,R.currentOverLegalBalls=0;const H=_?["MAIDEN_OVER"]:[],an=r(f.battingTeamId),y=Qo(R),L=f.targetToWin!==null&&f.runs<f.targetToWin?f.allocatedBalls!==null?` (${f.targetToWin-f.runs} needed from ${Math.max(0,f.allocatedBalls-f.legalBalls)} balls)`:` (${f.targetToWin-f.runs} needed to win)`:"",$=_?"OVER_MAIDEN":"OVER_SUMMARY",B=io($,_?[{id:"OV_MDN_1",render:()=>`End of over ${S} (maiden from ${k}): ${an} ${f.runs}/${f.wickets}${L}.`},{id:"OV_MDN_2",render:()=>`Maiden over! ${k} closes over ${S} without conceding off the bat or bowling extras — ${an} ${f.runs}/${f.wickets}${L}.`},{id:"OV_MDN_3",render:()=>`Over ${S} complete, a probing maiden by ${k}. ${an} stand at ${f.runs}/${f.wickets}${L}.`}]:[{id:"OV_SUM_1",render:()=>`End of over ${S} (${U} run${U===1?"":"s"}${M>0?`, ${M} wkt${M===1?"":"s"}`:""}): ${an} ${f.runs}/${f.wickets}${L}.`},{id:"OV_SUM_2",render:()=>`Over ${S} complete — ${U} off it${M>0?` and ${M} wicket${M===1?"":"s"}`:""}. ${an} are ${f.runs}/${f.wickets}${L}.`},{id:"OV_SUM_3",render:()=>`After ${S} over${S===1?"":"s"}, ${an} move to ${f.runs}/${f.wickets} (${U} from ${k}'s over)${L}.`}],t,v.sequence,T,o,e),W=B.selected.render();b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"OVER",templateId:B.selected.id,templateFamily:$,cooldownApplied:B.cooldownApplied,presentationDigest:B.digest,milestoneTags:H,short:`Ov ${S}: ${f.runs}/${f.wickets}${_?" (M)":""}`,text:W,detailed:`${W} ${k} figures: ${y}; current stand ${f.partnershipRuns} (${f.partnershipBalls}b).`,factSlots:[{slot:"overNumber",value:String(S),sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.completedOvers"},{slot:"overRuns",value:String(U),sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.overTeamRuns"},{slot:"inningsScore",value:`${f.runs}/${f.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"},{slot:"bowlerFigures",value:y,sourceKind:"BOWLER_PROJECTION",sourceRef:`bowler.${I.bowlerId}`}]});continue}if(v.type==="INNINGS_STARTED"){const I=v.payload;u=I.inningsIndex;const f=h(I.inningsIndex,I.battingTeamId),S=r(f.battingTeamId),k=f.targetToWin!==null?f.allocatedBalls!==null?` chasing ${f.targetToWin} from ${Math.floor(f.allocatedBalls/6)} overs`:` requiring ${f.targetToWin} to win`:"",R=io("INNINGS_STARTED",[{id:"INN_START_1",render:()=>`Start of innings ${I.inningsIndex+1}: ${S} begin batting${k}.`},{id:"INN_START_2",render:()=>`Opening innings ${I.inningsIndex+1} — ${S} take the crease${k}.`}],t,v.sequence,T,o,e),_=R.selected.render(),U=[{slot:"inningsNumber",value:String(I.inningsIndex+1),sourceKind:"EVENT_FIELD",sourceRef:"event.inningsIndex"},{slot:"battingTeam",value:S,sourceKind:"EVENT_FIELD",sourceRef:"event.battingTeamId"}];f.targetToWin!==null&&U.push({slot:"targetToWin",value:String(f.targetToWin),sourceKind:"CHASE_PROJECTION",sourceRef:"innings.targetToWin"}),b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"INNINGS",templateId:R.selected.id,templateFamily:"INNINGS_STARTED",cooldownApplied:R.cooldownApplied,presentationDigest:R.digest,milestoneTags:[],short:`Inn ${I.inningsIndex+1}: ${S}`,text:_,detailed:`${_} Format: ${n.format}.`,factSlots:U});continue}if(v.type==="INNINGS_COMPLETED"){const I=v.payload,f=h(I.inningsIndex),S=r(f.battingTeamId),k=Na(f.legalBalls),R=f.wickets>=10,_=R?`End of innings ${I.inningsIndex+1}: ${S} all out for ${f.runs} in ${k} overs.`:`End of innings ${I.inningsIndex+1}: ${S} close on ${f.runs}/${f.wickets} (${k} overs).`;b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"INNINGS",templateId:R?"INN_END_ALL_OUT":"INN_END_CLOSED",templateFamily:"INNINGS_COMPLETED",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|INN_END`)),milestoneTags:R?["ALL_OUT"]:[],short:`End Inn ${I.inningsIndex+1}: ${f.runs}/${f.wickets}`,text:_,detailed:`${_} Legal deliveries: ${f.legalBalls}.`,factSlots:[{slot:"inningsNumber",value:String(I.inningsIndex+1),sourceKind:"EVENT_FIELD",sourceRef:"event.inningsIndex"},{slot:"inningsTotal",value:`${f.runs}/${f.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"},{slot:"overs",value:k,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.legalBalls"}]});continue}if(v.type==="MATCH_COMPLETED"){const I=v.payload.result;let f="Match complete",S="Match completed.";const k=[];if(I)if(k.push({slot:"resultKind",value:I.kind,sourceKind:"MATCH_RESULT",sourceRef:"result.kind"}),I.kind==="WIN"){const _=r(I.winnerTeamId);k.push({slot:"winnerTeam",value:_,sourceKind:"MATCH_RESULT",sourceRef:"result.winnerTeamId"}),I.marginType==="RUNS"?(f=`${_} won by ${I.marginRuns} runs`,S=`Result: ${_} win by ${I.marginRuns} run${I.marginRuns===1?"":"s"}.`,k.push({slot:"marginRuns",value:String(I.marginRuns),sourceKind:"MATCH_RESULT",sourceRef:"result.marginRuns"})):I.marginType==="WICKETS"?(f=`${_} won by ${I.marginWickets} wkts`,S=`Result: ${_} win by ${I.marginWickets} wicket${I.marginWickets===1?"":"s"}.`,k.push({slot:"marginWickets",value:String(I.marginWickets),sourceKind:"MATCH_RESULT",sourceRef:"result.marginWickets"})):(f=`${_} won by innings & ${I.marginRuns}`,S=`Result: ${_} win by an innings and ${I.marginRuns} run${I.marginRuns===1?"":"s"}.`,k.push({slot:"marginRuns",value:String(I.marginRuns),sourceKind:"MATCH_RESULT",sourceRef:"result.marginRuns"}))}else I.kind==="TIE"?(f="Match tied",S=`Result: Match tied (${I.completionReason}).`):I.kind==="DRAW"?(f="Match drawn",S=`Result: Match drawn (${I.completionReason}).`):(f="No result",S=`Result: No result (${I.completionReason}).`);else k.push({slot:"eventType",value:v.type,sourceKind:"EVENT_FIELD",sourceRef:"event.type"});const R=[...c.values()].sort((_,U)=>_.inningsIndex-U.inningsIndex).map(_=>`${r(_.battingTeamId)} ${_.runs}/${_.wickets}${_.declared?"d":""} (${Na(_.legalBalls)} ov)`).join("; ");b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"RESULT",templateId:`RESULT_${I?.kind??"COMPLETE"}`,templateFamily:"MATCH_COMPLETED",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|RESULT`)),milestoneTags:[],short:f,text:S,detailed:R?`${S} Final scores: ${R}.`:S,factSlots:k});continue}if(v.type==="TOSS_RESOLVED"){const I=v.payload,f=r(I.winnerId),S=I.coin.toLowerCase(),k=`Toss: ${S}. ${f} won the toss.`;b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"SELECTION",templateId:"TOSS_RESOLVED_1",templateFamily:"TOSS_RESOLVED",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|TOSS`)),milestoneTags:[],short:`Toss: ${f} (${S})`,text:k,detailed:I.callerId&&I.call?`${k} (${r(I.callerId)} called ${I.call.toLowerCase()}).`:k,factSlots:[{slot:"coin",value:S,sourceKind:"EVENT_FIELD",sourceRef:"event.coin"},{slot:"winnerTeam",value:f,sourceKind:"EVENT_FIELD",sourceRef:"event.winnerId"}]});continue}if(v.type==="BATTER_SELECTED"){const I=v.payload.playerId,f=i(I),S=h(u),k=io("BATTER_SELECTED",[{id:"BAT_SEL_1",render:()=>`${f} comes in to bat.`},{id:"BAT_SEL_2",render:()=>`${f} walks to the crease.`}],t,v.sequence,T,o,e),R=k.selected.render();b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"SELECTION",templateId:k.selected.id,templateFamily:"BATTER_SELECTED",cooldownApplied:k.cooldownApplied,presentationDigest:k.digest,milestoneTags:[],short:`In: ${f}`,text:R,detailed:`${R} (${r(S.battingTeamId)} ${S.runs}/${S.wickets}).`,factSlots:[{slot:"batterName",value:f,sourceKind:"EVENT_FIELD",sourceRef:"event.playerId"}]});continue}if(v.type==="BOWLER_SELECTED"){const I=v.payload.playerId,f=i(I),S=h(u),k=Qo(E(S,I)),R=io("BOWLER_SELECTED",[{id:"BWL_SEL_1",render:()=>`${f} will bowl.`},{id:"BWL_SEL_2",render:()=>`${f} comes into the attack.`}],t,v.sequence,T,o,e),_=R.selected.render();b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"SELECTION",templateId:R.selected.id,templateFamily:"BOWLER_SELECTED",cooldownApplied:R.cooldownApplied,presentationDigest:R.digest,milestoneTags:[],short:`Bowl: ${f}`,text:_,detailed:`${_} Current figures: ${k}.`,factSlots:[{slot:"bowlerName",value:f,sourceKind:"EVENT_FIELD",sourceRef:"event.playerId"},{slot:"bowlerFigures",value:k,sourceKind:"BOWLER_PROJECTION",sourceRef:`bowler.${I}`}]});continue}if(v.type==="RAIN_DELAY"){const I=v.payload.seconds,f=Math.round(I/60),S=`Weather delay: ${f} minute${f===1?"":"s"} lost to rain.`;b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"CONDITIONS",templateId:"RAIN_DELAY_1",templateFamily:"RAIN_DELAY",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|RAIN`)),milestoneTags:[],short:`Rain (${f}m)`,text:S,detailed:`${S} (${I} seconds deducted from playing time).`,factSlots:[{slot:"lostMinutes",value:`${f} minute${f===1?"":"s"}`,sourceKind:"EVENT_FIELD",sourceRef:"event.seconds"}]});continue}if(v.type==="DECLARED"){const I=v.payload.teamId,f=r(I),S=h(u);S.declared=!0;const k=`${f} declared the innings at ${S.runs}/${S.wickets}.`;b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"TACTICAL",templateId:"DECLARED_1",templateFamily:"DECLARED",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|DECL`)),milestoneTags:[],short:`Declared (${S.runs}/${S.wickets}d)`,text:k,detailed:`${k} (${Na(S.legalBalls)} overs bowled).`,factSlots:[{slot:"declaringTeam",value:f,sourceKind:"EVENT_FIELD",sourceRef:"event.teamId"},{slot:"declaredTotal",value:`${S.runs}/${S.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"}]});continue}if(v.type==="FOLLOW_ON_CHOSEN"){const I=!!v.payload.enforce,f=I?"Follow-on enforced.":"Follow-on declined.";b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"TACTICAL",templateId:I?"FOLLOW_ON_ENFORCED":"FOLLOW_ON_DECLINED",templateFamily:"FOLLOW_ON_CHOSEN",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|FO`)),milestoneTags:[],short:f,text:f,detailed:I?`${f} The trailing side will bat again immediately.`:`${f} The leading side elects to bat again.`,factSlots:[{slot:"followOnEnforced",value:String(I),sourceKind:"EVENT_FIELD",sourceRef:"event.enforce"}]});continue}if(v.type==="NEW_BALL_TAKEN"){const I=h(u),f="New ball taken.";b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"TACTICAL",templateId:"NEW_BALL_TAKEN_1",templateFamily:"NEW_BALL_TAKEN",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|NB`)),milestoneTags:[],short:"New ball",text:f,detailed:`${f} Taken after ${Na(I.legalBalls)} overs with the score at ${I.runs}/${I.wickets}.`,factSlots:[{slot:"oversAtNewBall",value:Na(I.legalBalls),sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.legalBalls"}]});continue}if(v.type==="BATTING_PLAN_CHANGED"){const I=v.payload,f=i(I.playerId),S=`Batting plan updated for ${f}: aggression ${I.aggression}, ${I.intent.toLowerCase()} intent.`;b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"TACTICAL",templateId:"BAT_PLAN_1",templateFamily:"BATTING_PLAN_CHANGED",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|BATP`)),milestoneTags:[],short:`Bat plan: ${f}`,text:S,detailed:S,factSlots:[{slot:"batterName",value:f,sourceKind:"EVENT_FIELD",sourceRef:"event.playerId"},{slot:"aggression",value:String(I.aggression),sourceKind:"EVENT_FIELD",sourceRef:"event.aggression"}]});continue}if(v.type==="BOWLING_PLAN_CHANGED"){const I=v.payload,f=i(I.bowlerId),S=`Bowling plan for ${f}: ${I.line.toLowerCase()} line, ${I.length.toLowerCase().replaceAll("_"," ")} length (${I.effort.toLowerCase()} effort).`;b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"TACTICAL",templateId:"BWL_PLAN_1",templateFamily:"BOWLING_PLAN_CHANGED",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|BWLP`)),milestoneTags:[],short:`Bowl plan: ${f}`,text:S,detailed:S,factSlots:[{slot:"bowlerName",value:f,sourceKind:"EVENT_FIELD",sourceRef:"event.bowlerId"},{slot:"line",value:I.line.toLowerCase(),sourceKind:"EVENT_FIELD",sourceRef:"event.line"},{slot:"length",value:I.length.toLowerCase(),sourceKind:"EVENT_FIELD",sourceRef:"event.length"}]});continue}if(v.type==="FIELD_CHANGED"){const I=v.payload.fieldSlots,f="Field placement adjusted.",S=I.slice(0,4).map(k=>k.slotId.toLowerCase().replaceAll("_"," ")).join(", ");b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"TACTICAL",templateId:"FIELD_CHANGED_1",templateFamily:"FIELD_CHANGED",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|FLD`)),milestoneTags:[],short:"Field adjusted",text:f,detailed:S?`${f} Key ring/slip posts include ${S}.`:f,factSlots:[{slot:"slotCount",value:String(I.length),sourceKind:"EVENT_FIELD",sourceRef:"event.fieldSlots"}]});continue}if(v.type==="TEAMS_CONFIRMED"){const I=r(n.teamIds[0]),f=r(n.teamIds[1]),S=`Teams confirmed: ${I} vs ${f}.`;b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"SELECTION",templateId:"TEAMS_CONFIRMED_1",templateFamily:"TEAMS_CONFIRMED",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|TC`)),milestoneTags:[],short:`${I} v ${f}`,text:S,detailed:n.groundName?`${S} Venue: ${n.groundName} (${n.format}).`:`${S} Format: ${n.format}.`,factSlots:[{slot:"homeTeam",value:I,sourceKind:"INNINGS_PROJECTION",sourceRef:"match.teamIds[0]"},{slot:"awayTeam",value:f,sourceKind:"INNINGS_PROJECTION",sourceRef:"match.teamIds[1]"}]});continue}const A=v.type.replaceAll("_"," ").toLowerCase();b.push({adapterVersion:ee,sequence:v.sequence,eventType:v.type,category:"SELECTION",templateId:"EVENT_GENERIC_FALLBACK",templateFamily:"EVENT_GENERIC",cooldownApplied:!1,presentationDigest:ye(Ne(`${t}|${v.sequence}|${T}|GEN`)),milestoneTags:[],short:A,text:A,detailed:A,factSlots:[{slot:"eventType",value:v.type,sourceKind:"EVENT_FIELD",sourceRef:"event.type"}]})}return{adapterVersion:ee,format:n.format,presentationKeyDigest:a,repetitionCooldownWindow:e,entries:b}}const cS=4500,lS=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]);function st(n,e){return n>>>e|n<<32-e}function dS(n){const e=new TextEncoder().encode(n),t=e.length*8,a=Math.ceil((e.length+9)/64)*64,o=new Uint8Array(a);o.set(e),o[e.length]=128;const i=new DataView(o.buffer);i.setUint32(a-8,Math.floor(t/4294967296),!1),i.setUint32(a-4,t>>>0,!1);const r=new Uint32Array([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),s=new Uint32Array(64);for(let c=0;c<a;c+=64){for(let A=0;A<16;A+=1)s[A]=i.getUint32(c+A*4,!1);for(let A=16;A<64;A+=1){const I=st(s[A-15],7)^st(s[A-15],18)^s[A-15]>>>3,f=st(s[A-2],17)^st(s[A-2],19)^s[A-2]>>>10;s[A]=s[A-16]+I+s[A-7]+f>>>0}let u=r[0],h=r[1],p=r[2],E=r[3],b=r[4],w=r[5],v=r[6],T=r[7];for(let A=0;A<64;A+=1){const I=st(b,6)^st(b,11)^st(b,25),f=b&w^~b&v,S=T+I+f+lS[A]+s[A]>>>0,k=st(u,2)^st(u,13)^st(u,22),R=u&h^u&p^h&p,_=k+R>>>0;T=v,v=w,w=b,b=E+S>>>0,E=p,p=h,h=u,u=S+_>>>0}r[0]=r[0]+u>>>0,r[1]=r[1]+h>>>0,r[2]=r[2]+p>>>0,r[3]=r[3]+E>>>0,r[4]=r[4]+b>>>0,r[5]=r[5]+w>>>0,r[6]=r[6]+v>>>0,r[7]=r[7]+T>>>0}return Array.from(r).map(c=>c.toString(16).padStart(8,"0")).join("")}const uS=[{assetId:"lc-sfx-bat-dot-v1",cueKind:"BAT_BALL_DOT",channel:"EFFECTS",title:"Willow tap — defensive dot",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"triangle-210Hz->120Hz-bandpass-65ms",durationMs:75},{assetId:"lc-sfx-bat-single-v1",cueKind:"BAT_BALL_SINGLE",channel:"EFFECTS",title:"Crisp bat knock — rotated single/runs",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"triangle-340Hz->165Hz-click-95ms",durationMs:105},{assetId:"lc-crowd-boundary-four-v1",cueKind:"BOUNDARY_FOUR",channel:"CROWD",title:"Sweet-spot drive + boundary applause swell",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"harmonic-knock-440Hz+bandpass-applause-680ms",durationMs:720},{assetId:"lc-crowd-boundary-six-v1",cueKind:"BOUNDARY_SIX",channel:"CROWD",title:"Lofted strike + full stadium roar",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"harmonic-strike-520Hz+warm-crowd-swell-960ms",durationMs:980},{assetId:"lc-sfx-wicket-fall-v1",cueKind:"WICKET_FALL",channel:"EFFECTS",title:"Timber rattle + crowd gasp",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"dual-stump-resonance-610Hz-390Hz+crowd-hush-820ms",durationMs:840},{assetId:"lc-sfx-milestone-chime-v1",cueKind:"MILESTONE_CHIME",channel:"CROWD",title:"Milestone applause & fifth-chord chime",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"sine-triad-523Hz-659Hz-784Hz+soft-applause-640ms",durationMs:680},{assetId:"lc-sfx-over-bell-v1",cueKind:"OVER_BELL",channel:"EFFECTS",title:"End-of-over brass chime",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"sine-bell-660Hz-880Hz-240ms",durationMs:260},{assetId:"lc-sfx-innings-change-v1",cueKind:"INNINGS_CHANGE",channel:"CROWD",title:"Innings interval pavilion chime",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"warm-chord-392Hz-494Hz-587Hz-540ms",durationMs:560},{assetId:"lc-crowd-match-complete-v1",cueKind:"MATCH_COMPLETE",channel:"CROWD",title:"Full-time pavilion fanfare & crowd ovation",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"major-fanfare-523Hz-659Hz-784Hz-1046Hz+ovation-1100ms",durationMs:1150},{assetId:"lc-ui-click-v1",cueKind:"UI_CLICK",channel:"INTERFACE",title:"Subtle tactile slate click",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"sine-tick-740Hz->420Hz-35ms",durationMs:40}].map(n=>({...n,sha256:dS(JSON.stringify({assetId:n.assetId,cueKind:n.cueKind,channel:n.channel,license:n.license,origin:n.origin,synthesisProfile:n.synthesisProfile,durationMs:n.durationMs}))})),mS={manifestVersion:fd,attributionNotice:"All audio cues are synthesized offline in-repo from original mathematical waveforms and noise envelopes owned by Lord Cricket XXVI (MIT). No third-party commercial sound recordings, voices, or network audio streams are used.",networkCallsAllowed:!1,assets:[...uS]};function gS(n,e=mS){return e.assets.find(t=>t.cueKind===n)??null}function ts(n,e){return n.factSlots.find(t=>t.slot===e)?.value}function IS(n){if(n.category==="RESULT")return{cueKind:"MATCH_COMPLETE",channel:"CROWD",priority:95,caption:`Match complete: ${n.short}`,narrationText:n.text};if(n.category==="INNINGS")return{cueKind:"INNINGS_CHANGE",channel:"CROWD",priority:75,caption:`Innings update: ${n.short}`,narrationText:n.text};if(n.category==="DISMISSAL")return{cueKind:"WICKET_FALL",channel:"EFFECTS",priority:92,caption:`Wicket! ${n.short}`,narrationText:n.text};if(n.milestoneTags.some(e=>["BATTER_FIFTY","BATTER_CENTURY","BATTER_150","BATTER_DOUBLE_CENTURY","PARTNERSHIP_FIFTY","PARTNERSHIP_CENTURY","PARTNERSHIP_150","BOWLER_THREE_FOR","BOWLER_FIVE_FOR"].includes(e))){const e=ts(n,"boundary"),t=n.milestoneTags.join(", ").replace(/_/g," ").toLowerCase();return{cueKind:"MILESTONE_CHIME",channel:"CROWD",priority:e==="6"?88:82,caption:`Milestone (${t}): ${n.short}`,narrationText:n.text}}if(n.category==="OVER")return{cueKind:"OVER_BELL",channel:"EFFECTS",priority:55,caption:`Over complete: ${n.short}`,narrationText:n.short};if(n.category==="DELIVERY"){const e=ts(n,"boundary"),t=Number(ts(n,"runs")??"0");return e==="6"?{cueKind:"BOUNDARY_SIX",channel:"CROWD",priority:86,caption:`SIX! ${n.short}`,narrationText:n.text}:e==="4"?{cueKind:"BOUNDARY_FOUR",channel:"CROWD",priority:80,caption:`FOUR! ${n.short}`,narrationText:n.text}:t>0?{cueKind:"BAT_BALL_SINGLE",channel:"EFFECTS",priority:35,caption:n.short}:{cueKind:"BAT_BALL_DOT",channel:"EFFECTS",priority:20,caption:n.short}}return null}function as(n){const e=n.maxCues??48,t=[...n.commentaryEntries].sort((i,r)=>i.sequence-r.sequence),a=e>0?t.slice(-e):t,o=[];for(const i of a){const r=IS(i);if(!r)continue;const s=gS(r.cueKind);s&&o.push({cueId:`${n.matchId}:${i.sequence}:${r.cueKind}`,sequence:i.sequence,channel:r.channel,cueKind:r.cueKind,assetId:s.assetId,priority:r.priority,caption:r.caption.slice(0,280),...r.narrationText?{narrationText:r.narrationText.slice(0,360)}:{},ttlMs:cS})}return{adapterVersion:Hr,matchId:n.matchId,format:n.format,cues:o}}const Kd="Transparent Game Award: batting (runs, boundaries, milestones, not-out, format-par strike rate) + bowling (24 pts/wkt, 3w/5w hauls, maidens, format-par economy) + attributable fielding (catches 7, stumpings 9, run-outs 11) + modest winning-team bonus (5 pts; standout losing performances can still win).",pS={T20:13e3,ODI:9200,RED_BALL:5500},hS={T20:750,ODI:520,RED_BALL:320},fS={T20:12,ODI:24,RED_BALL:30};function qd(n,e,t){return Math.max(e,Math.min(t,Math.round(n)))}function ES(n,e){if(!n)return{byPlayer:new Map,evaluated:!1};const t=new Map;for(const a of n){if(a.type!=="DELIVERY_RECORDED")continue;const i=a.payload?.event,r=i?.dismissal;if(!r||!r.fielderId)continue;const s=r.fielderId,c=e[s]??i?.bowlingTeamId??"unknown",u=t.get(s)??{teamId:c,catches:0,stumpings:0,runOuts:0};r.kind==="CAUGHT"?u.catches+=1:r.kind==="STUMPED"?u.stumpings+=1:r.kind==="RUN_OUT"&&(u.runOuts+=1),t.set(s,u)}return{byPlayer:t,evaluated:!0}}function SS(n){return{byPlayer:new Map(n.map(e=>[e.playerId,{teamId:e.teamId,catches:e.catches,stumpings:e.stumpings,runOuts:e.runOuts}])),evaluated:!0}}function _S(n,e){if(!n.batted)return 0;let t=n.runs*100;if(n.runs>=150?t+=5e3:n.runs>=100?t+=3500:n.runs>=50?t+=1500:n.runs>=30&&(t+=500),n.notOutWithRuns&&n.runs>=20&&(t+=400),t+=n.sixes*150+n.fours*50,n.ballsFaced>=10&&n.runs>=15){const a=Math.round(n.runs*1e4/n.ballsFaced),o=pS[e];t+=qd((a-o)*Math.min(40,n.ballsFaced)/250,-600,1400)}return t}function TS(n,e){if(!n.bowled)return 0;let t=n.wickets*2400;if(n.wickets>=5?t+=3e3:n.wickets>=3&&(t+=1200),t+=n.maidens*500,n.legalBalls>=fS[e]){const a=Math.round(n.runsConceded*600/n.legalBalls),o=hS[e],i=n.legalBalls/6;t+=qd((o-a)*Math.min(8,i)/4,-900,1600)}return t}function RS(n){return n.catches*700+n.stumpings*900+n.runOuts*1100}function vS(n){const e=[];if(n.batted&&e.push(`${n.runs}${n.notOutWithRuns?"*":""} (${n.ballsFaced})`),n.bowled&&e.push(`${n.wickets}/${n.runsConceded} (${Math.floor(n.legalBalls/6)}.${n.legalBalls%6})`),n.catches+n.stumpings+n.runOuts>0){const a=[];n.catches>0&&a.push(`${n.catches}c`),n.stumpings>0&&a.push(`${n.stumpings}st`),n.runOuts>0&&a.push(`${n.runOuts}ro`),e.push(a.join(" "))}return e.length>0?e.join(" · "):"Selected XI"}function AS(n){const{format:e,scorecard:t}=n,a=n.fixtureId??null,o=n.seasonNumber??null,i=n.sourceCompletionSha256??null,r=n.events??n.archive?.events,s={...n.participantTeamByPlayerId??{}},c=new Map,u=(R,_)=>{let U=c.get(R);return U||(U={playerId:R,teamId:_,runs:0,ballsFaced:0,fours:0,sixes:0,batted:!1,notOutWithRuns:!1,wickets:0,runsConceded:0,legalBalls:0,maidens:0,bowled:!1,catches:0,stumpings:0,runOuts:0},c.set(R,U)),s[R]=U.teamId,U};for(const R of t.innings){for(const[_,U]of Object.entries(R.batting)){const M=u(_,R.battingTeamId);(U.ballsFaced>0||U.dismissed||U.runs>0)&&(M.batted=!0,M.runs+=U.runs,M.ballsFaced+=U.ballsFaced,M.fours+=U.fours,M.sixes+=U.sixes,!U.dismissed&&U.runs>0&&(M.notOutWithRuns=!0))}for(const[_,U]of Object.entries(R.bowling)){const M=u(_,R.bowlingTeamId);(U.legalBalls>0||U.runsConceded>0||U.wickets>0)&&(M.bowled=!0,M.wickets+=U.wickets,M.runsConceded+=U.runsConceded,M.legalBalls+=U.legalBalls,M.maidens+=U.maidens)}}const h=!r&&n.fieldingDigest?SS(n.fieldingDigest):ES(r,s);for(const[R,_]of h.byPlayer.entries()){const U=u(R,_.teamId);U.catches+=_.catches,U.stumpings+=_.stumpings,U.runOuts+=_.runOuts}const p=h.evaluated?"ARCHIVE_EVENTS":"SCORECARD_NOT_ATTRIBUTABLE";if(t.result.kind==="NO_RESULT"||c.size===0)return{record:Fr.parse({awardVersion:ao,awardCategory:"PLAYER_OF_THE_MATCH",awardProvenance:"GAME_AWARD",format:e,matchId:t.matchId,fixtureId:a,seasonNumber:o,sourceCompletionSha256:i,status:"NO_RESULT_NOT_AWARDED",winnerPlayerId:null,winnerTeamId:null,fromWinningTeam:null,fromLosingTeam:!1,scoreTotalX100:null,components:null,fieldingSourceStatus:p,explanationText:"No Player of the Match awarded because the fixture finished as a no-result without a completed competitive outcome.",formulaSummary:Kd,candidates:[]}),allCandidates:[]};const E=t.result.kind==="WIN"?t.result.winnerTeamId:null,b=t.result.kind==="WIN"&&E!==null,w=[...c.values()].map(R=>{const _=_S(R,e),U=TS(R,e),M=RS(R),H=E!==null&&R.teamId===E,an=H?500:0,y=_+U+M+an;return{playerId:R.playerId,teamId:R.teamId,battingPointsX100:_,bowlingPointsX100:U,fieldingPointsX100:M,resultBonusX100:an,totalPointsX100:y,fromWinningTeam:H,summaryLine:vS(R)}}).sort((R,_)=>{if(_.totalPointsX100!==R.totalPointsX100)return _.totalPointsX100-R.totalPointsX100;const U=R.battingPointsX100+R.bowlingPointsX100+R.fieldingPointsX100,M=_.battingPointsX100+_.bowlingPointsX100+_.fieldingPointsX100;return M!==U?M-U:R.fromWinningTeam!==_.fromWinningTeam?R.fromWinningTeam?-1:1:cl(R.playerId,_.playerId)}),v=w[0],T=b&&v.teamId!==E,A=n.playerNames?.[v.playerId]??v.playerId,I=n.teamNames?.[v.teamId]??v.teamId,f=T?" (standout performance from the losing side)":"",S=p==="SCORECARD_NOT_ATTRIBUTABLE"?" Attributable fielding points unavailable because delivery event archive was not attached.":"";return{record:Fr.parse({awardVersion:ao,awardCategory:"PLAYER_OF_THE_MATCH",awardProvenance:"GAME_AWARD",format:e,matchId:t.matchId,fixtureId:a,seasonNumber:o,sourceCompletionSha256:i,status:"AWARDED",winnerPlayerId:v.playerId,winnerTeamId:v.teamId,fromWinningTeam:b?v.fromWinningTeam:null,fromLosingTeam:T,scoreTotalX100:v.totalPointsX100,components:{battingPointsX100:v.battingPointsX100,bowlingPointsX100:v.bowlingPointsX100,fieldingPointsX100:v.fieldingPointsX100,resultBonusX100:v.resultBonusX100},fieldingSourceStatus:p,explanationText:`${A} (${I}${f}) awarded Player of the Match with ${(v.totalPointsX100/100).toFixed(2)} pts — ${v.summaryLine}.${S}`,formulaSummary:Kd,candidates:w.slice(0,5)}),allCandidates:w}}function os(n){return AS(n).record}function Zd(){return{schemaId:Rd,records:[],attempts:[]}}function bS(n,e){const t=e.kind==="WIN"&&e.winnerTeamId===n.playerTeamId,a=e.kind==="WIN"&&e.winnerTeamId!==n.playerTeamId,o=n.objective==="WIN"?t:!a&&e.kind!=="NO_RESULT",i=t?e.marginType==="WICKETS"?e.marginWickets:e.marginRuns:null,r=t&&i!==null&&i>0?e.marginType:null,s=r==="WICKETS"?` by ${i} wicket${i===1?"":"s"}`:r==="RUNS"?` by ${i} run${i===1?"":"s"}`:r==="INNINGS"?` by an innings and ${i} run${i===1?"":"s"}`:"",c=t?`Won${s}`:a?"Lost":e.kind==="TIE"?"Tied":e.kind==="DRAW"?"Drawn":"No result";return{outcome:o?"COMPLETED":"FAILED",marginType:r,marginValue:r?i:null,text:`${c}. Challenge ${o?"completed":"failed"}.`}}function Xd(n,e){return`${n}:${e}`}function wS(n){return n.sort((e,t)=>Xd(e.scenarioId,e.challengeSha256)<Xd(t.scenarioId,t.challengeSha256)?-1:1)}function OS(n,e){const t=La.parse(n);if(t.attempts.some(r=>r.gameId===e.gameId))return t;const a=t.records.map(r=>({...r})),o=a.find(r=>r.scenarioId===e.scenarioId&&r.challengeSha256===e.challengeSha256);o?o.attempts+=1:a.push({scenarioId:e.scenarioId,challengeSha256:e.challengeSha256,attempts:1,completions:0,failures:0,bestMarginType:null,bestMarginValue:null,lastOutcome:null});const i=[...t.attempts,{gameId:e.gameId,scenarioId:e.scenarioId,challengeSha256:e.challengeSha256,playerTeamId:e.playerTeamId,objective:e.objective,outcome:null,resultText:null}].slice(-64);return La.parse({...t,records:wS(a),attempts:i})}function LS(n,e,t){const a=La.parse(n),o=a.attempts.find(c=>c.gameId===e);if(!o||o.outcome!==null)return a;const i=a.records.map(c=>({...c})),r=i.find(c=>c.scenarioId===o.scenarioId&&c.challengeSha256===o.challengeSha256);r&&(r.lastOutcome=t.outcome,t.outcome==="COMPLETED"?(r.completions+=1,t.marginType&&t.marginValue!==null&&(r.bestMarginValue===null||r.bestMarginType!==t.marginType||t.marginValue>r.bestMarginValue)&&(r.bestMarginType===null||r.bestMarginType===t.marginType)&&(r.bestMarginType=t.marginType,r.bestMarginValue=t.marginValue)):r.failures+=1);const s=a.attempts.map(c=>c.gameId===e?{...c,outcome:t.outcome,resultText:t.text}:c);return La.parse({...a,records:i,attempts:s})}function Jd(n,e){return n.attempts.find(t=>t.gameId===e)??null}/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */function NS(n){return n instanceof Uint8Array||ArrayBuffer.isView(n)&&n.constructor.name==="Uint8Array"}function ni(n,...e){if(!NS(n))throw new Error("Uint8Array expected");if(e.length>0&&!e.includes(n.length))throw new Error("Uint8Array expected of length "+e+", got length="+n.length)}function Qd(n,e=!0){if(n.destroyed)throw new Error("Hash instance has been destroyed");if(e&&n.finished)throw new Error("Hash#digest() has already been called")}function yS(n,e){ni(n);const t=e.outputLen;if(n.length<t)throw new Error("digestInto() expects output buffer of length at least "+t)}function is(...n){for(let e=0;e<n.length;e++)n[e].fill(0)}function rs(n){return new DataView(n.buffer,n.byteOffset,n.byteLength)}function ct(n,e){return n<<32-e|n>>>e}const DS=typeof Uint8Array.from([]).toHex=="function"&&typeof Uint8Array.fromHex=="function",CS=Array.from({length:256},(n,e)=>e.toString(16).padStart(2,"0"));function kS(n){if(ni(n),DS)return n.toHex();let e="";for(let t=0;t<n.length;t++)e+=CS[n[t]];return e}function ss(n){if(typeof n!="string")throw new Error("string expected");return new Uint8Array(new TextEncoder().encode(n))}function nu(n){return typeof n=="string"&&(n=ss(n)),ni(n),n}class BS{}function PS(n){const e=a=>n().update(nu(a)).digest(),t=n();return e.outputLen=t.outputLen,e.blockLen=t.blockLen,e.create=()=>n(),e}function xS(n,e,t,a){if(typeof n.setBigUint64=="function")return n.setBigUint64(e,t,a);const o=BigInt(32),i=BigInt(4294967295),r=Number(t>>o&i),s=Number(t&i),c=a?4:0,u=a?0:4;n.setUint32(e+c,r,a),n.setUint32(e+u,s,a)}function HS(n,e,t){return n&e^~n&t}function FS(n,e,t){return n&e^n&t^e&t}class MS extends BS{constructor(e,t,a,o){super(),this.finished=!1,this.length=0,this.pos=0,this.destroyed=!1,this.blockLen=e,this.outputLen=t,this.padOffset=a,this.isLE=o,this.buffer=new Uint8Array(e),this.view=rs(this.buffer)}update(e){Qd(this),e=nu(e),ni(e);const{view:t,buffer:a,blockLen:o}=this,i=e.length;for(let r=0;r<i;){const s=Math.min(o-this.pos,i-r);if(s===o){const c=rs(e);for(;o<=i-r;r+=o)this.process(c,r);continue}a.set(e.subarray(r,r+s),this.pos),this.pos+=s,r+=s,this.pos===o&&(this.process(t,0),this.pos=0)}return this.length+=e.length,this.roundClean(),this}digestInto(e){Qd(this),yS(e,this),this.finished=!0;const{buffer:t,view:a,blockLen:o,isLE:i}=this;let{pos:r}=this;t[r++]=128,is(this.buffer.subarray(r)),this.padOffset>o-r&&(this.process(a,0),r=0);for(let p=r;p<o;p++)t[p]=0;xS(a,o-8,BigInt(this.length*8),i),this.process(a,0);const s=rs(e),c=this.outputLen;if(c%4)throw new Error("_sha2: outputLen should be aligned to 32bit");const u=c/4,h=this.get();if(u>h.length)throw new Error("_sha2: outputLen bigger than state");for(let p=0;p<u;p++)s.setUint32(4*p,h[p],i)}digest(){const{buffer:e,outputLen:t}=this;this.digestInto(e);const a=e.slice(0,t);return this.destroy(),a}_cloneInto(e){e||(e=new this.constructor),e.set(...this.get());const{blockLen:t,buffer:a,length:o,finished:i,destroyed:r,pos:s}=this;return e.destroyed=r,e.finished=i,e.length=o,e.pos=s,o%t&&e.buffer.set(a),e}clone(){return this._cloneInto()}}const Ot=Uint32Array.from([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),VS=Uint32Array.from([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),Lt=new Uint32Array(64);class WS extends MS{constructor(e=32){super(64,e,8,!1),this.A=Ot[0]|0,this.B=Ot[1]|0,this.C=Ot[2]|0,this.D=Ot[3]|0,this.E=Ot[4]|0,this.F=Ot[5]|0,this.G=Ot[6]|0,this.H=Ot[7]|0}get(){const{A:e,B:t,C:a,D:o,E:i,F:r,G:s,H:c}=this;return[e,t,a,o,i,r,s,c]}set(e,t,a,o,i,r,s,c){this.A=e|0,this.B=t|0,this.C=a|0,this.D=o|0,this.E=i|0,this.F=r|0,this.G=s|0,this.H=c|0}process(e,t){for(let p=0;p<16;p++,t+=4)Lt[p]=e.getUint32(t,!1);for(let p=16;p<64;p++){const E=Lt[p-15],b=Lt[p-2],w=ct(E,7)^ct(E,18)^E>>>3,v=ct(b,17)^ct(b,19)^b>>>10;Lt[p]=v+Lt[p-7]+w+Lt[p-16]|0}let{A:a,B:o,C:i,D:r,E:s,F:c,G:u,H:h}=this;for(let p=0;p<64;p++){const E=ct(s,6)^ct(s,11)^ct(s,25),b=h+E+HS(s,c,u)+VS[p]+Lt[p]|0,v=(ct(a,2)^ct(a,13)^ct(a,22))+FS(a,o,i)|0;h=u,u=c,c=s,s=r+b|0,r=i,i=o,o=a,a=b+v|0}a=a+this.A|0,o=o+this.B|0,i=i+this.C|0,r=r+this.D|0,s=s+this.E|0,c=c+this.F|0,u=u+this.G|0,h=h+this.H|0,this.set(a,o,i,r,s,c,u,h)}roundClean(){is(Lt)}destroy(){this.set(0,0,0,0,0,0,0,0),is(this.buffer)}}const eu=PS(()=>new WS);function te(n){return kS(eu(n))}function ce(n){return ss(G(n))}function US(n){return G(n),ss(wh(n))}function Nt(n=jn){if(n!==jn)throw new Error("UNSUPPORTED_RANDOM_VERSION: "+String(n));return Object.freeze({version:jn,uint32(e){const t=eu(US(e));return new DataView(t.buffer,t.byteOffset,t.byteLength).getUint32(0,!1)}})}function qn(n=Uo){if(n!==Uo)throw new Error("UNSUPPORTED_STATE_HASH_VERSION: "+String(n));return Object.freeze({version:Uo,hash(e){return te(ce(e))}})}const cs={schemaVersion:"1.0.0",referenceEdition:"MCC_2017_FOURTH_EDITION_2026",effectiveDate:"2026-10-01",customProfile:!0,ballsPerOver:6,playersPerXI:11,wicketsToAllOut:10,consecutiveOvers:!1,maxLegSide:5,maxBehindSquareLegSide:2,limitedOversRain:!1,superOver:!1,supportedClauses:[],validationStatus:"CONTRACT_ONLY"},yt=[{...cs,rulesId:"LC_T20_01",format:"T20",inningsPerTeam:1,allocatedBalls:120,bowlerMaxBalls:24,freeHitAfterNoBall:!0,declarations:!1,followOnLead:null,newBallAfterLegalBalls:null,fieldPhases:[{fromLegalBall:0,maxOutside:2},{fromLegalBall:36,maxOutside:5}],localVariations:["No super over; ties share points"],fixtureIds:["F01","F02","F03","F04","F05","F06","F07","F08","F09"]},{...cs,rulesId:"LC_ODI_01",format:"ODI",inningsPerTeam:1,allocatedBalls:300,bowlerMaxBalls:60,freeHitAfterNoBall:!0,declarations:!1,followOnLead:null,newBallAfterLegalBalls:null,fieldPhases:[{fromLegalBall:0,maxOutside:2},{fromLegalBall:60,maxOutside:4},{fromLegalBall:240,maxOutside:5}],localVariations:["One ball per innings"],fixtureIds:["F01","F02","F07","F08","F09"]},{...cs,rulesId:"LC_RED5_01",format:"RED_BALL",inningsPerTeam:2,allocatedBalls:null,bowlerMaxBalls:null,freeHitAfterNoBall:!1,declarations:!0,followOnLead:200,newBallAfterLegalBalls:480,fieldPhases:[],localVariations:["Custom five-day clock; over completed at stumps despite wicket","No limited-overs rain provider"],fixtureIds:["F10","F11","F12"]}].map(n=>hh.parse(n)),$S={DRY:{DRY:85,OVERCAST:12,RAIN:3},OVERCAST:{DRY:30,OVERCAST:60,RAIN:10},RAIN:{DRY:20,OVERCAST:40,RAIN:40}},ro=1800,ya=ll.parse({registryId:"LC_FIELD_CONTRACT_01",referenceHand:"R",positions:[{slotId:"slip-1",sector:7,angleDegrees:315,depth:"INNER",insideCircle:!0,legSide:!1,behindSquare:!0},{slotId:"slip-2",sector:7,angleDegrees:300,depth:"INNER",insideCircle:!0,legSide:!1,behindSquare:!0},{slotId:"point",sector:6,angleDegrees:270,depth:"MIDDLE",insideCircle:!0,legSide:!1,behindSquare:!1},{slotId:"cover",sector:5,angleDegrees:225,depth:"MIDDLE",insideCircle:!0,legSide:!1,behindSquare:!1},{slotId:"mid-off",sector:4,angleDegrees:190,depth:"MIDDLE",insideCircle:!0,legSide:!1,behindSquare:!1},{slotId:"mid-on",sector:4,angleDegrees:170,depth:"MIDDLE",insideCircle:!0,legSide:!0,behindSquare:!1},{slotId:"midwicket",sector:3,angleDegrees:135,depth:"MIDDLE",insideCircle:!0,legSide:!0,behindSquare:!1},{slotId:"deep-square-leg",sector:2,angleDegrees:90,depth:"DEEP",insideCircle:!1,legSide:!0,behindSquare:!1},{slotId:"fine-leg",sector:1,angleDegrees:45,depth:"DEEP",insideCircle:!1,legSide:!0,behindSquare:!0},{slotId:"deep-cover",sector:5,angleDegrees:225,depth:"DEEP",insideCircle:!1,legSide:!1,behindSquare:!1},{slotId:"long-on",sector:4,angleDegrees:170,depth:"DEEP",insideCircle:!1,legSide:!0,behindSquare:!1}]}),ls=["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"],ds=["deep-cover","long-on","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"],tu=ll.parse({registryId:"LC_ODI_FIELD_01",referenceHand:"R",positions:[...ya.positions,{slotId:"long-off",sector:4,angleDegrees:190,depth:"DEEP",insideCircle:!1,legSide:!1,behindSquare:!1}]}),au=ls,GS=ds,jS=["deep-cover","long-off","long-on","deep-square-leg","fine-leg","point","cover","mid-on","midwicket"],pe=Object.freeze({manifest:{modelId:"synthetic-alpha-01",schemaVersion:"1.0.0",status:"SYNTHETIC_ALPHA",randomId:"SHA256_COUNTER_V1",fixedPointScale:1e4,expLutHash:"d0cb73226646dec41e482127fc745ef64213f1c71f898ed7ad8c345ce591f825",featureSpecHash:"8a369a30b377ede7f7bc8c8f523a1c0124b6fd299ddf4f9fad5b3fd402d065b7",variationIds:["stock"],effects:{overAroundWicket:!1,individualVariations:!1,moisture:!1,geometryEffects:!1,outfieldSpeed:!1}},probabilityVersion:"LC_INTEGER_PROBABILITY_V1",lutVersion:"LC_EXP_LUT_V1",lutScale:"1000000000000",lutStepBp:100,lutMinDeltaBp:-16e4,lutMaxDeltaBp:0,logitMinBp:-8e4,logitMaxBp:8e4,coefficients:{legality:{WIDE:{CONTROL:-7e3,FATIGUE:5e3,LEG_LINE:2e3,MAXIMUM_EFFORT:1500,CONSERVE_EFFORT:-1e3},NO_BALL:{CONTROL:-5e3,FATIGUE:4e3,MAXIMUM_EFFORT:1500,CONSERVE_EFFORT:-1e3}},contact:{MISS:{DEFENCE:-4e3,AGGRESSION:2500,MOVEMENT:2500},PAD:{DEFENCE:-3e3,MOVEMENT:2e3},GROUND:{TIMING:3500,AGGRESSION:-1500},AERIAL:{AGGRESSION:4500,POWER:2500},EDGE:{TIMING:-4e3,AGGRESSION:2500,MOVEMENT:3e3},HIT_WICKET:{AGGRESSION:1e3}}},featureSpec:{maxTerms:32,fixedPointScale:1e4,termMultiplyRounding:"NEAREST_TIES_AWAY_FROM_ZERO",accumulationOrder:"INTERCEPT_TERMS_IN_ARRAY_ORDER",clipTiming:"AFTER_SUM",lutDeltaRounding:"NEAREST_TIES_AWAY_FROM_ZERO",categoryOrder:"AS_SUPPLIED",massAllocation:"LARGEST_REMAINDER_CATEGORY_INDEX"},expLutValues:[1e12,990049833749,980198673307,970445533549,960789439152,951229424501,941764533584,932393819906,923116346387,913931185271,904837418036,895834135297,886920436717,878095430921,869358235399,860707976425,852143788966,843664816596,835270211411,826959133943,818730753078,810584245970,802518797962,794533602503,786627861067,778800783071,771051585804,763379494337,755783741456,748263567579,740818220682,733446956224,726149037074,718923733432,711770322763,704688089719,697676326071,690734330637,683861409212,677056874498,670320046036,663650250136,657046819815,650509094723,644036421083,637628151622,631283645507,625002268283,618783391806,612626394184,606530659713,600495578812,594520547970,588604969678,582748252374,576949810380,571209063849,565525438700,559898366565,554327284735,548811636094,543350869074,537944437595,532591801007,527292424043,522045776761,516851334492,511708577787,506616992366,501576069066,496585303791,491644197461,486752255960,481908990090,477113915521,472366552741,467666427010,463013068311,458406011305,453844795282,449328964117,444858066223,440431654506,436049286322,431710523429,427414931949,423162082318,418951549248,414782911682,410655752752,406569659741,402524224034,398519041085,394553710372,390627835359,386741023455,382892885975,379083038103,375311098851,371576691022,367879441171,364218979572,360594940173,357006960569,353454681959,349937749111,346455810330,343008517419,339595525645,336216493707,332871083698,329558961075,326279794623,323033256422,319819021816,316636769379,313486180883,310366941265,307278738601,304221264067,301194211912,298197279430,295230166924,292292577681,289384217939,286504796860,283654026500,280831621778,278037300453,275270783090,272531793034,269820056385,267135301966,264477261300,261845668580,259240260646,256660776954,254106959553,251578553060,249075304632,246596963942,244143283153,241714016897,239308922244,236927758682,234570288094,232236274730,229925485187,227637688384,225372655539,223130160148,220909977959,218711886952,216535667316,214381101427,212247973827,210136071201,208045182357,205975098205,203925611734,201896517995,199887614075,197898699084,195929574127,193980042291,192049908621,190138980102,188247065639,186373976039,184519523993,182683524053,180865792617,179066147911,177284409970,175520400617,173773943450,172044863823,170332988825,168638147269,166960169667,165298888222,163654136803,162025750934,160413567775,158817426107,157237166314,155672630368,154123661815,152590105757,151071808836,149568619223,148080386595,146606962130,145148198484,143703949778,142274071587,140858420921,139456856215,138069237311,136695425446,135335283237,133988674669,132655465080,131335521148,130028710878,128734903588,127453969895,126185781705,124930212199,123687135817,122456428253,121237966433,120031628511,118837293852,117654843022,116484157773,115325121038,114177616911,113041530640,111916748617,110803158362,109700648516,108609108825,107528430136,106458504379,105399224562,104350484755,103312180083,102284206716,101266461854,100258843723,99261251560,98273585604,97295747090,96327638230,95369162216,94420223196,93480726278,92550577510,91629683878,90717953289,89815294572,88921617459,88036832582,87160851462,86293586499,85434950967,84584859002,83743225592,82909966575,82084998624,81268239241,80459606750,79659020286,78866399791,78081666001,77304740443,76535545424,75774004023,75020040085,74273578214,73534543763,72802862827,72078462239,71361269556,70651213060,69948221745,69252225309,68563154154,67880939372,67205512740,66536806715,65874754426,65219289668,64570346893,63927861207,63291768360,62662004742,62038507377,61421213915,60810062625,60204992392,59605942709,59012853669,58425665965,57844320875,57268760265,56698926580,56134762834,55576212611,55023220056,54475729869,53933687300,53397038145,52865728738,52339705948,51818917173,51303310332,50792833865,50287436724,49787068368,49291678760,48801218362,48315638126,47834889494,47358924391,46887695220,46421154857,45959256649,45501954405,45049202394,44600955340,44157168420,43717797253,43282797902,42852126867,42425741081,42003597903,41585655121,41171870939,40762203978,40356613272,39955058261,39557498788,39163895099,38774207832,38388398018,38006427075,37628256807,37253849396,36883167401,36516173754,36152831754,35793105068,35436957722,35084354101,34735258945,34389637343,34047454735,33708676900,33373269960,33041200376,32712434939,32386940773,32064685328,31745636378,31429762018,31117030661,30807411033,30500872171,30197383422,29896914437,29599435168,29304915867,29013327082,28724639654,28438824714,28155853680,27875698255,27598330423,27323722447,27051846866,26782676493,26516184409,26252343966,25991128779,25732512726,25476469947,25222974835,24972002042,24723526470,24477523272,24233967846,23992835837,23754103131,23517745856,23283740375,23052063287,22822691425,22595601851,22370771856,22148178957,21927800894,21709615630,21493601345,21279736438,21067999523,20858369425,20650825182,20445346038,20241911446,20040501062,19841094744,19643672553,19448214745,19254701775,19063114292,18873433135,18685639338,18499714120,18315638889,18133395237,17952964940,17774329954,17597472416,17422374639,17249019115,17077388507,16907465653,16739233559,16572675402,16407774526,16244514442,16082878823,15922851505,15764416485,15607557920,15452260124,15298507567,15146284873,14995576820,14846368338,14698644505,14552390548,14407591843,14264233909,14122302410,13981783153,13842662086,13704925297,13568559012,13433549594,13299883542,13167547490,13036528203,12906812580,12778387650,12651240568,12525358621,12400729220,12277339903,12155178330,12034232285,11914489673,11795938520,11678566970,11562363287,11447315851,11333413155,11220643810,11108996538,10998460176,10889023669,10780676073,10673406554,10567204384,10462058943,10357959718,10254896296,10152858373,10051835745,9951818308,9852796061,9754759102,9657697628,9561601931,9466462402,9372269527,9279013887,9186686156,9095277102,9004777582,8915178548,8826471040,8738646185,8651695203,8565609397,8480380160,8395998967,8312457382,8229747049,8147859698,8066787139,7986521266,7907054052,7828377549,7750483891,7673365288,7597014028,7521422475,7446583071,7372488331,7299130847,7226503281,7154598372,7083408929,7012927833,6943148035,6874062557,6805664492,6737946999,6670903306,6604526709,6538810571,6473748318,6409333446,6345559513,6282420141,6219909016,6158019887,6096746566,6036082924,5976022895,5916560474,5857689713,5799404727,5741699686,5684568819,5628006414,5572006815,5516564421,5461673688,5407329126,5353525303,5300256836,5247518399,5195304719,5143610573,5092430793,5041760260,4991593907,4941926718,4892753725,4844070012,4795870710,4748150999,4700906108,4654131310,4607821930,4561973336,4516580943,4471640211,4427146648,4383095803,4339483271,4296304691,4253555745,4211232158,4169329698,4127844174,4086771438,4046107383,4005847942,3965989089,3926526838,3887457243,3848776398,3810480433,3772565519,3735027865,3697863716,3661069358,3624641109,3588575327,3552868406,3517516775,3482516898,3447865276,3413558443,3379592969,3345965457,3312672545,3279710902,3247077234,3214768275,3182780797,3151111598,3119757514,3088715408,3057982176,3027554745,2997430072,2967605145,2938076980,2908842626,2879899158,2851243683,2822873334,2794785275,2766976697,2739444819,2712186887,2685200177,2658481989,2632029651,2605840518,2579911972,2554241419,2528826292,2503664050,2478752177,2454088180,2429669595,2405493979,2381558914,2357862006,2334400888,2311173211,2288176653,2265408915,2242867719,2220550813,2198455963,2176580961,2154923618,2133481770,2112253272,2091236001,2070427855,2049826753,2029430636,2009237464,1989245217,1969451897,1949855523,1930454136,1911245797,1892228583,1873400594,1854759947,1836304777,1818033239,1799943506,1782033769,1764302237,1746747136,1729366712,1712159226,1695122957,1678256201,1661557273,1645024502,1628656235,1612450834,1596406681,1580522169,1564795710,1549225733,1533810679,1518549008,1503439193,1488479723,1473669102,1459005850,1444488499,1430115598,1415885710,1401797412,1387849295,1374039964,1360368038,1346832149,1333430946,1320163086,1307027244,1294022105,1281146370,1268398751,1255777973,1243282773,1230911903,1218664125,1206538214,1194532958,1182647157,1170879621,1159229174,1147694651,1136274898,1124968774,1113775148,1102692900,1091720922,1080858118,1070103400,1059455693,1048913933,1038477065,1028144045,1017913841,1007785429,997757796,987829941,978000868,968269597,958635154,949096575,939652906,930303203,921046532,911881966,902808588,893825493,884931781,876126562,867408957,858778094,850233109,841773148,833397366,825104923,816894992,808766751,800719387,792752096,784864081,777054553,769322731,761667842,754089120,746585808,739157155,731802419,724520863,717311760,710174389,703108036,696111994,689185564,682328053,675538775,668817052,662162211,655573587,649050521,642592360,636198460,629868179,623600886,617395954,611252761,605170695,599149146,593187512,587285198,581441612,575656171,569928297,564257416,558642960,553084370,547581089,542132566,536738257,531397622,526110127,520875244,515692449,510561223,505481054,500451433,495471858,490541831,485660858,480828452,476044129,471307411,466617824,461974899,457378172,452827183,448321477,443860604,439444117,435071575,430742541,426456581,422213267,418012175,413852884,409734979,405658048,401621683,397625480,393669041,389751968,385873871,382034362,378233057,374469575,370743540,367054581,363402326,359786413,356206478,352662165,349153117,345678986,342239423,338834083,335462628,332124719,328820023,325548209,322308950,319101922,315926805,312783281,309671035,306589757,303539138,300518873,297528660,294568201,291637198,288735360,285862395,283018016,280201940,277413884,274653570,271920721,269215065,266536330,263884249,261258557,258658991,256085291,253537200,251014463,248516827,246044043,243595864,241172045,238772343,236396518,234044334,231715554,229409945,227127278,224867324,222629857,220414653,218221490,216050150,213900415,211772071,209664903,207578703,205513260,203468369,201443825,199439425,197454970,195490260,193545100,191619294,189712650,187824977,185956088,184105794,182273910,180460255,178664645,176886902,175126848,173384307,171659104,169951068,168260026,166585811,164928254,163287191,161662456,160053888,158461325,156884609,155323581,153778085,152247968,150733075,149233256,147748360,146278239,144822747,143381736,141955064,140542588,139144166,137759658,136388926,135031834,133688245,132358025,131041040,129737160,128446254,127168192,125902848,124650093,123409804,122181856,120966126,119762493,118570836,117391037,116222977,115066539,113921607,112788069,111665808,110554715,109454677,108365585,107287330,106219803,105162898,104116510,103080533,102054865,101039402,100034043,99038688,98053236,97077590,96111652,95155325,94208514,93271123,92343060,91424231,90514545,89613910,88722237,87839436,86965419,86100099,85243388,84395203,83555456,82724066,81900947,81086019,80279200,79480409,78689565,77906591,77131407,76363937,75604103,74851830,74107042,73369664,72639624,71916848,71201263,70492799,69791384,69096948,68409422,67728736,67054824,66387618,65727050,65073055,64425567,63784522,63149855,62521504,61899404,61283495,60673714,60070001,59472294,58880535,58294664,57714622,57140352,56571796,56008897,55451599,54899847,54353584,53812757,53277311,52747193,52222350,51702729,51188278,50678946,50174682,49675436,49181157,48691796,48207305,47727634,47252736,46782563,46317069,45856207,45399930,44948193,44500951,44058159,43619773,43185749,42756044,42330614,41909417,41492412,41079555,40670807,40266126,39865471,39468803,39076082,38687268,38302323,37921209,37543887,37170319,36800468,36434297,36071770,35712850,35357501,35005688,34657375,34312529,33971113,33633095,33298440,32967115,32639087,32314323,31992790,31674456,31359290,31047260,30738335,30432483,30129675,29829879,29533067,29239208,28948273,28660233,28375059,28092723,27813195,27536449,27262457,26991191,26722624,26456730,26193481,25932851,25674815,25419347,25166420,24916010,24668091,24422640,24179630,23939039,23700842,23465014,23231533,23000376,22771518,22544938,22320612,22098518,21878634,21660938,21445408,21232023,21020761,20811601,20604522,20399503,20196525,19995566,19796607,19599627,19404608,19211529,19020371,18831115,18643742,18458234,18274571,18092736,17912711,17734476,17558015,17383310,17210343,17039098,16869556,16701701,16535516,16370985,16208091,16046818,15887149,15729069,15572563,15417613,15264205,15112324,14961954,14813080,14665687,14519761,14375287,14232251,14090637,13950433,13811624,13674196,13538136,13403429,13270062,13138023,13007298,12877873,12749736,12622874,12497274,12372924,12249812,12127924,12007249,11887775,11769490,11652381,11536438,11421649,11308001,11195485,11084088,10973799,10864608,10756504,10649475,10543511,10438601,10334735,10231903,10130094,10029297,9929504,9830704,9732887,9636043,9540163,9445237,9351255,9258208,9166088,9074884,8984587,8895189,8806680,8719052,8632296,8546404,8461365,8377173,8293819,8211294,8129591,8048700,7968614,7889325,7810825,7733106,7656160,7579980,7504558,7429886,7355958,7282765,7210300,7138556,7067526,6997203,6927580,6858650,6790405,6722839,6655946,6589718,6524149,6459233,6394962,6331331,6268334,6205963,6144212,6083076,6022549,5962623,5903294,5844556,5786401,5728826,5671823,5615387,5559513,5504195,5449428,5395205,5341522,5288373,5235752,5183656,5132078,5081013,5030456,4980402,4930846,4881783,4833209,4785117,4737505,4690366,4643696,4597490,4551744,4506454,4461614,4417220,4373268,4329753,4286672,4244018,4201790,4159981,4118589,4077608,4037035,3996866,3957097,3917723,3878741,3840147,3801937,3764107,3726653,3689572,3652860,3616514,3580529,3544902,3509630,3474708,3440134,3405905,3372015,3338463,3305245,3272357,3239797,3207560,3175644,3144046,3112762,3081790,3051126,3020766,2990709,2960951,2931489,2902320,2873442,2844851,2816544,2788519,2760773,2733302,2706106,2679179,2652521,2626128,2599998,2574127,2548514,2523156,2498050,2473194,2448586,2424222,2400100,2376219,2352575,2329167,2305991,2283046,2260329,2237839,2215572,2193527,2171701,2150092,2128698,2107517,2086547,2065786,2045231,2024880,2004732,1984785,1965036,1945484,1926126,1906960,1887986,1869200,1850601,1832187,1813957,1795908,1778038,1760346,1742831,1725489,1708320,1691322,1674493,1657832,1641336,1625004,1608835,1592827,1576978,1561287,1545752,1530372,1515144,1500068,1485142,1470365,1455734,1441250,1426909,1412711,1398654,1384737,1370959,1357318,1343812,1330441,1317203,1304097,1291121,1278274,1265555,1252962,1240495,1228152,1215932,1203833,1191855,1179995,1168254,1156630,1145121,1133727,1122446,1111278,1100220,1089273,1078435,1067704,1057080,1046562,1036149,1025839,1015631,1005526,995521,985615,975808,966099,956486,946969,937546,928217,918981,909837,900784,891821,882948,874162,865464,856853,848327,839886,831529,823255,815063,806953,798924,790975,783104,775312,767598,759960,752398,744912,737500,730162,722896,715703,708582,701532,694551,687640,680798,674024,667317,660678,654104,647595,641152,634772,628456,622203,616012,609882,603814,597806,591857,585968,580138,574365,568650,562992,557390,551844,546353,540917,535535,530206,524930,519707,514536,509416,504348,499329,494361,489442,484572,479750,474977,470251,465572,460939,456353,451812,447316,442865,438459,434096,429777,425500,421267,417075,412925,408816,404748,400721,396734,392786,388878,385009,381178,377385,373630,369912,366232,362588,358980,355408,351871,348370,344904,341472,338074,334710,331380,328083,324818,321586,318386,315218,312082,308977,305902,302859,299845,296862,293908,290983,288088,285221,282383,279574,276792,274038,271311,268611,265939,263293,260673,258079,255511,252969,250452,247960,245492,243050,240631,238237,235866,233520,231196,228896,226618,224363,222131,219920,217732,215566,213421,211297,209195,207113,205052,203012,200992,198992,197012,195052,193111,191190,189287,187404,185539,183693,181865,180056,178264,176490,174734,172996,171274,169570,167883,166212,164558,162921,161300,159695,158106,156533,154975,153433,151907,150395,148899,147417,145950,144498,143060,141637,140227,138832,137451,136083,134729,133388,132061,130747,129446,128158,126883,125621,124371,123133,121908,120695,119494,118305,117128,115962,114809,113666,112535],baselines:{legality:[{id:"LEGAL",baseWeight:9820},{id:"WIDE",baseWeight:130},{id:"NO_BALL",baseWeight:50}],contact:{T20_EARLY:[{id:"MISS",baseWeight:1250},{id:"PAD",baseWeight:700},{id:"GROUND",baseWeight:5900},{id:"AERIAL",baseWeight:1500},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],T20_MIDDLE:[{id:"MISS",baseWeight:1100},{id:"PAD",baseWeight:650},{id:"GROUND",baseWeight:6100},{id:"AERIAL",baseWeight:1500},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],T20_LATE:[{id:"MISS",baseWeight:1350},{id:"PAD",baseWeight:500},{id:"GROUND",baseWeight:5e3},{id:"AERIAL",baseWeight:2500},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],ODI_EARLY:[{id:"MISS",baseWeight:1700},{id:"PAD",baseWeight:900},{id:"GROUND",baseWeight:5950},{id:"AERIAL",baseWeight:800},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],ODI_MIDDLE:[{id:"MISS",baseWeight:1300},{id:"PAD",baseWeight:800},{id:"GROUND",baseWeight:6400},{id:"AERIAL",baseWeight:900},{id:"EDGE",baseWeight:595},{id:"HIT_WICKET",baseWeight:5}],ODI_LATE:[{id:"MISS",baseWeight:1300},{id:"PAD",baseWeight:550},{id:"GROUND",baseWeight:5300},{id:"AERIAL",baseWeight:2200},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],RED_BALL:[{id:"MISS",baseWeight:1900},{id:"PAD",baseWeight:1400},{id:"GROUND",baseWeight:5650},{id:"AERIAL",baseWeight:400},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}]}}}),tt="d0cb73226646dec41e482127fc745ef64213f1c71f898ed7ad8c345ce591f825",Cn="d47d5caca955b7a374b0052d712b1674bca6d855e222194ce9f0587d8580b7ab";function ou(n){for(const e of Object.values(n))e&&typeof e=="object"&&ou(e);return Object.freeze(n)}const Tn=ou({stagePackId:"synthetic-alpha-01-delivery-v1",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",status:"SYNTHETIC_ALPHA",source:"Lord_Cricket_XXVI_Technical_Design_V0_1(1).docx Appendix F",length:{intended:7e3,neighboursTotal:2500,gross:500,intendedControlBp:6e3,intendedFatigueBp:-5e3},elapsedSeconds:40,sectorLineMultiplierBp:12500,coverage:{neighbourBp:3500,ground:{INNER:8e3,MIDDLE:1e4,DEEP:7e3},aerial:{INNER:2e3,MIDDLE:5e3,DEEP:1e4},edge:{keeper:1e4,slip:1e4,gully:6e3,other:1e3}},catchOpportunityBp:{AERIAL:3e3,EDGE:4500},catchConversion:{interceptBp:15e3,catchingBp:12e3},runs:{GROUND:[4400,3600,900,100,1e3,0],AERIAL:[1800,1600,900,100,2400,3200],EDGE:[6e3,1300,300,0,2400,0],NONE:[9700,250,0,0,50,0],WIDE:[9800,150,50]},running:{interceptBp:-65e3,throwingBp:5e3,coverageBp:3e3,rotateBp:2500},bowled:{interceptBp:-35e3,controlBp:3e3,defenceBp:-3e3,stumpsBp:4e3},lbw:{interceptBp:-4e4,controlBp:3e3,defenceBp:-3e3},stumping:{numerator:3,denominator:1e3},noLiveMatchOrCalibration:!0}),Zn="34efa3037702e44a134ea38b414eab3e97c6f79f10b3e5458bc2ab05412e5d7a",xn=Object.freeze({worldPackId:"fictional-eight-01",worldSeed:"lcxxvi-fictional-eight-v1-20260927",worldGeneratorVersion:"LC_FICTIONAL_WORLD_GENERATOR_V1",generatorSourceSha256:"a3aaa4b64926ad9859f84222eb51274e7881df750308c2e9ae8fd1fa66e2f4da",provenanceSourceSha256:"97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",worldFileSha256:"0136173903ba42a199c84a17407cf711c2caf1b57c52472abb52e9be7a6d8257",worldCanonicalSha256:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",worldByteLength:310033}),us=n=>new Set(n).size===n.length;function wn(n,e){if(!n)throw new Error(`INVALID_DEFAULT_WORLD: ${e}`)}const at=n=>n.bowlingStyle!==null&&(n.role==="BOWLER"||n.role==="ALLROUNDER");function YS(n,e){const t=tf.parse(e),a=xn;for(const E of Object.keys(a))wn(t[E]===a[E],`manifest violates frozen ${E}`);wn(t.modelHash===Cn,"model hash mismatch"),wn(t.stagePackHash===Zn,"stage pack hash mismatch"),wn(t.modelId===pe.manifest.modelId,"wrong model"),wn(t.stagePackId===Tn.stagePackId,"wrong stage pack");const o=yt.map(E=>E.rulesId);wn(JSON.stringify(t.rulesIds)===JSON.stringify(o),"inconsistent rule IDs"),wn(JSON.stringify(t.variationIds)===JSON.stringify(pe.manifest.variationIds),"model variation set mismatch");const i=mr(n,t.variationIds,o);wn(i.packId===t.worldPackId,"pack ID mismatch"),wn(i.schemaVersion===t.schemaVersion,"schema mismatch"),wn(i.players.length===160&&i.teams.length===8&&i.grounds.length===8,"expected exactly 160 players, eight teams and eight grounds"),wn(JSON.stringify(i.rulesIds)===JSON.stringify(t.rulesIds),"world rules differ from manifest");const r=i.teams.map(E=>E.teamId),s=i.grounds.map(E=>E.groundId),c=E=>Array.from({length:8},(b,w)=>`${E}-${String(w+1).padStart(2,"0")}`);wn(JSON.stringify(r)===JSON.stringify(c("team")),"team ID/order convention changed"),wn(JSON.stringify(s)===JSON.stringify(c("ground")),"ground ID/order convention changed"),wn(JSON.stringify(r)===JSON.stringify(t.teamIds)&&JSON.stringify(s)===JSON.stringify(t.groundIds),"world/manifest ID mismatch");const u=new Set(s);wn(JSON.stringify(Object.keys(t.homeGroundIds))===JSON.stringify(r),"home-ground keys mismatch"),wn(t.homeGroundIds&&us(Object.values(t.homeGroundIds))&&Object.values(t.homeGroundIds).every(E=>u.has(E)),"home-ground reference invalid");const h=new Map(i.players.map(E=>[E.playerId,E])),p=[];for(const E of i.teams){wn(E.squadIds.length===20,`20 players required: ${E.teamId}`);const b=E.squadIds.map(w=>h.get(w));p.push(...E.squadIds),wn(b.filter(w=>w.role==="KEEPER").length>=2,`keepers missing: ${E.teamId}`),wn(b.filter(at).length>=6,`bowling capacity missing: ${E.teamId}`),wn(new Set(b.map(w=>w.role)).size>=3,`insufficient role variety: ${E.teamId}`),wn(us(b.map(w=>w.playerId)),`repeated player in squad: ${E.teamId}`),wn(new Set(b.map(w=>w.batHand)).size===2,`bat handedness missing: ${E.teamId}`),wn(new Set(b.filter(at).map(w=>w.bowlHand)).size===2,`bowling handedness missing: ${E.teamId}`)}wn(us(p)&&p.length===160&&p.every(E=>h.has(E)),"shared squad member or missing assignment");for(const E of i.players)wn(E.provenance.kind==="FICTIONAL"&&E.provenance.sourceId===i.packId&&E.provenance.sourceHash===t.provenanceSourceSha256,`wrong provenance: ${E.playerId}`),wn(E.exposureBalls.T20===0&&E.exposureBalls.ODI===0&&E.exposureBalls.RED_BALL===0,`invented exposure: ${E.playerId}`),wn(Object.keys(E.skills).length===3&&Object.keys(E.exposureBalls).length===3,`missing format or exposure: ${E.playerId}`),wn(E.variations.length===1&&E.variations[0]==="stock",`unsupported variation: ${E.playerId}`);return{world:i,manifest:t}}const so=Object.freeze({version:"LC_T20_CONDITIONS_V1",fatigueBaseBp:{pace:20,spin:12},effortFactorBp:{CONSERVE:8e3,NORMAL:1e4,MAXIMUM:13e3},recoveryNonBowlerPerOverBp:15,wearIncrementPerLegalBall:1,wearStep:100,wearTurnDeltaBp:20,wearVariabilityDeltaBp:10,wearSeamDeltaBp:-10,maxBasisPoints:1e4,weather:"DRY",ballAgeResetAtInnings:!0}),iu=Object.freeze({...so,version:"LC_ODI_CONDITIONS_V1"});gf.parse({competitionVersion:"LC_T20_LEAGUE_COMPETITION_V1",competitionId:"LC_T20_LEAGUE_01",format:"T20",worldPackId:"fictional-eight-01",worldCanonicalSha256:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",teamIds:["team-01","team-02","team-03","team-04","team-05","team-06","team-07","team-08"],groundIds:["ground-01","ground-02","ground-03","ground-04","ground-05","ground-06","ground-07","ground-08"],homeGroundIds:{"team-01":"ground-01","team-02":"ground-02","team-03":"ground-03","team-04":"ground-04","team-05":"ground-05","team-06":"ground-06","team-07":"ground-07","team-08":"ground-08"},teamCount:8,rounds:14,matchesPerRound:4,totalFixtures:56,roundSpacingDays:3,playoffs:!1,points:{win:2,tie:1,noResult:1,loss:0},tableOrder:["POINTS","WINS","NET_RUN_RATE","HEAD_TO_HEAD_POINTS","TEAM_ID"],rainAdjustedNrr:!1,schedulerAlgorithm:"CIRCLE_REVERSE_VENUES_V1"}),pf.parse({conditionPolicyVersion:"LC_T20_CAREER_CONDITION_V1",maxFatigueBp:1e4,restRecoveryPerDayBp:2e3,practiceRecoveryPerDayBp:1400,noRandomInjuries:!0}),ff.parse({availabilityVersion:"LC_T20_AVAILABILITY_PACK_V1",packId:"fictional-eight-01-availability-v1",worldPackId:xn.worldPackId,worldCanonicalSha256:xn.worldCanonicalSha256,entries:[]});const zS=Object.freeze(Object.fromEntries(Array.from({length:8},(n,e)=>{const t=e*20+1;return[`team-${String(e+1).padStart(2,"0")}`,Array.from({length:20},(a,o)=>`p${String(t+o).padStart(3,"0")}`)]}))),KS=Object.freeze(Array.from({length:160},(n,e)=>`p${String(e+1).padStart(3,"0")}`));Sf.parse({trainingPolicyVersion:"LC_T20_CAREER_TRAINING_V1",readinessMinRatingDelta:-3,readinessMaxRatingDelta:3,readinessPracticeGainPerDay:1,readinessDecayPerDay:1,restRecoveryPerDayBp:2e3,practiceRecoveryPerDayBp:1400,noPermanentAttributeGrowth:!0}),Tf.parse({policyVersion:"LC_T20_OFFSCREEN_POLICY_V1",executionVersion:"LC_T20_OFFSCREEN_FIXTURE_V1",selectionPolicyId:"LC_SEASON_XI_BASELINE_V1",captainPolicyId:"LC_FIXTURE_CAPTAIN_V1",conditionDeltaPolicyId:"LC_ENGINE_FINAL_FATIGUE_DELTA_V1",matchEngineVersion:"LC_T20_MATCH_V1",selectionScorePolicy:"SUM_SUPPORTED_T20_SKILLS_PLUS_AREA_READINESS_V1",unavailablePlayersExcluded:!0,fatigueSelectionEffect:"LOWER_FATIGUE_STABLE_TIEBREAK_ONLY",minimumNonKeeperBowlingCapable:5,requiresKeeper:!0,noFutureRandomAccess:!0,noAlternateMatchSimulator:!0});const qS=Object.freeze([{schemaId:He,scenarioId:"t20-death-overs-chase",title:"Death-overs chase",format:"T20",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-2",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-03",objective:"WIN",objectiveSummary:"Score 23 from the last 24 balls with 5 wickets in hand.",briefing:"Northlight Ridge are 68 for 5 after 16 overs, chasing 91 against Silver Fen at Northlight Park. You captain the chase: pick your batters and their intent, and see it home.",checkpoint:{inningsIndex:1,legalBalls:96,revision:105,battingTeamId:"team-03",runs:68,wickets:5,targetToWin:91}},{schemaId:He,scenarioId:"t20-tail-end-chase",title:"Tail-end chase",format:"T20",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-12",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-06",objective:"WIN",objectiveSummary:"Score 46 from the last 30 balls with 3 wickets in hand.",briefing:"Silver Fen have collapsed to 36 for 7 after 15 overs, chasing 82 against Northlight Ridge. Three wickets remain. Find 46 runs before the overs or the batters run out.",checkpoint:{inningsIndex:1,legalBalls:90,revision:102,battingTeamId:"team-06",runs:36,wickets:7,targetToWin:82}},{schemaId:He,scenarioId:"t20-defend-55",title:"Hold the line",format:"T20",difficulty:"STANDARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-11",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-03",objective:"WIN",objectiveSummary:"Stop Silver Fen scoring 55 from the last 30 balls.",briefing:"Silver Fen are 49 for 4 after 15 overs, chasing 104. You lead Northlight Ridge in the field: choose bowlers, plans and fields for the last five overs.",checkpoint:{inningsIndex:1,legalBalls:90,revision:98,battingTeamId:"team-06",runs:49,wickets:4,targetToWin:104}},{schemaId:He,scenarioId:"t20-defend-19",title:"Nineteen to defend",format:"T20",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-1",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-03",objective:"WIN",objectiveSummary:"Stop Silver Fen scoring 19 from the last 30 balls.",briefing:"Silver Fen are 52 for 4 after 15 overs, chasing 71. Northlight Ridge need six wickets, or to keep the runs below 19, in the last five overs.",checkpoint:{inningsIndex:1,legalBalls:90,revision:99,battingTeamId:"team-06",runs:52,wickets:4,targetToWin:71}},{schemaId:He,scenarioId:"odi-tail-rescue",title:"Lower-order rescue",format:"ODI",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-odi-8",matchId:"human-odi",teamIds:["team-02","team-05"],groundId:"ground-02",playerTeamId:"team-02",objective:"WIN",objectiveSummary:"Score 32 more runs with 3 wickets in hand.",briefing:"Copper Vale are 59 for 7 after 17 overs, chasing 91 against Ember Plains at Copperfield. There is plenty of time and very little batting left. Nurse the tail to the target.",checkpoint:{inningsIndex:1,legalBalls:102,revision:133,battingTeamId:"team-02",runs:59,wickets:7,targetToWin:91}},{schemaId:He,scenarioId:"odi-last-ten",title:"Ten runs, two wickets",format:"ODI",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-odi-2",matchId:"human-odi",teamIds:["team-02","team-05"],groundId:"ground-02",playerTeamId:"team-05",objective:"WIN",objectiveSummary:"Take 2 wickets before Copper Vale score 10.",briefing:"Copper Vale are 134 for 8 after 40 overs, chasing 144. Ember Plains have 60 balls to take the last two wickets before the final 10 runs come.",checkpoint:{inningsIndex:1,legalBalls:240,revision:187,battingTeamId:"team-02",runs:134,wickets:8,targetToWin:144}},{schemaId:He,scenarioId:"red-fourth-innings-chase",title:"Fourth-innings chase",format:"RED_BALL",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-red-4",matchId:"human-red5",teamIds:["team-04","team-07"],groundId:"ground-04",playerTeamId:"team-07",objective:"WIN",objectiveSummary:"Score 63 more in the fourth innings with 4 wickets in hand.",briefing:"Larchwood are 41 for 6 in the fourth innings, chasing 104 against Westmere Isles at Westmere Oval. Time is not the problem; wickets are.",checkpoint:{inningsIndex:3,legalBalls:114,revision:293,battingTeamId:"team-07",runs:41,wickets:6,targetToWin:104}},{schemaId:He,scenarioId:"red-fourth-innings-defence",title:"Bowl them out",format:"RED_BALL",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-red-5",matchId:"human-red5",teamIds:["team-04","team-07"],groundId:"ground-04",playerTeamId:"team-04",objective:"WIN",objectiveSummary:"Take 7 wickets before Larchwood score 63.",briefing:"Larchwood are 28 for 3 in the fourth innings, chasing 91 at Westmere Oval. Westmere Isles must bowl them out to win.",checkpoint:{inningsIndex:3,legalBalls:84,revision:301,battingTeamId:"team-07",runs:28,wickets:3,targetToWin:91}},{schemaId:He,scenarioId:"t20-super-over-decider",title:"Level at the death",format:"T20",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-tie-469",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-06",objective:"WIN",objectiveSummary:"Score 12 from the last 12 balls with 2 wickets in hand.",briefing:"Silver Fen are 71 for 8 after 18 overs, chasing 83 against Northlight Ridge. Left to the engine, this match finishes level. Finish it level and it goes to a super over; only an outright win completes the challenge.",checkpoint:{inningsIndex:1,legalBalls:108,revision:109,battingTeamId:"team-06",runs:71,wickets:8,targetToWin:83}},{schemaId:He,scenarioId:"t20-six-to-defend",title:"Six to defend",format:"T20",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-tie-555",matchId:"human-t20",teamIds:["team-01","team-02"],groundId:"ground-01",playerTeamId:"team-01",objective:"WIN",objectiveSummary:"Stop Copper Vale scoring 6 from the last 18 balls.",briefing:"Copper Vale are 70 for 5 after 17 overs, chasing 76 at Aster Quay. Left to the engine, this match ends in a tie. Aster Harbour need five wickets, or to keep the last six runs out, to win outright.",checkpoint:{inningsIndex:1,legalBalls:102,revision:98,battingTeamId:"team-02",runs:70,wickets:5,targetToWin:76}},{schemaId:He,scenarioId:"odi-cup-final-defence",title:"Cup final: three wickets",format:"ODI",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-odi-tie-8",matchId:"human-odi",teamIds:["team-01","team-02"],groundId:"ground-01",playerTeamId:"team-01",objective:"WIN",objectiveSummary:"Take 3 wickets before Copper Vale score 10.",briefing:"A one-day cup final at Aster Quay. Copper Vale are 65 for 7 after 22 overs, chasing 75. Left to the engine, this final ends in a tie. Aster Harbour need three wickets before the last ten runs come.",checkpoint:{inningsIndex:1,legalBalls:132,revision:125,battingTeamId:"team-02",runs:65,wickets:7,targetToWin:75}},{schemaId:He,scenarioId:"odi-cup-final-chase",title:"Cup final: the tail's turn",format:"ODI",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-odi-tie-95",matchId:"human-odi",teamIds:["team-05","team-08"],groundId:"ground-05",playerTeamId:"team-08",objective:"WIN",objectiveSummary:"Score 21 more with 3 wickets in hand.",briefing:"A one-day cup final at Ember Meadow. Moonstone Bay are 45 for 7 after 11 overs, chasing 66 against Ember Plains. Left to the engine, this final ends in a tie. Find 21 runs before the last three wickets fall.",checkpoint:{inningsIndex:1,legalBalls:66,revision:106,battingTeamId:"team-08",runs:45,wickets:7,targetToWin:66}}].map(n=>Object.freeze(E1.parse(n))));function ru(n){return qS.find(e=>e.scenarioId===n)??null}w1.parse({schemaId:wd,packId:"fictional-eight-tournaments-01",competitions:[{competitionId:"eight-nations-cup",title:"Eight Nations Cup",format:"T20",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-01","team-02","team-03","team-04","team-05","team-06","team-07","team-08"],groundIds:["ground-01","ground-02","ground-03","ground-04","ground-05","ground-06","ground-07","ground-08"],structure:{kind:"GROUPS_KNOCKOUT",groups:[["team-01","team-03","team-05","team-07"],["team-02","team-04","team-06","team-08"]]},points:{win:2,tie:1,loss:0},summary:"All eight sides in two T20 groups of four. The top two in each group reach the semi-finals, then a final. A tied knockout match goes to a super over."},{competitionId:"harbour-tri-series",title:"Harbour Tri-Series",format:"ODI",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-02","team-04","team-05"],groundIds:["ground-02","ground-04","ground-05"],structure:{kind:"ROUND_ROBIN",legs:2,finalTopTwo:!0},points:{win:4,tie:2,loss:0},summary:"Copper Vale, Westmere Isles and Ember Plains play each other twice in one-day matches. The top two meet in the final."},{competitionId:"larchwood-westmere-series",title:"Larchwood v Westmere one-day series",format:"ODI",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-07","team-04"],groundIds:["ground-07","ground-04"],structure:{kind:"SERIES",matches:5},points:{win:1,tie:0,loss:0},summary:"A five-match one-day series, home and away. It ends as soon as one side has won three."},{competitionId:"northern-t20-league",title:"Northern T20 League",format:"T20",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-01","team-03","team-06","team-08"],groundIds:["ground-01","ground-03","ground-06","ground-08"],structure:{kind:"ROUND_ROBIN",legs:2,finalTopTwo:!1},points:{win:2,tie:1,loss:0},summary:"Four sides play each other home and away in T20s. Top of the table wins."}]});const su=BigInt(wa),ZS=10000n,cu=-80000n,lu=80000n,XS=100n;function co(n,e){if(e<=0n)throw new Error("INVALID_DIVISOR: must be positive");const t=n<0n?-1n:1n,a=n<0n?-n:n;return t*((a*2n+e)/(2n*e))}function JS(n){let e=BigInt(n.interceptBp);for(const t of n.terms)e+=co(BigInt(t.coefficientBp)*BigInt(t.featureBp),ZS);return e<cu?Number(cu):e>lu?Number(lu):Number(e)}function QS(n){G(n);const e=jh.parse(n);if(te(ce(e))!==Cn)throw new Error("UNSUPPORTED_MODEL_HASH: model pack bytes do not match pinned version");if(e.manifest.modelId!==Be||e.probabilityVersion!==se||e.lutVersion!==ze||e.manifest.expLutHash!==tt)throw new Error("UNSUPPORTED_MODEL_VERSION");const t={version:e.lutVersion,stepBp:e.lutStepBp,minDeltaBp:e.lutMinDeltaBp,maxDeltaBp:e.lutMaxDeltaBp,scale:e.lutScale,values:e.expLutValues};if(te(ce(t))!==e.manifest.expLutHash)throw new Error("UNSUPPORTED_LUT_HASH: lookup table checksum mismatch");if(te(ce(e.featureSpec))!==e.manifest.featureSpecHash)throw new Error("UNSUPPORTED_FEATURE_SPEC_HASH");if(e.expLutValues[0]!==1e12||e.expLutValues.at(-1)<=0||e.expLutValues.some((o,i,r)=>i>0&&o>r[i-1]))throw new Error("INVALID_LUT: nonpositive or non-monotone exponential table");const a=[e.baselines.legality,...Object.values(e.baselines.contact)];if(Object.keys(e.baselines.contact).length!==7||a.some(o=>o.reduce((i,r)=>i+r.baseWeight,0)!==1e4||new Set(o.map(i=>i.id)).size!==o.length))throw new Error("INVALID_SYNTHETIC_BASELINES");return e}function du(n,e){if(!Number.isInteger(e)||e<0||e>=wa)throw new Error("INVALID_UINT32: draw outside [0, 2^32)");if(n.length===0||n.length>32)throw new Error("INVALID_CUMULATIVE_MASS");let t=0,a=-1;for(let o=0;o<n.length;o++){const i=n[o];if(!Number.isSafeInteger(i.mass)||!Number.isSafeInteger(i.cumulative)||i.mass<0||i.cumulative!==t+i.mass||!i.allowed&&i.mass!==0||i.cumulative>wa)throw new Error("INVALID_CUMULATIVE_MASS");a<0&&i.mass>0&&e<i.cumulative&&(a=o),t=i.cumulative}if(t!==wa||a===-1)throw new Error("INVALID_CUMULATIVE_MASS: exact 2^32 coverage required");return{index:a,id:n[a].id}}function uu(n=pe){const e=QS(n),t=Object.freeze(e.expLutValues.slice()),a=Nt(jn);function o(r){G(r);const s=Ir.parse(r);if(s.modelHash!==Cn||s.lutHash!==tt)throw new Error("UNSUPPORTED_MODEL_OR_LUT_HASH");const c=s.categories.map(R=>R.id);if(new Set(c).size!==c.length)throw new Error("DUPLICATE_CATEGORY_ID: canonical category order requires unique IDs");const u=s.categories.map(R=>R.allowed&&R.baseWeight>0?JS(R):null),h=u.filter(R=>R!==null);if(!h.length)throw new Error("EMPTY_POSITIVE_MASK: no allowed category has positive weight");const p=h.reduce((R,_)=>R>_?R:_),E=u.map(R=>{if(R===null)return null;const _=BigInt(R)-BigInt(p),U=Number(-co(_,XS));if(U<0||U>=t.length)throw new Error("INVALID_LUT_INDEX");return U}),b=s.categories.map((R,_)=>E[_]===null?0n:BigInt(R.baseWeight)*BigInt(t[E[_]])),w=b.reduce((R,_)=>R+_,0n);if(w<=0n)throw new Error("INVALID_PROBABILITY_TOTAL");const v=b.map(R=>R*su),T=v.map(R=>R/w),A=v.map(R=>R%w),I=su-T.reduce((R,_)=>R+_,0n);if(I<0n||I>=BigInt(b.length))throw new Error("INVALID_REMAINDER_ALLOCATION");const f=b.map((R,_)=>_).sort((R,_)=>{const U=A[R]-A[_];return U>0n?-1:U<0n?1:R-_});for(let R=0;R<Number(I);R++)T[f[R]]+=1n;let S=0;const k=s.categories.map((R,_)=>{const U=Number(T[_]);return S+=U,Object.freeze({id:R.id,allowed:R.allowed,logitBp:u[_],lutIndex:E[_],mass:U,cumulative:S})});if(S!==wa)throw new Error("MASS_NOT_NORMALISED");return Object.freeze({probabilityVersion:se,modelId:Be,modelHash:Cn,lutVersion:ze,lutHash:tt,totalMass:wa,categories:Object.freeze(k)})}function i(r){G(r);const s=Gh.parse(r),c=o({probabilityVersion:s.probabilityVersion,modelId:s.modelId,modelHash:s.modelHash,lutVersion:s.lutVersion,lutHash:s.lutHash,categories:s.categories});if(s.kind==="NORMALISE_CATEGORIES")return{kind:s.kind,...c};if(s.address.stageName!==s.stageName)throw new Error("STAGE_ADDRESS_MISMATCH: draw address must name its probability stage");const u=a.uint32(s.address),h=du(c.categories,u);return{kind:s.kind,...c,draw:u,selectedIndex:h.index,selectedCategoryId:h.id}}return Object.freeze({version:se,modelId:Be,modelHash:Cn,lutHash:tt,normalise:o,execute:i})}uu();function n_(n){G(n);const e=Yh.parse(n),t={CONTROL:(e.controlRating-50)*200,FATIGUE:e.fatigueBp,LEG_LINE:e.line==="LEG"?1e4:0,MAXIMUM_EFFORT:e.effort==="MAXIMUM"?1e4:0,CONSERVE_EFFORT:e.effort==="CONSERVE"?1e4:0};return pe.baselines.legality.map(a=>{const o=Object.entries(pe.coefficients.legality).find(([r])=>r===a.id)?.[1],i=o?Object.entries(o).map(([r,s])=>{const c=t[r];if(c===void 0)throw new Error("UNKNOWN_LEGALITY_FEATURE");return{coefficientBp:s,featureBp:c}}):[];return{id:a.id,baseWeight:a.baseWeight,allowed:!0,interceptBp:0,terms:i}})}function e_(n){G(n);const e=zh.parse(n),t={DEFENCE:(e.defenceRating-50)*200,TIMING:(e.timingRating-50)*200,POWER:(e.powerRating-50)*200,AGGRESSION:(e.aggression-2)*1e4,MOVEMENT:e.effectiveMovementBp};return pe.baselines.contact[e.phase].map(a=>{const o=Object.entries(pe.coefficients.contact).find(([r])=>r===a.id)?.[1];if(!o)throw new Error("MISSING_CONTACT_COEFFICIENT");const i=Object.entries(o).map(([r,s])=>{const c=t[r];if(c===void 0)throw new Error("UNKNOWN_CONTACT_FEATURE");return{coefficientBp:s,featureBp:c}});return{id:a.id,baseWeight:a.baseWeight,allowed:!0,interceptBp:0,terms:i}})}class ms extends Error{code;constructor(e,t){super(`${e}: ${t}`),this.code=e,this.name="ResolutionValidationError"}}const Sn=(n,e,t)=>{if(!n)throw new ms(e,t)};function gs(n,e){const t=Aa.safeParse(n),a=Go.safeParse(e);if(!t.success||!a.success)throw new ms("INVALID_STRUCTURE","Context or resolution failed strict schema validation");const o=t.data,i=a.data,r=i.extras,s=i.dismissal;Sn(o.deliveryIndex>=o.legalBalls,"INVALID_CONTEXT","Global delivery attempt index precedes legal-ball count"),Sn(o.rulesId==="LC_RED5_01"?o.allocatedBalls===null&&o.inningsIndex<=3:o.allocatedBalls===(o.rulesId==="LC_T20_01"?120:300)&&o.inningsIndex<=1,"INVALID_CONTEXT","Base profile allocation or innings index invalid");const c=[o.strikerId,o.nonStrikerId,o.bowlerId,o.keeperId,...o.outfieldIds];Sn(new Set(c).size===c.length&&o.battingTeamId!==o.bowlingTeamId,"INVALID_CONTEXT","IDs must be distinct"),Sn(o.endsBefore[o.strikerEnd==="NORTH"?"north":"south"]===o.strikerId&&o.endsBefore[o.strikerEnd==="NORTH"?"south":"north"]===o.nonStrikerId,"INVALID_CONTEXT","Starting ends must identify both batters"),Sn((o.allocatedBalls===null||o.legalBalls<o.allocatedBalls)&&(o.targetToWin===null||o.runs<o.targetToWin),"INVALID_CONTEXT","Innings already ended"),Sn(o.rulesId!=="LC_RED5_01"||!o.freeHitPending,"INVALID_CONTEXT","Red-ball profile has no free hit"),Sn(r.penalties===0,"UNSUPPORTED_PENALTY","Penalty scoring requires a later administrative contract");const u=i.batRuns+r.wides+r.noBalls+r.byes+r.legByes;if(Sn(Number.isSafeInteger(u)&&Number.isSafeInteger(o.runs+u)&&Number.isSafeInteger(o.legalBalls+1)&&Number.isSafeInteger(o.deliveryIndex+1)&&Number.isSafeInteger(o.ballAgeLegalBalls+1),"UNSAFE_TOTAL","Counter arithmetic must remain safe"),Sn(!(r.byes>0&&r.legByes>0)&&!(i.batRuns>0&&(r.byes>0||r.legByes>0)),"INVALID_EXTRAS","Conflicting run channels"),Sn(!(i.batContact&&(r.byes>0||r.legByes>0))&&(r.legByes===0||i.attemptedStroke)&&(i.batRuns===0||i.batContact),"INVALID_EXTRAS","Contact/stroke evidence inconsistent"),i.legality==="LEGAL"&&Sn(r.wides===0&&r.noBalls===0,"INVALID_EXTRAS","Legal ball cannot charge wide/no-ball"),i.legality==="NO_BALL"&&Sn(r.noBalls===1&&r.wides===0,"INVALID_EXTRAS","No-ball overrides wide and carries one automatic run"),i.legality==="WIDE"&&Sn(r.wides>=1&&r.noBalls===0&&r.byes===0&&r.legByes===0&&i.batRuns===0&&!i.batContact,"INVALID_EXTRAS","Wide channel is exclusive"),i.legality==="DEAD"&&Sn(u===0&&s===null&&i.completedRuns===0&&i.attemptedRuns===0&&!i.batContact&&i.boundary==="NONE"&&i.fieldOutcome==="NONE","INVALID_EXTRAS","Early dead ball cannot score or dismiss"),i.boundary!=="NONE"?Sn(i.completedRuns===0&&i.attemptedRuns===0&&s===null&&u-r.noBalls-(i.legality==="WIDE"?1:0)===(i.boundary==="FOUR"?4:6)&&(i.boundary!=="SIX"||i.batRuns===6&&i.batContact),"INVALID_BOUNDARY","Boundary allowance incompatible with running/dismissal"):Sn(i.completedRuns===i.batRuns+r.byes+r.legByes+Math.max(0,r.wides-1),"INVALID_RUNNING","Completed runs exclude automatic penalties"),Sn(i.attemptedRuns===i.completedRuns+(s?.kind==="RUN_OUT"?1:0),"INVALID_RUNNING","Only the failed run-out attempt remains uncompleted"),i.stage==="IMMEDIATE_PENALTY")Sn((i.legality==="WIDE"||i.legality==="NO_BALL")&&o.targetToWin!==null&&o.runs+1>=o.targetToWin&&u===1&&i.batRuns===0&&i.completedRuns===0&&i.attemptedRuns===0&&s===null&&i.boundary==="NONE"&&!i.batContact&&i.trajectory===null&&i.shotSector===null&&i.fieldOutcome==="NONE","INVALID_IMMEDIATE_PENALTY","Winning automatic extra must terminate before contact or dismissal");else if((i.legality==="WIDE"||i.legality==="NO_BALL")&&o.targetToWin!==null&&o.runs+1>=o.targetToWin)throw new ms("INVALID_IMMEDIATE_PENALTY","Immediate winning extra requires truncated resolution");Sn(!(o.targetToWin!==null&&o.runs+u>=o.targetToWin&&s!==null),"INVALID_DISMISSAL","Result achieved before a later dismissal"),Sn(!(o.targetToWin!==null&&i.boundary==="NONE"&&o.runs+u>o.targetToWin),"INVALID_RUNNING","Running cannot continue past the winning run"),s&&(Sn(s.playerId===o.strikerId||s.playerId===o.nonStrikerId,"INVALID_DISMISSAL","Dismissed player must be active"),Sn(s.kind==="RUN_OUT"||s.playerId===o.strikerId,"INVALID_DISMISSAL","Only a run-out may dismiss the non-striker"),Sn(!(i.legality==="NO_BALL"||o.freeHitPending)||s.kind==="RUN_OUT","INVALID_DISMISSAL","No-ball/free-hit mask"),Sn(i.legality!=="WIDE"||["RUN_OUT","STUMPED","HIT_WICKET"].includes(s.kind),"INVALID_DISMISSAL","Wide dismissal mask"),Sn(i.legality!=="DEAD","INVALID_DISMISSAL","Dead-ball dismissal"),Sn(s.fielderId===null||[o.bowlerId,o.keeperId,...o.outfieldIds].includes(s.fielderId),"INVALID_DISMISSAL","Unknown fielder"),s.kind==="CAUGHT"&&Sn(i.batContact&&["AERIAL","EDGE"].includes(i.trajectory??"")&&s.fielderId!==null&&i.fieldOutcome==="CATCH"&&i.batRuns===0,"INVALID_DISMISSAL","Catch requires bat contact, fielder and zero bat runs"),s.kind==="STUMPED"&&Sn(s.fielderId===o.keeperId&&!i.batContact&&i.attemptedRuns===0,"INVALID_DISMISSAL","Stumping requires keeper and no run attempted"),s.kind==="RUN_OUT"&&Sn(s.fielderId!==null&&i.fieldOutcome==="RUN_OUT","INVALID_DISMISSAL","Run-out needs a fielder and outcome"),["BOWLED","LBW","HIT_WICKET"].includes(s.kind)&&Sn(s.fielderId===null,"INVALID_DISMISSAL","Unassisted dismissal"),s.kind==="LBW"&&Sn(!i.batContact,"INVALID_DISMISSAL","LBW cannot follow bat contact"),s.kind!=="RUN_OUT"&&Sn(s.wicketEnd===o.strikerEnd&&i.completedRuns===0,"INVALID_DISMISSAL","Supported non-run-out dismissal is at striker end without completed runs")),Sn(i.fieldOutcome!=="CATCH"||s?.kind==="CAUGHT","INVALID_DISMISSAL","Ineligible catch must be a stop, not a credited catch"),Sn(i.fieldOutcome!=="RUN_OUT"||s?.kind==="RUN_OUT","INVALID_DISMISSAL","Run-out outcome requires a dismissal");const h=[i.endsAfter.north,i.endsAfter.south].filter(p=>p!==null);if(s)Sn(h.length===1&&h[0]===(s.playerId===o.strikerId?o.nonStrikerId:o.strikerId),"INVALID_ENDS","Exactly the surviving batter occupies an end");else{const p=i.completedRuns%2===1;Sn(i.endsAfter.north===o.endsBefore[p?"south":"north"]&&i.endsAfter.south===o.endsBefore[p?"north":"south"],"INVALID_ENDS","Physical running determines ends")}return s&&s.kind!=="RUN_OUT"&&Sn(i.endsAfter[o.strikerEnd==="NORTH"?"north":"south"]===null,"INVALID_ENDS","Incoming batter belongs at dismissed striker end"),{context:o,resolution:i}}class t_ extends Error{code;constructor(e,t){super(`${e}: ${t}`),this.code=e,this.name="ScoringInvariantError"}}function In(n,e,t){if(!n)throw new t_(e,t)}function Hn(...n){let e=0;for(const t of n)In(Number.isSafeInteger(t)&&t>=0,"UNSAFE_COUNTER","Counter is not a safe non-negative integer"),e+=t,In(Number.isSafeInteger(e),"UNSAFE_COUNTER","Counter overflow");return e}function ei(n,e){const{context:t,resolution:a}=gs(n,e);return Wo.parse({type:"DELIVERY_RECORDED",inningsIndex:t.inningsIndex,deliveryIndex:t.deliveryIndex,strikerId:t.strikerId,nonStrikerId:t.nonStrikerId,bowlerId:t.bowlerId,legality:a.legality,legalBall:a.legality==="LEGAL",countsAsBallFaced:a.legality==="LEGAL"||a.legality==="NO_BALL",batRuns:a.batRuns,extras:a.extras,completedRuns:a.completedRuns,boundary:a.boundary,dismissal:a.dismissal?{...a.dismissal,creditedBowlerId:a.dismissal.kind==="RUN_OUT"?null:t.bowlerId}:null,endsAfter:a.endsAfter,shotSector:a.shotSector,trajectory:a.trajectory,executedLength:a.executedLength,fieldOutcome:a.fieldOutcome,elapsedSeconds:a.elapsedSeconds,freeHitNext:t.rulesId!=="LC_RED5_01"&&(a.legality==="NO_BALL"||t.freeHitPending&&a.legality!=="LEGAL")})}function a_(n,e){const t=Aa.parse(n),a=Wo.parse(e);for(const s of["inningsIndex","deliveryIndex","strikerId","nonStrikerId","bowlerId"])In(a[s]===t[s],"EVENT_CONTEXT_MISMATCH",s);In(a.legalBall===(a.legality==="LEGAL"),"INVALID_EVENT_FLAGS","legalBall"),In(a.countsAsBallFaced===(a.legality==="LEGAL"||a.legality==="NO_BALL"),"INVALID_EVENT_FLAGS","countsAsBallFaced");const o=t.rulesId!=="LC_RED5_01"&&(a.legality==="NO_BALL"||t.freeHitPending&&a.legality!=="LEGAL");In(a.freeHitNext===o,"INVALID_EVENT_FLAGS","freeHitNext"),a.dismissal&&In(a.dismissal.creditedBowlerId===(a.dismissal.kind==="RUN_OUT"?null:t.bowlerId),"INVALID_WICKET_CREDIT","Dismissal credit differs from its kind");const{creditedBowlerId:i,...r}=a.dismissal??{creditedBowlerId:null};return gs(t,{stage:(a.legality==="WIDE"||a.legality==="NO_BALL")&&t.targetToWin!==null&&t.runs+1>=t.targetToWin?"IMMEDIATE_PENALTY":"DELIVERY",legality:a.legality,batRuns:a.batRuns,extras:a.extras,completedRuns:a.completedRuns,attemptedRuns:a.completedRuns+(a.dismissal?.kind==="RUN_OUT"?1:0),boundary:a.boundary,dismissal:a.dismissal?r:null,endsAfter:a.endsAfter,batContact:a.batRuns>0||a.dismissal?.kind==="CAUGHT",attemptedStroke:!0,shotSector:a.shotSector,trajectory:a.trajectory,executedLength:a.executedLength,fieldOutcome:a.fieldOutcome,elapsedSeconds:a.elapsedSeconds}),{context:t,event:a}}function o_(n,e){const{context:t,event:a}=a_(n,e),o=a.extras,i={teamRuns:Hn(a.batRuns,o.wides,o.noBalls,o.byes,o.legByes,o.penalties),batterRuns:a.batRuns,bowlerRuns:Hn(a.batRuns,o.wides,o.noBalls),legalBalls:Number(a.legalBall),ballsFaced:Number(a.countsAsBallFaced),wickets:+(a.dismissal!==null),bowlerWickets:+(a.dismissal?.creditedBowlerId!==null&&a.dismissal!==null),deliveryAttempts:1},r={runs:Hn(t.runs,i.teamRuns),wickets:Hn(t.wickets,i.wickets),legalBalls:Hn(t.legalBalls,i.legalBalls),ballAgeLegalBalls:Hn(t.ballAgeLegalBalls,i.legalBalls)},s=a.legalBall&&r.legalBalls%6===0,c=s?t.strikerEnd==="NORTH"?"SOUTH":"NORTH":t.strikerEnd,u=t.targetToWin!==null&&r.runs>=t.targetToWin,h=u||r.wickets===10||t.allocatedBalls!==null&&r.legalBalls>=t.allocatedBalls;let p=null;u?p={kind:"WIN",winnerTeamId:t.battingTeamId,marginType:"WICKETS",marginRuns:null,marginWickets:10-r.wickets,completionReason:"TARGET_REACHED"}:h&&t.targetToWin!==null&&(r.runs===t.targetToWin-1?p={kind:"TIE",winnerTeamId:null,marginType:null,marginRuns:null,marginWickets:null,completionReason:"CHASE_COMPLETE_LEVEL"}:p={kind:"WIN",winnerTeamId:t.bowlingTeamId,marginType:"RUNS",marginRuns:t.targetToWin-1-r.runs,marginWickets:null,completionReason:"CHASE_COMPLETE_SHORT"});const E=h||!a.dismissal?null:a.endsAfter.north===null?"NORTH":"SOUTH",b=h?null:a.endsAfter[c==="NORTH"?"north":"south"],w=p?"NONE":h?"START_NEXT_INNINGS":E?"SELECT_BATTER":s?"SELECT_BOWLER":"ADVANCE",v=["DELIVERY_RECORDED"];return s&&v.push("OVER_COMPLETED"),h&&v.push("INNINGS_COMPLETED"),p&&v.push("MATCH_COMPLETED"),dl.parse({event:a,delta:i,totals:r,strikerEndAfter:c,nextStrikerId:b,requiredBatterEnd:E,freeHitPending:a.freeHitNext,overCompleted:s,inningsComplete:h,result:p,events:v,nextAction:w})}function le(n){const e=xh.parse(n),t=e.innings,a=Object.keys(e.batting),o=Object.keys(e.bowling);In(t.battingTeamId!==t.bowlingTeamId,"INVALID_LEDGER","Teams must differ"),In(t.battingOrder.length===11&&new Set(t.battingOrder).size===11&&a.length===11&&t.battingOrder.every(s=>Object.hasOwn(e.batting,s)),"INVALID_LEDGER","Batting order must identify eleven ledger players"),In(o.length===11&&[e.keeperId,...e.outfieldIds,...t.bowlerId?[t.bowlerId]:[]].every(s=>Object.hasOwn(e.bowling,s)),"INVALID_LEDGER","Bowling references missing"),In(new Set([e.keeperId,...e.outfieldIds]).size===10&&!o.some(s=>Object.hasOwn(e.batting,s)),"INVALID_LEDGER","Field identities overlap"),In(new Set(t.dismissed).size===t.dismissed.length&&t.dismissed.length===t.wickets&&t.dismissed.every(s=>e.batting[s]?.dismissed),"INVALID_LEDGER","Dismissed identities mismatch"),In(a.filter(s=>e.batting[s].dismissed).length===t.wickets,"INVALID_LEDGER","Dismissal flags mismatch"),In(t.complete||!(t.wickets===10||t.allocatedBalls!==null&&t.legalBalls>=t.allocatedBalls||t.targetToWin!==null&&t.runs>=t.targetToWin),"INVALID_LEDGER","Terminal innings must be marked complete");const i=e.rulesId==="LC_T20_01"?24:e.rulesId==="LC_ODI_01"?60:null;In(i===null||Object.values(e.bowling).every(s=>s.legalBalls<=i),"BOWLER_QUOTA","Stored quota exceeded");const r=[t.northBatterId,t.southBatterId].filter(s=>s!==null);In(new Set(r).size===r.length&&r.every(s=>Object.hasOwn(e.batting,s)&&!e.batting[s].dismissed),"INVALID_LEDGER","Invalid end occupancy"),In(Hn(...Object.values(e.batting).map(s=>s.runs),...Object.values(t.extras))===t.runs,"SCORE_RECONCILIATION","Bat runs plus extras must equal innings runs"),In(Hn(...Object.values(e.bowling).map(s=>s.legalBalls))===t.legalBalls,"BALL_RECONCILIATION","Bowler legal-ball counts must reconcile"),In(Hn(...Object.values(e.bowling).map(s=>s.runsConceded))===t.runs-t.extras.byes-t.extras.legByes-t.extras.penalties,"SCORE_RECONCILIATION","Bowler conceded runs mismatch"),In(Object.keys(e.dismissals).length===t.wickets&&t.dismissed.every(s=>e.dismissals[s]?.playerId===s),"WICKET_RECONCILIATION","Dismissal records missing");for(const s of o)In(e.bowling[s].wickets===Object.values(e.dismissals).filter(c=>c.creditedBowlerId===s).length,"WICKET_RECONCILIATION","Bowler credits must match dismissal records");for(const s of Object.values(e.dismissals))In((s.kind==="RUN_OUT"?s.creditedBowlerId===null:s.creditedBowlerId!==null&&Object.hasOwn(e.bowling,s.creditedBowlerId))&&(s.fielderId===null||Object.hasOwn(e.bowling,s.fielderId)),"WICKET_RECONCILIATION","Invalid historical dismissal credit");In(Hn(...Object.values(e.batting).map(s=>s.ballsFaced))===Hn(t.legalBalls,t.extras.noBalls),"BALL_RECONCILIATION","Batter balls faced must equal legal deliveries plus delivered no-balls"),In(Object.keys(t.bowlerLegalBalls).length===o.length&&o.every(s=>t.bowlerLegalBalls[s]===e.bowling[s].legalBalls),"BALL_RECONCILIATION","Bowler quota map mismatch"),In(t.deliveryAttempts>=t.legalBalls&&e.nextDeliveryIndex>=t.deliveryAttempts&&t.ballAgeLegalBalls<=t.legalBalls,"INVALID_LEDGER","Delivery/ball-age counters inconsistent"),In(t.bowlerId!==null||e.currentOverRuns===0,"INVALID_LEDGER","No active bowler for unfinished over runs"),t.bowlerId&&In(t.bowlerId!==e.keeperId&&!e.outfieldIds.includes(t.bowlerId),"INVALID_LEDGER","Bowler cannot occupy keeper/outfield slot"),t.previousOverBowlerId!==null&&In(Object.hasOwn(e.bowling,t.previousOverBowlerId),"INVALID_LEDGER","Previous bowler absent");for(const s of Object.values(e.batting))In(Hn(s.fours*4,s.sixes*6)<=s.runs,"INVALID_LEDGER","Boundary counters exceed bat runs");for(const s of Object.values(e.bowling))In(s.maidens<=Math.floor(s.legalBalls/6),"INVALID_LEDGER","Maiden counter exceeds completed overs");return In(e.rulesId==="LC_RED5_01"?t.allocatedBalls===null&&t.index<=3:t.allocatedBalls===(e.rulesId==="LC_T20_01"?120:300)&&t.index<=1,"INVALID_LEDGER","Unsupported profile allocation/index"),In(e.rulesId!=="LC_RED5_01"||!t.freeHitPending,"INVALID_LEDGER","Red-ball free hit"),e}function Fe(n){const e=le(n),t=e.innings;In(!t.complete,"INNINGS_COMPLETE","No more delivery after completion"),In(t.northBatterId!==null&&t.southBatterId!==null,"BATTER_REQUIRED","Both ends need selected batters"),In(t.bowlerId!==null,"BOWLER_REQUIRED","Select a bowler");const a=e.rulesId==="LC_T20_01"?24:e.rulesId==="LC_ODI_01"?60:null;return In(a===null||e.bowling[t.bowlerId].legalBalls<a,"BOWLER_QUOTA","Active bowler exhausted"),Aa.parse({rulesId:e.rulesId,inningsIndex:t.index,deliveryIndex:e.nextDeliveryIndex,battingTeamId:t.battingTeamId,bowlingTeamId:t.bowlingTeamId,strikerId:t.strikerEnd==="NORTH"?t.northBatterId:t.southBatterId,nonStrikerId:t.strikerEnd==="NORTH"?t.southBatterId:t.northBatterId,bowlerId:t.bowlerId,keeperId:e.keeperId,outfieldIds:e.outfieldIds,endsBefore:{north:t.northBatterId,south:t.southBatterId},strikerEnd:t.strikerEnd,runs:t.runs,wickets:t.wickets,legalBalls:t.legalBalls,allocatedBalls:t.allocatedBalls,targetToWin:t.targetToWin,freeHitPending:t.freeHitPending,ballAgeLegalBalls:t.ballAgeLegalBalls})}function ti(n,e){const t=le(n),a=Fe(t),o=o_(a,e),i=o.event,r=t.innings,s=t.rulesId==="LC_T20_01"?24:t.rulesId==="LC_ODI_01"?60:null;In(s===null||t.bowling[i.bowlerId].legalBalls+o.delta.legalBalls<=s,"BOWLER_QUOTA","Bowler quota exceeded"),In(r.previousOverBowlerId!==i.bowlerId,"CONSECUTIVE_OVERS","Previous over bowler cannot bowl this over");const c=t.batting[i.strikerId],u=t.bowling[i.bowlerId];c.runs=Hn(c.runs,o.delta.batterRuns),c.ballsFaced=Hn(c.ballsFaced,o.delta.ballsFaced),i.boundary==="FOUR"&&i.batRuns===4&&(c.fours=Hn(c.fours,1)),i.boundary==="SIX"&&i.batRuns===6&&(c.sixes=Hn(c.sixes,1)),i.dismissal&&(t.batting[i.dismissal.playerId].dismissed=!0,t.dismissals[i.dismissal.playerId]=i.dismissal,r.dismissed.push(i.dismissal.playerId)),u.runsConceded=Hn(u.runsConceded,o.delta.bowlerRuns),u.legalBalls=Hn(u.legalBalls,o.delta.legalBalls),u.wickets=Hn(u.wickets,o.delta.bowlerWickets),t.currentOverRuns=Hn(t.currentOverRuns,o.delta.bowlerRuns),o.overCompleted&&(t.currentOverRuns===0&&(u.maidens=Hn(u.maidens,1)),t.currentOverRuns=0,r.previousOverBowlerId=i.bowlerId,r.bowlerId=null),r.runs=o.totals.runs,r.wickets=o.totals.wickets,r.legalBalls=o.totals.legalBalls,r.ballAgeLegalBalls=o.totals.ballAgeLegalBalls,r.deliveryAttempts=Hn(r.deliveryAttempts,1),r.strikerEnd=o.strikerEndAfter,r.northBatterId=i.endsAfter.north,r.southBatterId=i.endsAfter.south,r.freeHitPending=o.freeHitPending,r.complete=o.inningsComplete;for(const h of["wides","noBalls","byes","legByes","penalties"])r.extras[h]=Hn(r.extras[h],i.extras[h]);return r.bowlerLegalBalls[i.bowlerId]=u.legalBalls,t.nextDeliveryIndex=Hn(t.nextDeliveryIndex,1),{ledger:le(t),observation:o}}function lo(n,e){const t=le(n),a=t.innings;return In(!a.complete,"INNINGS_COMPLETE","Cannot select after completion"),In(Object.hasOwn(t.batting,e)&&!t.batting[e].dismissed&&![a.northBatterId,a.southBatterId].includes(e),"ILLEGAL_BATTER","Player must be available and not already at an end"),In(a.northBatterId===null!=(a.southBatterId===null),"ILLEGAL_SELECTION","Exactly one replacement end must be empty"),a.northBatterId===null?a.northBatterId=e:a.southBatterId=e,le(t)}function ai(n,e,t){const a=le(n),o=a.innings;In(!o.complete,"INNINGS_COMPLETE","Cannot select after completion"),In(o.northBatterId!==null&&o.southBatterId!==null,"BATTER_REQUIRED","Batter decision has priority"),In(o.bowlerId===null&&o.legalBalls%6===0,"ILLEGAL_SELECTION","Bowler selection only at an over boundary"),In(Object.hasOwn(a.bowling,e)&&e!==a.keeperId&&e!==o.previousOverBowlerId,"ILLEGAL_BOWLER","Unknown, keeping or consecutive bowler");const i=a.rulesId==="LC_T20_01"?24:a.rulesId==="LC_ODI_01"?60:null;return In(i===null||a.bowling[e].legalBalls<i,"BOWLER_QUOTA","Quota exhausted"),o.bowlerId=e,a.outfieldIds=[...t],le(a)}const i_=Object.freeze({EXECUTED_LENGTH:Object.freeze({stageName:"length",drawIndex:0}),LEGALITY:Object.freeze({stageName:"legality",drawIndex:0}),CONTACT:Object.freeze({stageName:"contact",drawIndex:0}),SECTOR:Object.freeze({stageName:"sector",drawIndex:0}),IMMEDIATE_DISMISSAL:Object.freeze({stageName:"dismissal",drawIndex:0}),STUMPING:Object.freeze({stageName:"dismissal",drawIndex:1}),FIELD_CHANCE:Object.freeze({stageName:"fielding",drawIndex:0}),FIELD_CONVERSION:Object.freeze({stageName:"fielding",drawIndex:1}),RUNS:Object.freeze({stageName:"running",drawIndex:0}),RUN_OUT:Object.freeze({stageName:"running",drawIndex:1}),RUN_OUT_END:Object.freeze({stageName:"running",drawIndex:2})}),mu=uu(),r_=Nt(jn),s_=["0","1","2","3","4","6"],oi=["YORKER","FULL","GOOD","SHORT"],gu=10000n;function Iu(n){if(n&&typeof n=="object"&&!Object.isFrozen(n)){for(const e of Object.values(n))Iu(e);Object.freeze(n)}return n}function c_(n,e,t){return n<e?e:n>t?t:n}function ii(n,e){return Number(co(BigInt(n)*BigInt(e),gu))}function ot(n){return(n-50)*200}function Yn(n,e,t=0,a=[],o=!0){return{id:n,baseWeight:e,interceptBp:t,terms:[...a],allowed:o}}function ri(n,e){return n==="RED_BALL"?"RED_BALL":n==="T20"?e<36?"T20_EARLY":e<90?"T20_MIDDLE":"T20_LATE":e<60?"ODI_EARLY":e<240?"ODI_MIDDLE":"ODI_LATE"}function si(n){const e=yt.find(t=>t.rulesId===n);if(!e)throw new Error("UNSUPPORTED_GENERATOR_RULES");return te(ce(e))}function l_(n){G(n);const e=Qh.parse(n);if(e.stagePackHash!==Zn||te(ce(Tn))!==Zn||e.modelHash!==Cn||e.lutHash!==tt||e.stagePackId!==ml||e.generatorVersion!==jo||e.probabilityVersion!==se||e.modelId!==Be||e.lutVersion!==ze||e.randomVersion!==jn)throw new Error("UNSUPPORTED_GENERATOR_PACK_OR_VERSION");if(e.rulesHash!==si(e.context.rulesId))throw new Error("UNSUPPORTED_RULES_HASH");const t=e.context.rulesId==="LC_T20_01"?"T20":e.context.rulesId==="LC_ODI_01"?"ODI":"RED_BALL";if(e.format!==t||e.phase!==ri(t,e.context.legalBalls))throw new Error("INCONSISTENT_FORMAT_OR_PHASE");if(e.attemptOrdinal!==e.context.deliveryIndex)throw new Error("ATTEMPT_ORDINAL_MISMATCH");if(`${e.matchId}:${e.context.inningsIndex}`.length>128)throw new Error("RANDOM_ENTITY_ID_TOO_LONG");if(e.context.bowlerId===e.context.strikerId||e.context.bowlerId===e.context.nonStrikerId||e.context.strikerId===e.context.nonStrikerId||e.context.endsBefore[e.context.strikerEnd==="NORTH"?"north":"south"]!==e.context.strikerId||e.context.endsBefore[e.context.strikerEnd==="NORTH"?"south":"north"]!==e.context.nonStrikerId)throw new Error("INCONSISTENT_BATTER_ENDS");if(e.context.runs>=(e.context.targetToWin??Number.MAX_SAFE_INTEGER)||e.context.allocatedBalls!==(t==="T20"?120:t==="ODI"?300:null)||e.context.allocatedBalls!==null&&e.context.legalBalls>=e.context.allocatedBalls||t==="RED_BALL"&&e.context.freeHitPending||e.context.wickets>=10||e.attemptOrdinal<e.context.legalBalls)throw new Error("INNINGS_NOT_READY_FOR_GENERATOR");const a=e.field.slots.map(o=>o.playerId);if(new Set(a).size!==9||[...a].sort().join("\0")!==[...e.context.outfieldIds].sort().join("\0")||new Set([e.context.strikerId,e.context.nonStrikerId,e.context.bowlerId,e.context.keeperId,...a]).size!==13||e.batting.shotSectorWeights.every(o=>o===0))throw new Error("INVALID_GENERATOR_FIELD_OR_SECTORS");return e}function d_(n){const a=((!["FAST","MEDIUM"].includes(n.bowling.bowlingStyle)?n.conditions.turnBp:n.conditions.seamBp)-5e3)*2;return c_(ot(n.bowling.movementRating)+ii(2500,a)-ii(2500,n.bowling.fatigueBp),-1e4,1e4)}function u_(n){const e=n.bowling.intendedLength,t=oi.indexOf(e),a=new Map([[e,Tn.length.intended]]),o=[oi[t-1],oi[t+1]].filter(c=>c!==void 0),i=Tn.length.neighboursTotal/o.length;for(const c of o)a.set(c,(a.get(c)??0)+i);const r=t<2?"FULL_TOSS":"FULL";a.set(r,(a.get(r)??0)+Tn.length.gross);const s=[{coefficientBp:Tn.length.intendedControlBp,featureBp:ot(n.bowling.controlRating)},{coefficientBp:Tn.length.intendedFatigueBp,featureBp:n.bowling.fatigueBp}];return[...oi,"FULL_TOSS"].filter(c=>(a.get(c)??0)>0).map(c=>Yn(c,a.get(c),0,c===e?s:[]))}function m_(n,e,t){const a=e_({phase:n.phase,defenceRating:n.batting.defenceRating,timingRating:n.batting.timingRating,powerRating:n.batting.powerRating,effectiveMovementBp:d_(n),aggression:n.batting.aggression}),o=ot(["FAST","MEDIUM"].includes(n.bowling.bowlingStyle)?n.batting.vsPaceRating:n.batting.vsSpinRating);return a.map(i=>{const r=[];function s(c){r.push({coefficientBp:c,featureBp:1e4})}return e==="YORKER"&&i.id==="MISS"&&s(2e3),e==="YORKER"&&i.id==="AERIAL"&&s(-1e3),e==="FULL_TOSS"&&i.id==="AERIAL"&&s(5e3),e==="FULL_TOSS"&&i.id==="GROUND"&&s(2e3),e==="SHORT"&&(i.id==="AERIAL"||i.id==="EDGE")&&s(1500),(i.id==="MISS"||i.id==="EDGE")&&r.push({coefficientBp:-2e3,featureBp:o}),i.id==="GROUND"&&r.push({coefficientBp:2e3,featureBp:o}),{...i,allowed:!(t&&i.id==="HIT_WICKET"),terms:[...i.terms,...r]}})}function g_(n){return n.batting.shotSectorWeights.map((t,a)=>{const i=(n.bowling.line==="OFF"?a<=2:n.bowling.line==="STUMPS"?a===3||a===4:a>=5)?Number(co(BigInt(t)*BigInt(Tn.sectorLineMultiplierBp),gu)):t;return Yn(`SECTOR_${a}`,i)})}function I_(n,e,t){const a=n.field.slots.map(o=>{const i=(o.sector-e+8)%8,r=i===0?1e4:i===1||i===7?Tn.coverage.neighbourBp:0,s=t==="GROUND"?Tn.coverage.ground[o.depth]:Tn.coverage.aerial[o.depth],c=t==="EDGE"?o.role==="SLIP"?1e4:o.role==="GULLY"?6e3:1e3:ii(s,r);return{playerId:o.playerId,coverageBp:c,catchingRating:o.catchingRating,throwingRating:o.throwingRating,role:o.role}});return t==="EDGE"&&a.push({playerId:n.context.keeperId,coverageBp:1e4,catchingRating:n.field.keeper.catchingRating,throwingRating:n.field.keeper.throwingRating,role:"KEEPER"}),a.sort((o,i)=>i.coverageBp-o.coverageBp||(o.playerId<i.playerId?-1:o.playerId>i.playerId?1:0)),a[0]}function p_(n,e,t){const a=e==="MISS",o=a?Tn.bowled:Tn.lbw,i=!t&&(a||n.bowling.line!=="LEG");return[Yn(a?"BOWLED":"LBW",1,o.interceptBp,[{coefficientBp:o.controlBp,featureBp:ot(n.bowling.controlRating)},{coefficientBp:o.defenceBp,featureBp:ot(n.batting.defenceRating)},...a&&n.bowling.line==="STUMPS"?[{coefficientBp:Tn.bowled.stumpsBp,featureBp:1e4}]:[]],i),Yn("NONE",1)]}function h_(n,e,t){const a=Tn.runs[e],o=ot(n.batting.timingRating),i=ot(n.batting.powerRating),r=ot(n.batting.rotationRating);return s_.map((s,c)=>{const u=[];s==="0"&&u.push({coefficientBp:5e3,featureBp:t},{coefficientBp:-3e3,featureBp:r}),s==="1"&&n.batting.intent!=="NORMAL"&&u.push({coefficientBp:n.batting.intent==="ROTATE"?3500:-5e3,featureBp:1e4}),(s==="4"||s==="6")&&u.push({coefficientBp:4e3,featureBp:o},{coefficientBp:5e3,featureBp:i},{coefficientBp:-7e3,featureBp:t});const h=Number(s),p=n.context.targetToWin===null?null:n.context.targetToWin-n.context.runs;return Yn(s,a[c],0,u,p===null||h<=p||h>=4)})}function f_(n,e,t,a){const o=n.context.targetToWin===null?null:n.context.targetToWin-n.context.runs-a,i=o===null||t-1<o;return[Yn("RUN_OUT",1,Tn.running.interceptBp,[{coefficientBp:Tn.running.throwingBp,featureBp:ot(e.throwingRating)},{coefficientBp:Tn.running.coverageBp,featureBp:e.coverageBp},{coefficientBp:Tn.running.rotateBp,featureBp:n.batting.intent==="ROTATE"?1e4:0}],i),Yn("SAFE",1)]}function ci(n){const e=l_(n),t=[],a=new Set;function o(R,_){const U=i_[R],M={seed:e.seed,domain:"MATCH_DELIVERY",entityId:`${e.matchId}:${e.context.inningsIndex}`,eventOrdinal:e.attemptOrdinal,stageName:U.stageName,drawIndex:U.drawIndex},H=JSON.stringify(M);if(a.has(H))throw new Error("DUPLICATE_DELIVERY_DRAW_ADDRESS");a.add(H);const an=mu.normalise({probabilityVersion:se,modelId:Be,modelHash:Cn,lutVersion:ze,lutHash:tt,categories:_}),y=r_.uint32(M),L=du(an.categories,y);return t.push({stageName:U.stageName,address:M,draw:y,selectedCategoryId:L.id,categories:an.categories}),L.id}const i=o("EXECUTED_LENGTH",u_(e)),r=o("LEGALITY",n_({controlRating:e.bowling.controlRating,fatigueBp:e.bowling.fatigueBp,line:e.bowling.line,effort:e.bowling.effort})),s=e.context,c={wides:0,noBalls:0,byes:0,legByes:0,penalties:0},u={stage:"DELIVERY",legality:r,batRuns:0,extras:c,completedRuns:0,attemptedRuns:0,boundary:"NONE",dismissal:null,endsAfter:{...s.endsBefore},batContact:!1,attemptedStroke:e.batting.attemptedStroke,shotSector:null,trajectory:null,executedLength:i,fieldOutcome:"NONE",elapsedSeconds:Tn.elapsedSeconds};function h(R){const _=gs(s,R).resolution;return Iu(ef.parse({kind:"GENERATED_DELIVERY",generatorVersion:jo,modelHash:Cn,stagePackHash:Zn,internalOnly:!0,trace:t,resolution:_}))}if(r==="WIDE"&&(c.wides=1),r==="NO_BALL"&&(c.noBalls=1),(r==="WIDE"||r==="NO_BALL")&&s.targetToWin!==null&&s.runs+1>=s.targetToWin)return h({...u,stage:"IMMEDIATE_PENALTY",batContact:!1,attemptedStroke:!1});const p=r==="NO_BALL"||s.freeHitPending,E=r==="WIDE"?"WIDE":o("CONTACT",m_(e,i,p));if(E==="HIT_WICKET")return u.dismissal={kind:"HIT_WICKET",playerId:s.strikerId,fielderId:null,wicketEnd:s.strikerEnd},u.endsAfter[s.strikerEnd==="NORTH"?"north":"south"]=null,h(u);if(E==="MISS"||E==="PAD"){const R=o("IMMEDIATE_DISMISSAL",p_(e,E,p));if(R!=="NONE")return u.dismissal={kind:R,playerId:s.strikerId,fielderId:null,wicketEnd:s.strikerEnd},u.endsAfter[s.strikerEnd==="NORTH"?"north":"south"]=null,h(u)}let b={playerId:s.keeperId,coverageBp:0,catchingRating:e.field.keeper.catchingRating,throwingRating:e.field.keeper.throwingRating};if(E==="GROUND"||E==="AERIAL"||E==="EDGE")if(u.batContact=!0,u.trajectory=E,u.shotSector=Number(o("SECTOR",g_(e)).split("_")[1]),b=I_(e,u.shotSector,E),E==="AERIAL"||E==="EDGE")if(!p&&b.coverageBp>0){const R=ii(Tn.catchOpportunityBp[E],b.coverageBp);if(o("FIELD_CHANCE",[Yn("CHANCE",R),Yn("NO_CHANCE",1e4-R)])==="CHANCE"){if(o("FIELD_CONVERSION",[Yn("CATCH",1,Tn.catchConversion.interceptBp,[{coefficientBp:Tn.catchConversion.catchingBp,featureBp:ot(b.catchingRating)}]),Yn("DROP",1)])==="CATCH")return u.fieldOutcome="CATCH",u.dismissal={kind:"CAUGHT",playerId:s.strikerId,fielderId:b.playerId,wicketEnd:s.strikerEnd},u.endsAfter[s.strikerEnd==="NORTH"?"north":"south"]=null,h(u);u.fieldOutcome="DROP"}else u.fieldOutcome=b.coverageBp>0?"STOP":"NONE"}else u.fieldOutcome=b.coverageBp>0?"STOP":"NONE";else u.fieldOutcome=b.coverageBp>0?"STOP":"NONE";const w=E==="WIDE",v=E==="MISS"||E==="PAD",T=w?[Yn("1",Tn.runs.WIDE[0]),Yn("2",Tn.runs.WIDE[1]),Yn("5",Tn.runs.WIDE[2])]:v?[Yn("0",Tn.runs.NONE[0]),Yn("1",Tn.runs.NONE[1],0,[],E==="MISS"||e.batting.attemptedStroke),Yn("4",Tn.runs.NONE[4],0,[],E==="MISS"||e.batting.attemptedStroke)]:h_(e,E,b.coverageBp),A=s.targetToWin===null?null:s.targetToWin-s.runs-(r==="WIDE"||r==="NO_BALL"?1:0),I=T.map(R=>{const _=Number(R.id),U=w?_===5:v?_===4:_>=4,M=w?_-1:_;return A!==null&&!U&&M>A?{...R,allowed:!1}:R}),f=Number(o("RUNS",I)),S=r==="WIDE"||r==="NO_BALL"?1:0;w?(c.wides=f,f===5?u.boundary="FOUR":u.completedRuns=f-1,u.attemptedStroke=!1):v?(E==="MISS"?c.byes=f:c.legByes=f,f===4?u.boundary="FOUR":u.completedRuns=f):(u.batRuns=f,f>=4?u.boundary=f===4?"FOUR":"SIX":u.completedRuns=f),u.boundary!=="NONE"&&u.fieldOutcome==="STOP"&&(u.fieldOutcome="NONE");const k=!["FAST","MEDIUM"].includes(e.bowling.bowlingStyle);if((E==="MISS"&&r==="LEGAL"||w)&&k&&!p&&e.batting.aggression>2&&u.completedRuns===0&&u.boundary==="NONE"){const R=mu.normalise({probabilityVersion:se,modelId:Be,modelHash:Cn,lutVersion:ze,lutHash:tt,categories:[Yn("SUCCESS",1,0,[{coefficientBp:1e4,featureBp:ot(e.field.keeper.keepingRating)}]),Yn("FAILURE",1)]}),U=BigInt(R.categories[0].mass)*BigInt(Tn.stumping.numerator)/BigInt(Tn.stumping.denominator),M=Number(co(U*1000000000n,4294967296n));if(o("STUMPING",[Yn("STUMPED",M),Yn("NONE",1e9-M)])==="STUMPED")return u.dismissal={kind:"STUMPED",playerId:s.strikerId,fielderId:s.keeperId,wicketEnd:s.strikerEnd},u.endsAfter[s.strikerEnd==="NORTH"?"north":"south"]=null,h(u)}if(u.completedRuns>0&&u.completedRuns<=3&&u.boundary==="NONE"&&o("RUN_OUT",f_(e,b,u.completedRuns,S))==="RUN_OUT"){const _=o("RUN_OUT_END",[Yn("NORTH",1),Yn("SOUTH",1)]),U=u.completedRuns,M=U-1,H=s.endsBefore.north,an=s.endsBefore.south,y=_==="NORTH"?U%2===0?H:an:U%2===0?an:H,L=y===H?an:H;return u.completedRuns=M,u.attemptedRuns=U,u.fieldOutcome="RUN_OUT",u.dismissal={kind:"RUN_OUT",playerId:y,fielderId:b.playerId,wicketEnd:_},u.endsAfter={north:_==="NORTH"?null:L,south:_==="SOUTH"?null:L},w?c.wides=M+1:E==="MISS"?c.byes=M:E==="PAD"?c.legByes=M:u.batRuns=M,h(u)}return u.attemptedRuns=u.completedRuns,u.completedRuns%2===1&&(u.endsAfter={north:s.endsBefore.south,south:s.endsBefore.north}),h(u)}const pu=new WeakSet,hu=new WeakSet,fu=new WeakSet;function E_(n){return!!n&&typeof n=="object"&&pu.has(n)}const Is=G(pe),ps=G(Tn),hs=yt.find(n=>n.rulesId==="LC_T20_01");if(!hs)throw new Error("INVALID_SETUP: frozen T20 rule manifest missing");const S_=G(hs),fs=yt.find(n=>n.rulesId==="LC_ODI_01");if(!fs)throw new Error("INVALID_SETUP: frozen ODI rule manifest missing");const __=G(fs),Es=yt.find(n=>n.rulesId==="LC_RED5_01");if(!Es)throw new Error("INVALID_SETUP: frozen red-ball rule manifest missing");const T_=G(Es);function X(n,e){if(!n)throw new Error(`INVALID_T20_SETUP: ${e}`)}function ia(n){if(n!==null&&typeof n=="object"){for(const e of Object.values(n))ia(e);Object.freeze(n)}return n}function Da(n,e){X(n instanceof Uint8Array&&n.byteLength>0,"world bytes missing");const t=te(n);X(t===xn.worldFileSha256,"world file bytes are not the frozen published world");let a;try{a=JSON.parse(new TextDecoder("utf-8",{fatal:!0}).decode(n))}catch{throw new Error("INVALID_T20_SETUP: world bytes are not strict UTF-8 JSON")}const o=YS(a,e);X(n.byteLength===o.manifest.worldByteLength,"world file length mismatch"),X(t===o.manifest.worldFileSha256,"world file manifest hash mismatch");const i=te(ce(o.world));return X(i===o.manifest.worldCanonicalSha256,"canonical world manifest hash mismatch"),X(i===xn.worldCanonicalSha256,"published canonical world pin mismatch"),o}function Eu(n,e,t,a=hs,o=pe,i=Tn){const r=gl.parse(n),{world:s,manifest:c}=Da(e,t);X(r.setup.format==="T20","only T20 setup is supported"),X(r.setup.worldPackId===s.packId,"wrong world ID"),X(r.setup.randomId===c.randomId,"unsupported random ID"),X(r.setup.modelId===c.modelId,"unsupported model ID"),X(r.setup.rulesId==="LC_T20_01"&&s.rulesIds.includes(r.setup.rulesId),"unsupported T20 rules"),X(!r.setup.capabilities.limitedOversRain&&!r.setup.capabilities.superOver&&!r.setup.capabilities.injuries&&!r.setup.capabilities.prediction,"unsupported gameplay capability enabled"),X(r.worldFileSha256===c.worldFileSha256&&r.worldCanonicalSha256===c.worldCanonicalSha256,"setup world hash mismatch"),X(G(a)===S_,"non-pinned T20 rule manifest"),X(G(o)===Is,"non-pinned probability pack"),X(G(i)===ps,"non-pinned conditional-delivery stage pack");const u=te(ce(a));X(r.rulesHash===u,"T20 rules hash mismatch"),X(r.modelHash===Cn&&r.modelHash===c.modelHash,"probability model hash mismatch"),X(r.stagePackHash===Zn&&r.stagePackHash===c.stagePackHash,"stage pack hash mismatch"),X(a.format==="T20"&&a.allocatedBalls===120&&a.bowlerMaxBalls===24&&i.noLiveMatchOrCalibration,"T20 setup cannot enable unsupported game rules or live play"),X(new Set(r.setup.teamIds).size===2,"teams must differ"),X(r.selectedTeams.every((T,A)=>T.teamId===r.setup.teamIds[A]),"selection order must equal match team order");const h=new Map(s.players.map(T=>[T.playerId,T])),p=r.selectedTeams.map(T=>{const A=s.teams.find(S=>S.teamId===T.teamId);X(!!A,`unknown team ${T.teamId}`),X(new Set(T.playerIds).size===11,`duplicate player in XI ${T.teamId}`);const I=new Set(A.squadIds);X(T.playerIds.every(S=>I.has(S)&&h.has(S)),`XI player not in own squad ${T.teamId}`),X(T.playerIds.includes(T.captainId),`captain not selected ${T.teamId}`),X(T.playerIds.includes(T.keeperId),`keeper not selected ${T.teamId}`);const f=T.playerIds.map(S=>h.get(S));return X(f.find(S=>S.playerId===T.keeperId)?.role==="KEEPER",`designated keeper ineligible ${T.teamId}`),X(f.filter(at).length>=5,`XI lacks five bowling-capable players ${T.teamId}`),ia({teamId:A.teamId,name:A.name,playerIds:[...T.playerIds],xi:f.map(S=>structuredClone(S)),captainId:T.captainId,keeperId:T.keeperId})}),E=p.flatMap(T=>T.playerIds);X(new Set(E).size===22,"teams cannot share XI players");const b=s.grounds.find(T=>T.groundId===r.setup.groundId);X(!!b,"unknown match ground");const w={schema:"1.0.0",engine:"LC_T20_SETUP_V1",random:c.randomId,rules:r.setup.rulesId,rulesHash:u,model:c.modelId,modelHash:Cn,worldHash:c.worldCanonicalSha256},v=ia({setupVersion:"LC_T20_SETUP_V1",gameId:r.setup.gameId,matchId:r.setup.matchId,seed:r.setup.seed,format:"T20",teams:p,ground:structuredClone(b),versions:w,stagePackHash:Zn,modelStatus:"SYNTHETIC_ALPHA",worldSeed:c.worldSeed,fixtureOnly:!0});return pu.add(v),v}function R_(n){return!!n&&typeof n=="object"&&hu.has(n)}function Su(n,e,t,a=fs,o=pe,i=Tn){const r=af.parse(n),{world:s,manifest:c}=Da(e,t);X(r.setup.format==="ODI","only ODI setup is supported"),X(r.setup.worldPackId===s.packId,"wrong world ID"),X(r.setup.randomId===c.randomId,"unsupported random ID"),X(r.setup.modelId===c.modelId,"unsupported model ID"),X(r.setup.rulesId==="LC_ODI_01"&&s.rulesIds.includes(r.setup.rulesId),"unsupported ODI rules"),X(!r.setup.capabilities.limitedOversRain&&!r.setup.capabilities.superOver&&!r.setup.capabilities.injuries&&!r.setup.capabilities.prediction,"unsupported gameplay capability enabled"),X(r.worldFileSha256===c.worldFileSha256&&r.worldCanonicalSha256===c.worldCanonicalSha256,"setup world hash mismatch"),X(G(a)===__,"non-pinned ODI rule manifest"),X(G(o)===Is,"non-pinned probability pack"),X(G(i)===ps,"non-pinned conditional-delivery stage pack");const u=te(ce(a));X(r.rulesHash===u,"ODI rules hash mismatch"),X(r.modelHash===Cn&&r.modelHash===c.modelHash,"probability model hash mismatch"),X(r.stagePackHash===Zn&&r.stagePackHash===c.stagePackHash,"stage pack hash mismatch"),X(a.format==="ODI"&&a.allocatedBalls===300&&a.bowlerMaxBalls===60&&i.noLiveMatchOrCalibration,"ODI setup cannot enable unsupported game rules or live play"),X(new Set(r.setup.teamIds).size===2,"teams must differ"),X(r.selectedTeams.every((T,A)=>T.teamId===r.setup.teamIds[A]),"selection order must equal match team order");const h=new Map(s.players.map(T=>[T.playerId,T])),p=r.selectedTeams.map(T=>{const A=s.teams.find(S=>S.teamId===T.teamId);X(!!A,`unknown team ${T.teamId}`),X(new Set(T.playerIds).size===11,`duplicate player in XI ${T.teamId}`);const I=new Set(A.squadIds);X(T.playerIds.every(S=>I.has(S)&&h.has(S)),`XI player not in own squad ${T.teamId}`),X(T.playerIds.includes(T.captainId),`captain not selected ${T.teamId}`),X(T.playerIds.includes(T.keeperId),`keeper not selected ${T.teamId}`);const f=T.playerIds.map(S=>h.get(S));return X(f.find(S=>S.playerId===T.keeperId)?.role==="KEEPER",`designated keeper ineligible ${T.teamId}`),X(f.filter(at).length>=5,`XI lacks five bowling-capable players ${T.teamId}`),ia({teamId:A.teamId,name:A.name,playerIds:[...T.playerIds],xi:f.map(S=>structuredClone(S)),captainId:T.captainId,keeperId:T.keeperId})}),E=p.flatMap(T=>T.playerIds);X(new Set(E).size===22,"teams cannot share XI players");const b=s.grounds.find(T=>T.groundId===r.setup.groundId);X(!!b,"unknown match ground");const w={schema:"1.0.0",engine:"LC_ODI_SETUP_V1",random:c.randomId,rules:r.setup.rulesId,rulesHash:u,model:c.modelId,modelHash:Cn,worldHash:c.worldCanonicalSha256},v=ia({setupVersion:"LC_ODI_SETUP_V1",gameId:r.setup.gameId,matchId:r.setup.matchId,seed:r.setup.seed,format:"ODI",teams:p,ground:structuredClone(b),versions:w,stagePackHash:Zn,modelStatus:"SYNTHETIC_ALPHA",worldSeed:c.worldSeed,fixtureOnly:!0});return hu.add(v),v}function Ss(n){return!!n&&typeof n=="object"&&fu.has(n)}function _u(n,e,t,a=Es,o=pe,i=Tn){const r=of.parse(n),{world:s,manifest:c}=Da(e,t);X(r.setup.format==="RED_BALL","only red-ball setup is supported"),X(r.setup.worldPackId===s.packId,"wrong world ID"),X(r.setup.randomId===c.randomId,"unsupported random ID"),X(r.setup.modelId===c.modelId,"unsupported model ID"),X(r.setup.rulesId==="LC_RED5_01"&&s.rulesIds.includes(r.setup.rulesId),"unsupported red-ball rules"),X(!r.setup.capabilities.limitedOversRain&&!r.setup.capabilities.superOver&&!r.setup.capabilities.injuries&&!r.setup.capabilities.prediction,"unsupported gameplay capability enabled"),X(r.worldFileSha256===c.worldFileSha256&&r.worldCanonicalSha256===c.worldCanonicalSha256,"setup world hash mismatch"),X(G(a)===T_,"non-pinned red-ball rule manifest"),X(G(o)===Is,"non-pinned probability pack"),X(G(i)===ps,"non-pinned conditional-delivery stage pack");const u=te(ce(a));X(r.rulesHash===u,"red-ball rules hash mismatch"),X(r.modelHash===Cn&&r.modelHash===c.modelHash,"probability model hash mismatch"),X(r.stagePackHash===Zn&&r.stagePackHash===c.stagePackHash,"stage pack hash mismatch");const h=a;X(h.format==="RED_BALL"&&h.inningsPerTeam===2&&h.allocatedBalls===null&&h.bowlerMaxBalls===null&&h.declarations&&h.followOnLead===200&&h.newBallAfterLegalBalls===480,"red-ball setup rule mismatch"),X(new Set(r.setup.teamIds).size===2,"teams must differ");const p=new Map(s.players.map(T=>[T.playerId,T])),E=r.selectedTeams.map(T=>{const A=s.teams.find(S=>S.teamId===T.teamId);X(!!A,`unknown team ${T.teamId}`),X(new Set(T.playerIds).size===11,`duplicate player in XI ${T.teamId}`);const I=new Set(A.squadIds);X(T.playerIds.every(S=>I.has(S)&&p.has(S)),`XI player not in own squad ${T.teamId}`),X(T.playerIds.includes(T.captainId),`captain not selected ${T.teamId}`),X(T.playerIds.includes(T.keeperId),`keeper not selected ${T.teamId}`);const f=T.playerIds.map(S=>p.get(S));return X(f.find(S=>S.playerId===T.keeperId)?.role==="KEEPER",`designated keeper ineligible ${T.teamId}`),X(f.filter(at).length>=5,`XI lacks five bowling-capable players ${T.teamId}`),ia({teamId:A.teamId,name:A.name,playerIds:[...T.playerIds],xi:f.map(S=>structuredClone(S)),captainId:T.captainId,keeperId:T.keeperId})});X(new Set(E.flatMap(T=>T.playerIds)).size===22,"teams cannot share XI players");const b=s.grounds.find(T=>T.groundId===r.setup.groundId);X(!!b,"unknown match ground");const w={schema:"1.0.0",engine:"LC_RED5_SETUP_V1",random:c.randomId,rules:r.setup.rulesId,rulesHash:u,model:c.modelId,modelHash:Cn,worldHash:c.worldCanonicalSha256},v=ia({setupVersion:"LC_RED5_SETUP_V1",gameId:r.setup.gameId,matchId:r.setup.matchId,seed:r.setup.seed,format:"RED_BALL",teams:E,ground:structuredClone(b),versions:w,stagePackHash:Zn,modelStatus:"SYNTHETIC_ALPHA",worldSeed:c.worldSeed,fixtureOnly:!0});return fu.add(v),v}const v_=qn(),A_=Nt(),Fn=n=>v_.hash(n),ft=n=>structuredClone(n),li=n=>{throw new Error(`LC_T20_${n}`)};function nn(n,e){n||li(e)}const Tu=Fn(so),b_=Tu,w_={line:"STUMPS",length:"GOOD",variationId:"stock",effort:"NORMAL"};function uo(n,e){const t=n.setup.teams.find(a=>a.teamId===e);return nn(t,"UNKNOWN_TEAM"),t}function Et(n,e){const t=n.setup.teams.flatMap(a=>a.xi).find(a=>a.playerId===e);return nn(t,"UNKNOWN_PLAYER"),t}function mo(n,e){const t=n.setup.teams.find(a=>a.teamId!==e);return nn(t,"UNKNOWN_OPPONENT"),t.teamId}function ae(n){const e=n.core.innings[n.core.activeInningsIndex];return nn(e,"NO_ACTIVE_INNINGS"),e}function di(n){return uo(n,ae(n).innings.battingTeamId)}function Dt(n){return uo(n,ae(n).innings.bowlingTeamId)}function Ru(n){const e=ya.positions.find(t=>t.slotId===n);return nn(e,"UNKNOWN_FIELD_POSITION"),e}function O_(n,e){const t=e<36?ls:ds;return[...n].sort().map((a,o)=>({slotId:t[o],playerId:a}))}function Ca(n,e,t,a){nn(n.length===9&&new Set(n.map(s=>s.playerId)).size===9&&new Set(n.map(s=>s.slotId)).size===9,"INVALID_FIELD_DUPLICATES"),nn([...n.map(s=>s.playerId)].sort().join("|")===[...e].sort().join("|"),"INVALID_FIELD_IDENTITIES");const o=n.map(s=>Ru(s.slotId)),i=o.filter(s=>t==="R"?s.legSide:!s.legSide),r=o.filter(s=>!s.insideCircle).length;nn(r<=(a<36?2:5),"INVALID_FIELD_POWERPLAY"),nn(i.length<=5,"INVALID_FIELD_LEG_SIDE"),nn(i.filter(s=>s.behindSquare).length<=2,"INVALID_FIELD_BEHIND_SQUARE")}function L_(n,e,t){const a=uo(n,e),o=uo(n,mo(n,e)),i=Object.fromEntries(a.playerIds.map(u=>[u,{runs:0,ballsFaced:0,fours:0,sixes:0,dismissed:!1}])),r=Object.fromEntries(o.playerIds.map(u=>[u,{runsConceded:0,legalBalls:0,wickets:0,maidens:0}])),s=Object.fromEntries(o.playerIds.map(u=>[u,0])),c=o.playerIds.filter(u=>u!==o.keeperId).slice(0,9);return le({engineVersion:Qe,rulesId:"LC_T20_01",nextDeliveryIndex:n.core.globalAttemptOrdinal,batting:i,bowling:r,dismissals:{},keeperId:o.keeperId,outfieldIds:c,currentOverRuns:0,innings:{index:t,battingTeamId:e,bowlingTeamId:o.teamId,runs:0,wickets:0,legalBalls:0,deliveryAttempts:0,targetToWin:t===1?n.core.innings[0].innings.runs+1:null,allocatedBalls:120,extras:{wides:0,noBalls:0,byes:0,legByes:0,penalties:0},northBatterId:null,southBatterId:null,strikerEnd:"NORTH",battingOrder:[...a.playerIds],dismissed:[],bowlerId:null,previousOverBowlerId:null,bowlerLegalBalls:s,freeHitPending:!1,ballAgeLegalBalls:0,complete:!1}})}function N_(n){return nn(E_(n)&&Object.isFrozen(n)&&n.setupVersion==="LC_T20_SETUP_V1"&&n.teams.length===2&&n.fixtureOnly,"INVALID_FROZEN_SETUP"),nn(n.versions.worldHash===xn.worldCanonicalSha256&&n.versions.modelHash===Cn&&n.stagePackHash===Zn&&n.versions.rulesHash===si("LC_T20_01")&&n.versions.random===jn&&n.versions.rules==="LC_T20_01","UNSUPPORTED_PINNED_SETUP"),pl.parse({engine:Il,eventChain:Ke,conditionPolicy:pr,conditionPolicyHash:Tu,setupHash:Fn(n),worldHash:n.versions.worldHash,rulesHash:n.versions.rulesHash,modelHash:n.versions.modelHash,stagePackHash:n.stagePackHash,randomVersion:jn,scoringVersion:Qe,probabilityVersion:se})}function ui(n){const e=N_(n),t=Fn(n),a={phase:"SETUP",setupHash:t,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:ft(n.ground.pitchPrior),fatigueBp:Object.fromEntries(n.teams.flatMap(i=>i.playerIds).map(i=>[i,0]))},o=Fn([Ke,t,Fn(e)]);return{setup:n,executionManifest:e,core:a,revision:0,events:[],receipts:{},commands:[],genesisHash:o,lastEventHash:o}}function y_(n,e,t){const a=Et(n,e.bowlerId),i=!["FAST","MEDIUM"].includes(a.bowlingStyle??"")?12:20,r=so.effortFactorBp[t],s=Math.floor((i*r+5e3)/1e4);if(n.core.fatigueBp[e.bowlerId]=Math.min(1e4,n.core.fatigueBp[e.bowlerId]+s),e.legalBall){const c=ft(n.core.pitch);c.wearPoints+=1,c.wearPoints%100===0&&(c.turnBp=Math.min(1e4,c.turnBp+20),c.variabilityBp=Math.min(1e4,c.variabilityBp+10),c.seamBp=Math.max(0,c.seamBp-10)),n.core.pitch=c}}function vu(n,e,t){const a=n.core;switch(e){case"TEAMS_CONFIRMED":nn(a.phase==="SETUP","WRONG_PHASE"),a.phase="TOSS";break;case"TOSS_RESOLVED":nn(a.phase==="TOSS","WRONG_PHASE"),nn(uo(n,t.winnerId),"INVALID_TOSS"),a.tossWinnerId=t.winnerId,a.tossCallerId=t.callerId,a.phase="AWAITING_INNINGS";break;case"INNINGS_STARTED":{const o=t.inningsIndex,i=t.battingTeamId;nn(a.phase==="AWAITING_INNINGS"||a.phase==="INTERVAL","WRONG_PHASE"),nn(o===a.innings.length&&o<2,"INNINGS_ORDER"),o===0?a.battingFirstId=i:nn(mo(n,a.battingFirstId)===i,"INNINGS_ORDER");const r=L_(n,i,o);a.innings.push(r),a.activeInningsIndex=o,a.fieldSlots=[],a.bowlingPlan=null,a.phase="AWAITING_BATTER";break}case"BATTER_SELECTED":{nn(a.phase==="AWAITING_BATTER","WRONG_PHASE");const o=ae(n),i=t.playerId;if(nn(di(n).playerIds.includes(i),"INVALID_BATTER_TEAM"),o.innings.northBatterId===null&&o.innings.southBatterId===null){nn(!o.batting[i].dismissed,"DISMISSED_BATTER");const s=ft(o);s.innings.northBatterId=i,a.innings[a.activeInningsIndex]=le(s)}else a.innings[a.activeInningsIndex]=lo(o,i);const r=ae(n).innings;a.phase=r.northBatterId===null||r.southBatterId===null?"AWAITING_BATTER":r.bowlerId===null?"AWAITING_BOWLER":"READY";break}case"BOWLER_SELECTED":{nn(a.phase==="AWAITING_BOWLER","WRONG_PHASE");const o=ae(n),i=t.playerId;nn(Dt(n).playerIds.includes(i)&&Et(n,i).bowlingStyle!==null,"INELIGIBLE_BOWLER");const r=Dt(n).playerIds.filter(c=>c!==Dt(n).keeperId&&c!==i);a.innings[a.activeInningsIndex]=ai(o,i,r),a.bowlingPlan={...w_,bowlerId:i},a.fieldSlots=O_(r,o.innings.legalBalls);const s=Fe(ae(n)).strikerId;Ca(a.fieldSlots,r,Et(n,s).batHand,o.innings.legalBalls),a.phase="READY";break}case"FIELD_CHANGED":{nn(a.phase==="READY","WRONG_PHASE");const o=ae(n),i=Fe(o).strikerId,r=t.fieldSlots;Ca(r,o.outfieldIds,Et(n,i).batHand,o.innings.legalBalls),a.fieldSlots=ft(r);break}case"BATTING_PLAN_CHANGED":{nn(a.phase==="READY","WRONG_PHASE");const o=t.playerId;nn([ae(n).innings.northBatterId,ae(n).innings.southBatterId].includes(o),"BATTER_NOT_ACTIVE"),a.battingPlans[o]={aggression:t.aggression,intent:t.intent};break}case"BOWLING_PLAN_CHANGED":{nn(a.phase==="READY","WRONG_PHASE"),nn(t.bowlerId===ae(n).innings.bowlerId,"BOWLER_NOT_ACTIVE"),nn(t.variationId==="stock","UNSUPPORTED_VARIATION"),a.bowlingPlan=ft(t);break}case"DELIVERY_RECORDED":{nn(a.phase==="READY","WRONG_PHASE");const o=ae(n),i=t.event;nn(t.attemptOrdinal===a.globalAttemptOrdinal&&i.deliveryIndex===a.globalAttemptOrdinal,"GLOBAL_ATTEMPT_MISMATCH"),Ca(a.fieldSlots,o.outfieldIds,Et(n,Fe(o).strikerId).batHand,o.innings.legalBalls);const r=ti(o,i);a.innings[a.activeInningsIndex]=r.ledger,a.globalAttemptOrdinal++,y_(n,i,a.bowlingPlan.effort),r.observation.result&&(a.result=r.observation.result),r.observation.inningsComplete?a.phase="INTERVAL":r.observation.requiredBatterEnd?a.phase="AWAITING_BATTER":r.observation.overCompleted?a.phase="AWAITING_BOWLER":a.phase="READY";break}case"OVER_COMPLETED":{nn(ae(n).innings.legalBalls%6===0,"INVALID_OVER_MARKER");const o=t.bowlerId;nn(ae(n).innings.previousOverBowlerId===o,"OVER_BOWLER_MISMATCH");for(const i of Dt(n).playerIds)i!==o&&(a.fatigueBp[i]=Math.max(0,a.fatigueBp[i]-15));break}case"INNINGS_COMPLETED":nn(ae(n).innings.complete,"INVALID_INNINGS_MARKER"),a.phase=a.activeInningsIndex===0?"INTERVAL":a.phase;break;case"MATCH_COMPLETED":nn(a.activeInningsIndex===1&&ae(n).innings.complete&&a.result!==null,"INVALID_RESULT_MARKER"),a.phase="COMPLETE";break;default:li("UNKNOWN_EVENT")}}function Me(n,e,t,a){vu(n,t,a);const o=n.events.length+1,i=n.lastEventHash,r=Fn(n.core),s=Fn([Ke,o,e,t,a,i,r]),c=Yo.parse({version:Ke,sequence:o,commandId:e,type:t,payload:a,previousHash:i,stateHash:r,eventHash:s});n.events.push(c),n.lastEventHash=s}function D_(n){const e=ae(n),t=Fe(e),a=Et(n,t.strikerId),o=Et(n,t.bowlerId),i=Et(n,t.keeperId),r=a.skills.T20,s=o.skills.T20;Ca(n.core.fieldSlots,e.outfieldIds,a.batHand,e.innings.legalBalls);const c={kind:"GENERATE_DELIVERY",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:Zn,randomVersion:jn,probabilityVersion:se,modelId:Be,modelHash:Cn,lutVersion:ze,lutHash:tt,rulesHash:n.setup.versions.rulesHash,matchId:n.setup.matchId,seed:n.setup.seed,attemptOrdinal:n.core.globalAttemptOrdinal,format:"T20",phase:ri("T20",e.innings.legalBalls),context:t,bowling:{bowlingStyle:o.bowlingStyle,controlRating:s.control,movementRating:s.movement,fatigueBp:n.core.fatigueBp[o.playerId],line:n.core.bowlingPlan.line,intendedLength:n.core.bowlingPlan.length,effort:n.core.bowlingPlan.effort,variationId:"stock"},batting:{defenceRating:r.defence,timingRating:r.timing,powerRating:r.power,rotationRating:r.rotation,vsPaceRating:r.vsPace,vsSpinRating:r.vsSpin,aggression:n.core.battingPlans[a.playerId]?.aggression??2,intent:n.core.battingPlans[a.playerId]?.intent??"NORMAL",attemptedStroke:!0,shotSectorWeights:[...a.shotSectorWeights]},conditions:{seamBp:n.core.pitch.seamBp,turnBp:n.core.pitch.turnBp},field:{keeper:{keepingRating:i.skills.T20.keeping,catchingRating:i.skills.T20.catching,throwingRating:i.skills.T20.throwing},slots:n.core.fieldSlots.map(p=>{const E=Et(n,p.playerId),b=Ru(p.slotId);return{playerId:p.playerId,sector:b.sector,depth:b.depth,role:p.slotId.startsWith("slip")?"SLIP":"NORMAL",catchingRating:E.skills.T20.catching,throwingRating:E.skills.T20.throwing}})}},u=ci(c);return{event:ei(t,u.resolution),traceHash:Fn(u.trace)}}function C_(n,e,t,a){const o=n.core.globalAttemptOrdinal;Me(n,e,"DELIVERY_RECORDED",{type:"DELIVERY_RECORDED",event:t,attemptOrdinal:o,traceHash:a});const i=ae(n);t.legalBall&&i.innings.legalBalls%6===0&&Me(n,e,"OVER_COMPLETED",{type:"OVER_COMPLETED",bowlerId:t.bowlerId}),i.innings.complete&&(Me(n,e,"INNINGS_COMPLETED",{type:"INNINGS_COMPLETED",inningsIndex:n.core.activeInningsIndex}),n.core.activeInningsIndex===1?Me(n,e,"MATCH_COMPLETED",{type:"MATCH_COMPLETED",result:n.core.result}):Me(n,e,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:1,battingTeamId:mo(n,i.innings.battingTeamId)}))}function k_(n,e,t){nn(n.core.phase==="READY","WRONG_PHASE");const a=Math.floor(ae(n).innings.legalBalls/6);let o=0;for(;n.core.phase==="READY"&&o<60;){const{event:i,traceHash:r}=D_(n);C_(n,e,i,r),o++;const s=ae(n);if(t==="DELIVERY"||Math.floor(s.innings.legalBalls/6)!==a)break}nn(o<60,"ADVANCE_ATTEMPT_LIMIT")}function ka(n,e){const t=hl.parse(e),a=n.receipts[t.commandId];if(a)return{session:n,receipt:a};nn(t.expectedRevision===n.revision,"STALE_REVISION");const o={...n,core:ft(n.core),events:[...n.events],receipts:{...n.receipts},commands:[...n.commands]},i=o.events.length+1,r=t.commandId,s=u=>{nn(o.setup.teams.some(h=>h.teamId===u),"ACTOR_TEAM_UNKNOWN"),nn(t.actorId===`USER:${u}`||t.actorId===`AI:${u}`||t.actorId==="SYSTEM","ACTOR_UNAUTHORISED")};switch(t.kind){case"CONFIRM_TEAMS":nn(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),Me(o,r,"TEAMS_CONFIRMED",{type:"TEAMS_CONFIRMED"});break;case"CALL_TOSS":{s(t.payload.teamId),nn(o.core.phase==="TOSS","WRONG_PHASE");const u=A_.uint32({seed:o.setup.seed,domain:"TOSS",entityId:o.setup.matchId,eventOrdinal:0,stageName:"coin",drawIndex:0})%2===0?"HEADS":"TAILS",h=t.payload.call===u?t.payload.teamId:mo(o,t.payload.teamId);Me(o,r,"TOSS_RESOLVED",{type:"TOSS_RESOLVED",callerId:t.payload.teamId,winnerId:h,call:t.payload.call,coin:u});break}case"CHOOSE_INNINGS":{s(t.payload.teamId),nn(t.payload.teamId===o.core.tossWinnerId,"NOT_TOSS_WINNER"),nn(o.core.phase==="AWAITING_INNINGS","WRONG_PHASE");const u=t.payload.choice==="BAT"?t.payload.teamId:mo(o,t.payload.teamId);Me(o,r,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:0,battingTeamId:u});break}case"SET_BATTER":s(t.payload.teamId),nn(o.core.phase==="AWAITING_BATTER"&&t.payload.teamId===di(o).teamId,"WRONG_TEAM_OR_PHASE"),Me(o,r,"BATTER_SELECTED",{type:"BATTER_SELECTED",playerId:t.payload.playerId});break;case"SET_BOWLER":s(t.payload.teamId),nn(o.core.phase==="AWAITING_BOWLER"&&t.payload.teamId===Dt(o).teamId,"WRONG_TEAM_OR_PHASE"),Me(o,r,"BOWLER_SELECTED",{type:"BOWLER_SELECTED",playerId:t.payload.bowlerId});break;case"SET_FIELD":s(t.payload.teamId),nn(o.core.phase==="READY"&&t.payload.teamId===Dt(o).teamId,"WRONG_TEAM_OR_PHASE"),Me(o,r,"FIELD_CHANGED",{type:"FIELD_CHANGED",fieldSlots:t.payload.fieldSlots});break;case"SET_BATTING_PLAN":{const u=di(o);s(u.teamId),Me(o,r,"BATTING_PLAN_CHANGED",{type:"BATTING_PLAN_CHANGED",...t.payload});break}case"SET_BOWLING_PLAN":{const u=Dt(o);s(u.teamId),Me(o,r,"BOWLING_PLAN_CHANGED",{type:"BOWLING_PLAN_CHANGED",...t.payload});break}case"ADVANCE":nn(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),k_(o,r,t.payload.scope);break;default:li("UNKNOWN_COMMAND")}nn(o.events.length>=i,"COMMAND_WITH_NO_EVENT"),o.revision=n.revision+1;const c=rf.parse({commandId:r,committedRevision:o.revision,fromSequence:i,toSequence:o.events.length,lastEventHash:o.lastEventHash});return o.receipts[r]=c,o.commands.push(t),{session:o,receipt:c}}function B_(n,e,t){return Au(ui(n),e,t)}function Au(n,e,t){nn(n.revision===0&&n.events.length===0&&n.core.phase==="SETUP","REPLAY_INITIAL_STATE");for(const[a,o]of e.entries()){const i=Yo.parse(o);nn(i.sequence===a+1&&i.previousHash===n.lastEventHash,"REPLAY_CHAIN_GAP"),nn(i.eventHash===Fn([Ke,i.sequence,i.commandId,i.type,i.payload,i.previousHash,i.stateHash]),"REPLAY_EVENT_HASH"),vu(n,i.type,i.payload),i.stateHash!==Fn(n.core)&&li("REPLAY_STATE_HASH"),n.events.push(i),n.lastEventHash=i.eventHash}if(t){const a=no.parse(t);nn(a.version===Ke&&a.genesisHash===n.genesisHash&&a.finalEventHash===n.lastEventHash&&a.finalStateHash===Fn(n.core)&&a.eventCount===e.length&&a.executionManifestHash===Fn(n.executionManifest),"REPLAY_MANIFEST_MISMATCH")}return n}function bu(n){return no.parse({version:Ke,genesisHash:n.genesisHash,finalEventHash:n.lastEventHash,finalStateHash:Fn(n.core),eventCount:n.events.length,executionManifestHash:Fn(n.executionManifest)})}function P_(n){let e=ui(n.setup);for(const t of n.commands)e=ka(e,t).session;nn(e.events.length===n.events.length,"RESIMULATION_LENGTH");for(let t=0;t<n.events.length;t++)nn(te(ce(e.events[t]))===te(ce(n.events[t])),`RESIMULATION_MISMATCH_${t}`);nn(Fn(e.core)===Fn(n.core),"RESIMULATION_FINAL_STATE")}function mi(n){const t={commandId:`auto-${String(n.revision+1).padStart(6,"0")}`,expectedRevision:n.revision};if(n.core.phase==="SETUP")return{...t,actorId:"SYSTEM",kind:"CONFIRM_TEAMS",payload:{}};if(n.core.phase==="TOSS")return{...t,actorId:`AI:${n.setup.teams[0].teamId}`,kind:"CALL_TOSS",payload:{teamId:n.setup.teams[0].teamId,call:"HEADS"}};if(n.core.phase==="AWAITING_INNINGS")return{...t,actorId:`AI:${n.core.tossWinnerId}`,kind:"CHOOSE_INNINGS",payload:{teamId:n.core.tossWinnerId,choice:"BAT"}};const a=ae(n);if(n.core.phase==="AWAITING_BATTER"){const o=di(n),i=new Set([a.innings.northBatterId,a.innings.southBatterId,...a.innings.dismissed]),r=o.playerIds.find(s=>!i.has(s));return nn(r,"NO_ELIGIBLE_BATTER"),{...t,actorId:`AI:${o.teamId}`,kind:"SET_BATTER",payload:{teamId:o.teamId,playerId:r}}}if(n.core.phase==="AWAITING_BOWLER"){const o=Dt(n),i=o.xi.filter(r=>r.bowlingStyle!==null&&r.playerId!==o.keeperId&&r.playerId!==a.innings.previousOverBowlerId&&a.bowling[r.playerId].legalBalls<24).sort((r,s)=>a.bowling[r.playerId].legalBalls-a.bowling[s.playerId].legalBalls||r.playerId.localeCompare(s.playerId));return nn(i.length,"NO_ELIGIBLE_BOWLER"),{...t,actorId:`AI:${o.teamId}`,kind:"SET_BOWLER",payload:{teamId:o.teamId,bowlerId:i[0].playerId}}}return nn(n.core.phase==="READY","INVALID_AUTOPILOT_PHASE"),{...t,actorId:"SYSTEM",kind:"ADVANCE",payload:{scope:"OVER"}}}function gi(n){nn(n.core.phase==="COMPLETE"&&n.core.innings.length===2&&n.core.result,"SCORECARD_NOT_COMPLETE");const e=n.core.innings.map((t,a)=>{le(t);const o=n.events.filter(u=>u.type==="DELIVERY_RECORDED"&&u.payload.event.inningsIndex===a);let i=0,r=0;const s=[];for(const u of o){const h=u.payload.event;i+=h.batRuns+Object.values(h.extras).reduce((p,E)=>p+E,0),r+=Number(h.legalBall),h.dismissal&&s.push({playerId:h.dismissal.playerId,runs:i,legalBalls:r,sequence:u.sequence})}nn(i===t.innings.runs&&r===t.innings.legalBalls&&o.length===t.innings.deliveryAttempts,"PROJECTED_SCORE_MISMATCH");const c=t.innings;return{battingTeamId:c.battingTeamId,bowlingTeamId:c.bowlingTeamId,runs:c.runs,wickets:c.wickets,legalBalls:c.legalBalls,overs:`${Math.floor(c.legalBalls/6)}.${c.legalBalls%6}`,extras:ft(c.extras),batting:ft(t.batting),bowling:ft(t.bowling),fallOfWickets:s,targetToWin:c.targetToWin}});return hr.parse({matchId:n.setup.matchId,innings:e,result:n.core.result})}function x_(n,e,t){nn(!!n&&typeof n=="object"&&!Array.isArray(n),"SAVE_SHAPE");const a=n,o=a.setup;nn(!!o&&o.setupVersion==="LC_T20_SETUP_V1","SAVE_SETUP"),nn(Array.isArray(o.teams)&&o.teams.length===2,"SAVE_TEAMS");const i=Eu({setupVersion:"LC_T20_SETUP_V1",setup:{schemaVersion:"1.0.0",gameId:o.gameId,matchId:o.matchId,format:"T20",worldPackId:xn.worldPackId,rulesId:o.versions.rules,modelId:o.versions.model,randomId:o.versions.random,seed:o.seed,teamIds:o.teams.map(s=>s.teamId),groundId:o.ground.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:xn.worldFileSha256,worldCanonicalSha256:o.versions.worldHash,rulesHash:o.versions.rulesHash,modelHash:o.versions.modelHash,stagePackHash:o.stagePackHash,selectedTeams:o.teams.map(s=>({teamId:s.teamId,playerIds:[...s.playerIds],captainId:s.captainId,keeperId:s.keeperId}))},e,t);nn(Array.isArray(a.commands),"SAVE_COMMANDS");let r=ui(i);for(const s of a.commands)r=ka(r,s).session;return nn(typeof a.revision=="number"&&r.revision===a.revision,"SAVE_REVISION"),nn(Array.isArray(a.events)&&Fn(r.events)===Fn(a.events),"SAVE_EVENTS"),nn(a.core!==void 0&&Fn(r.core)===Fn(a.core),"SAVE_CORE"),nn(a.receipts!==void 0&&Fn(r.receipts)===Fn(a.receipts),"SAVE_RECEIPTS"),nn(a.executionManifest!==void 0&&Fn(r.executionManifest)===Fn(a.executionManifest),"SAVE_MANIFEST"),nn(a.genesisHash===r.genesisHash&&a.lastEventHash===r.lastEventHash,"SAVE_CHAIN"),r}const H_=qn(),F_=Nt(),Mn=n=>H_.hash(n),St=n=>structuredClone(n),Ii=n=>{throw new Error(`LC_ODI_${n}`)};function en(n,e){n||Ii(e)}const wu=Mn(iu),M_=wu,V_={line:"STUMPS",length:"GOOD",variationId:"stock",effort:"NORMAL"};function go(n,e){const t=n.setup.teams.find(a=>a.teamId===e);return en(t,"UNKNOWN_TEAM"),t}function _t(n,e){const t=n.setup.teams.flatMap(a=>a.xi).find(a=>a.playerId===e);return en(t,"UNKNOWN_PLAYER"),t}function Io(n,e){const t=n.setup.teams.find(a=>a.teamId!==e);return en(t,"UNKNOWN_OPPONENT"),t.teamId}function oe(n){const e=n.core.innings[n.core.activeInningsIndex];return en(e,"NO_ACTIVE_INNINGS"),e}function pi(n){return go(n,oe(n).innings.battingTeamId)}function Ct(n){return go(n,oe(n).innings.bowlingTeamId)}function Ou(n){const e=tu.positions.find(t=>t.slotId===n);return en(e,"UNKNOWN_FIELD_POSITION"),e}function W_(n,e){const t=e<60?au:e<240?GS:jS;return[...n].sort().map((a,o)=>({slotId:t[o],playerId:a}))}function Ba(n,e,t,a){en(n.length===9&&new Set(n.map(s=>s.playerId)).size===9&&new Set(n.map(s=>s.slotId)).size===9,"INVALID_FIELD_DUPLICATES"),en([...n.map(s=>s.playerId)].sort().join("|")===[...e].sort().join("|"),"INVALID_FIELD_IDENTITIES");const o=n.map(s=>Ou(s.slotId)),i=o.filter(s=>t==="R"?s.legSide:!s.legSide),r=o.filter(s=>!s.insideCircle).length;en(r<=(a<60?2:a<240?4:5),"INVALID_FIELD_POWERPLAY"),en(i.length<=5,"INVALID_FIELD_LEG_SIDE"),en(i.filter(s=>s.behindSquare).length<=2,"INVALID_FIELD_BEHIND_SQUARE")}function U_(n,e,t){const a=go(n,e),o=go(n,Io(n,e)),i=Object.fromEntries(a.playerIds.map(u=>[u,{runs:0,ballsFaced:0,fours:0,sixes:0,dismissed:!1}])),r=Object.fromEntries(o.playerIds.map(u=>[u,{runsConceded:0,legalBalls:0,wickets:0,maidens:0}])),s=Object.fromEntries(o.playerIds.map(u=>[u,0])),c=o.playerIds.filter(u=>u!==o.keeperId).slice(0,9);return le({engineVersion:Qe,rulesId:"LC_ODI_01",nextDeliveryIndex:n.core.globalAttemptOrdinal,batting:i,bowling:r,dismissals:{},keeperId:o.keeperId,outfieldIds:c,currentOverRuns:0,innings:{index:t,battingTeamId:e,bowlingTeamId:o.teamId,runs:0,wickets:0,legalBalls:0,deliveryAttempts:0,targetToWin:t===1?n.core.innings[0].innings.runs+1:null,allocatedBalls:300,extras:{wides:0,noBalls:0,byes:0,legByes:0,penalties:0},northBatterId:null,southBatterId:null,strikerEnd:"NORTH",battingOrder:[...a.playerIds],dismissed:[],bowlerId:null,previousOverBowlerId:null,bowlerLegalBalls:s,freeHitPending:!1,ballAgeLegalBalls:0,complete:!1}})}function $_(n){return en(R_(n)&&Object.isFrozen(n)&&n.setupVersion==="LC_ODI_SETUP_V1"&&n.teams.length===2&&n.fixtureOnly,"INVALID_FROZEN_SETUP"),en(n.versions.worldHash===xn.worldCanonicalSha256&&n.versions.modelHash===Cn&&n.stagePackHash===Zn&&n.versions.rulesHash===si("LC_ODI_01")&&n.versions.random===jn&&n.versions.rules==="LC_ODI_01","UNSUPPORTED_PINNED_SETUP"),El.parse({engine:fl,eventChain:qe,conditionPolicy:fr,conditionPolicyHash:wu,setupHash:Mn(n),worldHash:n.versions.worldHash,rulesHash:n.versions.rulesHash,modelHash:n.versions.modelHash,stagePackHash:n.stagePackHash,randomVersion:jn,scoringVersion:Qe,probabilityVersion:se})}function hi(n){const e=$_(n),t=Mn(n),a={phase:"SETUP",setupHash:t,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:St(n.ground.pitchPrior),fatigueBp:Object.fromEntries(n.teams.flatMap(i=>i.playerIds).map(i=>[i,0]))},o=Mn([qe,t,Mn(e)]);return{setup:n,executionManifest:e,core:a,revision:0,events:[],receipts:{},commands:[],genesisHash:o,lastEventHash:o}}function G_(n,e,t){const a=_t(n,e.bowlerId),i=!["FAST","MEDIUM"].includes(a.bowlingStyle??"")?12:20,r=iu.effortFactorBp[t],s=Math.floor((i*r+5e3)/1e4);if(n.core.fatigueBp[e.bowlerId]=Math.min(1e4,n.core.fatigueBp[e.bowlerId]+s),e.legalBall){const c=St(n.core.pitch);c.wearPoints+=1,c.wearPoints%100===0&&(c.turnBp=Math.min(1e4,c.turnBp+20),c.variabilityBp=Math.min(1e4,c.variabilityBp+10),c.seamBp=Math.max(0,c.seamBp-10)),n.core.pitch=c}}function Lu(n,e,t){const a=n.core;switch(e){case"TEAMS_CONFIRMED":en(a.phase==="SETUP","WRONG_PHASE"),a.phase="TOSS";break;case"TOSS_RESOLVED":en(a.phase==="TOSS","WRONG_PHASE"),en(go(n,t.winnerId),"INVALID_TOSS"),a.tossWinnerId=t.winnerId,a.tossCallerId=t.callerId,a.phase="AWAITING_INNINGS";break;case"INNINGS_STARTED":{const o=t.inningsIndex,i=t.battingTeamId;en(a.phase==="AWAITING_INNINGS"||a.phase==="INTERVAL","WRONG_PHASE"),en(o===a.innings.length&&o<2,"INNINGS_ORDER"),o===0?a.battingFirstId=i:en(Io(n,a.battingFirstId)===i,"INNINGS_ORDER");const r=U_(n,i,o);a.innings.push(r),a.activeInningsIndex=o,a.fieldSlots=[],a.bowlingPlan=null,a.phase="AWAITING_BATTER";break}case"BATTER_SELECTED":{en(a.phase==="AWAITING_BATTER","WRONG_PHASE");const o=oe(n),i=t.playerId;if(en(pi(n).playerIds.includes(i),"INVALID_BATTER_TEAM"),o.innings.northBatterId===null&&o.innings.southBatterId===null){en(!o.batting[i].dismissed,"DISMISSED_BATTER");const s=St(o);s.innings.northBatterId=i,a.innings[a.activeInningsIndex]=le(s)}else a.innings[a.activeInningsIndex]=lo(o,i);const r=oe(n).innings;a.phase=r.northBatterId===null||r.southBatterId===null?"AWAITING_BATTER":r.bowlerId===null?"AWAITING_BOWLER":"READY";break}case"BOWLER_SELECTED":{en(a.phase==="AWAITING_BOWLER","WRONG_PHASE");const o=oe(n),i=t.playerId;en(Ct(n).playerIds.includes(i)&&_t(n,i).bowlingStyle!==null,"INELIGIBLE_BOWLER");const r=Ct(n).playerIds.filter(c=>c!==Ct(n).keeperId&&c!==i);a.innings[a.activeInningsIndex]=ai(o,i,r),a.bowlingPlan={...V_,bowlerId:i},a.fieldSlots=W_(r,o.innings.legalBalls);const s=Fe(oe(n)).strikerId;Ba(a.fieldSlots,r,_t(n,s).batHand,o.innings.legalBalls),a.phase="READY";break}case"FIELD_CHANGED":{en(a.phase==="READY","WRONG_PHASE");const o=oe(n),i=Fe(o).strikerId,r=t.fieldSlots;Ba(r,o.outfieldIds,_t(n,i).batHand,o.innings.legalBalls),a.fieldSlots=St(r);break}case"BATTING_PLAN_CHANGED":{en(a.phase==="READY","WRONG_PHASE");const o=t.playerId;en([oe(n).innings.northBatterId,oe(n).innings.southBatterId].includes(o),"BATTER_NOT_ACTIVE"),a.battingPlans[o]={aggression:t.aggression,intent:t.intent};break}case"BOWLING_PLAN_CHANGED":{en(a.phase==="READY","WRONG_PHASE"),en(t.bowlerId===oe(n).innings.bowlerId,"BOWLER_NOT_ACTIVE"),en(t.variationId==="stock","UNSUPPORTED_VARIATION"),a.bowlingPlan=St(t);break}case"DELIVERY_RECORDED":{en(a.phase==="READY","WRONG_PHASE");const o=oe(n),i=t.event;en(t.attemptOrdinal===a.globalAttemptOrdinal&&i.deliveryIndex===a.globalAttemptOrdinal,"GLOBAL_ATTEMPT_MISMATCH"),Ba(a.fieldSlots,o.outfieldIds,_t(n,Fe(o).strikerId).batHand,o.innings.legalBalls);const r=ti(o,i);a.innings[a.activeInningsIndex]=r.ledger,a.globalAttemptOrdinal++,G_(n,i,a.bowlingPlan.effort),r.observation.result&&(a.result=r.observation.result),r.observation.inningsComplete?a.phase="INTERVAL":r.observation.requiredBatterEnd?a.phase="AWAITING_BATTER":r.observation.overCompleted?a.phase="AWAITING_BOWLER":a.phase="READY";break}case"OVER_COMPLETED":{en(oe(n).innings.legalBalls%6===0,"INVALID_OVER_MARKER");const o=t.bowlerId;en(oe(n).innings.previousOverBowlerId===o,"OVER_BOWLER_MISMATCH");for(const i of Ct(n).playerIds)i!==o&&(a.fatigueBp[i]=Math.max(0,a.fatigueBp[i]-15));break}case"INNINGS_COMPLETED":en(oe(n).innings.complete,"INVALID_INNINGS_MARKER"),a.phase=a.activeInningsIndex===0?"INTERVAL":a.phase;break;case"MATCH_COMPLETED":en(a.activeInningsIndex===1&&oe(n).innings.complete&&a.result!==null,"INVALID_RESULT_MARKER"),a.phase="COMPLETE";break;default:Ii("UNKNOWN_EVENT")}}function Ve(n,e,t,a){Lu(n,t,a);const o=n.events.length+1,i=n.lastEventHash,r=Mn(n.core),s=Mn([qe,o,e,t,a,i,r]),c=_l.parse({version:qe,sequence:o,commandId:e,type:t,payload:a,previousHash:i,stateHash:r,eventHash:s});n.events.push(c),n.lastEventHash=s}function j_(n){const e=oe(n),t=Fe(e),a=_t(n,t.strikerId),o=_t(n,t.bowlerId),i=_t(n,t.keeperId),r=a.skills.ODI,s=o.skills.ODI;Ba(n.core.fieldSlots,e.outfieldIds,a.batHand,e.innings.legalBalls);const c={kind:"GENERATE_DELIVERY",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:Zn,randomVersion:jn,probabilityVersion:se,modelId:Be,modelHash:Cn,lutVersion:ze,lutHash:tt,rulesHash:n.setup.versions.rulesHash,matchId:n.setup.matchId,seed:n.setup.seed,attemptOrdinal:n.core.globalAttemptOrdinal,format:"ODI",phase:ri("ODI",e.innings.legalBalls),context:t,bowling:{bowlingStyle:o.bowlingStyle,controlRating:s.control,movementRating:s.movement,fatigueBp:n.core.fatigueBp[o.playerId],line:n.core.bowlingPlan.line,intendedLength:n.core.bowlingPlan.length,effort:n.core.bowlingPlan.effort,variationId:"stock"},batting:{defenceRating:r.defence,timingRating:r.timing,powerRating:r.power,rotationRating:r.rotation,vsPaceRating:r.vsPace,vsSpinRating:r.vsSpin,aggression:n.core.battingPlans[a.playerId]?.aggression??2,intent:n.core.battingPlans[a.playerId]?.intent??"NORMAL",attemptedStroke:!0,shotSectorWeights:[...a.shotSectorWeights]},conditions:{seamBp:n.core.pitch.seamBp,turnBp:n.core.pitch.turnBp},field:{keeper:{keepingRating:i.skills.ODI.keeping,catchingRating:i.skills.ODI.catching,throwingRating:i.skills.ODI.throwing},slots:n.core.fieldSlots.map(p=>{const E=_t(n,p.playerId),b=Ou(p.slotId);return{playerId:p.playerId,sector:b.sector,depth:b.depth,role:p.slotId.startsWith("slip")?"SLIP":"NORMAL",catchingRating:E.skills.ODI.catching,throwingRating:E.skills.ODI.throwing}})}},u=ci(c);return{event:ei(t,u.resolution),traceHash:Mn(u.trace)}}function Y_(n,e,t,a){const o=n.core.globalAttemptOrdinal;Ve(n,e,"DELIVERY_RECORDED",{type:"DELIVERY_RECORDED",event:t,attemptOrdinal:o,traceHash:a});const i=oe(n);t.legalBall&&i.innings.legalBalls%6===0&&Ve(n,e,"OVER_COMPLETED",{type:"OVER_COMPLETED",bowlerId:t.bowlerId}),i.innings.complete&&(Ve(n,e,"INNINGS_COMPLETED",{type:"INNINGS_COMPLETED",inningsIndex:n.core.activeInningsIndex}),n.core.activeInningsIndex===1?Ve(n,e,"MATCH_COMPLETED",{type:"MATCH_COMPLETED",result:n.core.result}):Ve(n,e,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:1,battingTeamId:Io(n,i.innings.battingTeamId)}))}function z_(n,e,t){en(n.core.phase==="READY","WRONG_PHASE");const a=Math.floor(oe(n).innings.legalBalls/6);let o=0;for(;n.core.phase==="READY"&&o<60;){const{event:i,traceHash:r}=j_(n);Y_(n,e,i,r),o++;const s=oe(n);if(t==="DELIVERY"||Math.floor(s.innings.legalBalls/6)!==a)break}en(o<60,"ADVANCE_ATTEMPT_LIMIT")}function Pa(n,e){const t=Sl.parse(e),a=n.receipts[t.commandId];if(a)return{session:n,receipt:a};en(t.expectedRevision===n.revision,"STALE_REVISION");const o={...n,core:St(n.core),events:[...n.events],receipts:{...n.receipts},commands:[...n.commands]},i=o.events.length+1,r=t.commandId,s=u=>{en(o.setup.teams.some(h=>h.teamId===u),"ACTOR_TEAM_UNKNOWN"),en(t.actorId===`USER:${u}`||t.actorId===`AI:${u}`||t.actorId==="SYSTEM","ACTOR_UNAUTHORISED")};switch(t.kind){case"CONFIRM_TEAMS":en(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),Ve(o,r,"TEAMS_CONFIRMED",{type:"TEAMS_CONFIRMED"});break;case"CALL_TOSS":{s(t.payload.teamId),en(o.core.phase==="TOSS","WRONG_PHASE");const u=F_.uint32({seed:o.setup.seed,domain:"TOSS",entityId:o.setup.matchId,eventOrdinal:0,stageName:"coin",drawIndex:0})%2===0?"HEADS":"TAILS",h=t.payload.call===u?t.payload.teamId:Io(o,t.payload.teamId);Ve(o,r,"TOSS_RESOLVED",{type:"TOSS_RESOLVED",callerId:t.payload.teamId,winnerId:h,call:t.payload.call,coin:u});break}case"CHOOSE_INNINGS":{s(t.payload.teamId),en(t.payload.teamId===o.core.tossWinnerId,"NOT_TOSS_WINNER"),en(o.core.phase==="AWAITING_INNINGS","WRONG_PHASE");const u=t.payload.choice==="BAT"?t.payload.teamId:Io(o,t.payload.teamId);Ve(o,r,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:0,battingTeamId:u});break}case"SET_BATTER":s(t.payload.teamId),en(o.core.phase==="AWAITING_BATTER"&&t.payload.teamId===pi(o).teamId,"WRONG_TEAM_OR_PHASE"),Ve(o,r,"BATTER_SELECTED",{type:"BATTER_SELECTED",playerId:t.payload.playerId});break;case"SET_BOWLER":s(t.payload.teamId),en(o.core.phase==="AWAITING_BOWLER"&&t.payload.teamId===Ct(o).teamId,"WRONG_TEAM_OR_PHASE"),Ve(o,r,"BOWLER_SELECTED",{type:"BOWLER_SELECTED",playerId:t.payload.bowlerId});break;case"SET_FIELD":s(t.payload.teamId),en(o.core.phase==="READY"&&t.payload.teamId===Ct(o).teamId,"WRONG_TEAM_OR_PHASE"),Ve(o,r,"FIELD_CHANGED",{type:"FIELD_CHANGED",fieldSlots:t.payload.fieldSlots});break;case"SET_BATTING_PLAN":{const u=pi(o);s(u.teamId),Ve(o,r,"BATTING_PLAN_CHANGED",{type:"BATTING_PLAN_CHANGED",...t.payload});break}case"SET_BOWLING_PLAN":{const u=Ct(o);s(u.teamId),Ve(o,r,"BOWLING_PLAN_CHANGED",{type:"BOWLING_PLAN_CHANGED",...t.payload});break}case"ADVANCE":en(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),z_(o,r,t.payload.scope);break;default:Ii("UNKNOWN_COMMAND")}en(o.events.length>=i,"COMMAND_WITH_NO_EVENT"),o.revision=n.revision+1;const c=sf.parse({commandId:r,committedRevision:o.revision,fromSequence:i,toSequence:o.events.length,lastEventHash:o.lastEventHash});return o.receipts[r]=c,o.commands.push(t),{session:o,receipt:c}}function K_(n,e,t){return Nu(hi(n),e,t)}function Nu(n,e,t){en(n.revision===0&&n.events.length===0&&n.core.phase==="SETUP","REPLAY_INITIAL_STATE");for(const[a,o]of e.entries()){const i=_l.parse(o);en(i.sequence===a+1&&i.previousHash===n.lastEventHash,"REPLAY_CHAIN_GAP"),en(i.eventHash===Mn([qe,i.sequence,i.commandId,i.type,i.payload,i.previousHash,i.stateHash]),"REPLAY_EVENT_HASH"),Lu(n,i.type,i.payload),i.stateHash!==Mn(n.core)&&Ii("REPLAY_STATE_HASH"),n.events.push(i),n.lastEventHash=i.eventHash}if(t){const a=Tl.parse(t);en(a.version===qe&&a.genesisHash===n.genesisHash&&a.finalEventHash===n.lastEventHash&&a.finalStateHash===Mn(n.core)&&a.eventCount===e.length&&a.executionManifestHash===Mn(n.executionManifest),"REPLAY_MANIFEST_MISMATCH")}return n}function yu(n){return Tl.parse({version:qe,genesisHash:n.genesisHash,finalEventHash:n.lastEventHash,finalStateHash:Mn(n.core),eventCount:n.events.length,executionManifestHash:Mn(n.executionManifest)})}function q_(n){let e=hi(n.setup);for(const t of n.commands)e=Pa(e,t).session;en(e.events.length===n.events.length,"RESIMULATION_LENGTH");for(let t=0;t<n.events.length;t++)en(te(ce(e.events[t]))===te(ce(n.events[t])),`RESIMULATION_MISMATCH_${t}`);en(Mn(e.core)===Mn(n.core),"RESIMULATION_FINAL_STATE")}function po(n){const t={commandId:`auto-${String(n.revision+1).padStart(6,"0")}`,expectedRevision:n.revision};if(n.core.phase==="SETUP")return{...t,actorId:"SYSTEM",kind:"CONFIRM_TEAMS",payload:{}};if(n.core.phase==="TOSS")return{...t,actorId:`AI:${n.setup.teams[0].teamId}`,kind:"CALL_TOSS",payload:{teamId:n.setup.teams[0].teamId,call:"HEADS"}};if(n.core.phase==="AWAITING_INNINGS")return{...t,actorId:`AI:${n.core.tossWinnerId}`,kind:"CHOOSE_INNINGS",payload:{teamId:n.core.tossWinnerId,choice:"BAT"}};const a=oe(n);if(n.core.phase==="AWAITING_BATTER"){const o=pi(n),i=new Set([a.innings.northBatterId,a.innings.southBatterId,...a.innings.dismissed]),r=o.playerIds.find(s=>!i.has(s));return en(r,"NO_ELIGIBLE_BATTER"),{...t,actorId:`AI:${o.teamId}`,kind:"SET_BATTER",payload:{teamId:o.teamId,playerId:r}}}if(n.core.phase==="AWAITING_BOWLER"){const o=Ct(n),i=o.xi.filter(r=>r.bowlingStyle!==null&&r.playerId!==o.keeperId&&r.playerId!==a.innings.previousOverBowlerId&&a.bowling[r.playerId].legalBalls<60).sort((r,s)=>a.bowling[r.playerId].legalBalls-a.bowling[s.playerId].legalBalls||r.playerId.localeCompare(s.playerId));return en(i.length,"NO_ELIGIBLE_BOWLER"),{...t,actorId:`AI:${o.teamId}`,kind:"SET_BOWLER",payload:{teamId:o.teamId,bowlerId:i[0].playerId}}}return en(n.core.phase==="READY","INVALID_AUTOPILOT_PHASE"),{...t,actorId:"SYSTEM",kind:"ADVANCE",payload:{scope:"OVER"}}}function _s(n){en(n.core.phase==="COMPLETE"&&n.core.innings.length===2&&n.core.result,"SCORECARD_NOT_COMPLETE");const e=n.core.innings.map((t,a)=>{le(t);const o=n.events.filter(u=>u.type==="DELIVERY_RECORDED"&&u.payload.event.inningsIndex===a);let i=0,r=0;const s=[];for(const u of o){const h=u.payload.event;i+=h.batRuns+Object.values(h.extras).reduce((p,E)=>p+E,0),r+=Number(h.legalBall),h.dismissal&&s.push({playerId:h.dismissal.playerId,runs:i,legalBalls:r,sequence:u.sequence})}en(i===t.innings.runs&&r===t.innings.legalBalls&&o.length===t.innings.deliveryAttempts,"PROJECTED_SCORE_MISMATCH");const c=t.innings;return{battingTeamId:c.battingTeamId,bowlingTeamId:c.bowlingTeamId,runs:c.runs,wickets:c.wickets,legalBalls:c.legalBalls,overs:`${Math.floor(c.legalBalls/6)}.${c.legalBalls%6}`,extras:St(c.extras),batting:St(t.batting),bowling:St(t.bowling),fallOfWickets:s,targetToWin:c.targetToWin}});return cf.parse({matchId:n.setup.matchId,innings:e,result:n.core.result})}function Z_(n,e,t){en(!!n&&typeof n=="object"&&!Array.isArray(n),"SAVE_SHAPE");const a=n,o=a.setup;en(!!o&&o.setupVersion==="LC_ODI_SETUP_V1","SAVE_SETUP"),en(Array.isArray(o.teams)&&o.teams.length===2,"SAVE_TEAMS");const i=Su({setupVersion:"LC_ODI_SETUP_V1",setup:{schemaVersion:"1.0.0",gameId:o.gameId,matchId:o.matchId,format:"ODI",worldPackId:xn.worldPackId,rulesId:o.versions.rules,modelId:o.versions.model,randomId:o.versions.random,seed:o.seed,teamIds:o.teams.map(s=>s.teamId),groundId:o.ground.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:xn.worldFileSha256,worldCanonicalSha256:o.versions.worldHash,rulesHash:o.versions.rulesHash,modelHash:o.versions.modelHash,stagePackHash:o.stagePackHash,selectedTeams:o.teams.map(s=>({teamId:s.teamId,playerIds:[...s.playerIds],captainId:s.captainId,keeperId:s.keeperId}))},e,t);en(Array.isArray(a.commands),"SAVE_COMMANDS");let r=hi(i);for(const s of a.commands)r=Pa(r,s).session;return en(typeof a.revision=="number"&&r.revision===a.revision,"SAVE_REVISION"),en(Array.isArray(a.events)&&Mn(r.events)===Mn(a.events),"SAVE_EVENTS"),en(a.core!==void 0&&Mn(r.core)===Mn(a.core),"SAVE_CORE"),en(a.receipts!==void 0&&Mn(r.receipts)===Mn(a.receipts),"SAVE_RECEIPTS"),en(a.executionManifest!==void 0&&Mn(r.executionManifest)===Mn(a.executionManifest),"SAVE_MANIFEST"),en(a.genesisHash===r.genesisHash&&a.lastEventHash===r.lastEventHash,"SAVE_CHAIN"),r}const Du=11*3600,Ts=13*3600,Cu=13*3600+2400,Rs=15*3600+2400,ku=16*3600,fi=17*3600,ho=18*3600,X_=18*3600+1800;function Bu(){return{day:1,localSeconds:Du,phase:"PLAY",dayLegalBalls:0,finalHourActive:!1,finalHourBallsRemaining:0,overMustFinish:!1,delaySecondsToday:0}}function vs(n){return n>=Ts&&n<Cu?Cu:n>=Rs&&n<ku?ku:n}function Ei(n){return{...n,day:n.day+1,localSeconds:Du,phase:"PLAY",dayLegalBalls:0,finalHourActive:!1,finalHourBallsRemaining:0,overMustFinish:!1,delaySecondsToday:0}}function Si(n){return n.day===5?ho:n.dayLegalBalls<540?X_:ho}function Pu(n){const e=n%6;return e===0?90:6-e+84}function _i(n,e,t,a){return n.day===5&&!n.finalHourActive&&e<fi&&t>=fi?(n.finalHourActive=!0,n.finalHourBallsRemaining=Pu(a),!0):!1}function As(n){return n.day===5&&n.finalHourActive&&n.localSeconds>=ho&&n.finalHourBallsRemaining===0}function J_(n,e=0){let t={...n,phase:"INNINGS_INTERVAL",overMustFinish:!1};const a=t.localSeconds,o=a+600;if(_i(t,a,o,e),t.localSeconds=o,t.day<5&&t.localSeconds>=Si(t))return t=Ei(t),{clock:t,dayFiveExpired:!1,newDay:!0};const i=As(t);return t.phase=i?"COMPLETE":"PLAY",{clock:t,dayFiveExpired:i,newDay:!1}}function Q_(n,e,t=0){if(!Number.isInteger(e)||e<60)throw new Error("LC_RED5_INVALID_RAIN_DELAY");let a={...n,phase:"RAIN",overMustFinish:!1};const o=a.localSeconds,i=o+e;if(a.delaySecondsToday+=e,_i(a,o,i,t),a.day===5&&a.finalHourActive){const s=Math.max(0,i-Math.max(o,fi));a.finalHourBallsRemaining=Math.max(0,a.finalHourBallsRemaining-6*Math.floor(s/240))}if(a.localSeconds=vs(i),a.day<5&&a.localSeconds>=Si(a))return a=Ei(a),{clock:a,dayFiveExpired:!1,newDay:!0};const r=As(a);return a.phase=r?"COMPLETE":"PLAY",{clock:a,dayFiveExpired:r,newDay:!1}}function n5(n,e=120,t=0){if(!Number.isInteger(e)||e<0)throw new Error("LC_RED5_INVALID_BALL_REPLACEMENT_TIME");let a={...n,overMustFinish:!1};const o=a.localSeconds,i=o+e;if(_i(a,o,i,t),a.localSeconds=vs(i),a.day<5&&a.localSeconds>=Si(a))return a=Ei(a),{clock:a,dayFiveExpired:!1,newDay:!0};const r=As(a);return a.phase=r?"COMPLETE":"PLAY",{clock:a,dayFiveExpired:r,newDay:!1}}function e5(n,e){let t={...n};const a=t.localSeconds,o=e.inningsLegalBalls-(e.legalBall?1:0);t.localSeconds+=e.elapsedSeconds,_i(t,a,t.localSeconds,o),e.legalBall&&(t.dayLegalBalls++,t.finalHourActive&&(t.finalHourBallsRemaining=Math.max(0,t.finalHourBallsRemaining-1))),t.day===5&&!t.finalHourActive&&t.localSeconds>=fi&&(t.finalHourActive=!0,t.finalHourBallsRemaining=Pu(o),e.legalBall&&(t.finalHourBallsRemaining=Math.max(0,t.finalHourBallsRemaining-1)));const i=a<Ts&&t.localSeconds>=Ts||a<Rs&&t.localSeconds>=Rs||a<ho&&t.localSeconds>=ho;if(t.overMustFinish=!e.overCompleted&&i,e.terminalResult)return t.overMustFinish=!1,{clock:t,dayFiveExpired:!1,newDay:!1};if(e.inningsCompleted)return t.overMustFinish=!1,{clock:t,dayFiveExpired:!1,newDay:!1};if(!e.overCompleted)return{clock:t,dayFiveExpired:!1,newDay:!1};t.overMustFinish=!1,t.localSeconds=vs(t.localSeconds);const r=Si(t);return t.localSeconds>=r&&(t.day<5||t.finalHourBallsRemaining===0)?t.day===5?(t.phase="COMPLETE",{clock:t,dayFiveExpired:!0,newDay:!1}):(t=Ei(t),{clock:t,dayFiveExpired:!1,newDay:!0}):(t.phase="PLAY",{clock:t,dayFiveExpired:!1,newDay:!1})}const Xn=qn().hash,t5=Nt(),lt=n=>structuredClone(n),xu=n=>{throw new Error(`LC_RED5_${n}`)};function dn(n,e){n||xu(e)}const a5={line:"STUMPS",length:"GOOD",variationId:"stock",effort:"NORMAL"},Hu=Xn(so),o5=Hu,Ti=(n,e)=>{const t=n.setup.teams.find(a=>a.teamId===e);return dn(t,"UNKNOWN_TEAM"),t},fo=(n,e)=>{const t=n.setup.teams.find(a=>a.teamId!==e);return dn(t,"UNKNOWN_OPPONENT"),t.teamId},kt=(n,e)=>{const t=n.setup.teams.flatMap(a=>a.xi).find(a=>a.playerId===e);return dn(t,"UNKNOWN_PLAYER"),t},ie=n=>{const e=n.core.innings[n.core.activeInningsIndex];return dn(e,"NO_ACTIVE_INNINGS"),e},Ri=n=>Ti(n,ie(n).innings.battingTeamId),Bt=n=>Ti(n,ie(n).innings.bowlingTeamId),Fu=n=>{const e=ya.positions.find(t=>t.slotId===n);return dn(e,"UNKNOWN_FIELD_POSITION"),e};function vi(n,e,t){dn(n.length===9&&new Set(n.map(i=>i.playerId)).size===9&&new Set(n.map(i=>i.slotId)).size===9,"INVALID_FIELD_DUPLICATES"),dn([...n.map(i=>i.playerId)].sort().join("|")===[...e].sort().join("|"),"INVALID_FIELD_IDENTITIES");const a=n.map(i=>Fu(i.slotId)),o=a.filter(i=>t==="R"?i.legSide:!i.legSide);dn(o.length<=5,"INVALID_FIELD_LEG_SIDE"),dn(o.filter(i=>i.behindSquare).length<=2,"INVALID_FIELD_BEHIND_SQUARE")}function i5(n,e,t){const a=Ti(n,e),o=Ti(n,fo(n,e)),i=Object.fromEntries(a.playerIds.map(u=>[u,{runs:0,ballsFaced:0,fours:0,sixes:0,dismissed:!1}])),r=Object.fromEntries(o.playerIds.map(u=>[u,{runsConceded:0,legalBalls:0,wickets:0,maidens:0}])),s=Object.fromEntries(o.playerIds.map(u=>[u,0])),c=o.playerIds.filter(u=>u!==o.keeperId).slice(0,9);return le({engineVersion:Qe,rulesId:"LC_RED5_01",nextDeliveryIndex:n.core.globalAttemptOrdinal,batting:i,bowling:r,dismissals:{},keeperId:o.keeperId,outfieldIds:c,currentOverRuns:0,innings:{index:t,battingTeamId:e,bowlingTeamId:o.teamId,runs:0,wickets:0,legalBalls:0,deliveryAttempts:0,targetToWin:t===3?Math.max(1,Mu(n,o.teamId)-Mu(n,e)+1):null,allocatedBalls:null,extras:{wides:0,noBalls:0,byes:0,legByes:0,penalties:0},northBatterId:null,southBatterId:null,strikerEnd:"NORTH",battingOrder:[...a.playerIds],dismissed:[],bowlerId:null,previousOverBowlerId:null,bowlerLegalBalls:s,freeHitPending:!1,ballAgeLegalBalls:0,complete:!1}})}function r5(n){return dn(Ss(n)&&Object.isFrozen(n)&&n.setupVersion==="LC_RED5_SETUP_V1","INVALID_FROZEN_SETUP"),dn(n.versions.worldHash===xn.worldCanonicalSha256&&n.versions.modelHash===Cn&&n.stagePackHash===Zn&&n.versions.rulesHash===si("LC_RED5_01")&&n.versions.random===jn,"UNSUPPORTED_PINNED_SETUP"),vl.parse({engine:Rl,eventChain:nt,conditionPolicy:Er,conditionPolicyHash:Hu,setupHash:Xn(n),worldHash:n.versions.worldHash,rulesHash:n.versions.rulesHash,modelHash:n.versions.modelHash,stagePackHash:n.stagePackHash,randomVersion:jn,scoringVersion:Qe,probabilityVersion:se})}function Ai(n){const e=r5(n),t=Xn(n),a={phase:"SETUP",setupHash:t,tossWinnerId:null,tossCallerId:null,battingFirstId:null,inningsOrder:[],activeInningsIndex:0,innings:[],declared:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:lt(n.ground.pitchPrior),fatigueBp:Object.fromEntries(n.teams.flatMap(i=>i.playerIds).map(i=>[i,0])),clock:Bu(),followOnEnforced:!1,newBallsTaken:0},o=Xn([nt,t,Xn(e)]);return{setup:n,executionManifest:e,core:a,revision:0,events:[],receipts:{},commands:[],genesisHash:o,lastEventHash:o}}function Mu(n,e){return n.core.innings.filter(t=>t.innings.battingTeamId===e).reduce((t,a)=>t+a.innings.runs,0)}function s5(n,e,t=!1){const[a,o]=n,i=b=>e.filter(w=>w.teamId===b),r=b=>i(b).reduce((w,v)=>w+v.runs,0),s=b=>i(b).filter(w=>w.complete).length,c=r(a),u=r(o),h=s(a),p=s(o);let E=null;if(e.length>=3){const b=e.slice(0,3),w=T=>b.filter(A=>A.teamId===T).length,v=e[3]?.teamId??(w(a)===1?a:w(o)===1?o:null);if(v){const T=v===a?o:a,A=I=>b.filter(f=>f.teamId===I).reduce((f,S)=>f+S.runs,0);E=Math.max(1,A(T)-A(v)+1)}}return h===2&&p<2&&c<u?{result:{kind:"WIN",winnerTeamId:o,marginType:"INNINGS",marginRuns:u-c,marginWickets:null,completionReason:"INNINGS_VICTORY"},targetToWin:null}:p===2&&h<2&&u<c?{result:{kind:"WIN",winnerTeamId:a,marginType:"INNINGS",marginRuns:c-u,marginWickets:null,completionReason:"INNINGS_VICTORY"},targetToWin:null}:h===2&&p===2?c===u?{result:{kind:"TIE",winnerTeamId:null,marginType:null,marginRuns:null,marginWickets:null,completionReason:"CHASE_COMPLETE_LEVEL"},targetToWin:E}:{result:{kind:"WIN",winnerTeamId:c>u?a:o,marginType:"RUNS",marginRuns:Math.abs(c-u),marginWickets:null,completionReason:"CHASE_COMPLETE_SHORT"},targetToWin:E}:t?{result:{kind:"DRAW",winnerTeamId:null,marginType:null,marginRuns:null,marginWickets:null,completionReason:"TIME_EXPIRED"},targetToWin:E}:{result:null,targetToWin:E}}function bs(n){const e=n.setup.teams.map(t=>t.teamId);return s5(e,n.core.innings.map(t=>({teamId:t.innings.battingTeamId,runs:t.innings.runs,complete:t.innings.complete}))).result}function Eo(n,e){const t=n.core.innings.length;n.core.inningsOrder.push(e),n.core.innings.push(i5(n,e,t)),n.core.declared.push(!1),n.core.activeInningsIndex=t,n.core.fieldSlots=[],n.core.bowlingPlan=null,n.core.phase="AWAITING_BATTER",n.core.clock.phase="PLAY"}function c5(n,e,t,a){const o=!!n.core.result,i=e5(n.core.clock,{elapsedSeconds:e.elapsedSeconds+(e.dismissal?90:0)+(t?60:0),legalBall:e.legalBall,overCompleted:t,inningsCompleted:a,inningsLegalBalls:ie(n).innings.legalBalls,terminalResult:o});n.core.clock=i.clock,i.dayFiveExpired&&!n.core.result&&(n.core.result={kind:"DRAW",winnerTeamId:null,marginType:null,marginRuns:null,marginWickets:null,completionReason:"time expired after day five"},n.core.phase="COMPLETE",n.core.clock.phase="COMPLETE")}function l5(n){const e=J_(n.core.clock,ie(n).innings.legalBalls);n.core.clock=e.clock,e.dayFiveExpired&&!n.core.result&&(n.core.result={kind:"DRAW",winnerTeamId:null,marginType:null,marginRuns:null,marginWickets:null,completionReason:"time expired during innings interval"},n.core.phase="COMPLETE")}function Vu(n){const e=bs(n);if(e){n.core.result=e,n.core.phase="COMPLETE",n.core.clock.phase="COMPLETE";return}l5(n);const t=n.core.innings.length-1;if(t===0){Eo(n,fo(n,n.core.innings[0].innings.battingTeamId));return}if(t===1){const a=n.core.innings[0],o=n.core.innings[1],i=a.innings.runs-o.innings.runs;if(a.innings.battingTeamId===n.core.battingFirstId&&i>=200){n.core.phase="AWAITING_FOLLOW_ON";return}Eo(n,n.core.battingFirstId);return}if(t===2){Eo(n,fo(n,n.core.innings[2].innings.battingTeamId));return}if(t===3){const a=bs(n);a&&(n.core.result=a,n.core.phase="COMPLETE",n.core.clock.phase="COMPLETE")}}function d5(n,e,t,a){const o=kt(n,e.bowlerId),i=!(o.bowlingStyle==="FAST"||o.bowlingStyle==="MEDIUM"),r=i?12:20,s=so.effortFactorBp[t];if(n.core.fatigueBp[e.bowlerId]=Math.min(1e4,n.core.fatigueBp[e.bowlerId]+Math.floor((r*s+5e3)/1e4)),e.legalBall){const c=lt(n.core.pitch);c.wearPoints+=1,c.wearPoints%100===0&&(c.turnBp=Math.min(1e4,c.turnBp+20),c.variabilityBp=Math.min(1e4,c.variabilityBp+10),c.seamBp=Math.max(0,c.seamBp-10)),n.core.pitch=c}if(a)for(const c of Bt(n).playerIds)c!==e.bowlerId&&(n.core.fatigueBp[c]=Math.max(0,n.core.fatigueBp[c]-15))}function Wu(n,e,t){const a=n.core;switch(e){case"TEAMS_CONFIRMED":a.phase="TOSS";break;case"TOSS_RESOLVED":a.tossWinnerId=t.winnerId,a.tossCallerId=t.callerId,a.phase="AWAITING_INNINGS";break;case"INNINGS_STARTED":a.battingFirstId||(a.battingFirstId=t.battingTeamId),Eo(n,t.battingTeamId);break;case"BATTER_SELECTED":{const o=ie(n),i=t.playerId;if(o.innings.northBatterId===null&&o.innings.southBatterId===null){const s=lt(o);s.innings.northBatterId=i,a.innings[a.activeInningsIndex]=le(s)}else a.innings[a.activeInningsIndex]=lo(o,i);const r=ie(n).innings;a.phase=r.northBatterId===null||r.southBatterId===null?"AWAITING_BATTER":r.bowlerId===null?"AWAITING_BOWLER":"READY";break}case"BOWLER_SELECTED":{const o=ie(n),i=t.playerId;dn(i!==o.innings.previousOverBowlerId,"CONSECUTIVE_BOWLER");const r=Bt(n).playerIds.filter(s=>s!==Bt(n).keeperId&&s!==i);a.innings[a.activeInningsIndex]=ai(o,i,r),a.bowlingPlan={...a5,bowlerId:i},a.fieldSlots=[...r].sort().map((s,c)=>({slotId:ds[c],playerId:s})),vi(a.fieldSlots,r,kt(n,Fe(ie(n)).strikerId).batHand),a.phase="READY";break}case"FIELD_CHANGED":vi(t.fieldSlots,ie(n).outfieldIds,kt(n,Fe(ie(n)).strikerId).batHand),a.fieldSlots=lt(t.fieldSlots);break;case"BATTING_PLAN_CHANGED":a.battingPlans[t.playerId]={aggression:t.aggression,intent:t.intent};break;case"BOWLING_PLAN_CHANGED":dn(t.variationId==="stock","UNSUPPORTED_VARIATION"),a.bowlingPlan=lt(t);break;case"DELIVERY_RECORDED":{const o=t.event,i=ti(ie(n),o);a.innings[a.activeInningsIndex]=i.ledger,a.globalAttemptOrdinal++;let r=null;i.observation.inningsComplete&&(r=a.activeInningsIndex===3&&i.observation.result?i.observation.result:bs(n),r&&(a.result=r));const s=o.legalBall&&i.ledger.innings.legalBalls%6===0;d5(n,o,a.bowlingPlan.effort,s),c5(n,o,s,i.observation.inningsComplete),r?(a.phase="COMPLETE",a.clock.phase="COMPLETE"):i.observation.inningsComplete?(a.phase="INTERVAL",Vu(n)):a.phase!=="COMPLETE"&&(a.phase=i.observation.requiredBatterEnd?"AWAITING_BATTER":i.observation.overCompleted?"AWAITING_BOWLER":"READY");break}case"DECLARED":{const o=lt(ie(n));o.innings.complete=!0,a.innings[a.activeInningsIndex]=le(o),a.declared[a.activeInningsIndex]=!0,Vu(n);break}case"FOLLOW_ON_CHOSEN":{dn(a.phase==="AWAITING_FOLLOW_ON","WRONG_PHASE"),a.followOnEnforced=!!t.enforce;const o=a.innings[0],i=a.innings[1];Eo(n,t.enforce?i.innings.battingTeamId:o.innings.battingTeamId);break}case"NEW_BALL_TAKEN":{const o=lt(ie(n));dn(o.innings.ballAgeLegalBalls>=480,"NEW_BALL_NOT_AVAILABLE"),o.innings.ballAgeLegalBalls=0,a.innings[a.activeInningsIndex]=le(o),a.newBallsTaken++;const i=n5(a.clock,120,o.innings.legalBalls);a.clock=i.clock,i.dayFiveExpired&&!a.result&&(a.result={kind:"DRAW",winnerTeamId:null,marginType:null,marginRuns:null,marginWickets:null,completionReason:"time expired during new-ball replacement"},a.phase="COMPLETE");break}case"RAIN_DELAY":{const o=Q_(a.clock,t.seconds,ie(n).innings.legalBalls);a.clock=o.clock,o.dayFiveExpired&&(a.result={kind:"DRAW",winnerTeamId:null,marginType:null,marginRuns:null,marginWickets:null,completionReason:"time expired after day-five weather delay"},a.phase="COMPLETE");break}default:xu("UNKNOWN_EVENT")}}function We(n,e,t,a){Wu(n,t,a);const o=n.events.length+1,i=n.lastEventHash,r=Xn(n.core),s=Xn([nt,o,e,t,a,i,r]),c=bl.parse({version:nt,sequence:o,commandId:e,type:t,payload:a,previousHash:i,stateHash:r,eventHash:s});n.events.push(c),n.lastEventHash=s}function u5(n){const e=ie(n),t=Fe(e),a=kt(n,t.strikerId),o=kt(n,t.bowlerId),i=kt(n,t.keeperId),r=a.skills.RED_BALL,s=o.skills.RED_BALL;vi(n.core.fieldSlots,e.outfieldIds,a.batHand);const c={kind:"GENERATE_DELIVERY",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:Zn,randomVersion:jn,probabilityVersion:se,modelId:Be,modelHash:Cn,lutVersion:ze,lutHash:tt,rulesHash:n.setup.versions.rulesHash,matchId:n.setup.matchId,seed:n.setup.seed,attemptOrdinal:n.core.globalAttemptOrdinal,format:"RED_BALL",phase:"RED_BALL",context:t,bowling:{bowlingStyle:o.bowlingStyle,controlRating:s.control,movementRating:s.movement,fatigueBp:n.core.fatigueBp[o.playerId],line:n.core.bowlingPlan.line,intendedLength:n.core.bowlingPlan.length,effort:n.core.bowlingPlan.effort,variationId:"stock"},batting:{defenceRating:r.defence,timingRating:r.timing,powerRating:r.power,rotationRating:r.rotation,vsPaceRating:r.vsPace,vsSpinRating:r.vsSpin,aggression:n.core.battingPlans[a.playerId]?.aggression??2,intent:n.core.battingPlans[a.playerId]?.intent??"NORMAL",attemptedStroke:!0,shotSectorWeights:[...a.shotSectorWeights]},conditions:{seamBp:n.core.pitch.seamBp,turnBp:n.core.pitch.turnBp},field:{keeper:{keepingRating:i.skills.RED_BALL.keeping,catchingRating:i.skills.RED_BALL.catching,throwingRating:i.skills.RED_BALL.throwing},slots:n.core.fieldSlots.map(h=>{const p=kt(n,h.playerId),E=Fu(h.slotId);return{playerId:h.playerId,sector:E.sector,depth:E.depth,role:h.slotId.startsWith("slip")?"SLIP":"NORMAL",catchingRating:p.skills.RED_BALL.catching,throwingRating:p.skills.RED_BALL.throwing}})}},u=ci(c);return{event:ei(t,u.resolution),traceHash:Xn(u.trace)}}function m5(n,e,t,a){We(n,e,"DELIVERY_RECORDED",{type:"DELIVERY_RECORDED",event:t,attemptOrdinal:n.core.globalAttemptOrdinal,traceHash:a})}function g5(n,e,t){const a=Math.floor(ie(n).innings.legalBalls/6);let o=0;for(;n.core.phase==="READY"&&o++<60;){const i=u5(n);if(m5(n,e,i.event,i.traceHash),t==="DELIVERY"||n.core.phase!=="READY"||Math.floor(ie(n).innings.legalBalls/6)!==a)break}dn(o<60,"ADVANCE_ATTEMPT_LIMIT")}function Ue(n,e){const t=Al.parse(e),a=n.receipts[t.commandId];if(a)return{session:n,receipt:a};dn(t.expectedRevision===n.revision,"STALE_REVISION");const o={...n,core:lt(n.core),events:[...n.events],receipts:{...n.receipts},commands:[...n.commands]},i=o.events.length+1,r=t.commandId,s=u=>dn(t.actorId===`USER:${u}`||t.actorId===`AI:${u}`||t.actorId==="SYSTEM","ACTOR_UNAUTHORISED");switch(t.kind){case"CONFIRM_TEAMS":dn(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),dn(o.core.phase==="SETUP","WRONG_PHASE"),We(o,r,"TEAMS_CONFIRMED",{type:"TEAMS_CONFIRMED"});break;case"CALL_TOSS":s(t.payload.teamId),dn(o.core.phase==="TOSS","WRONG_PHASE");{const u=t5.uint32({seed:o.setup.seed,domain:"TOSS",entityId:o.setup.matchId,eventOrdinal:0,stageName:"coin",drawIndex:0})%2===0?"HEADS":"TAILS",h=u===t.payload.call?t.payload.teamId:fo(o,t.payload.teamId);We(o,r,"TOSS_RESOLVED",{type:"TOSS_RESOLVED",callerId:t.payload.teamId,winnerId:h,coin:u,call:t.payload.call})}break;case"CHOOSE_INNINGS":s(t.payload.teamId),dn(o.core.phase==="AWAITING_INNINGS","WRONG_PHASE"),dn(t.payload.teamId===o.core.tossWinnerId,"NOT_TOSS_WINNER"),We(o,r,"INNINGS_STARTED",{type:"INNINGS_STARTED",battingTeamId:t.payload.choice==="BAT"?t.payload.teamId:fo(o,t.payload.teamId)});break;case"SET_BATTER":s(t.payload.teamId),dn(o.core.phase==="AWAITING_BATTER"&&t.payload.teamId===Ri(o).teamId,"WRONG_TEAM_OR_PHASE"),We(o,r,"BATTER_SELECTED",{type:"BATTER_SELECTED",playerId:t.payload.playerId});break;case"SET_BOWLER":s(t.payload.teamId),dn(o.core.phase==="AWAITING_BOWLER"&&t.payload.teamId===Bt(o).teamId,"WRONG_TEAM_OR_PHASE"),dn(kt(o,t.payload.bowlerId).bowlingStyle!==null,"INELIGIBLE_BOWLER"),We(o,r,"BOWLER_SELECTED",{type:"BOWLER_SELECTED",playerId:t.payload.bowlerId});break;case"SET_FIELD":s(t.payload.teamId),dn(o.core.phase==="READY"&&t.payload.teamId===Bt(o).teamId,"WRONG_TEAM_OR_PHASE"),We(o,r,"FIELD_CHANGED",{type:"FIELD_CHANGED",fieldSlots:t.payload.fieldSlots});break;case"SET_BATTING_PLAN":s(Ri(o).teamId),dn(o.core.phase==="READY","WRONG_PHASE"),We(o,r,"BATTING_PLAN_CHANGED",{type:"BATTING_PLAN_CHANGED",...t.payload});break;case"SET_BOWLING_PLAN":s(Bt(o).teamId),dn(o.core.phase==="READY","WRONG_PHASE"),We(o,r,"BOWLING_PLAN_CHANGED",{type:"BOWLING_PLAN_CHANGED",...t.payload});break;case"ADVANCE":dn(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),dn(o.core.phase==="READY","WRONG_PHASE"),g5(o,r,t.payload.scope);break;case"DECLARE":s(t.payload.teamId),dn(t.payload.teamId===Ri(o).teamId&&o.core.phase==="READY","WRONG_TEAM_OR_PHASE"),We(o,r,"DECLARED",{type:"DECLARED",teamId:t.payload.teamId});break;case"CHOOSE_FOLLOW_ON":s(t.payload.teamId),dn(o.core.phase==="AWAITING_FOLLOW_ON","WRONG_PHASE"),dn(t.payload.teamId===o.core.battingFirstId,"FOLLOW_ON_AUTHORITY"),We(o,r,"FOLLOW_ON_CHOSEN",{type:"FOLLOW_ON_CHOSEN",enforce:t.payload.enforce});break;case"TAKE_NEW_BALL":s(t.payload.teamId),dn(t.payload.teamId===Bt(o).teamId&&o.core.phase==="READY","WRONG_TEAM_OR_PHASE"),dn(ie(o).innings.legalBalls%6===0&&ie(o).innings.ballAgeLegalBalls>=480,"NEW_BALL_NOT_AVAILABLE"),We(o,r,"NEW_BALL_TAKEN",{type:"NEW_BALL_TAKEN"});break;case"ADD_RAIN_DELAY":dn(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),We(o,r,"RAIN_DELAY",{type:"RAIN_DELAY",seconds:t.payload.seconds});break}dn(o.events.length>=i,"COMMAND_WITH_NO_EVENT"),o.revision=n.revision+1;const c=df.parse({commandId:r,committedRevision:o.revision,fromSequence:i,toSequence:o.events.length,lastEventHash:o.lastEventHash});return o.receipts[r]=c,o.commands.push(t),{session:o,receipt:c}}function I5(n,e,t){return Uu(Ai(n),e,t)}function Uu(n,e,t){dn(n.revision===0&&n.events.length===0&&n.core.phase==="SETUP","REPLAY_INITIAL_STATE");for(const[a,o]of e.entries()){const i=bl.parse(o);dn(i.sequence===a+1&&i.previousHash===n.lastEventHash,"REPLAY_CHAIN_GAP"),dn(i.eventHash===Xn([nt,i.sequence,i.commandId,i.type,i.payload,i.previousHash,i.stateHash]),"REPLAY_EVENT_HASH"),Wu(n,i.type,i.payload),dn(i.stateHash===Xn(n.core),"REPLAY_STATE_HASH"),n.events.push(i),n.lastEventHash=i.eventHash}if(t){const a=wl.parse(t);dn(a.finalEventHash===n.lastEventHash&&a.finalStateHash===Xn(n.core)&&a.eventCount===e.length,"REPLAY_MANIFEST_MISMATCH")}return n}function $u(n){return wl.parse({version:nt,genesisHash:n.genesisHash,finalEventHash:n.lastEventHash,finalStateHash:Xn(n.core),eventCount:n.events.length,executionManifestHash:Xn(n.executionManifest)})}function p5(n){let e=Ai(n.setup);for(const t of n.commands)e=Ue(e,t).session;dn(e.events.length===n.events.length,"RESIMULATION_LENGTH");for(let t=0;t<n.events.length;t++)dn(te(ce(e.events[t]))===te(ce(n.events[t])),`RESIMULATION_MISMATCH_${t}`)}function ra(n){const e={commandId:`auto-${String(n.revision+1).padStart(6,"0")}`,expectedRevision:n.revision};if(n.core.phase==="SETUP")return{...e,actorId:"SYSTEM",kind:"CONFIRM_TEAMS",payload:{}};if(n.core.phase==="TOSS")return{...e,actorId:`AI:${n.setup.teams[0].teamId}`,kind:"CALL_TOSS",payload:{teamId:n.setup.teams[0].teamId,call:"HEADS"}};if(n.core.phase==="AWAITING_INNINGS")return{...e,actorId:`AI:${n.core.tossWinnerId}`,kind:"CHOOSE_INNINGS",payload:{teamId:n.core.tossWinnerId,choice:"BAT"}};if(n.core.phase==="AWAITING_FOLLOW_ON")return{...e,actorId:`AI:${n.core.battingFirstId}`,kind:"CHOOSE_FOLLOW_ON",payload:{teamId:n.core.battingFirstId,enforce:!0}};const t=ie(n);if(n.core.phase==="AWAITING_BATTER"){const a=Ri(n),o=new Set([t.innings.northBatterId,t.innings.southBatterId,...t.innings.dismissed]),i=a.playerIds.find(r=>!o.has(r));return dn(i,"NO_ELIGIBLE_BATTER"),{...e,actorId:`AI:${a.teamId}`,kind:"SET_BATTER",payload:{teamId:a.teamId,playerId:i}}}if(n.core.phase==="AWAITING_BOWLER"){const a=Bt(n),o=a.xi.filter(i=>i.bowlingStyle!==null&&i.playerId!==a.keeperId&&i.playerId!==t.innings.previousOverBowlerId).sort((i,r)=>i.playerId.localeCompare(r.playerId))[0];return dn(o,"NO_ELIGIBLE_BOWLER"),{...e,actorId:`AI:${a.teamId}`,kind:"SET_BOWLER",payload:{teamId:a.teamId,bowlerId:o.playerId}}}return dn(n.core.phase==="READY","INVALID_AUTOPILOT_PHASE"),{...e,actorId:"SYSTEM",kind:"ADVANCE",payload:{scope:"OVER"}}}function ws(n){return dn(n.core.phase==="COMPLETE"&&n.core.result,"SCORECARD_NOT_COMPLETE"),mf.parse({matchId:n.setup.matchId,innings:n.core.innings.map((e,t)=>({battingTeamId:e.innings.battingTeamId,bowlingTeamId:e.innings.bowlingTeamId,runs:e.innings.runs,wickets:e.innings.wickets,legalBalls:e.innings.legalBalls,overs:`${Math.floor(e.innings.legalBalls/6)}.${e.innings.legalBalls%6}`,declared:n.core.declared[t]??!1,batting:lt(e.batting),bowling:lt(e.bowling)})),result:n.core.result,clock:n.core.clock,followOnEnforced:n.core.followOnEnforced})}function h5(n,e,t){dn(!!n&&typeof n=="object"&&!Array.isArray(n),"SAVE_SHAPE");const a=n,o=a.setup;dn(!!o&&o.setupVersion==="LC_RED5_SETUP_V1","SAVE_SETUP");const i={setupVersion:"LC_RED5_SETUP_V1",setup:{schemaVersion:"1.0.0",gameId:o.gameId,matchId:o.matchId,format:"RED_BALL",worldPackId:xn.worldPackId,rulesId:o.versions.rules,modelId:o.versions.model,randomId:o.versions.random,seed:o.seed,teamIds:o.teams.map(c=>c.teamId),groundId:o.ground.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:xn.worldFileSha256,worldCanonicalSha256:o.versions.worldHash,rulesHash:o.versions.rulesHash,modelHash:o.versions.modelHash,stagePackHash:o.stagePackHash,selectedTeams:o.teams.map(c=>({teamId:c.teamId,playerIds:[...c.playerIds],captainId:c.captainId,keeperId:c.keeperId}))},r=_u(i,e,t);dn(Array.isArray(a.commands),"SAVE_COMMANDS");let s=Ai(r);for(const c of a.commands)s=Ue(s,c).session;return dn(typeof a.revision=="number"&&s.revision===a.revision,"SAVE_REVISION"),dn(Array.isArray(a.events)&&Xn(s.events)===Xn(a.events),"SAVE_EVENTS"),dn(a.core!==void 0&&Xn(s.core)===Xn(a.core),"SAVE_CORE"),dn(a.receipts!==void 0&&Xn(s.receipts)===Xn(a.receipts),"SAVE_RECEIPTS"),dn(a.executionManifest!==void 0&&Xn(s.executionManifest)===Xn(a.executionManifest),"SAVE_MANIFEST"),dn(a.genesisHash===s.genesisHash&&a.lastEventHash===s.lastEventHash,"SAVE_CHAIN"),s}qn(),qn(),new Set(KS),new Map(Object.entries(zS).flatMap(([n,e])=>e.map(t=>[t,n]))),qn();function Gu(n,e){if(!n)throw new Error(`LC_T20_OFFSCREEN_${e}`)}function f5(n){const{seasonId:e,fixtureId:t,matchId:a,matchDayDate:o,session:i}=n;Gu(i.core.phase==="COMPLETE","CONDITION_DELTA_REQUIRES_COMPLETE_MATCH"),Gu(i.setup.matchId===a,"CONDITION_DELTA_MATCH_ID_MISMATCH");const r=i.setup.teams.flatMap(c=>[...c.playerIds]).sort(),s=Object.fromEntries(r.map(c=>[c,i.core.fatigueBp[c]??0]).filter(([,c])=>c>0));return Tr.parse({deltaVersion:"LC_T20_MATCH_CONDITION_DELTA_V1",matchCompletionKey:`complete-${e}-${t}`,matchId:a,matchDayDate:o,playerFatigueDeltaBp:s})}const ju=Object.fromEntries(Object.keys(Sa.shape).map(n=>[n,50]));function E5(n,e,t){if(new TextEncoder().encode(n).byteLength>Ul)throw new Error("Roster import exceeds 25 MB.");const a=Kf.parse(JSON.parse(n)),o=qn().hash(a),i=[],r=a.world.players.map(p=>{const E={},b={};for(const w of yr){const v=p.skills?.[w]??{},T=Object.keys(ju).filter(I=>!(I in v)),A=p.exposureBalls?.[w]===void 0;(T.length||A)&&i.push({playerId:p.playerId,format:w,fields:T,exposureMissing:A}),E[w]=Sa.parse({...ju,...v}),b[w]=p.exposureBalls?.[w]??0}return{...p,skills:E,exposureBalls:b,provenance:{kind:"USER_SUPPLIED",sourceId:a.sourceId,sourceHash:o,confidenceBp:1e3}}}),s=mr({...a.world,packId:`world-import-${o}`,provenance:`User-supplied roster ${a.sourceId}; source ${o}`,players:r},t,e);if([...s.players,...s.teams,...s.grounds].map(p=>p.name).some(p=>p!==p.trim()||[...p].some(E=>{const b=E.codePointAt(0);return b<32||b>=127&&b<=159})))throw new Error("Names cannot contain control characters or surrounding spaces.");const u=new Map(s.players.map(p=>[p.playerId,p])),h=new Set;for(const p of s.teams){const E=p.squadIds.map(b=>u.get(b));if(!E.some(b=>b.role==="KEEPER")||E.filter(b=>b.bowlingStyle!==null&&["BOWLER","ALLROUNDER"].includes(b.role)).length<5)throw new Error(`Roster cannot form a valid XI: ${p.teamId}`);for(const b of E){if(h.has(b.playerId))throw new Error(`Player belongs to multiple squads: ${b.playerId}`);h.add(b.playerId)}}if(h.size!==s.players.length)throw new Error("Every imported player must belong to one squad.");return{world:s,sourceHash:o,priorFields:i}}const Os=new WeakMap,Yu=new WeakMap,zu=new Map;function S5(n,e){return`${n.join(",")}|${e.join(",")}`}function _5(n,e){Ls(n);let t=Os.get(n);return t||(t=new Set,Os.set(n,t)),t.add(e),n}function T5(n,e,t){return xe.parse({version:"LC_STAGED_ROSTER_PACK_V1",sourceText:n,...E5(n,e,t)})}function R5(n,e,t){const a=S5(e,t);if(n!==null&&typeof n=="object"&&Object.isFrozen(n)&&Os.get(n)?.has(a))return n;const o=xe.parse(n),i=T5(o.sourceText,e,t);if(G(o)!==G(i))throw new Error("Roster pack contents do not match the staged source and priors.");return _5(o,a)}function v5(n,e,t,a){const o=R5(n,t,a),i=Gl.parse(e);if(!o.world.grounds.some(c=>c.groundId===i.groundId))throw new Error("Unknown match ground.");if(i.teams[0].teamId===i.teams[1].teamId)throw new Error("Match teams must differ.");const r=new Map(o.world.players.map(c=>[c.playerId,c])),s=new Set;for(const c of i.teams){const u=o.world.teams.find(h=>h.teamId===c.teamId);if(!u||new Set(c.playerIds).size!==11||c.playerIds.some(h=>!u.squadIds.includes(h)))throw new Error("Invalid team or XI membership.");if(!c.playerIds.includes(c.captainId)||!c.playerIds.includes(c.keeperId)||r.get(c.keeperId)?.role!=="KEEPER")throw new Error("Select an eligible captain and keeper.");if(c.playerIds.filter(h=>{const p=r.get(h);return p.bowlingStyle!==null&&["BOWLER","ALLROUNDER"].includes(p.role)}).length<5)throw new Error("The XI needs five bowling-capable players.");for(const h of c.playerIds){if(s.has(h))throw new Error("An XI player cannot play for both sides.");s.add(h)}}return{pack:o,selection:i}}function Ls(n){return n!==null&&typeof n=="object"&&(Object.values(n).forEach(Ls),Object.freeze(n)),n}function Ns(n,e){const t=jl.parse(e),{pack:a,selection:o}=v5(n,t.selection,yt.map(p=>p.rulesId),pe.manifest.variationIds),i=yt.find(p=>p.format===t.format&&a.world.rulesIds.includes(p.rulesId));if(!i)throw new Error("The roster does not support this match format.");const r=new Map(a.world.players.map(p=>[p.playerId,p])),s=o.teams.map(p=>{const E=a.world.teams.find(b=>b.teamId===p.teamId);return{teamId:E.teamId,name:E.name,colours:E.colours,playerIds:p.playerIds,xi:p.playerIds.map(b=>r.get(b)),captainId:p.captainId,keeperId:p.keeperId}});let c=Yu.get(a);if(!c){const p=qn().hash;c={worldHash:p(a.world),rosterPackHash:p(a)},Object.isFrozen(a)&&Yu.set(a,c)}let u=zu.get(i.rulesId);u||(u=qn().hash(i),zu.set(i.rulesId,u));const h=structuredClone({version:"LC_ROSTER_MATCH_PREPARATION_V1",gameId:t.gameId,matchId:t.matchId,seed:t.seed,format:t.format,worldHash:c.worldHash,rosterPackHash:c.rosterPackHash,rulesId:i.rulesId,rulesHash:u,modelHash:Cn,stagePackHash:Zn,ground:a.world.grounds.find(p=>p.groundId===o.groundId),teams:s});return Ls(h)}const De=qn().hash,ys=new WeakMap,Pt=n=>{throw new Error(`LC_ROSTER_T20_${n}`)};function Ds(n){const e=n.events.at(-1),t=n.events[0];return De({setupVersion:n.setup.setupVersion,rosterPackHash:n.setup.rosterPackHash,manifestEngine:n.executionManifest.engine,manifestSetupHash:n.executionManifest.setupHash,revision:n.revision,genesisHash:n.genesisHash,lastEventHash:n.lastEventHash,eventCount:n.events.length,firstEventHash:t?t.eventHash:null,tailEventHash:e?e.eventHash:null,commandCount:n.commands.length,core:n.core})}function A5(n,e){(n.format!=="T20"||n.teams.length!==2)&&Pt("FORMAT");const t={setupVersion:"LC_T20_ROSTER_SETUP_V2",gameId:n.gameId,matchId:n.matchId,seed:n.seed,format:"T20",teams:n.teams,ground:n.ground,versions:{schema:"1.0.0",engine:"LC_T20_ROSTER_SETUP_V2",random:jn,rules:n.rulesId,rulesHash:n.rulesHash,model:pe.manifest.modelId,modelHash:n.modelHash,worldHash:n.worldHash},stagePackHash:n.stagePackHash,modelStatus:"SYNTHETIC_ALPHA",worldSeed:e,fixtureOnly:!0,rosterPackHash:n.rosterPackHash};return Object.freeze(t.versions),Object.freeze(t)}function Cs(n,e){const t=Ns(n,e),a=A5(t,n.sourceHash),o=De(a),i=Yl.parse({engine:"LC_T20_MATCH_ROSTER_V2",eventChain:Ke,conditionPolicy:pr,conditionPolicyHash:b_,setupHash:o,worldHash:a.versions.worldHash,rulesHash:a.versions.rulesHash,modelHash:a.versions.modelHash,stagePackHash:a.stagePackHash,randomVersion:jn,scoringVersion:Qe,probabilityVersion:se}),r={phase:"SETUP",setupHash:o,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:structuredClone(a.ground.pitchPrior),fatigueBp:Object.fromEntries(a.teams.flatMap(u=>u.playerIds).map(u=>[u,0]))},s=De([Ke,o,De(i)]),c={setup:a,executionManifest:i,core:r,revision:0,events:[],receipts:{},commands:[],genesisHash:s,lastEventHash:s};return ys.set(c,Ds(c)),c}function ks(n,e){const t=ys.get(n);t||Pt("SESSION_UNVERIFIED"),Ds(n)!==t&&Pt("SESSION_TAMPERED");const a=ka(n,e),o=a.session;return ys.set(o,Ds(o)),{session:o,receipt:a.receipt}}function Ku(n,e){(!n||typeof n!="object"||Array.isArray(n))&&Pt("SAVE_SHAPE");const t=n,a=t.setup;if(!a)throw new Error("LC_ROSTER_T20_SAVE_SETUP");(a.setupVersion!=="LC_T20_ROSTER_SETUP_V2"||!Array.isArray(a.teams)||a.teams.length!==2)&&Pt("SAVE_SETUP");let o=Cs(e,{gameId:a.gameId,matchId:a.matchId,seed:a.seed,format:"T20",selection:{groundId:a.ground.groundId,teams:a.teams.map(i=>({teamId:i.teamId,playerIds:[...i.playerIds],captainId:i.captainId,keeperId:i.keeperId}))}});G(o.setup)!==G(a)&&Pt("SAVE_SETUP_MISMATCH"),Array.isArray(t.commands)||Pt("SAVE_COMMANDS");for(const i of t.commands)o=ks(o,i).session;return(t.revision!==o.revision||De(t.core)!==De(o.core)||De(t.events)!==De(o.events)||De(t.commands)!==De(o.commands)||De(t.receipts)!==De(o.receipts)||De(t.executionManifest)!==De(o.executionManifest)||t.genesisHash!==o.genesisHash||t.lastEventHash!==o.lastEventHash)&&Pt("SAVE_REPLAY_MISMATCH"),o}function b5(n,e){const t=Ku(n,e),a=t.setup,o=Cs(e,{gameId:a.gameId,matchId:a.matchId,seed:a.seed,format:"T20",selection:{groundId:a.ground.groundId,teams:a.teams.map(i=>({teamId:i.teamId,playerIds:[...i.playerIds],captainId:i.captainId,keeperId:i.keeperId}))}});return Au(o,t.events,bu(t))}const he=qn().hash,Bs=new WeakMap,xt=n=>{throw new Error(`LC_ROSTER_ODI_${n}`)};function w5(n,e){(n.format!=="ODI"||n.teams.length!==2)&&xt("FORMAT");const t={setupVersion:"LC_ODI_ROSTER_SETUP_V2",gameId:n.gameId,matchId:n.matchId,seed:n.seed,format:"ODI",teams:n.teams,ground:n.ground,versions:{schema:"1.0.0",engine:"LC_ODI_ROSTER_SETUP_V2",random:jn,rules:n.rulesId,rulesHash:n.rulesHash,model:pe.manifest.modelId,modelHash:n.modelHash,worldHash:n.worldHash},stagePackHash:n.stagePackHash,modelStatus:"SYNTHETIC_ALPHA",worldSeed:e,fixtureOnly:!0,rosterPackHash:n.rosterPackHash};return Object.freeze(t.versions),Object.freeze(t)}function Ps(n,e){const t=Ns(n,e),a=w5(t,n.sourceHash),o=he(a),i=qf.parse({engine:"LC_ODI_MATCH_ROSTER_V2",eventChain:qe,conditionPolicy:fr,conditionPolicyHash:M_,setupHash:o,worldHash:a.versions.worldHash,rulesHash:a.versions.rulesHash,modelHash:a.versions.modelHash,stagePackHash:a.stagePackHash,randomVersion:jn,scoringVersion:Qe,probabilityVersion:se}),r={phase:"SETUP",setupHash:o,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:structuredClone(a.ground.pitchPrior),fatigueBp:Object.fromEntries(a.teams.flatMap(u=>u.playerIds).map(u=>[u,0]))},s=he([qe,o,he(i)]),c={setup:a,executionManifest:i,core:r,revision:0,events:[],receipts:{},commands:[],genesisHash:s,lastEventHash:s};return Bs.set(c,he(c)),c}function xs(n,e){const t=Bs.get(n);t||xt("SESSION_UNVERIFIED"),he(n)!==t&&xt("SESSION_TAMPERED");const a=Pa(n,e),o=a.session;return Bs.set(o,he(o)),{session:o,receipt:a.receipt}}function qu(n,e){(!n||typeof n!="object"||Array.isArray(n))&&xt("SAVE_SHAPE");const t=n,a=t.setup;if(!a)throw new Error("LC_ROSTER_ODI_SAVE_SETUP");(a.setupVersion!=="LC_ODI_ROSTER_SETUP_V2"||!Array.isArray(a.teams)||a.teams.length!==2)&&xt("SAVE_SETUP");let o=Ps(e,{gameId:a.gameId,matchId:a.matchId,seed:a.seed,format:"ODI",selection:{groundId:a.ground.groundId,teams:a.teams.map(i=>({teamId:i.teamId,playerIds:[...i.playerIds],captainId:i.captainId,keeperId:i.keeperId}))}});G(o.setup)!==G(a)&&xt("SAVE_SETUP_MISMATCH"),Array.isArray(t.commands)||xt("SAVE_COMMANDS");for(const i of t.commands)o=xs(o,i).session;return(t.revision!==o.revision||he(t.core)!==he(o.core)||he(t.events)!==he(o.events)||he(t.commands)!==he(o.commands)||he(t.receipts)!==he(o.receipts)||he(t.executionManifest)!==he(o.executionManifest)||t.genesisHash!==o.genesisHash||t.lastEventHash!==o.lastEventHash)&&xt("SAVE_REPLAY_MISMATCH"),o}function O5(n,e){const t=qu(n,e),a=t.setup,o=Ps(e,{gameId:a.gameId,matchId:a.matchId,seed:a.seed,format:"ODI",selection:{groundId:a.ground.groundId,teams:a.teams.map(i=>({teamId:i.teamId,playerIds:[...i.playerIds],captainId:i.captainId,keeperId:i.keeperId}))}});return Nu(o,t.events,yu(t))}const fe=qn().hash,Hs=new WeakMap,Ht=n=>{throw new Error(`LC_ROSTER_RED5_${n}`)};function L5(n,e){(n.format!=="RED_BALL"||n.teams.length!==2)&&Ht("FORMAT");const t={setupVersion:"LC_RED5_ROSTER_SETUP_V2",gameId:n.gameId,matchId:n.matchId,seed:n.seed,format:"RED_BALL",teams:n.teams,ground:n.ground,versions:{schema:"1.0.0",engine:"LC_RED5_ROSTER_SETUP_V2",random:jn,rules:n.rulesId,rulesHash:n.rulesHash,model:pe.manifest.modelId,modelHash:n.modelHash,worldHash:n.worldHash},stagePackHash:n.stagePackHash,modelStatus:"SYNTHETIC_ALPHA",worldSeed:e,fixtureOnly:!0,rosterPackHash:n.rosterPackHash};return Object.freeze(t.versions),Object.freeze(t)}function Fs(n,e){const t=Ns(n,e),a=L5(t,n.sourceHash),o=fe(a),i=Zf.parse({engine:"LC_RED5_MATCH_ROSTER_V2",eventChain:nt,conditionPolicy:Er,conditionPolicyHash:o5,setupHash:o,worldHash:a.versions.worldHash,rulesHash:a.versions.rulesHash,modelHash:a.versions.modelHash,stagePackHash:a.stagePackHash,randomVersion:jn,scoringVersion:Qe,probabilityVersion:se}),r={phase:"SETUP",setupHash:o,tossWinnerId:null,tossCallerId:null,battingFirstId:null,inningsOrder:[],activeInningsIndex:0,innings:[],declared:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:structuredClone(a.ground.pitchPrior),fatigueBp:Object.fromEntries(a.teams.flatMap(u=>u.playerIds).map(u=>[u,0])),clock:Bu(),followOnEnforced:!1,newBallsTaken:0},s=fe([nt,o,fe(i)]),c={setup:a,executionManifest:i,core:r,revision:0,events:[],receipts:{},commands:[],genesisHash:s,lastEventHash:s};return Hs.set(c,fe(c)),c}function bi(n,e){const t=Hs.get(n);t||Ht("SESSION_UNVERIFIED"),fe(n)!==t&&Ht("SESSION_TAMPERED");const a=Ue(n,e),o=a.session;return Hs.set(o,fe(o)),{session:o,receipt:a.receipt}}function Zu(n,e){(!n||typeof n!="object"||Array.isArray(n))&&Ht("SAVE_SHAPE");const t=n,a=t.setup;if(!a)throw new Error("LC_ROSTER_RED5_SAVE_SETUP");(a.setupVersion!=="LC_RED5_ROSTER_SETUP_V2"||!Array.isArray(a.teams)||a.teams.length!==2)&&Ht("SAVE_SETUP");let o=Fs(e,{gameId:a.gameId,matchId:a.matchId,seed:a.seed,format:"RED_BALL",selection:{groundId:a.ground.groundId,teams:a.teams.map(i=>({teamId:i.teamId,playerIds:[...i.playerIds],captainId:i.captainId,keeperId:i.keeperId}))}});G(o.setup)!==G(a)&&Ht("SAVE_SETUP_MISMATCH"),Array.isArray(t.commands)||Ht("SAVE_COMMANDS");for(const i of t.commands)o=bi(o,i).session;return(t.revision!==o.revision||fe(t.core)!==fe(o.core)||fe(t.events)!==fe(o.events)||fe(t.commands)!==fe(o.commands)||fe(t.receipts)!==fe(o.receipts)||fe(t.executionManifest)!==fe(o.executionManifest)||t.genesisHash!==o.genesisHash||t.lastEventHash!==o.lastEventHash)&&Ht("SAVE_REPLAY_MISMATCH"),o}function N5(n,e){const t=Zu(n,e),a=t.setup,o=Fs(e,{gameId:a.gameId,matchId:a.matchId,seed:a.seed,format:"RED_BALL",selection:{groundId:a.ground.groundId,teams:a.teams.map(i=>({teamId:i.teamId,playerIds:[...i.playerIds],captainId:i.captainId,keeperId:i.keeperId}))}});return Uu(o,t.events,$u(t))}qn().hash,qn().hash,qn().hash,qn(),qn(),qn(),yt.map(n=>n.rulesId),pe.manifest.variationIds,Xl.parse({modelVersion:Zl,calibrationStatus:"FICTIONAL_PLACEHOLDER",disclaimer:"Fictional player lifecycle parameters (v1): permanent skill development, ageing, retirement, and youth intake use deterministic gameplay curves and are not empirically calibrated. Contracts and budgets are excluded.",minPermanentSkill:18,maxPermanentSkill:86,youthMinAgeYears:17,youthMaxAgeYears:19,growthWindowMaxAgeYears:25,primeWindowMaxAgeYears:30,earliestVoluntaryRetirementAgeYears:34,mandatoryRetirementAgeYears:40,minSquadKeepers:2,minSquadBowlingCapable:7}),id.parse({modelVersion:ad,calibrationStatus:"FICTIONAL_PLACEHOLDER",disclaimer:"Fictional domestic contract system (v1): symmetrical club wage budgets, player market valuations, persistent negotiation rounds, and buyout dead-cap rules use deterministic gameplay parameters. Auctions and international release rules are deferred.",annualClubWageBudgetK:HE,minAnnualWageK:FE,maxAnnualWageK:ME,youthRookieAnnualWageK:VE,minContractTermSeasons:od,maxContractTermSeasons:na,maxNegotiationRounds:ea,releaseBuyoutPercent:WE,minFreeAgentPoolSize:UE,maxFreeAgentPoolSize:$E});const y5="LC_RED5_CONTINUATION_V1";function Xu(n,e,t){const a=structuredClone(n),o=`${y5}:${n.setup.seed}:rev${n.revision}:${e}:r${t}`,i={...a.setup,seed:o};return Object.freeze(i),{...a,setup:i}}function Ms(n,e){const t=n.core.innings.filter(o=>o.innings.battingTeamId===e).reduce((o,i)=>o+i.innings.runs,0),a=n.core.innings.filter(o=>o.innings.battingTeamId!==e).reduce((o,i)=>o+i.innings.runs,0);return t-a}function Ju(n,e){const t=n.core.result;return n.core.phase!=="COMPLETE"||!t?{completed:!1,winnerTeamId:null,isDraw:!1,isTie:!1,wonByInnings:!1,evaluatingTeamLeadRuns:Ms(n,e)}:{completed:!0,winnerTeamId:t.kind==="WIN"?t.winnerTeamId:null,isDraw:t.kind==="DRAW",isTie:t.kind==="TIE",wonByInnings:t.kind==="WIN"&&t.marginType==="INNINGS",evaluatingTeamLeadRuns:Ms(n,e)}}function D5(n){const e=n.liveSession.core.activeInningsIndex,t=n.liveSession.core.innings[e];if(!t||n.liveSession.core.phase!=="READY"||e>=3)throw new Error("LC_RED5_DECLARATION_EVAL_INVALID_STATE");const a=t.innings.battingTeamId,o=t.innings.legalBalls;let i=Xu(n.liveSession,`DECL_${n.action}`,n.rolloutIndex),r=0;for(n.action==="DECLARE_NOW"&&(i=Ue(i,{commandId:`plan-decl-${i.revision+1}`,expectedRevision:i.revision,actorId:`AI:${a}`,kind:"DECLARE",payload:{teamId:a}}).session,r++);i.core.phase!=="COMPLETE"&&r<n.maxCommands;){if(n.action==="BAT_ON"&&i.core.phase==="READY"&&i.core.activeInningsIndex===e&&i.core.innings[e].innings.legalBalls-o>=n.continueOversBeforeReview*6){i=Ue(i,{commandId:`plan-baton-decl-${i.revision+1}`,expectedRevision:i.revision,actorId:`AI:${a}`,kind:"DECLARE",payload:{teamId:a}}).session,r++;continue}i=Ue(i,ra(i)).session,r++}return Ju(i,a)}function C5(n){if(n.liveSession.core.phase!=="AWAITING_FOLLOW_ON"||!n.liveSession.core.battingFirstId)throw new Error("LC_RED5_FOLLOW_ON_EVAL_INVALID_STATE");const e=n.liveSession.core.battingFirstId;let t=Xu(n.liveSession,`FO_${n.action}`,n.rolloutIndex);t=Ue(t,{commandId:`plan-fo-${t.revision+1}`,expectedRevision:t.revision,actorId:`AI:${e}`,kind:"CHOOSE_FOLLOW_ON",payload:{teamId:e,enforce:n.action==="ENFORCE"}}).session;let a=1;for(;t.core.phase!=="COMPLETE"&&a<n.maxCommands;){if(n.action==="BAT_AGAIN"&&t.core.phase==="READY"&&t.core.activeInningsIndex===2&&t.core.clock.day>=4&&Ms(t,e)>=360){t=Ue(t,{commandId:`plan-fo-decl-${t.revision+1}`,expectedRevision:t.revision,actorId:`AI:${e}`,kind:"DECLARE",payload:{teamId:e}}).session,a++;continue}t=Ue(t,ra(t)).session,a++}return Ju(t,e)}const k5="LC_RED5_WEATHER_SCHEDULE_V1",B5="LC_RED5_WEATHER_FORECAST_V1",P5="WEATHER",x5="PREDICTION",Qu=Nt(),nm=11*3600,H5=15;function F5(n,e,t,a){const o=$S[t],i=o.DRY+o.OVERCAST+o.RAIN,r=Qu.uint32({seed:n,domain:P5,entityId:e,eventOrdinal:a,stageName:"markov_segment",drawIndex:0})%i;return r<o.DRY?"DRY":r<o.DRY+o.OVERCAST?"OVERCAST":"RAIN"}function em(n,e){const t=[];let a="DRY",o=1;for(const i of[1,2,3,4,5])for(let r=0;r<H5;r++){a=F5(n,e,a,o++);const s=nm+r*ro;t.push({segmentKey:`d${i}-s${r}`,day:i,segmentIndex:r,startLocalSeconds:s,endLocalSeconds:s+ro,state:a})}return{version:k5,matchId:e,segmentSeconds:ro,segments:t}}function M5(n){const e=em(n.seed,n.matchId),t=e.segments.filter(b=>b.day===n.day&&b.endLocalSeconds>n.localSeconds),a=t.length>0?t:e.segments.filter(b=>b.day===Math.min(5,n.day+1)),o=a.length===0?0:a.reduce((b,w)=>b+(w.state==="RAIN"?100:w.state==="OVERCAST"?35:5),0)/a.length,i=Math.max(0,Math.floor((n.localSeconds-nm)/3600)),r=Qu.uint32({seed:n.seed,domain:x5,entityId:n.matchId,eventOrdinal:n.day*50+i,stageName:"forecast_noise",drawIndex:0})%25,s=Math.max(5,Math.min(90,Math.round(o+(r-12)))),c=Math.max(0,Math.floor((s-10)/5)*5),u=Math.min(95,Math.max(c+15,Math.ceil((s+10)/5)*5)),h=s>=50?"HIGH":s>=25?"MODERATE":"LOW",p=h==="HIGH"?"WET":h==="MODERATE"?"UNSETTLED":"CLEAR",E=p==="WET"?`Uncertain Day ${n.day} forecast: heavy cloud and high interruption risk (${c}% to ${u}% rain chance).`:p==="UNSETTLED"?`Uncertain Day ${n.day} forecast: unsettled skies with passing showers possible (${c}% to ${u}% rain chance).`:`Uncertain Day ${n.day} forecast: mostly fair conditions (${c}% to ${u}% shower chance).`;return{version:B5,day:n.day,outlook:p,rainRiskBand:h,estimatedRainChanceRangePct:[c,u],summaryText:E}}function tm(n){const e=n.session.core;if(e.phase!=="READY"||e.innings.length===0||e.clock.phase!=="PLAY")return null;const t=e.innings[e.activeInningsIndex];if(!t||t.innings.legalBalls%6!==0)return null;const o=em(n.session.setup.seed,n.session.setup.matchId).segments.find(i=>i.day===e.clock.day&&e.clock.localSeconds>=i.startLocalSeconds&&e.clock.localSeconds<i.endLocalSeconds);return!o||o.state!=="RAIN"||n.appliedSegmentKeys.has(o.segmentKey)?null:{segmentKey:o.segmentKey,delaySeconds:ro,command:{commandId:`weather-${o.segmentKey}-r${n.session.revision+1}`,expectedRevision:n.session.revision,actorId:"SYSTEM",kind:"ADD_RAIN_DELAY",payload:{seconds:ro}}}}const V5=qn(),W5=n=>V5.hash(n),am=n=>structuredClone(n),U5=n=>{throw new Error(`LC_SUPER_OVER_${n}`)};function Vn(n,e){n||U5(e)}const wi=3,$5=6,G5={T20:{ledgerRulesId:"LC_T20_01",allocatedBalls:120,slots:ls,validateField:Ca,rulesId:bd,recordSchemaId:Vr},ODI:{ledgerRulesId:"LC_ODI_01",allocatedBalls:300,slots:au,validateField:Ba,rulesId:Wr,recordSchemaId:Ur}};function xa(n){return G5[n.setup.format]}function So(n,e){const t=n.setup.teams.find(a=>a.teamId===e);return Vn(t,"UNKNOWN_TEAM"),t}function om(n,e){const t=n.setup.teams.find(a=>a.teamId!==e);return Vn(t,"UNKNOWN_TEAM"),t.teamId}function Ha(n,e){const t=n.setup.teams.flatMap(a=>a.xi).find(a=>a.playerId===e);return Vn(t,"UNKNOWN_PLAYER"),t}function j5(n){const e=ya.positions.find(t=>t.slotId===n);return Vn(e,"UNKNOWN_FIELD_POSITION"),e}function im(n){return(n.setup.format==="T20"||n.setup.format==="ODI")&&n.core.phase==="COMPLETE"&&n.core.result?.kind==="TIE"}function Oi(n,e,t){const a=new Set(e.excludedBatters[t]??[]);return So(n,t).playerIds.filter(o=>!a.has(o))}function Li(n,e,t){const a=So(n,t),o=new Set(e.excludedBowlers[t]??[]);return a.playerIds.filter(i=>i!==a.keeperId&&Ha(n,i).bowlingStyle!==null&&!o.has(i))}function Fa(n){const e=n.rounds[n.rounds.length-1];Vn(e,"NO_ROUND");const t=e.innings[e.innings.length-1];return Vn(t,"NO_INNINGS"),t}function Y5(n){return n.rounds[n.rounds.length-1].innings.length===1?0:1}function z5(n,e,t){return Oi(n,e,t).length>=2&&Li(n,e,om(n,t)).length>=1}function Vs(n,e,t){const a=e.rounds[e.rounds.length-1];if(!z5(n,e,t)){e.phase="COMPLETE",e.completionReason="NO_ELIGIBLE_PLAYERS";return}a.innings.push({battingTeamId:t,bowlingTeamId:om(n,t),batterIds:null,bowlerId:null,ledger:null,complete:!1}),e.phase="AWAITING_LINEUP"}function rm(n){Vn(im(n),"MATCH_NOT_TIED");const e=n.core.innings[1]?.innings.battingTeamId;Vn(e,"NO_SECOND_INNINGS");const t={rulesId:xa(n).rulesId,gameId:n.setup.gameId,baseLastEventHash:n.lastEventHash,rounds:[{roundNumber:1,innings:[]}],phase:"AWAITING_LINEUP",attemptOrdinal:n.core.globalAttemptOrdinal,firstBattingTeamId:e,excludedBatters:Object.fromEntries(n.setup.teams.map(a=>[a.teamId,[]])),excludedBowlers:Object.fromEntries(n.setup.teams.map(a=>[a.teamId,[]])),aggression:{},deliveries:[],winnerTeamId:null,completionReason:null};return Vs(n,t,e),t}function K5(n,e,t,a){const o=So(n,t.battingTeamId),i=So(n,t.bowlingTeamId),r=[...t.batterIds,...o.playerIds.filter(s=>!t.batterIds.includes(s))];return le({engineVersion:Qe,rulesId:xa(n).ledgerRulesId,nextDeliveryIndex:e.attemptOrdinal,batting:Object.fromEntries(o.playerIds.map(s=>[s,{runs:0,ballsFaced:0,fours:0,sixes:0,dismissed:!1}])),bowling:Object.fromEntries(i.playerIds.map(s=>[s,{runsConceded:0,legalBalls:0,wickets:0,maidens:0}])),dismissals:{},keeperId:i.keeperId,outfieldIds:i.playerIds.filter(s=>s!==i.keeperId).slice(0,9),currentOverRuns:0,innings:{index:Y5(e),battingTeamId:o.teamId,bowlingTeamId:i.teamId,runs:0,wickets:0,legalBalls:0,deliveryAttempts:0,targetToWin:a,allocatedBalls:xa(n).allocatedBalls,extras:{wides:0,noBalls:0,byes:0,legByes:0,penalties:0},northBatterId:null,southBatterId:null,strikerEnd:"NORTH",battingOrder:r,dismissed:[],bowlerId:null,previousOverBowlerId:null,bowlerLegalBalls:Object.fromEntries(i.playerIds.map(s=>[s,0])),freeHitPending:!1,ballAgeLegalBalls:0,complete:!1}})}function sm(n,e){const t=Fa(e);if(!t.batterIds||!t.bowlerId)return;const a=e.rounds[e.rounds.length-1],o=a.innings.length===2?a.innings[0].ledger.innings.runs+1:null;let i=K5(n,e,t,o);const r=am(i);r.innings.northBatterId=t.batterIds[0],i=lo(le(r),t.batterIds[1]);const s=So(n,t.bowlingTeamId),c=s.playerIds.filter(u=>u!==s.keeperId&&u!==t.bowlerId);i=ai(i,t.bowlerId,c),t.ledger=i,e.phase="READY"}function q5(n,e){const t=xa(n).slots;return[...e.outfieldIds].sort().map((a,o)=>({slotId:t[o],playerId:a}))}function Z5(n,e){const t=Fa(e),a=t.ledger,o=Fe(a),i=Ha(n,o.strikerId),r=Ha(n,o.bowlerId),s=Ha(n,o.keeperId),c=n.setup.format,u=q5(n,a);xa(n).validateField(u,a.outfieldIds,i.batHand,a.innings.legalBalls);const h=ci({kind:"GENERATE_DELIVERY",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:Zn,randomVersion:jn,probabilityVersion:se,modelId:Be,modelHash:Cn,lutVersion:ze,lutHash:tt,rulesHash:n.setup.versions.rulesHash,matchId:n.setup.matchId,seed:n.setup.seed,attemptOrdinal:e.attemptOrdinal,format:c,phase:ri(c,a.innings.legalBalls),context:o,bowling:{bowlingStyle:r.bowlingStyle,controlRating:r.skills[c].control,movementRating:r.skills[c].movement,fatigueBp:n.core.fatigueBp[r.playerId]??0,line:"STUMPS",intendedLength:"GOOD",effort:"NORMAL",variationId:"stock"},batting:{defenceRating:i.skills[c].defence,timingRating:i.skills[c].timing,powerRating:i.skills[c].power,rotationRating:i.skills[c].rotation,vsPaceRating:i.skills[c].vsPace,vsSpinRating:i.skills[c].vsSpin,aggression:e.aggression[i.playerId]??3,intent:"NORMAL",attemptedStroke:!0,shotSectorWeights:[...i.shotSectorWeights]},conditions:{seamBp:n.core.pitch.seamBp,turnBp:n.core.pitch.turnBp},field:{keeper:{keepingRating:s.skills[c].keeping,catchingRating:s.skills[c].catching,throwingRating:s.skills[c].throwing},slots:u.map(T=>{const A=Ha(n,T.playerId),I=j5(T.slotId);return{playerId:T.playerId,sector:I.sector,depth:I.depth,role:T.slotId.startsWith("slip")?"SLIP":"NORMAL",catchingRating:A.skills[c].catching,throwingRating:A.skills[c].throwing}})}}),p=ei(o,h.resolution),E=ti(a,p);t.ledger=E.ledger,e.attemptOrdinal+=1,e.deliveries.push(p);const b=E.ledger.innings,w=t.batterIds.length-1,v=b.targetToWin!==null&&b.runs>=b.targetToWin;if(b.legalBalls>=$5||b.wickets>=w||v||b.complete)X5(n,e);else if(E.observation.requiredBatterEnd){const T=t.batterIds.find(A=>!b.dismissed.includes(A)&&A!==b.northBatterId&&A!==b.southBatterId);Vn(T,"NO_NEXT_BATTER"),t.ledger=lo(E.ledger,T)}}function X5(n,e){const t=Fa(e);t.complete=!0;const a=t.ledger.innings;e.excludedBatters[t.battingTeamId]=[...new Set([...e.excludedBatters[t.battingTeamId]??[],...a.dismissed])],e.excludedBowlers[t.bowlingTeamId]=[...new Set([...e.excludedBowlers[t.bowlingTeamId]??[],t.bowlerId])];const o=e.rounds[e.rounds.length-1];if(o.innings.length===1){Vs(n,e,t.bowlingTeamId);return}const i=o.innings[0].ledger.innings.runs,r=a.runs;if(i!==r){e.winnerTeamId=r>i?t.battingTeamId:t.bowlingTeamId,e.completionReason="WON",e.phase="COMPLETE";return}e.rounds.push({roundNumber:o.roundNumber+1,innings:[]}),Vs(n,e,t.battingTeamId)}function cm(n,e,t){const a=Xo.parse(t),o=am(e);Vn(o.phase!=="COMPLETE","COMPLETE");const i=Fa(o);switch(a.kind){case"SET_SUPER_OVER_BATTERS":{Vn(o.phase==="AWAITING_LINEUP"&&i.batterIds===null,"WRONG_PHASE"),Vn(a.teamId===i.battingTeamId,"NOT_BATTING_TEAM");const r=new Set(Oi(n,o,a.teamId));Vn(new Set(a.playerIds).size===a.playerIds.length,"DUPLICATE_BATTER"),Vn(a.playerIds.every(s=>r.has(s)),"INELIGIBLE_BATTER"),Vn(a.playerIds.length===Math.min(wi,r.size),"BATTER_COUNT"),i.batterIds=[...a.playerIds],sm(n,o);break}case"SET_SUPER_OVER_BOWLER":{Vn(o.phase==="AWAITING_LINEUP"&&i.bowlerId===null,"WRONG_PHASE"),Vn(a.teamId===i.bowlingTeamId,"NOT_BOWLING_TEAM"),Vn(Li(n,o,a.teamId).includes(a.playerId),"INELIGIBLE_BOWLER"),i.bowlerId=a.playerId,sm(n,o);break}case"SET_SUPER_OVER_AGGRESSION":{Vn(o.phase==="READY","WRONG_PHASE");const r=i.ledger.innings;Vn([r.northBatterId,r.southBatterId].includes(a.playerId),"BATTER_NOT_ACTIVE"),o.aggression[a.playerId]=a.aggression;break}case"BOWL_SUPER_OVER_BALL":{Vn(o.phase==="READY","WRONG_PHASE"),Z5(n,o);break}}return o}function J5(n,e){if(e.phase==="COMPLETE")return null;if(e.phase==="READY")return{kind:"BOWL_SUPER_OVER_BALL"};const t=Fa(e);if(t.batterIds===null){const o=Oi(n,e,t.battingTeamId);return{kind:"SET_SUPER_OVER_BATTERS",teamId:t.battingTeamId,playerIds:o.slice(0,wi)}}const a=Li(n,e,t.bowlingTeamId).map(o=>Ha(n,o)).sort((o,i)=>i.skills[n.setup.format].control-o.skills[n.setup.format].control||(o.playerId<i.playerId?-1:1));return{kind:"SET_SUPER_OVER_BOWLER",teamId:t.bowlingTeamId,playerId:a[0].playerId}}function lm(n){if(n.phase!=="AWAITING_LINEUP")return null;const e=Fa(n);return e.batterIds===null?{teamId:e.battingTeamId,decision:"BATTERS"}:{teamId:e.bowlingTeamId,decision:"BOWLER"}}function Q5(n){return n.rounds.map(e=>({roundNumber:e.roundNumber,innings:e.innings.filter(t=>t.ledger!==null).map(t=>({battingTeamId:t.battingTeamId,runs:t.ledger.innings.runs,wickets:t.ledger.innings.wickets,legalBalls:t.ledger.innings.legalBalls}))}))}function dm(n){return W5(n)}function nT(n,e){let t=rm(n);for(const a of e)t=cm(n,t,a);return t}function um(n,e){return oa.parse({schemaId:n.rulesId===Wr?Ur:Vr,rulesId:n.rulesId,gameId:n.gameId,baseLastEventHash:n.baseLastEventHash,commands:[...e],stateSha256:dm(n)})}function mm(n,e){const t=oa.parse(e);Vn(t.rulesId===xa(n).rulesId,"RECORD_FORMAT_MISMATCH"),Vn(t.gameId===n.setup.gameId&&t.baseLastEventHash===n.lastEventHash,"RECORD_MATCH_MISMATCH");const a=nT(n,t.commands);return Vn(dm(a)===t.stateSha256,"RECORD_STATE_MISMATCH"),a}Nt(),qn(),Nt();function eT(n){return Array.from(n,e=>e.toString(16).padStart(2,"0")).join("")}async function tT(n){const e=new TextEncoder().encode(n),t=await crypto.subtle.digest("SHA-256",e);return eT(new Uint8Array(t))}async function Ni(n){const e=Ra.parse(n);if(await tT(G(e.world))!==e.worldCanonicalSha256)throw new Error("WORLD_COPY_HASH_MISMATCH");return e}ld.omit({completedSeasons:!0}),dd.omit({completedSeasons:!0});const Ws="LC_ARCHIVE_V1",yi="LC_ARCHIVE_V2_PRESENTATION",Di="LC_ARCHIVE_V3_ROSTER",Ma="LC_ARCHIVE_V4_DELEGATION",Ci="LC_ARCHIVE_V5_SUPER_OVER",gm=20*1024*1024,aT=50*1024*1024,oT=32,it=new TextEncoder,Ft=new TextDecoder("utf-8",{fatal:!0});function zn(n){return[n&255,n>>>8&255]}function $e(n){return[n&255,n>>>8&255,n>>>16&255,n>>>24&255]}function ki(n,e){return n[e]|n[e+1]<<8}function Bi(n,e){return(n[e]|n[e+1]<<8|n[e+2]<<16|n[e+3]<<24)>>>0}function Im(n){const e=n.reduce((o,i)=>o+i.length,0),t=new Uint8Array(e);let a=0;for(const o of n)t.set(o,a),a+=o.length;return t}const iT=(()=>{const n=new Uint32Array(256);for(let e=0;e<256;e++){let t=e;for(let a=0;a<8;a++)t=t&1?3988292384^t>>>1:t>>>1;n[e]=t>>>0}return n})();function pm(n){let e=4294967295;for(const t of n)e=iT[(e^t)&255]^e>>>8;return(e^4294967295)>>>0}function rT(n){return!!n&&!n.startsWith("/")&&!n.startsWith("\\")&&!/^[A-Za-z]:/.test(n)&&!n.split(/[\\/]/).some(e=>e===".."||e==="")}function sT(n){const e=[],t=[];let a=0;for(const r of n){const s=it.encode(r.name),c=pm(r.data),u=Uint8Array.from([...$e(67324752),...zn(20),...zn(0),...zn(0),...zn(0),...zn(0),...$e(c),...$e(r.data.length),...$e(r.data.length),...zn(s.length),...zn(0),...s]);e.push(u,r.data);const h=Uint8Array.from([...$e(33639248),...zn(20),...zn(20),...zn(0),...zn(0),...zn(0),...zn(0),...$e(c),...$e(r.data.length),...$e(r.data.length),...zn(s.length),...zn(0),...zn(0),...zn(0),...zn(0),...$e(0),...$e(a),...s]);t.push(h),a+=u.length+r.data.length}const o=Im(t),i=Uint8Array.from([...$e(101010256),...zn(0),...zn(0),...zn(n.length),...zn(n.length),...$e(o.length),...$e(a),...zn(0)]);return Im([...e,o,i])}function cT(n,e=gm,t=aT){if(!(n instanceof Uint8Array)||n.length<22||n.length>e)throw new Error("ARCHIVE_SIZE_INVALID");const a=new Map;let o=0,i=0;for(;o+4<=n.length&&Bi(n,o)===67324752;){if(a.size>=oT)throw new Error("ARCHIVE_TOO_MANY_FILES");if(o+30>n.length)throw new Error("ARCHIVE_TRUNCATED");const r=ki(n,o+6),s=ki(n,o+8),c=Bi(n,o+14),u=Bi(n,o+18),h=Bi(n,o+22),p=ki(n,o+26),E=ki(n,o+28);if(r!==0||s!==0||u!==h)throw new Error("ARCHIVE_COMPRESSION_UNSUPPORTED");const b=o+30,w=b+p+E,v=w+h;if(v>n.length)throw new Error("ARCHIVE_TRUNCATED");const T=Ft.decode(n.slice(b,b+p));if(!rT(T)||a.has(T))throw new Error("ARCHIVE_PATH_INVALID");if(i+=h,i>t)throw new Error("ARCHIVE_EXPANDED_SIZE_INVALID");const A=n.slice(w,v);if(pm(A)!==c)throw new Error("ARCHIVE_CRC_MISMATCH");a.set(T,A),o=v}if(a.size===0)throw new Error("ARCHIVE_EMPTY");return a}function hm(n,e){const t=me(e.setup,"ARCHIVE_SETUP");if(n.gameId!==t.gameId||n.baseLastEventHash!==e.lastEventHash)throw new Error("ARCHIVE_SUPER_OVER_MATCH_MISMATCH")}function me(n,e){if(!n||typeof n!="object"||Array.isArray(n))throw new Error(`${e}_INVALID`);return n}function fm(n,e){const t=me(e.setup,"ARCHIVE_SETUP"),a=Array.isArray(t.teams)?t.teams.map(o=>me(o,"ARCHIVE_TEAM").teamId):[];if(!Number.isSafeInteger(e.revision)||n.changes.some(o=>o.matchRevision>Number(e.revision)||!a.includes(o.teamId)))throw new Error("ARCHIVE_DELEGATION_SESSION_MISMATCH")}function _o(n,e,t){const a=me(n,t),o=Object.keys(a).sort(),i=[...e].sort();if(o.length!==i.length||o.some((r,s)=>r!==i[s]))throw new Error(`${t}_FIELDS_INVALID`)}function lT(n,e){if(typeof n!="string"||n.length===0)throw new Error(`${e}_INVALID`)}function Us(n,e){if(!Number.isSafeInteger(n)||Number(n)<0)throw new Error(`${e}_INVALID`)}function dT(n){_o(n,["saveId","kind","title","matchGameId","matchId","teams","ground","phase","revision","eventCount","lastEventHash","updatedAt","completed"],"ARCHIVE_SUMMARY");const e=n;for(const t of["saveId","title","matchGameId","matchId","ground","phase","updatedAt"])lT(e[t],`ARCHIVE_SUMMARY_${t}`);if(!["AUTO","MANUAL","IMPORTED"].includes(e.kind))throw new Error("ARCHIVE_SUMMARY_kind_INVALID");if(!Array.isArray(e.teams)||e.teams.length!==2||e.teams.some(t=>typeof t!="string"||t.length===0))throw new Error("ARCHIVE_SUMMARY_teams_INVALID");if(Us(e.revision,"ARCHIVE_SUMMARY_revision"),Us(e.eventCount,"ARCHIVE_SUMMARY_eventCount"),typeof e.lastEventHash!="string"||typeof e.completed!="boolean"||Number.isNaN(Date.parse(String(e.updatedAt))))throw new Error("ARCHIVE_SUMMARY_FIELDS_INVALID")}function uT(n,e=["game.json","events.ndjson"]){_o(n,e,"ARCHIVE_FILES");const t=n;for(const a of e){_o(t[a],["bytes","sha256"],`ARCHIVE_FILE_${a}`);const o=t[a];if(Us(o.bytes,`ARCHIVE_FILE_${a}_bytes`),typeof o.sha256!="string"||!/^[0-9a-f]{64}$/.test(o.sha256))throw new Error(`ARCHIVE_FILE_${a}_sha256_INVALID`)}}function Em(n,e){const t=me(n.setup,"ARCHIVE_SETUP"),a=me(t.versions,"ARCHIVE_SETUP_VERSIONS"),o=me(n.executionManifest,"ARCHIVE_EXECUTION"),i={engine:o.engine,eventChain:o.eventChain,random:a.random,model:a.model,modelHash:a.modelHash,rules:a.rules,rulesHash:a.rulesHash,worldHash:a.worldHash},r=t.setupVersion==="LC_T20_ROSTER_SETUP_V2"?"LC_T20_MATCH_ROSTER_V2":t.setupVersion==="LC_ODI_ROSTER_SETUP_V2"?"LC_ODI_MATCH_ROSTER_V2":t.setupVersion==="LC_RED5_ROSTER_SETUP_V2"?"LC_RED5_MATCH_ROSTER_V2":null;if(G(e)!==G(i)||o.engine!==r||o.worldHash!==a.worldHash||o.modelHash!==a.modelHash||o.rulesHash!==a.rulesHash||o.randomVersion!==a.random)throw new Error("ARCHIVE_ROSTER_PINS_MISMATCH")}async function mT(n,e,t,a,o=null,i=null,r=null,s=null){const c=me(n,"ARCHIVE_SESSION"),u=c.setup?me(c.setup,"ARCHIVE_SETUP"):null,h=["LC_T20_ROSTER_SETUP_V2","LC_ODI_ROSTER_SETUP_V2","LC_RED5_ROSTER_SETUP_V2"].includes(String(u?.setupVersion)),p=i===null?null:xe.parse(i);if(h!==!!p||p&&o!==null)throw new Error("ARCHIVE_ROSTER_REQUIRED");if(p&&Em(c,t),p&&(u?.rosterPackHash!==await Vt(it.encode(G(p)))||me(u?.versions,"ARCHIVE_SETUP_VERSIONS").worldHash!==await Vt(it.encode(G(p.world)))||t.worldHash!==me(u?.versions,"ARCHIVE_SETUP_VERSIONS").worldHash))throw new Error("ARCHIVE_ROSTER_MISMATCH");const E=G(n),b=c.events;if(!Array.isArray(b))throw new Error("ARCHIVE_SESSION_EVENTS_INVALID");const w=b.map(_=>G(_)).join(`
`)+(b.length?`
`:""),v=[{name:"game.json",data:it.encode(E)},{name:"events.ndjson",data:it.encode(w)}],T=o===null?null:await Ni(o);T&&v.push({name:"world-copy.json",data:it.encode(G(T))}),p&&v.push({name:"roster-pack.json",data:it.encode(G(p))});const A=r===null?null:ta(r);A&&(fm(A,c),v.push({name:"delegation.json",data:it.encode(G(A))}));const I=s===null?null:oa.parse(s);if(I){if(p)throw new Error("ARCHIVE_SUPER_OVER_ROSTER_UNSUPPORTED");hm(I,c),v.push({name:"super-over.json",data:it.encode(G(I))})}const f={};for(const _ of v)f[_.name]={bytes:_.data.length,sha256:await Vt(_.data)};const S={archiveVersion:I?Ci:A?Ma:p?Di:T?yi:Ws,saveSchema:p?Xe:T?Ce:ca,exportedAt:a,summary:e,pins:t,files:f,embeddedPacks:p?["roster-pack.json"]:T?["world-copy.json"]:[],...p?{rosterPackSha256:f["roster-pack.json"].sha256}:{},...T?{worldCopySha256:f["world-copy.json"].sha256}:{}},k=it.encode(G(S)),R=sT([{name:"manifest.json",data:k},...v]);if(R.length>gm)throw new Error("ARCHIVE_SIZE_INVALID");return R}async function gT(n,e){const t=cT(n),a=new Set(["manifest.json","game.json","events.ndjson","world-copy.json","roster-pack.json","delegation.json","super-over.json"]);for(const M of t.keys())if(!a.has(M))throw new Error("ARCHIVE_FILE_NOT_ALLOWED");for(const M of["manifest.json","game.json","events.ndjson"])if(!t.has(M))throw new Error(`ARCHIVE_MISSING_${M}`);let o;try{o=JSON.parse(Ft.decode(t.get("manifest.json")))}catch{throw new Error("ARCHIVE_MANIFEST_JSON_INVALID")}const i=me(o,"ARCHIVE_MANIFEST").archiveVersion;if(i!==Ws&&i!==yi&&i!==Di&&i!==Ma&&i!==Ci)throw new Error("ARCHIVE_VERSION_UNSUPPORTED");const r=i===Ci,s=me(o,"ARCHIVE_MANIFEST").files,c=i===Ma||r&&!!s&&typeof s=="object"&&Object.hasOwn(s,"delegation.json"),u=me(o,"ARCHIVE_MANIFEST").saveSchema,h=i===yi||(i===Ma||r)&&u===Ce,p=i===Di||i===Ma&&u===Xe;_o(o,["archiveVersion","saveSchema","exportedAt","summary","pins","files","embeddedPacks",...h?["worldCopySha256"]:[],...p?["rosterPackSha256"]:[]],"ARCHIVE_MANIFEST");const E=o;if(!(E.archiveVersion===Ws&&E.saveSchema===ca)&&!(E.archiveVersion===yi&&E.saveSchema===Ce)&&!(E.archiveVersion===Di&&E.saveSchema===Xe)&&!(E.archiveVersion===Ma&&[ca,Ce,Xe].includes(E.saveSchema))&&!(E.archiveVersion===Ci&&(E.saveSchema===ca||E.saveSchema===Ce)))throw new Error("ARCHIVE_VERSION_UNSUPPORTED");if(typeof E.exportedAt!="string"||Number.isNaN(Date.parse(E.exportedAt)))throw new Error("ARCHIVE_EXPORTED_AT_INVALID");dT(E.summary);const b=p?["game.json","events.ndjson","roster-pack.json"]:h?["game.json","events.ndjson","world-copy.json"]:["game.json","events.ndjson"];if(c&&b.push("delegation.json"),r&&b.push("super-over.json"),t.has("delegation.json")!==c)throw new Error("ARCHIVE_DELEGATION_FILE_MISMATCH");if(t.has("super-over.json")!==r)throw new Error("ARCHIVE_SUPER_OVER_FILE_MISMATCH");if(t.has("roster-pack.json")!==p)throw new Error("ARCHIVE_ROSTER_FILE_MISMATCH");if(t.has("world-copy.json")!==h)throw new Error("ARCHIVE_WORLD_COPY_FILE_MISMATCH");if(uT(E.files,b),!Array.isArray(E.embeddedPacks)||G(E.embeddedPacks)!==G(p?["roster-pack.json"]:h?["world-copy.json"]:[]))throw new Error("ARCHIVE_EMBEDDED_PACKS_UNSUPPORTED");_o(E.pins,["engine","eventChain","random","model","modelHash","rules","rulesHash","worldHash"],"ARCHIVE_PINS");const w=E.pins;if(Array.isArray(e)){if(!e.some(H=>("worldHash"in H||p)&&Object.entries(H).every(([an,y])=>w[an]===y)))throw new Error("ARCHIVE_PINS_UNSUPPORTED")}else for(const[M,H]of Object.entries(e))if(w[M]!==H)throw new Error(`ARCHIVE_PIN_UNSUPPORTED_${M}`);for(const M of b){const H=t.get(M);if(!H)throw new Error(`ARCHIVE_MISSING_${M}`);const an=E.files[M];if(!an||an.bytes!==H.length||an.sha256!==await Vt(H))throw new Error(`ARCHIVE_HASH_MISMATCH_${M}`)}let v=null;if(p){const M=t.get("roster-pack.json");if(await Vt(M)!==E.rosterPackSha256)throw new Error("ARCHIVE_ROSTER_HASH_MISMATCH");let H;try{H=JSON.parse(Ft.decode(M))}catch{throw new Error("ARCHIVE_ROSTER_JSON_INVALID")}v=xe.parse(H)}let T=null;if(h){const M=t.get("world-copy.json");if(await Vt(M)!==E.worldCopySha256)throw new Error("ARCHIVE_WORLD_COPY_HASH_MISMATCH");let H;try{H=JSON.parse(Ft.decode(M))}catch{throw new Error("ARCHIVE_WORLD_COPY_JSON_INVALID")}T=await Ni(H)}let A;try{A=JSON.parse(Ft.decode(t.get("game.json")))}catch{throw new Error("ARCHIVE_GAME_JSON_INVALID")}const I=Ft.decode(t.get("events.ndjson")),f=I.trim()?I.trimEnd().split(`
`).map(M=>JSON.parse(M)):[],S=me(A,"ARCHIVE_GAME");let k=null;if(c){let M;try{M=JSON.parse(Ft.decode(t.get("delegation.json")))}catch{throw new Error("ARCHIVE_DELEGATION_JSON_INVALID")}k=ta(M),fm(k,S)}const R=S.setup?me(S.setup,"ARCHIVE_SETUP"):null;if(["LC_T20_ROSTER_SETUP_V2","LC_ODI_ROSTER_SETUP_V2","LC_RED5_ROSTER_SETUP_V2"].includes(String(R?.setupVersion))!==p)throw new Error("ARCHIVE_ROSTER_VERSION_MISMATCH");if(v&&Em(S,E.pins),v&&(R?.rosterPackHash!==E.rosterPackSha256||me(R?.versions,"ARCHIVE_SETUP_VERSIONS").worldHash!==await Vt(it.encode(G(v.world)))||E.pins.worldHash!==me(R?.versions,"ARCHIVE_SETUP_VERSIONS").worldHash))throw new Error("ARCHIVE_ROSTER_MISMATCH");const _=S.events;if(!Array.isArray(_)||G(_)!==G(f))throw new Error("ARCHIVE_EVENT_STREAM_MISMATCH");let U=null;if(r){let M;try{M=JSON.parse(Ft.decode(t.get("super-over.json")))}catch{throw new Error("ARCHIVE_SUPER_OVER_JSON_INVALID")}U=oa.parse(M),hm(U,S)}return{session:A,summary:E.summary,manifest:E,worldCopy:T,rosterPack:v,delegationJournal:k,superOverRecord:U}}const Sm="LC_MANAGED_MATCH_BINDING_V1",_m="managed-binding:",IT="lord-cricket-xxvi",pT=1;function sa(n){return`${_m}${n}`}async function hT(n){const e=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(n));return Array.from(new Uint8Array(e),t=>t.toString(16).padStart(2,"0")).join("")}async function Pi(n){return hT(G(n))}const $s=/^[a-f0-9]{64}$/,fT=["PENDING","APPLIED","ABANDONED"];async function Gs(n){if(!n||typeof n!="object"||Array.isArray(n))return null;const e=n,t=r=>typeof e[r]=="string"&&e[r].length>0&&e[r].length<=256;if(e.bindingVersion!==Sm||e.careerKind!=="STANDARD"&&e.careerKind!=="ROSTER"||!fT.includes(e.status)||!["careerSaveId","matchGameId","matchId","fixtureId","seasonId","createdAt","updatedAt"].every(t)||typeof e.scheduleSha256!="string"||!$s.test(e.scheduleSha256)||typeof e.careerStateSha256!="string"||!$s.test(e.careerStateSha256)||typeof e.sha256!="string"||!$s.test(e.sha256)||e.resolution!==null&&typeof e.resolution!="string"||e.launch===null||typeof e.launch!="object")return null;const{sha256:a,...o}=e;let i;try{i=await Pi(o)}catch{return null}return i===a?e:null}class Tt extends Error{code;constructor(e,t){super(`${e}: ${t}`),this.code=e,this.name="ManagedBindingError"}}class ET{kv;clock;constructor(e,t){this.kv=e,this.clock=t}async get(e){const t=await this.kv.get(sa(e));if(t===void 0)return null;const a=await Gs(t);if(!a||a.matchGameId!==e)throw new Tt("BINDING_DAMAGED",`Binding for ${e} failed validation and was preserved.`);return a}async list(){const e=await this.kv.listPrefix(_m),t=[],a=[];for(const o of e){const i=await Gs(o.value);i&&sa(i.matchGameId)===o.key?t.push(i):a.push(o.key)}return t.sort((o,i)=>o.createdAt.localeCompare(i.createdAt)||o.matchGameId.localeCompare(i.matchGameId)),{bindings:t,damaged:a}}async pendingForCareer(e){const{bindings:t,damaged:a}=await this.list();return{bindings:t.filter(o=>o.careerSaveId===e&&o.status==="PENDING"),damaged:a}}async create(e){const t=sa(e.matchGameId),a=await this.kv.get(t);let o=null;if(a!==void 0){if(o=await Gs(a),!o)throw new Tt("BINDING_DAMAGED",`Binding for ${e.matchGameId} failed validation and was preserved.`);if(o.status==="APPLIED")throw new Tt("BINDING_ALREADY_APPLIED",`The result for ${e.fixtureId} was already applied.`);if(o.status==="PENDING"){if(!(G(js(o))===G(js(e))))throw new Tt("BINDING_CONFLICT",`A different pending binding already exists for ${e.matchGameId}.`);return o}}const i=this.clock(),r={bindingVersion:Sm,...js(e),launch:e.launch,status:"PENDING",createdAt:i,updatedAt:i,resolution:null},s={...r,sha256:await Pi(r)};if(!await this.kv.compareAndPut(t,o?.sha256??null,s))throw new Tt("BINDING_RACE",`Binding for ${e.matchGameId} changed while it was being written.`);return s}async resolve(e,t,a){const o=await this.get(e);if(!o)throw new Tt("BINDING_MISSING",`No binding exists for ${e}.`);if(o.status===t)return o;if(o.status!=="PENDING")throw new Tt("BINDING_CONFLICT",`Binding for ${e} is already ${o.status}.`);const i={...o,status:t,updatedAt:this.clock(),resolution:a.slice(0,200)};delete i.sha256;const r={...i,sha256:await Pi(i)};if(!await this.kv.compareAndPut(sa(e),o.sha256,r))throw new Tt("BINDING_RACE",`Binding for ${e} changed while it was being resolved.`);return r}async rekeyCareer(e,t){if(e===t)return 0;const{bindings:a}=await this.list();let o=0;for(const i of a.filter(r=>r.careerSaveId===e&&r.status==="PENDING")){const r=i.launch&&typeof i.launch=="object"&&i.launch.saveId===e?{...i.launch,saveId:t}:i.launch,s={...i,careerSaveId:t,launch:r,updatedAt:this.clock()};delete s.sha256;const c={...s,sha256:await Pi(s)};if(!await this.kv.compareAndPut(sa(i.matchGameId),i.sha256,c))throw new Tt("BINDING_RACE",`Binding for ${i.matchGameId} changed while it was being moved.`);o++}return o}async remove(e){await this.kv.delete(sa(e))}async removeForCareer(e){const{bindings:t}=await this.list(),a=t.filter(o=>o.careerSaveId===e);for(const o of a)await this.kv.delete(sa(o.matchGameId));return a.length}}function js(n){return{careerKind:n.careerKind,careerSaveId:n.careerSaveId,matchGameId:n.matchGameId,matchId:n.matchId,fixtureId:n.fixtureId,seasonId:n.seasonId,scheduleSha256:n.scheduleSha256,careerStateSha256:n.careerStateSha256,launch:n.launch}}class dt{databaseName;dbPromise=null;constructor(e=IT){this.databaseName=e}open(){return this.dbPromise?this.dbPromise:(this.dbPromise=new Promise((e,t)=>{const a=indexedDB.open(this.databaseName,pT);a.onupgradeneeded=()=>{const o=a.result,i=o.createObjectStore("games",{keyPath:"saveId"});i.createIndex("updatedAt","updatedAt"),i.createIndex("matchGameId","matchGameId"),o.createObjectStore("snapshots",{keyPath:["saveId","generation"]}).createIndex("saveId","saveId"),o.createObjectStore("events",{keyPath:["saveId","sequence"]}).createIndex("saveId","saveId"),o.createObjectStore("commands",{keyPath:["saveId","commandId"]}).createIndex("saveId","saveId"),o.createObjectStore("worldPacks",{keyPath:"hash"}),o.createObjectStore("modelPacks",{keyPath:"hash"}),o.createObjectStore("rulePacks",{keyPath:"hash"}),o.createObjectStore("projections",{keyPath:["saveId","scope","key"]}),o.createObjectStore("settings",{keyPath:"key"})},a.onsuccess=()=>e(a.result),a.onerror=()=>t(a.error??new Error("Unable to open IndexedDB")),a.onblocked=()=>t(new Error("IndexedDB upgrade blocked by another tab"))}),this.dbPromise)}static req(e){return new Promise((t,a)=>{e.onsuccess=()=>t(e.result),e.onerror=()=>a(e.error??new Error("IndexedDB request failed"))})}static done(e){return new Promise((t,a)=>{e.oncomplete=()=>t(),e.onabort=()=>a(e.error??new Error("IndexedDB transaction aborted")),e.onerror=()=>a(e.error??new Error("IndexedDB transaction failed"))})}async get(e){const a=(await this.open()).transaction("settings","readonly"),o=await dt.req(a.objectStore("settings").get(e));return await dt.done(a),o?.value}async compareAndPut(e,t,a){const i=(await this.open()).transaction("settings","readwrite"),r=i.objectStore("settings"),s=await dt.req(r.get(e)),c=s?.value;if((s===void 0?null:typeof c?.sha256=="string"?c.sha256:"")!==t){i.abort();try{await dt.done(i)}catch{}return!1}return r.put({key:e,value:a}),await dt.done(i),!0}async delete(e){const a=(await this.open()).transaction("settings","readwrite");a.objectStore("settings").delete(e),await dt.done(a)}async listPrefix(e){const a=(await this.open()).transaction("settings","readonly"),o=await dt.req(a.objectStore("settings").getAll(IDBKeyRange.bound(e,`${e}￿`)));return await dt.done(a),o.map(i=>({key:i.key,value:i.value}))}}function ST(n,e){return new ET(new dt(e),n)}const ca="LC_SAVE_V1",Ce="LC_SAVE_V2_PRESENTATION",Xe="LC_SAVE_V3_ROSTER",Mt="LC_SAVE_V4_DELEGATION",_T="lord-cricket-xxvi",TT=1,Ys=12e3,Tm=["lcxxvi-scenarios","SCENARIO_RECORDS_V1","ledger"],zs="SUPER_OVER_V1",Ks="lcxxvi-super-overs",la="TOURNAMENT_RUNS_V1",Jn="lcxxvi-tournaments",To="USER_COMPETITIONS_V1",Ro="USER_TOURS_V1",xi="TOURNAMENT_AUCTIONS_V1",vo="RAIN_MATCHES_V1",Ao="lcxxvi-rain-matches";function qs(n){const e=n.schemaVersion===Mt?n.baseSchemaVersion:n.schemaVersion;if(![ca,Ce,Xe].includes(e))throw new Error("SAVE_SCHEMA_UNSUPPORTED");if(n.schemaVersion!==Mt&&n.baseSchemaVersion!==void 0)throw new Error("SAVE_SCHEMA_UNSUPPORTED");return e}function fn(n){return new Promise((e,t)=>{n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error??new Error("IndexedDB request failed"))})}function rn(n){return new Promise((e,t)=>{n.oncomplete=()=>e(),n.onabort=()=>t(n.error??new Error("IndexedDB transaction aborted")),n.onerror=()=>t(n.error??new Error("IndexedDB transaction failed"))})}function RT(n){return Array.from(n,e=>e.toString(16).padStart(2,"0")).join("")}async function Vt(n){const e=new Uint8Array(n.byteLength);e.set(n);const t=await crypto.subtle.digest("SHA-256",e);return RT(new Uint8Array(t))}async function kn(n){return Vt(new TextEncoder().encode(n))}function ZR(n){return n}function Va(n){return`lease:${n}`}function da(n){return`delegation:${n}`}function bo(n,e){return`delegation-checkpoint:${n}:${e}`}async function wo(n,e){const t={saveId:n,journal:e};return{...t,sha256:await kn(G(t))}}async function Zs(n,e){const t=Qn(n),a=ta(t.journal),o=await wo(e,a);if(t.saveId!==e||t.sha256!==o.sha256)throw new Error("DELEGATION_CHECKPOINT_DAMAGED");return a}function Xs(n){return{saveId:n.saveId,kind:n.kind,title:n.title,matchGameId:n.matchGameId,matchId:n.matchId,teams:n.teams,ground:n.ground,phase:n.phase,revision:n.revision,eventCount:n.eventCount,lastEventHash:n.lastEventHash,updatedAt:n.updatedAt,completed:n.completed}}function Qn(n){return n&&typeof n=="object"&&!Array.isArray(n)?n:{}}function vT(n,e,t){const a=Qn(e),o=Qn(a.setup),i=Qn(a.core),r=Qn(o.ground),s=Array.isArray(o.teams)?o.teams.map(Qn):[],c=Array.isArray(a.events)?a.events:[];return{...Xs(n),matchGameId:String(o.gameId??n.matchGameId),matchId:String(o.matchId??n.matchId),teams:[String(s[0]?.name??n.teams[0]),String(s[1]?.name??n.teams[1])],ground:String(r.name??n.ground),phase:String(i.phase??n.phase),revision:Number(a.revision??t.revision),eventCount:c.length,lastEventHash:String(a.lastEventHash??""),updatedAt:t.createdAt,completed:i.phase==="COMPLETE"}}class AT{databaseName;dbPromise=null;constructor(e=_T){this.databaseName=e}open(){return this.dbPromise?this.dbPromise:(this.dbPromise=new Promise((e,t)=>{const a=indexedDB.open(this.databaseName,TT);a.onupgradeneeded=()=>{const o=a.result,i=o.createObjectStore("games",{keyPath:"saveId"});i.createIndex("updatedAt","updatedAt"),i.createIndex("matchGameId","matchGameId"),o.createObjectStore("snapshots",{keyPath:["saveId","generation"]}).createIndex("saveId","saveId"),o.createObjectStore("events",{keyPath:["saveId","sequence"]}).createIndex("saveId","saveId"),o.createObjectStore("commands",{keyPath:["saveId","commandId"]}).createIndex("saveId","saveId"),o.createObjectStore("worldPacks",{keyPath:"hash"}),o.createObjectStore("modelPacks",{keyPath:"hash"}),o.createObjectStore("rulePacks",{keyPath:"hash"}),o.createObjectStore("projections",{keyPath:["saveId","scope","key"]}),o.createObjectStore("settings",{keyPath:"key"})},a.onsuccess=()=>e(a.result),a.onerror=()=>t(a.error??new Error("Unable to open IndexedDB")),a.onblocked=()=>t(new Error("IndexedDB upgrade blocked by another tab"))}),this.dbPromise)}async list(){const t=(await this.open()).transaction("games","readonly"),a=await fn(t.objectStore("games").getAll());return await rn(t),a.filter(o=>o.recordType===void 0).sort((o,i)=>i.updatedAt.localeCompare(o.updatedAt)).map(Xs)}async loadScenarioLedger(){const t=(await this.open()).transaction("projections","readonly"),a=await fn(t.objectStore("projections").get([...Tm]));if(await rn(t),!a)return null;if(await kn(a.payload)!==a.sha256)throw new Error("SCENARIO_LEDGER_DAMAGED");return La.parse(JSON.parse(a.payload))}async saveScenarioLedger(e){const t=La.parse(e),a=G(t),o=await kn(a),r=(await this.open()).transaction("projections","readwrite"),[s,c,u]=Tm;return r.objectStore("projections").put({saveId:s,scope:c,key:u,payload:a,sha256:o}),await rn(r),t}async loadSuperOverRecord(e){const a=(await this.open()).transaction("projections","readonly"),o=await fn(a.objectStore("projections").get([Ks,zs,e]));if(await rn(a),!o)return null;if(await kn(o.payload)!==o.sha256)throw new Error("SUPER_OVER_RECORD_DAMAGED");const i=oa.parse(JSON.parse(o.payload));if(i.gameId!==e)throw new Error("SUPER_OVER_RECORD_DAMAGED");return i}async saveSuperOverRecord(e,t){const a=oa.parse(e),o=G(a),i=await kn(o),s=(await this.open()).transaction("projections","readwrite"),c=s.objectStore("projections"),u=await fn(c.get([Ks,zs,a.gameId])),h=u?oa.parse(JSON.parse(u.payload)):null,p=h?.commands.length??0,E=!h||h.schemaId===a.schemaId&&h.baseLastEventHash===a.baseLastEventHash&&G(h.commands)===G(a.commands.slice(0,p));if(p!==t||!E){s.abort();try{await rn(s)}catch{}throw new Error("SUPER_OVER_STALE")}return c.put({saveId:Ks,scope:zs,key:a.gameId,payload:o,sha256:i}),await rn(s),a}async listTournamentRuns(){const t=(await this.open()).transaction("projections","readonly"),a=await fn(t.objectStore("projections").getAll(IDBKeyRange.bound([Jn,la,""],[Jn,la,"￿"])));await rn(t);const o=[],i=[];for(const r of a)try{if(await kn(r.payload)!==r.sha256)throw new Error("hash");const s=Jo.parse(JSON.parse(r.payload));if(s.runId!==r.key)throw new Error("key");o.push(s)}catch{i.push(r.key)}return{runs:o,damaged:i}}async saveTournamentRun(e,t){const a=Jo.parse(e),o=G(a),i=await kn(o),s=(await this.open()).transaction("projections","readwrite"),c=s.objectStore("projections"),u=await fn(c.get([Jn,la,a.runId])),h=u?Jo.parse(JSON.parse(u.payload)):null;if(!(h?h.results.length===t&&h.competitionSha256===a.competitionSha256&&h.seed===a.seed&&G(h.results)===G(a.results.slice(0,t)):t===0)){s.abort();try{await rn(s)}catch{}throw new Error("TOURNAMENT_RUN_STALE")}return c.put({saveId:Jn,scope:la,key:a.runId,payload:o,sha256:i}),await rn(s),a}async deleteTournamentRun(e){const a=(await this.open()).transaction("projections","readwrite");a.objectStore("projections").delete([Jn,la,e]),await rn(a)}async listRainMatches(){const t=(await this.open()).transaction("projections","readonly"),a=await fn(t.objectStore("projections").getAll(IDBKeyRange.bound([Ao,vo,""],[Ao,vo,"￿"])));await rn(t);const o=[],i=[];for(const r of a)try{if(await kn(r.payload)!==r.sha256)throw new Error("hash");const s=jr.parse(JSON.parse(r.payload));if(s.gameId!==r.key)throw new Error("key");o.push(s)}catch{i.push(r.key)}return{records:o,damaged:i}}async saveRainMatch(e,t){const a=jr.parse(e),o=G(a),i=await kn(o),s=(await this.open()).transaction("projections","readwrite"),c=s.objectStore("projections"),u=await fn(c.get([Ao,vo,a.gameId])),h=u?jr.parse(JSON.parse(u.payload)):null,p=w=>G([w.schemaId,w.rulesId,w.matchId,w.seed,w.groundId,w.selectedTeams,w.schemaId==="LC_RAIN_MATCH_RECORD_V1"?null:[w.rain,w.reviewRulesId]]),E=w=>p(w)===p(a);if(!(h?h.commands.length===t&&E(h)&&G(h.commands)===G(a.commands.slice(0,t)):t===0)){s.abort();try{await rn(s)}catch{}throw new Error("RAIN_MATCH_STALE")}return c.put({saveId:Ao,scope:vo,key:a.gameId,payload:o,sha256:i}),await rn(s),a}async deleteRainMatch(e){const a=(await this.open()).transaction("projections","readwrite");a.objectStore("projections").delete([Ao,vo,e]),await rn(a)}async listUserCompetitions(){const t=(await this.open()).transaction("projections","readonly"),a=await fn(t.objectStore("projections").getAll(IDBKeyRange.bound([Jn,To,""],[Jn,To,"￿"])));await rn(t);const o=[],i=[];for(const r of a)try{if(await kn(r.payload)!==r.sha256)throw new Error("hash");const s=Dd.parse(JSON.parse(r.payload));if(s.competition.competitionId!==r.key)throw new Error("key");o.push(s.competition)}catch{i.push(r.key)}return{competitions:o,damaged:i}}async addUserCompetition(e){const t=Dd.parse({schemaId:yd,competition:e}),a=G(t),o=await kn(a),r=(await this.open()).transaction("projections","readwrite"),s=r.objectStore("projections"),c=t.competition.competitionId;if(await fn(s.get([Jn,To,c]))){r.abort();try{await rn(r)}catch{}throw new Error("USER_COMPETITION_EXISTS")}return s.put({saveId:Jn,scope:To,key:c,payload:a,sha256:o}),await rn(r),t.competition}async deleteUserCompetition(e){const{runs:t}=await this.listTournamentRuns();if(t.some(i=>i.competitionId===e))throw new Error("USER_COMPETITION_IN_USE");const o=(await this.open()).transaction("projections","readwrite");o.objectStore("projections").delete([Jn,To,e]),await rn(o)}async listUserTours(){const t=(await this.open()).transaction("projections","readonly"),a=await fn(t.objectStore("projections").getAll(IDBKeyRange.bound([Jn,Ro,""],[Jn,Ro,"￿"])));await rn(t);const o=[],i=[];for(const r of a)try{if(await kn(r.payload)!==r.sha256)throw new Error("hash");const s=kd.parse(JSON.parse(r.payload));if(s.tour.tourId!==r.key)throw new Error("key");o.push(s.tour)}catch{i.push(r.key)}return{tours:o,damaged:i}}async addUserTour(e){const t=kd.parse({schemaId:Cd,tour:e}),a=G(t),o=await kn(a),r=(await this.open()).transaction("projections","readwrite"),s=r.objectStore("projections"),c=t.tour.tourId;if(await fn(s.get([Jn,Ro,c]))){r.abort();try{await rn(r)}catch{}throw new Error("USER_TOUR_EXISTS")}return s.put({saveId:Jn,scope:Ro,key:c,payload:a,sha256:o}),await rn(r),t.tour}async deleteUserTour(e){const{runs:t}=await this.listTournamentRuns();if(t.some(i=>i.competitionId===e))throw new Error("USER_TOUR_IN_USE");const o=(await this.open()).transaction("projections","readwrite");o.objectStore("projections").delete([Jn,Ro,e]),await rn(o)}async listTournamentAuctions(){const t=(await this.open()).transaction("projections","readonly"),a=await fn(t.objectStore("projections").getAll(IDBKeyRange.bound([Jn,xi,""],[Jn,xi,"￿"])));await rn(t);const o=[],i=[];for(const r of a)try{if(await kn(r.payload)!==r.sha256)throw new Error("hash");const s=Bd.parse(JSON.parse(r.payload));if(s.runId!==r.key)throw new Error("key");o.push(s)}catch{i.push(r.key)}return{auctions:o,damaged:i}}async addAuctionedTournamentRun(e,t){const a=Bd.parse(e),o=Jo.parse(t);if(a.runId!==o.runId||a.competitionId!==o.competitionId||o.results.length!==0)throw new Error("TOURNAMENT_AUCTION_RUN_MISMATCH");const i=G(a),r=G(o),[s,c]=[await kn(i),await kn(r)],h=(await this.open()).transaction("projections","readwrite"),p=h.objectStore("projections");if([await fn(p.get([Jn,xi,a.runId])),await fn(p.get([Jn,la,o.runId]))].some(Boolean)){h.abort();try{await rn(h)}catch{}throw new Error("TOURNAMENT_RUN_STALE")}p.put({saveId:Jn,scope:xi,key:a.runId,payload:i,sha256:s}),p.put({saveId:Jn,scope:la,key:o.runId,payload:r,sha256:c}),await rn(h)}async activeSaveId(){const t=(await this.open()).transaction("settings","readonly"),a=await fn(t.objectStore("settings").get("activeSaveId"));return await rn(t),typeof a?.value=="string"?a.value:null}async setActiveSaveId(e){const a=(await this.open()).transaction("settings","readwrite"),o=a.objectStore("settings");e===null?o.delete("activeSaveId"):o.put({key:"activeSaveId",value:e}),await rn(a)}async acquireLease(e,t,a){const i=(await this.open()).transaction("settings","readwrite"),r=i.objectStore("settings"),s=Va(e),c=await fn(r.get(s));if(c&&c.ownerId!==t&&c.expiresAt>a){i.abort();try{await rn(i)}catch{}return!1}return r.put({key:s,saveId:e,ownerId:t,expiresAt:a+Ys}),await rn(i),!0}async renewLease(e,t,a){const i=(await this.open()).transaction("settings","readwrite"),r=i.objectStore("settings"),s=Va(e),c=await fn(r.get(s));if(!c||c.ownerId!==t||c.expiresAt<=a){i.abort();try{await rn(i)}catch{}return!1}return r.put({...c,expiresAt:a+Ys}),await rn(i),!0}async releaseLease(e,t){const o=(await this.open()).transaction("settings","readwrite"),i=o.objectStore("settings"),r=Va(e);(await fn(i.get(r)))?.ownerId===t&&i.delete(r),await rn(o)}async loadDelegationJournal(e){const a=(await this.open()).transaction(["games","settings"],"readonly"),o=await fn(a.objectStore("games").get(e)),i=await fn(a.objectStore("settings").get(da(e)));if(await rn(a),!o)throw new Error("SAVE_NOT_FOUND");if(o.schemaVersion===Mt&&!i)throw new Error("DELEGATION_ACTIVE_MISSING");const r=i?await Zs(i.value,e):{version:"LC_DELEGATION_JOURNAL_V1",changes:[]};if(r.changes.some(s=>s.matchRevision>o.revision))throw new Error("DELEGATION_AHEAD_OF_SAVE");return r}async appendDelegation(e,t,a,o){const i=await this.loadDelegationJournal(e),r=i.changes.length?await wo(e,i):null,s=l2(i,o),c=await wo(e,s),h=(await this.open()).transaction(["games","snapshots","settings"],"readwrite");try{const p=h.objectStore("settings"),E=await fn(h.objectStore("games").get(e)),b=await fn(p.get(Va(e))),w=await fn(p.get(da(e)));if(!E)throw new Error("SAVE_NOT_FOUND");if(!b||b.ownerId!==t||b.expiresAt<=a)throw new Error("SAVE_READ_ONLY");const v=qs(E);if(G(w?.value??null)!==G(r))throw new Error("DELEGATION_STALE_REVISION");if(s.changes.at(-1)?.matchRevision!==E.revision)throw new Error("DELEGATION_STALE_MATCH");const T=h.objectStore("snapshots"),A=await fn(T.get([e,E.checkpointGeneration]));if(!A||A.checkpointSerial!==E.checkpointSerial)throw new Error("DELEGATION_CHECKPOINT_MISSING");return p.put({key:da(e),value:c}),p.put({key:bo(e,A.generation),value:{checkpointSerial:A.checkpointSerial,record:c}}),T.put({...A,delegationTracked:!0}),h.objectStore("games").put({...E,schemaVersion:Mt,baseSchemaVersion:v}),await rn(h),s}catch(p){try{h.abort()}catch{}throw p}}async historyCommands(e,t=Number.MAX_SAFE_INTEGER){const o=(await this.open()).transaction("commands","readonly"),i=await fn(o.objectStore("commands").index("saveId").getAll(e));return await rn(o),i.filter(r=>r.committedRevision<=t).sort((r,s)=>r.committedRevision-s.committedRevision||r.commandId.localeCompare(s.commandId)).map(({commandId:r,requestCanonical:s,responseJson:c,committedRevision:u})=>({commandId:r,requestCanonical:s,responseJson:c,committedRevision:u}))}async command(e,t){const o=(await this.open()).transaction("commands","readonly"),i=await fn(o.objectStore("commands").get([e,t]));return await rn(o),i?{commandId:i.commandId,requestCanonical:i.requestCanonical,responseJson:i.responseJson,committedRevision:i.committedRevision}:null}async commit(e){const t=await this.open(),a=e.now,o=e.delegationJournal?ta(e.delegationJournal):null;if(o?.changes.some(J=>J.matchRevision>e.revision))throw new Error("DELEGATION_AHEAD_OF_SAVE");const i=e.expectedRevision!==null?await this.loadDelegationJournal(e.saveId):null,r=i?.changes.length?await wo(e.saveId,i):null,s=o?.changes.length?await wo(e.saveId,o):null,c=G(e.session),u=await kn(c),h=e.worldCopy?await Ni(e.worldCopy):null,p=h?G(h):null,E=p?await kn(p):null,b=e.rosterPack?xe.parse(e.rosterPack):null;if(b&&h)throw new Error("SAVE_WORLD_TYPE_CONFLICT");if(["LC_T20_ROSTER_SETUP_V2","LC_ODI_ROSTER_SETUP_V2","LC_RED5_ROSTER_SETUP_V2"].includes(String(Qn(Qn(e.session).setup).setupVersion))&&!b)throw new Error("SAVE_ROSTER_REQUIRED");const w=b?G(b):null,v=w?await kn(w):null;if(b){const J=Qn(Qn(e.session).setup);if(!["LC_T20_ROSTER_SETUP_V2","LC_ODI_ROSTER_SETUP_V2","LC_RED5_ROSTER_SETUP_V2"].includes(String(J.setupVersion))||J.rosterPackHash!==v||Qn(J.versions).worldHash!==await kn(G(b.world)))throw new Error("SAVE_ROSTER_SESSION_MISMATCH")}const T=await Promise.all(e.events.map(async J=>{const pn=G(J);return{saveId:e.saveId,sequence:J.sequence,payload:pn,sha256:await kn(pn)}})),A=t.transaction(["games","snapshots","events","commands","settings","projections","worldPacks"],"readwrite"),I=A.objectStore("games"),f=A.objectStore("snapshots"),S=A.objectStore("events"),k=A.objectStore("commands"),R=A.objectStore("settings"),_=await fn(I.get(e.saveId));let U=null;try{_&&(U=qs(_))}catch(J){throw A.abort(),J}if(_&&E&&E!==_.worldCopySha256){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_WORLD_COPY_IMMUTABLE")}if(U===Ce&&!_?.worldCopySha256){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_WORLD_COPY_MISSING")}if(U===Ce&&!E){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_WORLD_COPY_REQUIRED")}if(_&&U!==Ce&&_.worldCopySha256){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_WORLD_COPY_VERSION_MISMATCH")}if(_&&v&&(U!==Xe||_.rosterPackSha256!==v)){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_ROSTER_IMMUTABLE")}if(U===Xe&&(!_?.rosterPackSha256||!v)){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_ROSTER_REQUIRED")}if(_&&U!==Xe&&_.rosterPackSha256){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_ROSTER_VERSION_MISMATCH")}const M=await fn(R.get(Va(e.saveId)));if(!M||M.ownerId!==e.ownerId||M.expiresAt<=a){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_READ_ONLY: writer lease is not held")}const H=_?.revision??0;if(e.expectedRevision===null&&_){A.abort();try{await rn(A)}catch{}throw new Error(`SAVE_ALREADY_EXISTS: ${e.saveId} already holds revision ${H}; refusing to replace it`)}if(e.expectedRevision!==null&&H!==e.expectedRevision){A.abort();try{await rn(A)}catch{}throw new Error(`SAVE_STALE_REVISION: expected ${e.expectedRevision}, durable ${H}`)}const an=e.historyCommands??[];if((an.length||o)&&_){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_HISTORY_ONLY_ALLOWED_ON_NEW_SAVE")}const y=new Set;for(const J of an){if(y.has(J.commandId)||e.command&&J.commandId===e.command.commandId){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_DUPLICATE_HISTORY_COMMAND")}y.add(J.commandId)}if(e.command){const J=await fn(k.get([e.saveId,e.command.commandId]));if(J){if(J.requestCanonical!==e.command.requestCanonical){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_DUPLICATE_COMMAND_CONFLICT")}A.abort();try{await rn(A)}catch{}throw new Error("SAVE_DUPLICATE_COMMAND_ALREADY_COMMITTED")}}const L=_?await fn(R.get(da(e.saveId))):void 0;if(G(L?.value??null)!==G(r))throw A.abort(),new Error("DELEGATION_STALE_REVISION");if(_?.schemaVersion===Mt&&!r)throw A.abort(),new Error("DELEGATION_ACTIVE_MISSING");const $=o??i,P=s??r;if($?.changes.some(J=>J.matchRevision>e.revision))throw A.abort(),new Error("DELEGATION_AHEAD_OF_SAVE");const B=(_?.checkpointSerial??-1)+1,W=B%3,Z=e.updatedAt;f.put({saveId:e.saveId,generation:W,checkpointSerial:B,revision:e.revision,payload:c,sha256:u,createdAt:Z,...$?.changes.length?{delegationTracked:!0}:{}}),$?.changes.length?R.put({key:bo(e.saveId,W),value:{checkpointSerial:B,record:P}}):R.delete(bo(e.saveId,W));const j=_?.eventCount??0;for(const J of T)J.sequence>j&&S.put(J);for(const J of an)k.put({saveId:e.saveId,...J});e.command&&k.put({saveId:e.saveId,...e.command}),s&&R.put({key:da(e.saveId),value:s});const Q={saveId:e.saveId,kind:e.kind,title:e.title,matchGameId:e.metadata.matchGameId,matchId:e.metadata.matchId,teams:e.metadata.teams,ground:e.metadata.ground,phase:e.metadata.phase,revision:e.revision,eventCount:e.events.length,lastEventHash:e.events.length?String(e.events[e.events.length-1].eventHash??""):"",updatedAt:Z,completed:e.metadata.completed},En=_?.worldCopySha256??E;if(p&&E){const J=A.objectStore("worldPacks"),pn=await fn(J.get(E));if(!pn&&_){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_WORLD_COPY_MISSING")}if(pn&&pn.payload!==p){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_WORLD_COPY_CONFLICT")}pn||J.add({hash:E,payload:p})}if(w&&v){const J=A.objectStore("worldPacks"),pn=await fn(J.get(v));if(!pn&&_){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_ROSTER_MISSING")}if(pn&&pn.payload!==w){A.abort();try{await rn(A)}catch{}throw new Error("SAVE_ROSTER_CONFLICT")}pn||J.add({hash:v,payload:w})}if(I.put({...Q,schemaVersion:$?.changes.length?Mt:v?Xe:En?Ce:ca,...$?.changes.length?{baseSchemaVersion:v?Xe:En?Ce:ca}:{},...v?{rosterPackSha256:v}:{},...En?{worldCopySha256:En}:{},checkpointSerial:B,checkpointGeneration:W}),e.setActive!==!1&&R.put({key:"activeSaveId",value:e.saveId}),R.put({...M,expiresAt:a+Ys}),e.testAbortAfterWrites){const J=rn(A);A.abort();try{await J}catch{}throw new Error("SAVE_INJECTED_ABORT")}return await rn(A),Q}async cloneSave(e,t,a,o,i,r,s){const c=await this.load(e);if(!c)throw new Error("SAVE_NOT_FOUND");if(!await this.acquireLease(t,i,r))throw new Error("SAVE_READ_ONLY: target slot is locked");const h=Qn(c.session),p=Qn(h.setup),E=Qn(h.core),b=Array.isArray(p.teams)?p.teams.map(Qn):[],w=Qn(p.ground),v=h.events,T=Array.isArray(v)?v.filter(f=>Qn(f).sequence!==void 0&&typeof Qn(f).sequence=="number"):[],A=await this.historyCommands(e,Number(h.revision??0)),I=c.delegationJournal;return this.commit({saveId:t,kind:a,title:o,expectedRevision:null,session:h,revision:Number(h.revision??0),events:T,command:null,historyCommands:A,...I?.changes.length?{delegationJournal:I}:{},worldCopy:c.worldCopy??null,rosterPack:c.rosterPack??null,setActive:!1,ownerId:i,now:r,updatedAt:s,metadata:{matchGameId:String(p?.gameId??c.summary.matchGameId),matchId:String(p?.matchId??c.summary.matchId),teams:[c.worldCopy?c.summary.teams[0]:String(b[0]?.name??c.summary.teams[0]),c.worldCopy?c.summary.teams[1]:String(b[1]?.name??c.summary.teams[1])],ground:c.worldCopy?c.summary.ground:String(w.name??c.summary.ground),phase:String(E.phase??c.summary.phase),completed:E.phase==="COMPLETE"}})}async load(e){const a=(await this.open()).transaction(["games","snapshots","worldPacks","settings"],"readonly"),o=await fn(a.objectStore("games").get(e));if(!o)return await rn(a),null;let i;try{i=qs(o)}catch{throw await rn(a),new Error(`SAVE_SCHEMA_UNSUPPORTED: ${String(o.schemaVersion)}`)}if(i!==Ce&&o.worldCopySha256)throw await rn(a),new Error("SAVE_WORLD_COPY_VERSION_MISMATCH");const r=await fn(a.objectStore("snapshots").index("saveId").getAll(e)),s=await Promise.all([0,1,2].map(A=>fn(a.objectStore("settings").get(bo(e,A))))),c=await fn(a.objectStore("settings").get(da(e))),u=i===Xe&&o.rosterPackSha256?await fn(a.objectStore("worldPacks").get(o.rosterPackSha256)):void 0,h=i===Ce&&o.worldCopySha256?await fn(a.objectStore("worldPacks").get(o.worldCopySha256)):void 0;await rn(a);let p=null,E=!1;if(o.schemaVersion===Mt)try{if(!c)throw new Error("DELEGATION_ACTIVE_MISSING");p=await Zs(c.value,e)}catch{E=!0}let b=null;if(i===Xe){if(!u||!o.rosterPackSha256||await kn(u.payload)!==o.rosterPackSha256)throw new Error("SAVE_ROSTER_MISSING_OR_DAMAGED");b=xe.parse(JSON.parse(u.payload))}else if(o.rosterPackSha256)throw new Error("SAVE_ROSTER_VERSION_MISMATCH");let w=null;if(i===Ce){if(!h||!o.worldCopySha256||await kn(h.payload)!==o.worldCopySha256)throw new Error("SAVE_WORLD_COPY_MISSING_OR_DAMAGED");w=await Ni(JSON.parse(h.payload))}const v=b?await kn(G(b.world)):null,T=r.sort((A,I)=>I.checkpointSerial-A.checkpointSerial);for(const A of T)if(await kn(A.payload)===A.sha256)try{const I=JSON.parse(A.payload),f=Qn(Qn(I).setup);if(b&&(!["LC_T20_ROSTER_SETUP_V2","LC_ODI_ROSTER_SETUP_V2","LC_RED5_ROSTER_SETUP_V2"].includes(String(f.setupVersion))||f.rosterPackHash!==o.rosterPackSha256||Qn(f.versions).worldHash!==v)||!b&&["LC_T20_ROSTER_SETUP_V2","LC_ODI_ROSTER_SETUP_V2","LC_RED5_ROSTER_SETUP_V2"].includes(String(f.setupVersion)))continue;let S;const k=s[A.generation]?.value;if(A.delegationTracked){if(!k||k.checkpointSerial!==A.checkpointSerial||(S=await Zs(k.record,e),S.changes.some(_=>_.matchRevision>A.revision)))continue}else if(k?.checkpointSerial===A.checkpointSerial)continue;const R=A.checkpointSerial!==o.checkpointSerial||o.schemaVersion===Mt&&(E||!S||G(p)!==G(S));return{summary:R?vT(o,I,A):Xs(o),session:I,recovered:R,recoveredFromGeneration:R?A.generation:null,worldCopy:w,rosterPack:b,...S?{delegationJournal:S}:{}}}catch{}throw new Error("SAVE_CORRUPT: no valid checkpoint generation")}async delete(e){const a=(await this.open()).transaction(["games","snapshots","events","commands","projections","settings"],"readwrite");a.objectStore("games").delete(e);for(const i of["snapshots","events","commands"]){const r=a.objectStore(i),s=r.index("saveId"),c=IDBKeyRange.only(e);await new Promise((u,h)=>{const p=s.openKeyCursor(c);p.onerror=()=>h(p.error),p.onsuccess=()=>{const E=p.result;if(!E)return u();r.delete(E.primaryKey),E.continue()}})}(await fn(a.objectStore("settings").get("activeSaveId")))?.value===e&&a.objectStore("settings").delete("activeSaveId"),a.objectStore("settings").delete(Va(e)),a.objectStore("settings").delete(da(e));for(const i of[0,1,2])a.objectStore("settings").delete(bo(e,i));await rn(a)}async corruptCurrentCheckpoint(e){const a=(await this.open()).transaction(["games","snapshots"],"readwrite"),o=await fn(a.objectStore("games").get(e));if(!o)throw new Error("SAVE_NOT_FOUND");const i=[e,o.checkpointGeneration],r=await fn(a.objectStore("snapshots").get(i));a.objectStore("snapshots").put({...r,payload:`${r.payload} `}),await rn(a)}}function bT(n,e,t,a){const o=c=>c.eligible?Math.max(0,Math.ceil((a-c.legalBalls)/6)):0,i=e.find(c=>c.id===n);if(!i||o(i)<1)return!1;const r=t-1;if(r<=0)return!0;let s=0;for(const c of e){const u=c.id===n?o(c)-1:o(c);s+=Math.min(u,c.id===n?Math.floor(r/2):Math.ceil(r/2))}return s>=r}function Js(n,e,t){const a=n.filter(r=>r.eligible),o=new Set(a.filter(r=>bT(r.id,n,e,t)).map(r=>r.id)),i=new Map;if(o.size===0)return i;for(const r of a)o.has(r.id)||i.set(r.id,"Would leave overs that no one could bowl");return i}const Qs="LC_NEW_GAME_WORLD_COPY_V1",Hi=qn();function wT(n,e){if(Hi.hash(e)!==xn.worldCanonicalSha256)throw new Error("The original world does not match its accepted hash.");const t=mr(n,["stock"],e.rulesIds);if([...t.players,...t.teams,...t.grounds].map(i=>i.name).some(i=>i.trim()!==i||i.length===0||[...i].some(r=>{const s=r.codePointAt(0);return s<32||s>=127&&s<=159})))throw new Error("Names must have 1 to 80 characters, with no control characters or surrounding spaces.");const o=structuredClone(t);if(o.packId=e.packId,o.players.length!==e.players.length||o.teams.length!==e.teams.length||o.grounds.length!==e.grounds.length)throw new Error("This editor cannot add or remove players, teams or grounds.");if(o.players.forEach((i,r)=>{i.name=e.players[r].name}),o.teams.forEach((i,r)=>{i.name=e.teams[r].name,i.colours=[...e.teams[r].colours]}),o.grounds.forEach((i,r)=>{i.name=e.grounds[r].name}),G(o)!==G(e))throw new Error("Only names and team colours can change in this editor.");return t}function OT(n,e){const t=wT(n,e);t.packId=e.packId;const a=Hi.hash({copyVersion:Qs,baseWorldCanonicalSha256:xn.worldCanonicalSha256,world:t});return t.packId=`world-edit-${a}`,Ra.parse({copyVersion:Qs,baseWorldCanonicalSha256:xn.worldCanonicalSha256,worldCanonicalSha256:Hi.hash(t),world:t})}function Fi(n,e){if(!n||typeof n!="object"||!("copyVersion"in n)||n.copyVersion!==Qs)throw new Error("Unsupported world copy version.");const t=Ra.parse(n);if(t.baseWorldCanonicalSha256!==xn.worldCanonicalSha256)throw new Error("The world copy has an unsupported base world.");if(Hi.hash(t.world)!==t.worldCanonicalSha256)throw new Error("The world copy hash does not match its contents.");const a=OT(t.world,e);if(G(t)!==G(a))throw new Error("The world copy identity does not match its contents.");return t}const ve="LC_T20_UI_V2",ne=Object.freeze({engine:"LC_T20_MATCH_V1",eventChain:"LC_T20_EVENT_CHAIN_V1",worldHash:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",rulesHash:"7c67aec8e3aef8be7b849775d83bad64847338e03326848ec1f1d0d99c6fa745",modelHash:"d47d5caca955b7a374b0052d712b1674bca6d855e222194ce9f0587d8580b7ab",stagePackHash:"34efa3037702e44a134ea38b414eab3e97c6f79f10b3e5458bc2ab05412e5d7a"}),Wt=Object.freeze({engine:"LC_ODI_MATCH_V1",eventChain:"LC_ODI_EVENT_CHAIN_V1",worldHash:ne.worldHash,rulesHash:"81f8ec39a793e3761dac2d477a7fc7d4981df2e69b262e88160cb93141c28ee5",modelHash:ne.modelHash,stagePackHash:ne.stagePackHash}),Ut=Object.freeze({engine:"LC_RED5_MATCH_V1",eventChain:"LC_RED5_EVENT_CHAIN_V1",worldHash:ne.worldHash,rulesHash:"819b388b1947f71c6228b21680687472760bfcf4a872f0f41cc9508e65928800",modelHash:ne.modelHash,stagePackHash:ne.stagePackHash}),$t=Object.freeze({engine:Ut.engine,eventChain:Ut.eventChain,random:"SHA256_COUNTER_V1",model:"synthetic-alpha-01",modelHash:Ut.modelHash,rules:"LC_RED5_01",rulesHash:Ut.rulesHash,worldHash:Ut.worldHash}),Gt=Object.freeze({engine:ne.engine,eventChain:ne.eventChain,random:"SHA256_COUNTER_V1",model:"synthetic-alpha-01",modelHash:ne.modelHash,rules:"LC_T20_01",rulesHash:ne.rulesHash,worldHash:ne.worldHash}),jt=Object.freeze({engine:Wt.engine,eventChain:Wt.eventChain,random:"SHA256_COUNTER_V1",model:"synthetic-alpha-01",modelHash:Wt.modelHash,rules:"LC_ODI_01",rulesHash:Wt.rulesHash,worldHash:Wt.worldHash}),Wn={version:g(ve),requestId:C().regex(/^ui-[0-9]+$/),expectedRevision:F().int().nonnegative()},Mi={saveId:C().min(1).max(160),seasonId:C().min(1).max(128),scheduleSha256:C().regex(/^[a-f0-9]{64}$/),fixtureId:C().min(1).max(128),fixtureOrdinal:F().int().min(0).max(55),roundNumber:F().int().min(1).max(14),matchDayDate:gn(),homeTeamId:C().min(1).max(128),awayTeamId:C().min(1).max(128),groundId:C().min(1).max(128),matchId:C().min(1).max(128),matchGameId:C().min(1).max(128),matchSeed:C().min(1).max(256),selections:Kn([Ie,Ie]),careerStateSha256:C().regex(/^[a-f0-9]{64}$/),managedTeamId:C().min(1).max(128).optional()},nc=Gn("launchVersion",[m({...Mi,launchVersion:g("LC_CAREER_USER_MATCH_LAUNCH_V1")}),m({...Mi,launchVersion:g("LC_CAREER_USER_MATCH_LAUNCH_V2"),worldCopy:Ra}),m({...Mi,launchVersion:g("LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"),rosterPack:xe}),m({...Mi,launchVersion:g("LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"),rosterPack:xe,worldCopy:Ra.optional()})]),ua=Gn("type",[m({...Wn,type:g("BOOT"),fresh:z().optional(),careerFixture:nc.nullable().optional()}),m({...Wn,type:g("START"),format:D(["T20","ODI","RED_BALL"]).default("T20"),selections:Kn([Ie,Ie]),groundId:C().min(1),careerFixture:nc.nullable().optional(),worldCopy:Ra.nullable().optional(),rosterPack:xe.nullable().optional()}),m({...Wn,type:g("COMMAND"),origin:D(["HUMAN","AI"]),command:_e([hl,Sl,Al])}),m({...Wn,type:g("AI_STEP"),clubStyle:z().optional(),matchAware:z().optional(),teamId:C().min(1).max(128),delegated:z().optional(),redBallProfile:Br.optional()}),m({...Wn,type:g("SET_DELEGATION"),teamId:C().min(1).max(128),expectedDelegationRevision:F().int().nonnegative(),categories:O(ud).max(10).refine(n=>new Set(n).size===n.length),redBallProfile:Br.optional()}),m({...Wn,type:g("VERIFY")}),m({...Wn,type:g("CHECK_SEEDED_WEATHER")}),m({...Wn,type:g("REBUILD_ANALYTICS")}),m({...Wn,type:g("CANCEL_ANALYTICS"),targetRequestId:C().regex(/^ui-[0-9]+$/)}),m({...Wn,type:g("PREVIEW_DIAGNOSTIC"),includeSeed:z().optional()}),m({...Wn,type:g("EXPORT_DIAGNOSTIC"),sha256:C().regex(/^[a-f0-9]{64}$/)}),m({...Wn,type:g("LIST_SAVES")}),m({...Wn,type:g("MANUAL_SAVE"),title:C().trim().min(1).max(80)}),m({...Wn,type:g("LOAD_SAVE"),saveId:C().min(1).max(160)}),m({...Wn,type:g("DELETE_SAVE"),saveId:C().min(1).max(160)}),m({...Wn,type:g("EXPORT_SAVE"),saveId:C().min(1).max(160).nullable()}),m({...Wn,type:g("IMPORT_SAVE"),archive:ih(Uint8Array)}),m({...Wn,type:g("SUPER_OVER"),action:Gn("kind",[m({kind:g("START")}),m({kind:g("COMMAND"),command:Xo}),m({kind:g("AI"),teamId:C().min(1).max(128)})])}),m({...Wn,type:g("TOURNAMENT_START"),format:D(["T20","ODI"]),runId:C().min(1).max(128),runSeed:C().min(1).max(128),fixture:L1,rosterPack:xe.optional(),selections:Kn([Ie,Ie]).optional()}),m({...Wn,type:g("SCENARIO_START"),scenarioId:C().min(1).max(128)}),m({...Wn,type:g("RECOVER_MANAGED")}),m({...Wn,type:g("ABANDON_MANAGED")}),m({...Wn,type:g("RETRY_WRITER")}),m({...Wn,type:g("RELEASE_WRITER")})]);function ec(n,e,t,a=()=>({gameId:"human-exhibition",matchId:"human-t20"})){const{world:o}=Da(n,e),i={teams:o.teams.map(P=>{const B=P.squadIds.map(Q=>o.players.find(En=>En.playerId===Q)),W=B.find(Q=>Q.role==="KEEPER"),Z=B.filter(Q=>Q.playerId!==W.playerId&&at(Q)).slice(0,6),j=[W,...Z,...B.filter(Q=>Q!==W&&!Z.includes(Q))].slice(0,11);return{id:P.teamId,name:P.name,players:B.map(Q=>({id:Q.playerId,name:Q.name,role:Q.role,style:Q.bowlingStyle,canBowl:at(Q),batHand:Q.batHand})),suggested:{teamId:P.teamId,playerIds:j.map(Q=>Q.playerId),captainId:j[0].playerId,keeperId:W.playerId}}}),grounds:o.grounds.map(P=>({id:P.groundId,name:P.name,seamBp:P.pitchPrior.seamBp,turnBp:P.pitchPrior.turnBp}))};let r=null,s=null,c=null,u=o;function h(P){if(s&&P){const B=Fi(P,o).world,W=new Map(B.teams.map(Q=>[Q.teamId,Q.name])),Z=new Map(B.grounds.map(Q=>[Q.groundId,Q.name])),j=new Map(B.players.map(Q=>[Q.playerId,Q.name]));u={...s.world,teams:s.world.teams.map(Q=>{const En=W.get(Q.teamId);return En?{...Q,name:En}:Q}),grounds:s.world.grounds.map(Q=>{const En=Z.get(Q.groundId);return En?{...Q,name:En}:Q}),players:s.world.players.map(Q=>{const En=j.get(Q.playerId);return En?{...Q,name:En}:Q})};return}u=s?.world??(P?Fi(P,o).world:o)}function p(P){const B=P?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V2"?P.worldCopy:P?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"?P.worldCopy??null:null;h(B),c=P}const E=new Map,b=[],w=P=>te(ce(P)),v=zr(2);let T=null,A=-1,I=null,f=null,S=null,k=null,R=[],_=[];function U(){if(!r)return null;const P=r,B=P.core,W=B.innings[B.activeInningsIndex],Z=W?.innings;v.update(P.events);const j=B.phase==="COMPLETE"?gi(P):null,Q=Object.fromEntries(P.setup.teams.flatMap(mn=>mn.xi.map(Ln=>[Ln.playerId,u.players.find(Un=>Un.playerId===Ln.playerId)?.name??Ln.name]))),En=mn=>u.teams.find(Ln=>Ln.teamId===mn)?.name??"",J=B.phase==="TOSS"?P.setup.teams[0].teamId:B.phase==="AWAITING_INNINGS"?B.tossWinnerId:B.phase==="AWAITING_BATTER"?Z.battingTeamId:B.phase==="AWAITING_BOWLER"?Z.bowlingTeamId:null,pn={TOSS:`${En(J)}: call the toss`,AWAITING_INNINGS:`${En(B.tossWinnerId)} won the toss: choose bat or bowl`,AWAITING_BATTER:`${En(J)}: select ${Z?.northBatterId===null&&Z.southBatterId===null?"the opening batter":"the next batter"}`,AWAITING_BOWLER:`${En(J)}: select a bowler`,READY:"Ready: set tactics or advance play",COMPLETE:"Match complete: review the scorecard"},be=(P.setup.teams.find(mn=>mn.teamId===J)?.xi??[]).map(mn=>{let Ln="";B.phase==="AWAITING_BATTER"&&(Ln=W.batting[mn.playerId].dismissed?"Already dismissed":[Z.northBatterId,Z.southBatterId].includes(mn.playerId)?"Already batting":""),B.phase==="AWAITING_BOWLER"&&(Ln=mn.playerId===W.keeperId?"Designated keeper":mn.bowlingStyle===null?"Not a bowler":Z.previousOverBowlerId===mn.playerId?"Bowled the previous over":W.bowling[mn.playerId].legalBalls>=24?"Four-over limit reached":"");const{power:Un,rotation:zi,defence:qt}=mn.skills.T20;return{id:mn.playerId,name:Q[mn.playerId]??mn.name,reason:Ln,...B.phase==="AWAITING_BATTER"?{batting:{power:Un,rotation:zi,defence:qt}}:{}}});if(B.phase==="AWAITING_BOWLER"&&W&&Z){const mn=P.setup.teams.find(Un=>Un.teamId===J)?.xi??[],Ln=Js(mn.map(Un=>({id:Un.playerId,eligible:Un.playerId!==W.keeperId&&Un.bowlingStyle!==null,legalBalls:W.bowling[Un.playerId]?.legalBalls??0})),Math.ceil((120-Z.legalBalls)/6),24);for(const Un of be)!Un.reason&&Ln.has(Un.id)&&(Un.reason=Ln.get(Un.id))}let ke=B.phase==="COMPLETE"?"Match complete":B.phase!=="READY"?"Complete the next decision first":"";if(B.phase==="READY"&&W)try{const mn=Z.strikerEnd==="NORTH"?Z.northBatterId:Z.southBatterId,Ln=P.setup.teams.flatMap(Un=>Un.xi).find(Un=>Un.playerId===mn);Ca(B.fieldSlots,W.outfieldIds,Ln.batHand,Z.legalBalls)}catch{ke="Field is invalid for this striker. Apply a legal named field before advancing."}const je=B.result,On=Object.fromEntries(P.setup.teams.flatMap(mn=>mn.xi.map(Ln=>[Ln.playerId,Ln.batHand]))),K=u.grounds.find(mn=>mn.groundId===P.setup.ground.groundId)?.name??P.setup.ground.name;if(T!==P||A!==P.revision||I!==u){const mn=Object.fromEntries(P.setup.teams.map(Ln=>[Ln.teamId,En(Ln.teamId)]));R=es({format:"T20",events:P.events,playerNames:Q,teamNames:mn,teamIds:[P.setup.teams[0].teamId,P.setup.teams[1].teamId],groundName:K,presentationKey:`lcxxvi-commentary:T20:${P.setup.matchId}`}).entries,_=as({format:"T20",matchId:P.setup.matchId,commentaryEntries:R}).cues,f=Jr({format:"T20",phase:B.phase,innings:B.innings,activeIndex:B.activeInningsIndex,events:P.events,names:Q,pitch:B.pitch,fatigueBpByPlayerId:B.fatigueBp,activeBattingPlans:B.battingPlans,activeBowlingPlan:B.bowlingPlan,activeFieldSlots:B.fieldSlots,outfieldIds:W?.outfieldIds??[],bowlerVariationsByPlayerId:Object.fromEntries(P.setup.teams.flatMap(Ln=>Ln.xi.map(Un=>[Un.playerId,Un.variations])))}),S=ns({format:"T20",phase:B.phase,innings:B.innings,activeIndex:B.activeInningsIndex,fieldSlots:B.fieldSlots,events:P.events,names:Q,hands:On}),T=P,A=P.revision,I=u}const cn=R,un=B.phase==="COMPLETE"&&je?je.kind==="TIE"?"Match tied":`${En(je.winnerTeamId)} won by ${je.marginRuns??je.marginWickets} ${je.marginType?.toLowerCase()}`:null;return{format:"T20",fatigueBp:{...B.fatigueBp},captainNotes:Object.fromEntries(P.setup.teams.map(mn=>[mn.teamId,LT(P.commands,mn.teamId,Q)])),revision:P.revision,phase:B.phase,nextDecision:pn[B.phase]??B.phase,decisionTeamId:J,teams:P.setup.teams.map(mn=>({id:mn.teamId,name:En(mn.teamId),captainId:mn.captainId,keeperId:mn.keeperId,playerIds:[...mn.playerIds],...u.packId!==o.packId?{colours:[...u.teams.find(Ln=>Ln.teamId===mn.teamId).colours]}:{}})),names:Q,hands:On,ground:u.grounds.find(mn=>mn.groundId===P.setup.ground.groundId)?.name??P.setup.ground.name,innings:structuredClone(B.innings),activeIndex:B.activeInningsIndex,candidates:be,bowlingPlan:structuredClone(B.bowlingPlan),battingPlans:structuredClone(B.battingPlans),fieldSlots:structuredClone(B.fieldSlots),positions:ya.positions.map(mn=>mn.slotId),matchId:P.setup.matchId,advanceReason:ke,commentary:cn,audioCues:_,scorecard:j,analytics:j?v.snapshot(j):null,tacticalAssistant:f,fieldPresentation:S,matchAward:B.phase==="COMPLETE"&&j?k??=os({format:"T20",scorecard:j,events:P.events,playerNames:Q,teamNames:Object.fromEntries(u.teams.map(mn=>[mn.teamId,mn.name]))}):null,resultText:un,eventCount:P.events.length,lastEventHash:P.lastEventHash}}function M(){if(!c||c.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"||!r||r.core.phase!=="COMPLETE")return null;const P=gi(r),B=w(P),W=f5({seasonId:c.seasonId,fixtureId:c.fixtureId,matchId:c.matchId,matchDayDate:c.matchDayDate,session:r}),Z=w({source:"USER_MATCH",seasonId:c.seasonId,fixtureId:c.fixtureId,matchId:c.matchId,scorecardSha256:B,finalEventHash:r.lastEventHash});return{resultVersion:"LC_CAREER_USER_MATCH_RESULT_V1",seasonId:c.seasonId,scheduleSha256:c.scheduleSha256,fixtureId:c.fixtureId,matchId:c.matchId,fixtureOrdinal:c.fixtureOrdinal,roundNumber:c.roundNumber,matchDayDate:c.matchDayDate,homeTeamId:c.homeTeamId,awayTeamId:c.awayTeamId,selectedTeams:[structuredClone(c.selections[0]),structuredClone(c.selections[1])],scorecard:P,scorecardSha256:B,finalEventHash:r.lastEventHash,sourceCompletionSha256:Z,conditionDelta:W,completedSession:structuredClone(r)}}function H(){if(!r||r.core.phase!=="COMPLETE")throw new Error("Complete the match before verifying its final scorecard.");const P=s?b5(r,s):B_(r.setup,r.events,bu(r)),B=gi(r);if(w(gi(P))!==w(B))throw new Error("Replay scorecard mismatch.");return s||P_(r),{revision:r.revision,eventsSha256:w(r.events),scorecardSha256:w(B),eventCount:r.events.length,replay:!0,resimulation:!0,humanRequests:b.filter(W=>W.origin==="HUMAN").length,systemAutopilotRequests:b.filter(W=>W.origin==="AI").length}}function an(P){if(!r)throw new Error("Start a match first.");const B=P.command;if(B.kind==="CONFIRM_TEAMS")throw new Error("Team confirmation is only available through match setup.");if(B.commandId!==P.requestId||B.expectedRevision!==P.expectedRevision)throw new Error("Command envelope mismatch.");const W=r.core.innings[r.core.activeInningsIndex],Z="teamId"in B.payload?B.payload.teamId:B.kind==="SET_BATTING_PLAN"?W?.innings.battingTeamId:W?.innings.bowlingTeamId,j=B.kind==="ADVANCE"?"SYSTEM":`USER:${Z}`;if(B.actorId!==(P.origin==="AI"?B.kind==="ADVANCE"?"SYSTEM":`AI:${Z}`:j))throw new Error("Only human-owned or explicitly delegated AI-owned commands may change the team decision.");r=s?ks(r,B).session:ka(r,B).session,b.push({requestId:P.requestId,origin:P.origin,commandKind:B.kind,engineActorId:B.actorId})}function y(P,B=null){s=B,r=s?Ku(P,s):x_(P,n,e),p(null),E.clear(),b.splice(0,b.length,...r.commands.map(W=>({requestId:W.commandId,origin:W.actorId.startsWith("AI:")?"AI":"HUMAN",commandKind:W.kind,engineActorId:W.actorId})))}function L(){return r?structuredClone(r):null}function $(P,B=null){return{version:ve,requestId:P,revision:r?.revision??0,pins:ne,catalog:r?null:structuredClone(i),view:U(),error:B,verification:null,careerResult:M(),...c?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"&&r?.core.phase==="COMPLETE"?{rosterCareerSession:structuredClone(r)}:{}}}return{restore:y,setWorldCopy:h,snapshot:L,boundFixture:()=>c,currentResponse:$,handle(P){let B="invalid",W=null,Z=null,j;try{j=ua.parse(P),B=j.requestId;const En=E.get(B);if(En){if(En.request!==JSON.stringify(j))throw new Error("Request ID already used with different content.");return structuredClone(En.response)}if(j.type==="BOOT"&&j.careerFixture){if(r&&(r.setup.gameId!==j.careerFixture.matchGameId||r.setup.matchId!==j.careerFixture.matchId))throw new Error("Recovered match does not match the scheduled career fixture.");p(j.careerFixture)}if(j.type!=="BOOT"&&j.expectedRevision!==(r?.revision??0))throw new Error("Stale revision. Review the current decision and try again.");if(j.type==="START"){if(j.format!=="T20")throw new Error("T20 controller received a non-T20 start.");if(r)throw new Error("A match is already in progress.");if(j.careerFixture&&j.worldCopy)throw new Error("A career match cannot replace its world copy.");const J=j.careerFixture&&(j.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"||j.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE")?j.careerFixture:null;if(j.rosterPack&&(j.worldCopy||j.careerFixture&&!J))throw new Error("An imported roster cannot replace a career or edited world.");if(J&&JSON.stringify(j.rosterPack)!==JSON.stringify(J.rosterPack))throw new Error("Career roster binding mismatch.");if(s=j.rosterPack??null,p(j.careerFixture??null),j.careerFixture||h(j.worldCopy??null),c){if(c.matchId!==j.careerFixture?.matchId||c.groundId!==j.groundId)throw new Error("Career fixture binding mismatch.");if(c.homeTeamId!==j.selections[0].teamId||c.awayTeamId!==j.selections[1].teamId)throw new Error("Career fixture team order mismatch.");if(JSON.stringify(c.selections)!==JSON.stringify(j.selections))throw new Error("Career fixture XI snapshot mismatch.")}const pn=c?{gameId:c.matchGameId,matchId:c.matchId}:a();if(s){const be=Cs(s,{...pn,seed:c?c.matchSeed:t(),format:"T20",selection:{groundId:j.groundId,teams:j.selections}});r=ks(be,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:B,expectedRevision:0}).session,p(j.careerFixture??null),j.careerFixture||(u=s.world),b.push({requestId:B,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}else{const be=Eu({setupVersion:"LC_T20_SETUP_V1",setup:{schemaVersion:"1.0.0",...pn,format:"T20",worldPackId:xn.worldPackId,rulesId:"LC_T20_01",modelId:"synthetic-alpha-01",randomId:"SHA256_COUNTER_V1",seed:c?c.matchSeed:t(),teamIds:j.selections.map(On=>On.teamId),groundId:j.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:xn.worldFileSha256,worldCanonicalSha256:ne.worldHash,rulesHash:ne.rulesHash,modelHash:Cn,stagePackHash:Zn,selectedTeams:j.selections},n,e),ke=ui(be);for(const[On,K]of Object.entries(ne))if(ke.executionManifest[On]!==K)throw new Error("Worker build identity mismatch.");r=ka(ke,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:B,expectedRevision:0}).session,b.push({requestId:B,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}}else j.type==="COMMAND"?an(j):j.type==="VERIFY"&&(Z=H())}catch(En){W=En instanceof Error&&En.name!=="ZodError"?En.message:"Invalid request. Check selections, required fields and supported settings."}const Q={version:ve,requestId:B,revision:r?.revision??0,pins:ne,catalog:r?null:structuredClone(i),view:U(),error:W,verification:Z,careerResult:M(),...c?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"&&r?.core.phase==="COMPLETE"?{rosterCareerSession:structuredClone(r)}:{}};return j&&!W&&E.set(B,{request:JSON.stringify(j),response:structuredClone(Q)}),Q}}}function LT(n,e,t){const a=n.filter(u=>u.actorId===`AI:${e}`),o=a.filter(u=>u.kind==="SET_BOWLING_PLAN").slice(-5),i=o.filter(u=>u.payload.length==="YORKER").length;if(i>=2)return`Called for yorkers in ${i} of the last ${o.length} bowling plan changes.`;const r=a.filter(u=>u.kind==="SET_BOWLER").slice(-6),s=r.at(-1)?.payload.bowlerId,c=r.filter(u=>u.payload.bowlerId===s).length;return s&&c>=2?`Picked ${t[s]} for ${c} of the last ${r.length} overs assigned.`:""}async function NT(n,e,t=!1){const a=n&&(t||n.core?.phase==="COMPLETE")?n.setup.seed:null,o={version:"LC_MATCH_DIAGNOSTIC_V1",modelStatus:"SYNTHETIC_ALPHA",format:n?.setup.format??null,gameId:n?.setup.gameId??null,matchId:n?.setup.matchId??null,seed:a,revision:n?.revision??null,manifest:n?.executionManifest??null,lastEventHash:n?.lastEventHash??null,failure:e,events:n?.events??[]},i=new TextEncoder().encode(G(o));if(i.length>20*1024*1024)throw new Error("Diagnostic exceeds the 20 MiB export limit.");const r=await crypto.subtle.digest("SHA-256",i),s=Array.from(new Uint8Array(r),c=>c.toString(16).padStart(2,"0")).join("");return{bytes:i,preview:{format:o.format,eventCount:o.events.length,revision:o.revision,byteCount:i.length,sha256:s,includesSeed:o.seed!==null,engine:o.manifest?.engine??null,rulesHash:o.manifest?.rulesHash??null,modelHash:o.manifest?.modelHash??null,failure:e?{requestType:e.requestType,sequence:e.sequence,invariantCode:e.invariantCode}:null}}}function Rm(n,e){if(!Number.isFinite(n)||n<0)throw new Error(`LC_T20_AI_INVALID_${e}`)}function yT(n){for(const[u,h]of Object.entries({inningsLegalBalls:n.inningsLegalBalls,inningsRuns:n.inningsRuns,wicketsLost:n.wicketsLost,availableBatters:n.availableBatters}))Rm(h,u);if(n.inningsLegalBalls>120||n.wicketsLost>10)throw new Error("LC_T20_AI_INVALID_INNINGS");const e=Math.max(1,120-n.inningsLegalBalls),t=n.targetToWin===null?null:Math.max(0,n.targetToWin-n.inningsRuns)*6/e,a=n.inningsLegalBalls<36?"EARLY":n.inningsLegalBalls<90?"MIDDLE":"DEATH";let o=a==="EARLY"||a==="MIDDLE"?2:3;t!==null&&(o=t>12?4:t>9?3:t<5?1:2),n.wicketsLost>=7&&e>24&&(t===null||t<=9)&&(o=Math.min(o,1));const i=n.bowlingCandidates.filter(u=>{for(const[h,p]of Object.entries(u))h!=="playerId"&&Rm(p,h);return u.quotaRemaining>0&&u.fatigueBp<=1e4}),r=i.map(u=>({id:u.playerId,score:2*u.control+2*u.movement+u.variation+u.stamina/2-u.fatigueBp/90-(a!=="DEATH"&&u.quotaRemaining<=6?30:0)}));r.sort((u,h)=>h.score-u.score||u.id.localeCompare(h.id));const s=i.find(u=>u.playerId===r[0]?.id),c=s&&s.fatigueBp>=7e3?"CONSERVE":a==="DEATH"&&s&&s.fatigueBp<4e3?"MAXIMUM":"NORMAL";return{policyId:"LC_T20_TACTICAL_CAPTAIN_V1",aggression:o,preferredBowlerId:s?.playerId??null,bowlingEffort:c,bowlingLength:a==="DEATH"?"YORKER":a==="MIDDLE"?"FULL":"GOOD",fieldIntent:n.wicketsLost>=7?"ATTACK":a==="DEATH"?"DEFEND":"BALANCED",reason:`Public score context: ${a.toLowerCase()} phase, ${n.wicketsLost} wickets, ${e} balls remaining${t===null?"":`, required rate ${t.toFixed(2)}`}`}}function vm(n,e){if(!Number.isFinite(n)||n<0)throw new Error(`LC_ODI_AI_INVALID_${e}`)}function DT(n,e){if(n.length!==9||new Set(n).size!==9)throw new Error("LC_ODI_AI_INVALID_OUTFIELD");return[...n].sort().map((a,o)=>({slotId:e[o],playerId:a}))}function CT(n,e){return n<60?e==="ATTACK"?["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"]:["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","long-on"]:n<240?e==="ATTACK"?["slip-1","point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","fine-leg"]:e==="DEFEND"?["point","cover","mid-off","deep-cover","long-off","mid-on","midwicket","deep-square-leg","long-on"]:["point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","fine-leg","long-on"]:e==="ATTACK"?["slip-1","point","cover","deep-cover","long-off","mid-on","midwicket","deep-square-leg","long-on"]:["point","cover","deep-cover","long-off","mid-on","midwicket","deep-square-leg","fine-leg","long-on"]}function kT(n){for(const[w,v]of Object.entries({inningsLegalBalls:n.inningsLegalBalls,inningsRuns:n.inningsRuns,wicketsLost:n.wicketsLost,availableBatters:n.availableBatters}))vm(v,w);if(n.inningsLegalBalls>300||n.wicketsLost>10)throw new Error("LC_ODI_AI_INVALID_INNINGS");const e=Math.max(1,300-n.inningsLegalBalls),t=n.targetToWin===null?null:Math.max(0,n.targetToWin-n.inningsRuns)*6/e,a=n.inningsLegalBalls<60?"POWERPLAY_1":n.inningsLegalBalls<240?"MIDDLE":"LATE";let o=a==="POWERPLAY_1"||a==="MIDDLE"?2:3,i=a==="MIDDLE"?"ROTATE":"NORMAL";t!==null?(o=t>10.5?4:t>7.5?3:t<4.2?1:2,i=t>8?"NORMAL":t<4.5?"ROTATE":i):a==="LATE"&&n.availableBatters>=5&&(o=4,i="NORMAL"),n.availableBatters<=5&&e>90&&(t===null||t<=7.5)&&(o=Math.min(o,1),i=n.availableBatters<=3?"PROTECT":"ROTATE");const r=n.bowlingCandidates.filter(w=>{for(const[v,T]of Object.entries(w))v!=="playerId"&&vm(T,v);return w.quotaRemaining>0&&w.fatigueBp<=1e4}),s=r.some(w=>w.quotaRemaining>=24&&w.fatigueBp<5500),c=r.map(w=>{const v=a==="MIDDLE"&&s?w.quotaRemaining<=12?95:w.quotaRemaining<=18?70:0:0,T=a==="POWERPLAY_1"?2.2*w.movement+1.8*w.control+.8*w.variation:a==="MIDDLE"?2*w.control+1.8*w.variation+1*w.movement:2.2*w.control+1.8*w.variation+1.4*w.movement;return{id:w.playerId,score:T+w.stamina/2-w.fatigueBp/85-v}});c.sort((w,v)=>v.score-w.score||w.id.localeCompare(v.id));const u=r.find(w=>w.playerId===c[0]?.id),h=u&&u.fatigueBp>=6500?"CONSERVE":a==="LATE"&&u&&u.fatigueBp<3800?"MAXIMUM":"NORMAL",p=a==="LATE"?"YORKER":a==="POWERPLAY_1"?"FULL":"GOOD",E=n.wicketsLost>=7||a==="POWERPLAY_1"&&n.wicketsLost>=2?"ATTACK":a==="LATE"||t!==null&&t>7.5?"DEFEND":"BALANCED",b=DT(n.outfieldIds,CT(n.inningsLegalBalls,E));return{policyId:"LC_ODI_TACTICAL_CAPTAIN_V1",aggression:o,battingIntent:i,preferredBowlerId:u?.playerId??null,bowlingEffort:h,bowlingLength:p,fieldIntent:E,fieldSlots:b,reason:`Public ODI context: ${a.toLowerCase()}, ${n.wicketsLost} wickets, ${e} balls left${t===null?"":`, req ${t.toFixed(2)}`}`}}function Ee(n,e,t=!1){if(!Number.isFinite(n)||!t&&n<0)throw new Error(`LC_RED5_AI_INVALID_${e}`)}function BT(n,e){if(n.length!==9||new Set(n).size!==9)throw new Error("LC_RED5_AI_INVALID_OUTFIELD");return[...n].sort().map((a,o)=>({slotId:e[o],playerId:a}))}function PT(n){return n==="ATTACK"?["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"]:n==="DEFEND"?["point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","fine-leg","long-on"]:["slip-1","point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","long-on"]}function xT(n,e,t,a,o){if(a){const u=Math.max(0,5-n);return Math.floor(o/6)+u*90}const i=Math.max(0,90-Math.floor(t/6)),r=Math.max(0,Math.floor((18*3600-e)/240)),s=Math.min(i,Math.max(15,r)),c=Math.max(0,5-n);return s+c*90}function Am(n){if(Ee(n.inningsIndex,"inningsIndex"),Ee(n.inningsLegalBalls,"inningsLegalBalls"),Ee(n.inningsRuns,"inningsRuns"),Ee(n.wicketsLost,"wicketsLost"),Ee(n.leadRuns,"leadRuns",!0),Ee(n.availableBatters,"availableBatters"),Ee(n.day,"day"),Ee(n.localSeconds,"localSeconds"),Ee(n.dayLegalBalls,"dayLegalBalls"),Ee(n.ballAgeLegalBalls,"ballAgeLegalBalls"),n.inningsIndex>3||n.wicketsLost>10||n.day<1||n.day>5)throw new Error("LC_RED5_AI_INVALID_STATE");const e=xT(n.day,n.localSeconds,n.dayLegalBalls,n.finalHourActive,n.finalHourBallsRemaining);let t=!1;if(n.inningsIndex===0&&n.wicketsLost<10){const S=n.profile==="AGGRESSIVE"?500:n.profile==="BALANCED"?560:620;t=n.inningsRuns>=S||n.day>=3&&n.inningsRuns>=S-80}else if(n.inningsIndex===2&&n.wicketsLost<10&&n.leadRuns>0){const S=n.profile==="AGGRESSIVE"?260:n.profile==="BALANCED"?320:380,k=n.profile==="AGGRESSIVE"?210:n.profile==="BALANCED"?260:320,R=n.day>=5?k:S,_=n.profile==="AGGRESSIVE"?42:n.profile==="BALANCED"?50:60;(n.leadRuns>=R&&e>=_||n.day===5&&e<=_+12&&e>=35&&n.leadRuns>=k)&&(t=!0)}const a=n.bowlingCandidates.filter(S=>!S.isSpin),o=a.length>0?a.reduce((S,k)=>S+k.fatigueBp,0)/a.length:0;let i=!1;n.followOnAvailable&&(n.profile==="AGGRESSIVE"?i=o<5500||n.day>=4||n.leadRuns>=300:n.profile==="BALANCED"?i=n.day>=4||o<3400||n.leadRuns>=285:i=n.day>=4||o<2400&&n.leadRuns>=260||n.leadRuns>=350);const r=a.some(S=>S.fatigueBp<(n.profile==="CONSERVATIVE"?5e3:6500)),s=n.pitchTurnBp>=6200&&n.pitchWearPoints>=320&&!a.some(S=>S.fatigueBp<3e3);let c=!1;n.newBallAvailable&&(n.profile==="AGGRESSIVE"?c=r||!s:n.profile==="BALANCED"?c=r&&!s:c=r&&n.pitchTurnBp<6200);let u=n.profile==="AGGRESSIVE"?2:1,h=n.profile==="CONSERVATIVE"?"PROTECT":"ROTATE";if(n.inningsIndex===2&&n.leadRuns>=180&&n.availableBatters>=5)u=n.profile==="AGGRESSIVE"?3:n.profile==="BALANCED"?2:1,h=n.profile==="CONSERVATIVE"?"ROTATE":"NORMAL";else if(n.inningsIndex===3&&n.targetToWin!==null){const S=Math.max(0,n.targetToWin-n.inningsRuns),k=S/Math.max(1,e);n.day===5&&n.availableBatters<=4&&S>75||n.profile!=="AGGRESSIVE"&&k>4.6&&n.availableBatters<=5?(u=0,h="PROTECT"):S<=60||n.profile==="AGGRESSIVE"&&k<=4.8&&n.availableBatters>=5?(u=k>3.8?3:2,h="NORMAL"):(u=k>3.5?2:1,h="ROTATE")}else n.availableBatters<=4&&n.inningsLegalBalls<360&&(u=0,h="PROTECT");const p=n.bowlingCandidates.filter(S=>(Ee(S.control,"control"),Ee(S.movement,"movement"),Ee(S.variation,"variation"),Ee(S.stamina,"stamina"),Ee(S.fatigueBp,"fatigueBp"),Ee(S.legalBallsBowled,"legalBallsBowled"),S.fatigueBp<=1e4)),E=n.profile==="CONSERVATIVE"?42:n.profile==="BALANCED"?52:68,b=c?0:n.ballAgeLegalBalls,w=p.map(S=>{const k=!S.isSpin&&b<120?40+(n.pitchSeamBp-5e3)/150:0,R=S.isSpin&&b>=90&&(b>=180||n.pitchWearPoints>=200)?22+(n.pitchTurnBp-5e3)/150+Math.min(20,n.pitchWearPoints/25):0,_=S.isSpin?1.9*S.control+2*S.variation+.9*S.movement:2*S.control+2.1*S.movement+.7*S.variation,U=!S.isSpin&&S.fatigueBp>=5500?45:0;return{id:S.playerId,score:_+S.stamina*.6+k+R-S.fatigueBp/E-U}});w.sort((S,k)=>k.score-S.score||S.id.localeCompare(k.id));const v=p.find(S=>S.playerId===w[0]?.id),T=v&&v.fatigueBp>=5200?"CONSERVE":v&&!v.isSpin&&b<60&&v.fatigueBp<2600&&n.profile==="AGGRESSIVE"?"MAXIMUM":"NORMAL",A=b<72&&v&&!v.isSpin?"FULL":"GOOD",I=n.profile==="AGGRESSIVE"&&(b<150||n.wicketsLost>=6||n.inningsIndex===3)?"ATTACK":n.profile==="CONSERVATIVE"&&n.targetToWin!==null&&n.targetToWin-n.inningsRuns<90?"DEFEND":b<90||n.wicketsLost>=7?"ATTACK":n.profile==="CONSERVATIVE"?"DEFEND":"BALANCED",f=BT(n.outfieldIds,PT(I));return{policyId:"LC_RED5_TACTICAL_CAPTAIN_V1",profile:n.profile,shouldDeclare:t,enforceFollowOn:i,takeNewBall:c,aggression:u,battingIntent:h,preferredBowlerId:v?.playerId??null,bowlingEffort:T,bowlingLength:A,fieldIntent:I,fieldSlots:f,reason:`Red-ball ${n.profile.toLowerCase()} posture: day ${n.day}, inn ${n.inningsIndex+1}, lead ${n.leadRuns}, ~${e} overs left`}}const bm="LC_RED5_UTILITY_V1",wm="LC_RED5_PLANNING_BUDGET_V1",Om={version:wm,rolloutsPerAction:2,maxCommandsPerRollout:700,continueOversBeforeReview:6};function Lm(n){if(n.version!==wm||!Number.isSafeInteger(n.rolloutsPerAction)||n.rolloutsPerAction<1||n.rolloutsPerAction>32||!Number.isSafeInteger(n.maxCommandsPerRollout)||n.maxCommandsPerRollout<10||n.maxCommandsPerRollout>2500||!Number.isSafeInteger(n.continueOversBeforeReview)||n.continueOversBeforeReview<1||n.continueOversBeforeReview>60)throw new Error("LC_RED5_INVALID_PLANNING_BUDGET")}function Vi(n,e,t){return n.completed?n.winnerTeamId===e?n.wonByInnings?t==="AGGRESSIVE"?1200:1150:1e3:n.isTie?250:n.isDraw?t==="CONSERVATIVE"?350:t==="BALANCED"?150:25:t==="CONSERVATIVE"?-1150:t==="BALANCED"?-1e3:-900:Math.max(-300,Math.min(300,Math.round(n.evaluatingTeamLeadRuns/2)))}function HT(n){const e=n.budget??Om;Lm(e);let t=0,a=0;for(let r=0;r<e.rolloutsPerAction;r++)t+=Vi(n.simulateAction("DECLARE_NOW",r,e),n.evaluatingTeamId,n.profile),a+=Vi(n.simulateAction("BAT_ON",r,e),n.evaluatingTeamId,n.profile);const o=t/e.rolloutsPerAction,i=a/e.rolloutsPerAction;return{utilityVersion:bm,budget:e,declareMeanUtility:o,batOnMeanUtility:i,recommendedDeclare:o>i,rolloutsEvaluated:e.rolloutsPerAction*2}}function FT(n){const e=n.budget??Om;Lm(e);let t=0,a=0;for(let r=0;r<e.rolloutsPerAction;r++)t+=Vi(n.simulateAction("ENFORCE",r,e),n.evaluatingTeamId,n.profile),a+=Vi(n.simulateAction("BAT_AGAIN",r,e),n.evaluatingTeamId,n.profile);const o=t/e.rolloutsPerAction,i=a/e.rolloutsPerAction;return{utilityVersion:bm,budget:e,enforceMeanUtility:o,batAgainMeanUtility:i,recommendedEnforce:o>=i,rolloutsEvaluated:e.rolloutsPerAction*2}}function Wi(n){return[...n].sort((e,t)=>e.playerId.localeCompare(t.playerId)).map(e=>`${e.playerId}:${e.slotId}`).join("|")}function MT(n,e,t,a=!1,o=a){const i=VT(n,e,a,o);if(!i||!t)return i;const s={CALL_TOSS:"TOSS",CHOOSE_INNINGS:"INNINGS",SET_BATTER:"BATTER",SET_BOWLER:"BOWLER",SET_BATTING_PLAN:"BATTING_PLAN",SET_BOWLING_PLAN:"BOWLING_PLAN",SET_FIELD:"FIELD"}[i.kind];return s&&t.includes(s)?i:null}function VT(n,e,t,a){if(!n.setup.teams.some(T=>T.teamId===e))throw new Error("LC_T20_AI_UNKNOWN_TEAM");const o=n.core.phase;if(o==="COMPLETE"||o==="SETUP")return null;const i=n.core.innings[n.core.activeInningsIndex]?.innings,r={commandId:`opponent-${String(n.revision+1).padStart(6,"0")}`,expectedRevision:n.revision},s=T=>({...T,...r});if(o==="TOSS"||o==="AWAITING_INNINGS"){const T=o==="TOSS"?n.setup.teams[0].teamId:n.core.tossWinnerId;return e!==T?null:s(mi(n))}if(!i)return null;const c=i.battingTeamId===e,u=i.bowlingTeamId===e,h=n.core.innings[n.core.activeInningsIndex],p=n.setup.teams.find(T=>T.teamId===i.bowlingTeamId),E=p.xi.filter(T=>T.bowlingStyle&&T.playerId!==p.keeperId&&T.playerId!==i.previousOverBowlerId).filter(T=>h.bowling[T.playerId].legalBalls<24).map(T=>({playerId:T.playerId,control:T.skills.T20.control,movement:T.skills.T20.movement,variation:T.skills.T20.variation,stamina:T.skills.T20.stamina,fatigueBp:n.core.fatigueBp[T.playerId]??0,legalBallsBowled:h.bowling[T.playerId].legalBalls,quotaRemaining:24-h.bowling[T.playerId].legalBalls})),b={inningsLegalBalls:i.legalBalls,inningsRuns:i.runs,wicketsLost:i.wickets,targetToWin:i.targetToWin,availableBatters:Math.max(0,10-i.wickets),bowlingCandidates:E},w={...yT(b)},v=[...e].reduce((T,A)=>T+A.charCodeAt(0),0)%4<2;if((t||a&&v)&&u&&o==="AWAITING_BOWLER"&&E.length>1){const T=Js(p.xi.map(S=>({id:S.playerId,eligible:!!S.bowlingStyle&&S.playerId!==p.keeperId,legalBalls:h.bowling[S.playerId]?.legalBalls??0})),Math.ceil((120-i.legalBalls)/6),24),A=E.filter(S=>!T.has(S.playerId)).sort((S,k)=>k.control+k.movement-k.fatigueBp/250-(S.control+S.movement-S.fatigueBp/250)),f=A.length>1&&v&&i.legalBalls>=72&&i.legalBalls<108&&A[0].quotaRemaining<=12?A[1]:t?A[0]:A.find(S=>S.playerId===w.preferredBowlerId)??A[0];return{...r,actorId:`AI:${e}`,kind:"SET_BOWLER",payload:{teamId:e,bowlerId:f.playerId}}}if((t||a)&&o==="READY"){const T=i.strikerEnd==="NORTH"?i.northBatterId:i.southBatterId,A=T?h.batting[T]?.ballsFaced??0:0;if(u&&!v&&A<4&&(w.bowlingLength="YORKER",w.bowlingEffort="MAXIMUM"),t&&c&&i.targetToWin&&120-i.legalBalls>0){const I=(i.targetToWin-i.runs)*6/(120-i.legalBalls);I>=9?w.aggression=4:I<5&&i.wickets>=6&&(w.aggression=1)}}if(o==="AWAITING_BATTER"&&c)return s(mi(n));if(o==="AWAITING_BOWLER"&&u)return w.preferredBowlerId?{...r,actorId:`AI:${e}`,kind:"SET_BOWLER",payload:{teamId:e,bowlerId:w.preferredBowlerId}}:s(mi(n));if(o!=="READY")return null;if(c){const T=i.strikerEnd==="NORTH"?i.northBatterId:i.southBatterId;if(T&&(n.core.battingPlans[T]?.aggression??2)!==w.aggression)return{...r,actorId:`AI:${e}`,kind:"SET_BATTING_PLAN",payload:{playerId:T,aggression:w.aggression,intent:"NORMAL"}}}if(u&&n.core.bowlingPlan){const T=n.core.bowlingPlan;if(T.effort!==w.bowlingEffort||T.length!==w.bowlingLength)return{...r,actorId:`AI:${e}`,kind:"SET_BOWLING_PLAN",payload:{...T,length:w.bowlingLength,effort:w.bowlingEffort}}}return null}function WT(n,e,t){if(!n.setup.teams.some(I=>I.teamId===e))throw new Error("LC_ODI_AI_UNKNOWN_TEAM");const a=I=>!t||t.includes(I),o=n.core.phase;if(o==="COMPLETE"||o==="SETUP")return null;const i={commandId:`opponent-odi-${String(n.revision+1).padStart(6,"0")}`,expectedRevision:n.revision},r=I=>({...I,...i});if(o==="TOSS")return e!==n.setup.teams[0].teamId||!a("TOSS")?null:r(po(n));if(o==="AWAITING_INNINGS")return e!==n.core.tossWinnerId||!a("INNINGS")?null:r(po(n));const s=n.core.innings[n.core.activeInningsIndex];if(!s)return null;const c=s.innings,u=c.battingTeamId===e,h=c.bowlingTeamId===e,p=n.setup.teams.find(I=>I.teamId===c.bowlingTeamId),E=n.setup.teams.find(I=>I.teamId===c.battingTeamId),b=c.strikerEnd==="NORTH"?c.northBatterId:c.southBatterId;E.xi.find(I=>I.playerId===b)?.batHand;const w=c.bowlerId??p.xi.find(I=>I.bowlingStyle&&I.playerId!==p.keeperId)?.playerId??"",v=s.outfieldIds.length===9?s.outfieldIds:p.playerIds.filter(I=>I!==p.keeperId&&I!==w).slice(0,9),T=p.xi.filter(I=>I.bowlingStyle&&I.playerId!==p.keeperId&&I.playerId!==c.previousOverBowlerId).filter(I=>s.bowling[I.playerId].legalBalls<60).map(I=>({playerId:I.playerId,control:I.skills.ODI.control,movement:I.skills.ODI.movement,variation:I.skills.ODI.variation,stamina:I.skills.ODI.stamina,fatigueBp:n.core.fatigueBp[I.playerId]??0,legalBallsBowled:s.bowling[I.playerId].legalBalls,quotaRemaining:60-s.bowling[I.playerId].legalBalls})),A=kT({inningsLegalBalls:c.legalBalls,inningsRuns:c.runs,wicketsLost:c.wickets,targetToWin:c.targetToWin,availableBatters:Math.max(0,10-c.wickets),outfieldIds:v,bowlingCandidates:T});if(o==="AWAITING_BATTER")return u&&a("BATTER")?r(po(n)):null;if(o==="AWAITING_BOWLER")return!h||!a("BOWLER")?null:A.preferredBowlerId?{...i,actorId:`AI:${e}`,kind:"SET_BOWLER",payload:{teamId:e,bowlerId:A.preferredBowlerId}}:r(po(n));if(o!=="READY")return null;if(u&&a("BATTING_PLAN")&&b){const I=n.core.battingPlans[b];if(I?.aggression!==A.aggression||I?.intent!==A.battingIntent)return{...i,actorId:`AI:${e}`,kind:"SET_BATTING_PLAN",payload:{playerId:b,aggression:A.aggression,intent:A.battingIntent}}}if(h&&a("BOWLING_PLAN")&&n.core.bowlingPlan){const I=n.core.bowlingPlan;if(I.effort!==A.bowlingEffort||I.length!==A.bowlingLength)return{...i,actorId:`AI:${e}`,kind:"SET_BOWLING_PLAN",payload:{...I,length:A.bowlingLength,effort:A.bowlingEffort}}}return h&&a("FIELD")&&c.bowlerId&&c.legalBalls%6===0&&Wi(n.core.fieldSlots)!==Wi(A.fieldSlots)?{...i,actorId:`AI:${e}`,kind:"SET_FIELD",payload:{teamId:e,fieldSlots:[...A.fieldSlots]}}:null}function UT(n,e,t="BALANCED",a){if(!n.setup.teams.some(_=>_.teamId===e))throw new Error("LC_RED5_AI_UNKNOWN_TEAM");const o=_=>!a||a.includes(_),i=n.core,r=i.phase;if(r==="COMPLETE"||r==="SETUP")return null;const s={commandId:`opponent-red5-${String(n.revision+1).padStart(6,"0")}`,expectedRevision:n.revision},c=_=>({..._,...s});if(r==="TOSS")return e!==n.setup.teams[0].teamId||!o("TOSS")?null:c(ra(n));if(r==="AWAITING_INNINGS")return e!==i.tossWinnerId||!o("INNINGS")?null:c(ra(n));if(r==="AWAITING_FOLLOW_ON"){const _=i.innings[0].innings.battingTeamId;if(e!==_||!o("FOLLOW_ON"))return null;const U=i.innings[0],M=i.innings[1],H=n.setup.teams.find(P=>P.teamId===_),an=H.playerIds.filter(P=>P!==H.keeperId).slice(0,9),y=H.xi.filter(P=>P.bowlingStyle&&P.playerId!==H.keeperId).map(P=>({playerId:P.playerId,isSpin:P.bowlingStyle?.includes("SPIN")??!1,control:P.skills.RED_BALL.control,movement:P.skills.RED_BALL.movement,variation:P.skills.RED_BALL.variation,stamina:P.skills.RED_BALL.stamina,fatigueBp:i.fatigueBp[P.playerId]??0,legalBallsBowled:M.bowling[P.playerId]?.legalBalls??0})),L=Am({profile:t,inningsIndex:1,inningsLegalBalls:M.innings.legalBalls,inningsRuns:M.innings.runs,wicketsLost:M.innings.wickets,leadRuns:U.innings.runs-M.innings.runs,targetToWin:null,availableBatters:10,day:i.clock.day,localSeconds:i.clock.localSeconds,dayLegalBalls:i.clock.dayLegalBalls,finalHourActive:i.clock.finalHourActive,finalHourBallsRemaining:i.clock.finalHourBallsRemaining,ballAgeLegalBalls:M.innings.ballAgeLegalBalls,newBallAvailable:!1,followOnAvailable:!0,pitchSeamBp:i.pitch.seamBp,pitchTurnBp:i.pitch.turnBp,pitchWearPoints:i.pitch.wearPoints,outfieldIds:an,bowlingCandidates:y}),$=Ss(n.setup)?FT({evaluatingTeamId:e,profile:t,simulateAction:(P,B,W)=>C5({liveSession:n,action:P,rolloutIndex:B,maxCommands:W.maxCommandsPerRollout})}).recommendedEnforce:L.enforceFollowOn;return{...s,actorId:`AI:${e}`,kind:"CHOOSE_FOLLOW_ON",payload:{teamId:e,enforce:$}}}const u=i.innings[i.activeInningsIndex];if(!u)return null;const h=u.innings,p=h.battingTeamId===e,E=h.bowlingTeamId===e,b=n.setup.teams.find(_=>_.teamId===h.bowlingTeamId),w=n.setup.teams.find(_=>_.teamId===h.battingTeamId),v=i.innings.filter(_=>_.innings.battingTeamId===h.battingTeamId).reduce((_,U)=>_+U.innings.runs,0),T=i.innings.filter(_=>_.innings.battingTeamId===h.bowlingTeamId).reduce((_,U)=>_+U.innings.runs,0),A=h.strikerEnd==="NORTH"?h.northBatterId:h.southBatterId;w.xi.find(_=>_.playerId===A)?.batHand;const I=h.bowlerId??b.xi.find(_=>_.bowlingStyle&&_.playerId!==b.keeperId)?.playerId??"",f=u.outfieldIds.length===9?u.outfieldIds:b.playerIds.filter(_=>_!==b.keeperId&&_!==I).slice(0,9),S=b.xi.filter(_=>_.bowlingStyle&&_.playerId!==b.keeperId&&_.playerId!==h.previousOverBowlerId).map(_=>({playerId:_.playerId,isSpin:_.bowlingStyle?.includes("SPIN")??!1,control:_.skills.RED_BALL.control,movement:_.skills.RED_BALL.movement,variation:_.skills.RED_BALL.variation,stamina:_.skills.RED_BALL.stamina,fatigueBp:i.fatigueBp[_.playerId]??0,legalBallsBowled:u.bowling[_.playerId].legalBalls})),k=r==="READY"&&h.ballAgeLegalBalls>=480&&h.legalBalls%6===0,R=Am({profile:t,inningsIndex:i.activeInningsIndex,inningsLegalBalls:h.legalBalls,inningsRuns:h.runs,wicketsLost:h.wickets,leadRuns:v-T,targetToWin:h.targetToWin,availableBatters:Math.max(0,10-h.wickets),day:i.clock.day,localSeconds:i.clock.localSeconds,dayLegalBalls:i.clock.dayLegalBalls,finalHourActive:i.clock.finalHourActive,finalHourBallsRemaining:i.clock.finalHourBallsRemaining,ballAgeLegalBalls:h.ballAgeLegalBalls,newBallAvailable:k,followOnAvailable:!1,pitchSeamBp:i.pitch.seamBp,pitchTurnBp:i.pitch.turnBp,pitchWearPoints:i.pitch.wearPoints,outfieldIds:f,bowlingCandidates:S});if(r==="AWAITING_BATTER")return p&&o("BATTER")?c(ra(n)):null;if(E&&k&&o("NEW_BALL")&&R.takeNewBall)return{...s,actorId:`AI:${e}`,kind:"TAKE_NEW_BALL",payload:{teamId:e}};if(r==="AWAITING_BOWLER")return!E||!o("BOWLER")?null:R.preferredBowlerId?{...s,actorId:`AI:${e}`,kind:"SET_BOWLER",payload:{teamId:e,bowlerId:R.preferredBowlerId}}:c(ra(n));if(r!=="READY")return null;if(p&&o("DECLARATION")){const _=v-T;if((R.shouldDeclare||h.legalBalls>0&&h.legalBalls%18===0&&(i.activeInningsIndex===0&&h.runs>=420&&i.clock.day>=3||i.activeInningsIndex===2&&_>=270&&i.clock.day>=4))&&Ss(n.setup)?HT({evaluatingTeamId:e,profile:t,simulateAction:(H,an,y)=>D5({liveSession:n,action:H,rolloutIndex:an,maxCommands:y.maxCommandsPerRollout,continueOversBeforeReview:y.continueOversBeforeReview})}).recommendedDeclare:R.shouldDeclare)return{...s,actorId:`AI:${e}`,kind:"DECLARE",payload:{teamId:e}}}if(p&&o("BATTING_PLAN")&&A){const _=i.battingPlans[A];if(_?.aggression!==R.aggression||_?.intent!==R.battingIntent)return{...s,actorId:`AI:${e}`,kind:"SET_BATTING_PLAN",payload:{playerId:A,aggression:R.aggression,intent:R.battingIntent}}}if(E&&o("BOWLING_PLAN")&&i.bowlingPlan){const _=i.bowlingPlan;if(_.effort!==R.bowlingEffort||_.length!==R.bowlingLength)return{...s,actorId:`AI:${e}`,kind:"SET_BOWLING_PLAN",payload:{..._,length:R.bowlingLength,effort:R.bowlingEffort}}}return E&&o("FIELD")&&h.bowlerId&&h.legalBalls%6===0&&Wi(i.fieldSlots)!==Wi(R.fieldSlots)?{...s,actorId:`AI:${e}`,kind:"SET_FIELD",payload:{teamId:e,fieldSlots:[...R.fieldSlots]}}:null}function tc(n,e,t,a=()=>({gameId:"human-exhibition",matchId:"human-odi"})){const{world:o}=Da(n,e),i={teams:o.teams.map(y=>{const L=y.squadIds.map(W=>o.players.find(Z=>Z.playerId===W)),$=L.find(W=>W.role==="KEEPER"),P=L.filter(W=>W.playerId!==$.playerId&&at(W)).slice(0,6),B=[$,...P,...L.filter(W=>W!==$&&!P.includes(W))].slice(0,11);return{id:y.teamId,name:y.name,players:L.map(W=>({id:W.playerId,name:W.name,role:W.role,style:W.bowlingStyle,canBowl:at(W),batHand:W.batHand})),suggested:{teamId:y.teamId,playerIds:B.map(W=>W.playerId),captainId:B[0].playerId,keeperId:$.playerId}}}),grounds:o.grounds.map(y=>({id:y.groundId,name:y.name,seamBp:y.pitchPrior.seamBp,turnBp:y.pitchPrior.turnBp}))};let r=null,s=null,c=o;function u(y){c=s?.world??(y?Fi(y,o).world:o)}const h=new Map,p=[],E=y=>te(ce(y)),b=zr(2);let w=null,v=-1,T=null,A=null,I=null,f=null,S=[],k=[];function R(){if(!r)return null;const y=r,L=y.core,$=L.innings[L.activeInningsIndex],P=$?.innings;b.update(y.events);const B=L.phase==="COMPLETE"?_s(y):null,W=Object.fromEntries(y.setup.teams.flatMap(K=>K.xi.map(cn=>[cn.playerId,c.players.find(un=>un.playerId===cn.playerId)?.name??cn.name]))),Z=K=>c.teams.find(cn=>cn.teamId===K)?.name??"",j=L.phase==="TOSS"?y.setup.teams[0].teamId:L.phase==="AWAITING_INNINGS"?L.tossWinnerId:L.phase==="AWAITING_BATTER"?P.battingTeamId:L.phase==="AWAITING_BOWLER"?P.bowlingTeamId:null,Q={TOSS:`${Z(j)}: call the toss`,AWAITING_INNINGS:`${Z(L.tossWinnerId)} won the toss: choose bat or bowl`,AWAITING_BATTER:`${Z(j)}: select ${P?.northBatterId===null&&P.southBatterId===null?"the opening batter":"the next batter"}`,AWAITING_BOWLER:`${Z(j)}: select a bowler`,READY:"Ready: set tactics or advance play",COMPLETE:"Match complete: review the scorecard"},En=(y.setup.teams.find(K=>K.teamId===j)?.xi??[]).map(K=>{let cn="";L.phase==="AWAITING_BATTER"&&(cn=$.batting[K.playerId].dismissed?"Already dismissed":[P.northBatterId,P.southBatterId].includes(K.playerId)?"Already batting":""),L.phase==="AWAITING_BOWLER"&&(cn=K.playerId===$.keeperId?"Designated keeper":K.bowlingStyle===null?"Not a bowler":P.previousOverBowlerId===K.playerId?"Bowled the previous over":$.bowling[K.playerId].legalBalls>=60?"Ten-over limit reached":"");const{power:un,rotation:mn,defence:Ln}=K.skills.ODI;return{id:K.playerId,name:W[K.playerId]??K.name,reason:cn,...L.phase==="AWAITING_BATTER"?{batting:{power:un,rotation:mn,defence:Ln}}:{}}});if(L.phase==="AWAITING_BOWLER"&&$&&P){const K=y.setup.teams.find(un=>un.teamId===j)?.xi??[],cn=Js(K.map(un=>({id:un.playerId,eligible:un.playerId!==$.keeperId&&un.bowlingStyle!==null,legalBalls:$.bowling[un.playerId]?.legalBalls??0})),Math.ceil((300-P.legalBalls)/6),60);for(const un of En)!un.reason&&cn.has(un.id)&&(un.reason=cn.get(un.id))}let J=L.phase==="COMPLETE"?"Match complete":L.phase!=="READY"?"Complete the next decision first":"";if(L.phase==="READY"&&$)try{const K=P.strikerEnd==="NORTH"?P.northBatterId:P.southBatterId,cn=y.setup.teams.flatMap(un=>un.xi).find(un=>un.playerId===K);Ba(L.fieldSlots,$.outfieldIds,cn.batHand,P.legalBalls)}catch{J="Field is invalid for this striker. Apply a legal named field before advancing."}const pn=L.result,be=Object.fromEntries(y.setup.teams.flatMap(K=>K.xi.map(cn=>[cn.playerId,cn.batHand]))),ke=c.grounds.find(K=>K.groundId===y.setup.ground.groundId)?.name??y.setup.ground.name;if(w!==y||v!==y.revision||T!==c){const K=Object.fromEntries(y.setup.teams.map(cn=>[cn.teamId,Z(cn.teamId)]));S=es({format:"ODI",events:y.events,playerNames:W,teamNames:K,teamIds:[y.setup.teams[0].teamId,y.setup.teams[1].teamId],groundName:ke,presentationKey:`lcxxvi-commentary:ODI:${y.setup.matchId}`}).entries,k=as({format:"ODI",matchId:y.setup.matchId,commentaryEntries:S}).cues,A=Jr({format:"ODI",phase:L.phase,innings:L.innings,activeIndex:L.activeInningsIndex,events:y.events,names:W,pitch:L.pitch,fatigueBpByPlayerId:L.fatigueBp,activeBattingPlans:L.battingPlans,activeBowlingPlan:L.bowlingPlan,activeFieldSlots:L.fieldSlots,outfieldIds:$?.outfieldIds??[],bowlerVariationsByPlayerId:Object.fromEntries(y.setup.teams.flatMap(cn=>cn.xi.map(un=>[un.playerId,un.variations])))}),I=ns({format:"ODI",phase:L.phase,innings:L.innings,activeIndex:L.activeInningsIndex,fieldSlots:L.fieldSlots,events:y.events,names:W,hands:be}),w=y,v=y.revision,T=c}const je=S,On=L.phase==="COMPLETE"&&pn?pn.kind==="TIE"?"Match tied":`${Z(pn.winnerTeamId)} won by ${pn.marginRuns??pn.marginWickets} ${pn.marginType?.toLowerCase()}`:null;return{format:"ODI",revision:y.revision,phase:L.phase,nextDecision:Q[L.phase]??L.phase,decisionTeamId:j,teams:y.setup.teams.map(K=>({id:K.teamId,name:Z(K.teamId),captainId:K.captainId,keeperId:K.keeperId,playerIds:[...K.playerIds],...c.packId!==o.packId?{colours:[...c.teams.find(cn=>cn.teamId===K.teamId).colours]}:{}})),names:W,hands:be,ground:c.grounds.find(K=>K.groundId===y.setup.ground.groundId)?.name??y.setup.ground.name,innings:structuredClone(L.innings),activeIndex:L.activeInningsIndex,candidates:En,bowlingPlan:structuredClone(L.bowlingPlan),battingPlans:structuredClone(L.battingPlans),fieldSlots:structuredClone(L.fieldSlots),positions:tu.positions.map(K=>K.slotId),matchId:y.setup.matchId,advanceReason:J,commentary:je,audioCues:k,scorecard:B,analytics:B?b.snapshot(B):null,tacticalAssistant:A,fieldPresentation:I,matchAward:L.phase==="COMPLETE"&&B?f??=os({format:"ODI",scorecard:B,events:y.events,playerNames:W,teamNames:Object.fromEntries(c.teams.map(K=>[K.teamId,K.name]))}):null,resultText:On,eventCount:y.events.length,lastEventHash:y.lastEventHash}}function _(){if(!r||r.core.phase!=="COMPLETE")throw new Error("Complete the match before verifying its final scorecard.");const y=s?O5(r,s):K_(r.setup,r.events,yu(r)),L=_s(r);if(E(_s(y))!==E(L))throw new Error("Replay scorecard mismatch.");return s||q_(r),{revision:r.revision,eventsSha256:E(r.events),scorecardSha256:E(L),eventCount:r.events.length,replay:!0,resimulation:!0,humanRequests:p.filter($=>$.origin==="HUMAN").length,systemAutopilotRequests:p.filter($=>$.origin==="AI").length}}function U(y){if(!r)throw new Error("Start a match first.");const L=y.command;if(L.kind==="CONFIRM_TEAMS")throw new Error("Team confirmation is only available through match setup.");if(L.commandId!==y.requestId||L.expectedRevision!==y.expectedRevision)throw new Error("Command envelope mismatch.");const $=r.core.innings[r.core.activeInningsIndex],P="teamId"in L.payload?L.payload.teamId:L.kind==="SET_BATTING_PLAN"?$?.innings.battingTeamId:$?.innings.bowlingTeamId,B=y.origin==="AI"?L.kind==="ADVANCE"?"SYSTEM":`AI:${P}`:L.kind==="ADVANCE"?"SYSTEM":`USER:${P}`;if(L.actorId!==B)throw new Error("Only valid human or tactical-captain commands are accepted by this match interface.");r=s?xs(r,L).session:Pa(r,L).session,p.push({requestId:y.requestId,origin:y.origin,commandKind:L.kind,engineActorId:L.actorId})}function M(y,L=null){s=L,r=s?qu(y,s):Z_(y,n,e),u(null),h.clear(),p.splice(0,p.length,...r.commands.map($=>({requestId:$.commandId,origin:$.actorId.startsWith("AI:")?"AI":"HUMAN",commandKind:$.kind,engineActorId:$.actorId})))}function H(){return r?structuredClone(r):null}function an(y,L=null){return{version:ve,requestId:y,revision:r?.revision??0,pins:ne,catalog:r?null:structuredClone(i),view:R(),error:L,verification:null}}return{restore:M,setWorldCopy:u,snapshot:H,currentResponse:an,handle(y){let L="invalid",$=null,P=null,B;try{B=ua.parse(y),L=B.requestId;const Z=h.get(L);if(Z){if(Z.request!==JSON.stringify(B))throw new Error("Request ID already used with different content.");return structuredClone(Z.response)}if(B.type!=="BOOT"&&B.expectedRevision!==(r?.revision??0))throw new Error("Stale revision. Review the current decision and try again.");if(B.type==="START"){if(B.format!=="ODI")throw new Error("ODI controller received a non-ODI start.");if(r)throw new Error("A match is already in progress.");if(B.careerFixture)throw new Error("Career fixtures require T20.");if(B.rosterPack&&B.worldCopy)throw new Error("Choose either a roster or an edited world.");if(s=B.rosterPack??null,u(B.worldCopy??null),s){const j=Ps(s,{...a(),seed:t(),format:"ODI",selection:{groundId:B.groundId,teams:B.selections}});r=xs(j,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:L,expectedRevision:0}).session,c=s.world,p.push({requestId:L,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}else{const j=Su({setupVersion:"LC_ODI_SETUP_V1",setup:{schemaVersion:"1.0.0",...a(),format:"ODI",worldPackId:xn.worldPackId,rulesId:"LC_ODI_01",modelId:"synthetic-alpha-01",randomId:"SHA256_COUNTER_V1",seed:t(),teamIds:B.selections.map(J=>J.teamId),groundId:B.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:xn.worldFileSha256,worldCanonicalSha256:Wt.worldHash,rulesHash:Wt.rulesHash,modelHash:Cn,stagePackHash:Zn,selectedTeams:B.selections},n,e),Q=hi(j);for(const[J,pn]of Object.entries(Wt))if(Q.executionManifest[J]!==pn)throw new Error("Worker build identity mismatch.");r=Pa(Q,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:L,expectedRevision:0}).session,p.push({requestId:L,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}}else B.type==="COMMAND"?U(B):B.type==="VERIFY"&&(P=_())}catch(Z){$=Z instanceof Error&&Z.name!=="ZodError"?Z.message:"Invalid request. Check selections, required fields and supported settings."}const W={version:ve,requestId:L,revision:r?.revision??0,pins:ne,catalog:r?null:structuredClone(i),view:R(),error:$,verification:P};return B&&!$&&h.set(L,{request:JSON.stringify(B),response:structuredClone(W)}),W}}}function Nm(n,e,t,a=()=>({gameId:"human-exhibition",matchId:"human-red5"})){const{world:o}=Da(n,e),i={teams:o.teams.map(y=>{const L=y.squadIds.map(W=>o.players.find(Z=>Z.playerId===W)),$=L.find(W=>W.role==="KEEPER"),P=L.filter(W=>W.playerId!==$.playerId&&at(W)).slice(0,6),B=[$,...P,...L.filter(W=>W!==$&&!P.includes(W))].slice(0,11);return{id:y.teamId,name:y.name,players:L.map(W=>({id:W.playerId,name:W.name,role:W.role,style:W.bowlingStyle,canBowl:at(W),batHand:W.batHand})),suggested:{teamId:y.teamId,playerIds:B.map(W=>W.playerId),captainId:B[0].playerId,keeperId:$.playerId}}}),grounds:o.grounds.map(y=>({id:y.groundId,name:y.name,seamBp:y.pitchPrior.seamBp,turnBp:y.pitchPrior.turnBp}))};let r=null,s=null,c=o;function u(y){c=s?.world??(y?Fi(y,o).world:o)}const h=new Map,p=[],E=y=>te(ce(y)),b=zr(4);let w=null,v=-1,T=null,A=null,I=null,f=null,S=[],k=[];function R(){if(!r)return null;const y=r,L=y.core,$=L.innings[L.activeInningsIndex],P=$?.innings;b.update(y.events);const B=L.phase==="COMPLETE"?ws(y):null,W=Object.fromEntries(y.setup.teams.flatMap(K=>K.xi.map(cn=>[cn.playerId,c.players.find(un=>un.playerId===cn.playerId)?.name??cn.name]))),Z=K=>c.teams.find(cn=>cn.teamId===K)?.name??"",j=L.phase==="TOSS"?y.setup.teams[0].teamId:L.phase==="AWAITING_INNINGS"?L.tossWinnerId:L.phase==="AWAITING_FOLLOW_ON"?L.battingFirstId:L.phase==="AWAITING_BATTER"?P.battingTeamId:L.phase==="AWAITING_BOWLER"?P.bowlingTeamId:null,Q={TOSS:`${Z(j)}: call the toss`,AWAITING_INNINGS:`${Z(L.tossWinnerId)} won the toss: choose bat or bowl`,AWAITING_BATTER:`${Z(j)}: select ${P?.northBatterId===null&&P.southBatterId===null?"the opening batter":"the next batter"}`,AWAITING_BOWLER:`${Z(j)}: select a bowler`,AWAITING_FOLLOW_ON:`${Z(j)}: choose whether to enforce the follow-on`,READY:"Ready: set tactics, declare, take a new ball if available, or advance play",COMPLETE:"Match complete: review the scorecard"},En=(y.setup.teams.find(K=>K.teamId===j)?.xi??[]).map(K=>{let cn="";return L.phase==="AWAITING_BATTER"&&(cn=$.batting[K.playerId].dismissed?"Already dismissed":[P.northBatterId,P.southBatterId].includes(K.playerId)?"Already batting":""),L.phase==="AWAITING_BOWLER"&&(cn=K.playerId===$.keeperId?"Designated keeper":K.bowlingStyle===null?"Not a bowler":P.previousOverBowlerId===K.playerId?"Bowled the previous over":""),{id:K.playerId,name:W[K.playerId]??K.name,reason:cn}});let J=L.phase==="COMPLETE"?"Match complete":L.phase!=="READY"?"Complete the next decision first":"";if(L.phase==="READY"&&$)try{const K=P.strikerEnd==="NORTH"?P.northBatterId:P.southBatterId,cn=y.setup.teams.flatMap(un=>un.xi).find(un=>un.playerId===K);vi(L.fieldSlots,$.outfieldIds,cn.batHand)}catch{J="Field is invalid for this striker. Apply a legal named field before advancing."}const pn=L.result,be=Object.fromEntries(y.setup.teams.flatMap(K=>K.xi.map(cn=>[cn.playerId,cn.batHand]))),ke=c.grounds.find(K=>K.groundId===y.setup.ground.groundId)?.name??y.setup.ground.name;if(w!==y||v!==y.revision||T!==c){const K=Object.fromEntries(y.setup.teams.map(cn=>[cn.teamId,Z(cn.teamId)]));S=es({format:"RED_BALL",events:y.events,playerNames:W,teamNames:K,teamIds:[y.setup.teams[0].teamId,y.setup.teams[1].teamId],groundName:ke,presentationKey:`lcxxvi-commentary:RED_BALL:${y.setup.matchId}`}).entries,k=as({format:"RED_BALL",matchId:y.setup.matchId,commentaryEntries:S}).cues,A=Jr({format:"RED_BALL",phase:L.phase,innings:L.innings,activeIndex:L.activeInningsIndex,events:y.events,names:W,pitch:L.pitch,fatigueBpByPlayerId:L.fatigueBp,activeBattingPlans:L.battingPlans,activeBowlingPlan:L.bowlingPlan,activeFieldSlots:L.fieldSlots,outfieldIds:$?.outfieldIds??[],bowlerVariationsByPlayerId:Object.fromEntries(y.setup.teams.flatMap(cn=>cn.xi.map(un=>[un.playerId,un.variations]))),redBallDay:L.clock.day}),I=ns({format:"RED_BALL",phase:L.phase,innings:L.innings,activeIndex:L.activeInningsIndex,fieldSlots:L.fieldSlots,events:y.events,names:W,hands:be}),w=y,v=y.revision,T=c}const je=S,On=L.phase==="COMPLETE"&&pn?pn.kind==="DRAW"?"Match drawn":pn.kind==="TIE"?"Match tied":pn.marginType==="INNINGS"?`${Z(pn.winnerTeamId)} won by an innings and ${pn.marginRuns} run${pn.marginRuns===1?"":"s"}`:`${Z(pn.winnerTeamId)} won by ${pn.marginRuns??pn.marginWickets} ${pn.marginType?.toLowerCase()}`:null;return{format:"RED_BALL",revision:y.revision,phase:L.phase,nextDecision:Q[L.phase]??L.phase,decisionTeamId:j,teams:y.setup.teams.map(K=>({id:K.teamId,name:Z(K.teamId),captainId:K.captainId,keeperId:K.keeperId,playerIds:[...K.playerIds],...c.packId!==o.packId?{colours:[...c.teams.find(cn=>cn.teamId===K.teamId).colours]}:{}})),names:W,hands:be,ground:c.grounds.find(K=>K.groundId===y.setup.ground.groundId)?.name??y.setup.ground.name,innings:structuredClone(L.innings),activeIndex:L.activeInningsIndex,candidates:En,bowlingPlan:structuredClone(L.bowlingPlan),battingPlans:structuredClone(L.battingPlans),fieldSlots:structuredClone(L.fieldSlots),positions:ya.positions.map(K=>K.slotId),matchId:y.setup.matchId,advanceReason:J,commentary:je,audioCues:k,scorecard:B,analytics:B?b.snapshot(B):null,tacticalAssistant:A,fieldPresentation:I,matchAward:L.phase==="COMPLETE"&&B?f??=os({format:"RED_BALL",scorecard:B,events:y.events,playerNames:W,teamNames:Object.fromEntries(c.teams.map(K=>[K.teamId,K.name]))}):null,resultText:On,eventCount:y.events.length,lastEventHash:y.lastEventHash,redBall:{day:L.clock.day,localSeconds:L.clock.localSeconds,clockPhase:L.clock.phase,delaySecondsToday:L.clock.delaySecondsToday,finalHourActive:L.clock.finalHourActive,finalHourBallsRemaining:L.clock.finalHourBallsRemaining,followOnEnforced:L.followOnEnforced,newBallAvailable:!!$&&$.innings.ballAgeLegalBalls>=480&&$.innings.legalBalls%6===0,declared:[...L.declared],pitchWearPoints:L.pitch.wearPoints,seamBp:L.pitch.seamBp,turnBp:L.pitch.turnBp,atSafeWeatherBoundary:L.phase==="READY"&&L.clock.phase==="PLAY"&&!!$&&$.innings.legalBalls%6===0,forecast:M5({seed:y.setup.seed,matchId:y.setup.matchId,day:L.clock.day,localSeconds:L.clock.localSeconds})}}}function _(){if(!r||r.core.phase!=="COMPLETE")throw new Error("Complete the match before verifying its final scorecard.");const y=s?N5(r,s):I5(r.setup,r.events,$u(r)),L=ws(r);if(E(ws(y))!==E(L))throw new Error("Replay scorecard mismatch.");return s||p5(r),{revision:r.revision,eventsSha256:E(r.events),scorecardSha256:E(L),eventCount:r.events.length,replay:!0,resimulation:!0,humanRequests:p.filter($=>$.origin==="HUMAN").length,systemAutopilotRequests:p.filter($=>$.origin==="AI").length}}function U(y){if(!r)throw new Error("Start a match first.");const L=y.command;if(L.kind==="CONFIRM_TEAMS")throw new Error("Team confirmation is only available through match setup.");if(L.commandId!==y.requestId||L.expectedRevision!==y.expectedRevision)throw new Error("Command envelope mismatch.");const $=r.core.innings[r.core.activeInningsIndex],P="teamId"in L.payload?L.payload.teamId:L.kind==="SET_BATTING_PLAN"?$?.innings.battingTeamId:$?.innings.bowlingTeamId,B=y.origin==="AI"?L.kind==="ADVANCE"||L.kind==="ADD_RAIN_DELAY"?"SYSTEM":`AI:${P}`:L.kind==="ADVANCE"||L.kind==="ADD_RAIN_DELAY"?"SYSTEM":`USER:${P}`;if(L.actorId!==B)throw new Error("Only valid human or tactical-captain commands are accepted by this match interface.");r=s?bi(r,L).session:Ue(r,L).session,p.push({requestId:y.requestId,origin:y.origin,commandKind:L.kind,engineActorId:L.actorId})}function M(y,L=null){s=L,r=s?Zu(y,s):h5(y,n,e),u(null),h.clear(),p.splice(0,p.length,...r.commands.map($=>({requestId:$.commandId,origin:$.actorId.startsWith("AI:")?"AI":"HUMAN",commandKind:$.kind,engineActorId:$.actorId})))}function H(){return r?structuredClone(r):null}function an(y,L=null){return{version:ve,requestId:y,revision:r?.revision??0,pins:ne,catalog:r?null:structuredClone(i),view:R(),error:L,verification:null}}return{restore:M,setWorldCopy:u,snapshot:H,currentResponse:an,handle(y){let L="invalid",$=null,P=null,B;try{B=ua.parse(y),L=B.requestId;const Z=h.get(L);if(Z){if(Z.request!==JSON.stringify(B))throw new Error("Request ID already used with different content.");return structuredClone(Z.response)}if(B.type!=="BOOT"&&B.expectedRevision!==(r?.revision??0))throw new Error("Stale revision. Review the current decision and try again.");if(B.type==="START"){if(B.format!=="RED_BALL")throw new Error("Red-ball controller received a non-red-ball start.");if(r)throw new Error("A match is already in progress.");if(B.careerFixture)throw new Error("Career fixtures require T20.");if(B.rosterPack&&B.worldCopy)throw new Error("Choose either a roster or an edited world.");if(s=B.rosterPack??null,u(B.worldCopy??null),s){const j=Fs(s,{...a(),seed:t(),format:"RED_BALL",selection:{groundId:B.groundId,teams:B.selections}});r=bi(j,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:L,expectedRevision:0}).session,c=s.world,p.push({requestId:L,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}else{const j=_u({setupVersion:"LC_RED5_SETUP_V1",setup:{schemaVersion:"1.0.0",...a(),format:"RED_BALL",worldPackId:xn.worldPackId,rulesId:"LC_RED5_01",modelId:"synthetic-alpha-01",randomId:"SHA256_COUNTER_V1",seed:t(),teamIds:B.selections.map(J=>J.teamId),groundId:B.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:xn.worldFileSha256,worldCanonicalSha256:Ut.worldHash,rulesHash:Ut.rulesHash,modelHash:Cn,stagePackHash:Zn,selectedTeams:B.selections},n,e),Q=Ai(j);for(const[J,pn]of Object.entries(Ut))if(Q.executionManifest[J]!==pn)throw new Error("Worker build identity mismatch.");r=Ue(Q,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:L,expectedRevision:0}).session,p.push({requestId:L,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}}else if(B.type==="COMMAND")U(B);else if(B.type==="CHECK_SEEDED_WEATHER"){if(!r||r.core.phase==="COMPLETE")throw new Error("Start an active red-ball match before checking boundary weather.");const j=new Set;for(const En of r.events){const J=/^weather-(d[1-5]-s\d+)-r\d+$/.exec(En.commandId);J?.[1]&&j.add(J[1])}const Q=tm({session:r,appliedSegmentKeys:j});Q&&(r=s?bi(r,Q.command).session:Ue(r,Q.command).session,p.push({requestId:L,origin:"HUMAN",commandKind:"ADD_RAIN_DELAY",engineActorId:"SYSTEM"}))}else B.type==="VERIFY"&&(P=_())}catch(Z){$=Z instanceof Error&&Z.name!=="ZodError"?Z.message:"Invalid request. Check selections, required fields and supported settings."}const W={version:ve,requestId:L,revision:r?.revision??0,pins:ne,catalog:r?null:structuredClone(i),view:R(),error:$,verification:P};return B&&!$&&h.set(L,{request:JSON.stringify(B),response:structuredClone(W)}),W}}}const $T=4e3;function ym(n){const e=n.core.innings[n.core.activeInningsIndex];return e?e.innings:null}function GT(n,e){const t=ym(n);return n.core.phase!=="COMPLETE"&&n.core.activeInningsIndex===e.inningsIndex&&t!==null&&t.legalBalls>=e.legalBalls}function jT(n,e,t){const a=ym(n);if(!a)throw new Error("SCENARIO_CHECKPOINT_NO_INNINGS");return{inningsIndex:e,legalBalls:t,revision:n.revision,battingTeamId:a.battingTeamId,runs:a.runs,wickets:a.wickets,targetToWin:a.targetToWin??null}}function YT(n){if(n.setup.format==="T20"){const t=n;return ka(t,mi(t)).session}if(n.setup.format==="ODI"){const t=n;return Pa(t,po(t)).session}const e=n;return Ue(e,ra(e)).session}function zT(n,e){let t=n;for(let a=0;!GT(t,e);a+=1){if(t.core.phase==="COMPLETE")throw new Error("SCENARIO_CHECKPOINT_UNREACHED");if(a>=$T)throw new Error("SCENARIO_FAST_FORWARD_LIMIT");t=YT(t)}return t}function KT(n,e,t){if(n.snapshot())throw new Error("SCENARIO_CONTROLLER_BUSY");const a=n.currentResponse(t).catalog;if(!a)throw new Error("SCENARIO_CATALOGUE_UNAVAILABLE");const o=h=>{const p=a.teams.find(E=>E.id===h);if(!p)throw new Error("SCENARIO_TEAM_UNKNOWN");return p.suggested},i=[o(e.teamIds[0]),o(e.teamIds[1])],r=n.handle({version:ve,requestId:t,expectedRevision:0,type:"START",format:e.format,selections:i,groundId:e.groundId});if(r.error)throw new Error(r.error);const s=n.snapshot();if(!s)throw new Error("SCENARIO_START_FAILED");const c=zT(s,e.checkpoint),u=jT(c,e.checkpoint.inningsIndex,e.checkpoint.legalBalls);if(JSON.stringify(u)!==JSON.stringify(e.checkpoint))throw new Error("SCENARIO_CHECKPOINT_MISMATCH");return n.restore(c),n.currentResponse(t)}function qT(n){const e=n.core.result;return n.core.phase!=="COMPLETE"||!e?null:{kind:e.kind,winnerTeamId:e.winnerTeamId??null,marginType:e.marginType??null,marginRuns:e.marginRuns??null,marginWickets:e.marginWickets??null}}function ac(n,e){const t=n,a=t?.setup?.setupVersion;return!e&&!!t&&(t.setup?.format==="T20"&&a==="LC_T20_SETUP_V1"||t.setup?.format==="ODI"&&a==="LC_ODI_SETUP_V1")&&im(t)}function ZT(n){if(n.dismissal)return"W";const e=n.extras.wides+n.extras.noBalls+n.extras.byes+n.extras.legByes+n.extras.penalties,t=n.batRuns+e;return n.extras.wides?`${t}wd`:n.extras.noBalls?`${t}nb`:String(t)}function XT(n,e){const t=Object.fromEntries(n.setup.teams.flatMap(p=>p.xi.map(E=>[E.playerId,E.name])));for(const p of n.setup.teams)t[p.teamId]=p.name;const a=n.setup.format==="ODI"?"LC_ODI_SUPER_OVER_01":"LC_T20_SUPER_OVER_01";if(!e)return{rulesId:a,started:!1,phase:"NOT_STARTED",rounds:[],pending:null,choices:[],battersToName:wi,current:null,winnerTeamId:null,completionReason:null,names:t};const o=lm(e),i=o?(o.decision==="BATTERS"?Oi(n,e,o.teamId):Li(n,e,o.teamId)).map(p=>({id:p,name:t[p]??p})):[],r=e.rounds[e.rounds.length-1],s=r?.innings[r.innings.length-1]??null,c=s?.ledger??null,u=c?c.nextDeliveryIndex-c.innings.deliveryAttempts:0,h=s?{battingTeamId:s.battingTeamId,bowlingTeamId:s.bowlingTeamId,strikerId:c?c.innings.strikerEnd==="NORTH"?c.innings.northBatterId:c.innings.southBatterId:null,nonStrikerId:c?c.innings.strikerEnd==="NORTH"?c.innings.southBatterId:c.innings.northBatterId:null,bowlerId:s.bowlerId,runs:c?.innings.runs??0,wickets:c?.innings.wickets??0,legalBalls:c?.innings.legalBalls??0,targetToWin:c?.innings.targetToWin??null,balls:c?e.deliveries.filter(p=>p.deliveryIndex>=u).map(ZT):[]}:null;return{rulesId:a,started:!0,phase:e.phase,rounds:Q5(e),pending:o,choices:i,battersToName:Math.min(wi,i.length),current:h,winnerTeamId:e.winnerTeamId,completionReason:e.completionReason,names:t}}async function Dm(n,e){const t=await e.load(String(n.setup.gameId));return t?{state:mm(n,t),commands:[...t.commands]}:{state:null,commands:[]}}async function JT(n,e,t){const{state:a,commands:o}=await Dm(n,e);if(t.kind==="START"){if(a)return a;const s=rm(n);return await e.save(um(s,[]),0),s}if(!a)throw new Error("Start the super over first.");let i=null;if(t.kind==="COMMAND"?i=t.command:lm(a)?.teamId===t.teamId&&(i=J5(n,a)),!i)return a;const r=cm(n,a,i);return await e.save(um(r,[...o,i]),o.length),r}function QT(n,e){return`${n}:${e}`}function nR(n,e){return{gameId:`tour-${n}-m${e}`.slice(0,128),matchId:`tour-m${e}`}}const Yt=new TextEncoder().encode($m),tn=new AT,ma=ST(()=>new Date().toISOString());let eR=9e8;const Dn=self.name||`tab-${$a(16)}`;let on=null,re=null,ge=null,_n=!1,ut=!1,mt=null;const Je=()=>({version:"LC_DELEGATION_JOURNAL_V1",changes:[]});let Se=Je(),x=Ge(),Cm=!1,zt=null,Wa=null,Ua=null,rt=null;function $a(n){const e=crypto.getRandomValues(new Uint8Array(n));return Array.from(e,t=>t.toString(16).padStart(2,"0")).join("")}function Ae(){return Date.now()}function Ga(){return new Date().toISOString()}function oc(){return $a(32)}function Ui(){const n=$a(12);return{gameId:`game-${n}`,matchId:`match-${n}`}}function tR(n,e,t){const a=()=>e,o=()=>({gameId:Ui().gameId,matchId:t});return n==="ODI"?tc(Yt,Rt,a,o):n==="RED_BALL"?Nm(Yt,Rt,a,o):ec(Yt,Rt,a,o)}function Ge(n="T20"){return n==="ODI"?tc(Yt,Rt,oc,Ui):n==="RED_BALL"?Nm(Yt,Rt,oc,Ui):ec(Yt,Rt,oc,Ui)}function Kt(n){const e=n;return e?.setup?.format==="ODI"?"ODI":e?.setup?.format==="RED_BALL"?"RED_BALL":"T20"}function ic(n,e){const t=n.find(o=>o.saveId.startsWith("recovered-")&&o.matchGameId===e);if(t)return t.saveId;const a=`auto:${e}`;return n.some(o=>o.saveId===a)?a:null}function Oo(n,e=null){const t=e?.world;return{matchGameId:String(n.setup.gameId),matchId:String(n.setup.matchId),teams:[t?.teams.find(a=>a.teamId===n.setup.teams[0].teamId)?.name??String(n.setup.teams[0].name),t?.teams.find(a=>a.teamId===n.setup.teams[1].teamId)?.name??String(n.setup.teams[1].name)],ground:t?.grounds.find(a=>a.groundId===n.setup.ground.groundId)?.name??String(n.setup.ground.name),phase:String(n.core.phase),completed:n.core.phase==="COMPLETE"}}function aR(n,e){const t=Oo(n,e).teams;return`${t[0]} v ${t[1]}`}function km(){return ge?null:re}function $i(n,e){n.setWorldCopy(e)}function Gi(n,e,t){if(t&&Kt(e)==="ODI")n.restore(e,t);else if(t&&Kt(e)==="T20")n.restore(e,t);else if(t&&Kt(e)==="RED_BALL")n.restore(e,t);else{if(t)throw new Error("Imported roster match format is unsupported.");n.restore(e)}}function oR(n){return{engine:n.executionManifest.engine,eventChain:n.executionManifest.eventChain,random:n.setup.versions.random,model:n.setup.versions.model,modelHash:n.setup.versions.modelHash,rules:n.setup.versions.rules,rulesHash:n.setup.versions.rulesHash,worldHash:n.setup.versions.worldHash}}const iR={engine:"LC_T20_MATCH_ROSTER_V2",eventChain:Gt.eventChain,random:Gt.random,model:Gt.model,modelHash:Gt.modelHash,rules:Gt.rules,rulesHash:Gt.rulesHash},rR={engine:"LC_RED5_MATCH_ROSTER_V2",eventChain:$t.eventChain,random:$t.random,model:$t.model,modelHash:$t.modelHash,rules:$t.rules,rulesHash:$t.rulesHash},sR={engine:"LC_ODI_MATCH_ROSTER_V2",eventChain:jt.eventChain,random:jt.random,model:jt.model,modelHash:jt.modelHash,rules:jt.rules,rulesHash:jt.rulesHash};function Bm(n){return n.commands.map(e=>{const t=e.kind==="CONFIRM_TEAMS"?{version:ve,requestId:e.commandId,expectedRevision:e.expectedRevision,type:"START",format:n.setup.format,selections:n.setup.teams.map(a=>({teamId:a.teamId,playerIds:[...a.playerIds],captainId:a.captainId,keeperId:a.keeperId})),groundId:n.setup.ground.groundId}:{version:ve,requestId:e.commandId,expectedRevision:e.expectedRevision,type:"COMMAND",origin:e.actorId.startsWith("AI:")?"AI":"HUMAN",command:e};return{commandId:e.commandId,requestCanonical:G(t),responseJson:"",committedRevision:n.receipts[e.commandId]?.committedRevision??e.expectedRevision+1}})}async function cR(){const n=await tn.list(),e=on?n.find(t=>t.saveId===on)??null:null;return{saveId:on,durableRevision:e?.revision??null,savedAt:e?.updatedAt??null,readOnly:_n,recovered:ut,recoveredFromGeneration:mt,saves:n}}function ja(){const n=x.boundFixture;return n?n():null}async function lR(n){try{return(await ma.get(n))?.status??null}catch{return null}}async function Pm(){try{return await tn.loadScenarioLedger()??Zd()}catch{return Zd()}}async function xm(n,e){if(!n)return null;let t=await Pm(),a=Jd(t,n);if(!a)return null;const o=ru(a.scenarioId);if(!o)return null;if(a.outcome===null&&e==="COMPLETE"&&Mm(n)&&!_n){const i=x.snapshot(),r=i&&String(i.setup.gameId)===n?qT(i):null;if(r)try{t=await tn.saveScenarioLedger(LS(t,n,bS(a,r))),a=Jd(t,n)??a}catch{}}return{scenarioId:o.scenarioId,title:o.title,format:o.format,difficulty:o.difficulty,objectiveSummary:o.objectiveSummary,briefing:o.briefing,playerTeamId:a.playerTeamId,opponentTeamId:o.teamIds.find(i=>i!==a.playerTeamId)??o.teamIds[1],outcome:a.outcome,resultText:a.resultText}}const Hm={load:n=>tn.loadSuperOverRecord(n),save:(n,e)=>tn.saveSuperOverRecord(n,e)};async function Fm(n){if(n!=="COMPLETE")return null;const e=x.snapshot();if(!ac(e,ja()!==null))return null;try{return XT(e,(await Dm(e,Hm)).state)}catch{return null}}async function q(n,e=null){const t=ja(),a=await cR(),o=a.saves.find(s=>s.saveId===a.saveId)??null,i=await xm(o?.matchGameId??null,n.view?.phase??null),r=await Fm(n.view?.phase??null);return{...n,scenario:i,superOver:r,persistence:a,archive:e,delegation:Se,...t?{managedStatus:await lR(t.matchGameId)}:{}}}function Mm(n){return on===`auto:${n}`||(on?.startsWith("recovered-")??!1)}async function Lo(n){try{const e=await ma.get(n);return{binding:e&&e.status==="PENDING"?e:null,problem:null}}catch(e){return{binding:null,problem:e instanceof Error?e.message:"The career binding could not be read."}}}async function rc(){const n=x.snapshot();if(!n||ja()||!("boundFixture"in x))return null;const e=String(n.setup.gameId);if(!Mm(e))return null;const{binding:t,problem:a}=await Lo(e);if(a)return a;if(!t)return null;const o=nc.safeParse(t.launch);if(!o.success)return"The saved career binding is not a valid launch and was preserved.";const i=o.data;if(i.matchGameId!==t.matchGameId||i.matchId!==t.matchId||i.fixtureId!==t.fixtureId||i.saveId!==t.careerSaveId||i.seasonId!==t.seasonId||i.scheduleSha256!==t.scheduleSha256||i.careerStateSha256!==t.careerStateSha256)return"The saved career binding does not match its launch and was preserved.";if(i.matchGameId!==e||i.matchId!==String(n.setup.matchId))return"The saved match does not belong to the career fixture.";const r=i.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V2"?i.worldCopy:i.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"?i.worldCopy??null:null,s=i.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"||i.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"?i.rosterPack:null;if(G(s)!==G(ge))return"The saved match belongs to a different roster.";if(s){if(re!==null)return"The saved match belongs to a different world copy.";re=r}else if(G(r)!==G(re))return"The saved match belongs to a different world copy.";return x.handle({version:ve,type:"BOOT",requestId:`ui-${++eR}`,expectedRevision:0,careerFixture:i}).error}function dR(){const n=x.snapshot();if(!n)return 0;let e=0;for(const t of n.commands){const a=Number(/^ui-(\d+)$/.exec(t.commandId)?.[1]??0);a<8e8&&a>e&&(e=a)}return e}function uR(n){const e=ja(),t={...n,commandIdFloor:dR()};return e?{...t,careerFixture:e}:{...t,careerFixture:null,error:n.error??zt}}async function Ya(n){const e=await tn.load(n);if(!e)throw new Error("Save not found.");x=Ge(Kt(e.session)),Gi(x,e.session,e.rosterPack??null),$i(x,e.worldCopy??null),re=e.worldCopy??null,ge=e.rosterPack??null,ut=e.recovered,mt=e.recoveredFromGeneration,Se=e.delegationJournal??Je();let t=n;if(e.recovered){const a=x.snapshot();if(t=`recovered-${$a(10)}`,!await tn.acquireLease(t,Dn,Ae()))throw new Error("Recovered save could not acquire a writer lease.");await tn.commit({saveId:t,kind:"MANUAL",title:`${e.summary.title} (Recovered)`,expectedRevision:null,session:a,revision:a.revision,events:a.events,command:null,historyCommands:await tn.historyCommands(n,a.revision),...e.delegationJournal?{delegationJournal:e.delegationJournal}:{},metadata:Oo(a,re),worldCopy:km(),rosterPack:ge,ownerId:Dn,now:Ae(),updatedAt:Ga()})}t===n?_n=!await tn.acquireLease(t,Dn,Ae()):_n=!1,on=t,await tn.setActiveSaveId(t),zt=await rc()}async function Vm(){if(Cm)return;Cm=!0;const n=await tn.activeSaveId();if(n)try{await Ya(n)}catch(e){Ua={requestType:"RECOVERY",sequence:null,invariantCode:e instanceof Error&&/^[A-Z][A-Z0-9_]{2,80}$/.test(e.message)?e.message:null,command:null},rt=null,on=null,re=null,ge=null,Se=Je(),_n=!1,x=Ge(),await tn.setActiveSaveId(null)}}async function ji(n,e){const t=n instanceof Error?n.message:"Durable save failed.";if(on)try{const a=await tn.load(on);a&&(x=Ge(Kt(a.session)),Gi(x,a.session,a.rosterPack??null),$i(x,a.worldCopy??null),re=a.worldCopy??null,ge=a.rosterPack??null,Se=a.delegationJournal??Je())}catch{}return q(x.currentResponse(e,`Save failed. ${t}`))}async function Yi(n,e){const t=x.snapshot();if(!t||e.error)return q(e);if(n.type==="START"){const o=`auto:${t.setup.gameId}`;if((await tn.list()).some(i=>i.saveId===o)){if(x=Ge(n.format),on)try{const i=await tn.load(on);i&&(x=Ge(Kt(i.session)),Gi(x,i.session,i.rosterPack??null),$i(x,i.worldCopy??null),zt=await rc())}catch{}return q(x.currentResponse(n.requestId,"SAVE_ALREADY_EXISTS: a saved match already exists for this game. Resume it instead of starting it again."))}if(re=n.careerFixture?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V2"?n.careerFixture.worldCopy:n.careerFixture?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"?n.careerFixture.worldCopy??null:n.worldCopy??null,ge=n.rosterPack??null,on=o,_n=!await tn.acquireLease(on,Dn,Ae()),_n)return ji(new Error("A writer lease could not be acquired for the new game."),n.requestId)}else{if(!on)return ji(new Error("No active durable save exists."),n.requestId);if(_n||!await tn.renewLease(on,Dn,Ae()))return _n=!0,ji(new Error("This save is open read-only in this tab."),n.requestId)}const a=on;try{const o=await tn.commit({saveId:a,kind:"AUTO",title:aR(t,re),expectedRevision:n.type==="START"?null:n.expectedRevision,session:t,revision:t.revision,events:t.events,command:{commandId:n.type==="COMMAND"?n.command.commandId:n.requestId,requestCanonical:G(n),responseJson:G(e),committedRevision:t.revision},metadata:Oo(t,re),worldCopy:km(),rosterPack:ge,ownerId:Dn,now:Ae(),updatedAt:Ga()});return await tn.setActiveSaveId(a),n.type==="START"&&(Se=Je()),ut=!1,mt=null,{...e,persistence:{saveId:a,durableRevision:o.revision,savedAt:o.updatedAt,readOnly:_n,recovered:ut,recoveredFromGeneration:mt,saves:await tn.list()},archive:null,delegation:Se,scenario:await xm(String(t.setup.gameId),e.view?.phase??null),superOver:await Fm(e.view?.phase??null),...t.receipts[n.requestId]?{acknowledgement:t.receipts[n.requestId]}:{}}}catch(o){const i=o instanceof Error&&o.message.startsWith("SAVE_ALREADY_EXISTS");if(n.type==="START"&&!i){const r=on;if(r){try{await tn.releaseLease(r,Dn)}catch{}try{await tn.delete(r)}catch{}}on=null,re=null,ge=null,Se=Je(),_n=!1,x=Ge(),await tn.setActiveSaveId(null);const s=o instanceof Error?o.message:"Durable save failed.";return q(x.currentResponse(n.requestId,`Save failed. ${s}`))}return ji(o,n.requestId)}}async function mR(n){if(n.type==="LIST_SAVES")return q(x.currentResponse(n.requestId));if(n.type==="MANUAL_SAVE"){if(!on||!x.snapshot())return q(x.currentResponse(n.requestId,"Start or load a match before creating a manual save."));const e=`manual-${$a(10)}`;try{return await tn.cloneSave(on,e,"MANUAL",n.title.trim(),Dn,Ae(),Ga()),await tn.releaseLease(e,Dn),await tn.setActiveSaveId(on),q(x.currentResponse(n.requestId))}catch(t){return q(x.currentResponse(n.requestId,t instanceof Error?t.message:"Manual save failed."))}}if(n.type==="LOAD_SAVE"){on&&!_n&&await tn.releaseLease(on,Dn);try{return await Ya(n.saveId),q(x.currentResponse(n.requestId))}catch(e){return q(x.currentResponse(n.requestId,e instanceof Error?e.message:"Load failed."))}}if(n.type==="DELETE_SAVE")try{const e=(await tn.list()).find(t=>t.saveId===n.saveId);if(n.saveId===on?(_n||await tn.releaseLease(n.saveId,Dn),await tn.delete(n.saveId),on=null,re=null,ge=null,Se=Je(),_n=!1,ut=!1,mt=null,x=Ge()):await tn.delete(n.saveId),e?.matchGameId&&ic(await tn.list(),e.matchGameId)===null)try{(await ma.get(e.matchGameId))?.status==="PENDING"&&await ma.resolve(e.matchGameId,"ABANDONED","MATCH_SAVE_DELETED")}catch{}return q(x.currentResponse(n.requestId))}catch(e){return q(x.currentResponse(n.requestId,e instanceof Error?e.message:"Delete failed."))}if(n.type==="EXPORT_SAVE"){const e=n.saveId??on;if(!e)return q(x.currentResponse(n.requestId,"Choose a save to export."));try{const t=await tn.load(e);if(!t)throw new Error("Save not found.");const a=Kt(t.session),o=t.delegationJournal,i=t.rosterPack?oR(t.session):a==="ODI"?jt:a==="RED_BALL"?$t:Gt,r=t.rosterPack?null:await tn.loadSuperOverRecord(String(t.session.setup.gameId)),s=await mT(t.session,t.summary,i,Ga(),t.worldCopy??null,t.rosterPack??null,o?.changes.length?o:null,r);return q(x.currentResponse(n.requestId),s)}catch(t){return q(x.currentResponse(n.requestId,t instanceof Error?t.message:"Export failed."))}}if(n.type==="IMPORT_SAVE")try{const e=await gT(n.archive,[Gt,iR,sR,rR,jt,$t]),t=Ge(Kt(e.session));Gi(t,e.session,e.rosterPack),$i(t,e.worldCopy);const a=t.snapshot();if(e.superOverRecord){if(!ac(a,!1))throw new Error("ARCHIVE_SUPER_OVER_NOT_ELIGIBLE");mm(a,e.superOverRecord);const i=await tn.loadSuperOverRecord(String(a.setup.gameId));if(i&&G(i)!==G(e.superOverRecord))throw new Error("A different super-over record already exists for this game in this browser.")}const o=`import-${$a(10)}`;if(!await tn.acquireLease(o,Dn,Ae()))throw new Error("Imported save slot is locked.");return await tn.commit({saveId:o,kind:"IMPORTED",title:`${e.summary.title} (Imported)`,expectedRevision:null,session:a,revision:a.revision,events:a.events,command:null,historyCommands:Bm(a),...e.delegationJournal?{delegationJournal:e.delegationJournal}:{},metadata:Oo(a,e.worldCopy),worldCopy:e.worldCopy,rosterPack:e.rosterPack,ownerId:Dn,now:Ae(),updatedAt:Ga()}),on&&!_n&&await tn.releaseLease(on,Dn),on=o,Se=e.delegationJournal??Je(),re=e.worldCopy,ge=e.rosterPack,_n=!1,ut=!1,mt=null,x=t,await tn.setActiveSaveId(o),e.superOverRecord&&!await tn.loadSuperOverRecord(String(a.setup.gameId))&&await tn.saveSuperOverRecord(e.superOverRecord,0),q(x.currentResponse(n.requestId))}catch(e){return q(x.currentResponse(n.requestId,e instanceof Error?e.message:"Import rejected."))}return null}async function gR(n){const e=x.snapshot();if(e){const{binding:b}=await Lo(String(e.setup.gameId));if(b)return q(x.currentResponse(n.requestId,"This match is linked to a career fixture. Finish it, or abandon the career match first."))}if(n.rosterPack===void 0!=(n.selections===void 0))return q(x.currentResponse(n.requestId,"A generated-squad tournament match needs both its roster and its teams."));const t=n.rosterPack??null,a=()=>G(ge)===G(t),o=nR(n.runId,n.fixture.matchNumber),i=`auto:${o.gameId}`;if(on===i&&e)return a()?q(x.currentResponse(n.requestId)):q(x.currentResponse(n.requestId,"The saved match belongs to a different roster."));if((await tn.list()).some(b=>b.saveId===i)){if(on&&!_n)try{await tn.releaseLease(on,Dn)}catch{}try{await Ya(i)}catch(b){return q(x.currentResponse(n.requestId,b instanceof Error?b.message:"The tournament match could not be resumed."))}return a()?q(x.currentResponse(n.requestId)):q(x.currentResponse(n.requestId,"The saved match belongs to a different roster."))}const r=QT(n.runSeed,n.fixture.fixtureId),s=()=>r,c=()=>o,u=n.format==="ODI"?tc(Yt,Rt,s,c):ec(Yt,Rt,s,c);let h;if(n.selections){if(h=n.selections,h[0].teamId!==n.fixture.homeTeamId||h[1].teamId!==n.fixture.awayTeamId)return q(x.currentResponse(n.requestId,"The teams do not match the tournament fixture."))}else{const b=u.currentResponse(n.requestId).catalog,w=A=>b?.teams.find(I=>I.id===A)?.suggested,v=w(n.fixture.homeTeamId),T=w(n.fixture.awayTeamId);if(!v||!T)return q(x.currentResponse(n.requestId,"Unknown tournament team."));h=[v,T]}const p={version:ve,requestId:n.requestId,expectedRevision:0,type:"START",format:n.format,selections:h,groundId:n.fixture.groundId,...t?{rosterPack:t}:{}},E=u.handle(p);if(E.error)return q(x.currentResponse(n.requestId,E.error));if(on&&!_n)try{await tn.releaseLease(on,Dn)}catch{}return x=u,on=null,re=null,ge=t,Se=Je(),_n=!1,ut=!1,mt=null,zt=null,Yi(p,E)}async function IR(n){const e=ru(n.scenarioId);if(!e)return q(x.currentResponse(n.requestId,"Unknown scenario."));const t=x.snapshot();if(t){const{binding:s}=await Lo(String(t.setup.gameId));if(s)return q(x.currentResponse(n.requestId,"This match is linked to a career fixture. Finish it, or abandon the career match first."))}const a=tR(e.format,e.seed,e.matchId);let o,i;try{i=KT(a,e,n.requestId),o=a.snapshot()}catch(s){return q(x.currentResponse(n.requestId,`The scenario could not be prepared. ${s instanceof Error?s.message:""}`.trim()))}const r=`auto:${o.setup.gameId}`;if(!await tn.acquireLease(r,Dn,Ae()))return q(x.currentResponse(n.requestId,"A writer lease could not be acquired for the scenario."));try{await tn.commit({saveId:r,kind:"AUTO",title:`Scenario: ${e.title}`,expectedRevision:null,session:o,revision:o.revision,events:o.events,command:null,historyCommands:Bm(o),metadata:Oo(o,null),worldCopy:null,rosterPack:null,ownerId:Dn,now:Ae(),updatedAt:Ga()})}catch(s){try{await tn.releaseLease(r,Dn)}catch{}return q(x.currentResponse(n.requestId,`Save failed. ${s instanceof Error?s.message:""}`.trim()))}if(on&&on!==r&&!_n)try{await tn.releaseLease(on,Dn)}catch{}x=a,on=r,re=null,ge=null,Se=Je(),_n=!1,ut=!1,mt=null,zt=null,await tn.setActiveSaveId(r);try{const s=await Pm();await tn.saveScenarioLedger(OS(s,{gameId:String(o.setup.gameId),scenarioId:e.scenarioId,challengeSha256:await kn(G(e)),playerTeamId:e.playerTeamId,objective:e.objective}))}catch{}return q(i)}async function pR(n){const e=ua.safeParse(n);if(!e.success)return await Vm(),q(x.handle(n));const t=e.data;if(await Vm(),t.type==="RECOVER_MANAGED"){if(x.snapshot())zt=await rc()??zt;else{const{bindings:i}=await ma.list(),r=await tn.list(),s=i.filter(c=>c.status==="PENDING").map(c=>({binding:c,saveId:ic(r,c.matchGameId)})).filter(c=>c.saveId!==null);if(s.length===1)try{await Ya(s[0].saveId)}catch(c){return q(x.currentResponse(t.requestId,`The saved career match could not be resumed. ${c instanceof Error?c.message:""}`.trim()))}else if(s.length>1)return q(x.currentResponse(t.requestId,"More than one career match is in progress. Resume the one you want from the career screen."))}return q(x.currentResponse(t.requestId,ja()?null:zt))}if(t.type==="ABANDON_MANAGED"){const i=x.snapshot();if(!i)return q(x.currentResponse(t.requestId,"There is no active match."));try{const r=String(i.setup.gameId),s=await ma.get(r);s&&s.status==="PENDING"&&await ma.resolve(r,"ABANDONED","ABANDONED_BY_PLAYER")}catch(r){return q(x.currentResponse(t.requestId,r instanceof Error?r.message:"The career match could not be abandoned."))}return q(x.currentResponse(t.requestId))}if(t.type==="RETRY_WRITER"){if(!on||!_n)return q(x.currentResponse(t.requestId));try{await Ya(on)}catch(i){return q(x.currentResponse(t.requestId,i instanceof Error?i.message:"The writer lease could not be retaken."))}return q(x.currentResponse(t.requestId,_n?"Another tab still holds this match. Close it, then try again.":null))}if(t.type==="RELEASE_WRITER"){if(on&&!_n){try{await tn.releaseLease(on,Dn)}catch{}_n=!0}return q(x.currentResponse(t.requestId))}if(t.type==="CANCEL_ANALYTICS")return q(x.currentResponse(t.requestId));if(t.type==="REBUILD_ANALYTICS"){const i=x.snapshot();if(!i||i.core.phase!=="COMPLETE")return q(x.currentResponse(t.requestId,"Complete the match before rebuilding analytics."));if(t.expectedRevision!==i.revision)return q(x.currentResponse(t.requestId,"Stale match revision."));const r={requestId:t.requestId,revision:i.revision,cancelled:!1};Wa=r;const s=Yr(i.setup.format==="RED_BALL"?4:2);try{let c=performance.now();for(let h=0;h<i.events.length;h+=32){for(const p of i.events.slice(h,h+32))s.append(p);if(!(performance.now()-c<12&&h+32<i.events.length)&&(self.postMessage({type:"ANALYTICS_PROGRESS",version:ve,pins:ne,requestId:t.requestId,applied:s.appliedSequence,total:i.events.length}),await new Promise(p=>setTimeout(p,0)),c=performance.now(),r.cancelled))return{...await q(x.currentResponse(t.requestId)),analyticsRebuild:{state:"CANCELLED",applied:s.appliedSequence,total:i.events.length}}}const u=await q(x.currentResponse(t.requestId));if(!u.view?.scorecard||!u.view.analytics||G(s.snapshot(u.view.scorecard))!==G(u.view.analytics))throw new Error("Analytics rebuild does not match the incremental result.");return{...u,analyticsRebuild:{state:"COMPLETE",applied:s.appliedSequence,total:i.events.length}}}finally{Wa===r&&(Wa=null)}}if(t.type==="PREVIEW_DIAGNOSTIC"){const i=x.snapshot(),r=await NT(i,Ua,t.includeSeed??!1);return rt={...r,gameId:i?.setup.gameId??null,eventHash:i?.lastEventHash??null},{...await q(x.currentResponse(t.requestId)),diagnosticPreview:r.preview}}if(t.type==="EXPORT_DIAGNOSTIC"){const i=x.snapshot();return!rt||t.sha256!==rt.preview.sha256||rt.gameId!==(i?.setup.gameId??null)||rt.eventHash!==(i?.lastEventHash??null)||rt.preview.revision!==(i?.revision??null)?q(x.currentResponse(t.requestId,"Preview the diagnostic again before downloading.")):{...await q(x.currentResponse(t.requestId)),diagnosticBytes:rt.bytes}}if(t.type==="BOOT"&&t.careerFixture){const i=x.snapshot(),r=i?.setup.gameId===t.careerFixture.matchGameId&&i?.setup.matchId===t.careerFixture.matchId,s=t.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V2"?t.careerFixture.worldCopy:t.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"?t.careerFixture.worldCopy??null:null,c=t.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"||t.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"?t.careerFixture.rosterPack:null;if(r&&G(s)!==G(re))return q(x.currentResponse(t.requestId,"The saved match belongs to a different world copy."));if(r&&G(c)!==G(ge))return q(x.currentResponse(t.requestId,"The saved match belongs to a different roster."));if(!r){const u=ic(await tn.list(),t.careerFixture.matchGameId);if((i?(await Lo(String(i.setup.gameId))).binding:null)&&!u)return q(x.currentResponse(t.requestId,"Another career match is still in progress. Return to it or abandon it first."));if(on&&!_n)try{await tn.releaseLease(on,Dn)}catch{}if(u)try{await Ya(u)}catch(p){return on=null,re=null,ge=null,x=Ge("T20"),q(x.currentResponse(t.requestId,`The saved match for this fixture could not be resumed. ${p instanceof Error?p.message:""}`.trim()))}else on=null,re=null,ge=null,Se=Je(),_n=!1,ut=!1,mt=null,x=Ge("T20"),await tn.setActiveSaveId(null)}}else if(t.type==="BOOT"&&t.fresh){const i=x.snapshot();if(i){const{binding:r}=await Lo(String(i.setup.gameId));if(r)return q(x.currentResponse(t.requestId,"This match is linked to a career fixture. Finish it, or abandon the career match first."))}if(on&&!_n)try{await tn.releaseLease(on,Dn)}catch{}on=null,re=null,ge=null,Se=Je(),_n=!1,ut=!1,mt=null,x=Ge(),await tn.setActiveSaveId(null)}if(t.type==="SCENARIO_START")return IR(t);if(t.type==="TOURNAMENT_START")return gR(t);if(t.type==="SUPER_OVER"){const i=x.snapshot();if(!ac(i,ja()!==null))return q(x.currentResponse(t.requestId,"Super overs are for tied T20 and one-day exhibition matches."));if(_n||!on||!await tn.renewLease(on,Dn,Ae()))return q(x.currentResponse(t.requestId,"Super overs need a writable save."));try{await JT(i,Hm,t.action)}catch(r){const s=r instanceof Error?r.message:"The super over could not continue.";return q(x.currentResponse(t.requestId,s==="SUPER_OVER_STALE"?"Another tab changed this super over. Reload to continue.":s))}return q(x.currentResponse(t.requestId))}const a=await mR(t);if(a)return a;if(t.type==="SET_DELEGATION"){const i=x.snapshot();return i?i.setup.teams.some(r=>r.teamId===t.teamId)?t.expectedRevision!==i.revision?q(x.currentResponse(t.requestId,"Stale match revision.")):_n||!on||!await tn.renewLease(on,Dn,Ae())?q(x.currentResponse(t.requestId,"Delegation requires a writable durable save.")):(Se=await tn.appendDelegation(on,Dn,Ae(),{commandId:t.requestId,expectedRevision:t.expectedDelegationRevision,matchRevision:i.revision,teamId:t.teamId,categories:t.categories,...t.redBallProfile?{redBallProfile:t.redBallProfile}:{}}),q(x.currentResponse(t.requestId))):q(x.currentResponse(t.requestId,"Unknown delegation team.")):q(x.currentResponse(t.requestId,"Delegation requires an active match."))}if(t.type==="AI_STEP"){const i=x.snapshot();if(!i)return q(x.currentResponse(t.requestId,"AI decisions require an active match."));if(t.expectedRevision!==i.revision)return q(x.currentResponse(t.requestId,"Stale AI decision revision."));if(_n||!on)return q(x.currentResponse(t.requestId,"AI decision requires a writable durable save."));const r=t.delegated?d2(Se,t.teamId):void 0,s=t.redBallProfile??u2(Se,t.teamId),c=i.setup.format==="T20"?MT(i,t.teamId,r,!t.delegated&&t.matchAware,!t.delegated&&t.clubStyle):i.setup.format==="ODI"?WT(i,t.teamId,r):UT(i,t.teamId,s,r);if(!c)return q(x.currentResponse(t.requestId));const u={version:ve,type:"COMMAND",origin:"AI",requestId:t.requestId,expectedRevision:t.expectedRevision,command:{...c,commandId:t.requestId,expectedRevision:t.expectedRevision}};if(await tn.command(on,t.requestId))return q(x.currentResponse(t.requestId));const p=x.handle(u);return Yi(u,p)}if(t.type==="CHECK_SEEDED_WEATHER"){const i=x.snapshot();if(!i)return q(x.currentResponse(t.requestId,"Start an active match before checking weather."));if(i.setup.format!=="RED_BALL")return q(x.currentResponse(t.requestId,"Seeded weather interruptions are enabled only for five-day red-ball matches; limited-overs rain remains disabled."));if(t.expectedRevision!==i.revision)return q(x.currentResponse(t.requestId,"Stale weather check revision."));if(_n||!on)return q(x.currentResponse(t.requestId,"Weather checks require a writable durable save."));const r=new Set;for(const p of i.events){const E=/^weather-(d[1-5]-s\d+)-r\d+$/.exec(p.commandId);E?.[1]&&r.add(E[1])}const s=tm({session:i,appliedSegmentKeys:r});if(!s||await tn.command(on,s.command.commandId))return q(x.currentResponse(t.requestId));const u={version:ve,type:"COMMAND",origin:"HUMAN",requestId:t.requestId,expectedRevision:t.expectedRevision,command:{...s.command,expectedRevision:t.expectedRevision}},h=x.handle(u);return Yi(u,h)}if(t.type==="COMMAND"&&t.origin!=="HUMAN")return q(x.currentResponse(t.requestId,"AI commands must be generated inside the worker."));if(t.type==="BOOT")return q(x.handle(t));if(t.type==="START"&&!x.snapshot()&&(x=Ge(t.format)),t.type==="COMMAND"&&on){const i=await tn.command(on,t.command.commandId);if(i){if(i.requestCanonical!==G(t))return q(x.currentResponse(t.requestId,"Request ID already used with different content."));const r=await q(x.currentResponse(t.requestId)),s=x.snapshot()?.receipts[t.command.commandId];return s?{...r,acknowledgement:s}:q(x.currentResponse(t.requestId,"The saved command receipt is unavailable."))}}if((t.type==="START"||t.type==="COMMAND")&&_n)return q(x.currentResponse(t.requestId,"This save is read-only because another tab owns the writer lease."));const o=x.handle(t);return t.type==="START"||t.type==="COMMAND"?Yi(t,o):q(o)}const hR=new Set(["BOOT","RECOVER_MANAGED","LOAD_SAVE","RETRY_WRITER"]);async function fR(n){const e=await pR(n),t=n&&typeof n=="object"?n.type:void 0;return typeof t=="string"&&hR.has(t)?uR(e):e}let Wm=Promise.resolve();self.onmessage=n=>{const e=n.data,t=ua.safeParse(e);if(t.success&&t.data.type==="CANCEL_ANALYTICS"){Wa?.requestId===t.data.targetRequestId&&Wa.revision===t.data.expectedRevision&&(Wa.cancelled=!0);return}Wm=Wm.then(async()=>{try{const a=await fR(e),o=ua.safeParse(e);if(a.error&&o.success&&!["PREVIEW_DIAGNOSTIC","EXPORT_DIAGNOSTIC"].includes(o.data.type)){const i=x.snapshot();Ua={requestType:o.data.type,sequence:i?i.events.length+1:null,invariantCode:/^[A-Z][A-Z0-9_]{2,80}$/.test(a.error)?a.error:null,command:o.data.type==="COMMAND"?o.data.command:null},rt=null}else o.success&&["BOOT","START","LOAD_SAVE","IMPORT_SAVE"].includes(o.data.type)&&!a.error&&!(o.data.type==="BOOT"&&Ua?.requestType==="RECOVERY")&&(Ua=null,rt=null);self.postMessage(a)}catch(a){const o=ua.safeParse(e);if(o.success&&!["PREVIEW_DIAGNOSTIC","EXPORT_DIAGNOSTIC"].includes(o.data.type)){const r=x.snapshot(),s=a instanceof Error&&/^[A-Z][A-Z0-9_]{2,80}$/.test(a.message)?a.message:null;Ua={requestType:o.data.type,sequence:r?r.events.length+1:null,invariantCode:s,command:o.data.type==="COMMAND"?o.data.command:null},rt=null}const i=e&&typeof e=="object"&&"requestId"in e?String(e.requestId):"invalid";self.postMessage(await q(x.currentResponse(i,a instanceof Error?a.message:"Unexpected persistence failure.")))}})},setInterval(()=>{on&&!_n&&tn.renewLease(on,Dn,Ae()).then(n=>{n||(_n=!0)}).catch(()=>{_n=!0})},4e3)})();
