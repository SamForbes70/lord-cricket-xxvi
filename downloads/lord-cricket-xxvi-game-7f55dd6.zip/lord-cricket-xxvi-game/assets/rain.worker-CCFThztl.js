(function(){"use strict";var xc=`{
  "packId": "fictional-eight-01",
  "schemaVersion": "1.0.0",
  "players": [
    {
      "playerId": "p001",
      "name": "Ulen Elmcroft",
      "birthDate": "2006-01-24",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 55,
          "timing": 53,
          "power": 49,
          "rotation": 35,
          "vsPace": 58,
          "vsSpin": 47,
          "control": 23,
          "movement": 20,
          "variation": 40,
          "stamina": 35,
          "catching": 63,
          "groundFielding": 48,
          "throwing": 50,
          "keeping": 78
        },
        "ODI": {
          "defence": 42,
          "timing": 39,
          "power": 53,
          "rotation": 55,
          "vsPace": 46,
          "vsSpin": 54,
          "control": 16,
          "movement": 42,
          "variation": 23,
          "stamina": 37,
          "catching": 57,
          "groundFielding": 64,
          "throwing": 71,
          "keeping": 82
        },
        "RED_BALL": {
          "defence": 68,
          "timing": 59,
          "power": 41,
          "rotation": 57,
          "vsPace": 57,
          "vsSpin": 43,
          "control": 33,
          "movement": 20,
          "variation": 37,
          "stamina": 23,
          "catching": 41,
          "groundFielding": 54,
          "throwing": 52,
          "keeping": 78
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        769,
        543,
        812,
        249,
        256,
        943,
        996,
        930
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p002",
      "name": "Caro Harden",
      "birthDate": "1999-12-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 47,
          "power": 39,
          "rotation": 45,
          "vsPace": 40,
          "vsSpin": 40,
          "control": 15,
          "movement": 24,
          "variation": 38,
          "stamina": 36,
          "catching": 70,
          "groundFielding": 47,
          "throwing": 67,
          "keeping": 70
        },
        "ODI": {
          "defence": 56,
          "timing": 54,
          "power": 61,
          "rotation": 45,
          "vsPace": 35,
          "vsSpin": 36,
          "control": 26,
          "movement": 23,
          "variation": 32,
          "stamina": 22,
          "catching": 46,
          "groundFielding": 48,
          "throwing": 69,
          "keeping": 70
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 54,
          "power": 52,
          "rotation": 34,
          "vsPace": 50,
          "vsSpin": 37,
          "control": 19,
          "movement": 24,
          "variation": 13,
          "stamina": 31,
          "catching": 55,
          "groundFielding": 50,
          "throwing": 71,
          "keeping": 80
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        626,
        792,
        596,
        535,
        453,
        701,
        994,
        207
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p003",
      "name": "Talor Elmholt",
      "birthDate": "1988-07-28",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 49,
          "timing": 31,
          "power": 34,
          "rotation": 36,
          "vsPace": 30,
          "vsSpin": 34,
          "control": 64,
          "movement": 73,
          "variation": 62,
          "stamina": 56,
          "catching": 49,
          "groundFielding": 45,
          "throwing": 62,
          "keeping": 27
        },
        "ODI": {
          "defence": 30,
          "timing": 25,
          "power": 27,
          "rotation": 46,
          "vsPace": 36,
          "vsSpin": 40,
          "control": 64,
          "movement": 64,
          "variation": 69,
          "stamina": 78,
          "catching": 63,
          "groundFielding": 64,
          "throwing": 67,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 36,
          "timing": 43,
          "power": 26,
          "rotation": 41,
          "vsPace": 20,
          "vsSpin": 22,
          "control": 55,
          "movement": 58,
          "variation": 77,
          "stamina": 68,
          "catching": 68,
          "groundFielding": 42,
          "throwing": 56,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        650,
        907,
        747,
        833,
        478,
        405,
        619,
        846
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p004",
      "name": "Fenn Glenthorne",
      "birthDate": "1999-08-07",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 32,
          "timing": 40,
          "power": 29,
          "rotation": 19,
          "vsPace": 29,
          "vsSpin": 33,
          "control": 62,
          "movement": 79,
          "variation": 51,
          "stamina": 71,
          "catching": 58,
          "groundFielding": 62,
          "throwing": 69,
          "keeping": 34
        },
        "ODI": {
          "defence": 22,
          "timing": 46,
          "power": 34,
          "rotation": 19,
          "vsPace": 30,
          "vsSpin": 34,
          "control": 73,
          "movement": 56,
          "variation": 50,
          "stamina": 61,
          "catching": 49,
          "groundFielding": 54,
          "throwing": 60,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 50,
          "timing": 35,
          "power": 18,
          "rotation": 25,
          "vsPace": 39,
          "vsSpin": 37,
          "control": 63,
          "movement": 61,
          "variation": 74,
          "stamina": 60,
          "catching": 47,
          "groundFielding": 43,
          "throwing": 64,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        757,
        461,
        833,
        706,
        622,
        326,
        818,
        927
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p005",
      "name": "Arven Valebridge",
      "birthDate": "2007-07-01",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 28,
          "timing": 21,
          "power": 53,
          "rotation": 45,
          "vsPace": 45,
          "vsSpin": 37,
          "control": 80,
          "movement": 74,
          "variation": 69,
          "stamina": 50,
          "catching": 40,
          "groundFielding": 58,
          "throwing": 55,
          "keeping": 11
        },
        "ODI": {
          "defence": 35,
          "timing": 45,
          "power": 39,
          "rotation": 38,
          "vsPace": 24,
          "vsSpin": 47,
          "control": 76,
          "movement": 79,
          "variation": 54,
          "stamina": 61,
          "catching": 47,
          "groundFielding": 40,
          "throwing": 47,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 28,
          "timing": 45,
          "power": 20,
          "rotation": 37,
          "vsPace": 49,
          "vsSpin": 26,
          "control": 73,
          "movement": 77,
          "variation": 61,
          "stamina": 77,
          "catching": 66,
          "groundFielding": 62,
          "throwing": 62,
          "keeping": 12
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        307,
        372,
        469,
        256,
        638,
        703,
        520,
        273
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p006",
      "name": "Halen Normere",
      "birthDate": "1995-05-07",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 22,
          "timing": 46,
          "power": 42,
          "rotation": 49,
          "vsPace": 39,
          "vsSpin": 35,
          "control": 62,
          "movement": 69,
          "variation": 62,
          "stamina": 69,
          "catching": 41,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 29
        },
        "ODI": {
          "defence": 38,
          "timing": 23,
          "power": 49,
          "rotation": 26,
          "vsPace": 30,
          "vsSpin": 31,
          "control": 54,
          "movement": 66,
          "variation": 60,
          "stamina": 69,
          "catching": 61,
          "groundFielding": 41,
          "throwing": 53,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 41,
          "timing": 28,
          "power": 20,
          "rotation": 28,
          "vsPace": 45,
          "vsSpin": 33,
          "control": 60,
          "movement": 66,
          "variation": 60,
          "stamina": 65,
          "catching": 51,
          "groundFielding": 65,
          "throwing": 69,
          "keeping": 30
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        906,
        645,
        484,
        377,
        657,
        740,
        737,
        339
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p007",
      "name": "Sela Sablestone",
      "birthDate": "2002-06-18",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 46,
          "timing": 38,
          "power": 46,
          "rotation": 34,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 75,
          "movement": 71,
          "variation": 64,
          "stamina": 73,
          "catching": 59,
          "groundFielding": 39,
          "throwing": 61,
          "keeping": 12
        },
        "ODI": {
          "defence": 29,
          "timing": 32,
          "power": 40,
          "rotation": 27,
          "vsPace": 24,
          "vsSpin": 26,
          "control": 78,
          "movement": 54,
          "variation": 56,
          "stamina": 70,
          "catching": 56,
          "groundFielding": 48,
          "throwing": 48,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 46,
          "timing": 48,
          "power": 35,
          "rotation": 35,
          "vsPace": 43,
          "vsSpin": 42,
          "control": 60,
          "movement": 60,
          "variation": 51,
          "stamina": 63,
          "catching": 52,
          "groundFielding": 42,
          "throwing": 49,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        435,
        439,
        593,
        453,
        422,
        720,
        912,
        250
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p008",
      "name": "Isen Kelholt",
      "birthDate": "1996-07-10",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 29,
          "timing": 33,
          "power": 35,
          "rotation": 23,
          "vsPace": 31,
          "vsSpin": 23,
          "control": 74,
          "movement": 75,
          "variation": 80,
          "stamina": 76,
          "catching": 42,
          "groundFielding": 40,
          "throwing": 55,
          "keeping": 25
        },
        "ODI": {
          "defence": 34,
          "timing": 22,
          "power": 20,
          "rotation": 40,
          "vsPace": 36,
          "vsSpin": 30,
          "control": 62,
          "movement": 77,
          "variation": 61,
          "stamina": 50,
          "catching": 58,
          "groundFielding": 63,
          "throwing": 64,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 22,
          "power": 24,
          "rotation": 36,
          "vsPace": 24,
          "vsSpin": 41,
          "control": 79,
          "movement": 52,
          "variation": 57,
          "stamina": 53,
          "catching": 54,
          "groundFielding": 39,
          "throwing": 62,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        301,
        977,
        683,
        544,
        561,
        755,
        997,
        769
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p009",
      "name": "Nerin Orinbridge",
      "birthDate": "1988-03-08",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 38,
          "timing": 46,
          "power": 64,
          "rotation": 48,
          "vsPace": 56,
          "vsSpin": 52,
          "control": 55,
          "movement": 58,
          "variation": 53,
          "stamina": 43,
          "catching": 52,
          "groundFielding": 44,
          "throwing": 70,
          "keeping": 40
        },
        "ODI": {
          "defence": 39,
          "timing": 53,
          "power": 59,
          "rotation": 43,
          "vsPace": 48,
          "vsSpin": 52,
          "control": 61,
          "movement": 67,
          "variation": 43,
          "stamina": 47,
          "catching": 45,
          "groundFielding": 72,
          "throwing": 63,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 51,
          "power": 46,
          "rotation": 47,
          "vsPace": 41,
          "vsSpin": 43,
          "control": 63,
          "movement": 51,
          "variation": 51,
          "stamina": 62,
          "catching": 52,
          "groundFielding": 56,
          "throwing": 56,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        760,
        392,
        574,
        472,
        422,
        243,
        293,
        872
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p010",
      "name": "Zerin Sablebrook",
      "birthDate": "2003-05-22",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 38,
          "timing": 38,
          "power": 68,
          "rotation": 42,
          "vsPace": 48,
          "vsSpin": 53,
          "control": 55,
          "movement": 60,
          "variation": 52,
          "stamina": 56,
          "catching": 71,
          "groundFielding": 54,
          "throwing": 43,
          "keeping": 40
        },
        "ODI": {
          "defence": 68,
          "timing": 49,
          "power": 51,
          "rotation": 40,
          "vsPace": 54,
          "vsSpin": 48,
          "control": 62,
          "movement": 37,
          "variation": 38,
          "stamina": 48,
          "catching": 65,
          "groundFielding": 72,
          "throwing": 42,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 54,
          "timing": 51,
          "power": 39,
          "rotation": 56,
          "vsPace": 64,
          "vsSpin": 47,
          "control": 57,
          "movement": 48,
          "variation": 37,
          "stamina": 54,
          "catching": 67,
          "groundFielding": 71,
          "throwing": 61,
          "keeping": 25
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        763,
        267,
        604,
        292,
        768,
        345,
        424,
        560
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p011",
      "name": "Fenn Jorthorne",
      "birthDate": "2007-11-18",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 43,
          "power": 58,
          "rotation": 41,
          "vsPace": 38,
          "vsSpin": 65,
          "control": 45,
          "movement": 58,
          "variation": 59,
          "stamina": 37,
          "catching": 72,
          "groundFielding": 69,
          "throwing": 51,
          "keeping": 12
        },
        "ODI": {
          "defence": 49,
          "timing": 39,
          "power": 67,
          "rotation": 46,
          "vsPace": 61,
          "vsSpin": 55,
          "control": 37,
          "movement": 61,
          "variation": 41,
          "stamina": 46,
          "catching": 62,
          "groundFielding": 60,
          "throwing": 66,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 46,
          "power": 35,
          "rotation": 50,
          "vsPace": 45,
          "vsSpin": 39,
          "control": 53,
          "movement": 45,
          "variation": 49,
          "stamina": 37,
          "catching": 51,
          "groundFielding": 59,
          "throwing": 68,
          "keeping": 32
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        610,
        352,
        658,
        987,
        637,
        873,
        208,
        224
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p012",
      "name": "Elio Ashbrook",
      "birthDate": "1997-12-28",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 58,
          "timing": 63,
          "power": 59,
          "rotation": 53,
          "vsPace": 61,
          "vsSpin": 54,
          "control": 43,
          "movement": 19,
          "variation": 28,
          "stamina": 19,
          "catching": 58,
          "groundFielding": 43,
          "throwing": 41,
          "keeping": 17
        },
        "ODI": {
          "defence": 54,
          "timing": 69,
          "power": 58,
          "rotation": 66,
          "vsPace": 55,
          "vsSpin": 62,
          "control": 30,
          "movement": 33,
          "variation": 17,
          "stamina": 27,
          "catching": 54,
          "groundFielding": 45,
          "throwing": 63,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 66,
          "timing": 70,
          "power": 71,
          "rotation": 74,
          "vsPace": 61,
          "vsSpin": 51,
          "control": 14,
          "movement": 39,
          "variation": 32,
          "stamina": 35,
          "catching": 62,
          "groundFielding": 51,
          "throwing": 38,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        809,
        987,
        357,
        874,
        249,
        843,
        813,
        950
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p013",
      "name": "Quill Sablebridge",
      "birthDate": "1994-04-18",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 75,
          "timing": 64,
          "power": 55,
          "rotation": 59,
          "vsPace": 64,
          "vsSpin": 76,
          "control": 16,
          "movement": 29,
          "variation": 28,
          "stamina": 23,
          "catching": 65,
          "groundFielding": 64,
          "throwing": 46,
          "keeping": 26
        },
        "ODI": {
          "defence": 77,
          "timing": 57,
          "power": 76,
          "rotation": 72,
          "vsPace": 68,
          "vsSpin": 52,
          "control": 19,
          "movement": 17,
          "variation": 26,
          "stamina": 30,
          "catching": 46,
          "groundFielding": 51,
          "throwing": 43,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 71,
          "power": 55,
          "rotation": 54,
          "vsPace": 74,
          "vsSpin": 67,
          "control": 21,
          "movement": 38,
          "variation": 38,
          "stamina": 25,
          "catching": 60,
          "groundFielding": 57,
          "throwing": 60,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        552,
        929,
        640,
        875,
        271,
        354,
        860,
        670
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p014",
      "name": "Nave Elmford",
      "birthDate": "1991-01-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 70,
          "timing": 80,
          "power": 74,
          "rotation": 67,
          "vsPace": 68,
          "vsSpin": 77,
          "control": 32,
          "movement": 21,
          "variation": 27,
          "stamina": 29,
          "catching": 40,
          "groundFielding": 48,
          "throwing": 53,
          "keeping": 15
        },
        "ODI": {
          "defence": 74,
          "timing": 78,
          "power": 64,
          "rotation": 74,
          "vsPace": 80,
          "vsSpin": 73,
          "control": 23,
          "movement": 24,
          "variation": 44,
          "stamina": 41,
          "catching": 43,
          "groundFielding": 57,
          "throwing": 66,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 59,
          "power": 65,
          "rotation": 63,
          "vsPace": 56,
          "vsSpin": 68,
          "control": 38,
          "movement": 33,
          "variation": 26,
          "stamina": 41,
          "catching": 64,
          "groundFielding": 41,
          "throwing": 38,
          "keeping": 25
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        249,
        795,
        989,
        996,
        471,
        606,
        638,
        740
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p015",
      "name": "Eren Ashstead",
      "birthDate": "1988-05-06",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 55,
          "power": 59,
          "rotation": 52,
          "vsPace": 65,
          "vsSpin": 60,
          "control": 40,
          "movement": 34,
          "variation": 27,
          "stamina": 38,
          "catching": 51,
          "groundFielding": 59,
          "throwing": 59,
          "keeping": 19
        },
        "ODI": {
          "defence": 61,
          "timing": 56,
          "power": 64,
          "rotation": 52,
          "vsPace": 54,
          "vsSpin": 67,
          "control": 36,
          "movement": 37,
          "variation": 26,
          "stamina": 42,
          "catching": 63,
          "groundFielding": 40,
          "throwing": 56,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 50,
          "power": 55,
          "rotation": 63,
          "vsPace": 79,
          "vsSpin": 62,
          "control": 29,
          "movement": 18,
          "variation": 40,
          "stamina": 29,
          "catching": 37,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        305,
        339,
        390,
        487,
        867,
        724,
        327,
        533
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p016",
      "name": "Eren Rookholt",
      "birthDate": "2007-10-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 54,
          "power": 62,
          "rotation": 76,
          "vsPace": 78,
          "vsSpin": 69,
          "control": 24,
          "movement": 23,
          "variation": 40,
          "stamina": 19,
          "catching": 54,
          "groundFielding": 59,
          "throwing": 39,
          "keeping": 21
        },
        "ODI": {
          "defence": 50,
          "timing": 71,
          "power": 59,
          "rotation": 62,
          "vsPace": 51,
          "vsSpin": 69,
          "control": 37,
          "movement": 29,
          "variation": 19,
          "stamina": 34,
          "catching": 38,
          "groundFielding": 45,
          "throwing": 57,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 77,
          "power": 60,
          "rotation": 76,
          "vsPace": 77,
          "vsSpin": 51,
          "control": 30,
          "movement": 31,
          "variation": 22,
          "stamina": 34,
          "catching": 38,
          "groundFielding": 55,
          "throwing": 50,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        254,
        646,
        361,
        756,
        972,
        341,
        803,
        293
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p017",
      "name": "Nerin Elmcroft",
      "birthDate": "1996-01-18",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 58,
          "timing": 74,
          "power": 56,
          "rotation": 53,
          "vsPace": 73,
          "vsSpin": 73,
          "control": 26,
          "movement": 36,
          "variation": 21,
          "stamina": 21,
          "catching": 49,
          "groundFielding": 52,
          "throwing": 62,
          "keeping": 30
        },
        "ODI": {
          "defence": 58,
          "timing": 79,
          "power": 55,
          "rotation": 60,
          "vsPace": 77,
          "vsSpin": 52,
          "control": 37,
          "movement": 39,
          "variation": 18,
          "stamina": 34,
          "catching": 40,
          "groundFielding": 62,
          "throwing": 47,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 75,
          "timing": 67,
          "power": 61,
          "rotation": 67,
          "vsPace": 74,
          "vsSpin": 69,
          "control": 43,
          "movement": 42,
          "variation": 30,
          "stamina": 14,
          "catching": 45,
          "groundFielding": 54,
          "throwing": 61,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        470,
        461,
        260,
        560,
        430,
        410,
        792,
        532
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p018",
      "name": "Yoran Pellbrook",
      "birthDate": "1994-01-23",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 63,
          "power": 59,
          "rotation": 67,
          "vsPace": 74,
          "vsSpin": 79,
          "control": 25,
          "movement": 33,
          "variation": 40,
          "stamina": 26,
          "catching": 53,
          "groundFielding": 51,
          "throwing": 45,
          "keeping": 16
        },
        "ODI": {
          "defence": 68,
          "timing": 58,
          "power": 50,
          "rotation": 50,
          "vsPace": 73,
          "vsSpin": 66,
          "control": 25,
          "movement": 41,
          "variation": 29,
          "stamina": 44,
          "catching": 48,
          "groundFielding": 48,
          "throwing": 39,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 52,
          "power": 53,
          "rotation": 77,
          "vsPace": 75,
          "vsSpin": 64,
          "control": 27,
          "movement": 15,
          "variation": 21,
          "stamina": 26,
          "catching": 44,
          "groundFielding": 50,
          "throwing": 40,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        738,
        743,
        243,
        780,
        627,
        438,
        793,
        662
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p019",
      "name": "Yoran Harridge",
      "birthDate": "2004-12-01",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 70,
          "timing": 50,
          "power": 56,
          "rotation": 58,
          "vsPace": 59,
          "vsSpin": 50,
          "control": 30,
          "movement": 18,
          "variation": 20,
          "stamina": 44,
          "catching": 53,
          "groundFielding": 50,
          "throwing": 48,
          "keeping": 16
        },
        "ODI": {
          "defence": 51,
          "timing": 78,
          "power": 69,
          "rotation": 76,
          "vsPace": 77,
          "vsSpin": 50,
          "control": 24,
          "movement": 20,
          "variation": 28,
          "stamina": 32,
          "catching": 62,
          "groundFielding": 54,
          "throwing": 67,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 57,
          "timing": 79,
          "power": 54,
          "rotation": 65,
          "vsPace": 63,
          "vsSpin": 74,
          "control": 27,
          "movement": 44,
          "variation": 23,
          "stamina": 16,
          "catching": 59,
          "groundFielding": 57,
          "throwing": 51,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        829,
        413,
        737,
        576,
        955,
        951,
        844,
        913
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p020",
      "name": "Galen Zornden",
      "birthDate": "2002-08-20",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 53,
          "power": 80,
          "rotation": 73,
          "vsPace": 76,
          "vsSpin": 80,
          "control": 38,
          "movement": 41,
          "variation": 37,
          "stamina": 33,
          "catching": 50,
          "groundFielding": 45,
          "throwing": 50,
          "keeping": 31
        },
        "ODI": {
          "defence": 56,
          "timing": 80,
          "power": 74,
          "rotation": 80,
          "vsPace": 78,
          "vsSpin": 51,
          "control": 31,
          "movement": 34,
          "variation": 37,
          "stamina": 28,
          "catching": 60,
          "groundFielding": 49,
          "throwing": 48,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 78,
          "timing": 76,
          "power": 63,
          "rotation": 64,
          "vsPace": 57,
          "vsSpin": 68,
          "control": 31,
          "movement": 30,
          "variation": 14,
          "stamina": 32,
          "catching": 44,
          "groundFielding": 40,
          "throwing": 61,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        437,
        997,
        413,
        917,
        402,
        660,
        705,
        463
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p021",
      "name": "Walen Sableholt",
      "birthDate": "1997-12-15",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 36,
          "power": 41,
          "rotation": 56,
          "vsPace": 51,
          "vsSpin": 58,
          "control": 42,
          "movement": 31,
          "variation": 29,
          "stamina": 12,
          "catching": 56,
          "groundFielding": 58,
          "throwing": 57,
          "keeping": 73
        },
        "ODI": {
          "defence": 61,
          "timing": 37,
          "power": 63,
          "rotation": 53,
          "vsPace": 39,
          "vsSpin": 64,
          "control": 35,
          "movement": 42,
          "variation": 13,
          "stamina": 41,
          "catching": 69,
          "groundFielding": 65,
          "throwing": 45,
          "keeping": 80
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 55,
          "power": 43,
          "rotation": 42,
          "vsPace": 55,
          "vsSpin": 45,
          "control": 19,
          "movement": 14,
          "variation": 17,
          "stamina": 20,
          "catching": 48,
          "groundFielding": 66,
          "throwing": 52,
          "keeping": 76
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        691,
        484,
        492,
        590,
        991,
        255,
        476,
        877
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p022",
      "name": "Ulen Wrenthorne",
      "birthDate": "1998-06-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 54,
          "power": 60,
          "rotation": 40,
          "vsPace": 64,
          "vsSpin": 55,
          "control": 42,
          "movement": 13,
          "variation": 26,
          "stamina": 20,
          "catching": 45,
          "groundFielding": 62,
          "throwing": 41,
          "keeping": 56
        },
        "ODI": {
          "defence": 41,
          "timing": 58,
          "power": 48,
          "rotation": 34,
          "vsPace": 60,
          "vsSpin": 35,
          "control": 21,
          "movement": 38,
          "variation": 13,
          "stamina": 31,
          "catching": 66,
          "groundFielding": 44,
          "throwing": 44,
          "keeping": 59
        },
        "RED_BALL": {
          "defence": 51,
          "timing": 41,
          "power": 56,
          "rotation": 40,
          "vsPace": 60,
          "vsSpin": 54,
          "control": 25,
          "movement": 17,
          "variation": 17,
          "stamina": 13,
          "catching": 48,
          "groundFielding": 69,
          "throwing": 51,
          "keeping": 78
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        598,
        605,
        697,
        615,
        410,
        240,
        621,
        805
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p023",
      "name": "Pavan Zornstone",
      "birthDate": "2003-11-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 39,
          "timing": 48,
          "power": 39,
          "rotation": 32,
          "vsPace": 47,
          "vsSpin": 30,
          "control": 66,
          "movement": 77,
          "variation": 67,
          "stamina": 60,
          "catching": 65,
          "groundFielding": 52,
          "throwing": 62,
          "keeping": 24
        },
        "ODI": {
          "defence": 28,
          "timing": 29,
          "power": 24,
          "rotation": 36,
          "vsPace": 45,
          "vsSpin": 31,
          "control": 73,
          "movement": 74,
          "variation": 52,
          "stamina": 78,
          "catching": 63,
          "groundFielding": 52,
          "throwing": 68,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 27,
          "timing": 19,
          "power": 32,
          "rotation": 40,
          "vsPace": 24,
          "vsSpin": 48,
          "control": 64,
          "movement": 67,
          "variation": 61,
          "stamina": 76,
          "catching": 67,
          "groundFielding": 42,
          "throwing": 49,
          "keeping": 18
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        708,
        357,
        237,
        752,
        382,
        449,
        761,
        542
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p024",
      "name": "Rilan Rookfield",
      "birthDate": "2005-05-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 25,
          "timing": 37,
          "power": 30,
          "rotation": 22,
          "vsPace": 28,
          "vsSpin": 48,
          "control": 72,
          "movement": 65,
          "variation": 57,
          "stamina": 70,
          "catching": 65,
          "groundFielding": 58,
          "throwing": 42,
          "keeping": 21
        },
        "ODI": {
          "defence": 45,
          "timing": 24,
          "power": 34,
          "rotation": 47,
          "vsPace": 19,
          "vsSpin": 48,
          "control": 64,
          "movement": 52,
          "variation": 77,
          "stamina": 65,
          "catching": 64,
          "groundFielding": 40,
          "throwing": 69,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 27,
          "timing": 40,
          "power": 27,
          "rotation": 46,
          "vsPace": 48,
          "vsSpin": 19,
          "control": 55,
          "movement": 53,
          "variation": 50,
          "stamina": 80,
          "catching": 63,
          "groundFielding": 55,
          "throwing": 48,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        584,
        917,
        279,
        473,
        646,
        402,
        706,
        403
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p025",
      "name": "Zerin Wrenbrook",
      "birthDate": "1990-07-28",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 32,
          "timing": 20,
          "power": 34,
          "rotation": 35,
          "vsPace": 35,
          "vsSpin": 48,
          "control": 57,
          "movement": 65,
          "variation": 67,
          "stamina": 52,
          "catching": 50,
          "groundFielding": 45,
          "throwing": 40,
          "keeping": 29
        },
        "ODI": {
          "defence": 31,
          "timing": 37,
          "power": 42,
          "rotation": 19,
          "vsPace": 31,
          "vsSpin": 39,
          "control": 70,
          "movement": 69,
          "variation": 53,
          "stamina": 73,
          "catching": 41,
          "groundFielding": 55,
          "throwing": 52,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 31,
          "timing": 23,
          "power": 29,
          "rotation": 40,
          "vsPace": 40,
          "vsSpin": 39,
          "control": 56,
          "movement": 50,
          "variation": 71,
          "stamina": 50,
          "catching": 42,
          "groundFielding": 65,
          "throwing": 53,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        657,
        773,
        958,
        885,
        245,
        815,
        766,
        513
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p026",
      "name": "Borin Zornbrook",
      "birthDate": "1998-06-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 27,
          "timing": 36,
          "power": 25,
          "rotation": 49,
          "vsPace": 37,
          "vsSpin": 27,
          "control": 50,
          "movement": 78,
          "variation": 53,
          "stamina": 56,
          "catching": 65,
          "groundFielding": 42,
          "throwing": 49,
          "keeping": 41
        },
        "ODI": {
          "defence": 46,
          "timing": 43,
          "power": 33,
          "rotation": 25,
          "vsPace": 20,
          "vsSpin": 31,
          "control": 68,
          "movement": 54,
          "variation": 77,
          "stamina": 59,
          "catching": 48,
          "groundFielding": 57,
          "throwing": 56,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 28,
          "timing": 35,
          "power": 38,
          "rotation": 23,
          "vsPace": 28,
          "vsSpin": 33,
          "control": 63,
          "movement": 67,
          "variation": 55,
          "stamina": 63,
          "catching": 53,
          "groundFielding": 63,
          "throwing": 60,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        230,
        311,
        805,
        559,
        449,
        768,
        803,
        604
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p027",
      "name": "Jora Mossridge",
      "birthDate": "1988-08-21",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 44,
          "power": 41,
          "rotation": 22,
          "vsPace": 42,
          "vsSpin": 32,
          "control": 52,
          "movement": 76,
          "variation": 70,
          "stamina": 60,
          "catching": 55,
          "groundFielding": 59,
          "throwing": 51,
          "keeping": 31
        },
        "ODI": {
          "defence": 27,
          "timing": 39,
          "power": 47,
          "rotation": 26,
          "vsPace": 49,
          "vsSpin": 44,
          "control": 55,
          "movement": 58,
          "variation": 53,
          "stamina": 50,
          "catching": 49,
          "groundFielding": 60,
          "throwing": 47,
          "keeping": 34
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 34,
          "power": 36,
          "rotation": 38,
          "vsPace": 30,
          "vsSpin": 37,
          "control": 63,
          "movement": 76,
          "variation": 75,
          "stamina": 63,
          "catching": 42,
          "groundFielding": 45,
          "throwing": 43,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        685,
        344,
        907,
        538,
        521,
        813,
        493,
        981
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p028",
      "name": "Quill Ternstead",
      "birthDate": "1992-12-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 20,
          "timing": 28,
          "power": 41,
          "rotation": 33,
          "vsPace": 38,
          "vsSpin": 19,
          "control": 58,
          "movement": 69,
          "variation": 76,
          "stamina": 67,
          "catching": 46,
          "groundFielding": 60,
          "throwing": 58,
          "keeping": 38
        },
        "ODI": {
          "defence": 47,
          "timing": 31,
          "power": 25,
          "rotation": 40,
          "vsPace": 26,
          "vsSpin": 40,
          "control": 50,
          "movement": 78,
          "variation": 72,
          "stamina": 75,
          "catching": 48,
          "groundFielding": 52,
          "throwing": 65,
          "keeping": 27
        },
        "RED_BALL": {
          "defence": 44,
          "timing": 47,
          "power": 37,
          "rotation": 24,
          "vsPace": 19,
          "vsSpin": 22,
          "control": 69,
          "movement": 68,
          "variation": 54,
          "stamina": 54,
          "catching": 68,
          "groundFielding": 42,
          "throwing": 59,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        736,
        772,
        877,
        718,
        401,
        406,
        386,
        736
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p029",
      "name": "Leron Briarstone",
      "birthDate": "2003-01-02",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 47,
          "power": 49,
          "rotation": 59,
          "vsPace": 48,
          "vsSpin": 49,
          "control": 41,
          "movement": 64,
          "variation": 60,
          "stamina": 64,
          "catching": 54,
          "groundFielding": 49,
          "throwing": 54,
          "keeping": 32
        },
        "ODI": {
          "defence": 66,
          "timing": 51,
          "power": 45,
          "rotation": 43,
          "vsPace": 54,
          "vsSpin": 62,
          "control": 45,
          "movement": 44,
          "variation": 50,
          "stamina": 47,
          "catching": 53,
          "groundFielding": 51,
          "throwing": 55,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 55,
          "timing": 65,
          "power": 48,
          "rotation": 49,
          "vsPace": 46,
          "vsSpin": 56,
          "control": 50,
          "movement": 57,
          "variation": 67,
          "stamina": 58,
          "catching": 55,
          "groundFielding": 64,
          "throwing": 66,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        904,
        606,
        465,
        429,
        811,
        658,
        919,
        529
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p030",
      "name": "Rilan Jorfield",
      "birthDate": "1999-05-05",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 48,
          "timing": 38,
          "power": 61,
          "rotation": 46,
          "vsPace": 50,
          "vsSpin": 58,
          "control": 46,
          "movement": 58,
          "variation": 65,
          "stamina": 52,
          "catching": 68,
          "groundFielding": 44,
          "throwing": 59,
          "keeping": 18
        },
        "ODI": {
          "defence": 57,
          "timing": 48,
          "power": 49,
          "rotation": 66,
          "vsPace": 58,
          "vsSpin": 41,
          "control": 65,
          "movement": 54,
          "variation": 60,
          "stamina": 47,
          "catching": 63,
          "groundFielding": 67,
          "throwing": 55,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 49,
          "timing": 65,
          "power": 35,
          "rotation": 44,
          "vsPace": 52,
          "vsSpin": 50,
          "control": 52,
          "movement": 53,
          "variation": 50,
          "stamina": 58,
          "catching": 62,
          "groundFielding": 55,
          "throwing": 58,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        842,
        423,
        606,
        680,
        454,
        661,
        759,
        226
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p031",
      "name": "Elio Valethorne",
      "birthDate": "1995-08-25",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 45,
          "power": 46,
          "rotation": 58,
          "vsPace": 38,
          "vsSpin": 38,
          "control": 62,
          "movement": 66,
          "variation": 67,
          "stamina": 58,
          "catching": 45,
          "groundFielding": 69,
          "throwing": 57,
          "keeping": 21
        },
        "ODI": {
          "defence": 65,
          "timing": 63,
          "power": 65,
          "rotation": 41,
          "vsPace": 40,
          "vsSpin": 60,
          "control": 52,
          "movement": 57,
          "variation": 45,
          "stamina": 43,
          "catching": 65,
          "groundFielding": 48,
          "throwing": 65,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 68,
          "timing": 38,
          "power": 59,
          "rotation": 62,
          "vsPace": 64,
          "vsSpin": 66,
          "control": 58,
          "movement": 44,
          "variation": 54,
          "stamina": 52,
          "catching": 45,
          "groundFielding": 68,
          "throwing": 53,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        806,
        641,
        284,
        837,
        960,
        505,
        380,
        216
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p032",
      "name": "Ari Mossbridge",
      "birthDate": "1992-04-18",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 63,
          "power": 62,
          "rotation": 60,
          "vsPace": 51,
          "vsSpin": 50,
          "control": 18,
          "movement": 33,
          "variation": 35,
          "stamina": 30,
          "catching": 58,
          "groundFielding": 56,
          "throwing": 61,
          "keeping": 18
        },
        "ODI": {
          "defence": 58,
          "timing": 72,
          "power": 68,
          "rotation": 60,
          "vsPace": 62,
          "vsSpin": 60,
          "control": 19,
          "movement": 34,
          "variation": 15,
          "stamina": 22,
          "catching": 51,
          "groundFielding": 65,
          "throwing": 45,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 66,
          "power": 52,
          "rotation": 77,
          "vsPace": 80,
          "vsSpin": 57,
          "control": 15,
          "movement": 41,
          "variation": 33,
          "stamina": 18,
          "catching": 60,
          "groundFielding": 58,
          "throwing": 47,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        627,
        857,
        373,
        300,
        225,
        798,
        405,
        627
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p033",
      "name": "Vero Glenthorne",
      "birthDate": "1991-04-10",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 76,
          "timing": 62,
          "power": 68,
          "rotation": 73,
          "vsPace": 57,
          "vsSpin": 74,
          "control": 29,
          "movement": 20,
          "variation": 43,
          "stamina": 25,
          "catching": 57,
          "groundFielding": 59,
          "throwing": 61,
          "keeping": 25
        },
        "ODI": {
          "defence": 53,
          "timing": 76,
          "power": 77,
          "rotation": 70,
          "vsPace": 63,
          "vsSpin": 58,
          "control": 29,
          "movement": 20,
          "variation": 42,
          "stamina": 44,
          "catching": 44,
          "groundFielding": 42,
          "throwing": 50,
          "keeping": 41
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 67,
          "power": 75,
          "rotation": 57,
          "vsPace": 62,
          "vsSpin": 64,
          "control": 24,
          "movement": 21,
          "variation": 37,
          "stamina": 28,
          "catching": 48,
          "groundFielding": 54,
          "throwing": 66,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        362,
        821,
        415,
        466,
        660,
        589,
        420,
        203
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p034",
      "name": "Isen Ternfell",
      "birthDate": "2001-07-20",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 64,
          "power": 68,
          "rotation": 54,
          "vsPace": 67,
          "vsSpin": 78,
          "control": 15,
          "movement": 33,
          "variation": 31,
          "stamina": 39,
          "catching": 50,
          "groundFielding": 56,
          "throwing": 53,
          "keeping": 11
        },
        "ODI": {
          "defence": 60,
          "timing": 68,
          "power": 54,
          "rotation": 52,
          "vsPace": 72,
          "vsSpin": 62,
          "control": 34,
          "movement": 23,
          "variation": 16,
          "stamina": 17,
          "catching": 48,
          "groundFielding": 46,
          "throwing": 59,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 59,
          "timing": 66,
          "power": 72,
          "rotation": 51,
          "vsPace": 65,
          "vsSpin": 80,
          "control": 16,
          "movement": 30,
          "variation": 18,
          "stamina": 33,
          "catching": 61,
          "groundFielding": 48,
          "throwing": 48,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        561,
        842,
        1000,
        382,
        426,
        520,
        249,
        916
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p035",
      "name": "Talor Pellbridge",
      "birthDate": "1996-03-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 58,
          "power": 61,
          "rotation": 63,
          "vsPace": 53,
          "vsSpin": 68,
          "control": 40,
          "movement": 23,
          "variation": 15,
          "stamina": 18,
          "catching": 38,
          "groundFielding": 42,
          "throwing": 47,
          "keeping": 13
        },
        "ODI": {
          "defence": 57,
          "timing": 70,
          "power": 55,
          "rotation": 66,
          "vsPace": 57,
          "vsSpin": 72,
          "control": 35,
          "movement": 38,
          "variation": 15,
          "stamina": 36,
          "catching": 46,
          "groundFielding": 44,
          "throwing": 50,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 53,
          "power": 66,
          "rotation": 71,
          "vsPace": 73,
          "vsSpin": 53,
          "control": 16,
          "movement": 17,
          "variation": 29,
          "stamina": 42,
          "catching": 59,
          "groundFielding": 64,
          "throwing": 46,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        276,
        713,
        500,
        665,
        875,
        299,
        367,
        263
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p036",
      "name": "Vero Jorcroft",
      "birthDate": "2007-12-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 71,
          "power": 54,
          "rotation": 77,
          "vsPace": 53,
          "vsSpin": 76,
          "control": 39,
          "movement": 40,
          "variation": 44,
          "stamina": 28,
          "catching": 37,
          "groundFielding": 44,
          "throwing": 57,
          "keeping": 21
        },
        "ODI": {
          "defence": 70,
          "timing": 68,
          "power": 73,
          "rotation": 53,
          "vsPace": 66,
          "vsSpin": 58,
          "control": 18,
          "movement": 19,
          "variation": 39,
          "stamina": 14,
          "catching": 44,
          "groundFielding": 54,
          "throwing": 44,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 64,
          "timing": 73,
          "power": 62,
          "rotation": 64,
          "vsPace": 63,
          "vsSpin": 69,
          "control": 43,
          "movement": 29,
          "variation": 20,
          "stamina": 39,
          "catching": 57,
          "groundFielding": 51,
          "throwing": 39,
          "keeping": 32
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        850,
        339,
        912,
        540,
        951,
        924,
        338,
        394
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p037",
      "name": "Walen Mosswell",
      "birthDate": "2001-09-28",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 61,
          "power": 73,
          "rotation": 62,
          "vsPace": 67,
          "vsSpin": 57,
          "control": 34,
          "movement": 43,
          "variation": 21,
          "stamina": 35,
          "catching": 42,
          "groundFielding": 39,
          "throwing": 51,
          "keeping": 34
        },
        "ODI": {
          "defence": 59,
          "timing": 61,
          "power": 51,
          "rotation": 69,
          "vsPace": 79,
          "vsSpin": 63,
          "control": 18,
          "movement": 28,
          "variation": 43,
          "stamina": 14,
          "catching": 63,
          "groundFielding": 59,
          "throwing": 63,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 83,
          "timing": 63,
          "power": 64,
          "rotation": 54,
          "vsPace": 60,
          "vsSpin": 62,
          "control": 23,
          "movement": 38,
          "variation": 21,
          "stamina": 27,
          "catching": 59,
          "groundFielding": 59,
          "throwing": 37,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        214,
        200,
        732,
        547,
        844,
        659,
        331,
        523
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p038",
      "name": "Nalo Rookfield",
      "birthDate": "1998-05-04",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 63,
          "power": 83,
          "rotation": 58,
          "vsPace": 68,
          "vsSpin": 74,
          "control": 38,
          "movement": 33,
          "variation": 14,
          "stamina": 26,
          "catching": 41,
          "groundFielding": 58,
          "throwing": 50,
          "keeping": 13
        },
        "ODI": {
          "defence": 70,
          "timing": 61,
          "power": 78,
          "rotation": 67,
          "vsPace": 76,
          "vsSpin": 73,
          "control": 18,
          "movement": 16,
          "variation": 20,
          "stamina": 21,
          "catching": 66,
          "groundFielding": 62,
          "throwing": 61,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 79,
          "timing": 70,
          "power": 72,
          "rotation": 65,
          "vsPace": 62,
          "vsSpin": 64,
          "control": 32,
          "movement": 17,
          "variation": 31,
          "stamina": 33,
          "catching": 50,
          "groundFielding": 62,
          "throwing": 42,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        896,
        650,
        511,
        581,
        589,
        936,
        411,
        727
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p039",
      "name": "Arven Rookridge",
      "birthDate": "2002-12-12",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 52,
          "power": 67,
          "rotation": 53,
          "vsPace": 58,
          "vsSpin": 55,
          "control": 39,
          "movement": 31,
          "variation": 23,
          "stamina": 33,
          "catching": 51,
          "groundFielding": 57,
          "throwing": 37,
          "keeping": 14
        },
        "ODI": {
          "defence": 66,
          "timing": 62,
          "power": 50,
          "rotation": 53,
          "vsPace": 78,
          "vsSpin": 67,
          "control": 29,
          "movement": 43,
          "variation": 32,
          "stamina": 34,
          "catching": 42,
          "groundFielding": 63,
          "throwing": 59,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 83,
          "timing": 60,
          "power": 68,
          "rotation": 56,
          "vsPace": 77,
          "vsSpin": 75,
          "control": 40,
          "movement": 42,
          "variation": 39,
          "stamina": 21,
          "catching": 40,
          "groundFielding": 44,
          "throwing": 53,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        834,
        749,
        746,
        898,
        334,
        726,
        623,
        341
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p040",
      "name": "Jora Ashholt",
      "birthDate": "1996-09-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 67,
          "power": 55,
          "rotation": 66,
          "vsPace": 58,
          "vsSpin": 62,
          "control": 27,
          "movement": 14,
          "variation": 41,
          "stamina": 21,
          "catching": 48,
          "groundFielding": 48,
          "throwing": 57,
          "keeping": 31
        },
        "ODI": {
          "defence": 62,
          "timing": 78,
          "power": 79,
          "rotation": 52,
          "vsPace": 66,
          "vsSpin": 75,
          "control": 42,
          "movement": 30,
          "variation": 20,
          "stamina": 25,
          "catching": 67,
          "groundFielding": 40,
          "throwing": 66,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 76,
          "power": 64,
          "rotation": 62,
          "vsPace": 58,
          "vsSpin": 57,
          "control": 43,
          "movement": 43,
          "variation": 28,
          "stamina": 42,
          "catching": 46,
          "groundFielding": 64,
          "throwing": 41,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        930,
        412,
        455,
        976,
        691,
        811,
        208,
        872
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p041",
      "name": "Nave Glenthorne",
      "birthDate": "1988-01-02",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 47,
          "timing": 42,
          "power": 51,
          "rotation": 60,
          "vsPace": 38,
          "vsSpin": 40,
          "control": 12,
          "movement": 39,
          "variation": 26,
          "stamina": 14,
          "catching": 57,
          "groundFielding": 48,
          "throwing": 49,
          "keeping": 60
        },
        "ODI": {
          "defence": 37,
          "timing": 47,
          "power": 49,
          "rotation": 43,
          "vsPace": 63,
          "vsSpin": 44,
          "control": 28,
          "movement": 32,
          "variation": 40,
          "stamina": 28,
          "catching": 69,
          "groundFielding": 54,
          "throwing": 55,
          "keeping": 82
        },
        "RED_BALL": {
          "defence": 60,
          "timing": 45,
          "power": 45,
          "rotation": 34,
          "vsPace": 58,
          "vsSpin": 62,
          "control": 12,
          "movement": 34,
          "variation": 13,
          "stamina": 12,
          "catching": 71,
          "groundFielding": 66,
          "throwing": 43,
          "keeping": 71
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        554,
        322,
        981,
        809,
        689,
        395,
        238,
        434
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p042",
      "name": "Nave Harridge",
      "birthDate": "2007-03-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 54,
          "power": 60,
          "rotation": 45,
          "vsPace": 62,
          "vsSpin": 54,
          "control": 32,
          "movement": 27,
          "variation": 32,
          "stamina": 37,
          "catching": 58,
          "groundFielding": 56,
          "throwing": 70,
          "keeping": 61
        },
        "ODI": {
          "defence": 38,
          "timing": 45,
          "power": 52,
          "rotation": 55,
          "vsPace": 49,
          "vsSpin": 51,
          "control": 23,
          "movement": 18,
          "variation": 35,
          "stamina": 38,
          "catching": 48,
          "groundFielding": 56,
          "throwing": 49,
          "keeping": 71
        },
        "RED_BALL": {
          "defence": 55,
          "timing": 36,
          "power": 51,
          "rotation": 49,
          "vsPace": 60,
          "vsSpin": 43,
          "control": 15,
          "movement": 39,
          "variation": 30,
          "stamina": 18,
          "catching": 67,
          "groundFielding": 48,
          "throwing": 44,
          "keeping": 86
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        467,
        662,
        323,
        598,
        678,
        252,
        722,
        607
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p043",
      "name": "Isen Harbrook",
      "birthDate": "1991-01-10",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 28,
          "timing": 49,
          "power": 51,
          "rotation": 39,
          "vsPace": 36,
          "vsSpin": 34,
          "control": 68,
          "movement": 63,
          "variation": 78,
          "stamina": 58,
          "catching": 57,
          "groundFielding": 44,
          "throwing": 45,
          "keeping": 26
        },
        "ODI": {
          "defence": 42,
          "timing": 21,
          "power": 24,
          "rotation": 45,
          "vsPace": 37,
          "vsSpin": 39,
          "control": 75,
          "movement": 58,
          "variation": 75,
          "stamina": 60,
          "catching": 65,
          "groundFielding": 55,
          "throwing": 68,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 35,
          "timing": 48,
          "power": 32,
          "rotation": 38,
          "vsPace": 35,
          "vsSpin": 19,
          "control": 58,
          "movement": 78,
          "variation": 66,
          "stamina": 50,
          "catching": 66,
          "groundFielding": 48,
          "throwing": 53,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        861,
        505,
        271,
        974,
        891,
        585,
        230,
        505
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p044",
      "name": "Ari Mossthorne",
      "birthDate": "1991-07-12",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 19,
          "power": 32,
          "rotation": 36,
          "vsPace": 48,
          "vsSpin": 35,
          "control": 53,
          "movement": 63,
          "variation": 67,
          "stamina": 64,
          "catching": 42,
          "groundFielding": 39,
          "throwing": 57,
          "keeping": 19
        },
        "ODI": {
          "defence": 49,
          "timing": 49,
          "power": 45,
          "rotation": 36,
          "vsPace": 20,
          "vsSpin": 49,
          "control": 77,
          "movement": 79,
          "variation": 59,
          "stamina": 76,
          "catching": 64,
          "groundFielding": 41,
          "throwing": 55,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 39,
          "timing": 44,
          "power": 35,
          "rotation": 45,
          "vsPace": 36,
          "vsSpin": 49,
          "control": 79,
          "movement": 51,
          "variation": 73,
          "stamina": 67,
          "catching": 40,
          "groundFielding": 51,
          "throwing": 48,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        302,
        488,
        563,
        996,
        469,
        245,
        404,
        226
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p045",
      "name": "Belan Falkholt",
      "birthDate": "2007-08-02",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 47,
          "power": 34,
          "rotation": 43,
          "vsPace": 26,
          "vsSpin": 41,
          "control": 71,
          "movement": 56,
          "variation": 59,
          "stamina": 73,
          "catching": 65,
          "groundFielding": 68,
          "throwing": 67,
          "keeping": 26
        },
        "ODI": {
          "defence": 48,
          "timing": 24,
          "power": 19,
          "rotation": 22,
          "vsPace": 29,
          "vsSpin": 43,
          "control": 60,
          "movement": 75,
          "variation": 67,
          "stamina": 72,
          "catching": 46,
          "groundFielding": 59,
          "throwing": 45,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 30,
          "timing": 38,
          "power": 36,
          "rotation": 26,
          "vsPace": 37,
          "vsSpin": 30,
          "control": 74,
          "movement": 54,
          "variation": 66,
          "stamina": 62,
          "catching": 40,
          "groundFielding": 40,
          "throwing": 44,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        774,
        414,
        657,
        220,
        485,
        974,
        483,
        405
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p046",
      "name": "Borin Jorbridge",
      "birthDate": "2006-04-20",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 27,
          "power": 33,
          "rotation": 20,
          "vsPace": 44,
          "vsSpin": 35,
          "control": 78,
          "movement": 67,
          "variation": 70,
          "stamina": 68,
          "catching": 66,
          "groundFielding": 59,
          "throwing": 39,
          "keeping": 26
        },
        "ODI": {
          "defence": 28,
          "timing": 25,
          "power": 34,
          "rotation": 24,
          "vsPace": 32,
          "vsSpin": 46,
          "control": 65,
          "movement": 76,
          "variation": 77,
          "stamina": 73,
          "catching": 44,
          "groundFielding": 49,
          "throwing": 60,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 42,
          "timing": 31,
          "power": 45,
          "rotation": 30,
          "vsPace": 43,
          "vsSpin": 41,
          "control": 77,
          "movement": 55,
          "variation": 55,
          "stamina": 74,
          "catching": 61,
          "groundFielding": 43,
          "throwing": 61,
          "keeping": 31
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        461,
        201,
        894,
        586,
        504,
        767,
        306,
        799
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p047",
      "name": "Eren Corwell",
      "birthDate": "1988-02-20",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 25,
          "timing": 37,
          "power": 51,
          "rotation": 40,
          "vsPace": 22,
          "vsSpin": 42,
          "control": 66,
          "movement": 73,
          "variation": 54,
          "stamina": 59,
          "catching": 57,
          "groundFielding": 49,
          "throwing": 64,
          "keeping": 16
        },
        "ODI": {
          "defence": 30,
          "timing": 25,
          "power": 25,
          "rotation": 46,
          "vsPace": 37,
          "vsSpin": 19,
          "control": 56,
          "movement": 67,
          "variation": 50,
          "stamina": 62,
          "catching": 60,
          "groundFielding": 40,
          "throwing": 45,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 35,
          "timing": 21,
          "power": 45,
          "rotation": 41,
          "vsPace": 33,
          "vsSpin": 46,
          "control": 50,
          "movement": 57,
          "variation": 73,
          "stamina": 68,
          "catching": 59,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        226,
        331,
        974,
        685,
        901,
        851,
        617,
        250
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p048",
      "name": "Galen Dunstone",
      "birthDate": "1996-03-09",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 30,
          "timing": 27,
          "power": 36,
          "rotation": 45,
          "vsPace": 20,
          "vsSpin": 22,
          "control": 51,
          "movement": 50,
          "variation": 55,
          "stamina": 57,
          "catching": 64,
          "groundFielding": 46,
          "throwing": 53,
          "keeping": 14
        },
        "ODI": {
          "defence": 34,
          "timing": 28,
          "power": 36,
          "rotation": 39,
          "vsPace": 41,
          "vsSpin": 42,
          "control": 76,
          "movement": 59,
          "variation": 78,
          "stamina": 68,
          "catching": 59,
          "groundFielding": 42,
          "throwing": 47,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 33,
          "timing": 23,
          "power": 17,
          "rotation": 23,
          "vsPace": 39,
          "vsSpin": 34,
          "control": 77,
          "movement": 75,
          "variation": 67,
          "stamina": 53,
          "catching": 64,
          "groundFielding": 52,
          "throwing": 44,
          "keeping": 16
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        571,
        939,
        491,
        529,
        224,
        842,
        965,
        567
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p049",
      "name": "Isen Harfield",
      "birthDate": "1997-11-23",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 62,
          "power": 55,
          "rotation": 43,
          "vsPace": 47,
          "vsSpin": 56,
          "control": 51,
          "movement": 60,
          "variation": 42,
          "stamina": 55,
          "catching": 54,
          "groundFielding": 55,
          "throwing": 44,
          "keeping": 38
        },
        "ODI": {
          "defence": 52,
          "timing": 42,
          "power": 39,
          "rotation": 48,
          "vsPace": 57,
          "vsSpin": 39,
          "control": 39,
          "movement": 61,
          "variation": 62,
          "stamina": 60,
          "catching": 65,
          "groundFielding": 45,
          "throwing": 56,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 60,
          "timing": 64,
          "power": 51,
          "rotation": 46,
          "vsPace": 47,
          "vsSpin": 65,
          "control": 52,
          "movement": 59,
          "variation": 50,
          "stamina": 50,
          "catching": 48,
          "groundFielding": 51,
          "throwing": 46,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        259,
        933,
        283,
        687,
        986,
        262,
        696,
        458
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p050",
      "name": "Deren Norbridge",
      "birthDate": "2002-10-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 53,
          "power": 60,
          "rotation": 51,
          "vsPace": 38,
          "vsSpin": 68,
          "control": 64,
          "movement": 38,
          "variation": 53,
          "stamina": 37,
          "catching": 70,
          "groundFielding": 45,
          "throwing": 50,
          "keeping": 37
        },
        "ODI": {
          "defence": 55,
          "timing": 58,
          "power": 50,
          "rotation": 42,
          "vsPace": 39,
          "vsSpin": 67,
          "control": 65,
          "movement": 60,
          "variation": 62,
          "stamina": 56,
          "catching": 66,
          "groundFielding": 66,
          "throwing": 64,
          "keeping": 30
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 44,
          "power": 58,
          "rotation": 61,
          "vsPace": 66,
          "vsSpin": 50,
          "control": 45,
          "movement": 64,
          "variation": 52,
          "stamina": 57,
          "catching": 66,
          "groundFielding": 64,
          "throwing": 60,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        369,
        933,
        321,
        900,
        474,
        819,
        831,
        971
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p051",
      "name": "Vero Mossridge",
      "birthDate": "2001-12-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 66,
          "power": 51,
          "rotation": 52,
          "vsPace": 47,
          "vsSpin": 41,
          "control": 43,
          "movement": 44,
          "variation": 39,
          "stamina": 40,
          "catching": 47,
          "groundFielding": 54,
          "throwing": 66,
          "keeping": 40
        },
        "ODI": {
          "defence": 43,
          "timing": 47,
          "power": 68,
          "rotation": 42,
          "vsPace": 59,
          "vsSpin": 46,
          "control": 55,
          "movement": 63,
          "variation": 38,
          "stamina": 48,
          "catching": 46,
          "groundFielding": 54,
          "throwing": 51,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 51,
          "power": 40,
          "rotation": 60,
          "vsPace": 46,
          "vsSpin": 67,
          "control": 54,
          "movement": 65,
          "variation": 58,
          "stamina": 58,
          "catching": 47,
          "groundFielding": 53,
          "throwing": 44,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        902,
        350,
        646,
        728,
        370,
        419,
        256,
        623
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p052",
      "name": "Leron Zornfell",
      "birthDate": "1995-01-23",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 73,
          "power": 84,
          "rotation": 72,
          "vsPace": 69,
          "vsSpin": 79,
          "control": 20,
          "movement": 31,
          "variation": 30,
          "stamina": 23,
          "catching": 65,
          "groundFielding": 61,
          "throwing": 41,
          "keeping": 15
        },
        "ODI": {
          "defence": 79,
          "timing": 57,
          "power": 62,
          "rotation": 75,
          "vsPace": 79,
          "vsSpin": 77,
          "control": 32,
          "movement": 35,
          "variation": 35,
          "stamina": 39,
          "catching": 50,
          "groundFielding": 40,
          "throwing": 62,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 52,
          "power": 50,
          "rotation": 76,
          "vsPace": 62,
          "vsSpin": 60,
          "control": 21,
          "movement": 31,
          "variation": 44,
          "stamina": 36,
          "catching": 60,
          "groundFielding": 64,
          "throwing": 41,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        985,
        472,
        867,
        797,
        859,
        932,
        300,
        671
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p053",
      "name": "Galen Valecombe",
      "birthDate": "1991-06-02",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 70,
          "power": 71,
          "rotation": 68,
          "vsPace": 65,
          "vsSpin": 71,
          "control": 34,
          "movement": 25,
          "variation": 26,
          "stamina": 39,
          "catching": 48,
          "groundFielding": 62,
          "throwing": 62,
          "keeping": 40
        },
        "ODI": {
          "defence": 75,
          "timing": 73,
          "power": 74,
          "rotation": 60,
          "vsPace": 65,
          "vsSpin": 77,
          "control": 14,
          "movement": 29,
          "variation": 35,
          "stamina": 41,
          "catching": 62,
          "groundFielding": 63,
          "throwing": 60,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 71,
          "power": 76,
          "rotation": 59,
          "vsPace": 51,
          "vsSpin": 50,
          "control": 26,
          "movement": 25,
          "variation": 15,
          "stamina": 17,
          "catching": 61,
          "groundFielding": 52,
          "throwing": 63,
          "keeping": 25
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        548,
        406,
        572,
        896,
        960,
        888,
        453,
        993
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p054",
      "name": "Jora Ternstone",
      "birthDate": "1996-01-23",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 72,
          "power": 55,
          "rotation": 72,
          "vsPace": 70,
          "vsSpin": 63,
          "control": 25,
          "movement": 35,
          "variation": 36,
          "stamina": 37,
          "catching": 64,
          "groundFielding": 63,
          "throwing": 62,
          "keeping": 30
        },
        "ODI": {
          "defence": 56,
          "timing": 70,
          "power": 53,
          "rotation": 75,
          "vsPace": 66,
          "vsSpin": 78,
          "control": 14,
          "movement": 36,
          "variation": 26,
          "stamina": 18,
          "catching": 41,
          "groundFielding": 38,
          "throwing": 59,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 85,
          "timing": 55,
          "power": 70,
          "rotation": 56,
          "vsPace": 51,
          "vsSpin": 51,
          "control": 27,
          "movement": 38,
          "variation": 22,
          "stamina": 21,
          "catching": 61,
          "groundFielding": 48,
          "throwing": 37,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        210,
        865,
        602,
        871,
        522,
        207,
        801,
        940
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p055",
      "name": "Fenn Iverthorne",
      "birthDate": "1993-05-03",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 72,
          "timing": 52,
          "power": 62,
          "rotation": 54,
          "vsPace": 79,
          "vsSpin": 71,
          "control": 33,
          "movement": 26,
          "variation": 42,
          "stamina": 38,
          "catching": 63,
          "groundFielding": 55,
          "throwing": 54,
          "keeping": 13
        },
        "ODI": {
          "defence": 63,
          "timing": 72,
          "power": 61,
          "rotation": 54,
          "vsPace": 53,
          "vsSpin": 52,
          "control": 19,
          "movement": 20,
          "variation": 15,
          "stamina": 15,
          "catching": 63,
          "groundFielding": 38,
          "throwing": 45,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 85,
          "timing": 56,
          "power": 56,
          "rotation": 79,
          "vsPace": 77,
          "vsSpin": 78,
          "control": 15,
          "movement": 33,
          "variation": 22,
          "stamina": 20,
          "catching": 45,
          "groundFielding": 38,
          "throwing": 42,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        877,
        672,
        503,
        606,
        984,
        625,
        959,
        266
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p056",
      "name": "Nalo Mossridge",
      "birthDate": "1999-12-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 75,
          "timing": 67,
          "power": 76,
          "rotation": 50,
          "vsPace": 72,
          "vsSpin": 79,
          "control": 33,
          "movement": 32,
          "variation": 25,
          "stamina": 25,
          "catching": 53,
          "groundFielding": 47,
          "throwing": 52,
          "keeping": 17
        },
        "ODI": {
          "defence": 73,
          "timing": 53,
          "power": 64,
          "rotation": 72,
          "vsPace": 57,
          "vsSpin": 53,
          "control": 29,
          "movement": 20,
          "variation": 22,
          "stamina": 30,
          "catching": 64,
          "groundFielding": 48,
          "throwing": 38,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 78,
          "power": 50,
          "rotation": 71,
          "vsPace": 76,
          "vsSpin": 54,
          "control": 32,
          "movement": 25,
          "variation": 19,
          "stamina": 43,
          "catching": 54,
          "groundFielding": 51,
          "throwing": 47,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        420,
        716,
        754,
        455,
        911,
        204,
        557,
        978
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p057",
      "name": "Ulen Iverwick",
      "birthDate": "1997-04-13",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 61,
          "power": 80,
          "rotation": 68,
          "vsPace": 71,
          "vsSpin": 75,
          "control": 15,
          "movement": 42,
          "variation": 30,
          "stamina": 41,
          "catching": 63,
          "groundFielding": 64,
          "throwing": 43,
          "keeping": 31
        },
        "ODI": {
          "defence": 74,
          "timing": 70,
          "power": 56,
          "rotation": 54,
          "vsPace": 51,
          "vsSpin": 79,
          "control": 24,
          "movement": 22,
          "variation": 37,
          "stamina": 23,
          "catching": 37,
          "groundFielding": 58,
          "throwing": 54,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 64,
          "power": 54,
          "rotation": 61,
          "vsPace": 65,
          "vsSpin": 51,
          "control": 26,
          "movement": 40,
          "variation": 17,
          "stamina": 25,
          "catching": 50,
          "groundFielding": 41,
          "throwing": 57,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        906,
        466,
        610,
        991,
        441,
        743,
        358,
        236
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p058",
      "name": "Halen Briarmere",
      "birthDate": "1995-01-05",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 66,
          "power": 77,
          "rotation": 73,
          "vsPace": 58,
          "vsSpin": 51,
          "control": 17,
          "movement": 21,
          "variation": 33,
          "stamina": 39,
          "catching": 64,
          "groundFielding": 40,
          "throwing": 38,
          "keeping": 36
        },
        "ODI": {
          "defence": 51,
          "timing": 80,
          "power": 63,
          "rotation": 53,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 18,
          "movement": 22,
          "variation": 21,
          "stamina": 29,
          "catching": 47,
          "groundFielding": 44,
          "throwing": 39,
          "keeping": 19
        },
        "RED_BALL": {
          "defence": 78,
          "timing": 77,
          "power": 63,
          "rotation": 75,
          "vsPace": 80,
          "vsSpin": 51,
          "control": 34,
          "movement": 29,
          "variation": 37,
          "stamina": 29,
          "catching": 38,
          "groundFielding": 46,
          "throwing": 57,
          "keeping": 32
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        681,
        756,
        973,
        589,
        574,
        521,
        390,
        269
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p059",
      "name": "Walen Sablecombe",
      "birthDate": "1994-09-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 51,
          "timing": 77,
          "power": 83,
          "rotation": 78,
          "vsPace": 77,
          "vsSpin": 57,
          "control": 32,
          "movement": 26,
          "variation": 37,
          "stamina": 24,
          "catching": 49,
          "groundFielding": 46,
          "throwing": 54,
          "keeping": 28
        },
        "ODI": {
          "defence": 72,
          "timing": 75,
          "power": 72,
          "rotation": 59,
          "vsPace": 69,
          "vsSpin": 54,
          "control": 38,
          "movement": 26,
          "variation": 38,
          "stamina": 19,
          "catching": 44,
          "groundFielding": 53,
          "throwing": 61,
          "keeping": 39
        },
        "RED_BALL": {
          "defence": 69,
          "timing": 55,
          "power": 61,
          "rotation": 60,
          "vsPace": 58,
          "vsSpin": 67,
          "control": 27,
          "movement": 41,
          "variation": 16,
          "stamina": 17,
          "catching": 45,
          "groundFielding": 51,
          "throwing": 54,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        828,
        229,
        562,
        337,
        391,
        316,
        398,
        315
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p060",
      "name": "Sela Mossford",
      "birthDate": "1998-12-16",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 75,
          "timing": 61,
          "power": 73,
          "rotation": 52,
          "vsPace": 57,
          "vsSpin": 63,
          "control": 31,
          "movement": 18,
          "variation": 22,
          "stamina": 15,
          "catching": 60,
          "groundFielding": 44,
          "throwing": 42,
          "keeping": 37
        },
        "ODI": {
          "defence": 50,
          "timing": 51,
          "power": 61,
          "rotation": 59,
          "vsPace": 55,
          "vsSpin": 71,
          "control": 42,
          "movement": 38,
          "variation": 34,
          "stamina": 44,
          "catching": 39,
          "groundFielding": 55,
          "throwing": 59,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 68,
          "timing": 73,
          "power": 63,
          "rotation": 74,
          "vsPace": 54,
          "vsSpin": 71,
          "control": 23,
          "movement": 30,
          "variation": 42,
          "stamina": 41,
          "catching": 64,
          "groundFielding": 53,
          "throwing": 61,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        670,
        375,
        899,
        406,
        877,
        435,
        790,
        223
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p061",
      "name": "Vero Wrenford",
      "birthDate": "1995-12-12",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 51,
          "timing": 53,
          "power": 65,
          "rotation": 53,
          "vsPace": 62,
          "vsSpin": 47,
          "control": 26,
          "movement": 23,
          "variation": 23,
          "stamina": 22,
          "catching": 62,
          "groundFielding": 60,
          "throwing": 67,
          "keeping": 80
        },
        "ODI": {
          "defence": 53,
          "timing": 39,
          "power": 55,
          "rotation": 42,
          "vsPace": 44,
          "vsSpin": 44,
          "control": 21,
          "movement": 13,
          "variation": 33,
          "stamina": 33,
          "catching": 71,
          "groundFielding": 49,
          "throwing": 60,
          "keeping": 59
        },
        "RED_BALL": {
          "defence": 54,
          "timing": 47,
          "power": 45,
          "rotation": 51,
          "vsPace": 52,
          "vsSpin": 38,
          "control": 18,
          "movement": 38,
          "variation": 12,
          "stamina": 28,
          "catching": 46,
          "groundFielding": 67,
          "throwing": 67,
          "keeping": 59
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        371,
        981,
        638,
        488,
        314,
        344,
        429,
        265
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p062",
      "name": "Kaelen Iverridge",
      "birthDate": "2007-07-02",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 53,
          "power": 61,
          "rotation": 63,
          "vsPace": 54,
          "vsSpin": 38,
          "control": 24,
          "movement": 20,
          "variation": 42,
          "stamina": 38,
          "catching": 65,
          "groundFielding": 47,
          "throwing": 48,
          "keeping": 72
        },
        "ODI": {
          "defence": 41,
          "timing": 50,
          "power": 37,
          "rotation": 58,
          "vsPace": 64,
          "vsSpin": 53,
          "control": 28,
          "movement": 31,
          "variation": 22,
          "stamina": 36,
          "catching": 56,
          "groundFielding": 71,
          "throwing": 49,
          "keeping": 76
        },
        "RED_BALL": {
          "defence": 39,
          "timing": 57,
          "power": 46,
          "rotation": 44,
          "vsPace": 43,
          "vsSpin": 60,
          "control": 37,
          "movement": 38,
          "variation": 20,
          "stamina": 32,
          "catching": 45,
          "groundFielding": 45,
          "throwing": 47,
          "keeping": 65
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        795,
        405,
        427,
        863,
        786,
        596,
        544,
        896
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p063",
      "name": "Vero Rookcombe",
      "birthDate": "2007-10-16",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 45,
          "power": 41,
          "rotation": 21,
          "vsPace": 45,
          "vsSpin": 33,
          "control": 67,
          "movement": 78,
          "variation": 64,
          "stamina": 80,
          "catching": 53,
          "groundFielding": 58,
          "throwing": 56,
          "keeping": 37
        },
        "ODI": {
          "defence": 40,
          "timing": 33,
          "power": 42,
          "rotation": 26,
          "vsPace": 48,
          "vsSpin": 20,
          "control": 76,
          "movement": 53,
          "variation": 57,
          "stamina": 72,
          "catching": 53,
          "groundFielding": 61,
          "throwing": 54,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 43,
          "power": 36,
          "rotation": 49,
          "vsPace": 49,
          "vsSpin": 27,
          "control": 62,
          "movement": 62,
          "variation": 66,
          "stamina": 70,
          "catching": 46,
          "groundFielding": 52,
          "throwing": 48,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        266,
        669,
        587,
        706,
        581,
        623,
        982,
        646
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p064",
      "name": "Talor Zornbrook",
      "birthDate": "1988-02-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 40,
          "power": 35,
          "rotation": 41,
          "vsPace": 35,
          "vsSpin": 24,
          "control": 56,
          "movement": 71,
          "variation": 77,
          "stamina": 67,
          "catching": 53,
          "groundFielding": 62,
          "throwing": 51,
          "keeping": 37
        },
        "ODI": {
          "defence": 32,
          "timing": 39,
          "power": 43,
          "rotation": 49,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 55,
          "movement": 74,
          "variation": 59,
          "stamina": 52,
          "catching": 41,
          "groundFielding": 46,
          "throwing": 68,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 22,
          "power": 44,
          "rotation": 39,
          "vsPace": 45,
          "vsSpin": 43,
          "control": 77,
          "movement": 57,
          "variation": 50,
          "stamina": 64,
          "catching": 65,
          "groundFielding": 66,
          "throwing": 47,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        594,
        235,
        994,
        438,
        965,
        915,
        510,
        668
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p065",
      "name": "Miran Ashford",
      "birthDate": "1998-08-04",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 19,
          "timing": 44,
          "power": 39,
          "rotation": 26,
          "vsPace": 46,
          "vsSpin": 26,
          "control": 71,
          "movement": 58,
          "variation": 68,
          "stamina": 78,
          "catching": 56,
          "groundFielding": 60,
          "throwing": 40,
          "keeping": 40
        },
        "ODI": {
          "defence": 45,
          "timing": 48,
          "power": 28,
          "rotation": 29,
          "vsPace": 45,
          "vsSpin": 21,
          "control": 79,
          "movement": 53,
          "variation": 74,
          "stamina": 67,
          "catching": 64,
          "groundFielding": 66,
          "throwing": 41,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 41,
          "timing": 22,
          "power": 37,
          "rotation": 22,
          "vsPace": 35,
          "vsSpin": 23,
          "control": 57,
          "movement": 73,
          "variation": 72,
          "stamina": 69,
          "catching": 55,
          "groundFielding": 42,
          "throwing": 59,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        458,
        404,
        543,
        534,
        606,
        925,
        259,
        838
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p066",
      "name": "Deren Kelwick",
      "birthDate": "2006-03-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 23,
          "power": 32,
          "rotation": 42,
          "vsPace": 30,
          "vsSpin": 27,
          "control": 54,
          "movement": 69,
          "variation": 67,
          "stamina": 70,
          "catching": 47,
          "groundFielding": 67,
          "throwing": 67,
          "keeping": 21
        },
        "ODI": {
          "defence": 22,
          "timing": 37,
          "power": 23,
          "rotation": 33,
          "vsPace": 21,
          "vsSpin": 51,
          "control": 55,
          "movement": 62,
          "variation": 53,
          "stamina": 52,
          "catching": 64,
          "groundFielding": 42,
          "throwing": 47,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 34,
          "timing": 40,
          "power": 38,
          "rotation": 27,
          "vsPace": 42,
          "vsSpin": 46,
          "control": 74,
          "movement": 78,
          "variation": 50,
          "stamina": 68,
          "catching": 65,
          "groundFielding": 56,
          "throwing": 41,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        974,
        595,
        981,
        599,
        699,
        634,
        494,
        745
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p067",
      "name": "Saren Elmstead",
      "birthDate": "1992-03-17",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 34,
          "timing": 41,
          "power": 41,
          "rotation": 46,
          "vsPace": 36,
          "vsSpin": 20,
          "control": 79,
          "movement": 61,
          "variation": 59,
          "stamina": 61,
          "catching": 63,
          "groundFielding": 55,
          "throwing": 66,
          "keeping": 29
        },
        "ODI": {
          "defence": 36,
          "timing": 21,
          "power": 35,
          "rotation": 49,
          "vsPace": 45,
          "vsSpin": 37,
          "control": 58,
          "movement": 69,
          "variation": 75,
          "stamina": 69,
          "catching": 67,
          "groundFielding": 41,
          "throwing": 46,
          "keeping": 41
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 39,
          "power": 35,
          "rotation": 29,
          "vsPace": 20,
          "vsSpin": 31,
          "control": 56,
          "movement": 68,
          "variation": 71,
          "stamina": 74,
          "catching": 53,
          "groundFielding": 55,
          "throwing": 46,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        406,
        721,
        505,
        304,
        766,
        827,
        835,
        643
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p068",
      "name": "Galen Pellthorne",
      "birthDate": "2002-05-01",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 22,
          "timing": 25,
          "power": 27,
          "rotation": 21,
          "vsPace": 19,
          "vsSpin": 26,
          "control": 71,
          "movement": 53,
          "variation": 69,
          "stamina": 59,
          "catching": 57,
          "groundFielding": 56,
          "throwing": 40,
          "keeping": 39
        },
        "ODI": {
          "defence": 41,
          "timing": 25,
          "power": 31,
          "rotation": 33,
          "vsPace": 38,
          "vsSpin": 48,
          "control": 74,
          "movement": 68,
          "variation": 79,
          "stamina": 75,
          "catching": 56,
          "groundFielding": 48,
          "throwing": 42,
          "keeping": 17
        },
        "RED_BALL": {
          "defence": 44,
          "timing": 25,
          "power": 46,
          "rotation": 29,
          "vsPace": 39,
          "vsSpin": 28,
          "control": 79,
          "movement": 56,
          "variation": 57,
          "stamina": 58,
          "catching": 64,
          "groundFielding": 61,
          "throwing": 59,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        983,
        685,
        772,
        337,
        674,
        819,
        297,
        499
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p069",
      "name": "Nerin Wrenstone",
      "birthDate": "2000-11-04",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 68,
          "power": 64,
          "rotation": 61,
          "vsPace": 38,
          "vsSpin": 50,
          "control": 37,
          "movement": 54,
          "variation": 38,
          "stamina": 46,
          "catching": 59,
          "groundFielding": 64,
          "throwing": 60,
          "keeping": 36
        },
        "ODI": {
          "defence": 56,
          "timing": 47,
          "power": 51,
          "rotation": 68,
          "vsPace": 65,
          "vsSpin": 40,
          "control": 67,
          "movement": 60,
          "variation": 60,
          "stamina": 65,
          "catching": 70,
          "groundFielding": 59,
          "throwing": 50,
          "keeping": 34
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 63,
          "power": 57,
          "rotation": 51,
          "vsPace": 55,
          "vsSpin": 43,
          "control": 64,
          "movement": 63,
          "variation": 62,
          "stamina": 63,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 52,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        311,
        258,
        414,
        904,
        662,
        231,
        496,
        665
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p070",
      "name": "Talor Pellfell",
      "birthDate": "1989-01-28",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 45,
          "timing": 59,
          "power": 47,
          "rotation": 60,
          "vsPace": 50,
          "vsSpin": 59,
          "control": 44,
          "movement": 62,
          "variation": 66,
          "stamina": 52,
          "catching": 69,
          "groundFielding": 43,
          "throwing": 61,
          "keeping": 16
        },
        "ODI": {
          "defence": 52,
          "timing": 68,
          "power": 47,
          "rotation": 39,
          "vsPace": 45,
          "vsSpin": 63,
          "control": 58,
          "movement": 53,
          "variation": 40,
          "stamina": 48,
          "catching": 70,
          "groundFielding": 54,
          "throwing": 53,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 73,
          "timing": 54,
          "power": 37,
          "rotation": 43,
          "vsPace": 52,
          "vsSpin": 59,
          "control": 37,
          "movement": 46,
          "variation": 47,
          "stamina": 42,
          "catching": 70,
          "groundFielding": 61,
          "throwing": 59,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        512,
        329,
        726,
        590,
        711,
        697,
        478,
        615
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p071",
      "name": "Ari Ashford",
      "birthDate": "1990-08-16",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 49,
          "power": 67,
          "rotation": 51,
          "vsPace": 62,
          "vsSpin": 61,
          "control": 37,
          "movement": 46,
          "variation": 48,
          "stamina": 58,
          "catching": 49,
          "groundFielding": 50,
          "throwing": 63,
          "keeping": 24
        },
        "ODI": {
          "defence": 56,
          "timing": 38,
          "power": 58,
          "rotation": 63,
          "vsPace": 47,
          "vsSpin": 58,
          "control": 49,
          "movement": 51,
          "variation": 67,
          "stamina": 48,
          "catching": 50,
          "groundFielding": 52,
          "throwing": 71,
          "keeping": 17
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 50,
          "power": 63,
          "rotation": 39,
          "vsPace": 63,
          "vsSpin": 58,
          "control": 60,
          "movement": 58,
          "variation": 43,
          "stamina": 46,
          "catching": 44,
          "groundFielding": 50,
          "throwing": 66,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        462,
        507,
        226,
        870,
        491,
        965,
        356,
        812
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p072",
      "name": "Caro Pellwick",
      "birthDate": "1997-11-21",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 64,
          "timing": 59,
          "power": 77,
          "rotation": 69,
          "vsPace": 60,
          "vsSpin": 55,
          "control": 44,
          "movement": 21,
          "variation": 30,
          "stamina": 28,
          "catching": 46,
          "groundFielding": 43,
          "throwing": 45,
          "keeping": 11
        },
        "ODI": {
          "defence": 68,
          "timing": 78,
          "power": 78,
          "rotation": 60,
          "vsPace": 69,
          "vsSpin": 54,
          "control": 40,
          "movement": 32,
          "variation": 24,
          "stamina": 20,
          "catching": 46,
          "groundFielding": 46,
          "throwing": 41,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 63,
          "power": 68,
          "rotation": 56,
          "vsPace": 63,
          "vsSpin": 74,
          "control": 25,
          "movement": 31,
          "variation": 41,
          "stamina": 19,
          "catching": 56,
          "groundFielding": 41,
          "throwing": 38,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        249,
        441,
        328,
        399,
        390,
        509,
        968,
        742
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p073",
      "name": "Galen Lornford",
      "birthDate": "2007-01-13",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 72,
          "timing": 56,
          "power": 71,
          "rotation": 73,
          "vsPace": 76,
          "vsSpin": 72,
          "control": 16,
          "movement": 25,
          "variation": 42,
          "stamina": 35,
          "catching": 39,
          "groundFielding": 38,
          "throwing": 52,
          "keeping": 37
        },
        "ODI": {
          "defence": 66,
          "timing": 53,
          "power": 67,
          "rotation": 55,
          "vsPace": 78,
          "vsSpin": 71,
          "control": 40,
          "movement": 30,
          "variation": 18,
          "stamina": 44,
          "catching": 43,
          "groundFielding": 43,
          "throwing": 61,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 65,
          "power": 76,
          "rotation": 52,
          "vsPace": 67,
          "vsSpin": 56,
          "control": 16,
          "movement": 38,
          "variation": 32,
          "stamina": 24,
          "catching": 37,
          "groundFielding": 66,
          "throwing": 48,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        284,
        506,
        652,
        805,
        305,
        993,
        333,
        368
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p074",
      "name": "Isen Sablefield",
      "birthDate": "1997-09-09",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 64,
          "power": 72,
          "rotation": 61,
          "vsPace": 72,
          "vsSpin": 60,
          "control": 21,
          "movement": 31,
          "variation": 39,
          "stamina": 33,
          "catching": 44,
          "groundFielding": 58,
          "throwing": 48,
          "keeping": 32
        },
        "ODI": {
          "defence": 51,
          "timing": 67,
          "power": 63,
          "rotation": 68,
          "vsPace": 69,
          "vsSpin": 52,
          "control": 42,
          "movement": 18,
          "variation": 17,
          "stamina": 22,
          "catching": 43,
          "groundFielding": 67,
          "throwing": 48,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 70,
          "power": 75,
          "rotation": 63,
          "vsPace": 56,
          "vsSpin": 50,
          "control": 19,
          "movement": 37,
          "variation": 24,
          "stamina": 43,
          "catching": 49,
          "groundFielding": 43,
          "throwing": 52,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        753,
        977,
        988,
        677,
        304,
        288,
        916,
        488
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p075",
      "name": "Yoran Pellbrook 15",
      "birthDate": "1994-11-24",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 73,
          "power": 59,
          "rotation": 57,
          "vsPace": 58,
          "vsSpin": 75,
          "control": 40,
          "movement": 17,
          "variation": 31,
          "stamina": 21,
          "catching": 50,
          "groundFielding": 62,
          "throwing": 57,
          "keeping": 20
        },
        "ODI": {
          "defence": 56,
          "timing": 70,
          "power": 68,
          "rotation": 61,
          "vsPace": 51,
          "vsSpin": 62,
          "control": 21,
          "movement": 19,
          "variation": 25,
          "stamina": 35,
          "catching": 40,
          "groundFielding": 45,
          "throwing": 53,
          "keeping": 41
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 50,
          "power": 70,
          "rotation": 70,
          "vsPace": 57,
          "vsSpin": 65,
          "control": 30,
          "movement": 16,
          "variation": 21,
          "stamina": 34,
          "catching": 67,
          "groundFielding": 65,
          "throwing": 39,
          "keeping": 16
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        220,
        817,
        910,
        584,
        429,
        541,
        263,
        319
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p076",
      "name": "Pavan Sableford",
      "birthDate": "1996-09-21",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 61,
          "power": 59,
          "rotation": 55,
          "vsPace": 64,
          "vsSpin": 64,
          "control": 33,
          "movement": 28,
          "variation": 42,
          "stamina": 14,
          "catching": 61,
          "groundFielding": 43,
          "throwing": 48,
          "keeping": 28
        },
        "ODI": {
          "defence": 69,
          "timing": 53,
          "power": 67,
          "rotation": 74,
          "vsPace": 54,
          "vsSpin": 54,
          "control": 38,
          "movement": 22,
          "variation": 27,
          "stamina": 20,
          "catching": 39,
          "groundFielding": 56,
          "throwing": 47,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 83,
          "timing": 52,
          "power": 60,
          "rotation": 51,
          "vsPace": 57,
          "vsSpin": 66,
          "control": 18,
          "movement": 39,
          "variation": 19,
          "stamina": 21,
          "catching": 49,
          "groundFielding": 67,
          "throwing": 53,
          "keeping": 30
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        474,
        282,
        203,
        857,
        595,
        507,
        245,
        548
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p077",
      "name": "Saren Briarstone",
      "birthDate": "2007-04-03",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 73,
          "power": 62,
          "rotation": 54,
          "vsPace": 71,
          "vsSpin": 69,
          "control": 32,
          "movement": 41,
          "variation": 42,
          "stamina": 32,
          "catching": 61,
          "groundFielding": 57,
          "throwing": 55,
          "keeping": 27
        },
        "ODI": {
          "defence": 60,
          "timing": 53,
          "power": 59,
          "rotation": 76,
          "vsPace": 80,
          "vsSpin": 74,
          "control": 44,
          "movement": 16,
          "variation": 43,
          "stamina": 24,
          "catching": 60,
          "groundFielding": 64,
          "throwing": 40,
          "keeping": 17
        },
        "RED_BALL": {
          "defence": 76,
          "timing": 72,
          "power": 51,
          "rotation": 52,
          "vsPace": 72,
          "vsSpin": 80,
          "control": 21,
          "movement": 36,
          "variation": 24,
          "stamina": 21,
          "catching": 67,
          "groundFielding": 46,
          "throwing": 45,
          "keeping": 13
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        966,
        686,
        370,
        626,
        443,
        253,
        963,
        426
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p078",
      "name": "Borin Kelholt",
      "birthDate": "1992-05-26",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 60,
          "timing": 63,
          "power": 54,
          "rotation": 75,
          "vsPace": 66,
          "vsSpin": 76,
          "control": 17,
          "movement": 19,
          "variation": 19,
          "stamina": 43,
          "catching": 63,
          "groundFielding": 53,
          "throwing": 42,
          "keeping": 14
        },
        "ODI": {
          "defence": 65,
          "timing": 69,
          "power": 69,
          "rotation": 71,
          "vsPace": 78,
          "vsSpin": 54,
          "control": 27,
          "movement": 39,
          "variation": 27,
          "stamina": 43,
          "catching": 39,
          "groundFielding": 45,
          "throwing": 46,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 59,
          "timing": 55,
          "power": 65,
          "rotation": 54,
          "vsPace": 52,
          "vsSpin": 66,
          "control": 17,
          "movement": 35,
          "variation": 27,
          "stamina": 22,
          "catching": 50,
          "groundFielding": 51,
          "throwing": 47,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        487,
        677,
        900,
        418,
        222,
        507,
        879,
        887
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p079",
      "name": "Rilan Iverbridge",
      "birthDate": "2007-05-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 58,
          "timing": 75,
          "power": 72,
          "rotation": 64,
          "vsPace": 59,
          "vsSpin": 60,
          "control": 41,
          "movement": 31,
          "variation": 31,
          "stamina": 33,
          "catching": 46,
          "groundFielding": 56,
          "throwing": 47,
          "keeping": 19
        },
        "ODI": {
          "defence": 70,
          "timing": 75,
          "power": 51,
          "rotation": 50,
          "vsPace": 57,
          "vsSpin": 75,
          "control": 39,
          "movement": 17,
          "variation": 28,
          "stamina": 32,
          "catching": 59,
          "groundFielding": 38,
          "throwing": 56,
          "keeping": 33
        },
        "RED_BALL": {
          "defence": 79,
          "timing": 57,
          "power": 54,
          "rotation": 63,
          "vsPace": 56,
          "vsSpin": 75,
          "control": 27,
          "movement": 43,
          "variation": 17,
          "stamina": 34,
          "catching": 49,
          "groundFielding": 48,
          "throwing": 45,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        608,
        223,
        973,
        216,
        304,
        949,
        257,
        544
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p080",
      "name": "Galen Ashcombe",
      "birthDate": "1991-09-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 70,
          "power": 77,
          "rotation": 80,
          "vsPace": 76,
          "vsSpin": 51,
          "control": 31,
          "movement": 27,
          "variation": 44,
          "stamina": 31,
          "catching": 59,
          "groundFielding": 52,
          "throwing": 44,
          "keeping": 39
        },
        "ODI": {
          "defence": 67,
          "timing": 55,
          "power": 75,
          "rotation": 64,
          "vsPace": 72,
          "vsSpin": 51,
          "control": 15,
          "movement": 16,
          "variation": 27,
          "stamina": 38,
          "catching": 59,
          "groundFielding": 63,
          "throwing": 38,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 69,
          "power": 57,
          "rotation": 80,
          "vsPace": 70,
          "vsSpin": 58,
          "control": 23,
          "movement": 38,
          "variation": 14,
          "stamina": 16,
          "catching": 41,
          "groundFielding": 46,
          "throwing": 37,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        252,
        830,
        574,
        985,
        267,
        995,
        394,
        371
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p081",
      "name": "Rilan Jorfield 1",
      "birthDate": "2005-10-18",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 48,
          "power": 59,
          "rotation": 38,
          "vsPace": 37,
          "vsSpin": 52,
          "control": 20,
          "movement": 12,
          "variation": 19,
          "stamina": 40,
          "catching": 61,
          "groundFielding": 43,
          "throwing": 50,
          "keeping": 62
        },
        "ODI": {
          "defence": 44,
          "timing": 43,
          "power": 37,
          "rotation": 36,
          "vsPace": 49,
          "vsSpin": 41,
          "control": 16,
          "movement": 42,
          "variation": 42,
          "stamina": 28,
          "catching": 70,
          "groundFielding": 57,
          "throwing": 59,
          "keeping": 62
        },
        "RED_BALL": {
          "defence": 62,
          "timing": 63,
          "power": 32,
          "rotation": 39,
          "vsPace": 55,
          "vsSpin": 35,
          "control": 14,
          "movement": 19,
          "variation": 41,
          "stamina": 19,
          "catching": 61,
          "groundFielding": 58,
          "throwing": 46,
          "keeping": 67
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        693,
        966,
        272,
        820,
        972,
        832,
        990,
        890
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p082",
      "name": "Fenn Quenbridge",
      "birthDate": "1992-09-16",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 38,
          "timing": 39,
          "power": 51,
          "rotation": 60,
          "vsPace": 35,
          "vsSpin": 37,
          "control": 31,
          "movement": 15,
          "variation": 40,
          "stamina": 27,
          "catching": 66,
          "groundFielding": 56,
          "throwing": 69,
          "keeping": 63
        },
        "ODI": {
          "defence": 60,
          "timing": 58,
          "power": 39,
          "rotation": 62,
          "vsPace": 40,
          "vsSpin": 56,
          "control": 40,
          "movement": 42,
          "variation": 18,
          "stamina": 25,
          "catching": 51,
          "groundFielding": 57,
          "throwing": 52,
          "keeping": 76
        },
        "RED_BALL": {
          "defence": 59,
          "timing": 51,
          "power": 31,
          "rotation": 43,
          "vsPace": 39,
          "vsSpin": 43,
          "control": 18,
          "movement": 41,
          "variation": 20,
          "stamina": 31,
          "catching": 53,
          "groundFielding": 68,
          "throwing": 48,
          "keeping": 63
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        700,
        527,
        702,
        320,
        843,
        322,
        308,
        496
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p083",
      "name": "Belan Sablestone",
      "birthDate": "1993-01-10",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 23,
          "timing": 29,
          "power": 34,
          "rotation": 22,
          "vsPace": 30,
          "vsSpin": 24,
          "control": 67,
          "movement": 77,
          "variation": 56,
          "stamina": 67,
          "catching": 43,
          "groundFielding": 56,
          "throwing": 54,
          "keeping": 28
        },
        "ODI": {
          "defence": 28,
          "timing": 34,
          "power": 21,
          "rotation": 40,
          "vsPace": 39,
          "vsSpin": 22,
          "control": 62,
          "movement": 59,
          "variation": 78,
          "stamina": 75,
          "catching": 46,
          "groundFielding": 52,
          "throwing": 49,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 51,
          "timing": 30,
          "power": 40,
          "rotation": 46,
          "vsPace": 28,
          "vsSpin": 31,
          "control": 77,
          "movement": 74,
          "variation": 56,
          "stamina": 77,
          "catching": 46,
          "groundFielding": 50,
          "throwing": 55,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        636,
        699,
        683,
        546,
        932,
        404,
        687,
        325
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p084",
      "name": "Deren Falkholt",
      "birthDate": "2005-01-24",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 24,
          "timing": 26,
          "power": 40,
          "rotation": 41,
          "vsPace": 25,
          "vsSpin": 45,
          "control": 72,
          "movement": 62,
          "variation": 63,
          "stamina": 67,
          "catching": 69,
          "groundFielding": 66,
          "throwing": 66,
          "keeping": 39
        },
        "ODI": {
          "defence": 40,
          "timing": 41,
          "power": 30,
          "rotation": 31,
          "vsPace": 32,
          "vsSpin": 46,
          "control": 54,
          "movement": 62,
          "variation": 55,
          "stamina": 73,
          "catching": 67,
          "groundFielding": 54,
          "throwing": 39,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 33,
          "power": 29,
          "rotation": 45,
          "vsPace": 44,
          "vsSpin": 22,
          "control": 51,
          "movement": 64,
          "variation": 69,
          "stamina": 72,
          "catching": 57,
          "groundFielding": 49,
          "throwing": 65,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        366,
        275,
        515,
        637,
        604,
        429,
        381,
        650
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p085",
      "name": "Oren Elmwell",
      "birthDate": "2007-01-07",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 34,
          "timing": 41,
          "power": 36,
          "rotation": 37,
          "vsPace": 40,
          "vsSpin": 31,
          "control": 74,
          "movement": 71,
          "variation": 64,
          "stamina": 52,
          "catching": 68,
          "groundFielding": 46,
          "throwing": 46,
          "keeping": 37
        },
        "ODI": {
          "defence": 30,
          "timing": 49,
          "power": 39,
          "rotation": 22,
          "vsPace": 41,
          "vsSpin": 33,
          "control": 79,
          "movement": 59,
          "variation": 61,
          "stamina": 57,
          "catching": 50,
          "groundFielding": 67,
          "throwing": 47,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 28,
          "timing": 28,
          "power": 45,
          "rotation": 48,
          "vsPace": 34,
          "vsSpin": 31,
          "control": 58,
          "movement": 57,
          "variation": 67,
          "stamina": 77,
          "catching": 53,
          "groundFielding": 62,
          "throwing": 42,
          "keeping": 12
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        805,
        520,
        568,
        739,
        572,
        870,
        421,
        649
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p086",
      "name": "Nalo Zornfell",
      "birthDate": "2001-02-03",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 40,
          "timing": 47,
          "power": 53,
          "rotation": 28,
          "vsPace": 36,
          "vsSpin": 48,
          "control": 72,
          "movement": 68,
          "variation": 78,
          "stamina": 51,
          "catching": 45,
          "groundFielding": 50,
          "throwing": 51,
          "keeping": 22
        },
        "ODI": {
          "defence": 35,
          "timing": 45,
          "power": 49,
          "rotation": 20,
          "vsPace": 41,
          "vsSpin": 49,
          "control": 67,
          "movement": 79,
          "variation": 68,
          "stamina": 66,
          "catching": 61,
          "groundFielding": 66,
          "throwing": 60,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 23,
          "power": 43,
          "rotation": 47,
          "vsPace": 23,
          "vsSpin": 32,
          "control": 65,
          "movement": 63,
          "variation": 51,
          "stamina": 71,
          "catching": 62,
          "groundFielding": 65,
          "throwing": 46,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        367,
        952,
        234,
        774,
        996,
        934,
        265,
        805
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p087",
      "name": "Nalo Rookstead",
      "birthDate": "1991-09-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 32,
          "power": 43,
          "rotation": 39,
          "vsPace": 47,
          "vsSpin": 49,
          "control": 51,
          "movement": 64,
          "variation": 54,
          "stamina": 53,
          "catching": 67,
          "groundFielding": 41,
          "throwing": 51,
          "keeping": 32
        },
        "ODI": {
          "defence": 43,
          "timing": 46,
          "power": 23,
          "rotation": 35,
          "vsPace": 26,
          "vsSpin": 38,
          "control": 62,
          "movement": 54,
          "variation": 58,
          "stamina": 60,
          "catching": 58,
          "groundFielding": 39,
          "throwing": 39,
          "keeping": 19
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 30,
          "power": 45,
          "rotation": 21,
          "vsPace": 29,
          "vsSpin": 43,
          "control": 52,
          "movement": 74,
          "variation": 57,
          "stamina": 73,
          "catching": 50,
          "groundFielding": 42,
          "throwing": 63,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        781,
        457,
        433,
        387,
        473,
        645,
        245,
        716
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p088",
      "name": "Belan Briarstead",
      "birthDate": "1993-07-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 49,
          "timing": 35,
          "power": 49,
          "rotation": 35,
          "vsPace": 42,
          "vsSpin": 40,
          "control": 79,
          "movement": 56,
          "variation": 62,
          "stamina": 72,
          "catching": 53,
          "groundFielding": 60,
          "throwing": 58,
          "keeping": 29
        },
        "ODI": {
          "defence": 37,
          "timing": 33,
          "power": 26,
          "rotation": 47,
          "vsPace": 46,
          "vsSpin": 35,
          "control": 64,
          "movement": 52,
          "variation": 60,
          "stamina": 53,
          "catching": 51,
          "groundFielding": 46,
          "throwing": 48,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 33,
          "timing": 24,
          "power": 43,
          "rotation": 30,
          "vsPace": 38,
          "vsSpin": 37,
          "control": 55,
          "movement": 55,
          "variation": 65,
          "stamina": 56,
          "catching": 43,
          "groundFielding": 59,
          "throwing": 52,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        512,
        538,
        669,
        697,
        635,
        741,
        656,
        313
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p089",
      "name": "Ari Zornstead",
      "birthDate": "1997-09-12",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "FAST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 63,
          "power": 66,
          "rotation": 51,
          "vsPace": 54,
          "vsSpin": 50,
          "control": 46,
          "movement": 56,
          "variation": 65,
          "stamina": 55,
          "catching": 47,
          "groundFielding": 62,
          "throwing": 53,
          "keeping": 12
        },
        "ODI": {
          "defence": 41,
          "timing": 43,
          "power": 49,
          "rotation": 51,
          "vsPace": 63,
          "vsSpin": 63,
          "control": 41,
          "movement": 44,
          "variation": 39,
          "stamina": 66,
          "catching": 42,
          "groundFielding": 60,
          "throwing": 54,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 48,
          "timing": 68,
          "power": 64,
          "rotation": 41,
          "vsPace": 41,
          "vsSpin": 65,
          "control": 53,
          "movement": 58,
          "variation": 57,
          "stamina": 65,
          "catching": 56,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        992,
        249,
        689,
        675,
        942,
        205,
        830,
        984
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p090",
      "name": "Kaelen Quenthorne",
      "birthDate": "2007-06-24",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 59,
          "power": 69,
          "rotation": 55,
          "vsPace": 39,
          "vsSpin": 47,
          "control": 50,
          "movement": 57,
          "variation": 57,
          "stamina": 52,
          "catching": 60,
          "groundFielding": 57,
          "throwing": 72,
          "keeping": 11
        },
        "ODI": {
          "defence": 58,
          "timing": 40,
          "power": 59,
          "rotation": 55,
          "vsPace": 48,
          "vsSpin": 60,
          "control": 45,
          "movement": 52,
          "variation": 63,
          "stamina": 61,
          "catching": 52,
          "groundFielding": 61,
          "throwing": 62,
          "keeping": 34
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 54,
          "power": 39,
          "rotation": 57,
          "vsPace": 62,
          "vsSpin": 55,
          "control": 52,
          "movement": 48,
          "variation": 63,
          "stamina": 39,
          "catching": 43,
          "groundFielding": 55,
          "throwing": 66,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        762,
        675,
        915,
        758,
        723,
        372,
        280,
        570
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p091",
      "name": "Leron Ashcroft",
      "birthDate": "1999-04-20",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 38,
          "power": 49,
          "rotation": 66,
          "vsPace": 38,
          "vsSpin": 54,
          "control": 56,
          "movement": 55,
          "variation": 48,
          "stamina": 54,
          "catching": 59,
          "groundFielding": 42,
          "throwing": 42,
          "keeping": 25
        },
        "ODI": {
          "defence": 57,
          "timing": 48,
          "power": 51,
          "rotation": 53,
          "vsPace": 60,
          "vsSpin": 67,
          "control": 67,
          "movement": 39,
          "variation": 56,
          "stamina": 39,
          "catching": 54,
          "groundFielding": 64,
          "throwing": 48,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 57,
          "timing": 56,
          "power": 51,
          "rotation": 65,
          "vsPace": 39,
          "vsSpin": 58,
          "control": 60,
          "movement": 64,
          "variation": 48,
          "stamina": 38,
          "catching": 65,
          "groundFielding": 43,
          "throwing": 60,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        512,
        970,
        378,
        262,
        892,
        763,
        288,
        657
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p092",
      "name": "Kaelen Norden",
      "birthDate": "1990-06-06",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 65,
          "timing": 63,
          "power": 72,
          "rotation": 63,
          "vsPace": 58,
          "vsSpin": 50,
          "control": 21,
          "movement": 18,
          "variation": 24,
          "stamina": 24,
          "catching": 43,
          "groundFielding": 60,
          "throwing": 55,
          "keeping": 25
        },
        "ODI": {
          "defence": 68,
          "timing": 71,
          "power": 77,
          "rotation": 79,
          "vsPace": 73,
          "vsSpin": 61,
          "control": 39,
          "movement": 23,
          "variation": 27,
          "stamina": 32,
          "catching": 50,
          "groundFielding": 67,
          "throwing": 56,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 84,
          "timing": 54,
          "power": 73,
          "rotation": 52,
          "vsPace": 80,
          "vsSpin": 60,
          "control": 37,
          "movement": 35,
          "variation": 42,
          "stamina": 41,
          "catching": 41,
          "groundFielding": 62,
          "throwing": 65,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        749,
        462,
        236,
        845,
        885,
        256,
        793,
        713
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p093",
      "name": "Eren Falkfield",
      "birthDate": "2003-04-11",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 80,
          "timing": 77,
          "power": 56,
          "rotation": 69,
          "vsPace": 67,
          "vsSpin": 78,
          "control": 40,
          "movement": 27,
          "variation": 36,
          "stamina": 22,
          "catching": 38,
          "groundFielding": 62,
          "throwing": 46,
          "keeping": 35
        },
        "ODI": {
          "defence": 74,
          "timing": 60,
          "power": 58,
          "rotation": 63,
          "vsPace": 59,
          "vsSpin": 57,
          "control": 14,
          "movement": 21,
          "variation": 31,
          "stamina": 24,
          "catching": 59,
          "groundFielding": 54,
          "throwing": 62,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 75,
          "power": 48,
          "rotation": 68,
          "vsPace": 78,
          "vsSpin": 57,
          "control": 33,
          "movement": 26,
          "variation": 20,
          "stamina": 21,
          "catching": 41,
          "groundFielding": 57,
          "throwing": 62,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        683,
        271,
        412,
        334,
        822,
        353,
        718,
        316
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p094",
      "name": "Galen Yewfell",
      "birthDate": "2007-01-25",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 61,
          "timing": 70,
          "power": 69,
          "rotation": 62,
          "vsPace": 57,
          "vsSpin": 65,
          "control": 27,
          "movement": 19,
          "variation": 44,
          "stamina": 30,
          "catching": 57,
          "groundFielding": 53,
          "throwing": 53,
          "keeping": 26
        },
        "ODI": {
          "defence": 80,
          "timing": 76,
          "power": 75,
          "rotation": 63,
          "vsPace": 67,
          "vsSpin": 71,
          "control": 35,
          "movement": 36,
          "variation": 21,
          "stamina": 34,
          "catching": 47,
          "groundFielding": 48,
          "throwing": 44,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 74,
          "power": 70,
          "rotation": 78,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 35,
          "movement": 32,
          "variation": 34,
          "stamina": 27,
          "catching": 57,
          "groundFielding": 65,
          "throwing": 54,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        818,
        846,
        709,
        603,
        275,
        679,
        496,
        911
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p095",
      "name": "Miran Mosscroft",
      "birthDate": "2005-11-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 57,
          "power": 82,
          "rotation": 64,
          "vsPace": 69,
          "vsSpin": 78,
          "control": 23,
          "movement": 29,
          "variation": 22,
          "stamina": 33,
          "catching": 61,
          "groundFielding": 48,
          "throwing": 56,
          "keeping": 29
        },
        "ODI": {
          "defence": 63,
          "timing": 79,
          "power": 68,
          "rotation": 56,
          "vsPace": 78,
          "vsSpin": 65,
          "control": 24,
          "movement": 22,
          "variation": 37,
          "stamina": 22,
          "catching": 42,
          "groundFielding": 57,
          "throwing": 53,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 65,
          "timing": 58,
          "power": 72,
          "rotation": 53,
          "vsPace": 53,
          "vsSpin": 65,
          "control": 31,
          "movement": 23,
          "variation": 17,
          "stamina": 40,
          "catching": 39,
          "groundFielding": 51,
          "throwing": 38,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        876,
        822,
        379,
        875,
        305,
        352,
        616,
        890
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p096",
      "name": "Kaelen Pellcroft",
      "birthDate": "1998-05-13",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 68,
          "timing": 61,
          "power": 82,
          "rotation": 74,
          "vsPace": 73,
          "vsSpin": 59,
          "control": 24,
          "movement": 36,
          "variation": 35,
          "stamina": 28,
          "catching": 53,
          "groundFielding": 66,
          "throwing": 61,
          "keeping": 33
        },
        "ODI": {
          "defence": 56,
          "timing": 65,
          "power": 76,
          "rotation": 76,
          "vsPace": 51,
          "vsSpin": 55,
          "control": 16,
          "movement": 22,
          "variation": 33,
          "stamina": 36,
          "catching": 62,
          "groundFielding": 40,
          "throwing": 64,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 66,
          "timing": 58,
          "power": 63,
          "rotation": 68,
          "vsPace": 76,
          "vsSpin": 70,
          "control": 24,
          "movement": 28,
          "variation": 29,
          "stamina": 34,
          "catching": 49,
          "groundFielding": 58,
          "throwing": 67,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        690,
        360,
        957,
        592,
        239,
        721,
        208,
        431
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p097",
      "name": "Jora Orinstead",
      "birthDate": "2005-09-09",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 63,
          "timing": 64,
          "power": 77,
          "rotation": 55,
          "vsPace": 74,
          "vsSpin": 78,
          "control": 35,
          "movement": 21,
          "variation": 40,
          "stamina": 40,
          "catching": 60,
          "groundFielding": 66,
          "throwing": 55,
          "keeping": 38
        },
        "ODI": {
          "defence": 56,
          "timing": 57,
          "power": 53,
          "rotation": 73,
          "vsPace": 71,
          "vsSpin": 69,
          "control": 27,
          "movement": 18,
          "variation": 39,
          "stamina": 39,
          "catching": 55,
          "groundFielding": 56,
          "throwing": 42,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 60,
          "power": 73,
          "rotation": 52,
          "vsPace": 58,
          "vsSpin": 62,
          "control": 20,
          "movement": 36,
          "variation": 15,
          "stamina": 21,
          "catching": 44,
          "groundFielding": 41,
          "throwing": 65,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        213,
        408,
        467,
        537,
        464,
        282,
        634,
        886
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p098",
      "name": "Sela Iverwick",
      "birthDate": "1992-08-14",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 74,
          "power": 54,
          "rotation": 73,
          "vsPace": 68,
          "vsSpin": 77,
          "control": 14,
          "movement": 22,
          "variation": 44,
          "stamina": 26,
          "catching": 50,
          "groundFielding": 47,
          "throwing": 66,
          "keeping": 31
        },
        "ODI": {
          "defence": 63,
          "timing": 76,
          "power": 58,
          "rotation": 63,
          "vsPace": 53,
          "vsSpin": 52,
          "control": 35,
          "movement": 19,
          "variation": 16,
          "stamina": 17,
          "catching": 49,
          "groundFielding": 61,
          "throwing": 58,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 74,
          "timing": 68,
          "power": 48,
          "rotation": 79,
          "vsPace": 76,
          "vsSpin": 54,
          "control": 24,
          "movement": 44,
          "variation": 33,
          "stamina": 35,
          "catching": 47,
          "groundFielding": 40,
          "throwing": 58,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        773,
        492,
        637,
        590,
        524,
        460,
        823,
        857
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p099",
      "name": "Zerin Sablestone",
      "birthDate": "2007-08-17",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 63,
          "timing": 51,
          "power": 80,
          "rotation": 62,
          "vsPace": 66,
          "vsSpin": 76,
          "control": 25,
          "movement": 41,
          "variation": 43,
          "stamina": 30,
          "catching": 48,
          "groundFielding": 67,
          "throwing": 67,
          "keeping": 31
        },
        "ODI": {
          "defence": 63,
          "timing": 69,
          "power": 76,
          "rotation": 77,
          "vsPace": 59,
          "vsSpin": 69,
          "control": 15,
          "movement": 19,
          "variation": 20,
          "stamina": 28,
          "catching": 59,
          "groundFielding": 40,
          "throwing": 44,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 77,
          "power": 48,
          "rotation": 50,
          "vsPace": 67,
          "vsSpin": 75,
          "control": 37,
          "movement": 18,
          "variation": 40,
          "stamina": 27,
          "catching": 67,
          "groundFielding": 38,
          "throwing": 43,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        845,
        992,
        983,
        206,
        503,
        659,
        699,
        707
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p100",
      "name": "Fenn Terncombe",
      "birthDate": "2002-08-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 70,
          "timing": 63,
          "power": 80,
          "rotation": 72,
          "vsPace": 66,
          "vsSpin": 73,
          "control": 42,
          "movement": 28,
          "variation": 25,
          "stamina": 44,
          "catching": 64,
          "groundFielding": 57,
          "throwing": 39,
          "keeping": 21
        },
        "ODI": {
          "defence": 54,
          "timing": 77,
          "power": 80,
          "rotation": 58,
          "vsPace": 59,
          "vsSpin": 80,
          "control": 43,
          "movement": 19,
          "variation": 34,
          "stamina": 19,
          "catching": 59,
          "groundFielding": 53,
          "throwing": 37,
          "keeping": 27
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 70,
          "power": 67,
          "rotation": 53,
          "vsPace": 73,
          "vsSpin": 56,
          "control": 34,
          "movement": 36,
          "variation": 37,
          "stamina": 30,
          "catching": 41,
          "groundFielding": 59,
          "throwing": 53,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        710,
        482,
        639,
        749,
        530,
        928,
        474,
        647
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p101",
      "name": "Eren Briarridge",
      "birthDate": "2005-02-14",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 54,
          "timing": 47,
          "power": 54,
          "rotation": 60,
          "vsPace": 49,
          "vsSpin": 45,
          "control": 30,
          "movement": 20,
          "variation": 18,
          "stamina": 21,
          "catching": 41,
          "groundFielding": 46,
          "throwing": 65,
          "keeping": 68
        },
        "ODI": {
          "defence": 51,
          "timing": 60,
          "power": 50,
          "rotation": 56,
          "vsPace": 50,
          "vsSpin": 35,
          "control": 32,
          "movement": 16,
          "variation": 33,
          "stamina": 26,
          "catching": 47,
          "groundFielding": 46,
          "throwing": 63,
          "keeping": 74
        },
        "RED_BALL": {
          "defence": 48,
          "timing": 36,
          "power": 49,
          "rotation": 51,
          "vsPace": 52,
          "vsSpin": 43,
          "control": 35,
          "movement": 19,
          "variation": 17,
          "stamina": 13,
          "catching": 49,
          "groundFielding": 63,
          "throwing": 48,
          "keeping": 69
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        238,
        504,
        324,
        935,
        256,
        871,
        597,
        419
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p102",
      "name": "Nerin Harridge",
      "birthDate": "2007-09-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 38,
          "power": 53,
          "rotation": 42,
          "vsPace": 48,
          "vsSpin": 51,
          "control": 13,
          "movement": 24,
          "variation": 31,
          "stamina": 39,
          "catching": 55,
          "groundFielding": 61,
          "throwing": 46,
          "keeping": 77
        },
        "ODI": {
          "defence": 50,
          "timing": 49,
          "power": 59,
          "rotation": 52,
          "vsPace": 39,
          "vsSpin": 60,
          "control": 19,
          "movement": 29,
          "variation": 28,
          "stamina": 14,
          "catching": 70,
          "groundFielding": 70,
          "throwing": 57,
          "keeping": 61
        },
        "RED_BALL": {
          "defence": 49,
          "timing": 49,
          "power": 37,
          "rotation": 54,
          "vsPace": 60,
          "vsSpin": 38,
          "control": 38,
          "movement": 42,
          "variation": 14,
          "stamina": 27,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 52,
          "keeping": 63
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        271,
        223,
        930,
        377,
        298,
        674,
        440,
        757
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p103",
      "name": "Galen Briarcombe",
      "birthDate": "2001-09-24",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 37,
          "timing": 23,
          "power": 44,
          "rotation": 33,
          "vsPace": 35,
          "vsSpin": 24,
          "control": 61,
          "movement": 56,
          "variation": 65,
          "stamina": 52,
          "catching": 69,
          "groundFielding": 58,
          "throwing": 61,
          "keeping": 34
        },
        "ODI": {
          "defence": 27,
          "timing": 48,
          "power": 22,
          "rotation": 22,
          "vsPace": 29,
          "vsSpin": 24,
          "control": 61,
          "movement": 61,
          "variation": 76,
          "stamina": 71,
          "catching": 56,
          "groundFielding": 59,
          "throwing": 49,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 39,
          "timing": 35,
          "power": 23,
          "rotation": 20,
          "vsPace": 26,
          "vsSpin": 30,
          "control": 77,
          "movement": 55,
          "variation": 72,
          "stamina": 58,
          "catching": 60,
          "groundFielding": 45,
          "throwing": 42,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        290,
        448,
        335,
        206,
        964,
        566,
        323,
        698
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p104",
      "name": "Arven Terncroft",
      "birthDate": "1992-09-04",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 37,
          "power": 25,
          "rotation": 22,
          "vsPace": 41,
          "vsSpin": 21,
          "control": 65,
          "movement": 78,
          "variation": 53,
          "stamina": 66,
          "catching": 58,
          "groundFielding": 50,
          "throwing": 40,
          "keeping": 40
        },
        "ODI": {
          "defence": 19,
          "timing": 25,
          "power": 40,
          "rotation": 25,
          "vsPace": 49,
          "vsSpin": 43,
          "control": 61,
          "movement": 67,
          "variation": 54,
          "stamina": 63,
          "catching": 44,
          "groundFielding": 63,
          "throwing": 57,
          "keeping": 18
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 49,
          "power": 28,
          "rotation": 22,
          "vsPace": 31,
          "vsSpin": 24,
          "control": 54,
          "movement": 53,
          "variation": 77,
          "stamina": 51,
          "catching": 68,
          "groundFielding": 45,
          "throwing": 66,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        633,
        226,
        543,
        739,
        927,
        325,
        434,
        642
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p105",
      "name": "Nerin Jorwick",
      "birthDate": "1994-10-17",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 22,
          "timing": 47,
          "power": 28,
          "rotation": 44,
          "vsPace": 37,
          "vsSpin": 37,
          "control": 69,
          "movement": 77,
          "variation": 61,
          "stamina": 56,
          "catching": 47,
          "groundFielding": 64,
          "throwing": 46,
          "keeping": 30
        },
        "ODI": {
          "defence": 43,
          "timing": 45,
          "power": 23,
          "rotation": 47,
          "vsPace": 43,
          "vsSpin": 47,
          "control": 76,
          "movement": 54,
          "variation": 55,
          "stamina": 69,
          "catching": 47,
          "groundFielding": 40,
          "throwing": 50,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 37,
          "timing": 30,
          "power": 27,
          "rotation": 25,
          "vsPace": 25,
          "vsSpin": 22,
          "control": 59,
          "movement": 69,
          "variation": 54,
          "stamina": 70,
          "catching": 63,
          "groundFielding": 61,
          "throwing": 61,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        633,
        714,
        491,
        836,
        838,
        601,
        767,
        692
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p106",
      "name": "Elio Rookmere",
      "birthDate": "1990-12-18",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 34,
          "timing": 25,
          "power": 45,
          "rotation": 24,
          "vsPace": 21,
          "vsSpin": 35,
          "control": 66,
          "movement": 56,
          "variation": 70,
          "stamina": 72,
          "catching": 47,
          "groundFielding": 52,
          "throwing": 64,
          "keeping": 40
        },
        "ODI": {
          "defence": 44,
          "timing": 42,
          "power": 37,
          "rotation": 26,
          "vsPace": 39,
          "vsSpin": 25,
          "control": 77,
          "movement": 70,
          "variation": 65,
          "stamina": 76,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 49,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 51,
          "timing": 33,
          "power": 38,
          "rotation": 47,
          "vsPace": 43,
          "vsSpin": 51,
          "control": 50,
          "movement": 61,
          "variation": 62,
          "stamina": 77,
          "catching": 57,
          "groundFielding": 65,
          "throwing": 45,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        245,
        755,
        575,
        424,
        755,
        839,
        280,
        259
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p107",
      "name": "Walen Glenmere",
      "birthDate": "1989-06-11",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 49,
          "timing": 42,
          "power": 31,
          "rotation": 46,
          "vsPace": 39,
          "vsSpin": 43,
          "control": 58,
          "movement": 63,
          "variation": 69,
          "stamina": 74,
          "catching": 57,
          "groundFielding": 42,
          "throwing": 41,
          "keeping": 23
        },
        "ODI": {
          "defence": 42,
          "timing": 22,
          "power": 33,
          "rotation": 28,
          "vsPace": 44,
          "vsSpin": 42,
          "control": 58,
          "movement": 58,
          "variation": 68,
          "stamina": 62,
          "catching": 65,
          "groundFielding": 49,
          "throwing": 47,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 48,
          "power": 17,
          "rotation": 30,
          "vsPace": 19,
          "vsSpin": 33,
          "control": 56,
          "movement": 52,
          "variation": 60,
          "stamina": 77,
          "catching": 58,
          "groundFielding": 68,
          "throwing": 50,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        620,
        798,
        355,
        506,
        651,
        582,
        438,
        323
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p108",
      "name": "Isen Jorden",
      "birthDate": "1996-07-11",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 48,
          "timing": 27,
          "power": 32,
          "rotation": 49,
          "vsPace": 26,
          "vsSpin": 32,
          "control": 50,
          "movement": 62,
          "variation": 54,
          "stamina": 62,
          "catching": 50,
          "groundFielding": 56,
          "throwing": 57,
          "keeping": 31
        },
        "ODI": {
          "defence": 45,
          "timing": 40,
          "power": 40,
          "rotation": 30,
          "vsPace": 42,
          "vsSpin": 21,
          "control": 65,
          "movement": 60,
          "variation": 60,
          "stamina": 62,
          "catching": 65,
          "groundFielding": 57,
          "throwing": 62,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 32,
          "timing": 37,
          "power": 46,
          "rotation": 30,
          "vsPace": 40,
          "vsSpin": 47,
          "control": 71,
          "movement": 60,
          "variation": 59,
          "stamina": 64,
          "catching": 54,
          "groundFielding": 62,
          "throwing": 46,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        709,
        759,
        438,
        577,
        847,
        335,
        228,
        860
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p109",
      "name": "Arven Lornford",
      "birthDate": "2005-12-03",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "MEDIUM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 68,
          "power": 54,
          "rotation": 43,
          "vsPace": 51,
          "vsSpin": 65,
          "control": 62,
          "movement": 55,
          "variation": 52,
          "stamina": 63,
          "catching": 46,
          "groundFielding": 61,
          "throwing": 66,
          "keeping": 31
        },
        "ODI": {
          "defence": 54,
          "timing": 63,
          "power": 40,
          "rotation": 45,
          "vsPace": 62,
          "vsSpin": 40,
          "control": 40,
          "movement": 39,
          "variation": 43,
          "stamina": 47,
          "catching": 47,
          "groundFielding": 51,
          "throwing": 50,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 69,
          "timing": 45,
          "power": 45,
          "rotation": 55,
          "vsPace": 39,
          "vsSpin": 48,
          "control": 53,
          "movement": 38,
          "variation": 59,
          "stamina": 59,
          "catching": 45,
          "groundFielding": 70,
          "throwing": 69,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        863,
        784,
        391,
        964,
        521,
        604,
        457,
        926
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p110",
      "name": "Arven Ternholt",
      "birthDate": "2005-01-17",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 68,
          "power": 67,
          "rotation": 57,
          "vsPace": 54,
          "vsSpin": 61,
          "control": 45,
          "movement": 41,
          "variation": 53,
          "stamina": 52,
          "catching": 71,
          "groundFielding": 66,
          "throwing": 44,
          "keeping": 32
        },
        "ODI": {
          "defence": 48,
          "timing": 45,
          "power": 41,
          "rotation": 56,
          "vsPace": 48,
          "vsSpin": 57,
          "control": 55,
          "movement": 64,
          "variation": 52,
          "stamina": 44,
          "catching": 65,
          "groundFielding": 69,
          "throwing": 44,
          "keeping": 21
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 41,
          "power": 59,
          "rotation": 38,
          "vsPace": 57,
          "vsSpin": 48,
          "control": 55,
          "movement": 52,
          "variation": 59,
          "stamina": 59,
          "catching": 65,
          "groundFielding": 72,
          "throwing": 56,
          "keeping": 18
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        420,
        938,
        616,
        266,
        696,
        540,
        594,
        757
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p111",
      "name": "Walen Wrenden",
      "birthDate": "1996-05-03",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 41,
          "timing": 41,
          "power": 53,
          "rotation": 68,
          "vsPace": 64,
          "vsSpin": 60,
          "control": 51,
          "movement": 64,
          "variation": 66,
          "stamina": 46,
          "catching": 42,
          "groundFielding": 46,
          "throwing": 52,
          "keeping": 15
        },
        "ODI": {
          "defence": 52,
          "timing": 61,
          "power": 53,
          "rotation": 60,
          "vsPace": 61,
          "vsSpin": 45,
          "control": 53,
          "movement": 52,
          "variation": 43,
          "stamina": 45,
          "catching": 72,
          "groundFielding": 57,
          "throwing": 53,
          "keeping": 39
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 59,
          "power": 44,
          "rotation": 49,
          "vsPace": 55,
          "vsSpin": 68,
          "control": 63,
          "movement": 45,
          "variation": 41,
          "stamina": 61,
          "catching": 42,
          "groundFielding": 47,
          "throwing": 46,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        933,
        816,
        732,
        351,
        375,
        655,
        289,
        495
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p112",
      "name": "Walen Mossstead",
      "birthDate": "2002-07-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 79,
          "timing": 70,
          "power": 68,
          "rotation": 66,
          "vsPace": 77,
          "vsSpin": 54,
          "control": 40,
          "movement": 16,
          "variation": 32,
          "stamina": 43,
          "catching": 44,
          "groundFielding": 61,
          "throwing": 50,
          "keeping": 28
        },
        "ODI": {
          "defence": 52,
          "timing": 79,
          "power": 55,
          "rotation": 78,
          "vsPace": 61,
          "vsSpin": 64,
          "control": 34,
          "movement": 38,
          "variation": 44,
          "stamina": 34,
          "catching": 39,
          "groundFielding": 47,
          "throwing": 56,
          "keeping": 37
        },
        "RED_BALL": {
          "defence": 58,
          "timing": 71,
          "power": 77,
          "rotation": 71,
          "vsPace": 66,
          "vsSpin": 75,
          "control": 14,
          "movement": 28,
          "variation": 36,
          "stamina": 27,
          "catching": 39,
          "groundFielding": 50,
          "throwing": 57,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        836,
        815,
        207,
        925,
        531,
        827,
        438,
        278
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p113",
      "name": "Vero Yewfield",
      "birthDate": "2003-05-15",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 59,
          "power": 63,
          "rotation": 67,
          "vsPace": 72,
          "vsSpin": 72,
          "control": 32,
          "movement": 27,
          "variation": 33,
          "stamina": 14,
          "catching": 51,
          "groundFielding": 63,
          "throwing": 59,
          "keeping": 28
        },
        "ODI": {
          "defence": 55,
          "timing": 64,
          "power": 57,
          "rotation": 59,
          "vsPace": 68,
          "vsSpin": 65,
          "control": 41,
          "movement": 33,
          "variation": 26,
          "stamina": 33,
          "catching": 52,
          "groundFielding": 63,
          "throwing": 39,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 52,
          "power": 74,
          "rotation": 69,
          "vsPace": 79,
          "vsSpin": 75,
          "control": 44,
          "movement": 43,
          "variation": 26,
          "stamina": 32,
          "catching": 60,
          "groundFielding": 52,
          "throwing": 64,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        629,
        278,
        209,
        824,
        698,
        273,
        715,
        223
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p114",
      "name": "Miran Elmden",
      "birthDate": "1990-09-19",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 69,
          "timing": 64,
          "power": 77,
          "rotation": 66,
          "vsPace": 76,
          "vsSpin": 69,
          "control": 39,
          "movement": 18,
          "variation": 20,
          "stamina": 22,
          "catching": 49,
          "groundFielding": 57,
          "throwing": 52,
          "keeping": 27
        },
        "ODI": {
          "defence": 80,
          "timing": 65,
          "power": 60,
          "rotation": 77,
          "vsPace": 67,
          "vsSpin": 60,
          "control": 38,
          "movement": 19,
          "variation": 28,
          "stamina": 21,
          "catching": 65,
          "groundFielding": 38,
          "throwing": 48,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 80,
          "timing": 67,
          "power": 63,
          "rotation": 75,
          "vsPace": 55,
          "vsSpin": 73,
          "control": 37,
          "movement": 23,
          "variation": 34,
          "stamina": 41,
          "catching": 65,
          "groundFielding": 64,
          "throwing": 50,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        864,
        450,
        886,
        902,
        237,
        488,
        472,
        992
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p115",
      "name": "Halen Briarfell",
      "birthDate": "2003-07-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 52,
          "timing": 50,
          "power": 60,
          "rotation": 70,
          "vsPace": 73,
          "vsSpin": 51,
          "control": 34,
          "movement": 35,
          "variation": 36,
          "stamina": 44,
          "catching": 66,
          "groundFielding": 51,
          "throwing": 42,
          "keeping": 35
        },
        "ODI": {
          "defence": 79,
          "timing": 61,
          "power": 77,
          "rotation": 59,
          "vsPace": 67,
          "vsSpin": 57,
          "control": 38,
          "movement": 15,
          "variation": 41,
          "stamina": 16,
          "catching": 65,
          "groundFielding": 60,
          "throwing": 46,
          "keeping": 11
        },
        "RED_BALL": {
          "defence": 75,
          "timing": 72,
          "power": 67,
          "rotation": 53,
          "vsPace": 61,
          "vsSpin": 67,
          "control": 32,
          "movement": 19,
          "variation": 24,
          "stamina": 26,
          "catching": 62,
          "groundFielding": 63,
          "throwing": 44,
          "keeping": 40
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        818,
        779,
        876,
        255,
        612,
        682,
        399,
        656
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p116",
      "name": "Arven Quenholt",
      "birthDate": "2001-11-17",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 78,
          "timing": 57,
          "power": 75,
          "rotation": 57,
          "vsPace": 78,
          "vsSpin": 50,
          "control": 32,
          "movement": 40,
          "variation": 18,
          "stamina": 41,
          "catching": 38,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 11
        },
        "ODI": {
          "defence": 80,
          "timing": 61,
          "power": 77,
          "rotation": 70,
          "vsPace": 63,
          "vsSpin": 58,
          "control": 17,
          "movement": 32,
          "variation": 15,
          "stamina": 43,
          "catching": 53,
          "groundFielding": 60,
          "throwing": 50,
          "keeping": 29
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 57,
          "power": 48,
          "rotation": 63,
          "vsPace": 65,
          "vsSpin": 56,
          "control": 39,
          "movement": 28,
          "variation": 14,
          "stamina": 44,
          "catching": 65,
          "groundFielding": 40,
          "throwing": 54,
          "keeping": 24
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        680,
        565,
        749,
        875,
        221,
        982,
        852,
        925
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p117",
      "name": "Elio Elmwick",
      "birthDate": "2007-03-25",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 76,
          "timing": 74,
          "power": 79,
          "rotation": 56,
          "vsPace": 64,
          "vsSpin": 52,
          "control": 36,
          "movement": 18,
          "variation": 32,
          "stamina": 37,
          "catching": 41,
          "groundFielding": 66,
          "throwing": 58,
          "keeping": 23
        },
        "ODI": {
          "defence": 63,
          "timing": 76,
          "power": 66,
          "rotation": 80,
          "vsPace": 74,
          "vsSpin": 65,
          "control": 27,
          "movement": 25,
          "variation": 27,
          "stamina": 30,
          "catching": 56,
          "groundFielding": 59,
          "throwing": 44,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 76,
          "timing": 53,
          "power": 74,
          "rotation": 78,
          "vsPace": 74,
          "vsSpin": 78,
          "control": 20,
          "movement": 25,
          "variation": 16,
          "stamina": 32,
          "catching": 38,
          "groundFielding": 51,
          "throwing": 66,
          "keeping": 31
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        786,
        207,
        474,
        679,
        262,
        934,
        781,
        450
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p118",
      "name": "Jora Wrenthorne",
      "birthDate": "2004-02-11",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 68,
          "timing": 76,
          "power": 60,
          "rotation": 71,
          "vsPace": 73,
          "vsSpin": 57,
          "control": 23,
          "movement": 24,
          "variation": 30,
          "stamina": 20,
          "catching": 41,
          "groundFielding": 63,
          "throwing": 43,
          "keeping": 23
        },
        "ODI": {
          "defence": 51,
          "timing": 71,
          "power": 77,
          "rotation": 67,
          "vsPace": 71,
          "vsSpin": 57,
          "control": 33,
          "movement": 44,
          "variation": 26,
          "stamina": 41,
          "catching": 42,
          "groundFielding": 60,
          "throwing": 60,
          "keeping": 39
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 59,
          "power": 70,
          "rotation": 78,
          "vsPace": 78,
          "vsSpin": 64,
          "control": 39,
          "movement": 35,
          "variation": 41,
          "stamina": 44,
          "catching": 63,
          "groundFielding": 44,
          "throwing": 63,
          "keeping": 16
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        256,
        689,
        269,
        609,
        376,
        223,
        732,
        367
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p119",
      "name": "Saren Zornbrook",
      "birthDate": "1994-11-27",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 77,
          "power": 57,
          "rotation": 71,
          "vsPace": 62,
          "vsSpin": 80,
          "control": 36,
          "movement": 23,
          "variation": 29,
          "stamina": 28,
          "catching": 39,
          "groundFielding": 65,
          "throwing": 54,
          "keeping": 32
        },
        "ODI": {
          "defence": 65,
          "timing": 75,
          "power": 69,
          "rotation": 56,
          "vsPace": 72,
          "vsSpin": 79,
          "control": 31,
          "movement": 16,
          "variation": 38,
          "stamina": 40,
          "catching": 49,
          "groundFielding": 52,
          "throwing": 45,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 66,
          "timing": 54,
          "power": 54,
          "rotation": 54,
          "vsPace": 56,
          "vsSpin": 71,
          "control": 23,
          "movement": 20,
          "variation": 41,
          "stamina": 43,
          "catching": 62,
          "groundFielding": 61,
          "throwing": 56,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        692,
        284,
        435,
        758,
        933,
        595,
        399,
        565
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p120",
      "name": "Kaelen Corcombe",
      "birthDate": "2007-09-27",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 59,
          "timing": 52,
          "power": 80,
          "rotation": 53,
          "vsPace": 74,
          "vsSpin": 68,
          "control": 24,
          "movement": 15,
          "variation": 20,
          "stamina": 44,
          "catching": 50,
          "groundFielding": 65,
          "throwing": 65,
          "keeping": 35
        },
        "ODI": {
          "defence": 55,
          "timing": 57,
          "power": 62,
          "rotation": 63,
          "vsPace": 72,
          "vsSpin": 50,
          "control": 25,
          "movement": 36,
          "variation": 44,
          "stamina": 16,
          "catching": 66,
          "groundFielding": 66,
          "throwing": 58,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 84,
          "timing": 56,
          "power": 49,
          "rotation": 74,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 15,
          "movement": 35,
          "variation": 14,
          "stamina": 29,
          "catching": 59,
          "groundFielding": 58,
          "throwing": 37,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        289,
        410,
        376,
        829,
        514,
        297,
        236,
        244
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p121",
      "name": "Yoran Jorcroft",
      "birthDate": "1987-01-08",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 64,
          "timing": 53,
          "power": 56,
          "rotation": 36,
          "vsPace": 49,
          "vsSpin": 50,
          "control": 36,
          "movement": 32,
          "variation": 18,
          "stamina": 25,
          "catching": 52,
          "groundFielding": 45,
          "throwing": 61,
          "keeping": 83
        },
        "ODI": {
          "defence": 47,
          "timing": 43,
          "power": 35,
          "rotation": 47,
          "vsPace": 45,
          "vsSpin": 63,
          "control": 32,
          "movement": 16,
          "variation": 15,
          "stamina": 37,
          "catching": 41,
          "groundFielding": 68,
          "throwing": 59,
          "keeping": 61
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 44,
          "power": 38,
          "rotation": 59,
          "vsPace": 62,
          "vsSpin": 59,
          "control": 39,
          "movement": 28,
          "variation": 39,
          "stamina": 22,
          "catching": 67,
          "groundFielding": 45,
          "throwing": 71,
          "keeping": 82
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        638,
        501,
        1000,
        644,
        893,
        299,
        485,
        623
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p122",
      "name": "Nave Jorthorne",
      "birthDate": "2000-06-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 64,
          "power": 57,
          "rotation": 63,
          "vsPace": 48,
          "vsSpin": 40,
          "control": 18,
          "movement": 40,
          "variation": 18,
          "stamina": 32,
          "catching": 55,
          "groundFielding": 57,
          "throwing": 49,
          "keeping": 60
        },
        "ODI": {
          "defence": 52,
          "timing": 40,
          "power": 58,
          "rotation": 50,
          "vsPace": 43,
          "vsSpin": 46,
          "control": 37,
          "movement": 33,
          "variation": 19,
          "stamina": 15,
          "catching": 57,
          "groundFielding": 53,
          "throwing": 62,
          "keeping": 69
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 64,
          "power": 42,
          "rotation": 60,
          "vsPace": 64,
          "vsSpin": 41,
          "control": 31,
          "movement": 17,
          "variation": 14,
          "stamina": 24,
          "catching": 48,
          "groundFielding": 50,
          "throwing": 70,
          "keeping": 60
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        664,
        755,
        466,
        620,
        755,
        878,
        668,
        533
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p123",
      "name": "Caro Mossholt",
      "birthDate": "1990-11-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 37,
          "timing": 26,
          "power": 49,
          "rotation": 21,
          "vsPace": 25,
          "vsSpin": 34,
          "control": 61,
          "movement": 57,
          "variation": 69,
          "stamina": 66,
          "catching": 64,
          "groundFielding": 64,
          "throwing": 39,
          "keeping": 16
        },
        "ODI": {
          "defence": 21,
          "timing": 24,
          "power": 41,
          "rotation": 36,
          "vsPace": 38,
          "vsSpin": 35,
          "control": 77,
          "movement": 51,
          "variation": 65,
          "stamina": 64,
          "catching": 68,
          "groundFielding": 39,
          "throwing": 39,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 46,
          "timing": 44,
          "power": 37,
          "rotation": 49,
          "vsPace": 26,
          "vsSpin": 30,
          "control": 54,
          "movement": 77,
          "variation": 54,
          "stamina": 75,
          "catching": 46,
          "groundFielding": 41,
          "throwing": 48,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        769,
        727,
        297,
        726,
        387,
        726,
        891,
        218
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p124",
      "name": "Caro Sablefield",
      "birthDate": "2000-06-22",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 25,
          "timing": 36,
          "power": 41,
          "rotation": 37,
          "vsPace": 44,
          "vsSpin": 43,
          "control": 67,
          "movement": 58,
          "variation": 52,
          "stamina": 77,
          "catching": 39,
          "groundFielding": 46,
          "throwing": 54,
          "keeping": 30
        },
        "ODI": {
          "defence": 45,
          "timing": 31,
          "power": 40,
          "rotation": 20,
          "vsPace": 43,
          "vsSpin": 29,
          "control": 66,
          "movement": 54,
          "variation": 70,
          "stamina": 71,
          "catching": 67,
          "groundFielding": 44,
          "throwing": 66,
          "keeping": 12
        },
        "RED_BALL": {
          "defence": 37,
          "timing": 33,
          "power": 37,
          "rotation": 49,
          "vsPace": 49,
          "vsSpin": 38,
          "control": 56,
          "movement": 50,
          "variation": 56,
          "stamina": 66,
          "catching": 42,
          "groundFielding": 53,
          "throwing": 43,
          "keeping": 17
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        761,
        450,
        302,
        206,
        781,
        942,
        708,
        456
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p125",
      "name": "Nave Mossbridge",
      "birthDate": "1997-10-15",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 26,
          "timing": 29,
          "power": 41,
          "rotation": 19,
          "vsPace": 31,
          "vsSpin": 38,
          "control": 59,
          "movement": 57,
          "variation": 76,
          "stamina": 65,
          "catching": 54,
          "groundFielding": 41,
          "throwing": 55,
          "keeping": 32
        },
        "ODI": {
          "defence": 24,
          "timing": 25,
          "power": 37,
          "rotation": 39,
          "vsPace": 42,
          "vsSpin": 45,
          "control": 50,
          "movement": 57,
          "variation": 54,
          "stamina": 51,
          "catching": 67,
          "groundFielding": 66,
          "throwing": 48,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 30,
          "timing": 48,
          "power": 22,
          "rotation": 34,
          "vsPace": 24,
          "vsSpin": 47,
          "control": 77,
          "movement": 68,
          "variation": 76,
          "stamina": 64,
          "catching": 40,
          "groundFielding": 48,
          "throwing": 63,
          "keeping": 38
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        754,
        590,
        861,
        924,
        563,
        348,
        580,
        222
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p126",
      "name": "Leron Corwick",
      "birthDate": "1993-07-17",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 43,
          "timing": 32,
          "power": 27,
          "rotation": 44,
          "vsPace": 44,
          "vsSpin": 51,
          "control": 60,
          "movement": 58,
          "variation": 72,
          "stamina": 54,
          "catching": 55,
          "groundFielding": 43,
          "throwing": 58,
          "keeping": 19
        },
        "ODI": {
          "defence": 43,
          "timing": 47,
          "power": 25,
          "rotation": 28,
          "vsPace": 26,
          "vsSpin": 47,
          "control": 68,
          "movement": 64,
          "variation": 79,
          "stamina": 53,
          "catching": 40,
          "groundFielding": 55,
          "throwing": 51,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 45,
          "timing": 23,
          "power": 44,
          "rotation": 44,
          "vsPace": 27,
          "vsSpin": 39,
          "control": 62,
          "movement": 68,
          "variation": 65,
          "stamina": 65,
          "catching": 58,
          "groundFielding": 51,
          "throwing": 66,
          "keeping": 19
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        620,
        974,
        396,
        563,
        285,
        542,
        825,
        244
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p127",
      "name": "Tavin Lornbridge",
      "birthDate": "2007-10-03",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 21,
          "power": 47,
          "rotation": 32,
          "vsPace": 34,
          "vsSpin": 38,
          "control": 61,
          "movement": 53,
          "variation": 62,
          "stamina": 52,
          "catching": 66,
          "groundFielding": 45,
          "throwing": 64,
          "keeping": 25
        },
        "ODI": {
          "defence": 36,
          "timing": 28,
          "power": 44,
          "rotation": 38,
          "vsPace": 36,
          "vsSpin": 41,
          "control": 72,
          "movement": 72,
          "variation": 58,
          "stamina": 56,
          "catching": 63,
          "groundFielding": 69,
          "throwing": 68,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 32,
          "timing": 27,
          "power": 41,
          "rotation": 38,
          "vsPace": 31,
          "vsSpin": 19,
          "control": 69,
          "movement": 78,
          "variation": 77,
          "stamina": 68,
          "catching": 41,
          "groundFielding": 50,
          "throwing": 41,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        886,
        525,
        590,
        668,
        623,
        326,
        631,
        916
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p128",
      "name": "Saren Orinwick",
      "birthDate": "2000-02-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 23,
          "timing": 22,
          "power": 42,
          "rotation": 32,
          "vsPace": 24,
          "vsSpin": 43,
          "control": 55,
          "movement": 57,
          "variation": 55,
          "stamina": 75,
          "catching": 58,
          "groundFielding": 43,
          "throwing": 69,
          "keeping": 25
        },
        "ODI": {
          "defence": 20,
          "timing": 32,
          "power": 34,
          "rotation": 31,
          "vsPace": 39,
          "vsSpin": 34,
          "control": 62,
          "movement": 77,
          "variation": 56,
          "stamina": 77,
          "catching": 53,
          "groundFielding": 63,
          "throwing": 61,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 35,
          "timing": 20,
          "power": 25,
          "rotation": 44,
          "vsPace": 26,
          "vsSpin": 29,
          "control": 57,
          "movement": 67,
          "variation": 79,
          "stamina": 80,
          "catching": 48,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 36
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        872,
        778,
        656,
        586,
        911,
        353,
        420,
        823
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p129",
      "name": "Oren Norford",
      "birthDate": "1987-04-23",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 42,
          "timing": 60,
          "power": 56,
          "rotation": 58,
          "vsPace": 55,
          "vsSpin": 46,
          "control": 47,
          "movement": 54,
          "variation": 46,
          "stamina": 63,
          "catching": 69,
          "groundFielding": 49,
          "throwing": 67,
          "keeping": 25
        },
        "ODI": {
          "defence": 65,
          "timing": 53,
          "power": 42,
          "rotation": 63,
          "vsPace": 38,
          "vsSpin": 67,
          "control": 55,
          "movement": 54,
          "variation": 53,
          "stamina": 39,
          "catching": 54,
          "groundFielding": 56,
          "throwing": 64,
          "keeping": 27
        },
        "RED_BALL": {
          "defence": 48,
          "timing": 45,
          "power": 54,
          "rotation": 54,
          "vsPace": 41,
          "vsSpin": 54,
          "control": 45,
          "movement": 45,
          "variation": 54,
          "stamina": 64,
          "catching": 52,
          "groundFielding": 55,
          "throwing": 42,
          "keeping": 27
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        669,
        720,
        482,
        852,
        422,
        390,
        982,
        367
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p130",
      "name": "Walen Jorbridge",
      "birthDate": "2000-05-06",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 47,
          "timing": 60,
          "power": 53,
          "rotation": 60,
          "vsPace": 52,
          "vsSpin": 61,
          "control": 55,
          "movement": 48,
          "variation": 43,
          "stamina": 42,
          "catching": 50,
          "groundFielding": 71,
          "throwing": 67,
          "keeping": 26
        },
        "ODI": {
          "defence": 48,
          "timing": 45,
          "power": 38,
          "rotation": 44,
          "vsPace": 53,
          "vsSpin": 54,
          "control": 46,
          "movement": 40,
          "variation": 57,
          "stamina": 45,
          "catching": 71,
          "groundFielding": 72,
          "throwing": 49,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 58,
          "power": 44,
          "rotation": 43,
          "vsPace": 65,
          "vsSpin": 55,
          "control": 62,
          "movement": 46,
          "variation": 57,
          "stamina": 37,
          "catching": 57,
          "groundFielding": 59,
          "throwing": 56,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        549,
        245,
        719,
        699,
        624,
        266,
        958,
        326
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p131",
      "name": "Quill Harcombe",
      "birthDate": "1987-01-22",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 63,
          "timing": 48,
          "power": 48,
          "rotation": 49,
          "vsPace": 63,
          "vsSpin": 39,
          "control": 59,
          "movement": 56,
          "variation": 38,
          "stamina": 65,
          "catching": 51,
          "groundFielding": 42,
          "throwing": 58,
          "keeping": 38
        },
        "ODI": {
          "defence": 44,
          "timing": 43,
          "power": 47,
          "rotation": 45,
          "vsPace": 47,
          "vsSpin": 49,
          "control": 40,
          "movement": 59,
          "variation": 39,
          "stamina": 42,
          "catching": 46,
          "groundFielding": 66,
          "throwing": 43,
          "keeping": 19
        },
        "RED_BALL": {
          "defence": 60,
          "timing": 66,
          "power": 61,
          "rotation": 67,
          "vsPace": 59,
          "vsSpin": 42,
          "control": 49,
          "movement": 47,
          "variation": 65,
          "stamina": 47,
          "catching": 57,
          "groundFielding": 61,
          "throwing": 46,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        599,
        839,
        878,
        997,
        263,
        270,
        289,
        426
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p132",
      "name": "Halen Quenstone",
      "birthDate": "2003-01-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 51,
          "power": 73,
          "rotation": 56,
          "vsPace": 76,
          "vsSpin": 63,
          "control": 30,
          "movement": 30,
          "variation": 38,
          "stamina": 36,
          "catching": 56,
          "groundFielding": 63,
          "throwing": 57,
          "keeping": 23
        },
        "ODI": {
          "defence": 51,
          "timing": 71,
          "power": 78,
          "rotation": 50,
          "vsPace": 59,
          "vsSpin": 67,
          "control": 15,
          "movement": 29,
          "variation": 44,
          "stamina": 15,
          "catching": 39,
          "groundFielding": 57,
          "throwing": 67,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 74,
          "timing": 67,
          "power": 52,
          "rotation": 67,
          "vsPace": 52,
          "vsSpin": 63,
          "control": 17,
          "movement": 23,
          "variation": 14,
          "stamina": 42,
          "catching": 64,
          "groundFielding": 40,
          "throwing": 58,
          "keeping": 29
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        325,
        666,
        348,
        648,
        538,
        960,
        677,
        963
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p133",
      "name": "Miran Falkridge",
      "birthDate": "2005-11-18",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 51,
          "timing": 54,
          "power": 63,
          "rotation": 66,
          "vsPace": 76,
          "vsSpin": 60,
          "control": 14,
          "movement": 24,
          "variation": 34,
          "stamina": 18,
          "catching": 55,
          "groundFielding": 59,
          "throwing": 53,
          "keeping": 19
        },
        "ODI": {
          "defence": 78,
          "timing": 54,
          "power": 66,
          "rotation": 63,
          "vsPace": 79,
          "vsSpin": 74,
          "control": 39,
          "movement": 15,
          "variation": 14,
          "stamina": 21,
          "catching": 65,
          "groundFielding": 50,
          "throwing": 51,
          "keeping": 16
        },
        "RED_BALL": {
          "defence": 71,
          "timing": 58,
          "power": 70,
          "rotation": 50,
          "vsPace": 77,
          "vsSpin": 78,
          "control": 27,
          "movement": 24,
          "variation": 22,
          "stamina": 17,
          "catching": 44,
          "groundFielding": 50,
          "throwing": 47,
          "keeping": 26
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        551,
        297,
        340,
        522,
        690,
        919,
        670,
        493
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p134",
      "name": "Elio Dunfell",
      "birthDate": "1989-03-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 52,
          "timing": 77,
          "power": 77,
          "rotation": 56,
          "vsPace": 65,
          "vsSpin": 58,
          "control": 21,
          "movement": 26,
          "variation": 17,
          "stamina": 19,
          "catching": 67,
          "groundFielding": 58,
          "throwing": 48,
          "keeping": 11
        },
        "ODI": {
          "defence": 50,
          "timing": 58,
          "power": 76,
          "rotation": 69,
          "vsPace": 77,
          "vsSpin": 72,
          "control": 39,
          "movement": 33,
          "variation": 41,
          "stamina": 32,
          "catching": 57,
          "groundFielding": 50,
          "throwing": 63,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 66,
          "power": 57,
          "rotation": 72,
          "vsPace": 67,
          "vsSpin": 72,
          "control": 44,
          "movement": 40,
          "variation": 30,
          "stamina": 43,
          "catching": 48,
          "groundFielding": 61,
          "throwing": 60,
          "keeping": 35
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        978,
        452,
        353,
        480,
        940,
        708,
        433,
        349
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p135",
      "name": "Eren Quenstead",
      "birthDate": "2007-02-07",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 56,
          "timing": 58,
          "power": 73,
          "rotation": 53,
          "vsPace": 71,
          "vsSpin": 75,
          "control": 34,
          "movement": 23,
          "variation": 44,
          "stamina": 25,
          "catching": 54,
          "groundFielding": 55,
          "throwing": 48,
          "keeping": 23
        },
        "ODI": {
          "defence": 54,
          "timing": 67,
          "power": 58,
          "rotation": 76,
          "vsPace": 61,
          "vsSpin": 56,
          "control": 27,
          "movement": 37,
          "variation": 26,
          "stamina": 42,
          "catching": 50,
          "groundFielding": 37,
          "throwing": 58,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 57,
          "timing": 65,
          "power": 51,
          "rotation": 73,
          "vsPace": 60,
          "vsSpin": 78,
          "control": 34,
          "movement": 23,
          "variation": 30,
          "stamina": 31,
          "catching": 43,
          "groundFielding": 60,
          "throwing": 39,
          "keeping": 41
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        658,
        275,
        311,
        699,
        207,
        341,
        556,
        672
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p136",
      "name": "Eren Rookmere",
      "birthDate": "1990-02-19",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 53,
          "power": 74,
          "rotation": 65,
          "vsPace": 70,
          "vsSpin": 63,
          "control": 37,
          "movement": 22,
          "variation": 30,
          "stamina": 27,
          "catching": 60,
          "groundFielding": 40,
          "throwing": 39,
          "keeping": 20
        },
        "ODI": {
          "defence": 57,
          "timing": 79,
          "power": 80,
          "rotation": 75,
          "vsPace": 73,
          "vsSpin": 73,
          "control": 25,
          "movement": 35,
          "variation": 16,
          "stamina": 42,
          "catching": 59,
          "groundFielding": 64,
          "throwing": 38,
          "keeping": 32
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 50,
          "power": 50,
          "rotation": 68,
          "vsPace": 72,
          "vsSpin": 58,
          "control": 16,
          "movement": 36,
          "variation": 24,
          "stamina": 44,
          "catching": 43,
          "groundFielding": 67,
          "throwing": 61,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        446,
        685,
        661,
        273,
        675,
        361,
        355,
        794
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p137",
      "name": "Elio Norbrook",
      "birthDate": "2004-01-14",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 57,
          "timing": 53,
          "power": 80,
          "rotation": 52,
          "vsPace": 79,
          "vsSpin": 63,
          "control": 20,
          "movement": 33,
          "variation": 17,
          "stamina": 28,
          "catching": 64,
          "groundFielding": 65,
          "throwing": 43,
          "keeping": 35
        },
        "ODI": {
          "defence": 57,
          "timing": 54,
          "power": 68,
          "rotation": 58,
          "vsPace": 65,
          "vsSpin": 72,
          "control": 29,
          "movement": 26,
          "variation": 27,
          "stamina": 42,
          "catching": 56,
          "groundFielding": 40,
          "throwing": 38,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 64,
          "timing": 52,
          "power": 62,
          "rotation": 72,
          "vsPace": 56,
          "vsSpin": 79,
          "control": 27,
          "movement": 17,
          "variation": 38,
          "stamina": 22,
          "catching": 66,
          "groundFielding": 63,
          "throwing": 54,
          "keeping": 23
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        539,
        482,
        812,
        800,
        952,
        836,
        992,
        706
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p138",
      "name": "Belan Quencroft",
      "birthDate": "1998-04-18",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 61,
          "timing": 60,
          "power": 58,
          "rotation": 68,
          "vsPace": 73,
          "vsSpin": 57,
          "control": 35,
          "movement": 26,
          "variation": 21,
          "stamina": 20,
          "catching": 64,
          "groundFielding": 57,
          "throwing": 55,
          "keeping": 32
        },
        "ODI": {
          "defence": 65,
          "timing": 67,
          "power": 65,
          "rotation": 70,
          "vsPace": 71,
          "vsSpin": 78,
          "control": 32,
          "movement": 37,
          "variation": 30,
          "stamina": 26,
          "catching": 42,
          "groundFielding": 53,
          "throwing": 51,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 73,
          "timing": 61,
          "power": 72,
          "rotation": 52,
          "vsPace": 75,
          "vsSpin": 78,
          "control": 25,
          "movement": 35,
          "variation": 42,
          "stamina": 42,
          "catching": 47,
          "groundFielding": 48,
          "throwing": 50,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        673,
        756,
        695,
        641,
        702,
        640,
        408,
        285
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p139",
      "name": "Caro Sablefield 19",
      "birthDate": "2007-10-10",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 55,
          "timing": 74,
          "power": 65,
          "rotation": 53,
          "vsPace": 53,
          "vsSpin": 75,
          "control": 23,
          "movement": 31,
          "variation": 21,
          "stamina": 27,
          "catching": 54,
          "groundFielding": 53,
          "throwing": 43,
          "keeping": 12
        },
        "ODI": {
          "defence": 71,
          "timing": 74,
          "power": 56,
          "rotation": 66,
          "vsPace": 68,
          "vsSpin": 54,
          "control": 24,
          "movement": 31,
          "variation": 17,
          "stamina": 39,
          "catching": 56,
          "groundFielding": 48,
          "throwing": 49,
          "keeping": 36
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 57,
          "power": 47,
          "rotation": 71,
          "vsPace": 63,
          "vsSpin": 72,
          "control": 41,
          "movement": 15,
          "variation": 35,
          "stamina": 29,
          "catching": 49,
          "groundFielding": 49,
          "throwing": 55,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        941,
        779,
        733,
        649,
        702,
        652,
        544,
        240
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p140",
      "name": "Rilan Dunwick",
      "birthDate": "1995-01-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 63,
          "power": 74,
          "rotation": 76,
          "vsPace": 65,
          "vsSpin": 76,
          "control": 44,
          "movement": 42,
          "variation": 23,
          "stamina": 28,
          "catching": 52,
          "groundFielding": 51,
          "throwing": 51,
          "keeping": 21
        },
        "ODI": {
          "defence": 77,
          "timing": 69,
          "power": 54,
          "rotation": 71,
          "vsPace": 74,
          "vsSpin": 78,
          "control": 44,
          "movement": 22,
          "variation": 21,
          "stamina": 23,
          "catching": 44,
          "groundFielding": 67,
          "throwing": 38,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 56,
          "timing": 58,
          "power": 56,
          "rotation": 59,
          "vsPace": 79,
          "vsSpin": 53,
          "control": 28,
          "movement": 24,
          "variation": 31,
          "stamina": 23,
          "catching": 52,
          "groundFielding": 49,
          "throwing": 56,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        529,
        773,
        309,
        938,
        794,
        980,
        712,
        855
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p141",
      "name": "Rilan Sablecroft",
      "birthDate": "2006-06-16",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 50,
          "power": 53,
          "rotation": 53,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 28,
          "movement": 20,
          "variation": 12,
          "stamina": 34,
          "catching": 48,
          "groundFielding": 59,
          "throwing": 58,
          "keeping": 56
        },
        "ODI": {
          "defence": 55,
          "timing": 46,
          "power": 53,
          "rotation": 53,
          "vsPace": 55,
          "vsSpin": 59,
          "control": 31,
          "movement": 41,
          "variation": 12,
          "stamina": 41,
          "catching": 71,
          "groundFielding": 70,
          "throwing": 67,
          "keeping": 72
        },
        "RED_BALL": {
          "defence": 69,
          "timing": 45,
          "power": 31,
          "rotation": 41,
          "vsPace": 43,
          "vsSpin": 51,
          "control": 21,
          "movement": 38,
          "variation": 36,
          "stamina": 19,
          "catching": 46,
          "groundFielding": 53,
          "throwing": 65,
          "keeping": 76
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        206,
        622,
        342,
        507,
        501,
        476,
        388,
        614
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p142",
      "name": "Pavan Jorstone",
      "birthDate": "1999-11-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "KEEPER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 42,
          "power": 66,
          "rotation": 49,
          "vsPace": 53,
          "vsSpin": 41,
          "control": 36,
          "movement": 38,
          "variation": 37,
          "stamina": 41,
          "catching": 51,
          "groundFielding": 41,
          "throwing": 71,
          "keeping": 63
        },
        "ODI": {
          "defence": 51,
          "timing": 59,
          "power": 50,
          "rotation": 43,
          "vsPace": 50,
          "vsSpin": 53,
          "control": 27,
          "movement": 37,
          "variation": 18,
          "stamina": 36,
          "catching": 43,
          "groundFielding": 48,
          "throwing": 45,
          "keeping": 60
        },
        "RED_BALL": {
          "defence": 64,
          "timing": 51,
          "power": 39,
          "rotation": 38,
          "vsPace": 41,
          "vsSpin": 52,
          "control": 27,
          "movement": 26,
          "variation": 15,
          "stamina": 33,
          "catching": 42,
          "groundFielding": 56,
          "throwing": 43,
          "keeping": 75
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        526,
        434,
        275,
        985,
        273,
        445,
        577,
        521
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p143",
      "name": "Halen Orinmere",
      "birthDate": "1995-05-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "FAST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 24,
          "timing": 22,
          "power": 43,
          "rotation": 30,
          "vsPace": 34,
          "vsSpin": 40,
          "control": 76,
          "movement": 52,
          "variation": 50,
          "stamina": 56,
          "catching": 47,
          "groundFielding": 62,
          "throwing": 67,
          "keeping": 30
        },
        "ODI": {
          "defence": 40,
          "timing": 23,
          "power": 28,
          "rotation": 25,
          "vsPace": 48,
          "vsSpin": 32,
          "control": 50,
          "movement": 55,
          "variation": 71,
          "stamina": 63,
          "catching": 67,
          "groundFielding": 69,
          "throwing": 55,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 25,
          "timing": 35,
          "power": 31,
          "rotation": 19,
          "vsPace": 26,
          "vsSpin": 27,
          "control": 72,
          "movement": 61,
          "variation": 68,
          "stamina": 56,
          "catching": 56,
          "groundFielding": 64,
          "throwing": 50,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        895,
        882,
        998,
        602,
        488,
        751,
        508,
        379
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p144",
      "name": "Rilan Ternford",
      "birthDate": "1995-11-04",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "MEDIUM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 35,
          "timing": 45,
          "power": 29,
          "rotation": 35,
          "vsPace": 48,
          "vsSpin": 47,
          "control": 58,
          "movement": 72,
          "variation": 58,
          "stamina": 53,
          "catching": 44,
          "groundFielding": 46,
          "throwing": 47,
          "keeping": 40
        },
        "ODI": {
          "defence": 23,
          "timing": 48,
          "power": 27,
          "rotation": 34,
          "vsPace": 47,
          "vsSpin": 37,
          "control": 69,
          "movement": 50,
          "variation": 60,
          "stamina": 51,
          "catching": 44,
          "groundFielding": 55,
          "throwing": 45,
          "keeping": 33
        },
        "RED_BALL": {
          "defence": 40,
          "timing": 27,
          "power": 29,
          "rotation": 32,
          "vsPace": 44,
          "vsSpin": 20,
          "control": 66,
          "movement": 66,
          "variation": 69,
          "stamina": 65,
          "catching": 61,
          "groundFielding": 64,
          "throwing": 47,
          "keeping": 15
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        397,
        792,
        913,
        206,
        591,
        888,
        479,
        844
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p145",
      "name": "Caro Jorwell",
      "birthDate": "2003-04-05",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": "OFF_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 41,
          "power": 48,
          "rotation": 23,
          "vsPace": 30,
          "vsSpin": 27,
          "control": 71,
          "movement": 50,
          "variation": 61,
          "stamina": 79,
          "catching": 54,
          "groundFielding": 48,
          "throwing": 62,
          "keeping": 35
        },
        "ODI": {
          "defence": 24,
          "timing": 40,
          "power": 31,
          "rotation": 24,
          "vsPace": 45,
          "vsSpin": 41,
          "control": 62,
          "movement": 70,
          "variation": 75,
          "stamina": 75,
          "catching": 54,
          "groundFielding": 59,
          "throwing": 66,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 47,
          "timing": 49,
          "power": 27,
          "rotation": 21,
          "vsPace": 23,
          "vsSpin": 26,
          "control": 66,
          "movement": 74,
          "variation": 56,
          "stamina": 61,
          "catching": 47,
          "groundFielding": 58,
          "throwing": 45,
          "keeping": 11
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        873,
        213,
        669,
        741,
        604,
        688,
        678,
        674
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p146",
      "name": "Nave Orincombe",
      "birthDate": "1992-10-23",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEG_SPIN",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 39,
          "timing": 37,
          "power": 45,
          "rotation": 35,
          "vsPace": 30,
          "vsSpin": 30,
          "control": 70,
          "movement": 64,
          "variation": 54,
          "stamina": 54,
          "catching": 43,
          "groundFielding": 49,
          "throwing": 53,
          "keeping": 25
        },
        "ODI": {
          "defence": 45,
          "timing": 43,
          "power": 35,
          "rotation": 44,
          "vsPace": 39,
          "vsSpin": 49,
          "control": 58,
          "movement": 70,
          "variation": 70,
          "stamina": 67,
          "catching": 41,
          "groundFielding": 61,
          "throwing": 58,
          "keeping": 20
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 48,
          "power": 41,
          "rotation": 30,
          "vsPace": 19,
          "vsSpin": 22,
          "control": 71,
          "movement": 56,
          "variation": 77,
          "stamina": 72,
          "catching": 59,
          "groundFielding": 59,
          "throwing": 65,
          "keeping": 18
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        301,
        506,
        311,
        999,
        880,
        420,
        945,
        213
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p147",
      "name": "Elio Yewwell",
      "birthDate": "2001-11-22",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 31,
          "timing": 34,
          "power": 49,
          "rotation": 33,
          "vsPace": 30,
          "vsSpin": 37,
          "control": 55,
          "movement": 59,
          "variation": 71,
          "stamina": 76,
          "catching": 50,
          "groundFielding": 53,
          "throwing": 52,
          "keeping": 12
        },
        "ODI": {
          "defence": 47,
          "timing": 34,
          "power": 46,
          "rotation": 30,
          "vsPace": 22,
          "vsSpin": 34,
          "control": 75,
          "movement": 51,
          "variation": 53,
          "stamina": 60,
          "catching": 39,
          "groundFielding": 60,
          "throwing": 57,
          "keeping": 40
        },
        "RED_BALL": {
          "defence": 54,
          "timing": 26,
          "power": 29,
          "rotation": 30,
          "vsPace": 35,
          "vsSpin": 42,
          "control": 62,
          "movement": 60,
          "variation": 52,
          "stamina": 69,
          "catching": 69,
          "groundFielding": 63,
          "throwing": 65,
          "keeping": 34
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        882,
        373,
        542,
        439,
        374,
        374,
        736,
        266
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p148",
      "name": "Deren Norwick",
      "birthDate": "1992-11-25",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "BOWLER",
      "skills": {
        "T20": {
          "defence": 33,
          "timing": 34,
          "power": 25,
          "rotation": 35,
          "vsPace": 39,
          "vsSpin": 25,
          "control": 79,
          "movement": 78,
          "variation": 53,
          "stamina": 70,
          "catching": 69,
          "groundFielding": 56,
          "throwing": 60,
          "keeping": 33
        },
        "ODI": {
          "defence": 37,
          "timing": 44,
          "power": 24,
          "rotation": 41,
          "vsPace": 38,
          "vsSpin": 21,
          "control": 50,
          "movement": 51,
          "variation": 55,
          "stamina": 67,
          "catching": 41,
          "groundFielding": 64,
          "throwing": 68,
          "keeping": 25
        },
        "RED_BALL": {
          "defence": 42,
          "timing": 45,
          "power": 26,
          "rotation": 30,
          "vsPace": 46,
          "vsSpin": 31,
          "control": 79,
          "movement": 76,
          "variation": 64,
          "stamina": 54,
          "catching": 51,
          "groundFielding": 66,
          "throwing": 53,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        200,
        823,
        328,
        585,
        951,
        503,
        696,
        715
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p149",
      "name": "Galen Zornwick",
      "birthDate": "1998-07-01",
      "batHand": "L",
      "bowlHand": "L",
      "bowlingStyle": "LEG_SPIN",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 60,
          "timing": 57,
          "power": 70,
          "rotation": 64,
          "vsPace": 48,
          "vsSpin": 45,
          "control": 41,
          "movement": 60,
          "variation": 58,
          "stamina": 63,
          "catching": 55,
          "groundFielding": 72,
          "throwing": 48,
          "keeping": 36
        },
        "ODI": {
          "defence": 50,
          "timing": 55,
          "power": 39,
          "rotation": 48,
          "vsPace": 47,
          "vsSpin": 58,
          "control": 59,
          "movement": 46,
          "variation": 51,
          "stamina": 52,
          "catching": 51,
          "groundFielding": 43,
          "throwing": 47,
          "keeping": 14
        },
        "RED_BALL": {
          "defence": 43,
          "timing": 68,
          "power": 56,
          "rotation": 57,
          "vsPace": 67,
          "vsSpin": 52,
          "control": 49,
          "movement": 64,
          "variation": 60,
          "stamina": 46,
          "catching": 59,
          "groundFielding": 56,
          "throwing": 49,
          "keeping": 30
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        450,
        480,
        658,
        273,
        913,
        577,
        543,
        670
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p150",
      "name": "Borin Jorfield",
      "birthDate": "2007-08-03",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": "SLOW_LEFT_ARM",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 44,
          "timing": 67,
          "power": 46,
          "rotation": 49,
          "vsPace": 41,
          "vsSpin": 61,
          "control": 65,
          "movement": 58,
          "variation": 42,
          "stamina": 40,
          "catching": 49,
          "groundFielding": 71,
          "throwing": 47,
          "keeping": 12
        },
        "ODI": {
          "defence": 58,
          "timing": 56,
          "power": 56,
          "rotation": 40,
          "vsPace": 61,
          "vsSpin": 51,
          "control": 49,
          "movement": 42,
          "variation": 38,
          "stamina": 57,
          "catching": 51,
          "groundFielding": 44,
          "throwing": 66,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 67,
          "power": 42,
          "rotation": 42,
          "vsPace": 66,
          "vsSpin": 51,
          "control": 58,
          "movement": 45,
          "variation": 56,
          "stamina": 40,
          "catching": 68,
          "groundFielding": 55,
          "throwing": 42,
          "keeping": 28
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        501,
        429,
        592,
        335,
        549,
        786,
        997,
        258
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p151",
      "name": "Zerin Harridge",
      "birthDate": "2000-05-28",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": "LEFT_ARM_WRIST",
      "role": "ALLROUNDER",
      "skills": {
        "T20": {
          "defence": 41,
          "timing": 53,
          "power": 50,
          "rotation": 43,
          "vsPace": 53,
          "vsSpin": 56,
          "control": 64,
          "movement": 51,
          "variation": 53,
          "stamina": 50,
          "catching": 68,
          "groundFielding": 59,
          "throwing": 67,
          "keeping": 13
        },
        "ODI": {
          "defence": 41,
          "timing": 67,
          "power": 38,
          "rotation": 38,
          "vsPace": 40,
          "vsSpin": 56,
          "control": 47,
          "movement": 65,
          "variation": 54,
          "stamina": 39,
          "catching": 68,
          "groundFielding": 53,
          "throwing": 66,
          "keeping": 23
        },
        "RED_BALL": {
          "defence": 50,
          "timing": 44,
          "power": 55,
          "rotation": 57,
          "vsPace": 38,
          "vsSpin": 57,
          "control": 47,
          "movement": 59,
          "variation": 51,
          "stamina": 61,
          "catching": 47,
          "groundFielding": 45,
          "throwing": 49,
          "keeping": 33
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        584,
        570,
        841,
        998,
        767,
        814,
        270,
        238
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p152",
      "name": "Oren Lornmere",
      "birthDate": "2004-05-27",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 66,
          "timing": 69,
          "power": 75,
          "rotation": 52,
          "vsPace": 71,
          "vsSpin": 67,
          "control": 27,
          "movement": 32,
          "variation": 35,
          "stamina": 44,
          "catching": 52,
          "groundFielding": 44,
          "throwing": 55,
          "keeping": 27
        },
        "ODI": {
          "defence": 50,
          "timing": 61,
          "power": 74,
          "rotation": 50,
          "vsPace": 65,
          "vsSpin": 54,
          "control": 24,
          "movement": 24,
          "variation": 22,
          "stamina": 17,
          "catching": 46,
          "groundFielding": 47,
          "throwing": 67,
          "keeping": 22
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 53,
          "power": 70,
          "rotation": 64,
          "vsPace": 62,
          "vsSpin": 56,
          "control": 28,
          "movement": 42,
          "variation": 15,
          "stamina": 25,
          "catching": 47,
          "groundFielding": 37,
          "throwing": 52,
          "keeping": 14
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        539,
        300,
        203,
        819,
        329,
        944,
        559,
        506
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p153",
      "name": "Oren Kelwell",
      "birthDate": "1991-11-14",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 79,
          "timing": 55,
          "power": 61,
          "rotation": 68,
          "vsPace": 64,
          "vsSpin": 57,
          "control": 27,
          "movement": 24,
          "variation": 36,
          "stamina": 17,
          "catching": 58,
          "groundFielding": 54,
          "throwing": 50,
          "keeping": 11
        },
        "ODI": {
          "defence": 60,
          "timing": 61,
          "power": 69,
          "rotation": 65,
          "vsPace": 79,
          "vsSpin": 59,
          "control": 22,
          "movement": 16,
          "variation": 23,
          "stamina": 17,
          "catching": 58,
          "groundFielding": 49,
          "throwing": 62,
          "keeping": 24
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 54,
          "power": 56,
          "rotation": 78,
          "vsPace": 70,
          "vsSpin": 68,
          "control": 43,
          "movement": 16,
          "variation": 37,
          "stamina": 38,
          "catching": 51,
          "groundFielding": 49,
          "throwing": 51,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        821,
        868,
        333,
        281,
        290,
        743,
        728,
        855
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p154",
      "name": "Nerin Ashwell",
      "birthDate": "1995-08-15",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 76,
          "timing": 72,
          "power": 72,
          "rotation": 73,
          "vsPace": 79,
          "vsSpin": 51,
          "control": 41,
          "movement": 38,
          "variation": 25,
          "stamina": 23,
          "catching": 43,
          "groundFielding": 62,
          "throwing": 57,
          "keeping": 22
        },
        "ODI": {
          "defence": 65,
          "timing": 78,
          "power": 65,
          "rotation": 69,
          "vsPace": 61,
          "vsSpin": 67,
          "control": 21,
          "movement": 18,
          "variation": 40,
          "stamina": 24,
          "catching": 51,
          "groundFielding": 67,
          "throwing": 56,
          "keeping": 28
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 65,
          "power": 55,
          "rotation": 74,
          "vsPace": 50,
          "vsSpin": 73,
          "control": 19,
          "movement": 33,
          "variation": 37,
          "stamina": 25,
          "catching": 48,
          "groundFielding": 55,
          "throwing": 61,
          "keeping": 20
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        721,
        440,
        724,
        668,
        257,
        352,
        452,
        353
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p155",
      "name": "Eren Orinthorne",
      "birthDate": "1996-03-13",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 53,
          "timing": 77,
          "power": 58,
          "rotation": 69,
          "vsPace": 71,
          "vsSpin": 63,
          "control": 24,
          "movement": 42,
          "variation": 17,
          "stamina": 28,
          "catching": 56,
          "groundFielding": 51,
          "throwing": 64,
          "keeping": 12
        },
        "ODI": {
          "defence": 66,
          "timing": 52,
          "power": 64,
          "rotation": 62,
          "vsPace": 50,
          "vsSpin": 78,
          "control": 23,
          "movement": 27,
          "variation": 15,
          "stamina": 18,
          "catching": 38,
          "groundFielding": 49,
          "throwing": 58,
          "keeping": 15
        },
        "RED_BALL": {
          "defence": 81,
          "timing": 78,
          "power": 63,
          "rotation": 53,
          "vsPace": 62,
          "vsSpin": 54,
          "control": 25,
          "movement": 19,
          "variation": 36,
          "stamina": 17,
          "catching": 42,
          "groundFielding": 63,
          "throwing": 65,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        358,
        605,
        607,
        969,
        946,
        475,
        718,
        325
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p156",
      "name": "Miran Quenfell",
      "birthDate": "1989-02-22",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 50,
          "timing": 66,
          "power": 77,
          "rotation": 63,
          "vsPace": 55,
          "vsSpin": 51,
          "control": 24,
          "movement": 30,
          "variation": 41,
          "stamina": 34,
          "catching": 39,
          "groundFielding": 45,
          "throwing": 65,
          "keeping": 35
        },
        "ODI": {
          "defence": 64,
          "timing": 54,
          "power": 54,
          "rotation": 62,
          "vsPace": 57,
          "vsSpin": 63,
          "control": 18,
          "movement": 31,
          "variation": 22,
          "stamina": 30,
          "catching": 48,
          "groundFielding": 64,
          "throwing": 58,
          "keeping": 30
        },
        "RED_BALL": {
          "defence": 72,
          "timing": 59,
          "power": 47,
          "rotation": 79,
          "vsPace": 77,
          "vsSpin": 61,
          "control": 25,
          "movement": 20,
          "variation": 42,
          "stamina": 33,
          "catching": 46,
          "groundFielding": 55,
          "throwing": 54,
          "keeping": 21
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        754,
        345,
        805,
        911,
        635,
        821,
        904,
        868
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p157",
      "name": "Vero Norfield",
      "birthDate": "1997-02-07",
      "batHand": "R",
      "bowlHand": "L",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 61,
          "timing": 62,
          "power": 70,
          "rotation": 70,
          "vsPace": 58,
          "vsSpin": 55,
          "control": 32,
          "movement": 20,
          "variation": 19,
          "stamina": 14,
          "catching": 38,
          "groundFielding": 49,
          "throwing": 55,
          "keeping": 19
        },
        "ODI": {
          "defence": 50,
          "timing": 71,
          "power": 60,
          "rotation": 59,
          "vsPace": 71,
          "vsSpin": 60,
          "control": 34,
          "movement": 22,
          "variation": 31,
          "stamina": 42,
          "catching": 66,
          "groundFielding": 60,
          "throwing": 66,
          "keeping": 31
        },
        "RED_BALL": {
          "defence": 79,
          "timing": 63,
          "power": 63,
          "rotation": 75,
          "vsPace": 76,
          "vsSpin": 55,
          "control": 30,
          "movement": 36,
          "variation": 40,
          "stamina": 34,
          "catching": 41,
          "groundFielding": 43,
          "throwing": 50,
          "keeping": 37
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        243,
        968,
        635,
        930,
        759,
        338,
        318,
        426
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p158",
      "name": "Walen Norbridge",
      "birthDate": "1998-10-19",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 73,
          "timing": 66,
          "power": 84,
          "rotation": 68,
          "vsPace": 80,
          "vsSpin": 66,
          "control": 27,
          "movement": 36,
          "variation": 18,
          "stamina": 23,
          "catching": 52,
          "groundFielding": 65,
          "throwing": 54,
          "keeping": 19
        },
        "ODI": {
          "defence": 60,
          "timing": 67,
          "power": 62,
          "rotation": 71,
          "vsPace": 75,
          "vsSpin": 57,
          "control": 31,
          "movement": 33,
          "variation": 27,
          "stamina": 33,
          "catching": 43,
          "groundFielding": 64,
          "throwing": 45,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 67,
          "timing": 79,
          "power": 64,
          "rotation": 52,
          "vsPace": 79,
          "vsSpin": 75,
          "control": 40,
          "movement": 34,
          "variation": 36,
          "stamina": 42,
          "catching": 56,
          "groundFielding": 40,
          "throwing": 54,
          "keeping": 39
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        404,
        994,
        500,
        710,
        410,
        410,
        893,
        935
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p159",
      "name": "Nerin Yewfield",
      "birthDate": "1993-12-11",
      "batHand": "L",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 62,
          "timing": 80,
          "power": 81,
          "rotation": 65,
          "vsPace": 65,
          "vsSpin": 69,
          "control": 44,
          "movement": 15,
          "variation": 39,
          "stamina": 16,
          "catching": 67,
          "groundFielding": 49,
          "throwing": 46,
          "keeping": 41
        },
        "ODI": {
          "defence": 68,
          "timing": 59,
          "power": 52,
          "rotation": 57,
          "vsPace": 63,
          "vsSpin": 78,
          "control": 42,
          "movement": 33,
          "variation": 42,
          "stamina": 29,
          "catching": 64,
          "groundFielding": 57,
          "throwing": 45,
          "keeping": 38
        },
        "RED_BALL": {
          "defence": 61,
          "timing": 58,
          "power": 73,
          "rotation": 80,
          "vsPace": 64,
          "vsSpin": 53,
          "control": 39,
          "movement": 23,
          "variation": 26,
          "stamina": 40,
          "catching": 56,
          "groundFielding": 50,
          "throwing": 60,
          "keeping": 12
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        403,
        914,
        988,
        266,
        785,
        607,
        522,
        395
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    },
    {
      "playerId": "p160",
      "name": "Rilan Yewbridge",
      "birthDate": "1998-02-04",
      "batHand": "R",
      "bowlHand": "R",
      "bowlingStyle": null,
      "role": "BATTER",
      "skills": {
        "T20": {
          "defence": 67,
          "timing": 52,
          "power": 69,
          "rotation": 57,
          "vsPace": 53,
          "vsSpin": 70,
          "control": 33,
          "movement": 44,
          "variation": 41,
          "stamina": 18,
          "catching": 67,
          "groundFielding": 59,
          "throwing": 57,
          "keeping": 29
        },
        "ODI": {
          "defence": 52,
          "timing": 80,
          "power": 76,
          "rotation": 77,
          "vsPace": 58,
          "vsSpin": 59,
          "control": 39,
          "movement": 42,
          "variation": 38,
          "stamina": 27,
          "catching": 52,
          "groundFielding": 66,
          "throwing": 50,
          "keeping": 13
        },
        "RED_BALL": {
          "defence": 77,
          "timing": 75,
          "power": 60,
          "rotation": 54,
          "vsPace": 70,
          "vsSpin": 63,
          "control": 18,
          "movement": 31,
          "variation": 42,
          "stamina": 43,
          "catching": 40,
          "groundFielding": 41,
          "throwing": 61,
          "keeping": 22
        }
      },
      "variations": [
        "stock"
      ],
      "shotSectorWeights": [
        651,
        392,
        434,
        495,
        242,
        984,
        898,
        624
      ],
      "exposureBalls": {
        "T20": 0,
        "ODI": 0,
        "RED_BALL": 0
      },
      "provenance": {
        "kind": "FICTIONAL",
        "sourceId": "fictional-eight-01",
        "sourceHash": "97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",
        "confidenceBp": 3000
      }
    }
  ],
  "teams": [
    {
      "teamId": "team-01",
      "name": "Aster Harbour",
      "squadIds": [
        "p001",
        "p002",
        "p003",
        "p004",
        "p005",
        "p006",
        "p007",
        "p008",
        "p009",
        "p010",
        "p011",
        "p012",
        "p013",
        "p014",
        "p015",
        "p016",
        "p017",
        "p018",
        "p019",
        "p020"
      ],
      "colours": [
        "#254B69",
        "#E6C97D"
      ]
    },
    {
      "teamId": "team-02",
      "name": "Copper Vale",
      "squadIds": [
        "p021",
        "p022",
        "p023",
        "p024",
        "p025",
        "p026",
        "p027",
        "p028",
        "p029",
        "p030",
        "p031",
        "p032",
        "p033",
        "p034",
        "p035",
        "p036",
        "p037",
        "p038",
        "p039",
        "p040"
      ],
      "colours": [
        "#9B4A32",
        "#EEE5D1"
      ]
    },
    {
      "teamId": "team-03",
      "name": "Northlight Ridge",
      "squadIds": [
        "p041",
        "p042",
        "p043",
        "p044",
        "p045",
        "p046",
        "p047",
        "p048",
        "p049",
        "p050",
        "p051",
        "p052",
        "p053",
        "p054",
        "p055",
        "p056",
        "p057",
        "p058",
        "p059",
        "p060"
      ],
      "colours": [
        "#254A3D",
        "#D1DBDC"
      ]
    },
    {
      "teamId": "team-04",
      "name": "Westmere Isles",
      "squadIds": [
        "p061",
        "p062",
        "p063",
        "p064",
        "p065",
        "p066",
        "p067",
        "p068",
        "p069",
        "p070",
        "p071",
        "p072",
        "p073",
        "p074",
        "p075",
        "p076",
        "p077",
        "p078",
        "p079",
        "p080"
      ],
      "colours": [
        "#433E79",
        "#E7CBE5"
      ]
    },
    {
      "teamId": "team-05",
      "name": "Ember Plains",
      "squadIds": [
        "p081",
        "p082",
        "p083",
        "p084",
        "p085",
        "p086",
        "p087",
        "p088",
        "p089",
        "p090",
        "p091",
        "p092",
        "p093",
        "p094",
        "p095",
        "p096",
        "p097",
        "p098",
        "p099",
        "p100"
      ],
      "colours": [
        "#A43D38",
        "#27282E"
      ]
    },
    {
      "teamId": "team-06",
      "name": "Silver Fen",
      "squadIds": [
        "p101",
        "p102",
        "p103",
        "p104",
        "p105",
        "p106",
        "p107",
        "p108",
        "p109",
        "p110",
        "p111",
        "p112",
        "p113",
        "p114",
        "p115",
        "p116",
        "p117",
        "p118",
        "p119",
        "p120"
      ],
      "colours": [
        "#5F7480",
        "#F3E6CA"
      ]
    },
    {
      "teamId": "team-07",
      "name": "Larchwood",
      "squadIds": [
        "p121",
        "p122",
        "p123",
        "p124",
        "p125",
        "p126",
        "p127",
        "p128",
        "p129",
        "p130",
        "p131",
        "p132",
        "p133",
        "p134",
        "p135",
        "p136",
        "p137",
        "p138",
        "p139",
        "p140"
      ],
      "colours": [
        "#395431",
        "#F3B76D"
      ]
    },
    {
      "teamId": "team-08",
      "name": "Moonstone Bay",
      "squadIds": [
        "p141",
        "p142",
        "p143",
        "p144",
        "p145",
        "p146",
        "p147",
        "p148",
        "p149",
        "p150",
        "p151",
        "p152",
        "p153",
        "p154",
        "p155",
        "p156",
        "p157",
        "p158",
        "p159",
        "p160"
      ],
      "colours": [
        "#2A5B69",
        "#D9DDEA"
      ]
    }
  ],
  "grounds": [
    {
      "groundId": "ground-01",
      "name": "Aster Quay",
      "pitchPrior": {
        "seamBp": 6177,
        "turnBp": 6532,
        "variabilityBp": 4835,
        "moistureBp": 5963,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        8098,
        7182,
        7420,
        8266,
        7479,
        7978,
        8045,
        6931
      ],
      "outfieldSpeedBp": 5243
    },
    {
      "groundId": "ground-02",
      "name": "Copperfield",
      "pitchPrior": {
        "seamBp": 3946,
        "turnBp": 5277,
        "variabilityBp": 3840,
        "moistureBp": 4647,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7475,
        8038,
        7893,
        7532,
        7948,
        7349,
        7019,
        7213
      ],
      "outfieldSpeedBp": 4077
    },
    {
      "groundId": "ground-03",
      "name": "Northlight Park",
      "pitchPrior": {
        "seamBp": 5887,
        "turnBp": 6027,
        "variabilityBp": 5931,
        "moistureBp": 5222,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7204,
        7872,
        7641,
        8200,
        7538,
        8077,
        7936,
        6875
      ],
      "outfieldSpeedBp": 4303
    },
    {
      "groundId": "ground-04",
      "name": "Westmere Oval",
      "pitchPrior": {
        "seamBp": 4070,
        "turnBp": 4899,
        "variabilityBp": 6441,
        "moistureBp": 4496,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7587,
        7191,
        8208,
        6975,
        8011,
        6864,
        8345,
        7383
      ],
      "outfieldSpeedBp": 4457
    },
    {
      "groundId": "ground-05",
      "name": "Ember Meadow",
      "pitchPrior": {
        "seamBp": 6866,
        "turnBp": 6651,
        "variabilityBp": 5198,
        "moistureBp": 5995,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7972,
        6928,
        7231,
        7988,
        7989,
        8065,
        7220,
        6729
      ],
      "outfieldSpeedBp": 4302
    },
    {
      "groundId": "ground-06",
      "name": "Silverfen",
      "pitchPrior": {
        "seamBp": 7299,
        "turnBp": 3602,
        "variabilityBp": 6252,
        "moistureBp": 4016,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        8174,
        7699,
        7499,
        7502,
        7661,
        8045,
        8337,
        7332
      ],
      "outfieldSpeedBp": 5892
    },
    {
      "groundId": "ground-07",
      "name": "Larchwood Ground",
      "pitchPrior": {
        "seamBp": 4864,
        "turnBp": 6232,
        "variabilityBp": 6003,
        "moistureBp": 4907,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        7244,
        7584,
        7976,
        7439,
        8089,
        8236,
        7218,
        7782
      ],
      "outfieldSpeedBp": 4289
    },
    {
      "groundId": "ground-08",
      "name": "Moonstone Fields",
      "pitchPrior": {
        "seamBp": 4567,
        "turnBp": 4791,
        "variabilityBp": 3999,
        "moistureBp": 4992,
        "wearPoints": 0
      },
      "sectorRadiiCm": [
        8089,
        6702,
        7226,
        7499,
        8292,
        7176,
        6829,
        7070
      ],
      "outfieldSpeedBp": 5114
    }
  ],
  "rulesIds": [
    "LC_T20_01",
    "LC_ODI_01",
    "LC_RED5_01"
  ],
  "provenance": "FICTIONAL: One-time offline SHA256_COUNTER_V1 WORLD_GENERATION seed; provisional SYNTHETIC_ALPHA skills, not empirical cricket."
}
`,Fc={worldPackId:"fictional-eight-01",schemaVersion:"1.0.0",worldGeneratorVersion:"LC_FICTIONAL_WORLD_GENERATOR_V1",worldSeed:"lcxxvi-fictional-eight-v1-20260927",generatorSourceSha256:"a3aaa4b64926ad9859f84222eb51274e7881df750308c2e9ae8fd1fa66e2f4da",provenanceSourceSha256:"97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",worldFileSha256:"0136173903ba42a199c84a17407cf711c2caf1b57c52472abb52e9be7a6d8257",worldCanonicalSha256:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",worldByteLength:310033,rulesIds:["LC_T20_01","LC_ODI_01","LC_RED5_01"],modelId:"synthetic-alpha-01",modelHash:"d47d5caca955b7a374b0052d712b1674bca6d855e222194ce9f0587d8580b7ab",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:"34efa3037702e44a134ea38b414eab3e97c6f79f10b3e5458bc2ab05412e5d7a",randomId:"SHA256_COUNTER_V1",variationIds:["stock"],provenance:"FICTIONAL",modelStatus:"SYNTHETIC_ALPHA",teamIds:["team-01","team-02","team-03","team-04","team-05","team-06","team-07","team-08"],groundIds:["ground-01","ground-02","ground-03","ground-04","ground-05","ground-06","ground-07","ground-08"],homeGroundIds:{"team-01":"ground-01","team-02":"ground-02","team-03":"ground-03","team-04":"ground-04","team-05":"ground-05","team-06":"ground-06","team-07":"ground-07","team-08":"ground-08"}};function B(n,e,t){function i(c,u){var p;Object.defineProperty(c,"_zod",{value:c._zod??{},enumerable:!1}),(p=c._zod).traits??(p.traits=new Set),c._zod.traits.add(n),e(c,u);for(const S in r.prototype)S in c||Object.defineProperty(c,S,{value:r.prototype[S].bind(c)});c._zod.constr=r,c._zod.def=u}const a=t?.Parent??Object;class o extends a{}Object.defineProperty(o,"name",{value:n});function r(c){var u;const p=t?.Parent?new o:this;i(p,c),(u=p._zod).deferred??(u.deferred=[]);for(const S of p._zod.deferred)S();return p}return Object.defineProperty(r,"init",{value:i}),Object.defineProperty(r,Symbol.hasInstance,{value:c=>t?.Parent&&c instanceof t.Parent?!0:c?._zod?.traits?.has(n)}),Object.defineProperty(r,"name",{value:n}),r}class Je extends Error{constructor(){super("Encountered Promise during synchronous parse. Use .parseAsync() instead.")}}class uo extends Error{constructor(e){super(`Encountered unidirectional transform during encode: ${e}`),this.name="ZodEncodeError"}}const bi={};function fe(n){return n&&Object.assign(bi,n),bi}function Hc(n){const e=Object.values(n).filter(i=>typeof i=="number");return Object.entries(n).filter(([i,a])=>e.indexOf(+i)===-1).map(([i,a])=>a)}function Ti(n,e){return typeof e=="bigint"?e.toString():e}function $t(n){return{get value(){{const e=n();return Object.defineProperty(this,"value",{value:e}),e}}}}function Ri(n){return n==null}function Li(n){const e=n.startsWith("^")?1:0,t=n.endsWith("$")?n.length-1:n.length;return n.slice(e,t)}function Mc(n,e){const t=(n.toString().split(".")[1]||"").length,i=e.toString();let a=(i.split(".")[1]||"").length;if(a===0&&/\d?e-\d?/.test(i)){const u=i.match(/\d?e-(\d?)/);u?.[1]&&(a=Number.parseInt(u[1]))}const o=t>a?t:a,r=Number.parseInt(n.toFixed(o).replace(".","")),c=Number.parseInt(e.toFixed(o).replace(".",""));return r%c/10**o}const mo=Symbol("evaluating");function sn(n,e,t){let i;Object.defineProperty(n,e,{get(){if(i!==mo)return i===void 0&&(i=mo,i=t()),i},set(a){Object.defineProperty(n,e,{value:a})},configurable:!0})}function $e(n,e,t){Object.defineProperty(n,e,{value:t,writable:!0,enumerable:!0,configurable:!0})}function We(...n){const e={};for(const t of n){const i=Object.getOwnPropertyDescriptors(t);Object.assign(e,i)}return Object.defineProperties({},e)}function go(n){return JSON.stringify(n)}const po="captureStackTrace"in Error?Error.captureStackTrace:(...n)=>{};function ht(n){return typeof n=="object"&&n!==null&&!Array.isArray(n)}const Vc=$t(()=>{if(typeof navigator<"u"&&navigator?.userAgent?.includes("Cloudflare"))return!1;try{const n=Function;return new n(""),!0}catch{return!1}});function Qe(n){if(ht(n)===!1)return!1;const e=n.constructor;if(e===void 0)return!0;const t=e.prototype;return!(ht(t)===!1||Object.prototype.hasOwnProperty.call(t,"isPrototypeOf")===!1)}function Io(n){return Qe(n)?{...n}:Array.isArray(n)?[...n]:n}const $c=new Set(["string","number","symbol"]);function nt(n){return n.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function we(n,e,t){const i=new n._zod.constr(e??n._zod.def);return(!e||t?.parent)&&(i._zod.parent=n),i}function z(n){const e=n;if(!e)return{};if(typeof e=="string")return{error:()=>e};if(e?.message!==void 0){if(e?.error!==void 0)throw new Error("Cannot specify both `message` and `error` params");e.error=e.message}return delete e.message,typeof e.error=="string"?{...e,error:()=>e.error}:e}function Wc(n){return Object.keys(n).filter(e=>n[e]._zod.optin==="optional"&&n[e]._zod.optout==="optional")}const Uc={safeint:[Number.MIN_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],int32:[-2147483648,2147483647],uint32:[0,4294967295],float32:[-34028234663852886e22,34028234663852886e22],float64:[-Number.MAX_VALUE,Number.MAX_VALUE]};function Gc(n,e){const t=n._zod.def,i=We(n._zod.def,{get shape(){const a={};for(const o in e){if(!(o in t.shape))throw new Error(`Unrecognized key: "${o}"`);e[o]&&(a[o]=t.shape[o])}return $e(this,"shape",a),a},checks:[]});return we(n,i)}function zc(n,e){const t=n._zod.def,i=We(n._zod.def,{get shape(){const a={...n._zod.def.shape};for(const o in e){if(!(o in t.shape))throw new Error(`Unrecognized key: "${o}"`);e[o]&&delete a[o]}return $e(this,"shape",a),a},checks:[]});return we(n,i)}function Kc(n,e){if(!Qe(e))throw new Error("Invalid input to extend: expected a plain object");const t=n._zod.def.checks;if(t&&t.length>0)throw new Error("Object schemas containing refinements cannot be extended. Use `.safeExtend()` instead.");const a=We(n._zod.def,{get shape(){const o={...n._zod.def.shape,...e};return $e(this,"shape",o),o},checks:[]});return we(n,a)}function Yc(n,e){if(!Qe(e))throw new Error("Invalid input to safeExtend: expected a plain object");const t={...n._zod.def,get shape(){const i={...n._zod.def.shape,...e};return $e(this,"shape",i),i},checks:n._zod.def.checks};return we(n,t)}function jc(n,e){const t=We(n._zod.def,{get shape(){const i={...n._zod.def.shape,...e._zod.def.shape};return $e(this,"shape",i),i},get catchall(){return e._zod.def.catchall},checks:[]});return we(n,t)}function Zc(n,e,t){const i=We(e._zod.def,{get shape(){const a=e._zod.def.shape,o={...a};if(t)for(const r in t){if(!(r in a))throw new Error(`Unrecognized key: "${r}"`);t[r]&&(o[r]=n?new n({type:"optional",innerType:a[r]}):a[r])}else for(const r in a)o[r]=n?new n({type:"optional",innerType:a[r]}):a[r];return $e(this,"shape",o),o},checks:[]});return we(e,i)}function Xc(n,e,t){const i=We(e._zod.def,{get shape(){const a=e._zod.def.shape,o={...a};if(t)for(const r in t){if(!(r in o))throw new Error(`Unrecognized key: "${r}"`);t[r]&&(o[r]=new n({type:"nonoptional",innerType:a[r]}))}else for(const r in a)o[r]=new n({type:"nonoptional",innerType:a[r]});return $e(this,"shape",o),o},checks:[]});return we(e,i)}function et(n,e=0){if(n.aborted===!0)return!0;for(let t=e;t<n.issues.length;t++)if(n.issues[t]?.continue!==!0)return!0;return!1}function Ue(n,e){return e.map(t=>{var i;return(i=t).path??(i.path=[]),t.path.unshift(n),t})}function Wt(n){return typeof n=="string"?n:n?.message}function Ne(n,e,t){const i={...n,path:n.path??[]};if(!n.message){const a=Wt(n.inst?._zod.def?.error?.(n))??Wt(e?.error?.(n))??Wt(t.customError?.(n))??Wt(t.localeError?.(n))??"Invalid input";i.message=a}return delete i.inst,delete i.continue,e?.reportInput||delete i.input,i}function Ai(n){return Array.isArray(n)?"array":typeof n=="string"?"string":"unknown"}function ft(...n){const[e,t,i]=n;return typeof e=="string"?{message:e,code:"custom",input:t,inst:i}:{...e}}const ho=(n,e)=>{n.name="$ZodError",Object.defineProperty(n,"_zod",{value:n._zod,enumerable:!1}),Object.defineProperty(n,"issues",{value:e,enumerable:!1}),n.message=JSON.stringify(e,Ti,2),Object.defineProperty(n,"toString",{value:()=>n.message,enumerable:!1})},fo=B("$ZodError",ho),Eo=B("$ZodError",ho,{Parent:Error});function qc(n,e=t=>t.message){const t={},i=[];for(const a of n.issues)a.path.length>0?(t[a.path[0]]=t[a.path[0]]||[],t[a.path[0]].push(e(a))):i.push(e(a));return{formErrors:i,fieldErrors:t}}function Jc(n,e=t=>t.message){const t={_errors:[]},i=a=>{for(const o of a.issues)if(o.code==="invalid_union"&&o.errors.length)o.errors.map(r=>i({issues:r}));else if(o.code==="invalid_key")i({issues:o.issues});else if(o.code==="invalid_element")i({issues:o.issues});else if(o.path.length===0)t._errors.push(e(o));else{let r=t,c=0;for(;c<o.path.length;){const u=o.path[c];c===o.path.length-1?(r[u]=r[u]||{_errors:[]},r[u]._errors.push(e(o))):r[u]=r[u]||{_errors:[]},r=r[u],c++}}};return i(n),t}const Oi=n=>(e,t,i,a)=>{const o=i?Object.assign(i,{async:!1}):{async:!1},r=e._zod.run({value:t,issues:[]},o);if(r instanceof Promise)throw new Je;if(r.issues.length){const c=new(a?.Err??n)(r.issues.map(u=>Ne(u,o,fe())));throw po(c,a?.callee),c}return r.value},wi=n=>async(e,t,i,a)=>{const o=i?Object.assign(i,{async:!0}):{async:!0};let r=e._zod.run({value:t,issues:[]},o);if(r instanceof Promise&&(r=await r),r.issues.length){const c=new(a?.Err??n)(r.issues.map(u=>Ne(u,o,fe())));throw po(c,a?.callee),c}return r.value},Ut=n=>(e,t,i)=>{const a=i?{...i,async:!1}:{async:!1},o=e._zod.run({value:t,issues:[]},a);if(o instanceof Promise)throw new Je;return o.issues.length?{success:!1,error:new(n??fo)(o.issues.map(r=>Ne(r,a,fe())))}:{success:!0,data:o.value}},Qc=Ut(Eo),Gt=n=>async(e,t,i)=>{const a=i?Object.assign(i,{async:!0}):{async:!0};let o=e._zod.run({value:t,issues:[]},a);return o instanceof Promise&&(o=await o),o.issues.length?{success:!1,error:new n(o.issues.map(r=>Ne(r,a,fe())))}:{success:!0,data:o.value}},nl=Gt(Eo),el=n=>(e,t,i)=>{const a=i?Object.assign(i,{direction:"backward"}):{direction:"backward"};return Oi(n)(e,t,a)},tl=n=>(e,t,i)=>Oi(n)(e,t,i),il=n=>async(e,t,i)=>{const a=i?Object.assign(i,{direction:"backward"}):{direction:"backward"};return wi(n)(e,t,a)},al=n=>async(e,t,i)=>wi(n)(e,t,i),ol=n=>(e,t,i)=>{const a=i?Object.assign(i,{direction:"backward"}):{direction:"backward"};return Ut(n)(e,t,a)},rl=n=>(e,t,i)=>Ut(n)(e,t,i),sl=n=>async(e,t,i)=>{const a=i?Object.assign(i,{direction:"backward"}):{direction:"backward"};return Gt(n)(e,t,a)},cl=n=>async(e,t,i)=>Gt(n)(e,t,i),ll=/^[cC][^\s-]{8,}$/,dl=/^[0-9a-z]+$/,ul=/^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/,ml=/^[0-9a-vA-V]{20}$/,gl=/^[A-Za-z0-9]{27}$/,pl=/^[a-zA-Z0-9_-]{21}$/,Il=/^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/,hl=/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/,So=n=>n?new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${n}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`):/^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/,fl=/^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/,El="^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";function Sl(){return new RegExp(El,"u")}const _l=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,vl=/^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/,bl=/^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/,Tl=/^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,Rl=/^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/,_o=/^[A-Za-z0-9_-]*$/,Ll=/^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/,Al=/^\+(?:[0-9]){6,14}[0-9]$/,vo="(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))",Ol=new RegExp(`^${vo}$`);function bo(n){const e="(?:[01]\\d|2[0-3]):[0-5]\\d";return typeof n.precision=="number"?n.precision===-1?`${e}`:n.precision===0?`${e}:[0-5]\\d`:`${e}:[0-5]\\d\\.\\d{${n.precision}}`:`${e}(?::[0-5]\\d(?:\\.\\d+)?)?`}function wl(n){return new RegExp(`^${bo(n)}$`)}function Nl(n){const e=bo({precision:n.precision}),t=["Z"];n.local&&t.push(""),n.offset&&t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");const i=`${e}(?:${t.join("|")})`;return new RegExp(`^${vo}T(?:${i})$`)}const Dl=n=>{const e=n?`[\\s\\S]{${n?.minimum??0},${n?.maximum??""}}`:"[\\s\\S]*";return new RegExp(`^${e}$`)},Cl=/^-?\d+$/,yl=/^-?\d+(?:\.\d+)?/,kl=/^(?:true|false)$/i,Bl=/^null$/i,Pl=/^[^A-Z]*$/,xl=/^[^a-z]*$/,Gn=B("$ZodCheck",(n,e)=>{var t;n._zod??(n._zod={}),n._zod.def=e,(t=n._zod).onattach??(t.onattach=[])}),To={number:"number",bigint:"bigint",object:"date"},Ro=B("$ZodCheckLessThan",(n,e)=>{Gn.init(n,e);const t=To[typeof e.value];n._zod.onattach.push(i=>{const a=i._zod.bag,o=(e.inclusive?a.maximum:a.exclusiveMaximum)??Number.POSITIVE_INFINITY;e.value<o&&(e.inclusive?a.maximum=e.value:a.exclusiveMaximum=e.value)}),n._zod.check=i=>{(e.inclusive?i.value<=e.value:i.value<e.value)||i.issues.push({origin:t,code:"too_big",maximum:e.value,input:i.value,inclusive:e.inclusive,inst:n,continue:!e.abort})}}),Lo=B("$ZodCheckGreaterThan",(n,e)=>{Gn.init(n,e);const t=To[typeof e.value];n._zod.onattach.push(i=>{const a=i._zod.bag,o=(e.inclusive?a.minimum:a.exclusiveMinimum)??Number.NEGATIVE_INFINITY;e.value>o&&(e.inclusive?a.minimum=e.value:a.exclusiveMinimum=e.value)}),n._zod.check=i=>{(e.inclusive?i.value>=e.value:i.value>e.value)||i.issues.push({origin:t,code:"too_small",minimum:e.value,input:i.value,inclusive:e.inclusive,inst:n,continue:!e.abort})}}),Fl=B("$ZodCheckMultipleOf",(n,e)=>{Gn.init(n,e),n._zod.onattach.push(t=>{var i;(i=t._zod.bag).multipleOf??(i.multipleOf=e.value)}),n._zod.check=t=>{if(typeof t.value!=typeof e.value)throw new Error("Cannot mix number and bigint in multiple_of check.");(typeof t.value=="bigint"?t.value%e.value===BigInt(0):Mc(t.value,e.value)===0)||t.issues.push({origin:typeof t.value,code:"not_multiple_of",divisor:e.value,input:t.value,inst:n,continue:!e.abort})}}),Hl=B("$ZodCheckNumberFormat",(n,e)=>{Gn.init(n,e),e.format=e.format||"float64";const t=e.format?.includes("int"),i=t?"int":"number",[a,o]=Uc[e.format];n._zod.onattach.push(r=>{const c=r._zod.bag;c.format=e.format,c.minimum=a,c.maximum=o,t&&(c.pattern=Cl)}),n._zod.check=r=>{const c=r.value;if(t){if(!Number.isInteger(c)){r.issues.push({expected:i,format:e.format,code:"invalid_type",continue:!1,input:c,inst:n});return}if(!Number.isSafeInteger(c)){c>0?r.issues.push({input:c,code:"too_big",maximum:Number.MAX_SAFE_INTEGER,note:"Integers must be within the safe integer range.",inst:n,origin:i,continue:!e.abort}):r.issues.push({input:c,code:"too_small",minimum:Number.MIN_SAFE_INTEGER,note:"Integers must be within the safe integer range.",inst:n,origin:i,continue:!e.abort});return}}c<a&&r.issues.push({origin:"number",input:c,code:"too_small",minimum:a,inclusive:!0,inst:n,continue:!e.abort}),c>o&&r.issues.push({origin:"number",input:c,code:"too_big",maximum:o,inst:n})}}),Ml=B("$ZodCheckMaxLength",(n,e)=>{var t;Gn.init(n,e),(t=n._zod.def).when??(t.when=i=>{const a=i.value;return!Ri(a)&&a.length!==void 0}),n._zod.onattach.push(i=>{const a=i._zod.bag.maximum??Number.POSITIVE_INFINITY;e.maximum<a&&(i._zod.bag.maximum=e.maximum)}),n._zod.check=i=>{const a=i.value;if(a.length<=e.maximum)return;const r=Ai(a);i.issues.push({origin:r,code:"too_big",maximum:e.maximum,inclusive:!0,input:a,inst:n,continue:!e.abort})}}),Vl=B("$ZodCheckMinLength",(n,e)=>{var t;Gn.init(n,e),(t=n._zod.def).when??(t.when=i=>{const a=i.value;return!Ri(a)&&a.length!==void 0}),n._zod.onattach.push(i=>{const a=i._zod.bag.minimum??Number.NEGATIVE_INFINITY;e.minimum>a&&(i._zod.bag.minimum=e.minimum)}),n._zod.check=i=>{const a=i.value;if(a.length>=e.minimum)return;const r=Ai(a);i.issues.push({origin:r,code:"too_small",minimum:e.minimum,inclusive:!0,input:a,inst:n,continue:!e.abort})}}),$l=B("$ZodCheckLengthEquals",(n,e)=>{var t;Gn.init(n,e),(t=n._zod.def).when??(t.when=i=>{const a=i.value;return!Ri(a)&&a.length!==void 0}),n._zod.onattach.push(i=>{const a=i._zod.bag;a.minimum=e.length,a.maximum=e.length,a.length=e.length}),n._zod.check=i=>{const a=i.value,o=a.length;if(o===e.length)return;const r=Ai(a),c=o>e.length;i.issues.push({origin:r,...c?{code:"too_big",maximum:e.length}:{code:"too_small",minimum:e.length},inclusive:!0,exact:!0,input:i.value,inst:n,continue:!e.abort})}}),zt=B("$ZodCheckStringFormat",(n,e)=>{var t,i;Gn.init(n,e),n._zod.onattach.push(a=>{const o=a._zod.bag;o.format=e.format,e.pattern&&(o.patterns??(o.patterns=new Set),o.patterns.add(e.pattern))}),e.pattern?(t=n._zod).check??(t.check=a=>{e.pattern.lastIndex=0,!e.pattern.test(a.value)&&a.issues.push({origin:"string",code:"invalid_format",format:e.format,input:a.value,...e.pattern?{pattern:e.pattern.toString()}:{},inst:n,continue:!e.abort})}):(i=n._zod).check??(i.check=()=>{})}),Wl=B("$ZodCheckRegex",(n,e)=>{zt.init(n,e),n._zod.check=t=>{e.pattern.lastIndex=0,!e.pattern.test(t.value)&&t.issues.push({origin:"string",code:"invalid_format",format:"regex",input:t.value,pattern:e.pattern.toString(),inst:n,continue:!e.abort})}}),Ul=B("$ZodCheckLowerCase",(n,e)=>{e.pattern??(e.pattern=Pl),zt.init(n,e)}),Gl=B("$ZodCheckUpperCase",(n,e)=>{e.pattern??(e.pattern=xl),zt.init(n,e)}),zl=B("$ZodCheckIncludes",(n,e)=>{Gn.init(n,e);const t=nt(e.includes),i=new RegExp(typeof e.position=="number"?`^.{${e.position}}${t}`:t);e.pattern=i,n._zod.onattach.push(a=>{const o=a._zod.bag;o.patterns??(o.patterns=new Set),o.patterns.add(i)}),n._zod.check=a=>{a.value.includes(e.includes,e.position)||a.issues.push({origin:"string",code:"invalid_format",format:"includes",includes:e.includes,input:a.value,inst:n,continue:!e.abort})}}),Kl=B("$ZodCheckStartsWith",(n,e)=>{Gn.init(n,e);const t=new RegExp(`^${nt(e.prefix)}.*`);e.pattern??(e.pattern=t),n._zod.onattach.push(i=>{const a=i._zod.bag;a.patterns??(a.patterns=new Set),a.patterns.add(t)}),n._zod.check=i=>{i.value.startsWith(e.prefix)||i.issues.push({origin:"string",code:"invalid_format",format:"starts_with",prefix:e.prefix,input:i.value,inst:n,continue:!e.abort})}}),Yl=B("$ZodCheckEndsWith",(n,e)=>{Gn.init(n,e);const t=new RegExp(`.*${nt(e.suffix)}$`);e.pattern??(e.pattern=t),n._zod.onattach.push(i=>{const a=i._zod.bag;a.patterns??(a.patterns=new Set),a.patterns.add(t)}),n._zod.check=i=>{i.value.endsWith(e.suffix)||i.issues.push({origin:"string",code:"invalid_format",format:"ends_with",suffix:e.suffix,input:i.value,inst:n,continue:!e.abort})}}),jl=B("$ZodCheckOverwrite",(n,e)=>{Gn.init(n,e),n._zod.check=t=>{t.value=e.tx(t.value)}});class Zl{constructor(e=[]){this.content=[],this.indent=0,this&&(this.args=e)}indented(e){this.indent+=1,e(this),this.indent-=1}write(e){if(typeof e=="function"){e(this,{execution:"sync"}),e(this,{execution:"async"});return}const i=e.split(`
`).filter(r=>r),a=Math.min(...i.map(r=>r.length-r.trimStart().length)),o=i.map(r=>r.slice(a)).map(r=>" ".repeat(this.indent*2)+r);for(const r of o)this.content.push(r)}compile(){const e=Function,t=this?.args,a=[...(this?.content??[""]).map(o=>`  ${o}`)];return new e(...t,a.join(`
`))}}const Xl={major:4,minor:1,patch:12},mn=B("$ZodType",(n,e)=>{var t;n??(n={}),n._zod.def=e,n._zod.bag=n._zod.bag||{},n._zod.version=Xl;const i=[...n._zod.def.checks??[]];n._zod.traits.has("$ZodCheck")&&i.unshift(n);for(const a of i)for(const o of a._zod.onattach)o(n);if(i.length===0)(t=n._zod).deferred??(t.deferred=[]),n._zod.deferred?.push(()=>{n._zod.run=n._zod.parse});else{const a=(r,c,u)=>{let p=et(r),S;for(const h of c){if(h._zod.def.when){if(!h._zod.def.when(r))continue}else if(p)continue;const A=r.issues.length,N=h._zod.check(r);if(N instanceof Promise&&u?.async===!1)throw new Je;if(S||N instanceof Promise)S=(S??Promise.resolve()).then(async()=>{await N,r.issues.length!==A&&(p||(p=et(r,A)))});else{if(r.issues.length===A)continue;p||(p=et(r,A))}}return S?S.then(()=>r):r},o=(r,c,u)=>{if(et(r))return r.aborted=!0,r;const p=a(c,i,u);if(p instanceof Promise){if(u.async===!1)throw new Je;return p.then(S=>n._zod.parse(S,u))}return n._zod.parse(p,u)};n._zod.run=(r,c)=>{if(c.skipChecks)return n._zod.parse(r,c);if(c.direction==="backward"){const p=n._zod.parse({value:r.value,issues:[]},{...c,skipChecks:!0});return p instanceof Promise?p.then(S=>o(S,r,c)):o(p,r,c)}const u=n._zod.parse(r,c);if(u instanceof Promise){if(c.async===!1)throw new Je;return u.then(p=>a(p,i,c))}return a(u,i,c)}}n["~standard"]={validate:a=>{try{const o=Qc(n,a);return o.success?{value:o.data}:{issues:o.error?.issues}}catch{return nl(n,a).then(r=>r.success?{value:r.data}:{issues:r.error?.issues})}},vendor:"zod",version:1}}),Ni=B("$ZodString",(n,e)=>{mn.init(n,e),n._zod.pattern=[...n?._zod.bag?.patterns??[]].pop()??Dl(n._zod.bag),n._zod.parse=(t,i)=>{if(e.coerce)try{t.value=String(t.value)}catch{}return typeof t.value=="string"||t.issues.push({expected:"string",code:"invalid_type",input:t.value,inst:n}),t}}),Sn=B("$ZodStringFormat",(n,e)=>{zt.init(n,e),Ni.init(n,e)}),ql=B("$ZodGUID",(n,e)=>{e.pattern??(e.pattern=hl),Sn.init(n,e)}),Jl=B("$ZodUUID",(n,e)=>{if(e.version){const i={v1:1,v2:2,v3:3,v4:4,v5:5,v6:6,v7:7,v8:8}[e.version];if(i===void 0)throw new Error(`Invalid UUID version: "${e.version}"`);e.pattern??(e.pattern=So(i))}else e.pattern??(e.pattern=So());Sn.init(n,e)}),Ql=B("$ZodEmail",(n,e)=>{e.pattern??(e.pattern=fl),Sn.init(n,e)}),nd=B("$ZodURL",(n,e)=>{Sn.init(n,e),n._zod.check=t=>{try{const i=t.value.trim(),a=new URL(i);e.hostname&&(e.hostname.lastIndex=0,e.hostname.test(a.hostname)||t.issues.push({code:"invalid_format",format:"url",note:"Invalid hostname",pattern:Ll.source,input:t.value,inst:n,continue:!e.abort})),e.protocol&&(e.protocol.lastIndex=0,e.protocol.test(a.protocol.endsWith(":")?a.protocol.slice(0,-1):a.protocol)||t.issues.push({code:"invalid_format",format:"url",note:"Invalid protocol",pattern:e.protocol.source,input:t.value,inst:n,continue:!e.abort})),e.normalize?t.value=a.href:t.value=i;return}catch{t.issues.push({code:"invalid_format",format:"url",input:t.value,inst:n,continue:!e.abort})}}}),ed=B("$ZodEmoji",(n,e)=>{e.pattern??(e.pattern=Sl()),Sn.init(n,e)}),td=B("$ZodNanoID",(n,e)=>{e.pattern??(e.pattern=pl),Sn.init(n,e)}),id=B("$ZodCUID",(n,e)=>{e.pattern??(e.pattern=ll),Sn.init(n,e)}),ad=B("$ZodCUID2",(n,e)=>{e.pattern??(e.pattern=dl),Sn.init(n,e)}),od=B("$ZodULID",(n,e)=>{e.pattern??(e.pattern=ul),Sn.init(n,e)}),rd=B("$ZodXID",(n,e)=>{e.pattern??(e.pattern=ml),Sn.init(n,e)}),sd=B("$ZodKSUID",(n,e)=>{e.pattern??(e.pattern=gl),Sn.init(n,e)}),cd=B("$ZodISODateTime",(n,e)=>{e.pattern??(e.pattern=Nl(e)),Sn.init(n,e)}),ld=B("$ZodISODate",(n,e)=>{e.pattern??(e.pattern=Ol),Sn.init(n,e)}),dd=B("$ZodISOTime",(n,e)=>{e.pattern??(e.pattern=wl(e)),Sn.init(n,e)}),ud=B("$ZodISODuration",(n,e)=>{e.pattern??(e.pattern=Il),Sn.init(n,e)}),md=B("$ZodIPv4",(n,e)=>{e.pattern??(e.pattern=_l),Sn.init(n,e),n._zod.onattach.push(t=>{const i=t._zod.bag;i.format="ipv4"})}),gd=B("$ZodIPv6",(n,e)=>{e.pattern??(e.pattern=vl),Sn.init(n,e),n._zod.onattach.push(t=>{const i=t._zod.bag;i.format="ipv6"}),n._zod.check=t=>{try{new URL(`http://[${t.value}]`)}catch{t.issues.push({code:"invalid_format",format:"ipv6",input:t.value,inst:n,continue:!e.abort})}}}),pd=B("$ZodCIDRv4",(n,e)=>{e.pattern??(e.pattern=bl),Sn.init(n,e)}),Id=B("$ZodCIDRv6",(n,e)=>{e.pattern??(e.pattern=Tl),Sn.init(n,e),n._zod.check=t=>{const i=t.value.split("/");try{if(i.length!==2)throw new Error;const[a,o]=i;if(!o)throw new Error;const r=Number(o);if(`${r}`!==o)throw new Error;if(r<0||r>128)throw new Error;new URL(`http://[${a}]`)}catch{t.issues.push({code:"invalid_format",format:"cidrv6",input:t.value,inst:n,continue:!e.abort})}}});function Ao(n){if(n==="")return!0;if(n.length%4!==0)return!1;try{return atob(n),!0}catch{return!1}}const hd=B("$ZodBase64",(n,e)=>{e.pattern??(e.pattern=Rl),Sn.init(n,e),n._zod.onattach.push(t=>{t._zod.bag.contentEncoding="base64"}),n._zod.check=t=>{Ao(t.value)||t.issues.push({code:"invalid_format",format:"base64",input:t.value,inst:n,continue:!e.abort})}});function fd(n){if(!_o.test(n))return!1;const e=n.replace(/[-_]/g,i=>i==="-"?"+":"/"),t=e.padEnd(Math.ceil(e.length/4)*4,"=");return Ao(t)}const Ed=B("$ZodBase64URL",(n,e)=>{e.pattern??(e.pattern=_o),Sn.init(n,e),n._zod.onattach.push(t=>{t._zod.bag.contentEncoding="base64url"}),n._zod.check=t=>{fd(t.value)||t.issues.push({code:"invalid_format",format:"base64url",input:t.value,inst:n,continue:!e.abort})}}),Sd=B("$ZodE164",(n,e)=>{e.pattern??(e.pattern=Al),Sn.init(n,e)});function _d(n,e=null){try{const t=n.split(".");if(t.length!==3)return!1;const[i]=t;if(!i)return!1;const a=JSON.parse(atob(i));return!("typ"in a&&a?.typ!=="JWT"||!a.alg||e&&(!("alg"in a)||a.alg!==e))}catch{return!1}}const vd=B("$ZodJWT",(n,e)=>{Sn.init(n,e),n._zod.check=t=>{_d(t.value,e.alg)||t.issues.push({code:"invalid_format",format:"jwt",input:t.value,inst:n,continue:!e.abort})}}),Oo=B("$ZodNumber",(n,e)=>{mn.init(n,e),n._zod.pattern=n._zod.bag.pattern??yl,n._zod.parse=(t,i)=>{if(e.coerce)try{t.value=Number(t.value)}catch{}const a=t.value;if(typeof a=="number"&&!Number.isNaN(a)&&Number.isFinite(a))return t;const o=typeof a=="number"?Number.isNaN(a)?"NaN":Number.isFinite(a)?void 0:"Infinity":void 0;return t.issues.push({expected:"number",code:"invalid_type",input:a,inst:n,...o?{received:o}:{}}),t}}),bd=B("$ZodNumber",(n,e)=>{Hl.init(n,e),Oo.init(n,e)}),Td=B("$ZodBoolean",(n,e)=>{mn.init(n,e),n._zod.pattern=kl,n._zod.parse=(t,i)=>{if(e.coerce)try{t.value=!!t.value}catch{}const a=t.value;return typeof a=="boolean"||t.issues.push({expected:"boolean",code:"invalid_type",input:a,inst:n}),t}}),Rd=B("$ZodNull",(n,e)=>{mn.init(n,e),n._zod.pattern=Bl,n._zod.values=new Set([null]),n._zod.parse=(t,i)=>{const a=t.value;return a===null||t.issues.push({expected:"null",code:"invalid_type",input:a,inst:n}),t}}),Ld=B("$ZodUnknown",(n,e)=>{mn.init(n,e),n._zod.parse=t=>t}),Ad=B("$ZodNever",(n,e)=>{mn.init(n,e),n._zod.parse=(t,i)=>(t.issues.push({expected:"never",code:"invalid_type",input:t.value,inst:n}),t)});function wo(n,e,t){n.issues.length&&e.issues.push(...Ue(t,n.issues)),e.value[t]=n.value}const Od=B("$ZodArray",(n,e)=>{mn.init(n,e),n._zod.parse=(t,i)=>{const a=t.value;if(!Array.isArray(a))return t.issues.push({expected:"array",code:"invalid_type",input:a,inst:n}),t;t.value=Array(a.length);const o=[];for(let r=0;r<a.length;r++){const c=a[r],u=e.element._zod.run({value:c,issues:[]},i);u instanceof Promise?o.push(u.then(p=>wo(p,t,r))):wo(u,t,r)}return o.length?Promise.all(o).then(()=>t):t}});function Kt(n,e,t,i){n.issues.length&&e.issues.push(...Ue(t,n.issues)),n.value===void 0?t in i&&(e.value[t]=void 0):e.value[t]=n.value}function No(n){const e=Object.keys(n.shape);for(const i of e)if(!n.shape?.[i]?._zod?.traits?.has("$ZodType"))throw new Error(`Invalid element at key "${i}": expected a Zod schema`);const t=Wc(n.shape);return{...n,keys:e,keySet:new Set(e),numKeys:e.length,optionalKeys:new Set(t)}}function Do(n,e,t,i,a,o){const r=[],c=a.keySet,u=a.catchall._zod,p=u.def.type;for(const S of Object.keys(e)){if(c.has(S))continue;if(p==="never"){r.push(S);continue}const h=u.run({value:e[S],issues:[]},i);h instanceof Promise?n.push(h.then(A=>Kt(A,t,S,e))):Kt(h,t,S,e)}return r.length&&t.issues.push({code:"unrecognized_keys",keys:r,input:e,inst:o}),n.length?Promise.all(n).then(()=>t):t}const wd=B("$ZodObject",(n,e)=>{if(mn.init(n,e),!Object.getOwnPropertyDescriptor(e,"shape")?.get){const c=e.shape;Object.defineProperty(e,"shape",{get:()=>{const u={...c};return Object.defineProperty(e,"shape",{value:u}),u}})}const i=$t(()=>No(e));sn(n._zod,"propValues",()=>{const c=e.shape,u={};for(const p in c){const S=c[p]._zod;if(S.values){u[p]??(u[p]=new Set);for(const h of S.values)u[p].add(h)}}return u});const a=ht,o=e.catchall;let r;n._zod.parse=(c,u)=>{r??(r=i.value);const p=c.value;if(!a(p))return c.issues.push({expected:"object",code:"invalid_type",input:p,inst:n}),c;c.value={};const S=[],h=r.shape;for(const A of r.keys){const y=h[A]._zod.run({value:p[A],issues:[]},u);y instanceof Promise?S.push(y.then(L=>Kt(L,c,A,p))):Kt(y,c,A,p)}return o?Do(S,p,c,u,i.value,n):S.length?Promise.all(S).then(()=>c):c}}),Nd=B("$ZodObjectJIT",(n,e)=>{wd.init(n,e);const t=n._zod.parse,i=$t(()=>No(e)),a=A=>{const N=new Zl(["shape","payload","ctx"]),y=i.value,L=I=>{const _=go(I);return`shape[${_}]._zod.run({ value: input[${_}], issues: [] }, ctx)`};N.write("const input = payload.value;");const E=Object.create(null);let T=0;for(const I of y.keys)E[I]=`key_${T++}`;N.write("const newResult = {};");for(const I of y.keys){const _=E[I],C=go(I);N.write(`const ${_} = ${L(I)};`),N.write(`
        if (${_}.issues.length) {
          payload.issues = payload.issues.concat(${_}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${C}, ...iss.path] : [${C}]
          })));
        }
        
        
        if (${_}.value === undefined) {
          if (${C} in input) {
            newResult[${C}] = undefined;
          }
        } else {
          newResult[${C}] = ${_}.value;
        }
        
      `)}N.write("payload.value = newResult;"),N.write("return payload;");const g=N.compile();return(I,_)=>g(A,I,_)};let o;const r=ht,c=!bi.jitless,p=c&&Vc.value,S=e.catchall;let h;n._zod.parse=(A,N)=>{h??(h=i.value);const y=A.value;return r(y)?c&&p&&N?.async===!1&&N.jitless!==!0?(o||(o=a(e.shape)),A=o(A,N),S?Do([],y,A,N,h,n):A):t(A,N):(A.issues.push({expected:"object",code:"invalid_type",input:y,inst:n}),A)}});function Co(n,e,t,i){for(const o of n)if(o.issues.length===0)return e.value=o.value,e;const a=n.filter(o=>!et(o));return a.length===1?(e.value=a[0].value,a[0]):(e.issues.push({code:"invalid_union",input:e.value,inst:t,errors:n.map(o=>o.issues.map(r=>Ne(r,i,fe())))}),e)}const yo=B("$ZodUnion",(n,e)=>{mn.init(n,e),sn(n._zod,"optin",()=>e.options.some(a=>a._zod.optin==="optional")?"optional":void 0),sn(n._zod,"optout",()=>e.options.some(a=>a._zod.optout==="optional")?"optional":void 0),sn(n._zod,"values",()=>{if(e.options.every(a=>a._zod.values))return new Set(e.options.flatMap(a=>Array.from(a._zod.values)))}),sn(n._zod,"pattern",()=>{if(e.options.every(a=>a._zod.pattern)){const a=e.options.map(o=>o._zod.pattern);return new RegExp(`^(${a.map(o=>Li(o.source)).join("|")})$`)}});const t=e.options.length===1,i=e.options[0]._zod.run;n._zod.parse=(a,o)=>{if(t)return i(a,o);let r=!1;const c=[];for(const u of e.options){const p=u._zod.run({value:a.value,issues:[]},o);if(p instanceof Promise)c.push(p),r=!0;else{if(p.issues.length===0)return p;c.push(p)}}return r?Promise.all(c).then(u=>Co(u,a,n,o)):Co(c,a,n,o)}}),Dd=B("$ZodDiscriminatedUnion",(n,e)=>{yo.init(n,e);const t=n._zod.parse;sn(n._zod,"propValues",()=>{const a={};for(const o of e.options){const r=o._zod.propValues;if(!r||Object.keys(r).length===0)throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(o)}"`);for(const[c,u]of Object.entries(r)){a[c]||(a[c]=new Set);for(const p of u)a[c].add(p)}}return a});const i=$t(()=>{const a=e.options,o=new Map;for(const r of a){const c=r._zod.propValues?.[e.discriminator];if(!c||c.size===0)throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(r)}"`);for(const u of c){if(o.has(u))throw new Error(`Duplicate discriminator value "${String(u)}"`);o.set(u,r)}}return o});n._zod.parse=(a,o)=>{const r=a.value;if(!ht(r))return a.issues.push({code:"invalid_type",expected:"object",input:r,inst:n}),a;const c=i.value.get(r?.[e.discriminator]);return c?c._zod.run(a,o):e.unionFallback?t(a,o):(a.issues.push({code:"invalid_union",errors:[],note:"No matching discriminator",discriminator:e.discriminator,input:r,path:[e.discriminator],inst:n}),a)}}),Cd=B("$ZodIntersection",(n,e)=>{mn.init(n,e),n._zod.parse=(t,i)=>{const a=t.value,o=e.left._zod.run({value:a,issues:[]},i),r=e.right._zod.run({value:a,issues:[]},i);return o instanceof Promise||r instanceof Promise?Promise.all([o,r]).then(([u,p])=>ko(t,u,p)):ko(t,o,r)}});function Di(n,e){if(n===e)return{valid:!0,data:n};if(n instanceof Date&&e instanceof Date&&+n==+e)return{valid:!0,data:n};if(Qe(n)&&Qe(e)){const t=Object.keys(e),i=Object.keys(n).filter(o=>t.indexOf(o)!==-1),a={...n,...e};for(const o of i){const r=Di(n[o],e[o]);if(!r.valid)return{valid:!1,mergeErrorPath:[o,...r.mergeErrorPath]};a[o]=r.data}return{valid:!0,data:a}}if(Array.isArray(n)&&Array.isArray(e)){if(n.length!==e.length)return{valid:!1,mergeErrorPath:[]};const t=[];for(let i=0;i<n.length;i++){const a=n[i],o=e[i],r=Di(a,o);if(!r.valid)return{valid:!1,mergeErrorPath:[i,...r.mergeErrorPath]};t.push(r.data)}return{valid:!0,data:t}}return{valid:!1,mergeErrorPath:[]}}function ko(n,e,t){if(e.issues.length&&n.issues.push(...e.issues),t.issues.length&&n.issues.push(...t.issues),et(n))return n;const i=Di(e.value,t.value);if(!i.valid)throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(i.mergeErrorPath)}`);return n.value=i.data,n}const yd=B("$ZodTuple",(n,e)=>{mn.init(n,e);const t=e.items,i=t.length-[...t].reverse().findIndex(a=>a._zod.optin!=="optional");n._zod.parse=(a,o)=>{const r=a.value;if(!Array.isArray(r))return a.issues.push({input:r,inst:n,expected:"tuple",code:"invalid_type"}),a;a.value=[];const c=[];if(!e.rest){const p=r.length>t.length,S=r.length<i-1;if(p||S)return a.issues.push({...p?{code:"too_big",maximum:t.length}:{code:"too_small",minimum:t.length},input:r,inst:n,origin:"array"}),a}let u=-1;for(const p of t){if(u++,u>=r.length&&u>=i)continue;const S=p._zod.run({value:r[u],issues:[]},o);S instanceof Promise?c.push(S.then(h=>Yt(h,a,u))):Yt(S,a,u)}if(e.rest){const p=r.slice(t.length);for(const S of p){u++;const h=e.rest._zod.run({value:S,issues:[]},o);h instanceof Promise?c.push(h.then(A=>Yt(A,a,u))):Yt(h,a,u)}}return c.length?Promise.all(c).then(()=>a):a}});function Yt(n,e,t){n.issues.length&&e.issues.push(...Ue(t,n.issues)),e.value[t]=n.value}const kd=B("$ZodRecord",(n,e)=>{mn.init(n,e),n._zod.parse=(t,i)=>{const a=t.value;if(!Qe(a))return t.issues.push({expected:"record",code:"invalid_type",input:a,inst:n}),t;const o=[];if(e.keyType._zod.values){const r=e.keyType._zod.values;t.value={};for(const u of r)if(typeof u=="string"||typeof u=="number"||typeof u=="symbol"){const p=e.valueType._zod.run({value:a[u],issues:[]},i);p instanceof Promise?o.push(p.then(S=>{S.issues.length&&t.issues.push(...Ue(u,S.issues)),t.value[u]=S.value})):(p.issues.length&&t.issues.push(...Ue(u,p.issues)),t.value[u]=p.value)}let c;for(const u in a)r.has(u)||(c=c??[],c.push(u));c&&c.length>0&&t.issues.push({code:"unrecognized_keys",input:a,inst:n,keys:c})}else{t.value={};for(const r of Reflect.ownKeys(a)){if(r==="__proto__")continue;const c=e.keyType._zod.run({value:r,issues:[]},i);if(c instanceof Promise)throw new Error("Async schemas not supported in object keys currently");if(c.issues.length){t.issues.push({code:"invalid_key",origin:"record",issues:c.issues.map(p=>Ne(p,i,fe())),input:r,path:[r],inst:n}),t.value[c.value]=c.value;continue}const u=e.valueType._zod.run({value:a[r],issues:[]},i);u instanceof Promise?o.push(u.then(p=>{p.issues.length&&t.issues.push(...Ue(r,p.issues)),t.value[c.value]=p.value})):(u.issues.length&&t.issues.push(...Ue(r,u.issues)),t.value[c.value]=u.value)}}return o.length?Promise.all(o).then(()=>t):t}}),Bd=B("$ZodEnum",(n,e)=>{mn.init(n,e);const t=Hc(e.entries),i=new Set(t);n._zod.values=i,n._zod.pattern=new RegExp(`^(${t.filter(a=>$c.has(typeof a)).map(a=>typeof a=="string"?nt(a):a.toString()).join("|")})$`),n._zod.parse=(a,o)=>{const r=a.value;return i.has(r)||a.issues.push({code:"invalid_value",values:t,input:r,inst:n}),a}}),Pd=B("$ZodLiteral",(n,e)=>{if(mn.init(n,e),e.values.length===0)throw new Error("Cannot create literal schema with no valid values");n._zod.values=new Set(e.values),n._zod.pattern=new RegExp(`^(${e.values.map(t=>typeof t=="string"?nt(t):t?nt(t.toString()):String(t)).join("|")})$`),n._zod.parse=(t,i)=>{const a=t.value;return n._zod.values.has(a)||t.issues.push({code:"invalid_value",values:e.values,input:a,inst:n}),t}}),xd=B("$ZodTransform",(n,e)=>{mn.init(n,e),n._zod.parse=(t,i)=>{if(i.direction==="backward")throw new uo(n.constructor.name);const a=e.transform(t.value,t);if(i.async)return(a instanceof Promise?a:Promise.resolve(a)).then(r=>(t.value=r,t));if(a instanceof Promise)throw new Je;return t.value=a,t}});function Bo(n,e){return n.issues.length&&e===void 0?{issues:[],value:void 0}:n}const Fd=B("$ZodOptional",(n,e)=>{mn.init(n,e),n._zod.optin="optional",n._zod.optout="optional",sn(n._zod,"values",()=>e.innerType._zod.values?new Set([...e.innerType._zod.values,void 0]):void 0),sn(n._zod,"pattern",()=>{const t=e.innerType._zod.pattern;return t?new RegExp(`^(${Li(t.source)})?$`):void 0}),n._zod.parse=(t,i)=>{if(e.innerType._zod.optin==="optional"){const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(o=>Bo(o,t.value)):Bo(a,t.value)}return t.value===void 0?t:e.innerType._zod.run(t,i)}}),Hd=B("$ZodNullable",(n,e)=>{mn.init(n,e),sn(n._zod,"optin",()=>e.innerType._zod.optin),sn(n._zod,"optout",()=>e.innerType._zod.optout),sn(n._zod,"pattern",()=>{const t=e.innerType._zod.pattern;return t?new RegExp(`^(${Li(t.source)}|null)$`):void 0}),sn(n._zod,"values",()=>e.innerType._zod.values?new Set([...e.innerType._zod.values,null]):void 0),n._zod.parse=(t,i)=>t.value===null?t:e.innerType._zod.run(t,i)}),Md=B("$ZodDefault",(n,e)=>{mn.init(n,e),n._zod.optin="optional",sn(n._zod,"values",()=>e.innerType._zod.values),n._zod.parse=(t,i)=>{if(i.direction==="backward")return e.innerType._zod.run(t,i);if(t.value===void 0)return t.value=e.defaultValue,t;const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(o=>Po(o,e)):Po(a,e)}});function Po(n,e){return n.value===void 0&&(n.value=e.defaultValue),n}const Vd=B("$ZodPrefault",(n,e)=>{mn.init(n,e),n._zod.optin="optional",sn(n._zod,"values",()=>e.innerType._zod.values),n._zod.parse=(t,i)=>(i.direction==="backward"||t.value===void 0&&(t.value=e.defaultValue),e.innerType._zod.run(t,i))}),$d=B("$ZodNonOptional",(n,e)=>{mn.init(n,e),sn(n._zod,"values",()=>{const t=e.innerType._zod.values;return t?new Set([...t].filter(i=>i!==void 0)):void 0}),n._zod.parse=(t,i)=>{const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(o=>xo(o,n)):xo(a,n)}});function xo(n,e){return!n.issues.length&&n.value===void 0&&n.issues.push({code:"invalid_type",expected:"nonoptional",input:n.value,inst:e}),n}const Wd=B("$ZodCatch",(n,e)=>{mn.init(n,e),sn(n._zod,"optin",()=>e.innerType._zod.optin),sn(n._zod,"optout",()=>e.innerType._zod.optout),sn(n._zod,"values",()=>e.innerType._zod.values),n._zod.parse=(t,i)=>{if(i.direction==="backward")return e.innerType._zod.run(t,i);const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(o=>(t.value=o.value,o.issues.length&&(t.value=e.catchValue({...t,error:{issues:o.issues.map(r=>Ne(r,i,fe()))},input:t.value}),t.issues=[]),t)):(t.value=a.value,a.issues.length&&(t.value=e.catchValue({...t,error:{issues:a.issues.map(o=>Ne(o,i,fe()))},input:t.value}),t.issues=[]),t)}}),Ud=B("$ZodPipe",(n,e)=>{mn.init(n,e),sn(n._zod,"values",()=>e.in._zod.values),sn(n._zod,"optin",()=>e.in._zod.optin),sn(n._zod,"optout",()=>e.out._zod.optout),sn(n._zod,"propValues",()=>e.in._zod.propValues),n._zod.parse=(t,i)=>{if(i.direction==="backward"){const o=e.out._zod.run(t,i);return o instanceof Promise?o.then(r=>jt(r,e.in,i)):jt(o,e.in,i)}const a=e.in._zod.run(t,i);return a instanceof Promise?a.then(o=>jt(o,e.out,i)):jt(a,e.out,i)}});function jt(n,e,t){return n.issues.length?(n.aborted=!0,n):e._zod.run({value:n.value,issues:n.issues},t)}const Gd=B("$ZodReadonly",(n,e)=>{mn.init(n,e),sn(n._zod,"propValues",()=>e.innerType._zod.propValues),sn(n._zod,"values",()=>e.innerType._zod.values),sn(n._zod,"optin",()=>e.innerType._zod.optin),sn(n._zod,"optout",()=>e.innerType._zod.optout),n._zod.parse=(t,i)=>{if(i.direction==="backward")return e.innerType._zod.run(t,i);const a=e.innerType._zod.run(t,i);return a instanceof Promise?a.then(Fo):Fo(a)}});function Fo(n){return n.value=Object.freeze(n.value),n}const zd=B("$ZodLazy",(n,e)=>{mn.init(n,e),sn(n._zod,"innerType",()=>e.getter()),sn(n._zod,"pattern",()=>n._zod.innerType._zod.pattern),sn(n._zod,"propValues",()=>n._zod.innerType._zod.propValues),sn(n._zod,"optin",()=>n._zod.innerType._zod.optin??void 0),sn(n._zod,"optout",()=>n._zod.innerType._zod.optout??void 0),n._zod.parse=(t,i)=>n._zod.innerType._zod.run(t,i)}),Kd=B("$ZodCustom",(n,e)=>{Gn.init(n,e),mn.init(n,e),n._zod.parse=(t,i)=>t,n._zod.check=t=>{const i=t.value,a=e.fn(i);if(a instanceof Promise)return a.then(o=>Ho(o,t,i,n));Ho(a,t,i,n)}});function Ho(n,e,t,i){if(!n){const a={code:"custom",input:t,inst:i,path:[...i._zod.def.path??[]],continue:!i._zod.def.abort};i._zod.def.params&&(a.params=i._zod.def.params),e.issues.push(ft(a))}}class Yd{constructor(){this._map=new WeakMap,this._idmap=new Map}add(e,...t){const i=t[0];if(this._map.set(e,i),i&&typeof i=="object"&&"id"in i){if(this._idmap.has(i.id))throw new Error(`ID ${i.id} already exists in the registry`);this._idmap.set(i.id,e)}return this}clear(){return this._map=new WeakMap,this._idmap=new Map,this}remove(e){const t=this._map.get(e);return t&&typeof t=="object"&&"id"in t&&this._idmap.delete(t.id),this._map.delete(e),this}get(e){const t=e._zod.parent;if(t){const i={...this.get(t)??{}};delete i.id;const a={...i,...this._map.get(e)};return Object.keys(a).length?a:void 0}return this._map.get(e)}has(e){return this._map.has(e)}}function jd(){return new Yd}const Zt=jd();function Zd(n,e){return new n({type:"string",...z(e)})}function Xd(n,e){return new n({type:"string",format:"email",check:"string_format",abort:!1,...z(e)})}function Mo(n,e){return new n({type:"string",format:"guid",check:"string_format",abort:!1,...z(e)})}function qd(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,...z(e)})}function Jd(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,version:"v4",...z(e)})}function Qd(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,version:"v6",...z(e)})}function n0(n,e){return new n({type:"string",format:"uuid",check:"string_format",abort:!1,version:"v7",...z(e)})}function e0(n,e){return new n({type:"string",format:"url",check:"string_format",abort:!1,...z(e)})}function t0(n,e){return new n({type:"string",format:"emoji",check:"string_format",abort:!1,...z(e)})}function i0(n,e){return new n({type:"string",format:"nanoid",check:"string_format",abort:!1,...z(e)})}function a0(n,e){return new n({type:"string",format:"cuid",check:"string_format",abort:!1,...z(e)})}function o0(n,e){return new n({type:"string",format:"cuid2",check:"string_format",abort:!1,...z(e)})}function r0(n,e){return new n({type:"string",format:"ulid",check:"string_format",abort:!1,...z(e)})}function s0(n,e){return new n({type:"string",format:"xid",check:"string_format",abort:!1,...z(e)})}function c0(n,e){return new n({type:"string",format:"ksuid",check:"string_format",abort:!1,...z(e)})}function l0(n,e){return new n({type:"string",format:"ipv4",check:"string_format",abort:!1,...z(e)})}function d0(n,e){return new n({type:"string",format:"ipv6",check:"string_format",abort:!1,...z(e)})}function u0(n,e){return new n({type:"string",format:"cidrv4",check:"string_format",abort:!1,...z(e)})}function m0(n,e){return new n({type:"string",format:"cidrv6",check:"string_format",abort:!1,...z(e)})}function g0(n,e){return new n({type:"string",format:"base64",check:"string_format",abort:!1,...z(e)})}function p0(n,e){return new n({type:"string",format:"base64url",check:"string_format",abort:!1,...z(e)})}function I0(n,e){return new n({type:"string",format:"e164",check:"string_format",abort:!1,...z(e)})}function h0(n,e){return new n({type:"string",format:"jwt",check:"string_format",abort:!1,...z(e)})}function f0(n,e){return new n({type:"string",format:"datetime",check:"string_format",offset:!1,local:!1,precision:null,...z(e)})}function E0(n,e){return new n({type:"string",format:"date",check:"string_format",...z(e)})}function S0(n,e){return new n({type:"string",format:"time",check:"string_format",precision:null,...z(e)})}function _0(n,e){return new n({type:"string",format:"duration",check:"string_format",...z(e)})}function v0(n,e){return new n({type:"number",checks:[],...z(e)})}function b0(n,e){return new n({type:"number",check:"number_format",abort:!1,format:"safeint",...z(e)})}function T0(n,e){return new n({type:"boolean",...z(e)})}function R0(n,e){return new n({type:"null",...z(e)})}function L0(n){return new n({type:"unknown"})}function A0(n,e){return new n({type:"never",...z(e)})}function Vo(n,e){return new Ro({check:"less_than",...z(e),value:n,inclusive:!1})}function Ci(n,e){return new Ro({check:"less_than",...z(e),value:n,inclusive:!0})}function $o(n,e){return new Lo({check:"greater_than",...z(e),value:n,inclusive:!1})}function yi(n,e){return new Lo({check:"greater_than",...z(e),value:n,inclusive:!0})}function Wo(n,e){return new Fl({check:"multiple_of",...z(e),value:n})}function Uo(n,e){return new Ml({check:"max_length",...z(e),maximum:n})}function Xt(n,e){return new Vl({check:"min_length",...z(e),minimum:n})}function Go(n,e){return new $l({check:"length_equals",...z(e),length:n})}function O0(n,e){return new Wl({check:"string_format",format:"regex",...z(e),pattern:n})}function w0(n){return new Ul({check:"string_format",format:"lowercase",...z(n)})}function N0(n){return new Gl({check:"string_format",format:"uppercase",...z(n)})}function D0(n,e){return new zl({check:"string_format",format:"includes",...z(e),includes:n})}function C0(n,e){return new Kl({check:"string_format",format:"starts_with",...z(e),prefix:n})}function y0(n,e){return new Yl({check:"string_format",format:"ends_with",...z(e),suffix:n})}function Et(n){return new jl({check:"overwrite",tx:n})}function k0(n){return Et(e=>e.normalize(n))}function B0(){return Et(n=>n.trim())}function P0(){return Et(n=>n.toLowerCase())}function x0(){return Et(n=>n.toUpperCase())}function F0(n,e,t){return new n({type:"array",element:e,...z(t)})}function H0(n,e,t){return new n({type:"custom",check:"custom",fn:e,...z(t)})}function M0(n){const e=V0(t=>(t.addIssue=i=>{if(typeof i=="string")t.issues.push(ft(i,t.value,e._zod.def));else{const a=i;a.fatal&&(a.continue=!1),a.code??(a.code="custom"),a.input??(a.input=t.value),a.inst??(a.inst=e),a.continue??(a.continue=!e._zod.def.abort),t.issues.push(ft(a))}},n(t.value,t)));return e}function V0(n,e){const t=new Gn({check:"custom",...z(e)});return t._zod.check=n,t}const $0=B("ZodISODateTime",(n,e)=>{cd.init(n,e),Ln.init(n,e)});function Ee(n){return f0($0,n)}const W0=B("ZodISODate",(n,e)=>{ld.init(n,e),Ln.init(n,e)});function Q(n){return E0(W0,n)}const U0=B("ZodISOTime",(n,e)=>{dd.init(n,e),Ln.init(n,e)});function G0(n){return S0(U0,n)}const z0=B("ZodISODuration",(n,e)=>{ud.init(n,e),Ln.init(n,e)});function K0(n){return _0(z0,n)}const ae=B("ZodError",(n,e)=>{fo.init(n,e),n.name="ZodError",Object.defineProperties(n,{format:{value:t=>Jc(n,t)},flatten:{value:t=>qc(n,t)},addIssue:{value:t=>{n.issues.push(t),n.message=JSON.stringify(n.issues,Ti,2)}},addIssues:{value:t=>{n.issues.push(...t),n.message=JSON.stringify(n.issues,Ti,2)}},isEmpty:{get(){return n.issues.length===0}}})},{Parent:Error}),Y0=Oi(ae),j0=wi(ae),Z0=Ut(ae),X0=Gt(ae),q0=el(ae),J0=tl(ae),Q0=il(ae),nu=al(ae),eu=ol(ae),tu=rl(ae),iu=sl(ae),au=cl(ae),fn=B("ZodType",(n,e)=>(mn.init(n,e),n.def=e,n.type=e.type,Object.defineProperty(n,"_def",{value:e}),n.check=(...t)=>n.clone(We(e,{checks:[...e.checks??[],...t.map(i=>typeof i=="function"?{_zod:{check:i,def:{check:"custom"},onattach:[]}}:i)]})),n.clone=(t,i)=>we(n,t,i),n.brand=()=>n,n.register=((t,i)=>(t.add(n,i),n)),n.parse=(t,i)=>Y0(n,t,i,{callee:n.parse}),n.safeParse=(t,i)=>Z0(n,t,i),n.parseAsync=async(t,i)=>j0(n,t,i,{callee:n.parseAsync}),n.safeParseAsync=async(t,i)=>X0(n,t,i),n.spa=n.safeParseAsync,n.encode=(t,i)=>q0(n,t,i),n.decode=(t,i)=>J0(n,t,i),n.encodeAsync=async(t,i)=>Q0(n,t,i),n.decodeAsync=async(t,i)=>nu(n,t,i),n.safeEncode=(t,i)=>eu(n,t,i),n.safeDecode=(t,i)=>tu(n,t,i),n.safeEncodeAsync=async(t,i)=>iu(n,t,i),n.safeDecodeAsync=async(t,i)=>au(n,t,i),n.refine=(t,i)=>n.check(qu(t,i)),n.superRefine=t=>n.check(Ju(t)),n.overwrite=t=>n.check(Et(t)),n.optional=()=>Qo(n),n.nullable=()=>nr(n),n.nullish=()=>Qo(nr(n)),n.nonoptional=t=>Uu(n,t),n.array=()=>v(n),n.or=t=>Vn([n,t]),n.and=t=>yu(n,t),n.transform=t=>tr(n,Fu(t)),n.default=t=>Vu(n,t),n.prefault=t=>Wu(n,t),n.catch=t=>zu(n,t),n.pipe=t=>tr(n,t),n.readonly=()=>ju(n),n.describe=t=>{const i=n.clone();return Zt.add(i,{description:t}),i},Object.defineProperty(n,"description",{get(){return Zt.get(n)?.description},configurable:!0}),n.meta=(...t)=>{if(t.length===0)return Zt.get(n);const i=n.clone();return Zt.add(i,t[0]),i},n.isOptional=()=>n.safeParse(void 0).success,n.isNullable=()=>n.safeParse(null).success,n)),zo=B("_ZodString",(n,e)=>{Ni.init(n,e),fn.init(n,e);const t=n._zod.bag;n.format=t.format??null,n.minLength=t.minimum??null,n.maxLength=t.maximum??null,n.regex=(...i)=>n.check(O0(...i)),n.includes=(...i)=>n.check(D0(...i)),n.startsWith=(...i)=>n.check(C0(...i)),n.endsWith=(...i)=>n.check(y0(...i)),n.min=(...i)=>n.check(Xt(...i)),n.max=(...i)=>n.check(Uo(...i)),n.length=(...i)=>n.check(Go(...i)),n.nonempty=(...i)=>n.check(Xt(1,...i)),n.lowercase=i=>n.check(w0(i)),n.uppercase=i=>n.check(N0(i)),n.trim=()=>n.check(B0()),n.normalize=(...i)=>n.check(k0(...i)),n.toLowerCase=()=>n.check(P0()),n.toUpperCase=()=>n.check(x0())}),ou=B("ZodString",(n,e)=>{Ni.init(n,e),zo.init(n,e),n.email=t=>n.check(Xd(ru,t)),n.url=t=>n.check(e0(su,t)),n.jwt=t=>n.check(h0(bu,t)),n.emoji=t=>n.check(t0(cu,t)),n.guid=t=>n.check(Mo(Ko,t)),n.uuid=t=>n.check(qd(qt,t)),n.uuidv4=t=>n.check(Jd(qt,t)),n.uuidv6=t=>n.check(Qd(qt,t)),n.uuidv7=t=>n.check(n0(qt,t)),n.nanoid=t=>n.check(i0(lu,t)),n.guid=t=>n.check(Mo(Ko,t)),n.cuid=t=>n.check(a0(du,t)),n.cuid2=t=>n.check(o0(uu,t)),n.ulid=t=>n.check(r0(mu,t)),n.base64=t=>n.check(g0(Su,t)),n.base64url=t=>n.check(p0(_u,t)),n.xid=t=>n.check(s0(gu,t)),n.ksuid=t=>n.check(c0(pu,t)),n.ipv4=t=>n.check(l0(Iu,t)),n.ipv6=t=>n.check(d0(hu,t)),n.cidrv4=t=>n.check(u0(fu,t)),n.cidrv6=t=>n.check(m0(Eu,t)),n.e164=t=>n.check(I0(vu,t)),n.datetime=t=>n.check(Ee(t)),n.date=t=>n.check(Q(t)),n.time=t=>n.check(G0(t)),n.duration=t=>n.check(K0(t))});function w(n){return Zd(ou,n)}const Ln=B("ZodStringFormat",(n,e)=>{Sn.init(n,e),zo.init(n,e)}),ru=B("ZodEmail",(n,e)=>{Ql.init(n,e),Ln.init(n,e)}),Ko=B("ZodGUID",(n,e)=>{ql.init(n,e),Ln.init(n,e)}),qt=B("ZodUUID",(n,e)=>{Jl.init(n,e),Ln.init(n,e)}),su=B("ZodURL",(n,e)=>{nd.init(n,e),Ln.init(n,e)}),cu=B("ZodEmoji",(n,e)=>{ed.init(n,e),Ln.init(n,e)}),lu=B("ZodNanoID",(n,e)=>{td.init(n,e),Ln.init(n,e)}),du=B("ZodCUID",(n,e)=>{id.init(n,e),Ln.init(n,e)}),uu=B("ZodCUID2",(n,e)=>{ad.init(n,e),Ln.init(n,e)}),mu=B("ZodULID",(n,e)=>{od.init(n,e),Ln.init(n,e)}),gu=B("ZodXID",(n,e)=>{rd.init(n,e),Ln.init(n,e)}),pu=B("ZodKSUID",(n,e)=>{sd.init(n,e),Ln.init(n,e)}),Iu=B("ZodIPv4",(n,e)=>{md.init(n,e),Ln.init(n,e)}),hu=B("ZodIPv6",(n,e)=>{gd.init(n,e),Ln.init(n,e)}),fu=B("ZodCIDRv4",(n,e)=>{pd.init(n,e),Ln.init(n,e)}),Eu=B("ZodCIDRv6",(n,e)=>{Id.init(n,e),Ln.init(n,e)}),Su=B("ZodBase64",(n,e)=>{hd.init(n,e),Ln.init(n,e)}),_u=B("ZodBase64URL",(n,e)=>{Ed.init(n,e),Ln.init(n,e)}),vu=B("ZodE164",(n,e)=>{Sd.init(n,e),Ln.init(n,e)}),bu=B("ZodJWT",(n,e)=>{vd.init(n,e),Ln.init(n,e)}),Yo=B("ZodNumber",(n,e)=>{Oo.init(n,e),fn.init(n,e),n.gt=(i,a)=>n.check($o(i,a)),n.gte=(i,a)=>n.check(yi(i,a)),n.min=(i,a)=>n.check(yi(i,a)),n.lt=(i,a)=>n.check(Vo(i,a)),n.lte=(i,a)=>n.check(Ci(i,a)),n.max=(i,a)=>n.check(Ci(i,a)),n.int=i=>n.check(jo(i)),n.safe=i=>n.check(jo(i)),n.positive=i=>n.check($o(0,i)),n.nonnegative=i=>n.check(yi(0,i)),n.negative=i=>n.check(Vo(0,i)),n.nonpositive=i=>n.check(Ci(0,i)),n.multipleOf=(i,a)=>n.check(Wo(i,a)),n.step=(i,a)=>n.check(Wo(i,a)),n.finite=()=>n;const t=n._zod.bag;n.minValue=Math.max(t.minimum??Number.NEGATIVE_INFINITY,t.exclusiveMinimum??Number.NEGATIVE_INFINITY)??null,n.maxValue=Math.min(t.maximum??Number.POSITIVE_INFINITY,t.exclusiveMaximum??Number.POSITIVE_INFINITY)??null,n.isInt=(t.format??"").includes("int")||Number.isSafeInteger(t.multipleOf??.5),n.isFinite=!0,n.format=t.format??null});function k(n){return v0(Yo,n)}const Tu=B("ZodNumberFormat",(n,e)=>{bd.init(n,e),Yo.init(n,e)});function jo(n){return b0(Tu,n)}const Ru=B("ZodBoolean",(n,e)=>{Td.init(n,e),fn.init(n,e)});function H(n){return T0(Ru,n)}const Lu=B("ZodNull",(n,e)=>{Rd.init(n,e),fn.init(n,e)});function De(n){return R0(Lu,n)}const Au=B("ZodUnknown",(n,e)=>{Ld.init(n,e),fn.init(n,e)});function Zo(){return L0(Au)}const Ou=B("ZodNever",(n,e)=>{Ad.init(n,e),fn.init(n,e)});function Xo(n){return A0(Ou,n)}const wu=B("ZodArray",(n,e)=>{Od.init(n,e),fn.init(n,e),n.element=e.element,n.min=(t,i)=>n.check(Xt(t,i)),n.nonempty=t=>n.check(Xt(1,t)),n.max=(t,i)=>n.check(Uo(t,i)),n.length=(t,i)=>n.check(Go(t,i)),n.unwrap=()=>n.element});function v(n,e){return F0(wu,n,e)}const Nu=B("ZodObject",(n,e)=>{Nd.init(n,e),fn.init(n,e),sn(n,"shape",()=>e.shape),n.keyof=()=>O(Object.keys(n._zod.def.shape)),n.catchall=t=>n.clone({...n._zod.def,catchall:t}),n.passthrough=()=>n.clone({...n._zod.def,catchall:Zo()}),n.loose=()=>n.clone({...n._zod.def,catchall:Zo()}),n.strict=()=>n.clone({...n._zod.def,catchall:Xo()}),n.strip=()=>n.clone({...n._zod.def,catchall:void 0}),n.extend=t=>Kc(n,t),n.safeExtend=t=>Yc(n,t),n.merge=t=>jc(n,t),n.pick=t=>Gc(n,t),n.omit=t=>zc(n,t),n.partial=(...t)=>Zc(Jo,n,t[0]),n.required=(...t)=>Xc(er,n,t[0])});function d(n,e){return new Nu({type:"object",shape:n,catchall:Xo(),...z(e)})}const qo=B("ZodUnion",(n,e)=>{yo.init(n,e),fn.init(n,e),n.options=e.options});function Vn(n,e){return new qo({type:"union",options:n,...z(e)})}const Du=B("ZodDiscriminatedUnion",(n,e)=>{qo.init(n,e),Dd.init(n,e)});function An(n,e,t){return new Du({type:"union",options:e,discriminator:n,...z(t)})}const Cu=B("ZodIntersection",(n,e)=>{Cd.init(n,e),fn.init(n,e)});function yu(n,e){return new Cu({type:"intersection",left:n,right:e})}const ku=B("ZodTuple",(n,e)=>{yd.init(n,e),fn.init(n,e),n.rest=t=>n.clone({...n._zod.def,rest:t})});function wn(n,e,t){const i=e instanceof mn,a=i?t:e,o=i?e:null;return new ku({type:"tuple",items:n,rest:o,...z(a)})}const Bu=B("ZodRecord",(n,e)=>{kd.init(n,e),fn.init(n,e),n.keyType=e.keyType,n.valueType=e.valueType});function cn(n,e,t){return new Bu({type:"record",keyType:n,valueType:e,...z(t)})}const ki=B("ZodEnum",(n,e)=>{Bd.init(n,e),fn.init(n,e),n.enum=e.entries,n.options=Object.values(e.entries);const t=new Set(Object.keys(e.entries));n.extract=(i,a)=>{const o={};for(const r of i)if(t.has(r))o[r]=e.entries[r];else throw new Error(`Key ${r} not found in enum`);return new ki({...e,checks:[],...z(a),entries:o})},n.exclude=(i,a)=>{const o={...e.entries};for(const r of i)if(t.has(r))delete o[r];else throw new Error(`Key ${r} not found in enum`);return new ki({...e,checks:[],...z(a),entries:o})}});function O(n,e){const t=Array.isArray(n)?Object.fromEntries(n.map(i=>[i,i])):n;return new ki({type:"enum",entries:t,...z(e)})}const Pu=B("ZodLiteral",(n,e)=>{Pd.init(n,e),fn.init(n,e),n.values=new Set(e.values),Object.defineProperty(n,"value",{get(){if(e.values.length>1)throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");return e.values[0]}})});function m(n,e){return new Pu({type:"literal",values:Array.isArray(n)?n:[n],...z(e)})}const xu=B("ZodTransform",(n,e)=>{xd.init(n,e),fn.init(n,e),n._zod.parse=(t,i)=>{if(i.direction==="backward")throw new uo(n.constructor.name);t.addIssue=o=>{if(typeof o=="string")t.issues.push(ft(o,t.value,e));else{const r=o;r.fatal&&(r.continue=!1),r.code??(r.code="custom"),r.input??(r.input=t.value),r.inst??(r.inst=n),t.issues.push(ft(r))}};const a=e.transform(t.value,t);return a instanceof Promise?a.then(o=>(t.value=o,t)):(t.value=a,t)}});function Fu(n){return new xu({type:"transform",transform:n})}const Jo=B("ZodOptional",(n,e)=>{Fd.init(n,e),fn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function Qo(n){return new Jo({type:"optional",innerType:n})}const Hu=B("ZodNullable",(n,e)=>{Hd.init(n,e),fn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function nr(n){return new Hu({type:"nullable",innerType:n})}const Mu=B("ZodDefault",(n,e)=>{Md.init(n,e),fn.init(n,e),n.unwrap=()=>n._zod.def.innerType,n.removeDefault=n.unwrap});function Vu(n,e){return new Mu({type:"default",innerType:n,get defaultValue(){return typeof e=="function"?e():Io(e)}})}const $u=B("ZodPrefault",(n,e)=>{Vd.init(n,e),fn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function Wu(n,e){return new $u({type:"prefault",innerType:n,get defaultValue(){return typeof e=="function"?e():Io(e)}})}const er=B("ZodNonOptional",(n,e)=>{$d.init(n,e),fn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function Uu(n,e){return new er({type:"nonoptional",innerType:n,...z(e)})}const Gu=B("ZodCatch",(n,e)=>{Wd.init(n,e),fn.init(n,e),n.unwrap=()=>n._zod.def.innerType,n.removeCatch=n.unwrap});function zu(n,e){return new Gu({type:"catch",innerType:n,catchValue:typeof e=="function"?e:()=>e})}const Ku=B("ZodPipe",(n,e)=>{Ud.init(n,e),fn.init(n,e),n.in=e.in,n.out=e.out});function tr(n,e){return new Ku({type:"pipe",in:n,out:e})}const Yu=B("ZodReadonly",(n,e)=>{Gd.init(n,e),fn.init(n,e),n.unwrap=()=>n._zod.def.innerType});function ju(n){return new Yu({type:"readonly",innerType:n})}const Zu=B("ZodLazy",(n,e)=>{zd.init(n,e),fn.init(n,e),n.unwrap=()=>n._zod.def.getter()});function Xu(n){return new Zu({type:"lazy",getter:n})}const ir=B("ZodCustom",(n,e)=>{Kd.init(n,e),fn.init(n,e)});function qu(n,e={}){return H0(ir,n,e)}function Ju(n){return M0(n)}function Qu(n,e={error:`Input not instance of ${n.name}`}){const t=new ir({type:"custom",check:"custom",fn:i=>i instanceof n,abort:!0,...z(e)});return t._zod.bag.Class=n,t}function tt(n){const e=Xu(()=>Vn([w(n),k(),H(),De(),v(e),cn(w(),e)]));return e}const nm=typeof globalThis<"u"&&"document"in globalThis,em=typeof globalThis<"u"&&"importScripts"in globalThis;(nm||em)&&fe({jitless:!0});const l=k().int().min(0).max(Number.MAX_SAFE_INTEGER),x=l.min(1),s=w().min(1).max(128).regex(/^(?!(?:constructor|prototype)$)[A-Za-z0-9][A-Za-z0-9_.:-]*$/),b=w().regex(/^[a-f0-9]{64}$/),ar=w().min(1).max(128),$n=O(["T20","ODI","RED_BALL"]),gn=l.max(100),kn=l.max(1e4),it=O(["R","L"]),Jt=O(["FAST","MEDIUM","OFF_SPIN","LEG_SPIN","SLOW_LEFT_ARM","LEFT_ARM_WRIST"]),Bn=w().regex(/^[\s\S]{1,80}$/u),tm=d({kind:O(["FICTIONAL","LICENSED","USER_SUPPLIED"]),sourceId:s,sourceHash:b,confidenceBp:kn}),at=d({defence:gn,timing:gn,power:gn,rotation:gn,vsPace:gn,vsSpin:gn,control:gn,movement:gn,variation:gn,stamina:gn,catching:gn,groundFielding:gn,throwing:gn,keeping:gn}),Ce=d({playerId:s,name:Bn,birthDate:Q(),batHand:it,bowlHand:it,bowlingStyle:Jt.nullable(),role:O(["BATTER","BOWLER","ALLROUNDER","KEEPER"]),skills:cn($n,at),variations:v(s),shotSectorWeights:v(l).length(8),exposureBalls:cn($n,l),provenance:tm}),or=d({schema:m("1.0.0"),engine:ar,random:ar,rules:s,rulesHash:b,model:s,modelHash:b,worldHash:b}),St=d({playerId:s,aggression:l.max(4),intent:O(["NORMAL","ROTATE","PROTECT"])}),_t=d({bowlerId:s,line:O(["OFF","STUMPS","LEG"]),length:O(["YORKER","FULL","GOOD","SHORT"]),variationId:s,effort:O(["CONSERVE","NORMAL","MAXIMUM"])}),Bi=d({slotId:s,playerId:s}),rr=d({battingOrder:H(),bowlerSelection:H(),battingTactics:H(),bowlingTactics:H(),declarations:H(),followOn:H()}),sr=d({battingPlans:cn(s,St),bowlingPlan:_t,fieldSlots:v(Bi).length(9),nextBatterId:s.nullable(),delegation:rr}),cr=d({seamBp:kn,turnBp:kn,variabilityBp:kn,moistureBp:kn,wearPoints:l}),im=O(["DRY","OVERCAST","RAIN","UNSAFE_LIGHT"]),lr=d({pitch:cr,weather:im,outfieldSpeedBp:kn,ballId:s,ballAgeLegalBalls:l,weatherScheduleId:s}),Pi=d({wides:l,noBalls:l,byes:l,legByes:l,penalties:l}),ot=O(["NORTH","SOUTH"]),dr=d({kind:O(["BOWLED","LBW","CAUGHT","RUN_OUT","STUMPED","HIT_WICKET"]),playerId:s,creditedBowlerId:s.nullable(),fielderId:s.nullable(),wicketEnd:ot}),Qt=d({type:m("DELIVERY_RECORDED"),inningsIndex:l,deliveryIndex:l,strikerId:s,nonStrikerId:s,bowlerId:s,legality:O(["LEGAL","WIDE","NO_BALL","DEAD"]),legalBall:H(),countsAsBallFaced:H(),batRuns:l,extras:Pi,completedRuns:l,boundary:O(["NONE","FOUR","SIX"]),dismissal:dr.nullable(),endsAfter:d({north:s.nullable(),south:s.nullable()}),shotSector:l.max(7).nullable(),trajectory:O(["GROUND","AERIAL","EDGE"]).nullable(),executedLength:O(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"]).nullable(),fieldOutcome:O(["NONE","STOP","DROP","CATCH","MISS","RUN_OUT"]),elapsedSeconds:l,freeHitNext:H()}),xi=d({index:l,battingTeamId:s,bowlingTeamId:s,runs:l,wickets:l.max(10),legalBalls:l,deliveryAttempts:l,targetToWin:x.nullable(),allocatedBalls:x.nullable(),extras:Pi,northBatterId:s.nullable(),southBatterId:s.nullable(),strikerEnd:ot,battingOrder:v(s),dismissed:v(s),bowlerId:s.nullable(),previousOverBowlerId:s.nullable(),bowlerLegalBalls:cn(s,l),freeHitPending:H(),ballAgeLegalBalls:l,complete:H()});O(["LUNCH","TEA","STUMPS","INNINGS"]);const rt=d({day:x.max(5),localSeconds:l.max(86399),dayLegalBalls:l,finalHourActive:H(),finalHourBallsRequired:l,finalHourBallsDelivered:l,pendingInterval:O(["LUNCH","TEA","STUMPS"]).nullable()}),am={winnerTeamId:De(),marginType:De(),marginRuns:De(),marginWickets:De(),completionReason:w().min(1).max(240)},Ge=Vn([d({kind:m("WIN"),winnerTeamId:s,marginType:m("RUNS"),marginRuns:x,marginWickets:De(),completionReason:w().min(1).max(240)}),d({kind:m("WIN"),winnerTeamId:s,marginType:m("WICKETS"),marginRuns:De(),marginWickets:x.max(10),completionReason:w().min(1).max(240)}),d({kind:m("WIN"),winnerTeamId:s,marginType:m("INNINGS"),marginRuns:x,marginWickets:De(),completionReason:w().min(1).max(240)}),d({kind:O(["TIE","DRAW","NO_RESULT"]),...am})]),Fi=O(["SETUP","TOSS","AWAITING_INNINGS","READY","AWAITING_BATTER","AWAITING_BOWLER","INTERVAL","WEATHER_DELAY","COMPLETE"]);d({matchId:s,revision:l,versions:or,seed:w().min(1).max(256),format:$n,phase:Fi,teamIds:wn([s,s]),xi:cn(s,v(Ce).length(11)),inningsOrder:v(s).max(4),innings:v(xi).max(4),activeInningsIndex:l.max(3),clock:rt,tactics:cn(s,sr),conditions:lr,fatigueBp:cn(s,kn),result:Ge.nullable()});function ur(n,e){return n<e?-1:n>e?1:0}const om=d({limitedOversRain:m(!1),superOver:m(!1),injuries:m(!1),prediction:H()}),Hi=d({schemaVersion:m("1.0.0"),gameId:s,matchId:s,format:$n,worldPackId:s,rulesId:s,modelId:s,randomId:m("SHA256_COUNTER_V1"),seed:w().min(1).max(256),teamIds:wn([s,s]),groundId:s,capabilities:om}),rm=d({teamId:s,name:Bn,squadIds:v(s).min(11).max(100),colours:wn([w().regex(/^#[a-fA-F0-9]{6}$/),w().regex(/^#[a-fA-F0-9]{6}$/)])}),sm=d({groundId:s,name:Bn,pitchPrior:cr,sectorRadiiCm:v(x).length(8),outfieldSpeedBp:kn}),cm=d({slotId:s,sector:l.max(7),angleDegrees:l.max(359),depth:O(["INNER","MIDDLE","DEEP"]),insideCircle:H(),legSide:H(),behindSquare:H()}),mr=d({registryId:s,referenceHand:m("R"),positions:v(cm).min(9)}),lm=d({fromLegalBall:l,maxOutside:l.max(9)}),dm=d({rulesId:s,schemaVersion:m("1.0.0"),format:$n,referenceEdition:m("MCC_2017_FOURTH_EDITION_2026"),effectiveDate:m("2026-10-01"),customProfile:m(!0),ballsPerOver:m(6),playersPerXI:m(11),wicketsToAllOut:m(10),inningsPerTeam:Vn([m(1),m(2)]),allocatedBalls:x.nullable(),bowlerMaxBalls:x.nullable(),consecutiveOvers:m(!1),freeHitAfterNoBall:H(),declarations:H(),followOnLead:x.nullable(),newBallAfterLegalBalls:x.nullable(),fieldPhases:v(lm),maxLegSide:m(5),maxBehindSquareLegSide:m(2),limitedOversRain:m(!1),superOver:m(!1),supportedClauses:v(w().min(1)),localVariations:v(w().min(1)),fixtureIds:v(s),validationStatus:m("CONTRACT_ONLY")});d({modelId:s,schemaVersion:m("1.0.0"),status:O(["SYNTHETIC_ALPHA","EMPIRICALLY_VALIDATED"]),randomId:m("SHA256_COUNTER_V1"),fixedPointScale:m(1e4),expLutHash:b,featureSpecHash:b,variationIds:v(s),effects:d({overAroundWicket:m(!1),individualVariations:m(!1),moisture:m(!1),geometryEffects:m(!1),outfieldSpeed:m(!1)})});const vt=d({packId:s,schemaVersion:m("1.0.0"),players:v(Ce).min(1).max(1e4),teams:v(rm).min(2).max(500),grounds:v(sm).min(1),rulesIds:v(s).min(1),provenance:w().min(1).max(2e3)}),um=d({path:w().min(1).max(240).regex(/^(?!\/)(?!.*(?:^|\/)\.\.(?:\/|$))(?!.*\\)[A-Za-z0-9_./-]+$/),bytes:l.max(1e8),sha256:b});d({schemaVersion:m("1.0.0"),gameId:s,versions:or,entries:v(um).min(1).max(2e3)});const bt=d({copyVersion:m("LC_NEW_GAME_WORLD_COPY_V1"),baseWorldCanonicalSha256:b,worldCanonicalSha256:b,world:vt}),Mi={commandId:s,aggregateId:s,expectedRevision:l,actorId:w().regex(/^(?:(?:USER|AI):[A-Za-z0-9][A-Za-z0-9_.:-]*|SYSTEM)$/)},zn=(n,e)=>d({...Mi,kind:m(n),payload:d(e)}),mm=An("kind",[zn("SELECT_XI",{teamId:s,playerIds:v(s).length(11),captainId:s,keeperId:s}),zn("CONFIRM_TEAMS",{}),zn("CALL_TOSS",{teamId:s,call:O(["HEADS","TAILS"])}),zn("CHOOSE_INNINGS",{teamId:s,choice:O(["BAT","BOWL"])}),zn("SET_BATTER",{teamId:s,playerId:s}),zn("SET_BOWLER",{teamId:s,bowlerId:s}),d({...Mi,kind:m("SET_BATTING_PLAN"),payload:St}),d({...Mi,kind:m("SET_BOWLING_PLAN"),payload:_t}),zn("SET_FIELD",{teamId:s,fieldSlots:v(Bi).length(9)}),zn("SET_DELEGATION",{teamId:s,delegation:rr}),zn("ADVANCE",{scope:O(["DELIVERY","OVER","NEXT_DECISION","INNINGS","MATCH"])}),zn("DECLARE",{teamId:s}),zn("CHOOSE_FOLLOW_ON",{teamId:s,enforce:H()}),zn("TAKE_NEW_BALL",{teamId:s}),zn("RESUME_AFTER_DELAY",{}),zn("FINISH_MATCH",{})]),Wn=(n,e)=>d({type:m(n),...e}),gm=An("type",[Wn("TEAMS_CONFIRMED",{teams:v(d({teamId:s,players:v(Ce).length(11),captainId:s,keeperId:s})).length(2)}),Wn("TOSS_RESOLVED",{callingTeamId:s,call:O(["HEADS","TAILS"]),outcome:O(["HEADS","TAILS"]),winnerTeamId:s}),Wn("INNINGS_STARTED",{innings:xi}),Wn("BATTER_SELECTED",{inningsIndex:l,teamId:s,playerId:s,end:O(["NORTH","SOUTH"])}),Wn("BOWLER_SELECTED",{inningsIndex:l,teamId:s,bowlerId:s}),Wn("TACTICS_CHANGED",{teamId:s,tactics:sr}),Wn("OVER_COMPLETED",{inningsIndex:l,bowlerId:s,overIndex:l}),Wn("INNINGS_COMPLETED",{inningsIndex:l,reason:O(["ALL_OUT","ALLOCATION","TARGET","DECLARATION","TIME","ABANDONMENT"])}),Wn("INTERVAL_STARTED",{kind:O(["LUNCH","TEA","STUMPS","INNINGS"]),clock:rt}),Wn("INTERVAL_ENDED",{clock:rt}),Wn("WEATHER_CHANGED",{conditions:lr,clock:rt}),Wn("RULES_ADJUSTED",{calculationSequence:x,providerId:s,providerVersion:s,auditHash:b,targetToWin:x.nullable(),allocations:v(x),resultEligible:H()}),Wn("FOLLOW_ON_CHOSEN",{teamId:s,enforced:H(),inningsOrder:v(s).length(4)}),Wn("BALL_REPLACED",{inningsIndex:l,ballId:s,ballAgeLegalBalls:m(0)}),Wn("MATCH_COMPLETED",{result:Ge})]),pm=Vn([Qt,gm]),Im=d({gameId:s,matchId:s,sequence:x,commandId:s,previousHash:b,stateHash:b,payload:pm}),hm=d({commandId:s,committedRevision:l,eventRange:d({first:x,last:x}).nullable()}),fm=O(["STALE_REVISION","ILLEGAL_ACTION","INVALID_DATA","UNSUPPORTED_VERSION","PERSISTENCE_FAILED","INTERNAL_INVARIANT"]);An("type",[d({type:m("COMMAND"),command:mm}),d({type:m("CANCEL_BATCH"),commandId:s})]),An("type",[d({type:m("ACK"),receipt:hm}),d({type:m("STATE_DELTA"),fromRevision:l,toRevision:l,events:v(Im)}),d({type:m("ERROR"),commandId:s.nullable(),code:fm,message:w().min(1).max(1e3)})]);const Xn="SHA256_COUNTER_V1",ni="LC_CANONICAL_JSON_V1_SHA256",ei=d({seed:w().min(1).max(256),domain:O(["MATCH_DELIVERY","TOSS","WEATHER","AI_TIE_BREAK","CAREER_TRAINING","WORLD_GENERATION","PREDICTION"]),entityId:s,eventOrdinal:l,stageName:s,drawIndex:l}),Em=d({kind:m("RANDOM"),version:m(Xn),address:ei}),Sm=d({kind:m("HASH_STATE"),version:m(ni),value:tt()});An("kind",[Em,Sm]);function _m(n){const e=ei.parse(n);return JSON.stringify([e.seed,e.domain,e.entityId,e.eventOrdinal,e.stageName,e.drawIndex])}function pn(n){const e=new Set,t=i=>{if(i===null)return"null";if(typeof i=="string"||typeof i=="boolean")return JSON.stringify(i);if(typeof i=="number"){if(!Number.isFinite(i))throw new Error("Non-finite JSON number");return JSON.stringify(i)}if(typeof i!="object")throw new Error("Non-JSON value");if(e.has(i))throw new Error("Cyclic JSON");e.add(i);let a;if(Array.isArray(i)){if(Object.getOwnPropertyNames(i).length!==i.length+1||Object.keys(i).length!==i.length)throw new Error("Sparse or decorated array");if(Object.getOwnPropertySymbols(i).length)throw new Error("Symbol keys");const o=[];for(let r=0;r<i.length;r++){const c=Object.getOwnPropertyDescriptor(i,String(r));if(!c||!("value"in c))throw new Error("Sparse array or JSON accessor");o.push(t(c.value))}a="["+o.join(",")+"]"}else{if(Object.getPrototypeOf(i)!==Object.prototype&&Object.getPrototypeOf(i)!==null)throw new Error("Non-plain JSON object");if(Object.getOwnPropertySymbols(i).length)throw new Error("Symbol keys");if(Object.getOwnPropertyNames(i).length!==Object.keys(i).length)throw new Error("Non-enumerable JSON property");const o=i;a="{"+Object.keys(o).sort().map(r=>{const c=Object.getOwnPropertyDescriptor(o,r);if(!c||!("value"in c))throw new Error("JSON accessors forbidden");return JSON.stringify(r)+":"+t(c.value)}).join(",")+"}"}return e.delete(i),a};return t(n)}function Tt(n,e){if(!n)throw new Error(`INVALID_DATA: ${e}`)}const st=n=>new Set(n).size===n.length;function vm(n,e){const t=Ce.parse(n);return Tt(t.shotSectorWeights.some(i=>i>0),"shot sector total must be positive"),Tt(st(t.variations)&&t.variations.every(i=>e.includes(i)),"unknown or duplicate variation"),t}function Vi(n,e,t){const i=vt.parse(n);Tt(st(i.players.map(o=>o.playerId))&&st(i.teams.map(o=>o.teamId))&&st(i.grounds.map(o=>o.groundId)),"duplicate world IDs"),i.players.forEach(o=>vm(o,e));const a=new Set(i.players.map(o=>o.playerId));return Tt(i.teams.every(o=>st(o.squadIds)&&o.squadIds.every(r=>a.has(r))),"invalid squad references"),Tt(st(i.rulesIds)&&i.rulesIds.every(o=>t.includes(o)),"unknown rule references"),i}const ct=d({rulesId:O(["LC_T20_01","LC_ODI_01","LC_RED5_01"]),inningsIndex:l,deliveryIndex:l,battingTeamId:s,bowlingTeamId:s,strikerId:s,nonStrikerId:s,bowlerId:s,keeperId:s,outfieldIds:v(s).length(9),endsBefore:d({north:s,south:s}),strikerEnd:ot,runs:l,wickets:l.max(9),legalBalls:l,allocatedBalls:x.nullable(),targetToWin:x.nullable(),freeHitPending:H(),ballAgeLegalBalls:l}),ti=d({stage:O(["DELIVERY","IMMEDIATE_PENALTY"]),legality:O(["LEGAL","WIDE","NO_BALL","DEAD"]),batRuns:l,extras:Pi,completedRuns:l,attemptedRuns:l,boundary:O(["NONE","FOUR","SIX"]),dismissal:d({kind:O(["BOWLED","LBW","CAUGHT","RUN_OUT","STUMPED","HIT_WICKET"]),playerId:s,fielderId:s.nullable(),wicketEnd:ot}).nullable(),endsAfter:d({north:s.nullable(),south:s.nullable()}),batContact:H(),attemptedStroke:H(),shotSector:l.max(7).nullable(),trajectory:O(["GROUND","AERIAL","EDGE"]).nullable(),executedLength:O(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"]).nullable(),fieldOutcome:O(["NONE","STOP","DROP","CATCH","MISS","RUN_OUT"]),elapsedSeconds:l}),bm=O(["INVALID_STRUCTURE","INVALID_CONTEXT","UNSUPPORTED_PENALTY","INVALID_EXTRAS","INVALID_BOUNDARY","INVALID_RUNNING","INVALID_DISMISSAL","INVALID_ENDS","INVALID_IMMEDIATE_PENALTY","UNSAFE_TOTAL"]),gr=d({event:Qt,delta:d({teamRuns:l,batterRuns:l,bowlerRuns:l,legalBalls:l.max(1),ballsFaced:l.max(1),wickets:l.max(1),bowlerWickets:l.max(1),deliveryAttempts:m(1)}),totals:d({runs:l,wickets:l.max(10),legalBalls:l,ballAgeLegalBalls:l}),strikerEndAfter:ot,nextStrikerId:s.nullable(),requiredBatterEnd:ot.nullable(),freeHitPending:H(),overCompleted:H(),inningsComplete:H(),result:Ge.nullable(),events:v(O(["DELIVERY_RECORDED","OVER_COMPLETED","INNINGS_COMPLETED","MATCH_COMPLETED"])).min(1),nextAction:O(["ADVANCE","SELECT_BATTER","SELECT_BOWLER","START_NEXT_INNINGS","NONE"])}),lt={id:s,source:w().min(1),description:w().min(1),reasoning:w().min(1),tags:v(s).min(1)},Tm=d({...lt,context:ct,resolution:ti,expected:gr}),Rm=d({...lt,context:tt(),resolution:tt(),expectedError:bm}),Lm=d({...lt,rulesId:O(["LC_T20_01","LC_ODI_01","LC_RED5_01"]),teamIds:wn([s,s]),innings:v(d({teamId:s,runs:l,wickets:l.max(10),legalBalls:l,complete:H()})).min(1).max(4),timeExpired:H(),expected:d({result:Ge.nullable(),targetToWin:x.nullable(),phase:Fi,nextAction:O(["ADVANCE","START_NEXT_INNINGS","NONE"])})}),Am=d({...lt,trigger:O(["WICKET","INNINGS_COMPLETED","RAIN_DELAY","NEW_BALL","TARGET_REACHED"]),before:d({clock:rt,inningsLegalBalls:l,ballAgeLegalBalls:l,runs:l,targetToWin:x.nullable()}),input:d({attemptSeconds:l,wicketSeconds:l,overSeconds:l,delaySeconds:l,replacementSeconds:l,batRuns:l}),expected:d({clock:rt,inningsLegalBalls:l,ballAgeLegalBalls:l,phase:Fi,nextAction:O(["SELECT_BATTER","START_NEXT_INNINGS","ADVANCE","NONE"]),intervalSeconds:l,events:v(s)})}),Om=An("category",[d({...lt,category:m("PERSISTENCE"),before:d({durableRevision:l,lastSequence:l}),input:d({commandId:s,retryCommitted:H(),provisionalEvents:l,abortWrite:H()}),expected:d({durableRevision:l,lastSequence:l,extraCommittedEvents:l,returnOriginalReceipt:H(),resumeFromPreviousCheckpoint:H()})}),d({...lt,category:m("NRR"),input:d({runs:l,legalBalls:l,allocatedBalls:x,allOut:H(),successfulChase:H()}),expected:d({battingDenominatorBalls:x})})]);d({fixtureVersion:m("1.0.0"),authority:m("Lord_Cricket_XXVI_Technical_Design_V0_1(1).docx"),scorerImplemented:m(!1),deliveries:v(Tm).min(1),invalid:v(Rm).min(1),terminal:v(Lm).min(1),clock:v(Am).min(1),deferred:v(Om).min(1)}),d({context:ct,resolution:ti});const Rt="LC_SCORING_V1",wm=d({runs:l,ballsFaced:l,fours:l,sixes:l,dismissed:H()}),Nm=d({runsConceded:l,legalBalls:l,wickets:l,maidens:l}),Dm=d({engineVersion:m(Rt),rulesId:O(["LC_T20_01","LC_ODI_01","LC_RED5_01"]),innings:xi,nextDeliveryIndex:l,batting:cn(s,wm),dismissals:cn(s,dr),bowling:cn(s,Nm),keeperId:s,outfieldIds:v(s).length(9),currentOverRuns:l}),qn="LC_INTEGER_PROBABILITY_V1",me="LC_EXP_LUT_V1",le="synthetic-alpha-01",Cm=1e4,dt=4294967296,ym=k().int().min(-2e4).max(2e4),$i=k().int().min(-1e5).max(1e5),km=k().int().min(-2e5).max(2e5),Bm=d({coefficientBp:$i,featureBp:ym}),Pm=d({id:s,baseWeight:k().int().min(0).max(1e9),allowed:H(),interceptBp:km,terms:v(Bm).max(32)}),Wi=d({probabilityVersion:m(qn),modelId:m(le),modelHash:b,lutVersion:m(me),lutHash:b,categories:v(Pm).min(1).max(32)}),xm=Wi.extend({kind:m("NORMALISE_CATEGORIES")}),Fm=Wi.extend({kind:m("SAMPLE_CATEGORY"),stageName:s,randomVersion:m("SHA256_COUNTER_V1"),address:ei}),Hm=An("kind",[xm,Fm]),pr=d({id:s,baseWeight:k().int().min(0).max(1e4)}),Mm=d({manifest:d({modelId:m(le),schemaVersion:m("1.0.0"),status:m("SYNTHETIC_ALPHA"),randomId:m("SHA256_COUNTER_V1"),fixedPointScale:m(Cm),expLutHash:b,featureSpecHash:b,variationIds:v(s),effects:d({overAroundWicket:m(!1),individualVariations:m(!1),moisture:m(!1),geometryEffects:m(!1),outfieldSpeed:m(!1)})}),probabilityVersion:m(qn),lutVersion:m(me),lutScale:m("1000000000000"),lutStepBp:m(100),lutMinDeltaBp:m(-16e4),lutMaxDeltaBp:m(0),logitMinBp:m(-8e4),logitMaxBp:m(8e4),coefficients:d({legality:cn(s,cn(s,$i)),contact:cn(s,cn(s,$i))}),featureSpec:d({maxTerms:m(32),fixedPointScale:m(1e4),termMultiplyRounding:m("NEAREST_TIES_AWAY_FROM_ZERO"),accumulationOrder:m("INTERCEPT_TERMS_IN_ARRAY_ORDER"),clipTiming:m("AFTER_SUM"),lutDeltaRounding:m("NEAREST_TIES_AWAY_FROM_ZERO"),categoryOrder:m("AS_SUPPLIED"),massAllocation:m("LARGEST_REMAINDER_CATEGORY_INDEX")}),expLutValues:v(k().int().min(1).max(1e12)).length(1601),baselines:d({legality:v(pr).length(3),contact:cn(s,v(pr).length(6))})}),Vm=d({controlRating:k().int().min(0).max(100),fatigueBp:k().int().min(0).max(1e4),line:O(["OFF","STUMPS","LEG"]),effort:O(["CONSERVE","NORMAL","MAXIMUM"])}),$m=d({phase:O(["T20_EARLY","T20_MIDDLE","T20_LATE","ODI_EARLY","ODI_MIDDLE","ODI_LATE","RED_BALL"]),defenceRating:k().int().min(0).max(100),timingRating:k().int().min(0).max(100),powerRating:k().int().min(0).max(100),effectiveMovementBp:k().int().min(-1e4).max(1e4),aggression:k().int().min(0).max(4)}),ii="LC_CONDITIONAL_DELIVERY_V1",Ir="synthetic-alpha-01-delivery-v1",Wm=O(["OFF","STUMPS","LEG"]),Um=O(["YORKER","FULL","GOOD","SHORT"]),Gm=O(["CONSERVE","NORMAL","MAXIMUM"]),zm=O(["INNER","MIDDLE","DEEP"]),Km=d({playerId:s,sector:l.max(7),depth:zm,role:O(["NORMAL","SLIP","GULLY"]),catchingRating:gn,throwingRating:gn}),Ym=d({kind:m("GENERATE_DELIVERY"),generatorVersion:m(ii),stagePackId:m(Ir),stagePackHash:b,randomVersion:m("SHA256_COUNTER_V1"),probabilityVersion:m(qn),modelId:m(le),modelHash:b,lutVersion:m(me),lutHash:b,rulesHash:b,matchId:s,seed:w().min(1).max(256),attemptOrdinal:l,format:$n,phase:O(["T20_EARLY","T20_MIDDLE","T20_LATE","ODI_EARLY","ODI_MIDDLE","ODI_LATE","RED_BALL"]),context:ct,bowling:d({bowlingStyle:Jt,controlRating:gn,movementRating:gn,fatigueBp:kn,line:Wm,intendedLength:Um,effort:Gm,variationId:m("stock")}),batting:d({defenceRating:gn,timingRating:gn,powerRating:gn,rotationRating:gn,vsPaceRating:gn,vsSpinRating:gn,aggression:k().int().min(0).max(4),intent:O(["NORMAL","ROTATE","PROTECT"]),attemptedStroke:H(),shotSectorWeights:v(k().int().min(0).max(1e4)).length(8)}),conditions:d({seamBp:kn,turnBp:kn}),field:d({keeper:d({keepingRating:gn,catchingRating:gn,throwingRating:gn}),slots:v(Km).length(9)})}),jm=d({stageName:s,address:ei,draw:k().int().min(0).max(4294967295),selectedCategoryId:s,categories:v(d({id:s,allowed:H(),logitBp:k().int().nullable(),lutIndex:k().int().nullable(),mass:l,cumulative:l})).min(1)}),Zm=d({kind:m("GENERATED_DELIVERY"),generatorVersion:m(ii),modelHash:b,stagePackHash:b,internalOnly:m(!0),trace:v(jm).min(2),resolution:ti}),Xm=d({worldPackId:m("fictional-eight-01"),schemaVersion:m("1.0.0"),worldGeneratorVersion:m("LC_FICTIONAL_WORLD_GENERATOR_V1"),worldSeed:w().min(1).max(256),generatorSourceSha256:b,provenanceSourceSha256:b,worldFileSha256:b,worldCanonicalSha256:b,worldByteLength:k().int().min(1).max(25e6),rulesIds:v(s).length(3),modelId:m("synthetic-alpha-01"),modelHash:b,stagePackId:m("synthetic-alpha-01-delivery-v1"),stagePackHash:b,randomId:m("SHA256_COUNTER_V1"),variationIds:v(s).min(1),provenance:m("FICTIONAL"),modelStatus:m("SYNTHETIC_ALPHA"),teamIds:v(s).length(8),groundIds:v(s).length(8),homeGroundIds:cn(s,s)}),Hn=d({teamId:s,playerIds:v(s).length(11),captainId:s,keeperId:s}),hr=d({setup:Hi,worldFileSha256:b,worldCanonicalSha256:b,rulesHash:b,modelHash:b,stagePackHash:b,setupVersion:m("LC_T20_SETUP_V1"),selectedTeams:wn([Hn,Hn])}),qm=d({setup:Hi,worldFileSha256:b,worldCanonicalSha256:b,rulesHash:b,modelHash:b,stagePackHash:b,setupVersion:m("LC_ODI_SETUP_V1"),selectedTeams:wn([Hn,Hn])});d({setup:Hi,worldFileSha256:b,worldCanonicalSha256:b,rulesHash:b,modelHash:b,stagePackHash:b,setupVersion:m("LC_RED5_SETUP_V1"),selectedTeams:wn([Hn,Hn])});const fr="LC_T20_MATCH_V1",oe="LC_T20_EVENT_CHAIN_V1",Ui="LC_T20_CONDITIONS_V1",Er=d({engine:m(fr),eventChain:m(oe),conditionPolicy:m(Ui),conditionPolicyHash:b,setupHash:b,worldHash:b,rulesHash:b,modelHash:b,stagePackHash:b,randomVersion:m("SHA256_COUNTER_V1"),scoringVersion:m("LC_SCORING_V1"),probabilityVersion:m("LC_INTEGER_PROBABILITY_V1")}),Sr=An("kind",[d({commandId:s,expectedRevision:l,actorId:s,kind:m("CONFIRM_TEAMS"),payload:d({})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("CALL_TOSS"),payload:d({teamId:s,call:O(["HEADS","TAILS"])})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("CHOOSE_INNINGS"),payload:d({teamId:s,choice:O(["BAT","BOWL"])})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_BATTER"),payload:d({teamId:s,playerId:s})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_BOWLER"),payload:d({teamId:s,bowlerId:s})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_FIELD"),payload:d({teamId:s,fieldSlots:v(d({slotId:s,playerId:s})).length(9)})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_BATTING_PLAN"),payload:St}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_BOWLING_PLAN"),payload:_t}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("ADVANCE"),payload:d({scope:O(["DELIVERY","OVER"])})})]),ai=d({version:m(oe),sequence:l.min(1),commandId:s,type:s,payload:tt(),previousHash:b,stateHash:b,eventHash:b}),Jm=d({commandId:s,committedRevision:l.min(1),fromSequence:l.min(1),toSequence:l.min(1),lastEventHash:b}),Lt=d({version:m(oe),genesisHash:b,finalEventHash:b,finalStateHash:b,eventCount:l,executionManifestHash:b}),Gi=d({matchId:s,innings:v(d({battingTeamId:s,bowlingTeamId:s,runs:l,wickets:l,legalBalls:l,overs:w(),extras:d({wides:l,noBalls:l,byes:l,legByes:l,penalties:l}),batting:cn(s,d({runs:l,ballsFaced:l,fours:l,sixes:l,dismissed:H()})),bowling:cn(s,d({runsConceded:l,legalBalls:l,wickets:l,maidens:l})),fallOfWickets:v(d({playerId:s,runs:l,legalBalls:l,sequence:l})),targetToWin:l.nullable()})).length(2),result:Ge});d({caseId:s,seed:w().min(1).max(256),teamIds:wn([s,s]),groundId:s,modelId:m("synthetic-alpha-01"),rulesId:m("LC_T20_01"),stagePackId:m("synthetic-alpha-01-delivery-v1"),fixtureCaptainPolicyId:m("LC_FIXTURE_CAPTAIN_V1"),expectedFinalEventHash:b.nullable(),expectedScorecardSha256:b.nullable(),oracleStatus:O(["NOT_AUTHORED_UNTIL_PASS_07B","GENERATED_FROM_PRODUCTION_NOT_INDEPENDENT"])});const Qm="LC_ODI_MATCH_V1",zi="LC_ODI_EVENT_CHAIN_V1",ng=d({engine:m(Qm),eventChain:m(zi),conditionPolicy:m("LC_ODI_CONDITIONS_V1"),conditionPolicyHash:b,setupHash:b,worldHash:b,rulesHash:b,modelHash:b,stagePackHash:b,randomVersion:m("SHA256_COUNTER_V1"),scoringVersion:m("LC_SCORING_V1"),probabilityVersion:m("LC_INTEGER_PROBABILITY_V1")}),eg=An("kind",[d({commandId:s,expectedRevision:l,actorId:s,kind:m("CONFIRM_TEAMS"),payload:d({})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("CALL_TOSS"),payload:d({teamId:s,call:O(["HEADS","TAILS"])})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("CHOOSE_INNINGS"),payload:d({teamId:s,choice:O(["BAT","BOWL"])})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_BATTER"),payload:d({teamId:s,playerId:s})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_BOWLER"),payload:d({teamId:s,bowlerId:s})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_FIELD"),payload:d({teamId:s,fieldSlots:v(d({slotId:s,playerId:s})).length(9)})}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_BATTING_PLAN"),payload:St}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("SET_BOWLING_PLAN"),payload:_t}),d({commandId:s,expectedRevision:l,actorId:s,kind:m("ADVANCE"),payload:d({scope:O(["DELIVERY","OVER"])})})]);d({version:m(zi),sequence:l.min(1),commandId:s,type:s,payload:tt(),previousHash:b,stateHash:b,eventHash:b}),d({commandId:s,committedRevision:l.min(1),fromSequence:l.min(1),toSequence:l.min(1),lastEventHash:b}),d({version:m(zi),genesisHash:b,finalEventHash:b,finalStateHash:b,eventCount:l,executionManifestHash:b}),d({matchId:s,innings:v(d({battingTeamId:s,bowlingTeamId:s,runs:l,wickets:l,legalBalls:l,overs:w(),extras:d({wides:l,noBalls:l,byes:l,legByes:l,penalties:l}),batting:cn(s,d({runs:l,ballsFaced:l,fours:l,sixes:l,dismissed:H()})),bowling:cn(s,d({runsConceded:l,legalBalls:l,wickets:l,maidens:l})),fallOfWickets:v(d({playerId:s,runs:l,legalBalls:l,sequence:l})),targetToWin:l.nullable()})).length(2),result:Ge}),d({caseId:s,seed:w().min(1).max(256),teamIds:wn([s,s]),groundId:s,modelId:m("synthetic-alpha-01"),rulesId:m("LC_ODI_01"),stagePackId:m("synthetic-alpha-01-delivery-v1"),fixtureCaptainPolicyId:m("LC_FIXTURE_CAPTAIN_V1"),expectedFinalEventHash:b.nullable(),expectedScorecardSha256:b.nullable(),oracleStatus:O(["NOT_AUTHORED_UNTIL_PASS_07B","GENERATED_FROM_PRODUCTION_NOT_INDEPENDENT"])});const tg="LC_RED5_MATCH_V1",Ki="LC_RED5_EVENT_CHAIN_V1",ig="LC_RED5_CONDITIONS_V1",ag=d({day:k().int().min(1).max(5),localSeconds:k().int().min(0).max(24*3600),phase:O(["PLAY","LUNCH","TEA","INNINGS_INTERVAL","STUMPS","RAIN","COMPLETE"]),dayLegalBalls:l,finalHourActive:H(),finalHourBallsRemaining:l,overMustFinish:H(),delaySecondsToday:l}),og=d({engine:m(tg),eventChain:m(Ki),conditionPolicy:m(ig),conditionPolicyHash:b,setupHash:b,worldHash:b,rulesHash:b,modelHash:b,stagePackHash:b,randomVersion:m("SHA256_COUNTER_V1"),scoringVersion:m("LC_SCORING_V1"),probabilityVersion:m("LC_INTEGER_PROBABILITY_V1")}),Jn=(n,e)=>d({commandId:s,expectedRevision:l,actorId:s,kind:m(n),payload:e}),rg=An("kind",[Jn("CONFIRM_TEAMS",d({})),Jn("CALL_TOSS",d({teamId:s,call:O(["HEADS","TAILS"])})),Jn("CHOOSE_INNINGS",d({teamId:s,choice:O(["BAT","BOWL"])})),Jn("SET_BATTER",d({teamId:s,playerId:s})),Jn("SET_BOWLER",d({teamId:s,bowlerId:s})),Jn("SET_FIELD",d({teamId:s,fieldSlots:v(d({slotId:s,playerId:s})).length(9)})),Jn("SET_BATTING_PLAN",St),Jn("SET_BOWLING_PLAN",_t),Jn("ADVANCE",d({scope:O(["DELIVERY","OVER"])})),Jn("DECLARE",d({teamId:s})),Jn("CHOOSE_FOLLOW_ON",d({teamId:s,enforce:H()})),Jn("TAKE_NEW_BALL",d({teamId:s})),Jn("ADD_RAIN_DELAY",d({seconds:k().int().min(60).max(6*3600)}))]);d({version:m(Ki),sequence:l.min(1),commandId:s,type:s,payload:tt(),previousHash:b,stateHash:b,eventHash:b}),d({commandId:s,committedRevision:l.min(1),fromSequence:l.min(1),toSequence:l.min(1),lastEventHash:b}),d({version:m(Ki),genesisHash:b,finalEventHash:b,finalStateHash:b,eventCount:l,executionManifestHash:b});const sg=d({battingTeamId:s,bowlingTeamId:s,runs:l,wickets:l,legalBalls:l,overs:w(),declared:H(),batting:cn(s,d({runs:l,ballsFaced:l,fours:l,sixes:l,dismissed:H()})),bowling:cn(s,d({runsConceded:l,legalBalls:l,wickets:l,maidens:l}))});d({matchId:s,innings:v(sg).max(4),result:Ge,clock:ag,followOnEnforced:H()});const cg=d({competitionVersion:m("LC_T20_LEAGUE_COMPETITION_V1"),competitionId:m("LC_T20_LEAGUE_01"),format:m("T20"),worldPackId:m("fictional-eight-01"),worldCanonicalSha256:b,teamIds:v(s).length(8),groundIds:v(s).length(8),homeGroundIds:cn(s,s),teamCount:m(8),rounds:m(14),matchesPerRound:m(4),totalFixtures:m(56),roundSpacingDays:m(3),playoffs:m(!1),points:d({win:m(2),tie:m(1),noResult:m(1),loss:m(0)}),tableOrder:wn([m("POINTS"),m("WINS"),m("NET_RUN_RATE"),m("HEAD_TO_HEAD_POINTS"),m("TEAM_ID")]),rainAdjustedNrr:m(!1),schedulerAlgorithm:m("CIRCLE_REVERSE_VENUES_V1")});d({scheduleVersion:m("LC_T20_SEASON_SCHEDULE_V1"),seasonId:s,gameId:s,competitionId:m("LC_T20_LEAGUE_01"),worldPackId:m("fictional-eight-01"),worldCanonicalSha256:b,seasonSeed:w().min(1).max(256),startDate:Q(),teamIds:v(s).length(8),groundIds:v(s).length(8),homeGroundIds:cn(s,s)});const _r=d({fixtureId:s,matchId:s,ordinal:k().int().min(0).max(55),roundNumber:x.max(14),roundFixtureIndex:x.max(4),matchDayDate:Q(),homeTeamId:s,awayTeamId:s,groundId:s,matchSeed:b,status:m("SCHEDULED")}),vr=d({roundNumber:x.max(14),matchDayDate:Q(),fixtureIds:v(s).length(4)}),br={scheduleVersion:m("LC_T20_SEASON_SCHEDULE_V1"),schedulerAlgorithm:m("CIRCLE_REVERSE_VENUES_V1"),seasonId:s,gameId:s,competitionId:m("LC_T20_LEAGUE_01"),worldPackId:m("fictional-eight-01"),worldCanonicalSha256:b,seasonSeedHash:b,startDate:Q(),teamIds:v(s).length(8),groundIds:v(s).length(8),homeGroundIds:cn(s,s),rounds:v(vr).length(14),fixtures:v(_r).length(56)};d(br);const lg=d({...br,scheduleSha256:b}),dg=d({conditionPolicyVersion:m("LC_T20_CAREER_CONDITION_V1"),maxFatigueBp:m(1e4),restRecoveryPerDayBp:m(2e3),practiceRecoveryPerDayBp:m(1400),noRandomInjuries:m(!0)}),ug=d({playerId:s,startDate:Q(),endDate:Q(),reason:w().min(1).max(240),source:m("MANUAL_FIXTURE_PACK")}),mg=d({availabilityVersion:m("LC_T20_AVAILABILITY_PACK_V1"),packId:s,worldPackId:m("fictional-eight-01"),worldCanonicalSha256:b,entries:v(ug).max(320)}),Yi=d({playerId:s,fatigueBp:kn,lastUpdatedDate:Q()}),ji=d({matchCompletionKey:s,matchId:s,matchDayDate:Q(),payloadSha256:b}),Zi=d({deltaVersion:m("LC_T20_MATCH_CONDITION_DELTA_V1"),matchCompletionKey:s,matchId:s,matchDayDate:Q(),playerFatigueDeltaBp:cn(s,kn)}),Tr={careerStateVersion:m("LC_T20_CAREER_DAY_STATE_V1"),conditionPolicyVersion:m("LC_T20_CAREER_CONDITION_V1"),careerId:s,gameId:s,seasonId:s,competitionId:m("LC_T20_LEAGUE_01"),scheduleVersion:m("LC_T20_SEASON_SCHEDULE_V1"),scheduleSha256:b,worldPackId:m("fictional-eight-01"),worldCanonicalSha256:b,availabilityPackId:s,availabilityPackSha256:b,startDate:Q(),finalScheduledDate:Q(),currentDate:Q(),revision:k().int().min(0).max(Number.MAX_SAFE_INTEGER),playerConditions:v(Yi).length(160),appliedMatchConditions:v(ji).max(56)};d(Tr),d({...Tr,stateSha256:b});const gg=d({playerId:s,fatigueBp:kn,availability:O(["AVAILABLE","UNAVAILABLE"]),availabilityReason:w().min(1).max(240).nullable(),unavailableThrough:Q().nullable()});d({teamId:s,date:Q(),players:v(gg).length(20)}),d({command:m("ADVANCE_DAY"),previousDate:Q(),currentDate:Q(),recoveredPlayers:l,recoveryPerPlayerBp:m(2e3),revision:k().int().min(1).max(Number.MAX_SAFE_INTEGER),stateSha256:b});const pg=d({trainingPolicyVersion:m("LC_T20_CAREER_TRAINING_V1"),readinessMinRatingDelta:m(-3),readinessMaxRatingDelta:m(3),readinessPracticeGainPerDay:m(1),readinessDecayPerDay:m(1),restRecoveryPerDayBp:m(2e3),practiceRecoveryPerDayBp:m(1400),noPermanentAttributeGrowth:m(!0)}),ut=O(["REST","BATTING_PRACTICE","BOWLING_PRACTICE","FIELDING_PRACTICE"]),Rr=d({playerId:s,batting:k().int().min(-3).max(3),bowling:k().int().min(-3).max(3),fielding:k().int().min(-3).max(3),lastUpdatedDate:Q()}),Lr=d({playerId:s,directive:ut}),Ar={careerStateVersion:m("LC_T20_CAREER_DAY_STATE_V2"),conditionPolicyVersion:m("LC_T20_CAREER_CONDITION_V1"),trainingPolicyVersion:m("LC_T20_CAREER_TRAINING_V1"),careerId:s,gameId:s,seasonId:s,competitionId:m("LC_T20_LEAGUE_01"),scheduleVersion:m("LC_T20_SEASON_SCHEDULE_V1"),scheduleSha256:b,worldPackId:m("fictional-eight-01"),worldCanonicalSha256:b,availabilityPackId:s,availabilityPackSha256:b,startDate:Q(),finalScheduledDate:Q(),currentDate:Q(),revision:k().int().min(0).max(Number.MAX_SAFE_INTEGER),playerConditions:v(Yi).length(160),playerReadiness:v(Rr).length(160),trainingAssignments:v(Lr).length(160),appliedMatchConditions:v(ji).max(56)};d(Ar);const Ig=d({...Ar,stateSha256:b});d({command:m("SET_TRAINING_DIRECTIVE"),playerId:s,directive:ut,effectiveDate:Q(),expectedRevision:k().int().min(0).max(Number.MAX_SAFE_INTEGER)}),d({command:m("SET_TRAINING_DIRECTIVE"),playerId:s,previousDirective:ut,directive:ut,changed:H(),revision:k().int().min(0).max(Number.MAX_SAFE_INTEGER),stateSha256:b}),d({command:m("ADVANCE_DAY"),previousDate:Q(),currentDate:Q(),restPlayers:l,practicePlayers:l,recoveredPlayers:l,readinessChangedPlayers:l,restRecoveryPerPlayerBp:m(2e3),practiceRecoveryPerPlayerBp:m(1400),revision:k().int().min(1).max(Number.MAX_SAFE_INTEGER),stateSha256:b});const Or=d({playerId:s,fatigueBp:kn,availability:O(["AVAILABLE","UNAVAILABLE"]),availabilityReason:w().min(1).max(240).nullable(),unavailableThrough:Q().nullable(),directive:ut,battingReadiness:k().int().min(-3).max(3),bowlingReadiness:k().int().min(-3).max(3),fieldingReadiness:k().int().min(-3).max(3)});d({teamId:s,date:Q(),players:v(Or).length(20)});const hg=d({policyVersion:m("LC_T20_OFFSCREEN_POLICY_V1"),executionVersion:m("LC_T20_OFFSCREEN_FIXTURE_V1"),selectionPolicyId:m("LC_SEASON_XI_BASELINE_V1"),captainPolicyId:m("LC_FIXTURE_CAPTAIN_V1"),conditionDeltaPolicyId:m("LC_ENGINE_FINAL_FATIGUE_DELTA_V1"),matchEngineVersion:m("LC_T20_MATCH_V1"),selectionScorePolicy:m("SUM_SUPPORTED_T20_SKILLS_PLUS_AREA_READINESS_V1"),unavailablePlayersExcluded:m(!0),fatigueSelectionEffect:m("LOWER_FATIGUE_STABLE_TIEBREAK_ONLY"),minimumNonKeeperBowlingCapable:m(5),requiresKeeper:m(!0),noFutureRandomAccess:m(!0),noAlternateMatchSimulator:m(!0)}),wr={executionVersion:m("LC_T20_OFFSCREEN_FIXTURE_V1"),policyVersion:m("LC_T20_OFFSCREEN_POLICY_V1"),fixtureId:s,matchId:s,roundNumber:k().int().min(1).max(14),roundFixtureIndex:k().int().min(1).max(4),matchDayDate:Q(),homeTeamId:s,awayTeamId:s,groundId:s,scheduleSha256:b,matchSeedHash:b,careerRevisionBefore:l,careerRevisionAfter:l,careerStateSha256Before:b,careerStateSha256After:b,selectionPolicyId:m("LC_SEASON_XI_BASELINE_V1"),captainPolicyId:m("LC_FIXTURE_CAPTAIN_V1"),conditionDeltaPolicyId:m("LC_ENGINE_FINAL_FATIGUE_DELTA_V1"),selectedTeams:wn([Hn,Hn]),eventChain:Lt,eventLogSha256:b,commandLogSha256:b,scorecard:Gi,scorecardSha256:b,conditionDelta:Zi,conditionDeltaSha256:b};d(wr);const Nr=d({...wr,outcomeSha256:b}),Dr={executionVersion:m("LC_T20_OFFSCREEN_ROUND_V1"),seasonId:s,roundNumber:k().int().min(1).max(14),matchDayDate:Q(),scheduleSha256:b,userTeamId:s.nullable(),skippedUserFixtureId:s.nullable(),executedFixtureIds:v(s).max(4),outcomes:v(Nr).max(4),careerRevisionBefore:l,careerRevisionAfter:l,careerStateSha256Before:b,careerStateSha256After:b};d(Dr),d({...Dr,executionSha256:b});const Cr=k().int().min(Number.MIN_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),oi=d({completionVersion:m("LC_T20_SEASON_MATCH_COMPLETION_V1"),seasonId:s,scheduleSha256:b,fixtureId:s,matchId:s,fixtureOrdinal:k().int().min(0).max(55),roundNumber:x.max(14),matchDayDate:Q(),homeTeamId:s,awayTeamId:s,source:O(["OFFSCREEN","USER_MATCH"]),sourceCompletionSha256:b,selectedTeams:wn([Hn,Hn]),scorecard:Gi,scorecardSha256:b}),fg=d({fixtureId:s,matchId:s,fixtureOrdinal:k().int().min(0).max(55),roundNumber:x.max(14),homeTeamId:s,awayTeamId:s,sourceCompletionSha256:b,resultKind:O(["WIN","TIE","NO_RESULT"]),winnerTeamId:s.nullable(),homePoints:l.max(2),awayPoints:l.max(2),nrrEligible:H(),homeRuns:l,homeBalls:l,awayRuns:l,awayBalls:l}),Xi=d({rank:x.max(8),teamId:s,played:l.max(14),wins:l.max(14),losses:l.max(14),ties:l.max(14),noResults:l.max(14),points:l.max(28),runsFor:l,ballsFor:l,runsAgainst:l,ballsAgainst:l,nrrNumerator:Cr,nrrDenominator:x.nullable(),nrrX1000:Cr.nullable(),headToHeadPoints:l.max(28)}),qi=d({playerId:s,teamId:s,matches:l.max(14),runs:l,dismissals:l.max(14),ballsFaced:l,fours:l,sixes:l,battingAverageX100:l.nullable(),strikeRateX100:l.nullable(),bowlingRunsConceded:l,bowlingLegalBalls:l,bowlingWickets:l,maidens:l,bowlingAverageX100:l.nullable(),economyX100:l.nullable(),bowlingStrikeRateX100:l.nullable()}),ri=d({playerId:s,teamId:s,value:l}),si=d({runs:v(ri).max(10),wickets:v(ri).max(10)}),Eg=d({appliedCount:l.max(56),highestAppliedFixtureOrdinal:k().int().min(0).max(55).nullable(),missingFixtureOrdinals:v(k().int().min(0).max(55)).max(56)}),yr=d({projectionVersion:m("LC_T20_SEASON_PROJECTION_V1"),seasonId:s,scheduleSha256:b,competitionId:m("LC_T20_LEAGUE_01"),revision:l.max(56),cursor:Eg,appliedMatches:v(fg).max(56),table:v(Xi).length(8),players:v(qi).max(160),leaders:si}),Sg=1e6,_g="LC_COMPLETED_CAREER_MATCH_EVENT_ARCHIVE_V1",kr={seasonStateVersion:m("LC_T20_SEASON_STATE_V1"),seasonId:s,gameId:s,careerId:s,controlledTeamId:s.nullable(),schedule:lg,careerState:Ig,projection:yr,completedMatches:v(oi).max(56),revision:l,phase:O(["ACTIVE","COMPLETE"])};d(kr);const Br=d({...kr,stateSha256:b}),vg=d({saveId:s,kind:O(["AUTO","MANUAL","IMPORTED"]),title:w().min(1).max(240),seasonId:s,careerId:s,controlledTeamId:s.nullable(),currentDate:Q(),revision:l,completedFixtures:l.max(56),phase:O(["ACTIVE","COMPLETE"]),stateSha256:b,updatedAt:Ee()});d({commandId:s,requestCanonical:w(),responseJson:w(),committedRevision:l});const bg=d({archiveVersion:m("LC_T20_SEASON_ARCHIVE_V1"),seasonId:s,careerId:s,scheduleSha256:b,stateSha256:b,projectionRevision:m(56),fixtureCount:m(56),completedAt:Ee(),championTeamId:s,finalTable:v(Xi).length(8),leaders:si,completionKeys:v(s).length(56)}),Tg=d({...bg.shape,archiveSha256:b});d({saveId:s,requestedGeneration:k().int().min(0).max(2).nullable(),recoveredGeneration:k().int().min(0).max(2).nullable(),recoveredCheckpointSerial:l.nullable(),recoveredRevision:l.nullable(),corruptedGenerations:v(k().int().min(0).max(2)).max(3)});const Ji=d({archiveVersion:m("LC_T20_SEASON_PORTABLE_V1"),saveSchema:m("LC_SEASON_SAVE_V1"),exportedAt:Ee(),summary:vg,files:cn(w().min(1),d({bytes:l,sha256:b}))});Ji.extend({archiveVersion:m("LC_T20_SEASON_PORTABLE_V2"),saveSchema:m("LC_SEASON_SAVE_V2_PRESENTATION"),worldCopySha256:b});const Rg=d({archiveVersion:m(_g),seasonId:s,scheduleSha256:b,fixtureId:s,matchId:s,fixtureOrdinal:l.max(55),roundNumber:k().int().min(1).max(14),matchDayDate:Q(),source:O(["OFFSCREEN","USER_MATCH"]),sourceCompletionSha256:b,scorecardSha256:b,setupRequest:hr,eventChain:Lt,eventCount:l.min(1).max(600),finalEventHash:b,eventsSha256:b,events:v(ai).min(1).max(600),byteLength:l.min(1).max(Sg)});d({...Rg.shape,archiveSha256:b});const Lg=d({generation:k().int().min(0).max(2),checkpointSerial:l,revision:l,completedFixtures:l.max(56),currentDate:Q(),phase:O(["ACTIVE","COMPLETE"]),stateSha256:b,createdAt:Ee()});d({saveId:s,title:w().min(1).max(240),currentSerial:l,currentGeneration:k().int().min(0).max(2),corruptedGenerations:v(k().int().min(0).max(2)).max(3),validGenerations:v(Lg).max(3)}),Ji.extend({archiveVersion:m("LC_T20_SEASON_PORTABLE_V3_EVENT_ARCHIVES"),saveSchema:O(["LC_SEASON_SAVE_V1","LC_SEASON_SAVE_V2_PRESENTATION"]),worldCopySha256:b.optional(),matchEventArchiveCount:l.min(1).max(56)});const K=200,Ag="LC_PERSISTENT_WORLD_IDENTITY_V1",Og="LC_COMPLETED_SEASON_RECORD_V1",wg="LC_PERSISTENT_CAREER_PROJECTION_V1",Ng="LC_PERSISTENT_WORLD_ROLLOVER_RECEIPT_V1",Dg="LC_PERSISTENT_WORLD_STATE_V1",Cg="LC_PERSISTENT_WORLD_SAVE_V1",yg="LC_PERSISTENT_WORLD_SAVE_V1_PRESENTATION",kg="LC_PERSISTENT_WORLD_PORTABLE_V1",Qi=d({worldIdentityVersion:m(Ag),worldId:s,worldPackId:s,worldCanonicalSha256:b,baseSeed:w().min(1).max(256),originKind:O(["NEW_PERSISTENT_CAREER","COPIED_FROM_SINGLE_SEASON_V1"]),sourceSingleSeasonSaveId:s.nullable(),sourceSingleSeasonFinalStateSha256:b.nullable()}),Bg=d({completedSeasonVersion:m(Og),seasonNumber:x.max(K),calendarYear:k().int().min(1900).max(9999),seasonId:s,gameId:s,competitionId:m("LC_T20_LEAGUE_01"),startDate:Q(),endDate:Q(),scheduleSha256:b,finalSeasonStateSha256:b,championTeamId:s,runnerUpTeamId:s,seasonArchive:Tg,table:v(Xi).length(8),players:v(qi).max(1e4),leaders:si,completedMatches:v(oi).length(56)}),na=d({...Bg.shape,recordSha256:b}),Pg=d({playerId:s,teamId:s,seasonsPlayed:l.max(K),matches:l,battingInnings:l,notOuts:l,runs:l,dismissals:l,ballsFaced:l,fours:l,sixes:l,fifties:l,hundreds:l,ducks:l,highScoreRuns:l,highScoreNotOut:H(),battingAverageX100:l.nullable(),strikeRateX100:l.nullable(),bowlingInnings:l,bowlingRunsConceded:l,bowlingLegalBalls:l,bowlingWickets:l,maidens:l,bestBowlingWickets:l,bestBowlingRuns:l.nullable(),bowlingAverageX100:l.nullable(),economyX100:l.nullable(),bowlingStrikeRateX100:l.nullable()}),xg=d({teamId:s,seasonsCompleted:l.max(K),titles:l.max(K),runnerUpFinishes:l.max(K),played:l,wins:l,losses:l,ties:l,noResults:l,points:l,runsFor:l,ballsFor:l,runsAgainst:l,ballsAgainst:l}),Fg=d({seasonNumber:x.max(K),calendarYear:k().int().min(1900).max(9999),seasonId:s,championTeamId:s,runnerUpTeamId:s,leadingRunScorer:ri.nullable(),leadingWicketTaker:ri.nullable(),finalSeasonStateSha256:b}),Hg=d({careerProjectionVersion:m(wg),worldId:s,completedSeasonCount:l.max(K),activeSeasonNumber:x.max(K),activeSeasonMatchesApplied:l.max(56),totalMatchesApplied:l,rollOfHonour:v(Fg).max(K),teamHistory:v(xg).length(8),players:v(Pg).max(1e4),leaders:si}),ea=d({...Hg.shape,projectionSha256:b}),ta=d({receiptVersion:m(Ng),fromSeasonNumber:x.max(K-1),toSeasonNumber:x.max(K),closedSeasonId:s,closedSeasonStateSha256:b,closedSeasonRecordSha256:b,nextSeasonId:s,nextStartDate:Q(),nextScheduleSha256:b}),Mg=d({worldStateVersion:m(Dg),worldIdentity:Qi,careerId:s,controlledTeamId:s.nullable(),currentSeasonNumber:x.max(K),currentCalendarYear:k().int().min(1900).max(9999),currentSeason:Br,completedSeasons:v(na).max(K-1),careerProjection:ea,lastRolloverReceipt:ta.nullable(),revision:l});d({...Mg.shape,stateSha256:b});const ia=d({saveId:s,kind:O(["AUTO","MANUAL","IMPORTED"]),title:w().min(1).max(240),worldId:s,careerId:s,controlledTeamId:s.nullable(),currentSeasonNumber:x.max(K),currentCalendarYear:k().int().min(1900).max(9999),completedSeasonCount:l.max(K-1),seasonId:s,currentDate:Q(),revision:l,completedFixtures:l.max(56),phase:O(["ACTIVE","COMPLETE"]),stateSha256:b,updatedAt:Ee()});d({archiveVersion:m(kg),saveSchema:O([Cg,yg]),exportedAt:Ee(),summary:ia,careerProjectionSha256:b,worldCopySha256:b.optional(),matchEventArchiveCount:l.max(K*56),files:cn(w().min(1),d({bytes:l,sha256:b}))});const Pr=25e6,aa=["T20","ODI","RED_BALL"],oa=at.partial(),Vg=d({T20:oa.optional(),ODI:oa.optional(),RED_BALL:oa.optional()}),$g=d({T20:l.optional(),ODI:l.optional(),RED_BALL:l.optional()}),Wg=Ce.omit({skills:!0,exposureBalls:!0,provenance:!0}).extend({skills:Vg.optional(),exposureBalls:$g.optional()}),Ug=d({version:m("LC_ROSTER_IMPORT_V1"),sourceId:s,world:vt.omit({players:!0}).extend({players:v(Wg).min(1).max(1e4)})}),Se=d({version:m("LC_STAGED_ROSTER_PACK_V1"),sourceText:w().max(Pr),sourceHash:b,world:vt,priorFields:v(d({playerId:s,format:O(aa),fields:v(w()),exposureMissing:H()}))}),xr=d({teamId:s,playerIds:v(s).length(11),captainId:s,keeperId:s}),Fr=d({groundId:s,teams:wn([xr,xr])}),Hr=d({gameId:s,matchId:s,seed:w().min(1).max(256),format:O(aa),selection:Fr}),Mr=Er.extend({engine:m("LC_T20_MATCH_ROSTER_V2")});ng.extend({engine:m("LC_ODI_MATCH_ROSTER_V2")}),og.extend({engine:m("LC_RED5_MATCH_ROSTER_V2")});const Gg=d({seasonId:s,gameId:s,seasonSeed:w().min(1).max(256),startDate:Q()}),Vr=d({version:m("LC_T20_ROSTER_SCHEDULE_V2"),request:Gg,rosterPackHash:b,worldHash:b,teamIds:v(s).length(8),groundIds:v(s).length(8),homeGroundIds:cn(s,s),rounds:v(vr).length(14),fixtures:v(_r).length(56),scheduleSha256:b}),$r=d({version:m("LC_T20_ROSTER_CAREER_DAY_V3"),careerId:s,scheduleSha256:b,rosterPackHash:b,worldHash:b,startDate:Q(),finalScheduledDate:Q(),currentDate:Q(),revision:l,playerConditions:v(Yi).min(22).max(1e4),playerReadiness:v(Rr).min(22).max(1e4),trainingAssignments:v(Lr).min(22).max(1e4),appliedMatchConditions:v(ji).max(56),stateSha256:b}),zg=Nr.extend({executionVersion:m("LC_T20_ROSTER_OFFSCREEN_FIXTURE_V2"),policyVersion:m("LC_T20_ROSTER_OFFSCREEN_POLICY_V2"),engineManifest:Mr}),Kg=oi.extend({completionVersion:m("LC_T20_ROSTER_SEASON_COMPLETION_V2")}),Wr=yr.extend({projectionVersion:m("LC_T20_ROSTER_SEASON_PROJECTION_V2"),players:v(qi).max(1e4)}),Yg=d({version:m("LC_T20_ROSTER_MANAGED_FIXTURE_V1"),completion:Kg,conditionDelta:Zi,outcomeSha256:b});d({version:m("LC_T20_ROSTER_SEASON_STATE_V2"),careerId:s,controlledTeamId:s,schedule:Vr,careerState:$r,projection:Wr,outcomes:v(Vn([zg,Yg])).max(56),revision:l,phase:O(["ACTIVE","COMPLETE"]),stateSha256:b}),Ji.extend({archiveVersion:m("LC_T20_ROSTER_SEASON_PORTABLE_V1"),saveSchema:m("LC_SEASON_SAVE_V3_ROSTER"),rosterPackSha256:b});const Ur="LC_PLAYER_LIFECYCLE_MODEL_FICTIONAL_V1",jg="LC_PLAYER_LIFECYCLE_STATE_V1",Zg="LC_PLAYER_LIFECYCLE_STATE_V2_BOUNDED_PACKS",Xg=2,qg="LC_T20_LIFECYCLE_SEASON_STATE_V1",Jg="LC_COMPLETED_CAREER_MATCH_EVENT_ARCHIVE_V2_LIFECYCLE",Qg="LC_PERSISTENT_WORLD_STATE_V2",np="LC_PERSISTENT_WORLD_SAVE_V2",ep="LC_PERSISTENT_WORLD_SAVE_V2_PRESENTATION",tp="LC_PERSISTENT_WORLD_PORTABLE_V2_LIFECYCLE",ip=18,ap=22,op=3,Gr=d({modelVersion:m(Ur),calibrationStatus:m("FICTIONAL_PLACEHOLDER"),disclaimer:w().min(1).max(400),minPermanentSkill:k().int().min(10).max(40),maxPermanentSkill:k().int().min(80).max(100),youthMinAgeYears:k().int().min(16).max(20),youthMaxAgeYears:k().int().min(17).max(22),growthWindowMaxAgeYears:k().int().min(22).max(28),primeWindowMaxAgeYears:k().int().min(27).max(33),earliestVoluntaryRetirementAgeYears:k().int().min(32).max(38),mandatoryRetirementAgeYears:k().int().min(37).max(45),minSquadKeepers:k().int().min(1).max(4),minSquadBowlingCapable:k().int().min(5).max(12)}),rp=d({playerId:s,battingPracticeDays:l.max(366),bowlingPracticeDays:l.max(366),fieldingPracticeDays:l.max(366),restDays:l.max(366)}),At=k().int().min(-25).max(25),zr=d({battingDelta:At,bowlingDelta:At,fieldingDelta:At,keepingDelta:At,staminaDelta:At}),sp=d({playerId:s,teamId:s,ageBefore:k().int().min(15).max(60),ageAfter:k().int().min(16).max(61),matchesPlayed:l.max(56),ballsFaced:l,ballsBowled:l,battingPracticeDays:l.max(366),bowlingPracticeDays:l.max(366),fieldingPracticeDays:l.max(366),restDays:l.max(366),deltas:zr,phaseLabel:O(["YOUTH_GROWTH","EARLY_DEVELOPMENT","PRIME_MAINTENANCE","VETERAN_DECLINE"])}),cp=d({playerId:s,player:Ce,debutSeasonNumber:x.max(K),retiredAfterSeasonNumber:x.max(K),retiredCalendarYear:k().int().min(1900).max(9999),ageAtRetirement:k().int().min(18).max(65),lastTeamId:s,careerTeamIds:v(s).min(1).max(8),retirementReason:O(["AGE_AND_WORKLOAD","VETERAN_TRANSITION","MANDATORY_AGE_LIMIT"])}),lp=O(["ACADEMY_GRADUATE","FIRST_TEAM_PROSPECT","HIGH_CEILING_PROSPECT"]),Kr=O(["BALANCED","BATTING_PRACTICE","BOWLING_PRACTICE","FIELDING_PRACTICE"]),dp=d({prospectId:s,teamId:s,generatedInSeasonNumber:x.max(K),generatedCalendarYear:k().int().min(1900).max(9999),intakeRank:k().int().min(1).max(op),fictionalCeilingTier:lp,academyFocus:Kr,queuedForPromotion:H(),promotedInSeasonNumber:x.max(K).nullable(),player:Ce}),up=d({fromSeasonNumber:x.max(K-1),toSeasonNumber:x.max(K),calendarYear:k().int().min(1900).max(9999),agedPlayerCount:l.max(1e4),developedPlayers:v(sp).max(1e4),retiredPlayerIds:v(s).max(1e4),promotedYouthIds:v(s).max(1e4),generatedYouthIds:v(s).max(1e4)}),mp=d({...up.shape,transitionSha256:b}),gp=d({playerId:s,debutSeasonNumber:x.max(K),careerEntryT20Skills:at,priorSeasonT20Skills:at,lastSeasonDelta:zr}),ra=d({lifecycleVersion:m(jg),model:Gr,activeWorld:vt,activeRosterPack:Se.nullable(),historicalRosterPacks:v(Se).max(K*4),skillLedger:v(gp).min(22).max(1e4),seasonTrainingExposure:v(rp).min(22).max(1e4),retiredPlayers:v(cp).max(1e4),youthAcademy:v(dp).max(1e4),transitions:v(mp).max(K),squadRegistrationRevision:l}),sa=d({...ra.shape,lifecycleSha256:b}),Yr=ra.extend({lifecycleVersion:m(Zg),historicalRosterPacks:v(Se).max(Xg)}),jr=d({...Yr.shape,lifecycleSha256:b});An("lifecycleVersion",[ra,Yr]),An("lifecycleVersion",[sa,jr]);const pp=d({seasonStateVersion:m(qg),seasonId:s,gameId:s,careerId:s,controlledTeamId:s.nullable(),rosterPackSha256:b,schedule:Vr,careerState:$r,projection:Wr,completedMatches:v(oi).max(56),revision:l,phase:O(["ACTIVE","COMPLETE"])}),Ip=d({...pp.shape,stateSha256:b}),Zr=An("seasonStateVersion",[Br,Ip]),hp=d({archiveVersion:m(Jg),seasonId:s,scheduleSha256:b,fixtureId:s,matchId:s,fixtureOrdinal:k().int().min(0).max(55),roundNumber:x.max(14),matchDayDate:Q(),source:O(["OFFSCREEN","USER_MATCH"]),sourceCompletionSha256:b,rosterPackSha256:b,preparation:Hr,eventChain:Lt,events:v(ai).min(1).max(2e3),scorecardSha256:b});d({...hp.shape,archiveSha256:b});const fp=d({worldStateVersion:m(Qg),worldIdentity:Qi,careerId:s,controlledTeamId:s.nullable(),currentSeasonNumber:x.max(K),currentCalendarYear:k().int().min(1900).max(9999),currentSeason:Zr,completedSeasons:v(na).max(K-1),careerProjection:ea,lifecycle:sa,lastRolloverReceipt:ta.nullable(),revision:l});d({...fp.shape,stateSha256:b}),d({archiveVersion:m(tp),saveSchema:O([np,ep]),exportedAt:Ee(),summary:ia,careerProjectionSha256:b,lifecycleSha256:b,worldCopySha256:b.optional(),rosterPackHashes:v(b).max(K),matchEventArchiveCount:l.max(K*56),files:cn(w().min(1),d({bytes:l,sha256:b}))}),d({command:m("SET_ACADEMY_PROSPECT_FOCUS"),prospectId:s,academyFocus:Kr}),d({command:m("SET_ACADEMY_PROSPECT_QUEUE"),prospectId:s,queuedForPromotion:H()}),d({command:m("PROMOTE_YOUTH_PROSPECT"),prospectId:s,seasonNumber:x.max(K)});const Ot=d({min:k().int().min(0).max(100),p10:k().int().min(0).max(100),median:k().int().min(0).max(100),meanX10:k().int().min(0).max(1e3),p90:k().int().min(0).max(100),max:k().int().min(0).max(100)});d({seasonNumber:x.max(K),calendarYear:k().int().min(1900).max(9999),activePlayerCount:l,cumulativeRetiredCount:l,cumulativeYouthPromotedCount:l,minClubSquadSize:l,maxClubSquadSize:l,minClubKeepers:l,minClubBowlingCapable:l,clubsWithRoleShortage:l,meanAgeX10:l,battingAbility:Ot,bowlingAbility:Ot,fieldingAbility:Ot,keepingAbility:Ot,roleCounts:d({BATTER:l,BOWLER:l,ALLROUNDER:l,KEEPER:l}),directiveSampleCheck:ut.optional()}),d({teamId:s,date:Q(),players:v(Or).min(ip).max(ap)});const Xr="LC_SQUAD_ECONOMY_MODEL_FICTIONAL_V1",Ep="LC_SQUAD_ECONOMY_STATE_V1",Sp="LC_ECONOMY_LEDGER_ENTRY_V1",_p="LC_PERSISTENT_WORLD_STATE_V3",vp="LC_PERSISTENT_WORLD_SAVE_V3",bp="LC_PERSISTENT_WORLD_SAVE_V3_PRESENTATION",Tp="LC_PERSISTENT_WORLD_PORTABLE_V3_ECONOMY",Rp="LC_PERSISTENT_WORLD_STATE_V4",Lp="LC_PERSISTENT_WORLD_SAVE_V4",Ap="LC_PERSISTENT_WORLD_SAVE_V4_PRESENTATION",Op="LC_PERSISTENT_WORLD_STATE_V5",wp="LC_PERSISTENT_WORLD_SAVE_V5",Np="LC_PERSISTENT_WORLD_SAVE_V5_PRESENTATION",Dp=2500,Cp=35,yp=450,kp=40,qr=1,ze=3,Ke=3,Bp=50,Pp=16,xp=40,Jr=d({modelVersion:m(Xr),calibrationStatus:m("FICTIONAL_PLACEHOLDER"),disclaimer:w().min(1).max(400),annualClubWageBudgetK:k().int().min(1e3).max(1e4),minAnnualWageK:k().int().min(20).max(100),maxAnnualWageK:k().int().min(200).max(1e3),youthRookieAnnualWageK:k().int().min(25).max(100),minContractTermSeasons:m(qr),maxContractTermSeasons:m(ze),maxNegotiationRounds:m(Ke),releaseBuyoutPercent:k().int().min(0).max(100),minFreeAgentPoolSize:k().int().min(8).max(64),maxFreeAgentPoolSize:k().int().min(16).max(128)}),Fp=O(["INITIAL_SQUAD","RENEWAL","FREE_AGENT_SIGNING","YOUTH_GRADUATE","EMERGENCY_MINIMUM"]),Hp=d({contractId:s,playerId:s,teamId:s,signedSeasonNumber:x.max(K),startsSeasonNumber:x.max(K+1),expiresAfterSeasonNumber:x.max(K+5),annualWageK:k().int().min(20).max(1e3),origin:Fp,careerTeamIds:v(s).min(1).max(8)}),Mp=O(["UNATTACHED_POOL","CONTRACT_EXPIRED","CLUB_RELEASED"]),Vp=d({playerId:s,player:Ce,enteredMarketSeasonNumber:x.max(K),enteredReason:Mp,previousTeamId:s.nullable(),careerTeamIds:v(s).max(8),restrictedFromSigningTeamId:s.nullable(),restrictedSeasonNumber:x.max(K).nullable(),askingAnnualWageK:k().int().min(20).max(1e3),preferredTermSeasons:k().int().min(1).max(ze)}),$p=d({teamId:s,seasonNumber:x.max(K),annualWageBudgetK:k().int().min(500).max(2e4),committedWagesK:l.max(2e4),deadCapWagesK:l.max(2e4),pendingOfferReservedWagesK:l.max(2e4),availableWageSpaceK:l.max(2e4)}),Qr=O(["FREE_AGENT","RENEWAL"]),Wp=O(["PENDING_ROUND","COUNTERED","SIGNED","REJECTED","WITHDRAWN"]),Up=O(["AWAITING_ROUND_RESOLUTION","PLAYER_ACCEPTED_BEST_OFFER","PLAYER_COUNTERED_TERMS","WAGE_BELOW_RESERVATION","SIGNED_WITH_COMPETING_CLUB","CLUB_WITHDREW_OFFER","PLAYER_NO_LONGER_ELIGIBLE","CAP_OR_ROSTER_LIMIT"]),Gp=d({offerId:s,commandId:s,seasonNumber:x.max(K),roundSubmitted:k().int().min(1).max(Ke),roundResolved:k().int().min(1).max(Ke).nullable(),offeringTeamId:s,submittedBy:O(["HUMAN_MANAGER","AI_CLUB"]),playerId:s,offerKind:Qr,annualWageK:k().int().min(20).max(1e3),termSeasons:k().int().min(1).max(ze),status:Wp,reason:Up,counterAnnualWageK:k().int().min(20).max(1e3).nullable(),counterTermSeasons:k().int().min(1).max(ze).nullable(),rationale:w().min(1).max(280)}),zp=d({seasonNumber:x.max(K),windowPhase:O(["OPEN","CLOSED"]),currentRound:k().int().min(1).max(Ke),maxRounds:m(Ke),offers:v(Gp).max(2e3)}),Kp=O(["INITIAL_CONTRACT_REGISTERED","CONTRACT_RENEWED","FREE_AGENT_SIGNED","YOUTH_ROOKIE_CONTRACT_SIGNED","CONTRACT_EXPIRED_TO_FREE_AGENCY","CONTRACT_RELEASE_BUYOUT","CONTRACT_ENDED_ON_RETIREMENT","MINIMUM_SQUAD_TOPUP_SIGNED"]),Yp=d({ledgerEntryVersion:m(Sp),sequence:x,transactionId:s,seasonNumber:x.max(K),calendarYear:k().int().min(1900).max(9999),date:Q(),type:Kp,teamId:s,playerId:s,contractId:s.nullable(),offerId:s.nullable(),annualWageK:l.max(2e3),deadCapDeltaK:l.max(2e3),termSeasons:l.max(ze),teamCommittedWagesAfterK:l.max(2e4),teamDeadCapAfterK:l.max(2e4),teamBudgetLimitK:k().int().min(500).max(2e4),summary:w().min(1).max(320),prevEntrySha256:b.nullable()}),jp=d({...Yp.shape,entrySha256:b}),Zp=d({fromSeasonNumber:x.max(K-1),toSeasonNumber:x.max(K),calendarYear:k().int().min(1900).max(9999),humanRenewedCount:l.max(1e3),aiRenewedCount:l.max(1e3),expiredToFreeAgencyIds:v(s).max(1e3),retiredContractClosedIds:v(s).max(1e3),youthContractsSignedIds:v(s).max(1e3),aiOffseasonFreeAgentSigningsIds:v(s).max(1e3),minimumTopupSignedIds:v(s).max(1e3)}),Xp=d({economyVersion:m(Ep),model:Jr,contracts:v(Hp).min(22).max(1e4),freeAgents:v(Vp).max(2e3),clubBudgets:v($p).length(8),negotiationWindow:zp,ledger:v(jp).min(1).max(5e4),appliedCommandIds:v(s).max(1e4),transitions:v(Zp).max(K)}),qp=d({...Xp.shape,economySha256:b}),ns=d({worldStateVersion:m(_p),worldIdentity:Qi,careerId:s,controlledTeamId:s.nullable(),currentSeasonNumber:x.max(K),currentCalendarYear:k().int().min(1900).max(9999),currentSeason:Zr,completedSeasons:v(na).max(K-1),careerProjection:ea,lifecycle:sa,economy:qp,lastRolloverReceipt:ta.nullable(),revision:l});d({...ns.shape,stateSha256:b});const es=ns.extend({worldStateVersion:m(Rp),lifecycle:jr});d({...es.shape,stateSha256:b});const Jp=es.extend({worldStateVersion:m(Op)}),Qp=d({...Jp.shape,stateSha256:b}),n2=d({seasonId:s,recordSha256:b});d({...Qp.shape,completedSeasons:v(n2).max(K-1)});const e2=d({archiveVersion:m(Tp),saveSchema:O([vp,bp]),exportedAt:Ee(),summary:ia,careerProjectionSha256:b,lifecycleSha256:b,economySha256:b,worldCopySha256:b.optional(),rosterPackHashes:v(b).max(K*4),matchEventArchiveCount:l.max(K*56),files:cn(w().min(1),d({bytes:l,sha256:b}))});d({command:m("SUBMIT_CONTRACT_OFFER"),commandId:s,offeringTeamId:s,playerId:s,offerKind:Qr,annualWageK:k().int().min(20).max(1e3),termSeasons:k().int().min(1).max(ze)}),d({command:m("WITHDRAW_CONTRACT_OFFER"),commandId:s,offeringTeamId:s,offerId:s}),d({command:m("ACCEPT_COUNTER_OFFER"),commandId:s,offeringTeamId:s,offerId:s}),d({command:m("RESOLVE_NEGOTIATION_ROUND"),commandId:s,seasonNumber:x.max(K),expectedRound:k().int().min(1).max(Ke)}),d({command:m("RELEASE_CONTRACTED_PLAYER"),commandId:s,teamId:s,playerId:s}),d({seasonNumber:x.max(K),calendarYear:k().int().min(1900).max(9999),activeContractCount:l,freeAgentPoolCount:l,minClubPayrollUsedK:l,medianClubPayrollUsedK:l,maxClubPayrollUsedK:l,clubWageBudgetK:k().int().min(500).max(2e4),clubsOverspentCount:l,clubsWithRoleShortageCount:l,seasonFreeAgentSigningsCount:l,seasonRenewalsCount:l,seasonExpiredToFreeAgencyCount:l,seasonReleaseBuyoutsCount:l,wageDistributionK:Ot,aiHiddenFutureAbilityReads:m(0)});const ts=O(["TOSS","INNINGS","BATTER","BOWLER","BATTING_PLAN","BOWLING_PLAN","FIELD","DECLARATION","FOLLOW_ON","NEW_BALL"]),ca=O(["CONSERVATIVE","BALANCED","AGGRESSIVE"]),t2=v(ts).max(10).refine(n=>new Set(n).size===n.length).meta({uniqueItems:!0}),i2=d({commandId:w().min(1).max(128),expectedRevision:k().int().nonnegative(),matchRevision:k().int().nonnegative(),teamId:w().min(1).max(128),categories:t2,redBallProfile:ca.optional()});d({version:m("LC_DELEGATION_JOURNAL_V1"),changes:v(i2)});const la="LC_TACTICAL_BRIEFING_V1",a2=O(["SEAM_FRIENDLY","SPIN_FRIENDLY","LIVE_BOTH","BALANCED","FLAT"]),o2=O(["FRESH","READY","WORKED","TIRED"]),r2=d({playerId:s,name:Bn,role:O(["BATTER","BOWLER","ALLROUNDER","KEEPER"]),batHand:it,bowlingStyle:Jt.nullable(),canBowl:H(),selectedInXI:H(),fatigueBp:kn,readinessDelta:k().int().min(-20).max(20),conditionBand:o2}),is=d({teamId:s,teamName:Bn,squadSize:x,selectedCount:l.max(11),selectedKeepers:l.max(11),selectedBowlingOptions:l.max(11),selectedPaceOptions:l.max(11),selectedSpinOptions:l.max(11),selectedLeftHandBatters:l.max(11),freshInXI:l.max(11),tiredInXI:l.max(11),balanceSummary:w().min(1).max(320),players:v(r2).min(11).max(30)}),as=d({opponentTeamId:s,opponentTeamName:Bn,poolLabel:O(["SELECTED_XI","AVAILABLE_SQUAD"]),leftHandBatters:l.max(30),rightHandBatters:l.max(30),keepers:l.max(30),paceOptions:l.max(30),spinOptions:l.max(30),bowlingStyles:v(Jt).max(6),observations:v(w().min(1).max(280)).min(1).max(6)}),s2=d({groundId:s,groundName:Bn,seamBp:kn,turnBp:kn,pitchTendency:a2,pitchSummary:w().min(1).max(320),formatRulesSummary:w().min(1).max(320),modelLimitsDisclosure:w().min(1).max(320)});d({version:m(la),format:$n,ground:s2,teams:wn([is,is]),opponentObservations:wn([as,as])});const c2=O(["BATTING_AGGRESSION","BATTING_INTENT","BOWLING_LINE","BOWLING_LENGTH","BOWLING_EFFORT","BOWLING_VARIATION","FIELD_PLACEMENT"]),l2=d({controlId:c2,side:O(["BATTING","BOWLING","FIELDING"]),label:w().min(1).max(80),currentSetting:w().min(1).max(160),upside:w().min(1).max(280),tradeOff:w().min(1).max(280)}),d2=O(["BAT_CONSOLIDATE","BAT_ROTATE_STRIKE","BAT_BALANCED_TEMPO","BAT_BOUNDARY_PUSH","BOWL_DISCIPLINED_CHANNEL","BOWL_ATTACK_STUMPS","BOWL_CONSERVE_SPELL","BOWL_YORKER_CLOSE","BOWL_SHORT_TEST","FIELD_SLIP_ATTACK","FIELD_BALANCED_RING","FIELD_BOUNDARY_PROTECT"]),u2=d({presetId:d2,commandKind:O(["SET_BATTING_PLAN","SET_BOWLING_PLAN","SET_FIELD"]),label:w().min(1).max(80),whenToUse:w().min(1).max(240),tradeOff:w().min(1).max(240),contextualMatch:H(),contextualReason:w().max(200),activeNow:H(),battingPatch:d({aggression:l.max(4),intent:O(["NORMAL","ROTATE","PROTECT"])}).optional(),bowlingPatch:d({line:O(["OFF","STUMPS","LEG"]),length:O(["YORKER","FULL","GOOD","SHORT"]),effort:O(["CONSERVE","NORMAL","MAXIMUM"]),variationId:s}).optional(),fieldSlots:v(Bi).length(9).optional()}),m2=d({primaryLine:O(["OFF","STUMPS","LEG"]),primaryLength:O(["YORKER","FULL","GOOD","SHORT"]),primaryEffort:O(["CONSERVE","NORMAL","MAXIMUM"]),primaryVariationId:s,latestRingFielders:l.max(9),latestBoundaryFielders:l.max(9),latestCloseCatchers:l.max(9),planChangesCount:l,fieldChangesCount:l}),g2=d({YORKER:l,FULL:l,GOOD:l,SHORT:l,FULL_TOSS:l}),p2=d({GROUND:l,AERIAL:l,EDGE:l,NO_CONTACT:l}),I2=d({STOP:l,CATCH:l,DROP:l,MISS:l,RUN_OUT:l}),h2=d({legalBalls:l,oversDisplay:w().regex(/^[0-9]+\.[0-5]$/),deliveryAttempts:l,runsConceded:l,wickets:l,dots:l,singles:l,boundaries:l,fours:l,sixes:l,wides:l,noBalls:l,economyX100:l.nullable(),intendedLengthMatches:l,intendedLengthEvaluatedBalls:l,executedLengths:g2,trajectories:p2,fieldOutcomes:I2}),f2=d({spellId:w().min(1).max(160),inningsIndex:l,spellNumberInInnings:x,bowlerId:s,bowlerName:Bn,status:O(["IN_PROGRESS","BETWEEN_OVERS","COMPLETED"]),startOver:l,endOver:l,acceptedPlan:m2,outcomes:h2,factualSummary:w().min(1).max(420)}),E2=d({stintId:w().min(1).max(160),inningsIndex:l,playerId:s,playerName:Bn,dismissed:H(),acceptedPlan:d({primaryAggression:l.max(4),primaryIntent:O(["NORMAL","ROTATE","PROTECT"]),planChangesCount:l}),outcomes:d({ballsFaced:l,runs:l,dots:l,singles:l,boundaries:l,strikeRateX100:l.nullable()}),factualSummary:w().min(1).max(360)}),S2=d({phaseLabel:w().min(1).max(120),fieldRestrictionLabel:w().min(1).max(160),scoreContextLabel:w().min(1).max(200),pitchSummaryLabel:w().min(1).max(200),activeBowlerWorkloadLabel:w().max(200)}),_2=d({version:m(la),format:$n,situation:S2,controlGuide:v(l2).length(7),presets:v(u2).max(16),spellReviews:v(f2),battingStintReviews:v(E2)}),os="LC_FIELD_PRESENTATION_V1";O(["EVERY_BALL","KEY_MOMENT","FAST"]),O(["AUTO","REDUCED"]);const v2=O(["WICKET","SIX","FOUR","FREE_HIT","EXTRA","RUNS","DOT"]),b2=O(["RECORDED_SECTOR","PITCH_CHANNEL_ONLY"]),T2=O(["SLOT_COUNT","UNIQUE_PLAYERS","DUPLICATE_POSITION","UNSUPPORTED_POSITION","CIRCLE_RESTRICTION","LEG_SIDE_LIMIT","BEHIND_SQUARE_LEG_LIMIT"]),R2=d({code:T2,message:w().min(1).max(240),affectedSlotIds:v(s).max(9)}),rs=d({isLegal:H(),format:$n,strikerHand:it,phaseLabel:w().min(1).max(120),outsideCircleCount:l.max(9),maxOutsideCircle:l.max(9),legSideCount:l.max(9),maxLegSide:m(5),behindSquareLegCount:l.max(9),maxBehindSquareLeg:m(2),duplicateSlotIds:v(s).max(9),violations:v(R2).max(16),summaryText:w().min(1).max(320)}),_e=d({x10:l.max(2e3),y10:l.max(2e3)}),L2=d({slotId:s,label:Bn,sector:l.max(7),displaySector:l.max(7),depth:O(["INNER","MIDDLE","DEEP"]),insideCircle:H(),legSideForStriker:H(),behindSquare:H(),point:_e,occupiedByPlayerId:s.nullable(),occupiedByName:Bn.nullable()}),da=d({sequence:x,eventHash:b,inningsIndex:l.max(3),deliveryIndex:l,overBallLabel:w().min(1).max(24),strikerId:s,strikerName:Bn,strikerHand:it,bowlerId:s,bowlerName:Bn,momentKind:v2,isKeyMoment:H(),runsScored:l,batRuns:l,boundary:O(["NONE","FOUR","SIX"]),legality:O(["LEGAL","WIDE","NO_BALL","DEAD"]),dismissalKind:O(["BOWLED","LBW","CAUGHT","RUN_OUT","STUMPED","HIT_WICKET"]).nullable(),dismissedPlayerName:Bn.nullable(),fieldOutcome:O(["NONE","STOP","DROP","CATCH","MISS","RUN_OUT"]),executedLength:O(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"]).nullable(),trajectory:O(["GROUND","AERIAL","EDGE"]).nullable(),recordedSector:l.max(7).nullable(),displaySector:l.max(7).nullable(),sectorStatus:b2,releasePoint:_e,pitchBouncePoint:_e,strikerCreasePoint:_e,targetPoint:_e,headline:w().min(1).max(160),detailText:w().min(1).max(280),trackingDisclaimer:w().min(1).max(220)}),A2=d({version:m(os),format:$n,phase:w().min(1).max(64),activeInningsIndex:l.max(3),strikerId:s.nullable(),strikerName:Bn.nullable(),strikerHand:it,nonStrikerId:s.nullable(),nonStrikerName:Bn.nullable(),bowlerId:s.nullable(),bowlerName:Bn.nullable(),keeperId:s.nullable(),keeperName:Bn.nullable(),keeperPoint:_e,bowlerReleasePoint:_e,strikerPoint:_e,nonStrikerPoint:_e,boundaryRadiusX10:m(840),circleRadiusX10:m(480),positions:v(L2).min(11).max(12),legality:rs,recentHighlights:v(da).max(24),latestHighlight:da.nullable(),orientationNote:w().min(1).max(200),trackingDisclaimer:w().min(1).max(220)}),Dn="LC_COMMENTARY_ADAPTER_V1";O(["BRIEF","STANDARD","DETAILED","OFF"]);const O2=O(["DELIVERY","OVER","PARTNERSHIP","MILESTONE","DISMISSAL","TACTICAL","CONDITIONS","INNINGS","RESULT","SELECTION"]),w2=O(["EVENT_FIELD","INNINGS_PROJECTION","BATTER_PROJECTION","BOWLER_PROJECTION","PARTNERSHIP_PROJECTION","CHASE_PROJECTION","MATCH_RESULT","FORMAT_RULE"]),N2=d({slot:s,value:w().min(1).max(160),sourceKind:w2,sourceRef:w().min(1).max(160)}),D2=O(["BATTER_FIFTY","BATTER_CENTURY","BATTER_150","BATTER_DOUBLE_CENTURY","PARTNERSHIP_FIFTY","PARTNERSHIP_CENTURY","PARTNERSHIP_150","BOWLER_THREE_FOR","BOWLER_FIVE_FOR","MAIDEN_OVER","ALL_OUT","WINNING_DELIVERY"]),C2=d({adapterVersion:m(Dn),sequence:x,eventType:s,category:O2,templateId:s,templateFamily:s,cooldownApplied:H(),presentationDigest:w().regex(/^[a-f0-9]{8}$/),milestoneTags:v(D2).max(6),short:w().min(1).max(240),text:w().min(1).max(640),detailed:w().min(1).max(960),factSlots:v(N2).min(1).max(24)});d({adapterVersion:m(Dn),format:$n,presentationKeyDigest:w().regex(/^[a-f0-9]{8}$/),repetitionCooldownWindow:x.max(12),entries:v(C2)});const ua="LC_AUDIO_PRESENTATION_V1",ss="LC_AUDIO_PROVENANCE_V1",cs=O(["CROWD","EFFECTS","COMMENTARY","INTERFACE"]),ls=O(["BAT_BALL_DOT","BAT_BALL_SINGLE","BOUNDARY_FOUR","BOUNDARY_SIX","WICKET_FALL","MILESTONE_CHIME","OVER_BELL","INNINGS_CHANGE","MATCH_COMPLETE","UI_CLICK"]),y2=O(["ORIGINAL_PROCEDURAL_SYNTH","ORIGINAL_IN_REPO_PCM"]);O(["PLAYED","QUEUED_AWAITING_GESTURE","DEDUP_SKIPPED","EXPIRED_FAST_FORWARD","MUTED_OR_ZERO_VOLUME","BACKGROUND_TAB_SUPPRESSED","MISSING_ASSET_FALLBACK","DECODE_FAILED_FALLBACK"]);const ci=k().int().min(0).max(100);d({version:m(ua),muted:H(),crowdVolume:ci,effectsVolume:ci,commentaryVolume:ci,interfaceVolume:ci,narrationEnabled:H(),captionsEnabled:H()});const k2=d({assetId:s,cueKind:ls,channel:cs,title:w().min(1).max(120),author:w().min(1).max(120),license:m("MIT_ORIGINAL_LORD_CRICKET_XXVI"),origin:y2,synthesisProfile:w().min(1).max(200),durationMs:x.max(1e4),sha256:b});d({manifestVersion:m(ss),attributionNotice:w().min(1).max(320),networkCallsAllowed:m(!1),assets:v(k2).min(1).max(64)});const B2=d({cueId:s,sequence:x,channel:cs,cueKind:ls,assetId:s,priority:k().int().min(1).max(100),caption:w().min(1).max(280),narrationText:w().min(1).max(360).optional(),ttlMs:x.max(3e4)});d({adapterVersion:m(ua),matchId:s,format:$n,cues:v(B2)});const P2="LC_HISTORICAL_STATISTICS_PROJECTION_V1",x2=O(["CAREER"]),ds=O(["ALL","OPENER","TOP_ORDER","MIDDLE_ORDER","LOWER_ORDER"]),F2=O(["ALL","ACTIVE","RETIRED"]),H2=Vn([m("ALL"),m("ACTIVE"),x.max(K)]),M2=d({seasonScope:H2,format:m("T20"),competitionId:w().min(1).max(64),opponentTeamId:w().min(1).max(64),venueGroundId:w().min(1).max(64),battingPositionBand:ds,battingPositionExact:x.max(11).nullable(),playerStatus:F2,teamId:w().min(1).max(64)}),V2=d({seasonNumber:x.max(K),calendarYear:k().int().min(1900).max(9999),phase:O(["ACTIVE","COMPLETE"]),matchesCount:l}),$2=d({competitionId:s,label:w().min(1).max(120),format:$n}),W2=d({formats:v($n).min(1).max(3),unsupportedFormatsNote:w().min(1).max(240),competitions:v($2).max(32),seasons:v(V2).max(K),opponents:v(s).max(64),teams:v(s).max(64),venues:d({available:H(),coverage:O(["ALL_RESOLVED","PARTIAL","UNAVAILABLE"]),groundIds:v(s).max(64),note:w().min(1).max(240)}),battingPosition:d({available:m(!0),bands:v(ds).min(1),note:w().min(1).max(240)}),fielding:d({available:H(),archiveCoverageCount:l,totalMatchesCount:l,coverage:O(["ALL_ARCHIVED","PARTIAL_ARCHIVES","UNAVAILABLE"]),note:w().min(1).max(240)})}),U2=d({fixtureId:s,matchId:s,seasonNumber:x.max(K),calendarYear:k().int().min(1900).max(9999),roundNumber:x.max(14),matchDayDate:Q(),competitionId:s,format:m("T20"),groundId:s.nullable(),homeTeamId:s,awayTeamId:s,teamId:s,opponentTeamId:s,battedInnings:x.max(2).nullable(),battingPosition:x.max(11).nullable(),runsScored:l.nullable(),ballsFaced:l.nullable(),fours:l.nullable(),sixes:l.nullable(),notOut:H().nullable(),bowledLegalBalls:l.nullable(),bowlingRunsConceded:l.nullable(),bowlingWickets:l.max(10).nullable(),maidens:l.max(4).nullable(),catches:l.nullable(),stumpings:l.nullable(),runOuts:l.nullable(),archiveEvaluated:H(),archiveReplayAvailable:H(),resultSummary:w().min(1).max(240),sourceCompletionSha256:b}),G2=d({playerId:s,status:O(["ACTIVE","RETIRED"]),currentTeamId:s,careerTeamIds:v(s).min(1).max(64),retiredAfterSeasonNumber:x.max(K).nullable(),retiredCalendarYear:k().int().min(1900).max(9999).nullable(),seasonsPlayed:l.max(K),matches:l,battingInnings:l,notOuts:l,runs:l,dismissals:l,ballsFaced:l,fours:l,sixes:l,fifties:l,hundreds:l,ducks:l,highScoreRuns:l,highScoreNotOut:H(),highScoreFixtureId:s.nullable(),battingAverageX100:l.nullable(),strikeRateX100:l.nullable(),boundaryRunsPercentX100:l.nullable(),bowlingInnings:l,bowlingRunsConceded:l,bowlingLegalBalls:l,bowlingWickets:l,maidens:l,threeWicketHauls:l,fourWicketHauls:l,fiveWicketHauls:l,bestBowlingWickets:l.max(10),bestBowlingRuns:l.nullable(),bestBowlingFixtureId:s.nullable(),bowlingAverageX100:l.nullable(),economyX100:l.nullable(),bowlingStrikeRateX100:l.nullable(),fieldingMatchesArchived:l,catches:l,stumpings:l,runOuts:l,totalFieldingDismissals:l,bestMatchCatches:l,bestMatchFieldingDismissals:l,bestFieldingFixtureId:s.nullable(),contributingMatches:v(U2).max(K*14)}),z2=O(["RUNS","BATTING_AVERAGE","BATTING_STRIKE_RATE","HIGH_SCORE","SIXES","WICKETS","BOWLING_AVERAGE","ECONOMY","BOWLING_STRIKE_RATE","BEST_BOWLING","FIELDING_DISMISSALS","CATCHES"]),K2=d({rank:x,tied:H(),playerId:s,teamId:s,status:O(["ACTIVE","RETIRED"]),qualified:H(),primaryDisplay:w().min(1).max(64),primaryValueX100:l,secondaryDisplay:w().min(1).max(96),denominatorCount:l,denominatorLabel:w().min(1).max(64),contributingFixtureIds:v(s).min(1).max(K*14)}),Y2=d({summary:w().min(1).max(200),minDenominator:l,denominatorField:w().min(1).max(64),secondaryRule:w().min(1).max(160).nullable()}),re=d({metric:z2,title:w().min(1).max(80),sortDirection:O(["DESC","ASC"]),qualificationRule:Y2,denominatorDefinition:w().min(1).max(160),nullPolicy:w().min(1).max(160),tieRule:w().min(1).max(160),entries:v(K2).max(200),qualifiedCount:l,totalCandidatesCount:l}),j2=d({teamId:s,played:l,wins:l,losses:l,ties:l,noResults:l,points:l,runsFor:l,ballsFor:l,runsAgainst:l,ballsAgainst:l});d({projectionVersion:m(P2),sourceClass:x2,separationNotice:w().min(1).max(240),filterQuery:M2,filterSupport:W2,totalSourceMatches:l,filteredMatchesCount:l,players:v(G2).max(1e4),leaderboards:d({RUNS:re,BATTING_AVERAGE:re,BATTING_STRIKE_RATE:re,HIGH_SCORE:re,SIXES:re,WICKETS:re,BOWLING_AVERAGE:re,ECONOMY:re,BOWLING_STRIKE_RATE:re,BEST_BOWLING:re,FIELDING_DISMISSALS:re,CATCHES:re}),teamStandings:v(j2).max(64),projectionDigest:w().regex(/^[0-9a-f]{32}$/)});const wt="LC_AWARDS_HEURISTIC_GAME_V1",Z2="LC_CAREER_AWARDS_LEDGER_V1",Ye=k().int().min(Number.MIN_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER),X2=O(["T20","ODI","RED_BALL"]),q2=d({battingPointsX100:Ye,bowlingPointsX100:Ye,fieldingPointsX100:l,resultBonusX100:l}),J2=d({playerId:s,teamId:s,battingPointsX100:Ye,bowlingPointsX100:Ye,fieldingPointsX100:l,resultBonusX100:l,totalPointsX100:Ye,fromWinningTeam:H(),summaryLine:w().min(1).max(240)}),ma=d({awardVersion:m(wt),awardCategory:m("PLAYER_OF_THE_MATCH"),awardProvenance:m("GAME_AWARD"),format:X2,matchId:s,fixtureId:s.nullable(),seasonNumber:x.nullable(),sourceCompletionSha256:b.nullable(),status:O(["AWARDED","NO_RESULT_NOT_AWARDED"]),winnerPlayerId:s.nullable(),winnerTeamId:s.nullable(),fromWinningTeam:H().nullable(),fromLosingTeam:H(),scoreTotalX100:Ye.nullable(),components:q2.nullable(),fieldingSourceStatus:O(["ARCHIVE_EVENTS","SCORECARD_NOT_ATTRIBUTABLE"]),explanationText:w().min(1).max(400),formulaSummary:w().min(1).max(400),candidates:v(J2).max(5)}),Q2=O(["PLAYER_OF_THE_SEASON","LEADING_RUN_SCORER","LEADING_WICKET_TAKER","BEST_FIELDER","EMERGING_YOUTH_PLAYER"]),nI=d({awardVersion:m(wt),category:Q2,label:w().min(1).max(120),awardProvenance:m("GAME_AWARD"),status:O(["AWARDED","UNAVAILABLE"]),unavailableReason:w().min(1).max(240).nullable(),qualificationRule:w().min(1).max(240),formulaSummary:w().min(1).max(320),winnerPlayerId:s.nullable(),winnerTeamId:s.nullable(),headlineStat:w().min(1).max(160).nullable(),scoreX100:Ye.nullable(),tieBroken:H(),runnerUpPlayerId:s.nullable(),explanationText:w().min(1).max(400)}),eI=d({awardVersion:m(wt),seasonNumber:x,calendarYear:k().int().min(1900).max(9999),competitionId:m("LC_T20_LEAGUE_01"),sealedAtSeasonSha256:b.nullable(),provenanceNotice:w().min(1).max(320),awards:v(nI).length(5)}),tI=d({key:w().min(1).max(256),seasonNumber:x,fixtureId:s,matchId:s,sourceCompletionSha256:b,award:ma});d({ledgerVersion:m(Z2),worldOrCareerId:s,matchAwards:v(tI).max(2e4),seasonAwards:v(eI).max(200),ledgerSha256:b});const iI="LC_CAREER_MATCH_DIGEST_V1",ga=k().int().min(0).max(1e3);d({digestVersion:m(iI),fixtureId:s,groundId:s.nullable(),creaseOrder:wn([v(s).max(64),v(s).max(64)]),fielding:v(d({playerId:s,teamId:s,catches:ga,stumpings:ga,runOuts:ga})).max(64)});const us=e2.extend({archiveVersion:m("LC_PERSISTENT_WORLD_PORTABLE_V4_GZIP"),compression:m("gzip")});us.extend({archiveVersion:m("LC_PERSISTENT_WORLD_PORTABLE_V5_WORLD_V4"),saveSchema:O([Lp,Ap])}),us.extend({archiveVersion:m("LC_PERSISTENT_WORLD_PORTABLE_V6_WORLD_V5"),saveSchema:O([wp,Np])});const aI="LC_CAREER_STORIES_PROJECTION_V1",oI=O(["MILESTONE_BATTING","MILESTONE_BOWLING","MILESTONE_FIELDING","FORM_STREAK","YOUTH_BREAKTHROUGH","CONTRACT_TENSION","RETIREMENT_WATCH","AWARD_RECOGNITION","CLUB_BOARD_REVIEW"]),rI=d({key:w().min(1).max(80),value:Vn([w().min(1).max(200),k().int()])}),sI=d({storyId:w().min(1).max(256),seasonNumber:x,roundNumber:k().int().min(1).max(99),category:oI,headline:w().min(1).max(160),summaryText:w().min(1).max(480),subjectPlayerId:s.nullable(),subjectTeamId:s.nullable(),linkedMatchKey:w().min(1).max(160).nullable(),factProvenance:v(rI).min(1).max(20)});d({schemaId:m(aI),worldOrCareerId:s,stories:v(sI).max(2e4)});const Qn="LC_SCENARIO_CHALLENGE_V1",cI="LC_SCENARIO_RECORD_LEDGER_V1",lI=O(["STANDARD","HARD","ELITE"]),ms=O(["WIN","AVOID_DEFEAT"]),dI=d({inningsIndex:l.max(3),legalBalls:l.max(3e3),revision:x,battingTeamId:s,runs:l.max(2e3),wickets:l.max(10),targetToWin:x.max(2e3).nullable()}),uI=d({schemaId:m(Qn),scenarioId:s,title:w().min(1).max(80),format:$n,difficulty:lI,sourceType:m("FICTIONAL_CURATED"),seed:w().min(1).max(256),matchId:s,teamIds:wn([s,s]),groundId:s,playerTeamId:s,objective:ms,objectiveSummary:w().min(1).max(160),briefing:w().min(1).max(480),checkpoint:dI}),gs=O(["COMPLETED","FAILED"]),mI=d({scenarioId:s,challengeSha256:b,attempts:x,completions:l,failures:l,bestMarginType:O(["RUNS","WICKETS","INNINGS"]).nullable(),bestMarginValue:x.nullable(),lastOutcome:gs.nullable()}),gI=d({gameId:s,scenarioId:s,challengeSha256:b,playerTeamId:s,objective:ms,outcome:gs.nullable(),resultText:w().min(1).max(160).nullable()});d({schemaId:m(cI),records:v(mI).max(256),attempts:v(gI).max(64)}).superRefine((n,e)=>{new Set(n.records.map(i=>`${i.scenarioId}:${i.challengeSha256}`)).size!==n.records.length&&e.addIssue({code:"custom",message:"SCENARIO_RECORD_DUPLICATE"}),new Set(n.attempts.map(i=>i.gameId)).size!==n.attempts.length&&e.addIssue({code:"custom",message:"SCENARIO_ATTEMPT_DUPLICATE"});for(const i of n.records)i.completions+i.failures>i.attempts&&e.addIssue({code:"custom",message:"SCENARIO_RECORD_COUNTS"});for(const i of n.attempts)i.outcome===null!=(i.resultText===null)&&e.addIssue({code:"custom",message:"SCENARIO_ATTEMPT_RESULT"})});const pI="LC_T20_SUPER_OVER_01",II="LC_T20_SUPER_OVER_RECORD_V1",hI="LC_ODI_SUPER_OVER_01",fI="LC_ODI_SUPER_OVER_RECORD_V1",pa=An("kind",[d({kind:m("SET_SUPER_OVER_BATTERS"),teamId:s,playerIds:v(s).min(2).max(3)}),d({kind:m("SET_SUPER_OVER_BOWLER"),teamId:s,playerId:s}),d({kind:m("SET_SUPER_OVER_AGGRESSION"),playerId:s,aggression:l.max(4)}),d({kind:m("BOWL_SUPER_OVER_BALL")})]),EI=d({schemaId:m(II),rulesId:m(pI),gameId:s,baseLastEventHash:b,commands:v(pa).max(2e3),stateSha256:b}),SI=d({schemaId:m(fI),rulesId:m(hI),gameId:s,baseLastEventHash:b,commands:v(pa).max(2e3),stateSha256:b});An("schemaId",[EI,SI]);const _I=d({battingTeamId:s,runs:l,wickets:l.max(2),legalBalls:l.max(6)});d({roundNumber:x,innings:v(_I).max(2)});const ps="LC_CUSTOM_COMPETITION_PACK_V1",vI="LC_TOURNAMENT_RUN_V1",bI=An("kind",[d({kind:m("ROUND_ROBIN"),legs:Vn([m(1),m(2)]),finalTopTwo:H()}),d({kind:m("GROUPS_KNOCKOUT"),groups:wn([v(s).min(3).max(4),v(s).min(3).max(4)])}),d({kind:m("SERIES"),matches:Vn([m(1),m(3),m(5),m(7)])})]);function Is(n,e){new Set(n.teamIds).size!==n.teamIds.length&&e.addIssue({code:"custom",message:"COMPETITION_DUPLICATE_TEAM"}),new Set(n.groundIds).size!==n.groundIds.length&&e.addIssue({code:"custom",message:"COMPETITION_DUPLICATE_GROUND"});const t=n.structure;if(t.kind==="SERIES"&&n.teamIds.length!==2&&e.addIssue({code:"custom",message:"SERIES_NEEDS_TWO_TEAMS"}),t.kind==="ROUND_ROBIN"&&n.teamIds.length<(t.finalTopTwo?3:2)&&e.addIssue({code:"custom",message:"ROUND_ROBIN_TOO_FEW_TEAMS"}),t.kind==="GROUPS_KNOCKOUT"){const i=[...t.groups[0],...t.groups[1]];(new Set(i).size!==i.length||i.length!==n.teamIds.length||!i.every(a=>n.teamIds.includes(a)))&&e.addIssue({code:"custom",message:"GROUPS_MUST_PARTITION_TEAMS"})}}function hs(n){return d({competitionId:s,title:w().min(1).max(80),format:O(["T20","ODI"]),sourceType:m(n),worldPackId:m("fictional-eight-01"),teamIds:v(s).min(2).max(8),groundIds:v(s).min(1).max(8),structure:bI,points:d({win:l.max(10),tie:l.max(10),loss:l.max(10)}),summary:w().min(1).max(320)})}const fs=hs("FICTIONAL_CURATED").superRefine(Is),TI=d({schemaId:m(ps),packId:s,competitions:v(fs).min(1).max(32)}),RI=O(["LEAGUE","GROUP_A","GROUP_B","SEMI_FINAL","FINAL","SERIES"]),LI=d({fixtureId:s,matchNumber:x,stage:RI,homeTeamId:s,awayTeamId:s,groundId:s}),AI=d({fixtureId:s,homeTeamId:s,awayTeamId:s,resultKind:O(["WIN","TIE"]),winnerTeamId:s.nullable(),superOverWinnerTeamId:s.nullable(),homeRuns:l,homeWickets:l.max(10),homeLegalBalls:l,awayRuns:l,awayWickets:l.max(10),awayLegalBalls:l,resultText:w().min(1).max(160),lastEventHash:b});d({schemaId:m(vI),runId:s,competitionId:s,competitionSha256:b,seed:w().min(1).max(128),results:v(AI).max(64)});const OI="LC_USER_COMPETITION_V1",wI="LC_USER_COMPETITION_PACK_V1",Ia=hs("USER_AUTHORED").superRefine((n,e)=>{Is(n,e),n.competitionId.startsWith("user-")||e.addIssue({code:"custom",message:"USER_COMPETITION_ID_PREFIX"})});d({schemaId:m(OI),competition:Ia}),d({schemaId:m(wI),competitions:v(Ia).min(1).max(32)});const NI="LC_USER_TOUR_V1",DI=d({tourId:s.refine(n=>n.startsWith("user-tour-"),"USER_TOUR_ID_PREFIX"),title:w().min(1).max(80),format:O(["T20","ODI"]),hostTeamId:s,touringName:w().min(1).max(40),matches:Vn([m(1),m(3),m(5),m(7)]),groundIds:v(s).min(1).max(8)});d({schemaId:m(NI),tour:DI});const CI="LC_TOURNAMENT_AUCTION_V1",yI=An("kind",[d({kind:m("BID"),max:x.max(1e3)}),d({kind:m("PASS")}),d({kind:m("AUTO")})]);d({schemaId:m(CI),runId:s,competitionId:s,seed:w().min(1).max(160),playerTeamId:s.nullable(),decisions:v(yI).max(400),squadsSha256:b}),Vn([fs,Ia]);const ha="LC_T20_RAIN_01",fa="LC_ODI_RAIN_01",Ea="LC_RAIN_MATCH_RECORD_V1",Es=An("kind",[d({kind:m("CALL_TOSS"),teamId:s,call:O(["HEADS","TAILS"])}),d({kind:m("CHOOSE_INNINGS"),teamId:s,choice:O(["BAT","BOWL"])}),d({kind:m("SET_BATTER"),teamId:s,playerId:s}),d({kind:m("SET_BOWLER"),teamId:s,playerId:s}),d({kind:m("SET_AGGRESSION"),playerId:s,aggression:l.max(4)}),d({kind:m("BOWL"),scope:O(["BALL","OVER"])})]),kI=d({inningsIndex:Vn([m(0),m(1)]),atLegalBall:x,oversLost:x,terminal:H()}),BI=d({stoppages:v(kI).min(1).max(2)});d({inningsIndex:Vn([m(0),m(1)]),legalBalls:l,wickets:l.max(10),runs:l,ballsLost:l,allocations:wn([l,l]),terminal:H(),targetAfter:x.nullable()}),d({kind:O(["WIN","TIE","NO_RESULT"]),winnerTeamId:s.nullable(),marginType:O(["RUNS","WICKETS"]).nullable(),margin:l.nullable(),method:O(["STANDARD","RESOURCE_TABLE"])});const Ss=d({schemaId:m(Ea),rulesId:O([ha,fa]),gameId:s,matchId:s,seed:w().min(1).max(256),groundId:s,selectedTeams:v(d({teamId:s,playerIds:v(s).length(11),captainId:s,keeperId:s})).length(2),commands:v(Es).max(4e3),stateSha256:b}),Sa="LC_T20_DRS_01",_a="LC_ODI_DRS_01",va="LC_EXTRA_RULES_RECORD_V1",PI=2,ba=An("kind",[...Es.options,d({kind:m("REVIEW_DECISION"),teamId:s,review:H()})]),Ta=O(["IN","UMPIRES_CALL","OUT"]);d({pitching:Ta,impact:Ta,wickets:Ta});const _s=d({schemaId:m(va),rulesId:O([ha,fa]),rain:H(),reviewRulesId:O([Sa,_a]).nullable(),gameId:s,matchId:s,seed:w().min(1).max(256),groundId:s,selectedTeams:v(d({teamId:s,playerIds:v(s).length(11),captainId:s,keeperId:s})).length(2),commands:v(ba).max(6e3),stateSha256:b}),vs=An("schemaId",[Ss,_s]);/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */function xI(n){return n instanceof Uint8Array||ArrayBuffer.isView(n)&&n.constructor.name==="Uint8Array"}function li(n,...e){if(!xI(n))throw new Error("Uint8Array expected");if(e.length>0&&!e.includes(n.length))throw new Error("Uint8Array expected of length "+e+", got length="+n.length)}function bs(n,e=!0){if(n.destroyed)throw new Error("Hash instance has been destroyed");if(e&&n.finished)throw new Error("Hash#digest() has already been called")}function FI(n,e){li(n);const t=e.outputLen;if(n.length<t)throw new Error("digestInto() expects output buffer of length at least "+t)}function Ra(...n){for(let e=0;e<n.length;e++)n[e].fill(0)}function La(n){return new DataView(n.buffer,n.byteOffset,n.byteLength)}function ge(n,e){return n<<32-e|n>>>e}const HI=typeof Uint8Array.from([]).toHex=="function"&&typeof Uint8Array.fromHex=="function",MI=Array.from({length:256},(n,e)=>e.toString(16).padStart(2,"0"));function VI(n){if(li(n),HI)return n.toHex();let e="";for(let t=0;t<n.length;t++)e+=MI[n[t]];return e}function Aa(n){if(typeof n!="string")throw new Error("string expected");return new Uint8Array(new TextEncoder().encode(n))}function Ts(n){return typeof n=="string"&&(n=Aa(n)),li(n),n}class $I{}function WI(n){const e=i=>n().update(Ts(i)).digest(),t=n();return e.outputLen=t.outputLen,e.blockLen=t.blockLen,e.create=()=>n(),e}function UI(n,e,t,i){if(typeof n.setBigUint64=="function")return n.setBigUint64(e,t,i);const a=BigInt(32),o=BigInt(4294967295),r=Number(t>>a&o),c=Number(t&o),u=i?4:0,p=i?0:4;n.setUint32(e+u,r,i),n.setUint32(e+p,c,i)}function GI(n,e,t){return n&e^~n&t}function zI(n,e,t){return n&e^n&t^e&t}class KI extends $I{constructor(e,t,i,a){super(),this.finished=!1,this.length=0,this.pos=0,this.destroyed=!1,this.blockLen=e,this.outputLen=t,this.padOffset=i,this.isLE=a,this.buffer=new Uint8Array(e),this.view=La(this.buffer)}update(e){bs(this),e=Ts(e),li(e);const{view:t,buffer:i,blockLen:a}=this,o=e.length;for(let r=0;r<o;){const c=Math.min(a-this.pos,o-r);if(c===a){const u=La(e);for(;a<=o-r;r+=a)this.process(u,r);continue}i.set(e.subarray(r,r+c),this.pos),this.pos+=c,r+=c,this.pos===a&&(this.process(t,0),this.pos=0)}return this.length+=e.length,this.roundClean(),this}digestInto(e){bs(this),FI(e,this),this.finished=!0;const{buffer:t,view:i,blockLen:a,isLE:o}=this;let{pos:r}=this;t[r++]=128,Ra(this.buffer.subarray(r)),this.padOffset>a-r&&(this.process(i,0),r=0);for(let h=r;h<a;h++)t[h]=0;UI(i,a-8,BigInt(this.length*8),o),this.process(i,0);const c=La(e),u=this.outputLen;if(u%4)throw new Error("_sha2: outputLen should be aligned to 32bit");const p=u/4,S=this.get();if(p>S.length)throw new Error("_sha2: outputLen bigger than state");for(let h=0;h<p;h++)c.setUint32(4*h,S[h],o)}digest(){const{buffer:e,outputLen:t}=this;this.digestInto(e);const i=e.slice(0,t);return this.destroy(),i}_cloneInto(e){e||(e=new this.constructor),e.set(...this.get());const{blockLen:t,buffer:i,length:a,finished:o,destroyed:r,pos:c}=this;return e.destroyed=r,e.finished=o,e.length=a,e.pos=c,a%t&&e.buffer.set(i),e}clone(){return this._cloneInto()}}const ye=Uint32Array.from([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),YI=Uint32Array.from([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),ke=new Uint32Array(64);class jI extends KI{constructor(e=32){super(64,e,8,!1),this.A=ye[0]|0,this.B=ye[1]|0,this.C=ye[2]|0,this.D=ye[3]|0,this.E=ye[4]|0,this.F=ye[5]|0,this.G=ye[6]|0,this.H=ye[7]|0}get(){const{A:e,B:t,C:i,D:a,E:o,F:r,G:c,H:u}=this;return[e,t,i,a,o,r,c,u]}set(e,t,i,a,o,r,c,u){this.A=e|0,this.B=t|0,this.C=i|0,this.D=a|0,this.E=o|0,this.F=r|0,this.G=c|0,this.H=u|0}process(e,t){for(let h=0;h<16;h++,t+=4)ke[h]=e.getUint32(t,!1);for(let h=16;h<64;h++){const A=ke[h-15],N=ke[h-2],y=ge(A,7)^ge(A,18)^A>>>3,L=ge(N,17)^ge(N,19)^N>>>10;ke[h]=L+ke[h-7]+y+ke[h-16]|0}let{A:i,B:a,C:o,D:r,E:c,F:u,G:p,H:S}=this;for(let h=0;h<64;h++){const A=ge(c,6)^ge(c,11)^ge(c,25),N=S+A+GI(c,u,p)+YI[h]+ke[h]|0,L=(ge(i,2)^ge(i,13)^ge(i,22))+zI(i,a,o)|0;S=p,p=u,u=c,c=r+N|0,r=o,o=a,a=i,i=N+L|0}i=i+this.A|0,a=a+this.B|0,o=o+this.C|0,r=r+this.D|0,c=c+this.E|0,u=u+this.F|0,p=p+this.G|0,S=S+this.H|0,this.set(i,a,o,r,c,u,p,S)}roundClean(){Ra(ke)}destroy(){this.set(0,0,0,0,0,0,0,0),Ra(this.buffer)}}const Rs=WI(()=>new jI);function ne(n){return VI(Rs(n))}function se(n){return Aa(pn(n))}function ZI(n){return pn(n),Aa(_m(n))}function Be(n=Xn){if(n!==Xn)throw new Error("UNSUPPORTED_RANDOM_VERSION: "+String(n));return Object.freeze({version:Xn,uint32(e){const t=Rs(ZI(e));return new DataView(t.buffer,t.byteOffset,t.byteLength).getUint32(0,!1)}})}function Nn(n=ni){if(n!==ni)throw new Error("UNSUPPORTED_STATE_HASH_VERSION: "+String(n));return Object.freeze({version:ni,hash(e){return ne(se(e))}})}const Oa={schemaVersion:"1.0.0",referenceEdition:"MCC_2017_FOURTH_EDITION_2026",effectiveDate:"2026-10-01",customProfile:!0,ballsPerOver:6,playersPerXI:11,wicketsToAllOut:10,consecutiveOvers:!1,maxLegSide:5,maxBehindSquareLegSide:2,limitedOversRain:!1,superOver:!1,supportedClauses:[],validationStatus:"CONTRACT_ONLY"},Pe=[{...Oa,rulesId:"LC_T20_01",format:"T20",inningsPerTeam:1,allocatedBalls:120,bowlerMaxBalls:24,freeHitAfterNoBall:!0,declarations:!1,followOnLead:null,newBallAfterLegalBalls:null,fieldPhases:[{fromLegalBall:0,maxOutside:2},{fromLegalBall:36,maxOutside:5}],localVariations:["No super over; ties share points"],fixtureIds:["F01","F02","F03","F04","F05","F06","F07","F08","F09"]},{...Oa,rulesId:"LC_ODI_01",format:"ODI",inningsPerTeam:1,allocatedBalls:300,bowlerMaxBalls:60,freeHitAfterNoBall:!0,declarations:!1,followOnLead:null,newBallAfterLegalBalls:null,fieldPhases:[{fromLegalBall:0,maxOutside:2},{fromLegalBall:60,maxOutside:4},{fromLegalBall:240,maxOutside:5}],localVariations:["One ball per innings"],fixtureIds:["F01","F02","F07","F08","F09"]},{...Oa,rulesId:"LC_RED5_01",format:"RED_BALL",inningsPerTeam:2,allocatedBalls:null,bowlerMaxBalls:null,freeHitAfterNoBall:!1,declarations:!0,followOnLead:200,newBallAfterLegalBalls:480,fieldPhases:[],localVariations:["Custom five-day clock; over completed at stumps despite wicket","No limited-overs rain provider"],fixtureIds:["F10","F11","F12"]}].map(n=>dm.parse(n)),di=mr.parse({registryId:"LC_FIELD_CONTRACT_01",referenceHand:"R",positions:[{slotId:"slip-1",sector:7,angleDegrees:315,depth:"INNER",insideCircle:!0,legSide:!1,behindSquare:!0},{slotId:"slip-2",sector:7,angleDegrees:300,depth:"INNER",insideCircle:!0,legSide:!1,behindSquare:!0},{slotId:"point",sector:6,angleDegrees:270,depth:"MIDDLE",insideCircle:!0,legSide:!1,behindSquare:!1},{slotId:"cover",sector:5,angleDegrees:225,depth:"MIDDLE",insideCircle:!0,legSide:!1,behindSquare:!1},{slotId:"mid-off",sector:4,angleDegrees:190,depth:"MIDDLE",insideCircle:!0,legSide:!1,behindSquare:!1},{slotId:"mid-on",sector:4,angleDegrees:170,depth:"MIDDLE",insideCircle:!0,legSide:!0,behindSquare:!1},{slotId:"midwicket",sector:3,angleDegrees:135,depth:"MIDDLE",insideCircle:!0,legSide:!0,behindSquare:!1},{slotId:"deep-square-leg",sector:2,angleDegrees:90,depth:"DEEP",insideCircle:!1,legSide:!0,behindSquare:!1},{slotId:"fine-leg",sector:1,angleDegrees:45,depth:"DEEP",insideCircle:!1,legSide:!0,behindSquare:!0},{slotId:"deep-cover",sector:5,angleDegrees:225,depth:"DEEP",insideCircle:!1,legSide:!1,behindSquare:!1},{slotId:"long-on",sector:4,angleDegrees:170,depth:"DEEP",insideCircle:!1,legSide:!0,behindSquare:!1}]}),wa=["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"],Na=["deep-cover","long-on","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"],Ls=mr.parse({registryId:"LC_ODI_FIELD_01",referenceHand:"R",positions:[...di.positions,{slotId:"long-off",sector:4,angleDegrees:190,depth:"DEEP",insideCircle:!1,legSide:!1,behindSquare:!1}]}),XI=wa,qI=Na,JI=["deep-cover","long-off","long-on","deep-square-leg","fine-leg","point","cover","mid-on","midwicket"],ee=Object.freeze({manifest:{modelId:"synthetic-alpha-01",schemaVersion:"1.0.0",status:"SYNTHETIC_ALPHA",randomId:"SHA256_COUNTER_V1",fixedPointScale:1e4,expLutHash:"d0cb73226646dec41e482127fc745ef64213f1c71f898ed7ad8c345ce591f825",featureSpecHash:"8a369a30b377ede7f7bc8c8f523a1c0124b6fd299ddf4f9fad5b3fd402d065b7",variationIds:["stock"],effects:{overAroundWicket:!1,individualVariations:!1,moisture:!1,geometryEffects:!1,outfieldSpeed:!1}},probabilityVersion:"LC_INTEGER_PROBABILITY_V1",lutVersion:"LC_EXP_LUT_V1",lutScale:"1000000000000",lutStepBp:100,lutMinDeltaBp:-16e4,lutMaxDeltaBp:0,logitMinBp:-8e4,logitMaxBp:8e4,coefficients:{legality:{WIDE:{CONTROL:-7e3,FATIGUE:5e3,LEG_LINE:2e3,MAXIMUM_EFFORT:1500,CONSERVE_EFFORT:-1e3},NO_BALL:{CONTROL:-5e3,FATIGUE:4e3,MAXIMUM_EFFORT:1500,CONSERVE_EFFORT:-1e3}},contact:{MISS:{DEFENCE:-4e3,AGGRESSION:2500,MOVEMENT:2500},PAD:{DEFENCE:-3e3,MOVEMENT:2e3},GROUND:{TIMING:3500,AGGRESSION:-1500},AERIAL:{AGGRESSION:4500,POWER:2500},EDGE:{TIMING:-4e3,AGGRESSION:2500,MOVEMENT:3e3},HIT_WICKET:{AGGRESSION:1e3}}},featureSpec:{maxTerms:32,fixedPointScale:1e4,termMultiplyRounding:"NEAREST_TIES_AWAY_FROM_ZERO",accumulationOrder:"INTERCEPT_TERMS_IN_ARRAY_ORDER",clipTiming:"AFTER_SUM",lutDeltaRounding:"NEAREST_TIES_AWAY_FROM_ZERO",categoryOrder:"AS_SUPPLIED",massAllocation:"LARGEST_REMAINDER_CATEGORY_INDEX"},expLutValues:[1e12,990049833749,980198673307,970445533549,960789439152,951229424501,941764533584,932393819906,923116346387,913931185271,904837418036,895834135297,886920436717,878095430921,869358235399,860707976425,852143788966,843664816596,835270211411,826959133943,818730753078,810584245970,802518797962,794533602503,786627861067,778800783071,771051585804,763379494337,755783741456,748263567579,740818220682,733446956224,726149037074,718923733432,711770322763,704688089719,697676326071,690734330637,683861409212,677056874498,670320046036,663650250136,657046819815,650509094723,644036421083,637628151622,631283645507,625002268283,618783391806,612626394184,606530659713,600495578812,594520547970,588604969678,582748252374,576949810380,571209063849,565525438700,559898366565,554327284735,548811636094,543350869074,537944437595,532591801007,527292424043,522045776761,516851334492,511708577787,506616992366,501576069066,496585303791,491644197461,486752255960,481908990090,477113915521,472366552741,467666427010,463013068311,458406011305,453844795282,449328964117,444858066223,440431654506,436049286322,431710523429,427414931949,423162082318,418951549248,414782911682,410655752752,406569659741,402524224034,398519041085,394553710372,390627835359,386741023455,382892885975,379083038103,375311098851,371576691022,367879441171,364218979572,360594940173,357006960569,353454681959,349937749111,346455810330,343008517419,339595525645,336216493707,332871083698,329558961075,326279794623,323033256422,319819021816,316636769379,313486180883,310366941265,307278738601,304221264067,301194211912,298197279430,295230166924,292292577681,289384217939,286504796860,283654026500,280831621778,278037300453,275270783090,272531793034,269820056385,267135301966,264477261300,261845668580,259240260646,256660776954,254106959553,251578553060,249075304632,246596963942,244143283153,241714016897,239308922244,236927758682,234570288094,232236274730,229925485187,227637688384,225372655539,223130160148,220909977959,218711886952,216535667316,214381101427,212247973827,210136071201,208045182357,205975098205,203925611734,201896517995,199887614075,197898699084,195929574127,193980042291,192049908621,190138980102,188247065639,186373976039,184519523993,182683524053,180865792617,179066147911,177284409970,175520400617,173773943450,172044863823,170332988825,168638147269,166960169667,165298888222,163654136803,162025750934,160413567775,158817426107,157237166314,155672630368,154123661815,152590105757,151071808836,149568619223,148080386595,146606962130,145148198484,143703949778,142274071587,140858420921,139456856215,138069237311,136695425446,135335283237,133988674669,132655465080,131335521148,130028710878,128734903588,127453969895,126185781705,124930212199,123687135817,122456428253,121237966433,120031628511,118837293852,117654843022,116484157773,115325121038,114177616911,113041530640,111916748617,110803158362,109700648516,108609108825,107528430136,106458504379,105399224562,104350484755,103312180083,102284206716,101266461854,100258843723,99261251560,98273585604,97295747090,96327638230,95369162216,94420223196,93480726278,92550577510,91629683878,90717953289,89815294572,88921617459,88036832582,87160851462,86293586499,85434950967,84584859002,83743225592,82909966575,82084998624,81268239241,80459606750,79659020286,78866399791,78081666001,77304740443,76535545424,75774004023,75020040085,74273578214,73534543763,72802862827,72078462239,71361269556,70651213060,69948221745,69252225309,68563154154,67880939372,67205512740,66536806715,65874754426,65219289668,64570346893,63927861207,63291768360,62662004742,62038507377,61421213915,60810062625,60204992392,59605942709,59012853669,58425665965,57844320875,57268760265,56698926580,56134762834,55576212611,55023220056,54475729869,53933687300,53397038145,52865728738,52339705948,51818917173,51303310332,50792833865,50287436724,49787068368,49291678760,48801218362,48315638126,47834889494,47358924391,46887695220,46421154857,45959256649,45501954405,45049202394,44600955340,44157168420,43717797253,43282797902,42852126867,42425741081,42003597903,41585655121,41171870939,40762203978,40356613272,39955058261,39557498788,39163895099,38774207832,38388398018,38006427075,37628256807,37253849396,36883167401,36516173754,36152831754,35793105068,35436957722,35084354101,34735258945,34389637343,34047454735,33708676900,33373269960,33041200376,32712434939,32386940773,32064685328,31745636378,31429762018,31117030661,30807411033,30500872171,30197383422,29896914437,29599435168,29304915867,29013327082,28724639654,28438824714,28155853680,27875698255,27598330423,27323722447,27051846866,26782676493,26516184409,26252343966,25991128779,25732512726,25476469947,25222974835,24972002042,24723526470,24477523272,24233967846,23992835837,23754103131,23517745856,23283740375,23052063287,22822691425,22595601851,22370771856,22148178957,21927800894,21709615630,21493601345,21279736438,21067999523,20858369425,20650825182,20445346038,20241911446,20040501062,19841094744,19643672553,19448214745,19254701775,19063114292,18873433135,18685639338,18499714120,18315638889,18133395237,17952964940,17774329954,17597472416,17422374639,17249019115,17077388507,16907465653,16739233559,16572675402,16407774526,16244514442,16082878823,15922851505,15764416485,15607557920,15452260124,15298507567,15146284873,14995576820,14846368338,14698644505,14552390548,14407591843,14264233909,14122302410,13981783153,13842662086,13704925297,13568559012,13433549594,13299883542,13167547490,13036528203,12906812580,12778387650,12651240568,12525358621,12400729220,12277339903,12155178330,12034232285,11914489673,11795938520,11678566970,11562363287,11447315851,11333413155,11220643810,11108996538,10998460176,10889023669,10780676073,10673406554,10567204384,10462058943,10357959718,10254896296,10152858373,10051835745,9951818308,9852796061,9754759102,9657697628,9561601931,9466462402,9372269527,9279013887,9186686156,9095277102,9004777582,8915178548,8826471040,8738646185,8651695203,8565609397,8480380160,8395998967,8312457382,8229747049,8147859698,8066787139,7986521266,7907054052,7828377549,7750483891,7673365288,7597014028,7521422475,7446583071,7372488331,7299130847,7226503281,7154598372,7083408929,7012927833,6943148035,6874062557,6805664492,6737946999,6670903306,6604526709,6538810571,6473748318,6409333446,6345559513,6282420141,6219909016,6158019887,6096746566,6036082924,5976022895,5916560474,5857689713,5799404727,5741699686,5684568819,5628006414,5572006815,5516564421,5461673688,5407329126,5353525303,5300256836,5247518399,5195304719,5143610573,5092430793,5041760260,4991593907,4941926718,4892753725,4844070012,4795870710,4748150999,4700906108,4654131310,4607821930,4561973336,4516580943,4471640211,4427146648,4383095803,4339483271,4296304691,4253555745,4211232158,4169329698,4127844174,4086771438,4046107383,4005847942,3965989089,3926526838,3887457243,3848776398,3810480433,3772565519,3735027865,3697863716,3661069358,3624641109,3588575327,3552868406,3517516775,3482516898,3447865276,3413558443,3379592969,3345965457,3312672545,3279710902,3247077234,3214768275,3182780797,3151111598,3119757514,3088715408,3057982176,3027554745,2997430072,2967605145,2938076980,2908842626,2879899158,2851243683,2822873334,2794785275,2766976697,2739444819,2712186887,2685200177,2658481989,2632029651,2605840518,2579911972,2554241419,2528826292,2503664050,2478752177,2454088180,2429669595,2405493979,2381558914,2357862006,2334400888,2311173211,2288176653,2265408915,2242867719,2220550813,2198455963,2176580961,2154923618,2133481770,2112253272,2091236001,2070427855,2049826753,2029430636,2009237464,1989245217,1969451897,1949855523,1930454136,1911245797,1892228583,1873400594,1854759947,1836304777,1818033239,1799943506,1782033769,1764302237,1746747136,1729366712,1712159226,1695122957,1678256201,1661557273,1645024502,1628656235,1612450834,1596406681,1580522169,1564795710,1549225733,1533810679,1518549008,1503439193,1488479723,1473669102,1459005850,1444488499,1430115598,1415885710,1401797412,1387849295,1374039964,1360368038,1346832149,1333430946,1320163086,1307027244,1294022105,1281146370,1268398751,1255777973,1243282773,1230911903,1218664125,1206538214,1194532958,1182647157,1170879621,1159229174,1147694651,1136274898,1124968774,1113775148,1102692900,1091720922,1080858118,1070103400,1059455693,1048913933,1038477065,1028144045,1017913841,1007785429,997757796,987829941,978000868,968269597,958635154,949096575,939652906,930303203,921046532,911881966,902808588,893825493,884931781,876126562,867408957,858778094,850233109,841773148,833397366,825104923,816894992,808766751,800719387,792752096,784864081,777054553,769322731,761667842,754089120,746585808,739157155,731802419,724520863,717311760,710174389,703108036,696111994,689185564,682328053,675538775,668817052,662162211,655573587,649050521,642592360,636198460,629868179,623600886,617395954,611252761,605170695,599149146,593187512,587285198,581441612,575656171,569928297,564257416,558642960,553084370,547581089,542132566,536738257,531397622,526110127,520875244,515692449,510561223,505481054,500451433,495471858,490541831,485660858,480828452,476044129,471307411,466617824,461974899,457378172,452827183,448321477,443860604,439444117,435071575,430742541,426456581,422213267,418012175,413852884,409734979,405658048,401621683,397625480,393669041,389751968,385873871,382034362,378233057,374469575,370743540,367054581,363402326,359786413,356206478,352662165,349153117,345678986,342239423,338834083,335462628,332124719,328820023,325548209,322308950,319101922,315926805,312783281,309671035,306589757,303539138,300518873,297528660,294568201,291637198,288735360,285862395,283018016,280201940,277413884,274653570,271920721,269215065,266536330,263884249,261258557,258658991,256085291,253537200,251014463,248516827,246044043,243595864,241172045,238772343,236396518,234044334,231715554,229409945,227127278,224867324,222629857,220414653,218221490,216050150,213900415,211772071,209664903,207578703,205513260,203468369,201443825,199439425,197454970,195490260,193545100,191619294,189712650,187824977,185956088,184105794,182273910,180460255,178664645,176886902,175126848,173384307,171659104,169951068,168260026,166585811,164928254,163287191,161662456,160053888,158461325,156884609,155323581,153778085,152247968,150733075,149233256,147748360,146278239,144822747,143381736,141955064,140542588,139144166,137759658,136388926,135031834,133688245,132358025,131041040,129737160,128446254,127168192,125902848,124650093,123409804,122181856,120966126,119762493,118570836,117391037,116222977,115066539,113921607,112788069,111665808,110554715,109454677,108365585,107287330,106219803,105162898,104116510,103080533,102054865,101039402,100034043,99038688,98053236,97077590,96111652,95155325,94208514,93271123,92343060,91424231,90514545,89613910,88722237,87839436,86965419,86100099,85243388,84395203,83555456,82724066,81900947,81086019,80279200,79480409,78689565,77906591,77131407,76363937,75604103,74851830,74107042,73369664,72639624,71916848,71201263,70492799,69791384,69096948,68409422,67728736,67054824,66387618,65727050,65073055,64425567,63784522,63149855,62521504,61899404,61283495,60673714,60070001,59472294,58880535,58294664,57714622,57140352,56571796,56008897,55451599,54899847,54353584,53812757,53277311,52747193,52222350,51702729,51188278,50678946,50174682,49675436,49181157,48691796,48207305,47727634,47252736,46782563,46317069,45856207,45399930,44948193,44500951,44058159,43619773,43185749,42756044,42330614,41909417,41492412,41079555,40670807,40266126,39865471,39468803,39076082,38687268,38302323,37921209,37543887,37170319,36800468,36434297,36071770,35712850,35357501,35005688,34657375,34312529,33971113,33633095,33298440,32967115,32639087,32314323,31992790,31674456,31359290,31047260,30738335,30432483,30129675,29829879,29533067,29239208,28948273,28660233,28375059,28092723,27813195,27536449,27262457,26991191,26722624,26456730,26193481,25932851,25674815,25419347,25166420,24916010,24668091,24422640,24179630,23939039,23700842,23465014,23231533,23000376,22771518,22544938,22320612,22098518,21878634,21660938,21445408,21232023,21020761,20811601,20604522,20399503,20196525,19995566,19796607,19599627,19404608,19211529,19020371,18831115,18643742,18458234,18274571,18092736,17912711,17734476,17558015,17383310,17210343,17039098,16869556,16701701,16535516,16370985,16208091,16046818,15887149,15729069,15572563,15417613,15264205,15112324,14961954,14813080,14665687,14519761,14375287,14232251,14090637,13950433,13811624,13674196,13538136,13403429,13270062,13138023,13007298,12877873,12749736,12622874,12497274,12372924,12249812,12127924,12007249,11887775,11769490,11652381,11536438,11421649,11308001,11195485,11084088,10973799,10864608,10756504,10649475,10543511,10438601,10334735,10231903,10130094,10029297,9929504,9830704,9732887,9636043,9540163,9445237,9351255,9258208,9166088,9074884,8984587,8895189,8806680,8719052,8632296,8546404,8461365,8377173,8293819,8211294,8129591,8048700,7968614,7889325,7810825,7733106,7656160,7579980,7504558,7429886,7355958,7282765,7210300,7138556,7067526,6997203,6927580,6858650,6790405,6722839,6655946,6589718,6524149,6459233,6394962,6331331,6268334,6205963,6144212,6083076,6022549,5962623,5903294,5844556,5786401,5728826,5671823,5615387,5559513,5504195,5449428,5395205,5341522,5288373,5235752,5183656,5132078,5081013,5030456,4980402,4930846,4881783,4833209,4785117,4737505,4690366,4643696,4597490,4551744,4506454,4461614,4417220,4373268,4329753,4286672,4244018,4201790,4159981,4118589,4077608,4037035,3996866,3957097,3917723,3878741,3840147,3801937,3764107,3726653,3689572,3652860,3616514,3580529,3544902,3509630,3474708,3440134,3405905,3372015,3338463,3305245,3272357,3239797,3207560,3175644,3144046,3112762,3081790,3051126,3020766,2990709,2960951,2931489,2902320,2873442,2844851,2816544,2788519,2760773,2733302,2706106,2679179,2652521,2626128,2599998,2574127,2548514,2523156,2498050,2473194,2448586,2424222,2400100,2376219,2352575,2329167,2305991,2283046,2260329,2237839,2215572,2193527,2171701,2150092,2128698,2107517,2086547,2065786,2045231,2024880,2004732,1984785,1965036,1945484,1926126,1906960,1887986,1869200,1850601,1832187,1813957,1795908,1778038,1760346,1742831,1725489,1708320,1691322,1674493,1657832,1641336,1625004,1608835,1592827,1576978,1561287,1545752,1530372,1515144,1500068,1485142,1470365,1455734,1441250,1426909,1412711,1398654,1384737,1370959,1357318,1343812,1330441,1317203,1304097,1291121,1278274,1265555,1252962,1240495,1228152,1215932,1203833,1191855,1179995,1168254,1156630,1145121,1133727,1122446,1111278,1100220,1089273,1078435,1067704,1057080,1046562,1036149,1025839,1015631,1005526,995521,985615,975808,966099,956486,946969,937546,928217,918981,909837,900784,891821,882948,874162,865464,856853,848327,839886,831529,823255,815063,806953,798924,790975,783104,775312,767598,759960,752398,744912,737500,730162,722896,715703,708582,701532,694551,687640,680798,674024,667317,660678,654104,647595,641152,634772,628456,622203,616012,609882,603814,597806,591857,585968,580138,574365,568650,562992,557390,551844,546353,540917,535535,530206,524930,519707,514536,509416,504348,499329,494361,489442,484572,479750,474977,470251,465572,460939,456353,451812,447316,442865,438459,434096,429777,425500,421267,417075,412925,408816,404748,400721,396734,392786,388878,385009,381178,377385,373630,369912,366232,362588,358980,355408,351871,348370,344904,341472,338074,334710,331380,328083,324818,321586,318386,315218,312082,308977,305902,302859,299845,296862,293908,290983,288088,285221,282383,279574,276792,274038,271311,268611,265939,263293,260673,258079,255511,252969,250452,247960,245492,243050,240631,238237,235866,233520,231196,228896,226618,224363,222131,219920,217732,215566,213421,211297,209195,207113,205052,203012,200992,198992,197012,195052,193111,191190,189287,187404,185539,183693,181865,180056,178264,176490,174734,172996,171274,169570,167883,166212,164558,162921,161300,159695,158106,156533,154975,153433,151907,150395,148899,147417,145950,144498,143060,141637,140227,138832,137451,136083,134729,133388,132061,130747,129446,128158,126883,125621,124371,123133,121908,120695,119494,118305,117128,115962,114809,113666,112535],baselines:{legality:[{id:"LEGAL",baseWeight:9820},{id:"WIDE",baseWeight:130},{id:"NO_BALL",baseWeight:50}],contact:{T20_EARLY:[{id:"MISS",baseWeight:1250},{id:"PAD",baseWeight:700},{id:"GROUND",baseWeight:5900},{id:"AERIAL",baseWeight:1500},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],T20_MIDDLE:[{id:"MISS",baseWeight:1100},{id:"PAD",baseWeight:650},{id:"GROUND",baseWeight:6100},{id:"AERIAL",baseWeight:1500},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],T20_LATE:[{id:"MISS",baseWeight:1350},{id:"PAD",baseWeight:500},{id:"GROUND",baseWeight:5e3},{id:"AERIAL",baseWeight:2500},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],ODI_EARLY:[{id:"MISS",baseWeight:1700},{id:"PAD",baseWeight:900},{id:"GROUND",baseWeight:5950},{id:"AERIAL",baseWeight:800},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],ODI_MIDDLE:[{id:"MISS",baseWeight:1300},{id:"PAD",baseWeight:800},{id:"GROUND",baseWeight:6400},{id:"AERIAL",baseWeight:900},{id:"EDGE",baseWeight:595},{id:"HIT_WICKET",baseWeight:5}],ODI_LATE:[{id:"MISS",baseWeight:1300},{id:"PAD",baseWeight:550},{id:"GROUND",baseWeight:5300},{id:"AERIAL",baseWeight:2200},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}],RED_BALL:[{id:"MISS",baseWeight:1900},{id:"PAD",baseWeight:1400},{id:"GROUND",baseWeight:5650},{id:"AERIAL",baseWeight:400},{id:"EDGE",baseWeight:645},{id:"HIT_WICKET",baseWeight:5}]}}}),ve="d0cb73226646dec41e482127fc745ef64213f1c71f898ed7ad8c345ce591f825",Cn="d47d5caca955b7a374b0052d712b1674bca6d855e222194ce9f0587d8580b7ab";function As(n){for(const e of Object.values(n))e&&typeof e=="object"&&As(e);return Object.freeze(n)}const on=As({stagePackId:"synthetic-alpha-01-delivery-v1",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",status:"SYNTHETIC_ALPHA",source:"Lord_Cricket_XXVI_Technical_Design_V0_1(1).docx Appendix F",length:{intended:7e3,neighboursTotal:2500,gross:500,intendedControlBp:6e3,intendedFatigueBp:-5e3},elapsedSeconds:40,sectorLineMultiplierBp:12500,coverage:{neighbourBp:3500,ground:{INNER:8e3,MIDDLE:1e4,DEEP:7e3},aerial:{INNER:2e3,MIDDLE:5e3,DEEP:1e4},edge:{keeper:1e4,slip:1e4,gully:6e3,other:1e3}},catchOpportunityBp:{AERIAL:3e3,EDGE:4500},catchConversion:{interceptBp:15e3,catchingBp:12e3},runs:{GROUND:[4400,3600,900,100,1e3,0],AERIAL:[1800,1600,900,100,2400,3200],EDGE:[6e3,1300,300,0,2400,0],NONE:[9700,250,0,0,50,0],WIDE:[9800,150,50]},running:{interceptBp:-65e3,throwingBp:5e3,coverageBp:3e3,rotateBp:2500},bowled:{interceptBp:-35e3,controlBp:3e3,defenceBp:-3e3,stumpsBp:4e3},lbw:{interceptBp:-4e4,controlBp:3e3,defenceBp:-3e3},stumping:{numerator:3,denominator:1e3},noLiveMatchOrCalibration:!0}),Kn="34efa3037702e44a134ea38b414eab3e97c6f79f10b3e5458bc2ab05412e5d7a",Fn=Object.freeze({worldPackId:"fictional-eight-01",worldSeed:"lcxxvi-fictional-eight-v1-20260927",worldGeneratorVersion:"LC_FICTIONAL_WORLD_GENERATOR_V1",generatorSourceSha256:"a3aaa4b64926ad9859f84222eb51274e7881df750308c2e9ae8fd1fa66e2f4da",provenanceSourceSha256:"97c7a43de0937ce85dcc03c3cddbd2a1be67b99b8af2f0099391bb7c39562982",worldFileSha256:"0136173903ba42a199c84a17407cf711c2caf1b57c52472abb52e9be7a6d8257",worldCanonicalSha256:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",worldByteLength:310033}),Da=n=>new Set(n).size===n.length;function un(n,e){if(!n)throw new Error(`INVALID_DEFAULT_WORLD: ${e}`)}const mt=n=>n.bowlingStyle!==null&&(n.role==="BOWLER"||n.role==="ALLROUNDER");function QI(n,e){const t=Xm.parse(e),i=Fn;for(const A of Object.keys(i))un(t[A]===i[A],`manifest violates frozen ${A}`);un(t.modelHash===Cn,"model hash mismatch"),un(t.stagePackHash===Kn,"stage pack hash mismatch"),un(t.modelId===ee.manifest.modelId,"wrong model"),un(t.stagePackId===on.stagePackId,"wrong stage pack");const a=Pe.map(A=>A.rulesId);un(JSON.stringify(t.rulesIds)===JSON.stringify(a),"inconsistent rule IDs"),un(JSON.stringify(t.variationIds)===JSON.stringify(ee.manifest.variationIds),"model variation set mismatch");const o=Vi(n,t.variationIds,a);un(o.packId===t.worldPackId,"pack ID mismatch"),un(o.schemaVersion===t.schemaVersion,"schema mismatch"),un(o.players.length===160&&o.teams.length===8&&o.grounds.length===8,"expected exactly 160 players, eight teams and eight grounds"),un(JSON.stringify(o.rulesIds)===JSON.stringify(t.rulesIds),"world rules differ from manifest");const r=o.teams.map(A=>A.teamId),c=o.grounds.map(A=>A.groundId),u=A=>Array.from({length:8},(N,y)=>`${A}-${String(y+1).padStart(2,"0")}`);un(JSON.stringify(r)===JSON.stringify(u("team")),"team ID/order convention changed"),un(JSON.stringify(c)===JSON.stringify(u("ground")),"ground ID/order convention changed"),un(JSON.stringify(r)===JSON.stringify(t.teamIds)&&JSON.stringify(c)===JSON.stringify(t.groundIds),"world/manifest ID mismatch");const p=new Set(c);un(JSON.stringify(Object.keys(t.homeGroundIds))===JSON.stringify(r),"home-ground keys mismatch"),un(t.homeGroundIds&&Da(Object.values(t.homeGroundIds))&&Object.values(t.homeGroundIds).every(A=>p.has(A)),"home-ground reference invalid");const S=new Map(o.players.map(A=>[A.playerId,A])),h=[];for(const A of o.teams){un(A.squadIds.length===20,`20 players required: ${A.teamId}`);const N=A.squadIds.map(y=>S.get(y));h.push(...A.squadIds),un(N.filter(y=>y.role==="KEEPER").length>=2,`keepers missing: ${A.teamId}`),un(N.filter(mt).length>=6,`bowling capacity missing: ${A.teamId}`),un(new Set(N.map(y=>y.role)).size>=3,`insufficient role variety: ${A.teamId}`),un(Da(N.map(y=>y.playerId)),`repeated player in squad: ${A.teamId}`),un(new Set(N.map(y=>y.batHand)).size===2,`bat handedness missing: ${A.teamId}`),un(new Set(N.filter(mt).map(y=>y.bowlHand)).size===2,`bowling handedness missing: ${A.teamId}`)}un(Da(h)&&h.length===160&&h.every(A=>S.has(A)),"shared squad member or missing assignment");for(const A of o.players)un(A.provenance.kind==="FICTIONAL"&&A.provenance.sourceId===o.packId&&A.provenance.sourceHash===t.provenanceSourceSha256,`wrong provenance: ${A.playerId}`),un(A.exposureBalls.T20===0&&A.exposureBalls.ODI===0&&A.exposureBalls.RED_BALL===0,`invented exposure: ${A.playerId}`),un(Object.keys(A.skills).length===3&&Object.keys(A.exposureBalls).length===3,`missing format or exposure: ${A.playerId}`),un(A.variations.length===1&&A.variations[0]==="stock",`unsupported variation: ${A.playerId}`);return{world:o,manifest:t}}const Nt=Object.freeze({version:"LC_T20_CONDITIONS_V1",fatigueBaseBp:{pace:20,spin:12},effortFactorBp:{CONSERVE:8e3,NORMAL:1e4,MAXIMUM:13e3},recoveryNonBowlerPerOverBp:15,wearIncrementPerLegalBall:1,wearStep:100,wearTurnDeltaBp:20,wearVariabilityDeltaBp:10,wearSeamDeltaBp:-10,maxBasisPoints:1e4,weather:"DRY",ballAgeResetAtInnings:!0}),Os=Object.freeze({...Nt,version:"LC_ODI_CONDITIONS_V1"});cg.parse({competitionVersion:"LC_T20_LEAGUE_COMPETITION_V1",competitionId:"LC_T20_LEAGUE_01",format:"T20",worldPackId:"fictional-eight-01",worldCanonicalSha256:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",teamIds:["team-01","team-02","team-03","team-04","team-05","team-06","team-07","team-08"],groundIds:["ground-01","ground-02","ground-03","ground-04","ground-05","ground-06","ground-07","ground-08"],homeGroundIds:{"team-01":"ground-01","team-02":"ground-02","team-03":"ground-03","team-04":"ground-04","team-05":"ground-05","team-06":"ground-06","team-07":"ground-07","team-08":"ground-08"},teamCount:8,rounds:14,matchesPerRound:4,totalFixtures:56,roundSpacingDays:3,playoffs:!1,points:{win:2,tie:1,noResult:1,loss:0},tableOrder:["POINTS","WINS","NET_RUN_RATE","HEAD_TO_HEAD_POINTS","TEAM_ID"],rainAdjustedNrr:!1,schedulerAlgorithm:"CIRCLE_REVERSE_VENUES_V1"}),dg.parse({conditionPolicyVersion:"LC_T20_CAREER_CONDITION_V1",maxFatigueBp:1e4,restRecoveryPerDayBp:2e3,practiceRecoveryPerDayBp:1400,noRandomInjuries:!0}),mg.parse({availabilityVersion:"LC_T20_AVAILABILITY_PACK_V1",packId:"fictional-eight-01-availability-v1",worldPackId:Fn.worldPackId,worldCanonicalSha256:Fn.worldCanonicalSha256,entries:[]});const nh=Object.freeze(Object.fromEntries(Array.from({length:8},(n,e)=>{const t=e*20+1;return[`team-${String(e+1).padStart(2,"0")}`,Array.from({length:20},(i,a)=>`p${String(t+a).padStart(3,"0")}`)]}))),eh=Object.freeze(Array.from({length:160},(n,e)=>`p${String(e+1).padStart(3,"0")}`));pg.parse({trainingPolicyVersion:"LC_T20_CAREER_TRAINING_V1",readinessMinRatingDelta:-3,readinessMaxRatingDelta:3,readinessPracticeGainPerDay:1,readinessDecayPerDay:1,restRecoveryPerDayBp:2e3,practiceRecoveryPerDayBp:1400,noPermanentAttributeGrowth:!0}),hg.parse({policyVersion:"LC_T20_OFFSCREEN_POLICY_V1",executionVersion:"LC_T20_OFFSCREEN_FIXTURE_V1",selectionPolicyId:"LC_SEASON_XI_BASELINE_V1",captainPolicyId:"LC_FIXTURE_CAPTAIN_V1",conditionDeltaPolicyId:"LC_ENGINE_FINAL_FATIGUE_DELTA_V1",matchEngineVersion:"LC_T20_MATCH_V1",selectionScorePolicy:"SUM_SUPPORTED_T20_SKILLS_PLUS_AREA_READINESS_V1",unavailablePlayersExcluded:!0,fatigueSelectionEffect:"LOWER_FATIGUE_STABLE_TIEBREAK_ONLY",minimumNonKeeperBowlingCapable:5,requiresKeeper:!0,noFutureRandomAccess:!0,noAlternateMatchSimulator:!0}),Object.freeze([{schemaId:Qn,scenarioId:"t20-death-overs-chase",title:"Death-overs chase",format:"T20",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-2",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-03",objective:"WIN",objectiveSummary:"Score 23 from the last 24 balls with 5 wickets in hand.",briefing:"Northlight Ridge are 68 for 5 after 16 overs, chasing 91 against Silver Fen at Northlight Park. You captain the chase: pick your batters and their intent, and see it home.",checkpoint:{inningsIndex:1,legalBalls:96,revision:105,battingTeamId:"team-03",runs:68,wickets:5,targetToWin:91}},{schemaId:Qn,scenarioId:"t20-tail-end-chase",title:"Tail-end chase",format:"T20",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-12",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-06",objective:"WIN",objectiveSummary:"Score 46 from the last 30 balls with 3 wickets in hand.",briefing:"Silver Fen have collapsed to 36 for 7 after 15 overs, chasing 82 against Northlight Ridge. Three wickets remain. Find 46 runs before the overs or the batters run out.",checkpoint:{inningsIndex:1,legalBalls:90,revision:102,battingTeamId:"team-06",runs:36,wickets:7,targetToWin:82}},{schemaId:Qn,scenarioId:"t20-defend-55",title:"Hold the line",format:"T20",difficulty:"STANDARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-11",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-03",objective:"WIN",objectiveSummary:"Stop Silver Fen scoring 55 from the last 30 balls.",briefing:"Silver Fen are 49 for 4 after 15 overs, chasing 104. You lead Northlight Ridge in the field: choose bowlers, plans and fields for the last five overs.",checkpoint:{inningsIndex:1,legalBalls:90,revision:98,battingTeamId:"team-06",runs:49,wickets:4,targetToWin:104}},{schemaId:Qn,scenarioId:"t20-defend-19",title:"Nineteen to defend",format:"T20",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-t20-1",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-03",objective:"WIN",objectiveSummary:"Stop Silver Fen scoring 19 from the last 30 balls.",briefing:"Silver Fen are 52 for 4 after 15 overs, chasing 71. Northlight Ridge need six wickets, or to keep the runs below 19, in the last five overs.",checkpoint:{inningsIndex:1,legalBalls:90,revision:99,battingTeamId:"team-06",runs:52,wickets:4,targetToWin:71}},{schemaId:Qn,scenarioId:"odi-tail-rescue",title:"Lower-order rescue",format:"ODI",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-odi-8",matchId:"human-odi",teamIds:["team-02","team-05"],groundId:"ground-02",playerTeamId:"team-02",objective:"WIN",objectiveSummary:"Score 32 more runs with 3 wickets in hand.",briefing:"Copper Vale are 59 for 7 after 17 overs, chasing 91 against Ember Plains at Copperfield. There is plenty of time and very little batting left. Nurse the tail to the target.",checkpoint:{inningsIndex:1,legalBalls:102,revision:133,battingTeamId:"team-02",runs:59,wickets:7,targetToWin:91}},{schemaId:Qn,scenarioId:"odi-last-ten",title:"Ten runs, two wickets",format:"ODI",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-odi-2",matchId:"human-odi",teamIds:["team-02","team-05"],groundId:"ground-02",playerTeamId:"team-05",objective:"WIN",objectiveSummary:"Take 2 wickets before Copper Vale score 10.",briefing:"Copper Vale are 134 for 8 after 40 overs, chasing 144. Ember Plains have 60 balls to take the last two wickets before the final 10 runs come.",checkpoint:{inningsIndex:1,legalBalls:240,revision:187,battingTeamId:"team-02",runs:134,wickets:8,targetToWin:144}},{schemaId:Qn,scenarioId:"red-fourth-innings-chase",title:"Fourth-innings chase",format:"RED_BALL",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-red-4",matchId:"human-red5",teamIds:["team-04","team-07"],groundId:"ground-04",playerTeamId:"team-07",objective:"WIN",objectiveSummary:"Score 63 more in the fourth innings with 4 wickets in hand.",briefing:"Larchwood are 41 for 6 in the fourth innings, chasing 104 against Westmere Isles at Westmere Oval. Time is not the problem; wickets are.",checkpoint:{inningsIndex:3,legalBalls:114,revision:293,battingTeamId:"team-07",runs:41,wickets:6,targetToWin:104}},{schemaId:Qn,scenarioId:"red-fourth-innings-defence",title:"Bowl them out",format:"RED_BALL",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-scenario-red-5",matchId:"human-red5",teamIds:["team-04","team-07"],groundId:"ground-04",playerTeamId:"team-04",objective:"WIN",objectiveSummary:"Take 7 wickets before Larchwood score 63.",briefing:"Larchwood are 28 for 3 in the fourth innings, chasing 91 at Westmere Oval. Westmere Isles must bowl them out to win.",checkpoint:{inningsIndex:3,legalBalls:84,revision:301,battingTeamId:"team-07",runs:28,wickets:3,targetToWin:91}},{schemaId:Qn,scenarioId:"t20-super-over-decider",title:"Level at the death",format:"T20",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-tie-469",matchId:"human-t20",teamIds:["team-03","team-06"],groundId:"ground-03",playerTeamId:"team-06",objective:"WIN",objectiveSummary:"Score 12 from the last 12 balls with 2 wickets in hand.",briefing:"Silver Fen are 71 for 8 after 18 overs, chasing 83 against Northlight Ridge. Left to the engine, this match finishes level. Finish it level and it goes to a super over; only an outright win completes the challenge.",checkpoint:{inningsIndex:1,legalBalls:108,revision:109,battingTeamId:"team-06",runs:71,wickets:8,targetToWin:83}},{schemaId:Qn,scenarioId:"t20-six-to-defend",title:"Six to defend",format:"T20",difficulty:"ELITE",sourceType:"FICTIONAL_CURATED",seed:"lc-tie-555",matchId:"human-t20",teamIds:["team-01","team-02"],groundId:"ground-01",playerTeamId:"team-01",objective:"WIN",objectiveSummary:"Stop Copper Vale scoring 6 from the last 18 balls.",briefing:"Copper Vale are 70 for 5 after 17 overs, chasing 76 at Aster Quay. Left to the engine, this match ends in a tie. Aster Harbour need five wickets, or to keep the last six runs out, to win outright.",checkpoint:{inningsIndex:1,legalBalls:102,revision:98,battingTeamId:"team-02",runs:70,wickets:5,targetToWin:76}},{schemaId:Qn,scenarioId:"odi-cup-final-defence",title:"Cup final: three wickets",format:"ODI",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-odi-tie-8",matchId:"human-odi",teamIds:["team-01","team-02"],groundId:"ground-01",playerTeamId:"team-01",objective:"WIN",objectiveSummary:"Take 3 wickets before Copper Vale score 10.",briefing:"A one-day cup final at Aster Quay. Copper Vale are 65 for 7 after 22 overs, chasing 75. Left to the engine, this final ends in a tie. Aster Harbour need three wickets before the last ten runs come.",checkpoint:{inningsIndex:1,legalBalls:132,revision:125,battingTeamId:"team-02",runs:65,wickets:7,targetToWin:75}},{schemaId:Qn,scenarioId:"odi-cup-final-chase",title:"Cup final: the tail's turn",format:"ODI",difficulty:"HARD",sourceType:"FICTIONAL_CURATED",seed:"lc-odi-tie-95",matchId:"human-odi",teamIds:["team-05","team-08"],groundId:"ground-05",playerTeamId:"team-08",objective:"WIN",objectiveSummary:"Score 21 more with 3 wickets in hand.",briefing:"A one-day cup final at Ember Meadow. Moonstone Bay are 45 for 7 after 11 overs, chasing 66 against Ember Plains. Left to the engine, this final ends in a tie. Find 21 runs before the last three wickets fall.",checkpoint:{inningsIndex:1,legalBalls:66,revision:106,battingTeamId:"team-08",runs:45,wickets:7,targetToWin:66}}].map(n=>Object.freeze(uI.parse(n)))),TI.parse({schemaId:ps,packId:"fictional-eight-tournaments-01",competitions:[{competitionId:"eight-nations-cup",title:"Eight Nations Cup",format:"T20",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-01","team-02","team-03","team-04","team-05","team-06","team-07","team-08"],groundIds:["ground-01","ground-02","ground-03","ground-04","ground-05","ground-06","ground-07","ground-08"],structure:{kind:"GROUPS_KNOCKOUT",groups:[["team-01","team-03","team-05","team-07"],["team-02","team-04","team-06","team-08"]]},points:{win:2,tie:1,loss:0},summary:"All eight sides in two T20 groups of four. The top two in each group reach the semi-finals, then a final. A tied knockout match goes to a super over."},{competitionId:"harbour-tri-series",title:"Harbour Tri-Series",format:"ODI",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-02","team-04","team-05"],groundIds:["ground-02","ground-04","ground-05"],structure:{kind:"ROUND_ROBIN",legs:2,finalTopTwo:!0},points:{win:4,tie:2,loss:0},summary:"Copper Vale, Westmere Isles and Ember Plains play each other twice in one-day matches. The top two meet in the final."},{competitionId:"larchwood-westmere-series",title:"Larchwood v Westmere one-day series",format:"ODI",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-07","team-04"],groundIds:["ground-07","ground-04"],structure:{kind:"SERIES",matches:5},points:{win:1,tie:0,loss:0},summary:"A five-match one-day series, home and away. It ends as soon as one side has won three."},{competitionId:"northern-t20-league",title:"Northern T20 League",format:"T20",sourceType:"FICTIONAL_CURATED",worldPackId:"fictional-eight-01",teamIds:["team-01","team-03","team-06","team-08"],groundIds:["ground-01","ground-03","ground-06","ground-08"],structure:{kind:"ROUND_ROBIN",legs:2,finalTopTwo:!1},points:{win:2,tie:1,loss:0},summary:"Four sides play each other home and away in T20s. Top of the table wins."}]});const th=[[0,416,818,1206,1581,1943,2293,2630,2956,3270,3574,3868,4151,4424,4688,4943,5190,5428,5657,5879,6093,6300,6499,6692,6878,7058,7231,7399,7561,7717,7868,8014,8154,8290,8421,8548,8670,8788,8902,9012,9119,9221,9320,9416,9509,9598,9684,9767,9847,9925,1e4],[0,404,794,1169,1530,1879,2215,2538,2850,3151,3441,3720,3989,4248,4498,4738,4970,5194,5409,5617,5817,6010,6196,6375,6547,6714,6874,7028,7177,7320,7459,7592,7720,7844,7963,8078,8188,8295,8398,8497,8592,8684,8773,8858,8941,9020,9097,9170,9241,9310,9376],[0,387,760,1118,1462,1794,2112,2419,2714,2997,3270,3532,3784,4027,4260,4484,4700,4907,5107,5299,5483,5661,5832,5996,6154,6306,6452,6592,6727,6857,6982,7102,7218,7329,7436,7539,7638,7733,7824,7912,7997,8078,8157,8232,8304,8374,8441,8505,8567,8627,8684],[0,366,716,1053,1376,1686,1984,2270,2544,2808,3060,3303,3536,3759,3974,4180,4377,4567,4749,4924,5091,5252,5407,5555,5697,5834,5965,6091,6212,6328,6439,6546,6649,6747,6841,6932,7019,7103,7183,7260,7334,7405,7473,7538,7601,7661,7719,7774,7827,7878,7927],[0,339,663,973,1271,1556,1829,2091,2341,2581,2811,3031,3242,3444,3638,3823,4001,4171,4334,4490,4640,4783,4920,5051,5177,5298,5414,5524,5630,5732,5829,5922,6011,6097,6179,6257,6333,6405,6473,6540,6603,6663,6722,6777,6830,6881,6930,6977,7022,7065,7106],[0,306,598,878,1145,1401,1645,1878,2102,2315,2519,2714,2901,3079,3249,3412,3568,3717,3859,3995,4125,4250,4368,4482,4591,4695,4794,4889,4980,5066,5149,5229,5304,5377,5446,5512,5576,5636,5694,5750,5802,5853,5901,5948,5992,6034,6074,6113,6150,6185,6219],[0,267,522,765,997,1218,1429,1630,1822,2006,2181,2347,2507,2659,2803,2942,3074,3200,3320,3434,3543,3648,3747,3842,3933,4019,4102,4180,4255,4327,4395,4460,4523,4582,4639,4693,4744,4793,4840,4885,4928,4968,5007,5044,5080,5114,5146,5176,5206,5234,5260],[0,221,431,632,822,1004,1177,1341,1498,1647,1789,1925,2054,2176,2293,2404,2510,2611,2707,2799,2886,2969,3048,3123,3194,3263,3327,3389,3448,3504,3557,3608,3657,3703,3746,3788,3828,3866,3902,3936,3969,4e3,4030,4058,4085,4110,4135,4158,4180,4201,4221],[0,166,324,474,616,752,880,1003,1119,1229,1334,1434,1529,1619,1704,1786,1863,1936,2006,2072,2136,2195,2252,2306,2358,2407,2453,2497,2539,2579,2617,2653,2687,2719,2750,2779,2807,2834,2859,2883,2906,2927,2948,2967,2986,3003,3020,3036,3051,3065,3079],[0,99,193,282,366,447,523,595,663,728,789,847,903,955,1005,1052,1097,1139,1179,1217,1254,1288,1320,1351,1381,1408,1435,1460,1483,1506,1527,1547,1566,1585,1602,1618,1634,1648,1662,1675,1688,1700,1711,1722,1732,1742,1751,1759,1768,1775,1783]],ih=[[0,683,1343,1980,2595,3189,3763,4316,4851,5368,5866,6348,6813,7261,7695,8113,8518,8908,9285,9649,1e4],[0,663,1302,1918,2512,3084,3635,4166,4678,5171,5647,6105,6546,6972,7382,7777,8158,8525,8878,9219,9547],[0,636,1247,1835,2400,2944,3467,3970,4454,4919,5366,5797,6210,6608,6991,7359,7714,8054,8382,8697,9e3],[0,600,1176,1728,2259,2768,3257,3726,4176,4608,5023,5421,5803,6170,6522,6860,7184,7495,7794,8081,8356],[0,556,1088,1598,2086,2554,3002,3431,3842,4236,4614,4975,5321,5653,5970,6275,6566,6845,7113,7369,7615],[0,502,982,1441,1879,2299,2700,3083,3449,3799,4134,4454,4760,5053,5333,5600,5856,6100,6334,6557,6770],[0,438,856,1255,1636,1999,2345,2676,2991,3292,3579,3853,4114,4363,4601,4828,5045,5251,5448,5636,5816],[0,363,708,1036,1349,1647,1931,2201,2459,2704,2937,3159,3371,3572,3764,3946,4120,4286,4443,4593,4736],[0,273,532,778,1012,1234,1445,1646,1836,2018,2190,2354,2509,2657,2797,2931,3058,3178,3293,3401,3505],[0,163,317,463,601,733,858,976,1088,1194,1295,1391,1482,1568,1649,1727,1800,1870,1936,1998,2058]],ah=Object.freeze({T20:160,ODI:245});function ui(n,e,t){if(!Number.isInteger(e)||!Number.isInteger(t)||e<0||t<0)throw new Error("RESOURCE_INPUT_INVALID");if(t>=10||e===0)return 0;const i=n==="T20"?ih:th;if(e>(n==="T20"?120:300))throw new Error("RESOURCE_INPUT_INVALID");const o=i[t],r=Math.floor(e/6),c=e%6,u=o[r],p=c===0?u:o[r+1];return u+Math.floor((p-u)*c/6)}const ws=BigInt(dt),oh=10000n,Ns=-80000n,Ds=80000n,rh=100n;function Dt(n,e){if(e<=0n)throw new Error("INVALID_DIVISOR: must be positive");const t=n<0n?-1n:1n,i=n<0n?-n:n;return t*((i*2n+e)/(2n*e))}function sh(n){let e=BigInt(n.interceptBp);for(const t of n.terms)e+=Dt(BigInt(t.coefficientBp)*BigInt(t.featureBp),oh);return e<Ns?Number(Ns):e>Ds?Number(Ds):Number(e)}function ch(n){pn(n);const e=Mm.parse(n);if(ne(se(e))!==Cn)throw new Error("UNSUPPORTED_MODEL_HASH: model pack bytes do not match pinned version");if(e.manifest.modelId!==le||e.probabilityVersion!==qn||e.lutVersion!==me||e.manifest.expLutHash!==ve)throw new Error("UNSUPPORTED_MODEL_VERSION");const t={version:e.lutVersion,stepBp:e.lutStepBp,minDeltaBp:e.lutMinDeltaBp,maxDeltaBp:e.lutMaxDeltaBp,scale:e.lutScale,values:e.expLutValues};if(ne(se(t))!==e.manifest.expLutHash)throw new Error("UNSUPPORTED_LUT_HASH: lookup table checksum mismatch");if(ne(se(e.featureSpec))!==e.manifest.featureSpecHash)throw new Error("UNSUPPORTED_FEATURE_SPEC_HASH");if(e.expLutValues[0]!==1e12||e.expLutValues.at(-1)<=0||e.expLutValues.some((a,o,r)=>o>0&&a>r[o-1]))throw new Error("INVALID_LUT: nonpositive or non-monotone exponential table");const i=[e.baselines.legality,...Object.values(e.baselines.contact)];if(Object.keys(e.baselines.contact).length!==7||i.some(a=>a.reduce((o,r)=>o+r.baseWeight,0)!==1e4||new Set(a.map(o=>o.id)).size!==a.length))throw new Error("INVALID_SYNTHETIC_BASELINES");return e}function Cs(n,e){if(!Number.isInteger(e)||e<0||e>=dt)throw new Error("INVALID_UINT32: draw outside [0, 2^32)");if(n.length===0||n.length>32)throw new Error("INVALID_CUMULATIVE_MASS");let t=0,i=-1;for(let a=0;a<n.length;a++){const o=n[a];if(!Number.isSafeInteger(o.mass)||!Number.isSafeInteger(o.cumulative)||o.mass<0||o.cumulative!==t+o.mass||!o.allowed&&o.mass!==0||o.cumulative>dt)throw new Error("INVALID_CUMULATIVE_MASS");i<0&&o.mass>0&&e<o.cumulative&&(i=a),t=o.cumulative}if(t!==dt||i===-1)throw new Error("INVALID_CUMULATIVE_MASS: exact 2^32 coverage required");return{index:i,id:n[i].id}}function ys(n=ee){const e=ch(n),t=Object.freeze(e.expLutValues.slice()),i=Be(Xn);function a(r){pn(r);const c=Wi.parse(r);if(c.modelHash!==Cn||c.lutHash!==ve)throw new Error("UNSUPPORTED_MODEL_OR_LUT_HASH");const u=c.categories.map(f=>f.id);if(new Set(u).size!==u.length)throw new Error("DUPLICATE_CATEGORY_ID: canonical category order requires unique IDs");const p=c.categories.map(f=>f.allowed&&f.baseWeight>0?sh(f):null),S=p.filter(f=>f!==null);if(!S.length)throw new Error("EMPTY_POSITIVE_MASK: no allowed category has positive weight");const h=S.reduce((f,R)=>f>R?f:R),A=p.map(f=>{if(f===null)return null;const R=BigInt(f)-BigInt(h),F=Number(-Dt(R,rh));if(F<0||F>=t.length)throw new Error("INVALID_LUT_INDEX");return F}),N=c.categories.map((f,R)=>A[R]===null?0n:BigInt(f.baseWeight)*BigInt(t[A[R]])),y=N.reduce((f,R)=>f+R,0n);if(y<=0n)throw new Error("INVALID_PROBABILITY_TOTAL");const L=N.map(f=>f*ws),E=L.map(f=>f/y),T=L.map(f=>f%y),g=ws-E.reduce((f,R)=>f+R,0n);if(g<0n||g>=BigInt(N.length))throw new Error("INVALID_REMAINDER_ALLOCATION");const I=N.map((f,R)=>R).sort((f,R)=>{const F=T[f]-T[R];return F>0n?-1:F<0n?1:f-R});for(let f=0;f<Number(g);f++)E[I[f]]+=1n;let _=0;const C=c.categories.map((f,R)=>{const F=Number(E[R]);return _+=F,Object.freeze({id:f.id,allowed:f.allowed,logitBp:p[R],lutIndex:A[R],mass:F,cumulative:_})});if(_!==dt)throw new Error("MASS_NOT_NORMALISED");return Object.freeze({probabilityVersion:qn,modelId:le,modelHash:Cn,lutVersion:me,lutHash:ve,totalMass:dt,categories:Object.freeze(C)})}function o(r){pn(r);const c=Hm.parse(r),u=a({probabilityVersion:c.probabilityVersion,modelId:c.modelId,modelHash:c.modelHash,lutVersion:c.lutVersion,lutHash:c.lutHash,categories:c.categories});if(c.kind==="NORMALISE_CATEGORIES")return{kind:c.kind,...u};if(c.address.stageName!==c.stageName)throw new Error("STAGE_ADDRESS_MISMATCH: draw address must name its probability stage");const p=i.uint32(c.address),S=Cs(u.categories,p);return{kind:c.kind,...u,draw:p,selectedIndex:S.index,selectedCategoryId:S.id}}return Object.freeze({version:qn,modelId:le,modelHash:Cn,lutHash:ve,normalise:a,execute:o})}ys();function lh(n){pn(n);const e=Vm.parse(n),t={CONTROL:(e.controlRating-50)*200,FATIGUE:e.fatigueBp,LEG_LINE:e.line==="LEG"?1e4:0,MAXIMUM_EFFORT:e.effort==="MAXIMUM"?1e4:0,CONSERVE_EFFORT:e.effort==="CONSERVE"?1e4:0};return ee.baselines.legality.map(i=>{const a=Object.entries(ee.coefficients.legality).find(([r])=>r===i.id)?.[1],o=a?Object.entries(a).map(([r,c])=>{const u=t[r];if(u===void 0)throw new Error("UNKNOWN_LEGALITY_FEATURE");return{coefficientBp:c,featureBp:u}}):[];return{id:i.id,baseWeight:i.baseWeight,allowed:!0,interceptBp:0,terms:o}})}function dh(n){pn(n);const e=$m.parse(n),t={DEFENCE:(e.defenceRating-50)*200,TIMING:(e.timingRating-50)*200,POWER:(e.powerRating-50)*200,AGGRESSION:(e.aggression-2)*1e4,MOVEMENT:e.effectiveMovementBp};return ee.baselines.contact[e.phase].map(i=>{const a=Object.entries(ee.coefficients.contact).find(([r])=>r===i.id)?.[1];if(!a)throw new Error("MISSING_CONTACT_COEFFICIENT");const o=Object.entries(a).map(([r,c])=>{const u=t[r];if(u===void 0)throw new Error("UNKNOWN_CONTACT_FEATURE");return{coefficientBp:c,featureBp:u}});return{id:i.id,baseWeight:i.baseWeight,allowed:!0,interceptBp:0,terms:o}})}class Ca extends Error{code;constructor(e,t){super(`${e}: ${t}`),this.code=e,this.name="ResolutionValidationError"}}const an=(n,e,t)=>{if(!n)throw new Ca(e,t)};function ya(n,e){const t=ct.safeParse(n),i=ti.safeParse(e);if(!t.success||!i.success)throw new Ca("INVALID_STRUCTURE","Context or resolution failed strict schema validation");const a=t.data,o=i.data,r=o.extras,c=o.dismissal;an(a.deliveryIndex>=a.legalBalls,"INVALID_CONTEXT","Global delivery attempt index precedes legal-ball count"),an(a.rulesId==="LC_RED5_01"?a.allocatedBalls===null&&a.inningsIndex<=3:a.allocatedBalls===(a.rulesId==="LC_T20_01"?120:300)&&a.inningsIndex<=1,"INVALID_CONTEXT","Base profile allocation or innings index invalid");const u=[a.strikerId,a.nonStrikerId,a.bowlerId,a.keeperId,...a.outfieldIds];an(new Set(u).size===u.length&&a.battingTeamId!==a.bowlingTeamId,"INVALID_CONTEXT","IDs must be distinct"),an(a.endsBefore[a.strikerEnd==="NORTH"?"north":"south"]===a.strikerId&&a.endsBefore[a.strikerEnd==="NORTH"?"south":"north"]===a.nonStrikerId,"INVALID_CONTEXT","Starting ends must identify both batters"),an((a.allocatedBalls===null||a.legalBalls<a.allocatedBalls)&&(a.targetToWin===null||a.runs<a.targetToWin),"INVALID_CONTEXT","Innings already ended"),an(a.rulesId!=="LC_RED5_01"||!a.freeHitPending,"INVALID_CONTEXT","Red-ball profile has no free hit"),an(r.penalties===0,"UNSUPPORTED_PENALTY","Penalty scoring requires a later administrative contract");const p=o.batRuns+r.wides+r.noBalls+r.byes+r.legByes;if(an(Number.isSafeInteger(p)&&Number.isSafeInteger(a.runs+p)&&Number.isSafeInteger(a.legalBalls+1)&&Number.isSafeInteger(a.deliveryIndex+1)&&Number.isSafeInteger(a.ballAgeLegalBalls+1),"UNSAFE_TOTAL","Counter arithmetic must remain safe"),an(!(r.byes>0&&r.legByes>0)&&!(o.batRuns>0&&(r.byes>0||r.legByes>0)),"INVALID_EXTRAS","Conflicting run channels"),an(!(o.batContact&&(r.byes>0||r.legByes>0))&&(r.legByes===0||o.attemptedStroke)&&(o.batRuns===0||o.batContact),"INVALID_EXTRAS","Contact/stroke evidence inconsistent"),o.legality==="LEGAL"&&an(r.wides===0&&r.noBalls===0,"INVALID_EXTRAS","Legal ball cannot charge wide/no-ball"),o.legality==="NO_BALL"&&an(r.noBalls===1&&r.wides===0,"INVALID_EXTRAS","No-ball overrides wide and carries one automatic run"),o.legality==="WIDE"&&an(r.wides>=1&&r.noBalls===0&&r.byes===0&&r.legByes===0&&o.batRuns===0&&!o.batContact,"INVALID_EXTRAS","Wide channel is exclusive"),o.legality==="DEAD"&&an(p===0&&c===null&&o.completedRuns===0&&o.attemptedRuns===0&&!o.batContact&&o.boundary==="NONE"&&o.fieldOutcome==="NONE","INVALID_EXTRAS","Early dead ball cannot score or dismiss"),o.boundary!=="NONE"?an(o.completedRuns===0&&o.attemptedRuns===0&&c===null&&p-r.noBalls-(o.legality==="WIDE"?1:0)===(o.boundary==="FOUR"?4:6)&&(o.boundary!=="SIX"||o.batRuns===6&&o.batContact),"INVALID_BOUNDARY","Boundary allowance incompatible with running/dismissal"):an(o.completedRuns===o.batRuns+r.byes+r.legByes+Math.max(0,r.wides-1),"INVALID_RUNNING","Completed runs exclude automatic penalties"),an(o.attemptedRuns===o.completedRuns+(c?.kind==="RUN_OUT"?1:0),"INVALID_RUNNING","Only the failed run-out attempt remains uncompleted"),o.stage==="IMMEDIATE_PENALTY")an((o.legality==="WIDE"||o.legality==="NO_BALL")&&a.targetToWin!==null&&a.runs+1>=a.targetToWin&&p===1&&o.batRuns===0&&o.completedRuns===0&&o.attemptedRuns===0&&c===null&&o.boundary==="NONE"&&!o.batContact&&o.trajectory===null&&o.shotSector===null&&o.fieldOutcome==="NONE","INVALID_IMMEDIATE_PENALTY","Winning automatic extra must terminate before contact or dismissal");else if((o.legality==="WIDE"||o.legality==="NO_BALL")&&a.targetToWin!==null&&a.runs+1>=a.targetToWin)throw new Ca("INVALID_IMMEDIATE_PENALTY","Immediate winning extra requires truncated resolution");an(!(a.targetToWin!==null&&a.runs+p>=a.targetToWin&&c!==null),"INVALID_DISMISSAL","Result achieved before a later dismissal"),an(!(a.targetToWin!==null&&o.boundary==="NONE"&&a.runs+p>a.targetToWin),"INVALID_RUNNING","Running cannot continue past the winning run"),c&&(an(c.playerId===a.strikerId||c.playerId===a.nonStrikerId,"INVALID_DISMISSAL","Dismissed player must be active"),an(c.kind==="RUN_OUT"||c.playerId===a.strikerId,"INVALID_DISMISSAL","Only a run-out may dismiss the non-striker"),an(!(o.legality==="NO_BALL"||a.freeHitPending)||c.kind==="RUN_OUT","INVALID_DISMISSAL","No-ball/free-hit mask"),an(o.legality!=="WIDE"||["RUN_OUT","STUMPED","HIT_WICKET"].includes(c.kind),"INVALID_DISMISSAL","Wide dismissal mask"),an(o.legality!=="DEAD","INVALID_DISMISSAL","Dead-ball dismissal"),an(c.fielderId===null||[a.bowlerId,a.keeperId,...a.outfieldIds].includes(c.fielderId),"INVALID_DISMISSAL","Unknown fielder"),c.kind==="CAUGHT"&&an(o.batContact&&["AERIAL","EDGE"].includes(o.trajectory??"")&&c.fielderId!==null&&o.fieldOutcome==="CATCH"&&o.batRuns===0,"INVALID_DISMISSAL","Catch requires bat contact, fielder and zero bat runs"),c.kind==="STUMPED"&&an(c.fielderId===a.keeperId&&!o.batContact&&o.attemptedRuns===0,"INVALID_DISMISSAL","Stumping requires keeper and no run attempted"),c.kind==="RUN_OUT"&&an(c.fielderId!==null&&o.fieldOutcome==="RUN_OUT","INVALID_DISMISSAL","Run-out needs a fielder and outcome"),["BOWLED","LBW","HIT_WICKET"].includes(c.kind)&&an(c.fielderId===null,"INVALID_DISMISSAL","Unassisted dismissal"),c.kind==="LBW"&&an(!o.batContact,"INVALID_DISMISSAL","LBW cannot follow bat contact"),c.kind!=="RUN_OUT"&&an(c.wicketEnd===a.strikerEnd&&o.completedRuns===0,"INVALID_DISMISSAL","Supported non-run-out dismissal is at striker end without completed runs")),an(o.fieldOutcome!=="CATCH"||c?.kind==="CAUGHT","INVALID_DISMISSAL","Ineligible catch must be a stop, not a credited catch"),an(o.fieldOutcome!=="RUN_OUT"||c?.kind==="RUN_OUT","INVALID_DISMISSAL","Run-out outcome requires a dismissal");const S=[o.endsAfter.north,o.endsAfter.south].filter(h=>h!==null);if(c)an(S.length===1&&S[0]===(c.playerId===a.strikerId?a.nonStrikerId:a.strikerId),"INVALID_ENDS","Exactly the surviving batter occupies an end");else{const h=o.completedRuns%2===1;an(o.endsAfter.north===a.endsBefore[h?"south":"north"]&&o.endsAfter.south===a.endsBefore[h?"north":"south"],"INVALID_ENDS","Physical running determines ends")}return c&&c.kind!=="RUN_OUT"&&an(o.endsAfter[a.strikerEnd==="NORTH"?"north":"south"]===null,"INVALID_ENDS","Incoming batter belongs at dismissed striker end"),{context:a,resolution:o}}class uh extends Error{code;constructor(e,t){super(`${e}: ${t}`),this.code=e,this.name="ScoringInvariantError"}}function nn(n,e,t){if(!n)throw new uh(e,t)}function _n(...n){let e=0;for(const t of n)nn(Number.isSafeInteger(t)&&t>=0,"UNSAFE_COUNTER","Counter is not a safe non-negative integer"),e+=t,nn(Number.isSafeInteger(e),"UNSAFE_COUNTER","Counter overflow");return e}function ks(n,e){const{context:t,resolution:i}=ya(n,e);return Qt.parse({type:"DELIVERY_RECORDED",inningsIndex:t.inningsIndex,deliveryIndex:t.deliveryIndex,strikerId:t.strikerId,nonStrikerId:t.nonStrikerId,bowlerId:t.bowlerId,legality:i.legality,legalBall:i.legality==="LEGAL",countsAsBallFaced:i.legality==="LEGAL"||i.legality==="NO_BALL",batRuns:i.batRuns,extras:i.extras,completedRuns:i.completedRuns,boundary:i.boundary,dismissal:i.dismissal?{...i.dismissal,creditedBowlerId:i.dismissal.kind==="RUN_OUT"?null:t.bowlerId}:null,endsAfter:i.endsAfter,shotSector:i.shotSector,trajectory:i.trajectory,executedLength:i.executedLength,fieldOutcome:i.fieldOutcome,elapsedSeconds:i.elapsedSeconds,freeHitNext:t.rulesId!=="LC_RED5_01"&&(i.legality==="NO_BALL"||t.freeHitPending&&i.legality!=="LEGAL")})}function mh(n,e){const t=ct.parse(n),i=Qt.parse(e);for(const c of["inningsIndex","deliveryIndex","strikerId","nonStrikerId","bowlerId"])nn(i[c]===t[c],"EVENT_CONTEXT_MISMATCH",c);nn(i.legalBall===(i.legality==="LEGAL"),"INVALID_EVENT_FLAGS","legalBall"),nn(i.countsAsBallFaced===(i.legality==="LEGAL"||i.legality==="NO_BALL"),"INVALID_EVENT_FLAGS","countsAsBallFaced");const a=t.rulesId!=="LC_RED5_01"&&(i.legality==="NO_BALL"||t.freeHitPending&&i.legality!=="LEGAL");nn(i.freeHitNext===a,"INVALID_EVENT_FLAGS","freeHitNext"),i.dismissal&&nn(i.dismissal.creditedBowlerId===(i.dismissal.kind==="RUN_OUT"?null:t.bowlerId),"INVALID_WICKET_CREDIT","Dismissal credit differs from its kind");const{creditedBowlerId:o,...r}=i.dismissal??{creditedBowlerId:null};return ya(t,{stage:(i.legality==="WIDE"||i.legality==="NO_BALL")&&t.targetToWin!==null&&t.runs+1>=t.targetToWin?"IMMEDIATE_PENALTY":"DELIVERY",legality:i.legality,batRuns:i.batRuns,extras:i.extras,completedRuns:i.completedRuns,attemptedRuns:i.completedRuns+(i.dismissal?.kind==="RUN_OUT"?1:0),boundary:i.boundary,dismissal:i.dismissal?r:null,endsAfter:i.endsAfter,batContact:i.batRuns>0||i.dismissal?.kind==="CAUGHT",attemptedStroke:!0,shotSector:i.shotSector,trajectory:i.trajectory,executedLength:i.executedLength,fieldOutcome:i.fieldOutcome,elapsedSeconds:i.elapsedSeconds}),{context:t,event:i}}function gh(n,e){const{context:t,event:i}=mh(n,e),a=i.extras,o={teamRuns:_n(i.batRuns,a.wides,a.noBalls,a.byes,a.legByes,a.penalties),batterRuns:i.batRuns,bowlerRuns:_n(i.batRuns,a.wides,a.noBalls),legalBalls:Number(i.legalBall),ballsFaced:Number(i.countsAsBallFaced),wickets:+(i.dismissal!==null),bowlerWickets:+(i.dismissal?.creditedBowlerId!==null&&i.dismissal!==null),deliveryAttempts:1},r={runs:_n(t.runs,o.teamRuns),wickets:_n(t.wickets,o.wickets),legalBalls:_n(t.legalBalls,o.legalBalls),ballAgeLegalBalls:_n(t.ballAgeLegalBalls,o.legalBalls)},c=i.legalBall&&r.legalBalls%6===0,u=c?t.strikerEnd==="NORTH"?"SOUTH":"NORTH":t.strikerEnd,p=t.targetToWin!==null&&r.runs>=t.targetToWin,S=p||r.wickets===10||t.allocatedBalls!==null&&r.legalBalls>=t.allocatedBalls;let h=null;p?h={kind:"WIN",winnerTeamId:t.battingTeamId,marginType:"WICKETS",marginRuns:null,marginWickets:10-r.wickets,completionReason:"TARGET_REACHED"}:S&&t.targetToWin!==null&&(r.runs===t.targetToWin-1?h={kind:"TIE",winnerTeamId:null,marginType:null,marginRuns:null,marginWickets:null,completionReason:"CHASE_COMPLETE_LEVEL"}:h={kind:"WIN",winnerTeamId:t.bowlingTeamId,marginType:"RUNS",marginRuns:t.targetToWin-1-r.runs,marginWickets:null,completionReason:"CHASE_COMPLETE_SHORT"});const A=S||!i.dismissal?null:i.endsAfter.north===null?"NORTH":"SOUTH",N=S?null:i.endsAfter[u==="NORTH"?"north":"south"],y=h?"NONE":S?"START_NEXT_INNINGS":A?"SELECT_BATTER":c?"SELECT_BOWLER":"ADVANCE",L=["DELIVERY_RECORDED"];return c&&L.push("OVER_COMPLETED"),S&&L.push("INNINGS_COMPLETED"),h&&L.push("MATCH_COMPLETED"),gr.parse({event:i,delta:o,totals:r,strikerEndAfter:u,nextStrikerId:N,requiredBatterEnd:A,freeHitPending:i.freeHitNext,overCompleted:c,inningsComplete:S,result:h,events:L,nextAction:y})}function te(n){const e=Dm.parse(n),t=e.innings,i=Object.keys(e.batting),a=Object.keys(e.bowling);nn(t.battingTeamId!==t.bowlingTeamId,"INVALID_LEDGER","Teams must differ"),nn(t.battingOrder.length===11&&new Set(t.battingOrder).size===11&&i.length===11&&t.battingOrder.every(c=>Object.hasOwn(e.batting,c)),"INVALID_LEDGER","Batting order must identify eleven ledger players"),nn(a.length===11&&[e.keeperId,...e.outfieldIds,...t.bowlerId?[t.bowlerId]:[]].every(c=>Object.hasOwn(e.bowling,c)),"INVALID_LEDGER","Bowling references missing"),nn(new Set([e.keeperId,...e.outfieldIds]).size===10&&!a.some(c=>Object.hasOwn(e.batting,c)),"INVALID_LEDGER","Field identities overlap"),nn(new Set(t.dismissed).size===t.dismissed.length&&t.dismissed.length===t.wickets&&t.dismissed.every(c=>e.batting[c]?.dismissed),"INVALID_LEDGER","Dismissed identities mismatch"),nn(i.filter(c=>e.batting[c].dismissed).length===t.wickets,"INVALID_LEDGER","Dismissal flags mismatch"),nn(t.complete||!(t.wickets===10||t.allocatedBalls!==null&&t.legalBalls>=t.allocatedBalls||t.targetToWin!==null&&t.runs>=t.targetToWin),"INVALID_LEDGER","Terminal innings must be marked complete");const o=e.rulesId==="LC_T20_01"?24:e.rulesId==="LC_ODI_01"?60:null;nn(o===null||Object.values(e.bowling).every(c=>c.legalBalls<=o),"BOWLER_QUOTA","Stored quota exceeded");const r=[t.northBatterId,t.southBatterId].filter(c=>c!==null);nn(new Set(r).size===r.length&&r.every(c=>Object.hasOwn(e.batting,c)&&!e.batting[c].dismissed),"INVALID_LEDGER","Invalid end occupancy"),nn(_n(...Object.values(e.batting).map(c=>c.runs),...Object.values(t.extras))===t.runs,"SCORE_RECONCILIATION","Bat runs plus extras must equal innings runs"),nn(_n(...Object.values(e.bowling).map(c=>c.legalBalls))===t.legalBalls,"BALL_RECONCILIATION","Bowler legal-ball counts must reconcile"),nn(_n(...Object.values(e.bowling).map(c=>c.runsConceded))===t.runs-t.extras.byes-t.extras.legByes-t.extras.penalties,"SCORE_RECONCILIATION","Bowler conceded runs mismatch"),nn(Object.keys(e.dismissals).length===t.wickets&&t.dismissed.every(c=>e.dismissals[c]?.playerId===c),"WICKET_RECONCILIATION","Dismissal records missing");for(const c of a)nn(e.bowling[c].wickets===Object.values(e.dismissals).filter(u=>u.creditedBowlerId===c).length,"WICKET_RECONCILIATION","Bowler credits must match dismissal records");for(const c of Object.values(e.dismissals))nn((c.kind==="RUN_OUT"?c.creditedBowlerId===null:c.creditedBowlerId!==null&&Object.hasOwn(e.bowling,c.creditedBowlerId))&&(c.fielderId===null||Object.hasOwn(e.bowling,c.fielderId)),"WICKET_RECONCILIATION","Invalid historical dismissal credit");nn(_n(...Object.values(e.batting).map(c=>c.ballsFaced))===_n(t.legalBalls,t.extras.noBalls),"BALL_RECONCILIATION","Batter balls faced must equal legal deliveries plus delivered no-balls"),nn(Object.keys(t.bowlerLegalBalls).length===a.length&&a.every(c=>t.bowlerLegalBalls[c]===e.bowling[c].legalBalls),"BALL_RECONCILIATION","Bowler quota map mismatch"),nn(t.deliveryAttempts>=t.legalBalls&&e.nextDeliveryIndex>=t.deliveryAttempts&&t.ballAgeLegalBalls<=t.legalBalls,"INVALID_LEDGER","Delivery/ball-age counters inconsistent"),nn(t.bowlerId!==null||e.currentOverRuns===0,"INVALID_LEDGER","No active bowler for unfinished over runs"),t.bowlerId&&nn(t.bowlerId!==e.keeperId&&!e.outfieldIds.includes(t.bowlerId),"INVALID_LEDGER","Bowler cannot occupy keeper/outfield slot"),t.previousOverBowlerId!==null&&nn(Object.hasOwn(e.bowling,t.previousOverBowlerId),"INVALID_LEDGER","Previous bowler absent");for(const c of Object.values(e.batting))nn(_n(c.fours*4,c.sixes*6)<=c.runs,"INVALID_LEDGER","Boundary counters exceed bat runs");for(const c of Object.values(e.bowling))nn(c.maidens<=Math.floor(c.legalBalls/6),"INVALID_LEDGER","Maiden counter exceeds completed overs");return nn(e.rulesId==="LC_RED5_01"?t.allocatedBalls===null&&t.index<=3:t.allocatedBalls===(e.rulesId==="LC_T20_01"?120:300)&&t.index<=1,"INVALID_LEDGER","Unsupported profile allocation/index"),nn(e.rulesId!=="LC_RED5_01"||!t.freeHitPending,"INVALID_LEDGER","Red-ball free hit"),e}function je(n){const e=te(n),t=e.innings;nn(!t.complete,"INNINGS_COMPLETE","No more delivery after completion"),nn(t.northBatterId!==null&&t.southBatterId!==null,"BATTER_REQUIRED","Both ends need selected batters"),nn(t.bowlerId!==null,"BOWLER_REQUIRED","Select a bowler");const i=e.rulesId==="LC_T20_01"?24:e.rulesId==="LC_ODI_01"?60:null;return nn(i===null||e.bowling[t.bowlerId].legalBalls<i,"BOWLER_QUOTA","Active bowler exhausted"),ct.parse({rulesId:e.rulesId,inningsIndex:t.index,deliveryIndex:e.nextDeliveryIndex,battingTeamId:t.battingTeamId,bowlingTeamId:t.bowlingTeamId,strikerId:t.strikerEnd==="NORTH"?t.northBatterId:t.southBatterId,nonStrikerId:t.strikerEnd==="NORTH"?t.southBatterId:t.northBatterId,bowlerId:t.bowlerId,keeperId:e.keeperId,outfieldIds:e.outfieldIds,endsBefore:{north:t.northBatterId,south:t.southBatterId},strikerEnd:t.strikerEnd,runs:t.runs,wickets:t.wickets,legalBalls:t.legalBalls,allocatedBalls:t.allocatedBalls,targetToWin:t.targetToWin,freeHitPending:t.freeHitPending,ballAgeLegalBalls:t.ballAgeLegalBalls})}function Bs(n,e){const t=te(n),i=je(t),a=gh(i,e),o=a.event,r=t.innings,c=t.rulesId==="LC_T20_01"?24:t.rulesId==="LC_ODI_01"?60:null;nn(c===null||t.bowling[o.bowlerId].legalBalls+a.delta.legalBalls<=c,"BOWLER_QUOTA","Bowler quota exceeded"),nn(r.previousOverBowlerId!==o.bowlerId,"CONSECUTIVE_OVERS","Previous over bowler cannot bowl this over");const u=t.batting[o.strikerId],p=t.bowling[o.bowlerId];u.runs=_n(u.runs,a.delta.batterRuns),u.ballsFaced=_n(u.ballsFaced,a.delta.ballsFaced),o.boundary==="FOUR"&&o.batRuns===4&&(u.fours=_n(u.fours,1)),o.boundary==="SIX"&&o.batRuns===6&&(u.sixes=_n(u.sixes,1)),o.dismissal&&(t.batting[o.dismissal.playerId].dismissed=!0,t.dismissals[o.dismissal.playerId]=o.dismissal,r.dismissed.push(o.dismissal.playerId)),p.runsConceded=_n(p.runsConceded,a.delta.bowlerRuns),p.legalBalls=_n(p.legalBalls,a.delta.legalBalls),p.wickets=_n(p.wickets,a.delta.bowlerWickets),t.currentOverRuns=_n(t.currentOverRuns,a.delta.bowlerRuns),a.overCompleted&&(t.currentOverRuns===0&&(p.maidens=_n(p.maidens,1)),t.currentOverRuns=0,r.previousOverBowlerId=o.bowlerId,r.bowlerId=null),r.runs=a.totals.runs,r.wickets=a.totals.wickets,r.legalBalls=a.totals.legalBalls,r.ballAgeLegalBalls=a.totals.ballAgeLegalBalls,r.deliveryAttempts=_n(r.deliveryAttempts,1),r.strikerEnd=a.strikerEndAfter,r.northBatterId=o.endsAfter.north,r.southBatterId=o.endsAfter.south,r.freeHitPending=a.freeHitPending,r.complete=a.inningsComplete;for(const S of["wides","noBalls","byes","legByes","penalties"])r.extras[S]=_n(r.extras[S],o.extras[S]);return r.bowlerLegalBalls[o.bowlerId]=p.legalBalls,t.nextDeliveryIndex=_n(t.nextDeliveryIndex,1),{ledger:te(t),observation:a}}function Ps(n,e){const t=te(n),i=t.innings;return nn(!i.complete,"INNINGS_COMPLETE","Cannot select after completion"),nn(Object.hasOwn(t.batting,e)&&!t.batting[e].dismissed&&![i.northBatterId,i.southBatterId].includes(e),"ILLEGAL_BATTER","Player must be available and not already at an end"),nn(i.northBatterId===null!=(i.southBatterId===null),"ILLEGAL_SELECTION","Exactly one replacement end must be empty"),i.northBatterId===null?i.northBatterId=e:i.southBatterId=e,te(t)}function xs(n,e,t){const i=te(n),a=i.innings;nn(!a.complete,"INNINGS_COMPLETE","Cannot select after completion"),nn(a.northBatterId!==null&&a.southBatterId!==null,"BATTER_REQUIRED","Batter decision has priority"),nn(a.bowlerId===null&&a.legalBalls%6===0,"ILLEGAL_SELECTION","Bowler selection only at an over boundary"),nn(Object.hasOwn(i.bowling,e)&&e!==i.keeperId&&e!==a.previousOverBowlerId,"ILLEGAL_BOWLER","Unknown, keeping or consecutive bowler");const o=i.rulesId==="LC_T20_01"?24:i.rulesId==="LC_ODI_01"?60:null;return nn(o===null||i.bowling[e].legalBalls<o,"BOWLER_QUOTA","Quota exhausted"),a.bowlerId=e,i.outfieldIds=[...t],te(i)}const ph=Object.freeze({EXECUTED_LENGTH:Object.freeze({stageName:"length",drawIndex:0}),LEGALITY:Object.freeze({stageName:"legality",drawIndex:0}),CONTACT:Object.freeze({stageName:"contact",drawIndex:0}),SECTOR:Object.freeze({stageName:"sector",drawIndex:0}),IMMEDIATE_DISMISSAL:Object.freeze({stageName:"dismissal",drawIndex:0}),STUMPING:Object.freeze({stageName:"dismissal",drawIndex:1}),FIELD_CHANCE:Object.freeze({stageName:"fielding",drawIndex:0}),FIELD_CONVERSION:Object.freeze({stageName:"fielding",drawIndex:1}),RUNS:Object.freeze({stageName:"running",drawIndex:0}),RUN_OUT:Object.freeze({stageName:"running",drawIndex:1}),RUN_OUT_END:Object.freeze({stageName:"running",drawIndex:2})}),Fs=ys(),Ih=Be(Xn),hh=["0","1","2","3","4","6"],mi=["YORKER","FULL","GOOD","SHORT"],Hs=10000n;function Ms(n){if(n&&typeof n=="object"&&!Object.isFrozen(n)){for(const e of Object.values(n))Ms(e);Object.freeze(n)}return n}function fh(n,e,t){return n<e?e:n>t?t:n}function gi(n,e){return Number(Dt(BigInt(n)*BigInt(e),Hs))}function de(n){return(n-50)*200}function On(n,e,t=0,i=[],a=!0){return{id:n,baseWeight:e,interceptBp:t,terms:[...i],allowed:a}}function ka(n,e){return n==="RED_BALL"?"RED_BALL":n==="T20"?e<36?"T20_EARLY":e<90?"T20_MIDDLE":"T20_LATE":e<60?"ODI_EARLY":e<240?"ODI_MIDDLE":"ODI_LATE"}function Ba(n){const e=Pe.find(t=>t.rulesId===n);if(!e)throw new Error("UNSUPPORTED_GENERATOR_RULES");return ne(se(e))}function Eh(n){pn(n);const e=Ym.parse(n);if(e.stagePackHash!==Kn||ne(se(on))!==Kn||e.modelHash!==Cn||e.lutHash!==ve||e.stagePackId!==Ir||e.generatorVersion!==ii||e.probabilityVersion!==qn||e.modelId!==le||e.lutVersion!==me||e.randomVersion!==Xn)throw new Error("UNSUPPORTED_GENERATOR_PACK_OR_VERSION");if(e.rulesHash!==Ba(e.context.rulesId))throw new Error("UNSUPPORTED_RULES_HASH");const t=e.context.rulesId==="LC_T20_01"?"T20":e.context.rulesId==="LC_ODI_01"?"ODI":"RED_BALL";if(e.format!==t||e.phase!==ka(t,e.context.legalBalls))throw new Error("INCONSISTENT_FORMAT_OR_PHASE");if(e.attemptOrdinal!==e.context.deliveryIndex)throw new Error("ATTEMPT_ORDINAL_MISMATCH");if(`${e.matchId}:${e.context.inningsIndex}`.length>128)throw new Error("RANDOM_ENTITY_ID_TOO_LONG");if(e.context.bowlerId===e.context.strikerId||e.context.bowlerId===e.context.nonStrikerId||e.context.strikerId===e.context.nonStrikerId||e.context.endsBefore[e.context.strikerEnd==="NORTH"?"north":"south"]!==e.context.strikerId||e.context.endsBefore[e.context.strikerEnd==="NORTH"?"south":"north"]!==e.context.nonStrikerId)throw new Error("INCONSISTENT_BATTER_ENDS");if(e.context.runs>=(e.context.targetToWin??Number.MAX_SAFE_INTEGER)||e.context.allocatedBalls!==(t==="T20"?120:t==="ODI"?300:null)||e.context.allocatedBalls!==null&&e.context.legalBalls>=e.context.allocatedBalls||t==="RED_BALL"&&e.context.freeHitPending||e.context.wickets>=10||e.attemptOrdinal<e.context.legalBalls)throw new Error("INNINGS_NOT_READY_FOR_GENERATOR");const i=e.field.slots.map(a=>a.playerId);if(new Set(i).size!==9||[...i].sort().join("\0")!==[...e.context.outfieldIds].sort().join("\0")||new Set([e.context.strikerId,e.context.nonStrikerId,e.context.bowlerId,e.context.keeperId,...i]).size!==13||e.batting.shotSectorWeights.every(a=>a===0))throw new Error("INVALID_GENERATOR_FIELD_OR_SECTORS");return e}function Sh(n){const i=((!["FAST","MEDIUM"].includes(n.bowling.bowlingStyle)?n.conditions.turnBp:n.conditions.seamBp)-5e3)*2;return fh(de(n.bowling.movementRating)+gi(2500,i)-gi(2500,n.bowling.fatigueBp),-1e4,1e4)}function _h(n){const e=n.bowling.intendedLength,t=mi.indexOf(e),i=new Map([[e,on.length.intended]]),a=[mi[t-1],mi[t+1]].filter(u=>u!==void 0),o=on.length.neighboursTotal/a.length;for(const u of a)i.set(u,(i.get(u)??0)+o);const r=t<2?"FULL_TOSS":"FULL";i.set(r,(i.get(r)??0)+on.length.gross);const c=[{coefficientBp:on.length.intendedControlBp,featureBp:de(n.bowling.controlRating)},{coefficientBp:on.length.intendedFatigueBp,featureBp:n.bowling.fatigueBp}];return[...mi,"FULL_TOSS"].filter(u=>(i.get(u)??0)>0).map(u=>On(u,i.get(u),0,u===e?c:[]))}function vh(n,e,t){const i=dh({phase:n.phase,defenceRating:n.batting.defenceRating,timingRating:n.batting.timingRating,powerRating:n.batting.powerRating,effectiveMovementBp:Sh(n),aggression:n.batting.aggression}),a=de(["FAST","MEDIUM"].includes(n.bowling.bowlingStyle)?n.batting.vsPaceRating:n.batting.vsSpinRating);return i.map(o=>{const r=[];function c(u){r.push({coefficientBp:u,featureBp:1e4})}return e==="YORKER"&&o.id==="MISS"&&c(2e3),e==="YORKER"&&o.id==="AERIAL"&&c(-1e3),e==="FULL_TOSS"&&o.id==="AERIAL"&&c(5e3),e==="FULL_TOSS"&&o.id==="GROUND"&&c(2e3),e==="SHORT"&&(o.id==="AERIAL"||o.id==="EDGE")&&c(1500),(o.id==="MISS"||o.id==="EDGE")&&r.push({coefficientBp:-2e3,featureBp:a}),o.id==="GROUND"&&r.push({coefficientBp:2e3,featureBp:a}),{...o,allowed:!(t&&o.id==="HIT_WICKET"),terms:[...o.terms,...r]}})}function bh(n){return n.batting.shotSectorWeights.map((t,i)=>{const o=(n.bowling.line==="OFF"?i<=2:n.bowling.line==="STUMPS"?i===3||i===4:i>=5)?Number(Dt(BigInt(t)*BigInt(on.sectorLineMultiplierBp),Hs)):t;return On(`SECTOR_${i}`,o)})}function Th(n,e,t){const i=n.field.slots.map(a=>{const o=(a.sector-e+8)%8,r=o===0?1e4:o===1||o===7?on.coverage.neighbourBp:0,c=t==="GROUND"?on.coverage.ground[a.depth]:on.coverage.aerial[a.depth],u=t==="EDGE"?a.role==="SLIP"?1e4:a.role==="GULLY"?6e3:1e3:gi(c,r);return{playerId:a.playerId,coverageBp:u,catchingRating:a.catchingRating,throwingRating:a.throwingRating,role:a.role}});return t==="EDGE"&&i.push({playerId:n.context.keeperId,coverageBp:1e4,catchingRating:n.field.keeper.catchingRating,throwingRating:n.field.keeper.throwingRating,role:"KEEPER"}),i.sort((a,o)=>o.coverageBp-a.coverageBp||(a.playerId<o.playerId?-1:a.playerId>o.playerId?1:0)),i[0]}function Rh(n,e,t){const i=e==="MISS",a=i?on.bowled:on.lbw,o=!t&&(i||n.bowling.line!=="LEG");return[On(i?"BOWLED":"LBW",1,a.interceptBp,[{coefficientBp:a.controlBp,featureBp:de(n.bowling.controlRating)},{coefficientBp:a.defenceBp,featureBp:de(n.batting.defenceRating)},...i&&n.bowling.line==="STUMPS"?[{coefficientBp:on.bowled.stumpsBp,featureBp:1e4}]:[]],o),On("NONE",1)]}function Lh(n,e,t){const i=on.runs[e],a=de(n.batting.timingRating),o=de(n.batting.powerRating),r=de(n.batting.rotationRating);return hh.map((c,u)=>{const p=[];c==="0"&&p.push({coefficientBp:5e3,featureBp:t},{coefficientBp:-3e3,featureBp:r}),c==="1"&&n.batting.intent!=="NORMAL"&&p.push({coefficientBp:n.batting.intent==="ROTATE"?3500:-5e3,featureBp:1e4}),(c==="4"||c==="6")&&p.push({coefficientBp:4e3,featureBp:a},{coefficientBp:5e3,featureBp:o},{coefficientBp:-7e3,featureBp:t});const S=Number(c),h=n.context.targetToWin===null?null:n.context.targetToWin-n.context.runs;return On(c,i[u],0,p,h===null||S<=h||S>=4)})}function Ah(n,e,t,i){const a=n.context.targetToWin===null?null:n.context.targetToWin-n.context.runs-i,o=a===null||t-1<a;return[On("RUN_OUT",1,on.running.interceptBp,[{coefficientBp:on.running.throwingBp,featureBp:de(e.throwingRating)},{coefficientBp:on.running.coverageBp,featureBp:e.coverageBp},{coefficientBp:on.running.rotateBp,featureBp:n.batting.intent==="ROTATE"?1e4:0}],o),On("SAFE",1)]}function Vs(n){const e=Eh(n),t=[],i=new Set;function a(f,R){const F=ph[f],$={seed:e.seed,domain:"MATCH_DELIVERY",entityId:`${e.matchId}:${e.context.inningsIndex}`,eventOrdinal:e.attemptOrdinal,stageName:F.stageName,drawIndex:F.drawIndex},D=JSON.stringify($);if(i.has(D))throw new Error("DUPLICATE_DELIVERY_DRAW_ADDRESS");i.add(D);const G=Fs.normalise({probabilityVersion:qn,modelId:le,modelHash:Cn,lutVersion:me,lutHash:ve,categories:R}),M=Ih.uint32($),q=Cs(G.categories,M);return t.push({stageName:F.stageName,address:$,draw:M,selectedCategoryId:q.id,categories:G.categories}),q.id}const o=a("EXECUTED_LENGTH",_h(e)),r=a("LEGALITY",lh({controlRating:e.bowling.controlRating,fatigueBp:e.bowling.fatigueBp,line:e.bowling.line,effort:e.bowling.effort})),c=e.context,u={wides:0,noBalls:0,byes:0,legByes:0,penalties:0},p={stage:"DELIVERY",legality:r,batRuns:0,extras:u,completedRuns:0,attemptedRuns:0,boundary:"NONE",dismissal:null,endsAfter:{...c.endsBefore},batContact:!1,attemptedStroke:e.batting.attemptedStroke,shotSector:null,trajectory:null,executedLength:o,fieldOutcome:"NONE",elapsedSeconds:on.elapsedSeconds};function S(f){const R=ya(c,f).resolution;return Ms(Zm.parse({kind:"GENERATED_DELIVERY",generatorVersion:ii,modelHash:Cn,stagePackHash:Kn,internalOnly:!0,trace:t,resolution:R}))}if(r==="WIDE"&&(u.wides=1),r==="NO_BALL"&&(u.noBalls=1),(r==="WIDE"||r==="NO_BALL")&&c.targetToWin!==null&&c.runs+1>=c.targetToWin)return S({...p,stage:"IMMEDIATE_PENALTY",batContact:!1,attemptedStroke:!1});const h=r==="NO_BALL"||c.freeHitPending,A=r==="WIDE"?"WIDE":a("CONTACT",vh(e,o,h));if(A==="HIT_WICKET")return p.dismissal={kind:"HIT_WICKET",playerId:c.strikerId,fielderId:null,wicketEnd:c.strikerEnd},p.endsAfter[c.strikerEnd==="NORTH"?"north":"south"]=null,S(p);if(A==="MISS"||A==="PAD"){const f=a("IMMEDIATE_DISMISSAL",Rh(e,A,h));if(f!=="NONE")return p.dismissal={kind:f,playerId:c.strikerId,fielderId:null,wicketEnd:c.strikerEnd},p.endsAfter[c.strikerEnd==="NORTH"?"north":"south"]=null,S(p)}let N={playerId:c.keeperId,coverageBp:0,catchingRating:e.field.keeper.catchingRating,throwingRating:e.field.keeper.throwingRating};if(A==="GROUND"||A==="AERIAL"||A==="EDGE")if(p.batContact=!0,p.trajectory=A,p.shotSector=Number(a("SECTOR",bh(e)).split("_")[1]),N=Th(e,p.shotSector,A),A==="AERIAL"||A==="EDGE")if(!h&&N.coverageBp>0){const f=gi(on.catchOpportunityBp[A],N.coverageBp);if(a("FIELD_CHANCE",[On("CHANCE",f),On("NO_CHANCE",1e4-f)])==="CHANCE"){if(a("FIELD_CONVERSION",[On("CATCH",1,on.catchConversion.interceptBp,[{coefficientBp:on.catchConversion.catchingBp,featureBp:de(N.catchingRating)}]),On("DROP",1)])==="CATCH")return p.fieldOutcome="CATCH",p.dismissal={kind:"CAUGHT",playerId:c.strikerId,fielderId:N.playerId,wicketEnd:c.strikerEnd},p.endsAfter[c.strikerEnd==="NORTH"?"north":"south"]=null,S(p);p.fieldOutcome="DROP"}else p.fieldOutcome=N.coverageBp>0?"STOP":"NONE"}else p.fieldOutcome=N.coverageBp>0?"STOP":"NONE";else p.fieldOutcome=N.coverageBp>0?"STOP":"NONE";const y=A==="WIDE",L=A==="MISS"||A==="PAD",E=y?[On("1",on.runs.WIDE[0]),On("2",on.runs.WIDE[1]),On("5",on.runs.WIDE[2])]:L?[On("0",on.runs.NONE[0]),On("1",on.runs.NONE[1],0,[],A==="MISS"||e.batting.attemptedStroke),On("4",on.runs.NONE[4],0,[],A==="MISS"||e.batting.attemptedStroke)]:Lh(e,A,N.coverageBp),T=c.targetToWin===null?null:c.targetToWin-c.runs-(r==="WIDE"||r==="NO_BALL"?1:0),g=E.map(f=>{const R=Number(f.id),F=y?R===5:L?R===4:R>=4,$=y?R-1:R;return T!==null&&!F&&$>T?{...f,allowed:!1}:f}),I=Number(a("RUNS",g)),_=r==="WIDE"||r==="NO_BALL"?1:0;y?(u.wides=I,I===5?p.boundary="FOUR":p.completedRuns=I-1,p.attemptedStroke=!1):L?(A==="MISS"?u.byes=I:u.legByes=I,I===4?p.boundary="FOUR":p.completedRuns=I):(p.batRuns=I,I>=4?p.boundary=I===4?"FOUR":"SIX":p.completedRuns=I),p.boundary!=="NONE"&&p.fieldOutcome==="STOP"&&(p.fieldOutcome="NONE");const C=!["FAST","MEDIUM"].includes(e.bowling.bowlingStyle);if((A==="MISS"&&r==="LEGAL"||y)&&C&&!h&&e.batting.aggression>2&&p.completedRuns===0&&p.boundary==="NONE"){const f=Fs.normalise({probabilityVersion:qn,modelId:le,modelHash:Cn,lutVersion:me,lutHash:ve,categories:[On("SUCCESS",1,0,[{coefficientBp:1e4,featureBp:de(e.field.keeper.keepingRating)}]),On("FAILURE",1)]}),F=BigInt(f.categories[0].mass)*BigInt(on.stumping.numerator)/BigInt(on.stumping.denominator),$=Number(Dt(F*1000000000n,4294967296n));if(a("STUMPING",[On("STUMPED",$),On("NONE",1e9-$)])==="STUMPED")return p.dismissal={kind:"STUMPED",playerId:c.strikerId,fielderId:c.keeperId,wicketEnd:c.strikerEnd},p.endsAfter[c.strikerEnd==="NORTH"?"north":"south"]=null,S(p)}if(p.completedRuns>0&&p.completedRuns<=3&&p.boundary==="NONE"&&a("RUN_OUT",Ah(e,N,p.completedRuns,_))==="RUN_OUT"){const R=a("RUN_OUT_END",[On("NORTH",1),On("SOUTH",1)]),F=p.completedRuns,$=F-1,D=c.endsBefore.north,G=c.endsBefore.south,M=R==="NORTH"?F%2===0?D:G:F%2===0?G:D,q=M===D?G:D;return p.completedRuns=$,p.attemptedRuns=F,p.fieldOutcome="RUN_OUT",p.dismissal={kind:"RUN_OUT",playerId:M,fielderId:N.playerId,wicketEnd:R},p.endsAfter={north:R==="NORTH"?null:q,south:R==="SOUTH"?null:q},y?u.wides=$+1:A==="MISS"?u.byes=$:A==="PAD"?u.legByes=$:p.batRuns=$,S(p)}return p.attemptedRuns=p.completedRuns,p.completedRuns%2===1&&(p.endsAfter={north:c.endsBefore.south,south:c.endsBefore.north}),S(p)}const $s=new WeakSet,Ws=new WeakSet;function Us(n){return!!n&&typeof n=="object"&&$s.has(n)}const Gs=pn(ee),zs=pn(on),Pa=Pe.find(n=>n.rulesId==="LC_T20_01");if(!Pa)throw new Error("INVALID_SETUP: frozen T20 rule manifest missing");const Oh=pn(Pa),xa=Pe.find(n=>n.rulesId==="LC_ODI_01");if(!xa)throw new Error("INVALID_SETUP: frozen ODI rule manifest missing");const wh=pn(xa),Ks=Pe.find(n=>n.rulesId==="LC_RED5_01");if(!Ks)throw new Error("INVALID_SETUP: frozen red-ball rule manifest missing");pn(Ks);function Y(n,e){if(!n)throw new Error(`INVALID_T20_SETUP: ${e}`)}function Ct(n){if(n!==null&&typeof n=="object"){for(const e of Object.values(n))Ct(e);Object.freeze(n)}return n}function Fa(n,e){Y(n instanceof Uint8Array&&n.byteLength>0,"world bytes missing");const t=ne(n);Y(t===Fn.worldFileSha256,"world file bytes are not the frozen published world");let i;try{i=JSON.parse(new TextDecoder("utf-8",{fatal:!0}).decode(n))}catch{throw new Error("INVALID_T20_SETUP: world bytes are not strict UTF-8 JSON")}const a=QI(i,e);Y(n.byteLength===a.manifest.worldByteLength,"world file length mismatch"),Y(t===a.manifest.worldFileSha256,"world file manifest hash mismatch");const o=ne(se(a.world));return Y(o===a.manifest.worldCanonicalSha256,"canonical world manifest hash mismatch"),Y(o===Fn.worldCanonicalSha256,"published canonical world pin mismatch"),a}function Ha(n,e,t,i=Pa,a=ee,o=on){const r=hr.parse(n),{world:c,manifest:u}=Fa(e,t);Y(r.setup.format==="T20","only T20 setup is supported"),Y(r.setup.worldPackId===c.packId,"wrong world ID"),Y(r.setup.randomId===u.randomId,"unsupported random ID"),Y(r.setup.modelId===u.modelId,"unsupported model ID"),Y(r.setup.rulesId==="LC_T20_01"&&c.rulesIds.includes(r.setup.rulesId),"unsupported T20 rules"),Y(!r.setup.capabilities.limitedOversRain&&!r.setup.capabilities.superOver&&!r.setup.capabilities.injuries&&!r.setup.capabilities.prediction,"unsupported gameplay capability enabled"),Y(r.worldFileSha256===u.worldFileSha256&&r.worldCanonicalSha256===u.worldCanonicalSha256,"setup world hash mismatch"),Y(pn(i)===Oh,"non-pinned T20 rule manifest"),Y(pn(a)===Gs,"non-pinned probability pack"),Y(pn(o)===zs,"non-pinned conditional-delivery stage pack");const p=ne(se(i));Y(r.rulesHash===p,"T20 rules hash mismatch"),Y(r.modelHash===Cn&&r.modelHash===u.modelHash,"probability model hash mismatch"),Y(r.stagePackHash===Kn&&r.stagePackHash===u.stagePackHash,"stage pack hash mismatch"),Y(i.format==="T20"&&i.allocatedBalls===120&&i.bowlerMaxBalls===24&&o.noLiveMatchOrCalibration,"T20 setup cannot enable unsupported game rules or live play"),Y(new Set(r.setup.teamIds).size===2,"teams must differ"),Y(r.selectedTeams.every((E,T)=>E.teamId===r.setup.teamIds[T]),"selection order must equal match team order");const S=new Map(c.players.map(E=>[E.playerId,E])),h=r.selectedTeams.map(E=>{const T=c.teams.find(_=>_.teamId===E.teamId);Y(!!T,`unknown team ${E.teamId}`),Y(new Set(E.playerIds).size===11,`duplicate player in XI ${E.teamId}`);const g=new Set(T.squadIds);Y(E.playerIds.every(_=>g.has(_)&&S.has(_)),`XI player not in own squad ${E.teamId}`),Y(E.playerIds.includes(E.captainId),`captain not selected ${E.teamId}`),Y(E.playerIds.includes(E.keeperId),`keeper not selected ${E.teamId}`);const I=E.playerIds.map(_=>S.get(_));return Y(I.find(_=>_.playerId===E.keeperId)?.role==="KEEPER",`designated keeper ineligible ${E.teamId}`),Y(I.filter(mt).length>=5,`XI lacks five bowling-capable players ${E.teamId}`),Ct({teamId:T.teamId,name:T.name,playerIds:[...E.playerIds],xi:I.map(_=>structuredClone(_)),captainId:E.captainId,keeperId:E.keeperId})}),A=h.flatMap(E=>E.playerIds);Y(new Set(A).size===22,"teams cannot share XI players");const N=c.grounds.find(E=>E.groundId===r.setup.groundId);Y(!!N,"unknown match ground");const y={schema:"1.0.0",engine:"LC_T20_SETUP_V1",random:u.randomId,rules:r.setup.rulesId,rulesHash:p,model:u.modelId,modelHash:Cn,worldHash:u.worldCanonicalSha256},L=Ct({setupVersion:"LC_T20_SETUP_V1",gameId:r.setup.gameId,matchId:r.setup.matchId,seed:r.setup.seed,format:"T20",teams:h,ground:structuredClone(N),versions:y,stagePackHash:Kn,modelStatus:"SYNTHETIC_ALPHA",worldSeed:u.worldSeed,fixtureOnly:!0});return $s.add(L),L}function Nh(n){return!!n&&typeof n=="object"&&Ws.has(n)}function Dh(n,e,t,i=xa,a=ee,o=on){const r=qm.parse(n),{world:c,manifest:u}=Fa(e,t);Y(r.setup.format==="ODI","only ODI setup is supported"),Y(r.setup.worldPackId===c.packId,"wrong world ID"),Y(r.setup.randomId===u.randomId,"unsupported random ID"),Y(r.setup.modelId===u.modelId,"unsupported model ID"),Y(r.setup.rulesId==="LC_ODI_01"&&c.rulesIds.includes(r.setup.rulesId),"unsupported ODI rules"),Y(!r.setup.capabilities.limitedOversRain&&!r.setup.capabilities.superOver&&!r.setup.capabilities.injuries&&!r.setup.capabilities.prediction,"unsupported gameplay capability enabled"),Y(r.worldFileSha256===u.worldFileSha256&&r.worldCanonicalSha256===u.worldCanonicalSha256,"setup world hash mismatch"),Y(pn(i)===wh,"non-pinned ODI rule manifest"),Y(pn(a)===Gs,"non-pinned probability pack"),Y(pn(o)===zs,"non-pinned conditional-delivery stage pack");const p=ne(se(i));Y(r.rulesHash===p,"ODI rules hash mismatch"),Y(r.modelHash===Cn&&r.modelHash===u.modelHash,"probability model hash mismatch"),Y(r.stagePackHash===Kn&&r.stagePackHash===u.stagePackHash,"stage pack hash mismatch"),Y(i.format==="ODI"&&i.allocatedBalls===300&&i.bowlerMaxBalls===60&&o.noLiveMatchOrCalibration,"ODI setup cannot enable unsupported game rules or live play"),Y(new Set(r.setup.teamIds).size===2,"teams must differ"),Y(r.selectedTeams.every((E,T)=>E.teamId===r.setup.teamIds[T]),"selection order must equal match team order");const S=new Map(c.players.map(E=>[E.playerId,E])),h=r.selectedTeams.map(E=>{const T=c.teams.find(_=>_.teamId===E.teamId);Y(!!T,`unknown team ${E.teamId}`),Y(new Set(E.playerIds).size===11,`duplicate player in XI ${E.teamId}`);const g=new Set(T.squadIds);Y(E.playerIds.every(_=>g.has(_)&&S.has(_)),`XI player not in own squad ${E.teamId}`),Y(E.playerIds.includes(E.captainId),`captain not selected ${E.teamId}`),Y(E.playerIds.includes(E.keeperId),`keeper not selected ${E.teamId}`);const I=E.playerIds.map(_=>S.get(_));return Y(I.find(_=>_.playerId===E.keeperId)?.role==="KEEPER",`designated keeper ineligible ${E.teamId}`),Y(I.filter(mt).length>=5,`XI lacks five bowling-capable players ${E.teamId}`),Ct({teamId:T.teamId,name:T.name,playerIds:[...E.playerIds],xi:I.map(_=>structuredClone(_)),captainId:E.captainId,keeperId:E.keeperId})}),A=h.flatMap(E=>E.playerIds);Y(new Set(A).size===22,"teams cannot share XI players");const N=c.grounds.find(E=>E.groundId===r.setup.groundId);Y(!!N,"unknown match ground");const y={schema:"1.0.0",engine:"LC_ODI_SETUP_V1",random:u.randomId,rules:r.setup.rulesId,rulesHash:p,model:u.modelId,modelHash:Cn,worldHash:u.worldCanonicalSha256},L=Ct({setupVersion:"LC_ODI_SETUP_V1",gameId:r.setup.gameId,matchId:r.setup.matchId,seed:r.setup.seed,format:"ODI",teams:h,ground:structuredClone(N),versions:y,stagePackHash:Kn,modelStatus:"SYNTHETIC_ALPHA",worldSeed:u.worldSeed,fixtureOnly:!0});return Ws.add(L),L}const Ch=Nn(),yh=Be(),vn=n=>Ch.hash(n),be=n=>structuredClone(n),pi=n=>{throw new Error(`LC_T20_${n}`)};function W(n,e){n||pi(e)}const Ys=vn(Nt),kh=Ys,Bh={line:"STUMPS",length:"GOOD",variationId:"stock",effort:"NORMAL"};function yt(n,e){const t=n.setup.teams.find(i=>i.teamId===e);return W(t,"UNKNOWN_TEAM"),t}function Te(n,e){const t=n.setup.teams.flatMap(i=>i.xi).find(i=>i.playerId===e);return W(t,"UNKNOWN_PLAYER"),t}function kt(n,e){const t=n.setup.teams.find(i=>i.teamId!==e);return W(t,"UNKNOWN_OPPONENT"),t.teamId}function yn(n){const e=n.core.innings[n.core.activeInningsIndex];return W(e,"NO_ACTIVE_INNINGS"),e}function Ma(n){return yt(n,yn(n).innings.battingTeamId)}function Ze(n){return yt(n,yn(n).innings.bowlingTeamId)}function js(n){const e=di.positions.find(t=>t.slotId===n);return W(e,"UNKNOWN_FIELD_POSITION"),e}function Ph(n,e){const t=e<36?wa:Na;return[...n].sort().map((i,a)=>({slotId:t[a],playerId:i}))}function gt(n,e,t,i){W(n.length===9&&new Set(n.map(c=>c.playerId)).size===9&&new Set(n.map(c=>c.slotId)).size===9,"INVALID_FIELD_DUPLICATES"),W([...n.map(c=>c.playerId)].sort().join("|")===[...e].sort().join("|"),"INVALID_FIELD_IDENTITIES");const a=n.map(c=>js(c.slotId)),o=a.filter(c=>t==="R"?c.legSide:!c.legSide),r=a.filter(c=>!c.insideCircle).length;W(r<=(i<36?2:5),"INVALID_FIELD_POWERPLAY"),W(o.length<=5,"INVALID_FIELD_LEG_SIDE"),W(o.filter(c=>c.behindSquare).length<=2,"INVALID_FIELD_BEHIND_SQUARE")}function xh(n,e,t){const i=yt(n,e),a=yt(n,kt(n,e)),o=Object.fromEntries(i.playerIds.map(p=>[p,{runs:0,ballsFaced:0,fours:0,sixes:0,dismissed:!1}])),r=Object.fromEntries(a.playerIds.map(p=>[p,{runsConceded:0,legalBalls:0,wickets:0,maidens:0}])),c=Object.fromEntries(a.playerIds.map(p=>[p,0])),u=a.playerIds.filter(p=>p!==a.keeperId).slice(0,9);return te({engineVersion:Rt,rulesId:"LC_T20_01",nextDeliveryIndex:n.core.globalAttemptOrdinal,batting:o,bowling:r,dismissals:{},keeperId:a.keeperId,outfieldIds:u,currentOverRuns:0,innings:{index:t,battingTeamId:e,bowlingTeamId:a.teamId,runs:0,wickets:0,legalBalls:0,deliveryAttempts:0,targetToWin:t===1?n.core.innings[0].innings.runs+1:null,allocatedBalls:120,extras:{wides:0,noBalls:0,byes:0,legByes:0,penalties:0},northBatterId:null,southBatterId:null,strikerEnd:"NORTH",battingOrder:[...i.playerIds],dismissed:[],bowlerId:null,previousOverBowlerId:null,bowlerLegalBalls:c,freeHitPending:!1,ballAgeLegalBalls:0,complete:!1}})}function Fh(n){return W(Us(n)&&Object.isFrozen(n)&&n.setupVersion==="LC_T20_SETUP_V1"&&n.teams.length===2&&n.fixtureOnly,"INVALID_FROZEN_SETUP"),W(n.versions.worldHash===Fn.worldCanonicalSha256&&n.versions.modelHash===Cn&&n.stagePackHash===Kn&&n.versions.rulesHash===Ba("LC_T20_01")&&n.versions.random===Xn&&n.versions.rules==="LC_T20_01","UNSUPPORTED_PINNED_SETUP"),Er.parse({engine:fr,eventChain:oe,conditionPolicy:Ui,conditionPolicyHash:Ys,setupHash:vn(n),worldHash:n.versions.worldHash,rulesHash:n.versions.rulesHash,modelHash:n.versions.modelHash,stagePackHash:n.stagePackHash,randomVersion:Xn,scoringVersion:Rt,probabilityVersion:qn})}function Ii(n){const e=Fh(n),t=vn(n),i={phase:"SETUP",setupHash:t,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:be(n.ground.pitchPrior),fatigueBp:Object.fromEntries(n.teams.flatMap(o=>o.playerIds).map(o=>[o,0]))},a=vn([oe,t,vn(e)]);return{setup:n,executionManifest:e,core:i,revision:0,events:[],receipts:{},commands:[],genesisHash:a,lastEventHash:a}}function Hh(n,e,t){const i=Te(n,e.bowlerId),o=!["FAST","MEDIUM"].includes(i.bowlingStyle??"")?12:20,r=Nt.effortFactorBp[t],c=Math.floor((o*r+5e3)/1e4);if(n.core.fatigueBp[e.bowlerId]=Math.min(1e4,n.core.fatigueBp[e.bowlerId]+c),e.legalBall){const u=be(n.core.pitch);u.wearPoints+=1,u.wearPoints%100===0&&(u.turnBp=Math.min(1e4,u.turnBp+20),u.variabilityBp=Math.min(1e4,u.variabilityBp+10),u.seamBp=Math.max(0,u.seamBp-10)),n.core.pitch=u}}function Zs(n,e,t){const i=n.core;switch(e){case"TEAMS_CONFIRMED":W(i.phase==="SETUP","WRONG_PHASE"),i.phase="TOSS";break;case"TOSS_RESOLVED":W(i.phase==="TOSS","WRONG_PHASE"),W(yt(n,t.winnerId),"INVALID_TOSS"),i.tossWinnerId=t.winnerId,i.tossCallerId=t.callerId,i.phase="AWAITING_INNINGS";break;case"INNINGS_STARTED":{const a=t.inningsIndex,o=t.battingTeamId;W(i.phase==="AWAITING_INNINGS"||i.phase==="INTERVAL","WRONG_PHASE"),W(a===i.innings.length&&a<2,"INNINGS_ORDER"),a===0?i.battingFirstId=o:W(kt(n,i.battingFirstId)===o,"INNINGS_ORDER");const r=xh(n,o,a);i.innings.push(r),i.activeInningsIndex=a,i.fieldSlots=[],i.bowlingPlan=null,i.phase="AWAITING_BATTER";break}case"BATTER_SELECTED":{W(i.phase==="AWAITING_BATTER","WRONG_PHASE");const a=yn(n),o=t.playerId;if(W(Ma(n).playerIds.includes(o),"INVALID_BATTER_TEAM"),a.innings.northBatterId===null&&a.innings.southBatterId===null){W(!a.batting[o].dismissed,"DISMISSED_BATTER");const c=be(a);c.innings.northBatterId=o,i.innings[i.activeInningsIndex]=te(c)}else i.innings[i.activeInningsIndex]=Ps(a,o);const r=yn(n).innings;i.phase=r.northBatterId===null||r.southBatterId===null?"AWAITING_BATTER":r.bowlerId===null?"AWAITING_BOWLER":"READY";break}case"BOWLER_SELECTED":{W(i.phase==="AWAITING_BOWLER","WRONG_PHASE");const a=yn(n),o=t.playerId;W(Ze(n).playerIds.includes(o)&&Te(n,o).bowlingStyle!==null,"INELIGIBLE_BOWLER");const r=Ze(n).playerIds.filter(u=>u!==Ze(n).keeperId&&u!==o);i.innings[i.activeInningsIndex]=xs(a,o,r),i.bowlingPlan={...Bh,bowlerId:o},i.fieldSlots=Ph(r,a.innings.legalBalls);const c=je(yn(n)).strikerId;gt(i.fieldSlots,r,Te(n,c).batHand,a.innings.legalBalls),i.phase="READY";break}case"FIELD_CHANGED":{W(i.phase==="READY","WRONG_PHASE");const a=yn(n),o=je(a).strikerId,r=t.fieldSlots;gt(r,a.outfieldIds,Te(n,o).batHand,a.innings.legalBalls),i.fieldSlots=be(r);break}case"BATTING_PLAN_CHANGED":{W(i.phase==="READY","WRONG_PHASE");const a=t.playerId;W([yn(n).innings.northBatterId,yn(n).innings.southBatterId].includes(a),"BATTER_NOT_ACTIVE"),i.battingPlans[a]={aggression:t.aggression,intent:t.intent};break}case"BOWLING_PLAN_CHANGED":{W(i.phase==="READY","WRONG_PHASE"),W(t.bowlerId===yn(n).innings.bowlerId,"BOWLER_NOT_ACTIVE"),W(t.variationId==="stock","UNSUPPORTED_VARIATION"),i.bowlingPlan=be(t);break}case"DELIVERY_RECORDED":{W(i.phase==="READY","WRONG_PHASE");const a=yn(n),o=t.event;W(t.attemptOrdinal===i.globalAttemptOrdinal&&o.deliveryIndex===i.globalAttemptOrdinal,"GLOBAL_ATTEMPT_MISMATCH"),gt(i.fieldSlots,a.outfieldIds,Te(n,je(a).strikerId).batHand,a.innings.legalBalls);const r=Bs(a,o);i.innings[i.activeInningsIndex]=r.ledger,i.globalAttemptOrdinal++,Hh(n,o,i.bowlingPlan.effort),r.observation.result&&(i.result=r.observation.result),r.observation.inningsComplete?i.phase="INTERVAL":r.observation.requiredBatterEnd?i.phase="AWAITING_BATTER":r.observation.overCompleted?i.phase="AWAITING_BOWLER":i.phase="READY";break}case"OVER_COMPLETED":{W(yn(n).innings.legalBalls%6===0,"INVALID_OVER_MARKER");const a=t.bowlerId;W(yn(n).innings.previousOverBowlerId===a,"OVER_BOWLER_MISMATCH");for(const o of Ze(n).playerIds)o!==a&&(i.fatigueBp[o]=Math.max(0,i.fatigueBp[o]-15));break}case"INNINGS_COMPLETED":W(yn(n).innings.complete,"INVALID_INNINGS_MARKER"),i.phase=i.activeInningsIndex===0?"INTERVAL":i.phase;break;case"MATCH_COMPLETED":W(i.activeInningsIndex===1&&yn(n).innings.complete&&i.result!==null,"INVALID_RESULT_MARKER"),i.phase="COMPLETE";break;default:pi("UNKNOWN_EVENT")}}function ie(n,e,t,i){Zs(n,t,i);const a=n.events.length+1,o=n.lastEventHash,r=vn(n.core),c=vn([oe,a,e,t,i,o,r]),u=ai.parse({version:oe,sequence:a,commandId:e,type:t,payload:i,previousHash:o,stateHash:r,eventHash:c});n.events.push(u),n.lastEventHash=c}function Mh(n){const e=yn(n),t=je(e),i=Te(n,t.strikerId),a=Te(n,t.bowlerId),o=Te(n,t.keeperId),r=i.skills.T20,c=a.skills.T20;gt(n.core.fieldSlots,e.outfieldIds,i.batHand,e.innings.legalBalls);const u={kind:"GENERATE_DELIVERY",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:Kn,randomVersion:Xn,probabilityVersion:qn,modelId:le,modelHash:Cn,lutVersion:me,lutHash:ve,rulesHash:n.setup.versions.rulesHash,matchId:n.setup.matchId,seed:n.setup.seed,attemptOrdinal:n.core.globalAttemptOrdinal,format:"T20",phase:ka("T20",e.innings.legalBalls),context:t,bowling:{bowlingStyle:a.bowlingStyle,controlRating:c.control,movementRating:c.movement,fatigueBp:n.core.fatigueBp[a.playerId],line:n.core.bowlingPlan.line,intendedLength:n.core.bowlingPlan.length,effort:n.core.bowlingPlan.effort,variationId:"stock"},batting:{defenceRating:r.defence,timingRating:r.timing,powerRating:r.power,rotationRating:r.rotation,vsPaceRating:r.vsPace,vsSpinRating:r.vsSpin,aggression:n.core.battingPlans[i.playerId]?.aggression??2,intent:n.core.battingPlans[i.playerId]?.intent??"NORMAL",attemptedStroke:!0,shotSectorWeights:[...i.shotSectorWeights]},conditions:{seamBp:n.core.pitch.seamBp,turnBp:n.core.pitch.turnBp},field:{keeper:{keepingRating:o.skills.T20.keeping,catchingRating:o.skills.T20.catching,throwingRating:o.skills.T20.throwing},slots:n.core.fieldSlots.map(h=>{const A=Te(n,h.playerId),N=js(h.slotId);return{playerId:h.playerId,sector:N.sector,depth:N.depth,role:h.slotId.startsWith("slip")?"SLIP":"NORMAL",catchingRating:A.skills.T20.catching,throwingRating:A.skills.T20.throwing}})}},p=Vs(u);return{event:ks(t,p.resolution),traceHash:vn(p.trace)}}function Vh(n,e,t,i){const a=n.core.globalAttemptOrdinal;ie(n,e,"DELIVERY_RECORDED",{type:"DELIVERY_RECORDED",event:t,attemptOrdinal:a,traceHash:i});const o=yn(n);t.legalBall&&o.innings.legalBalls%6===0&&ie(n,e,"OVER_COMPLETED",{type:"OVER_COMPLETED",bowlerId:t.bowlerId}),o.innings.complete&&(ie(n,e,"INNINGS_COMPLETED",{type:"INNINGS_COMPLETED",inningsIndex:n.core.activeInningsIndex}),n.core.activeInningsIndex===1?ie(n,e,"MATCH_COMPLETED",{type:"MATCH_COMPLETED",result:n.core.result}):ie(n,e,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:1,battingTeamId:kt(n,o.innings.battingTeamId)}))}function $h(n,e,t){W(n.core.phase==="READY","WRONG_PHASE");const i=Math.floor(yn(n).innings.legalBalls/6);let a=0;for(;n.core.phase==="READY"&&a<60;){const{event:o,traceHash:r}=Mh(n);Vh(n,e,o,r),a++;const c=yn(n);if(t==="DELIVERY"||Math.floor(c.innings.legalBalls/6)!==i)break}W(a<60,"ADVANCE_ATTEMPT_LIMIT")}function Bt(n,e){const t=Sr.parse(e),i=n.receipts[t.commandId];if(i)return{session:n,receipt:i};W(t.expectedRevision===n.revision,"STALE_REVISION");const a={...n,core:be(n.core),events:[...n.events],receipts:{...n.receipts},commands:[...n.commands]},o=a.events.length+1,r=t.commandId,c=p=>{W(a.setup.teams.some(S=>S.teamId===p),"ACTOR_TEAM_UNKNOWN"),W(t.actorId===`USER:${p}`||t.actorId===`AI:${p}`||t.actorId==="SYSTEM","ACTOR_UNAUTHORISED")};switch(t.kind){case"CONFIRM_TEAMS":W(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),ie(a,r,"TEAMS_CONFIRMED",{type:"TEAMS_CONFIRMED"});break;case"CALL_TOSS":{c(t.payload.teamId),W(a.core.phase==="TOSS","WRONG_PHASE");const p=yh.uint32({seed:a.setup.seed,domain:"TOSS",entityId:a.setup.matchId,eventOrdinal:0,stageName:"coin",drawIndex:0})%2===0?"HEADS":"TAILS",S=t.payload.call===p?t.payload.teamId:kt(a,t.payload.teamId);ie(a,r,"TOSS_RESOLVED",{type:"TOSS_RESOLVED",callerId:t.payload.teamId,winnerId:S,call:t.payload.call,coin:p});break}case"CHOOSE_INNINGS":{c(t.payload.teamId),W(t.payload.teamId===a.core.tossWinnerId,"NOT_TOSS_WINNER"),W(a.core.phase==="AWAITING_INNINGS","WRONG_PHASE");const p=t.payload.choice==="BAT"?t.payload.teamId:kt(a,t.payload.teamId);ie(a,r,"INNINGS_STARTED",{type:"INNINGS_STARTED",inningsIndex:0,battingTeamId:p});break}case"SET_BATTER":c(t.payload.teamId),W(a.core.phase==="AWAITING_BATTER"&&t.payload.teamId===Ma(a).teamId,"WRONG_TEAM_OR_PHASE"),ie(a,r,"BATTER_SELECTED",{type:"BATTER_SELECTED",playerId:t.payload.playerId});break;case"SET_BOWLER":c(t.payload.teamId),W(a.core.phase==="AWAITING_BOWLER"&&t.payload.teamId===Ze(a).teamId,"WRONG_TEAM_OR_PHASE"),ie(a,r,"BOWLER_SELECTED",{type:"BOWLER_SELECTED",playerId:t.payload.bowlerId});break;case"SET_FIELD":c(t.payload.teamId),W(a.core.phase==="READY"&&t.payload.teamId===Ze(a).teamId,"WRONG_TEAM_OR_PHASE"),ie(a,r,"FIELD_CHANGED",{type:"FIELD_CHANGED",fieldSlots:t.payload.fieldSlots});break;case"SET_BATTING_PLAN":{const p=Ma(a);c(p.teamId),ie(a,r,"BATTING_PLAN_CHANGED",{type:"BATTING_PLAN_CHANGED",...t.payload});break}case"SET_BOWLING_PLAN":{const p=Ze(a);c(p.teamId),ie(a,r,"BOWLING_PLAN_CHANGED",{type:"BOWLING_PLAN_CHANGED",...t.payload});break}case"ADVANCE":W(t.actorId==="SYSTEM","ACTOR_UNAUTHORISED"),$h(a,r,t.payload.scope);break;default:pi("UNKNOWN_COMMAND")}W(a.events.length>=o,"COMMAND_WITH_NO_EVENT"),a.revision=n.revision+1;const u=Jm.parse({commandId:r,committedRevision:a.revision,fromSequence:o,toSequence:a.events.length,lastEventHash:a.lastEventHash});return a.receipts[r]=u,a.commands.push(t),{session:a,receipt:u}}function Wh(n,e,t){return Xs(Ii(n),e,t)}function Xs(n,e,t){W(n.revision===0&&n.events.length===0&&n.core.phase==="SETUP","REPLAY_INITIAL_STATE");for(const[i,a]of e.entries()){const o=ai.parse(a);W(o.sequence===i+1&&o.previousHash===n.lastEventHash,"REPLAY_CHAIN_GAP"),W(o.eventHash===vn([oe,o.sequence,o.commandId,o.type,o.payload,o.previousHash,o.stateHash]),"REPLAY_EVENT_HASH"),Zs(n,o.type,o.payload),o.stateHash!==vn(n.core)&&pi("REPLAY_STATE_HASH"),n.events.push(o),n.lastEventHash=o.eventHash}if(t){const i=Lt.parse(t);W(i.version===oe&&i.genesisHash===n.genesisHash&&i.finalEventHash===n.lastEventHash&&i.finalStateHash===vn(n.core)&&i.eventCount===e.length&&i.executionManifestHash===vn(n.executionManifest),"REPLAY_MANIFEST_MISMATCH")}return n}function qs(n){return Lt.parse({version:oe,genesisHash:n.genesisHash,finalEventHash:n.lastEventHash,finalStateHash:vn(n.core),eventCount:n.events.length,executionManifestHash:vn(n.executionManifest)})}function Uh(n){let e=Ii(n.setup);for(const t of n.commands)e=Bt(e,t).session;W(e.events.length===n.events.length,"RESIMULATION_LENGTH");for(let t=0;t<n.events.length;t++)W(ne(se(e.events[t]))===ne(se(n.events[t])),`RESIMULATION_MISMATCH_${t}`);W(vn(e.core)===vn(n.core),"RESIMULATION_FINAL_STATE")}function hi(n){W(n.core.phase==="COMPLETE"&&n.core.innings.length===2&&n.core.result,"SCORECARD_NOT_COMPLETE");const e=n.core.innings.map((t,i)=>{te(t);const a=n.events.filter(p=>p.type==="DELIVERY_RECORDED"&&p.payload.event.inningsIndex===i);let o=0,r=0;const c=[];for(const p of a){const S=p.payload.event;o+=S.batRuns+Object.values(S.extras).reduce((h,A)=>h+A,0),r+=Number(S.legalBall),S.dismissal&&c.push({playerId:S.dismissal.playerId,runs:o,legalBalls:r,sequence:p.sequence})}W(o===t.innings.runs&&r===t.innings.legalBalls&&a.length===t.innings.deliveryAttempts,"PROJECTED_SCORE_MISMATCH");const u=t.innings;return{battingTeamId:u.battingTeamId,bowlingTeamId:u.bowlingTeamId,runs:u.runs,wickets:u.wickets,legalBalls:u.legalBalls,overs:`${Math.floor(u.legalBalls/6)}.${u.legalBalls%6}`,extras:be(u.extras),batting:be(t.batting),bowling:be(t.bowling),fallOfWickets:c,targetToWin:u.targetToWin}});return Gi.parse({matchId:n.setup.matchId,innings:e,result:n.core.result})}function Gh(n,e,t){W(!!n&&typeof n=="object"&&!Array.isArray(n),"SAVE_SHAPE");const i=n,a=i.setup;W(!!a&&a.setupVersion==="LC_T20_SETUP_V1","SAVE_SETUP"),W(Array.isArray(a.teams)&&a.teams.length===2,"SAVE_TEAMS");const o=Ha({setupVersion:"LC_T20_SETUP_V1",setup:{schemaVersion:"1.0.0",gameId:a.gameId,matchId:a.matchId,format:"T20",worldPackId:Fn.worldPackId,rulesId:a.versions.rules,modelId:a.versions.model,randomId:a.versions.random,seed:a.seed,teamIds:a.teams.map(c=>c.teamId),groundId:a.ground.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:Fn.worldFileSha256,worldCanonicalSha256:a.versions.worldHash,rulesHash:a.versions.rulesHash,modelHash:a.versions.modelHash,stagePackHash:a.stagePackHash,selectedTeams:a.teams.map(c=>({teamId:c.teamId,playerIds:[...c.playerIds],captainId:c.captainId,keeperId:c.keeperId}))},e,t);W(Array.isArray(i.commands),"SAVE_COMMANDS");let r=Ii(o);for(const c of i.commands)r=Bt(r,c).session;return W(typeof i.revision=="number"&&r.revision===i.revision,"SAVE_REVISION"),W(Array.isArray(i.events)&&vn(r.events)===vn(i.events),"SAVE_EVENTS"),W(i.core!==void 0&&vn(r.core)===vn(i.core),"SAVE_CORE"),W(i.receipts!==void 0&&vn(r.receipts)===vn(i.receipts),"SAVE_RECEIPTS"),W(i.executionManifest!==void 0&&vn(r.executionManifest)===vn(i.executionManifest),"SAVE_MANIFEST"),W(i.genesisHash===r.genesisHash&&i.lastEventHash===r.lastEventHash,"SAVE_CHAIN"),r}const zh=Nn();Be();const Kh=n=>zh.hash(n),Yh=n=>{throw new Error(`LC_ODI_${n}`)};function pt(n,e){n||Yh(e)}Kh(Os);function jh(n){const e=Ls.positions.find(t=>t.slotId===n);return pt(e,"UNKNOWN_FIELD_POSITION"),e}function Zh(n,e,t,i){pt(n.length===9&&new Set(n.map(c=>c.playerId)).size===9&&new Set(n.map(c=>c.slotId)).size===9,"INVALID_FIELD_DUPLICATES"),pt([...n.map(c=>c.playerId)].sort().join("|")===[...e].sort().join("|"),"INVALID_FIELD_IDENTITIES");const a=n.map(c=>jh(c.slotId)),o=a.filter(c=>t==="R"?c.legSide:!c.legSide),r=a.filter(c=>!c.insideCircle).length;pt(r<=(i<60?2:i<240?4:5),"INVALID_FIELD_POWERPLAY"),pt(o.length<=5,"INVALID_FIELD_LEG_SIDE"),pt(o.filter(c=>c.behindSquare).length<=2,"INVALID_FIELD_BEHIND_SQUARE")}const Xh=Nn().hash;Be(),Xh(Nt),Nn(),Nn(),new Set(eh),new Map(Object.entries(nh).flatMap(([n,e])=>e.map(t=>[t,n]))),Nn();function Js(n,e){if(!n)throw new Error(`LC_T20_OFFSCREEN_${e}`)}function qh(n){const{seasonId:e,fixtureId:t,matchId:i,matchDayDate:a,session:o}=n;Js(o.core.phase==="COMPLETE","CONDITION_DELTA_REQUIRES_COMPLETE_MATCH"),Js(o.setup.matchId===i,"CONDITION_DELTA_MATCH_ID_MISMATCH");const r=o.setup.teams.flatMap(u=>[...u.playerIds]).sort(),c=Object.fromEntries(r.map(u=>[u,o.core.fatigueBp[u]??0]).filter(([,u])=>u>0));return Zi.parse({deltaVersion:"LC_T20_MATCH_CONDITION_DELTA_V1",matchCompletionKey:`complete-${e}-${t}`,matchId:i,matchDayDate:a,playerFatigueDeltaBp:c})}const Qs=Object.fromEntries(Object.keys(at.shape).map(n=>[n,50]));function Jh(n,e,t){if(new TextEncoder().encode(n).byteLength>Pr)throw new Error("Roster import exceeds 25 MB.");const i=Ug.parse(JSON.parse(n)),a=Nn().hash(i),o=[],r=i.world.players.map(h=>{const A={},N={};for(const y of aa){const L=h.skills?.[y]??{},E=Object.keys(Qs).filter(g=>!(g in L)),T=h.exposureBalls?.[y]===void 0;(E.length||T)&&o.push({playerId:h.playerId,format:y,fields:E,exposureMissing:T}),A[y]=at.parse({...Qs,...L}),N[y]=h.exposureBalls?.[y]??0}return{...h,skills:A,exposureBalls:N,provenance:{kind:"USER_SUPPLIED",sourceId:i.sourceId,sourceHash:a,confidenceBp:1e3}}}),c=Vi({...i.world,packId:`world-import-${a}`,provenance:`User-supplied roster ${i.sourceId}; source ${a}`,players:r},t,e);if([...c.players,...c.teams,...c.grounds].map(h=>h.name).some(h=>h!==h.trim()||[...h].some(A=>{const N=A.codePointAt(0);return N<32||N>=127&&N<=159})))throw new Error("Names cannot contain control characters or surrounding spaces.");const p=new Map(c.players.map(h=>[h.playerId,h])),S=new Set;for(const h of c.teams){const A=h.squadIds.map(N=>p.get(N));if(!A.some(N=>N.role==="KEEPER")||A.filter(N=>N.bowlingStyle!==null&&["BOWLER","ALLROUNDER"].includes(N.role)).length<5)throw new Error(`Roster cannot form a valid XI: ${h.teamId}`);for(const N of A){if(S.has(N.playerId))throw new Error(`Player belongs to multiple squads: ${N.playerId}`);S.add(N.playerId)}}if(S.size!==c.players.length)throw new Error("Every imported player must belong to one squad.");return{world:c,sourceHash:a,priorFields:o}}const Va=new WeakMap,nc=new WeakMap,ec=new Map;function Qh(n,e){return`${n.join(",")}|${e.join(",")}`}function n1(n,e){$a(n);let t=Va.get(n);return t||(t=new Set,Va.set(n,t)),t.add(e),n}function e1(n,e,t){return Se.parse({version:"LC_STAGED_ROSTER_PACK_V1",sourceText:n,...Jh(n,e,t)})}function t1(n,e,t){const i=Qh(e,t);if(n!==null&&typeof n=="object"&&Object.isFrozen(n)&&Va.get(n)?.has(i))return n;const a=Se.parse(n),o=e1(a.sourceText,e,t);if(pn(a)!==pn(o))throw new Error("Roster pack contents do not match the staged source and priors.");return n1(a,i)}function i1(n,e,t,i){const a=t1(n,t,i),o=Fr.parse(e);if(!a.world.grounds.some(u=>u.groundId===o.groundId))throw new Error("Unknown match ground.");if(o.teams[0].teamId===o.teams[1].teamId)throw new Error("Match teams must differ.");const r=new Map(a.world.players.map(u=>[u.playerId,u])),c=new Set;for(const u of o.teams){const p=a.world.teams.find(S=>S.teamId===u.teamId);if(!p||new Set(u.playerIds).size!==11||u.playerIds.some(S=>!p.squadIds.includes(S)))throw new Error("Invalid team or XI membership.");if(!u.playerIds.includes(u.captainId)||!u.playerIds.includes(u.keeperId)||r.get(u.keeperId)?.role!=="KEEPER")throw new Error("Select an eligible captain and keeper.");if(u.playerIds.filter(S=>{const h=r.get(S);return h.bowlingStyle!==null&&["BOWLER","ALLROUNDER"].includes(h.role)}).length<5)throw new Error("The XI needs five bowling-capable players.");for(const S of u.playerIds){if(c.has(S))throw new Error("An XI player cannot play for both sides.");c.add(S)}}return{pack:a,selection:o}}function $a(n){return n!==null&&typeof n=="object"&&(Object.values(n).forEach($a),Object.freeze(n)),n}function a1(n,e){const t=Hr.parse(e),{pack:i,selection:a}=i1(n,t.selection,Pe.map(h=>h.rulesId),ee.manifest.variationIds),o=Pe.find(h=>h.format===t.format&&i.world.rulesIds.includes(h.rulesId));if(!o)throw new Error("The roster does not support this match format.");const r=new Map(i.world.players.map(h=>[h.playerId,h])),c=a.teams.map(h=>{const A=i.world.teams.find(N=>N.teamId===h.teamId);return{teamId:A.teamId,name:A.name,colours:A.colours,playerIds:h.playerIds,xi:h.playerIds.map(N=>r.get(N)),captainId:h.captainId,keeperId:h.keeperId}});let u=nc.get(i);if(!u){const h=Nn().hash;u={worldHash:h(i.world),rosterPackHash:h(i)},Object.isFrozen(i)&&nc.set(i,u)}let p=ec.get(o.rulesId);p||(p=Nn().hash(o),ec.set(o.rulesId,p));const S=structuredClone({version:"LC_ROSTER_MATCH_PREPARATION_V1",gameId:t.gameId,matchId:t.matchId,seed:t.seed,format:t.format,worldHash:u.worldHash,rosterPackHash:u.rosterPackHash,rulesId:o.rulesId,rulesHash:p,modelHash:Cn,stagePackHash:Kn,ground:i.world.grounds.find(h=>h.groundId===a.groundId),teams:c});return $a(S)}const Yn=Nn().hash,Wa=new WeakMap,xe=n=>{throw new Error(`LC_ROSTER_T20_${n}`)};function Ua(n){const e=n.events.at(-1),t=n.events[0];return Yn({setupVersion:n.setup.setupVersion,rosterPackHash:n.setup.rosterPackHash,manifestEngine:n.executionManifest.engine,manifestSetupHash:n.executionManifest.setupHash,revision:n.revision,genesisHash:n.genesisHash,lastEventHash:n.lastEventHash,eventCount:n.events.length,firstEventHash:t?t.eventHash:null,tailEventHash:e?e.eventHash:null,commandCount:n.commands.length,core:n.core})}function o1(n,e){(n.format!=="T20"||n.teams.length!==2)&&xe("FORMAT");const t={setupVersion:"LC_T20_ROSTER_SETUP_V2",gameId:n.gameId,matchId:n.matchId,seed:n.seed,format:"T20",teams:n.teams,ground:n.ground,versions:{schema:"1.0.0",engine:"LC_T20_ROSTER_SETUP_V2",random:Xn,rules:n.rulesId,rulesHash:n.rulesHash,model:ee.manifest.modelId,modelHash:n.modelHash,worldHash:n.worldHash},stagePackHash:n.stagePackHash,modelStatus:"SYNTHETIC_ALPHA",worldSeed:e,fixtureOnly:!0,rosterPackHash:n.rosterPackHash};return Object.freeze(t.versions),Object.freeze(t)}function Ga(n,e){const t=a1(n,e),i=o1(t,n.sourceHash),a=Yn(i),o=Mr.parse({engine:"LC_T20_MATCH_ROSTER_V2",eventChain:oe,conditionPolicy:Ui,conditionPolicyHash:kh,setupHash:a,worldHash:i.versions.worldHash,rulesHash:i.versions.rulesHash,modelHash:i.versions.modelHash,stagePackHash:i.stagePackHash,randomVersion:Xn,scoringVersion:Rt,probabilityVersion:qn}),r={phase:"SETUP",setupHash:a,tossWinnerId:null,tossCallerId:null,battingFirstId:null,activeInningsIndex:0,innings:[],globalAttemptOrdinal:0,result:null,fieldSlots:[],bowlingPlan:null,battingPlans:{},pitch:structuredClone(i.ground.pitchPrior),fatigueBp:Object.fromEntries(i.teams.flatMap(p=>p.playerIds).map(p=>[p,0]))},c=Yn([oe,a,Yn(o)]),u={setup:i,executionManifest:o,core:r,revision:0,events:[],receipts:{},commands:[],genesisHash:c,lastEventHash:c};return Wa.set(u,Ua(u)),u}function za(n,e){const t=Wa.get(n);t||xe("SESSION_UNVERIFIED"),Ua(n)!==t&&xe("SESSION_TAMPERED");const i=Bt(n,e),a=i.session;return Wa.set(a,Ua(a)),{session:a,receipt:i.receipt}}function tc(n,e){(!n||typeof n!="object"||Array.isArray(n))&&xe("SAVE_SHAPE");const t=n,i=t.setup;if(!i)throw new Error("LC_ROSTER_T20_SAVE_SETUP");(i.setupVersion!=="LC_T20_ROSTER_SETUP_V2"||!Array.isArray(i.teams)||i.teams.length!==2)&&xe("SAVE_SETUP");let a=Ga(e,{gameId:i.gameId,matchId:i.matchId,seed:i.seed,format:"T20",selection:{groundId:i.ground.groundId,teams:i.teams.map(o=>({teamId:o.teamId,playerIds:[...o.playerIds],captainId:o.captainId,keeperId:o.keeperId}))}});pn(a.setup)!==pn(i)&&xe("SAVE_SETUP_MISMATCH"),Array.isArray(t.commands)||xe("SAVE_COMMANDS");for(const o of t.commands)a=za(a,o).session;return(t.revision!==a.revision||Yn(t.core)!==Yn(a.core)||Yn(t.events)!==Yn(a.events)||Yn(t.commands)!==Yn(a.commands)||Yn(t.receipts)!==Yn(a.receipts)||Yn(t.executionManifest)!==Yn(a.executionManifest)||t.genesisHash!==a.genesisHash||t.lastEventHash!==a.lastEventHash)&&xe("SAVE_REPLAY_MISMATCH"),a}function r1(n,e){const t=tc(n,e),i=t.setup,a=Ga(e,{gameId:i.gameId,matchId:i.matchId,seed:i.seed,format:"T20",selection:{groundId:i.ground.groundId,teams:i.teams.map(o=>({teamId:o.teamId,playerIds:[...o.playerIds],captainId:o.captainId,keeperId:o.keeperId}))}});return Xs(a,t.events,qs(t))}Nn().hash,Nn().hash,Nn().hash,Nn().hash,Nn().hash,Nn(),Nn(),Nn(),Pe.map(n=>n.rulesId),ee.manifest.variationIds,Gr.parse({modelVersion:Ur,calibrationStatus:"FICTIONAL_PLACEHOLDER",disclaimer:"Fictional player lifecycle parameters (v1): permanent skill development, ageing, retirement, and youth intake use deterministic gameplay curves and are not empirically calibrated. Contracts and budgets are excluded.",minPermanentSkill:18,maxPermanentSkill:86,youthMinAgeYears:17,youthMaxAgeYears:19,growthWindowMaxAgeYears:25,primeWindowMaxAgeYears:30,earliestVoluntaryRetirementAgeYears:34,mandatoryRetirementAgeYears:40,minSquadKeepers:2,minSquadBowlingCapable:7}),Jr.parse({modelVersion:Xr,calibrationStatus:"FICTIONAL_PLACEHOLDER",disclaimer:"Fictional domestic contract system (v1): symmetrical club wage budgets, player market valuations, persistent negotiation rounds, and buyout dead-cap rules use deterministic gameplay parameters. Auctions and international release rules are deferred.",annualClubWageBudgetK:Dp,minAnnualWageK:Cp,maxAnnualWageK:yp,youthRookieAnnualWageK:kp,minContractTermSeasons:qr,maxContractTermSeasons:ze,maxNegotiationRounds:Ke,releaseBuyoutPercent:Bp,minFreeAgentPoolSize:Pp,maxFreeAgentPoolSize:xp}),Be(),Nn();function s1(n){return ah[n]}function fi(n,e,t){let i=ui(n,e,0),a=e;for(const o of t){if(o.ballsBowled>a||o.ballsLost<0)throw new Error("RAIN_INTERRUPTION_INVALID");const r=a-o.ballsBowled,c=Math.max(0,r-o.ballsLost);i-=ui(n,r,o.wicketsLost)-ui(n,c,o.wicketsLost),a-=r-c}return Math.max(0,i)}function ic(n,e,t,i){if(t<=0)throw new Error("RAIN_RESOURCES_INVALID");return i<=t?Math.floor(e*i/t):e+Math.floor(s1(n)*(i-t)/1e4)}function c1(n,e,t,i){return ic(n,e,t,i)+1}function ac(n){const e=n.secondResourcesAvailable-ui(n.format,n.ballsLeft,n.wicketsLost);return ic(n.format,n.firstInningsRuns,n.firstResources,Math.max(0,e))}const l1=Be(),d1=Object.freeze({lbwClearOutGivenOutBp:8500,lbwUmpiresCallGivenOutBp:5e3,lbwNotOutGivenOutBp:600,edgeGivenOutBp:8e3,noEdgeGivenOutBp:400,lbwOutClippingBp:3e3,lbwNotOutAppealBp:2e3,missAppealBp:600,thinEdgeBp:3500,cueWrongBp:7e3,cueUmpiresCallBp:4e3,cueRightBp:1500});function u1(n){const e=[n.pitching,n.impact,n.wickets];return e.includes("OUT")?"NOT_OUT":e.includes("UMPIRES_CALL")?"UMPIRES_CALL":"OUT"}function m1(n){const{context:e,resolution:t}=n;if(t.legality!=="LEGAL"||e.freeHitPending||t.stage!=="DELIVERY")return null;const i=A=>l1.uint32({seed:n.seed,domain:"MATCH_DELIVERY",entityId:`${n.matchId}:${e.inningsIndex}`,eventOrdinal:n.attemptOrdinal,stageName:"umpire-review",drawIndex:A})%1e4,a=d1;let o,r,c=null,u;if(n.contact==="PAD"){o="LBW";const A=t.dismissal?.kind==="LBW",N=i(0);if(A?c={pitching:"IN",impact:"IN",wickets:N<a.lbwOutClippingBp?"UMPIRES_CALL":"IN"}:N<2500?c={pitching:"OUT",impact:"IN",wickets:"IN"}:N<5e3?c={pitching:"IN",impact:"OUT",wickets:"IN"}:N<8500?c={pitching:"IN",impact:"IN",wickets:"OUT"}:c={pitching:"IN",impact:"IN",wickets:"UMPIRES_CALL"},r=u1(c),r==="NOT_OUT"&&i(1)>=a.lbwNotOutAppealBp)return null;u=r==="OUT"?a.lbwClearOutGivenOutBp:r==="UMPIRES_CALL"?a.lbwUmpiresCallGivenOutBp:a.lbwNotOutGivenOutBp}else if(n.contact==="EDGE"&&t.dismissal?.kind==="CAUGHT"&&t.dismissal.fielderId===e.keeperId){if(i(1)>=a.thinEdgeBp)return null;o="CAUGHT_BEHIND",r="OUT",u=a.edgeGivenOutBp}else if(n.contact==="MISS"&&t.dismissal===null){if(i(1)>=a.missAppealBp)return null;o="CAUGHT_BEHIND",r="NOT_OUT",u=a.noEdgeGivenOutBp}else return null;const p=i(2)<u,h=r==="OUT"&&!p||r==="NOT_OUT"&&p?a.cueWrongBp:r==="UMPIRES_CALL"?a.cueUmpiresCallBp:a.cueRightBp;return{kind:o,onFieldOut:p,decisive:r,tracking:c,cue:i(3)<h?"CONFIDENT":"DOUBTFUL"}}const oc={wides:0,noBalls:0,byes:0,legByes:0,penalties:0};function g1(n,e,t){if(t==="LBW"&&n.dismissal?.kind==="LBW"||t==="CAUGHT_BEHIND"&&n.dismissal?.kind==="CAUGHT")return n;const i=e.strikerEnd==="NORTH"?"north":"south",a={north:e.endsBefore.north,south:e.endsBefore.south,[i]:null},o={...n,batRuns:0,extras:{...oc},completedRuns:0,attemptedRuns:0,boundary:"NONE",endsAfter:a};return t==="LBW"?{...o,dismissal:{kind:"LBW",playerId:e.strikerId,fielderId:null,wicketEnd:e.strikerEnd},batContact:!1,trajectory:null,shotSector:null,fieldOutcome:"NONE"}:{...o,dismissal:{kind:"CAUGHT",playerId:e.strikerId,fielderId:e.keeperId,wicketEnd:e.strikerEnd},batContact:!0,attemptedStroke:!0,trajectory:"EDGE",fieldOutcome:"CATCH"}}function p1(n,e){return n.dismissal===null?n:{...n,dismissal:null,batRuns:0,extras:{...oc},completedRuns:0,attemptedRuns:0,boundary:"NONE",fieldOutcome:n.fieldOutcome==="CATCH"?"STOP":n.fieldOutcome,endsAfter:{north:e.endsBefore.north,south:e.endsBefore.south}}}const I1=Nn(),rc=Be(),Ka=n=>I1.hash(n),Pt=n=>structuredClone(n),h1=n=>{throw new Error(`LC_RAIN_${n}`)};function ln(n,e){n||h1(e)}const f1={T20:{rulesId:ha,fullBalls:120,minBalls:30,maxOversLost:8,registry:di,slots:n=>n<36?wa:Na,validateField:gt,policy:Nt},ODI:{rulesId:fa,fullBalls:300,minBalls:120,maxOversLost:25,registry:Ls,slots:n=>n<60?XI:n<240?qI:JI,validateField:Zh,policy:Os}};function Re(n){return f1[n.format]}const Ya=Object.freeze({rain:!0,reviews:!1});function Xe(n,e){const t=n.teams.find(i=>i.teamId===e);return ln(t,"UNKNOWN_TEAM"),t}function ja(n,e){const t=n.teams.find(i=>i.teamId!==e);return ln(t,"UNKNOWN_TEAM"),t.teamId}function Fe(n,e){const t=n.teams.flatMap(i=>i.xi).find(i=>i.playerId===e);return ln(t,"UNKNOWN_PLAYER"),t}function Pn(n){const e=n.innings[n.activeInningsIndex];return ln(e,"NO_ACTIVE_INNINGS"),e}function E1(n){return Math.ceil(Math.ceil(n/6)/5)*6}function S1(n){const e=Re(n),t=e.fullBalls/6;let i=0;const a=()=>rc.uint32({seed:n.seed,domain:"WEATHER",entityId:n.matchId,eventOrdinal:0,stageName:"lo-rain-plan",drawIndex:i++}),o=a()%10<7?1:2,r=[];for(let p=0;p<o;p++){const S=a()%2,h=2+a()%(t-4),A=1+a()%e.maxOversLost,N=a()%4===0;r.push({inningsIndex:S,atLegalBall:h*6,oversLost:A,terminal:N})}r.sort((p,S)=>p.inningsIndex-S.inningsIndex||p.atLegalBall-S.atLegalBall);const c=r.filter((p,S)=>S===0||p.inningsIndex!==r[S-1].inningsIndex||p.atLegalBall!==r[S-1].atLegalBall),u=c.map((p,S)=>({...p,terminal:p.terminal&&p.inningsIndex===1&&S===c.length-1}));return BI.parse({stoppages:u})}function sc(n,e=Ya){ln(Us(n)||Nh(n),"INVALID_FROZEN_SETUP"),ln(e.rain||e.reviews,"NO_RULES_CHOSEN"),ln(n.versions.rules===(n.format==="T20"?"LC_T20_01":"LC_ODI_01"),"UNSUPPORTED_RULES");const t=Re(n);return{rulesId:t.rulesId,format:n.format,gameId:n.gameId,matchId:n.matchId,plan:e.rain?S1(n):{stoppages:[]},nextStoppage:0,phase:"TOSS",tossWinnerId:null,innings:[],activeInningsIndex:0,allocations:[t.fullBalls,t.fullBalls],startAllocations:[t.fullBalls,t.fullBalls],inningsClosed:[!1,!1],stoppages:[],target:null,attemptOrdinal:0,fatigueBp:Object.fromEntries(n.teams.flatMap(i=>i.playerIds).map(i=>[i,0])),pitch:Pt(n.ground.pitchPrior),aggression:{},lastDelivery:null,result:null,...e.rain?{}:{weatherOff:!0},...e.reviews?{reviews:{rulesId:n.format==="T20"?Sa:_a,reviewsLeft:{},pending:null,log:[]}}:{}}}function _1(n){return{rain:n.weatherOff!==!0,reviews:n.reviews!==void 0}}function v1(n,e,t,i,a){const o=Xe(n,t),r=Xe(n,ja(n,t));return te({engineVersion:Rt,rulesId:n.format==="T20"?"LC_T20_01":"LC_ODI_01",nextDeliveryIndex:e.attemptOrdinal,batting:Object.fromEntries(o.playerIds.map(c=>[c,{runs:0,ballsFaced:0,fours:0,sixes:0,dismissed:!1}])),bowling:Object.fromEntries(r.playerIds.map(c=>[c,{runsConceded:0,legalBalls:0,wickets:0,maidens:0}])),dismissals:{},keeperId:r.keeperId,outfieldIds:r.playerIds.filter(c=>c!==r.keeperId).slice(0,9),currentOverRuns:0,innings:{index:i,battingTeamId:o.teamId,bowlingTeamId:r.teamId,runs:0,wickets:0,legalBalls:0,deliveryAttempts:0,targetToWin:a,allocatedBalls:Re(n).fullBalls,extras:{wides:0,noBalls:0,byes:0,legByes:0,penalties:0},northBatterId:null,southBatterId:null,strikerEnd:"NORTH",battingOrder:[...o.playerIds],dismissed:[],bowlerId:null,previousOverBowlerId:null,bowlerLegalBalls:Object.fromEntries(r.playerIds.map(c=>[c,0])),freeHitPending:!1,ballAgeLegalBalls:0,complete:!1}})}function cc(n,e){return n.stoppages.filter(t=>t.inningsIndex===e&&!t.terminal).map(t=>({ballsBowled:t.legalBalls,wicketsLost:t.wickets,ballsLost:t.ballsLost}))}function lc(n,e){return fi(n.format,e.startAllocations[0],cc(e,0))}function dc(n,e){return fi(n.format,e.startAllocations[1],cc(e,1))}function uc(n,e){const t=e.innings[0].innings.runs;return e.stoppages.length===0?t+1:c1(n.format,t,lc(n,e),dc(n,e))}function Za(n){return n.stoppages.length===0?"STANDARD":"RESOURCE_TABLE"}function mc(n,e,t,i){for(i===1&&(e.startAllocations[1]=e.allocations[1],e.target=uc(n,e)),e.innings.push(v1(n,e,t,i,i===1?e.target:null)),e.reviews&&(e.reviews.reviewsLeft=Object.fromEntries(n.teams.map(a=>[a.teamId,PI]))),e.activeInningsIndex=i,e.phase="AWAITING_BATTER";e.nextStoppage<e.plan.stoppages.length&&e.plan.stoppages[e.nextStoppage].inningsIndex<i;)e.nextStoppage++}function qe(n,e){n.result=e,n.phase="COMPLETE"}function gc(n,e){const t=Pn(e).innings,i=e.target;t.runs>=i?qe(e,{kind:"WIN",winnerTeamId:t.battingTeamId,marginType:"WICKETS",margin:10-t.wickets,method:Za(e)}):t.runs===i-1?qe(e,{kind:"TIE",winnerTeamId:null,marginType:null,margin:null,method:Za(e)}):qe(e,{kind:"WIN",winnerTeamId:t.bowlingTeamId,marginType:"RUNS",margin:i-1-t.runs,method:Za(e)})}function b1(n,e){if(e.inningsClosed[e.activeInningsIndex]=!0,e.activeInningsIndex===0){mc(n,e,Pn(e).innings.bowlingTeamId,1);return}gc(n,e)}function T1(n){const e=Pn(n);return e.innings.complete||e.innings.legalBalls>=n.allocations[n.activeInningsIndex]}function R1(n,e){const t=e.activeInningsIndex,i=Pn(e).innings;for(;e.nextStoppage<e.plan.stoppages.length;){const S=e.plan.stoppages[e.nextStoppage];if(S.inningsIndex>t||!(S.inningsIndex<t||S.atLegalBall<i.legalBalls||S.atLegalBall>=e.allocations[t]))break;e.nextStoppage++}const a=e.plan.stoppages[e.nextStoppage];if(!a||a.inningsIndex!==t||a.atLegalBall!==i.legalBalls||i.complete)return!1;e.nextStoppage++;const o=Re(n);if(a.terminal){if(e.stoppages.push({inningsIndex:t,legalBalls:i.legalBalls,wickets:i.wickets,runs:i.runs,ballsLost:e.allocations[t]-i.legalBalls,allocations:[e.allocations[0],i.legalBalls],terminal:!0,targetAfter:e.target}),i.legalBalls<o.minBalls)return qe(e,{kind:"NO_RESULT",winnerTeamId:null,marginType:null,margin:null,method:"RESOURCE_TABLE"}),!0;const S=ac({format:n.format,firstInningsRuns:e.innings[0].innings.runs,firstResources:lc(n,e),secondResourcesAvailable:dc(n,e),ballsLeft:e.allocations[1]-i.legalBalls,wicketsLost:i.wickets});return e.allocations[1]=i.legalBalls,i.runs>S?qe(e,{kind:"WIN",winnerTeamId:i.battingTeamId,marginType:"RUNS",margin:i.runs-S,method:"RESOURCE_TABLE"}):i.runs===S?qe(e,{kind:"TIE",winnerTeamId:null,marginType:null,margin:null,method:"RESOURCE_TABLE"}):qe(e,{kind:"WIN",winnerTeamId:i.bowlingTeamId,marginType:"RUNS",margin:S-i.runs,method:"RESOURCE_TABLE"}),!0}const r=Math.max(i.legalBalls,o.minBalls);if(t===0){const S=Math.ceil(a.oversLost/2)*6,h=Math.max(r,e.allocations[0]-S),A=e.allocations[0]-h;return e.allocations=[h,h],e.stoppages.push({inningsIndex:0,legalBalls:i.legalBalls,wickets:i.wickets,runs:i.runs,ballsLost:A,allocations:[h,h],terminal:!1,targetAfter:null}),!1}const c=Math.max(r,e.allocations[1]-a.oversLost*6),u=e.allocations[1]-c;e.allocations[1]=c,e.stoppages.push({inningsIndex:1,legalBalls:i.legalBalls,wickets:i.wickets,runs:i.runs,ballsLost:u,allocations:[e.allocations[0],c],terminal:!1,targetAfter:null}),e.target=uc(n,e),e.stoppages[e.stoppages.length-1].targetAfter=e.target;const p=Pt(Pn(e));return p.innings.targetToWin=e.target,p.innings.runs>=e.target&&(p.innings.complete=!0),e.innings[1]=te(p),p.innings.runs>=e.target?(gc(n,e),!0):!1}function L1(n,e){const t=Re(n).slots(e.innings.legalBalls);return[...e.outfieldIds].sort().map((i,a)=>({slotId:t[a],playerId:i}))}function A1(n,e){const t=Re(n).registry.positions.find(i=>i.slotId===e);return ln(t,"UNKNOWN_FIELD_POSITION"),t}function O1(n,e,t){const i=Fe(n,t.bowlerId),o=!["FAST","MEDIUM"].includes(i.bowlingStyle??"")?12:20,r=Re(n).policy.effortFactorBp.NORMAL,c=Math.floor((o*r+5e3)/1e4);if(e.fatigueBp[t.bowlerId]=Math.min(1e4,(e.fatigueBp[t.bowlerId]??0)+c),t.legalBall){const u=Pt(e.pitch);e.pitch=u,u.wearPoints+=1,u.wearPoints%100===0&&(u.turnBp=Math.min(1e4,u.turnBp+20),u.variabilityBp=Math.min(1e4,u.variabilityBp+10),u.seamBp=Math.max(0,u.seamBp-10))}}function pc(n,e){const t=Pn(e),i=je(t),a=Fe(n,i.strikerId),o=Fe(n,i.bowlerId),r=Fe(n,i.keeperId),c=n.format,u=L1(n,t);Re(n).validateField(u,t.outfieldIds,a.batHand,t.innings.legalBalls);const p=Vs({kind:"GENERATE_DELIVERY",generatorVersion:"LC_CONDITIONAL_DELIVERY_V1",stagePackId:"synthetic-alpha-01-delivery-v1",stagePackHash:Kn,randomVersion:Xn,probabilityVersion:qn,modelId:le,modelHash:Cn,lutVersion:me,lutHash:ve,rulesHash:n.versions.rulesHash,matchId:n.matchId,seed:n.seed,attemptOrdinal:e.attemptOrdinal,format:c,phase:ka(c,t.innings.legalBalls),context:i,bowling:{bowlingStyle:o.bowlingStyle,controlRating:o.skills[c].control,movementRating:o.skills[c].movement,fatigueBp:e.fatigueBp[o.playerId]??0,line:"STUMPS",intendedLength:"GOOD",effort:"NORMAL",variationId:"stock"},batting:{defenceRating:a.skills[c].defence,timingRating:a.skills[c].timing,powerRating:a.skills[c].power,rotationRating:a.skills[c].rotation,vsPaceRating:a.skills[c].vsPace,vsSpinRating:a.skills[c].vsSpin,aggression:e.aggression[a.playerId]??2,intent:"NORMAL",attemptedStroke:!0,shotSectorWeights:[...a.shotSectorWeights]},conditions:{seamBp:e.pitch.seamBp,turnBp:e.pitch.turnBp},field:{keeper:{keepingRating:r.skills[c].keeping,catchingRating:r.skills[c].catching,throwingRating:r.skills[c].throwing},slots:u.map(S=>{const h=Fe(n,S.playerId),A=A1(n,S.slotId);return{playerId:S.playerId,sector:A.sector,depth:A.depth,role:S.slotId.startsWith("slip")?"SLIP":"NORMAL",catchingRating:h.skills[c].catching,throwingRating:h.skills[c].throwing}})}});if(e.reviews){const S=p.trace.find(A=>A.stageName==="contact")?.selectedCategoryId??null,h=m1({seed:n.seed,matchId:n.matchId,attemptOrdinal:e.attemptOrdinal,context:i,resolution:p.resolution,contact:S});if(h){const A=t.innings,N={kind:h.kind,strikerId:i.strikerId,bowlerId:i.bowlerId,onFieldOut:h.onFieldOut,decisive:h.decisive,tracking:h.tracking,cue:h.cue,reviewTeamId:h.onFieldOut?A.battingTeamId:A.bowlingTeamId,outResolution:g1(p.resolution,i,h.kind),notOutResolution:p1(p.resolution,i)};if((e.reviews.reviewsLeft[N.reviewTeamId]??0)>0){e.reviews.pending=N,e.phase="AWAITING_REVIEW";return}Ic(e,N,"NO_REVIEWS_LEFT",N.onFieldOut),Xa(n,e,N.onFieldOut?N.outResolution:N.notOutResolution);return}}Xa(n,e,p.resolution)}function Ic(n,e,t,i){const a=t==="OVERTURNED"||t==="STRUCK_DOWN"||t==="UMPIRES_CALL";n.reviews.log.push({inningsIndex:n.activeInningsIndex,legalBallsBefore:Pn(n).innings.legalBalls,kind:e.kind,strikerId:e.strikerId,bowlerId:e.bowlerId,onFieldOut:e.onFieldOut,reviewTeamId:e.reviewTeamId,outcome:t,tracking:a?e.tracking:null,finalOut:i})}function w1(n,e,t){const i=e.reviews.pending;e.reviews.pending=null;let a=i.onFieldOut,o="NOT_REVIEWED";t&&(i.decisive==="UMPIRES_CALL"?o="UMPIRES_CALL":(a=i.decisive==="OUT",o=a!==i.onFieldOut?"OVERTURNED":"STRUCK_DOWN",o==="STRUCK_DOWN"&&(e.reviews.reviewsLeft[i.reviewTeamId]=(e.reviews.reviewsLeft[i.reviewTeamId]??1)-1))),Ic(e,i,o,a),Xa(n,e,a?i.outResolution:i.notOutResolution)}function Xa(n,e,t){const i=Pn(e),a=je(i),o=ks(a,t),r=Bs(i,o);e.innings[e.activeInningsIndex]=r.ledger,e.attemptOrdinal+=1,e.lastDelivery=o,O1(n,e,o);const c=r.ledger.innings;if(o.legalBall&&c.legalBalls%6===0){for(const S of Xe(n,c.bowlingTeamId).playerIds)S!==o.bowlerId&&(e.fatigueBp[S]=Math.max(0,(e.fatigueBp[S]??0)-15));if(R1(n,e))return}if(T1(e)){b1(n,e);return}const p=Pn(e).innings;e.phase=p.northBatterId===null||p.southBatterId===null?"AWAITING_BATTER":p.bowlerId===null?"AWAITING_BOWLER":"READY"}function qa(n,e){const t=Pn(e),i=Xe(n,t.innings.bowlingTeamId),a=E1(e.allocations[e.activeInningsIndex]),o=i.playerIds.filter(c=>c!==i.keeperId&&Fe(n,c).bowlingStyle!==null&&c!==t.innings.previousOverBowlerId),r=o.filter(c=>t.bowling[c].legalBalls<a);return r.length>0?r:o.filter(c=>t.bowling[c].legalBalls<(n.format==="T20"?24:60))}function Ja(n,e){const t=Pn(e),i=new Set([t.innings.northBatterId,t.innings.southBatterId,...t.innings.dismissed]);return Xe(n,t.innings.battingTeamId).playerIds.filter(a=>!i.has(a))}function Qa(n,e){return e.phase==="AWAITING_REVIEW"?{teamId:e.reviews.pending.reviewTeamId,decision:"REVIEW"}:e.phase==="TOSS"?{teamId:n.teams[0].teamId,decision:"TOSS"}:e.phase==="AWAITING_INNINGS"?{teamId:e.tossWinnerId,decision:"INNINGS"}:e.phase==="AWAITING_BATTER"?{teamId:Pn(e).innings.battingTeamId,decision:"BATTER"}:e.phase==="AWAITING_BOWLER"?{teamId:Pn(e).innings.bowlingTeamId,decision:"BOWLER"}:null}function hc(n,e,t){const i=ba.parse(t),a=Pt(e);switch(ln(a.phase!=="COMPLETE","COMPLETE"),i.kind){case"CALL_TOSS":{ln(a.phase==="TOSS","WRONG_PHASE"),Xe(n,i.teamId);const o=rc.uint32({seed:n.seed,domain:"TOSS",entityId:n.matchId,eventOrdinal:0,stageName:"coin",drawIndex:0})%2===0?"HEADS":"TAILS";a.tossWinnerId=i.call===o?i.teamId:ja(n,i.teamId),a.phase="AWAITING_INNINGS";break}case"CHOOSE_INNINGS":{ln(a.phase==="AWAITING_INNINGS","WRONG_PHASE"),ln(i.teamId===a.tossWinnerId,"NOT_TOSS_WINNER"),mc(n,a,i.choice==="BAT"?i.teamId:ja(n,i.teamId),0);break}case"SET_BATTER":{ln(a.phase==="AWAITING_BATTER","WRONG_PHASE");const o=Pn(a);if(ln(i.teamId===o.innings.battingTeamId,"NOT_BATTING_TEAM"),ln(Ja(n,a).includes(i.playerId),"INELIGIBLE_BATTER"),o.innings.northBatterId===null&&o.innings.southBatterId===null){const c=Pt(o);c.innings.northBatterId=i.playerId,a.innings[a.activeInningsIndex]=te(c)}else a.innings[a.activeInningsIndex]=Ps(o,i.playerId);const r=Pn(a).innings;a.phase=r.northBatterId===null||r.southBatterId===null?"AWAITING_BATTER":r.bowlerId===null?"AWAITING_BOWLER":"READY";break}case"SET_BOWLER":{ln(a.phase==="AWAITING_BOWLER","WRONG_PHASE");const o=Pn(a);ln(i.teamId===o.innings.bowlingTeamId,"NOT_BOWLING_TEAM"),ln(qa(n,a).includes(i.playerId),"INELIGIBLE_BOWLER");const r=Xe(n,o.innings.bowlingTeamId),c=r.playerIds.filter(u=>u!==r.keeperId&&u!==i.playerId);a.innings[a.activeInningsIndex]=xs(o,i.playerId,c),a.phase="READY";break}case"SET_AGGRESSION":{ln(a.phase==="READY","WRONG_PHASE");const o=Pn(a).innings;ln([o.northBatterId,o.southBatterId].includes(i.playerId),"BATTER_NOT_ACTIVE"),a.aggression[i.playerId]=i.aggression;break}case"REVIEW_DECISION":{ln(a.phase==="AWAITING_REVIEW"&&a.reviews?.pending,"WRONG_PHASE"),ln(i.teamId===a.reviews.pending.reviewTeamId,"NOT_REVIEWING_TEAM"),w1(n,a,i.review);break}case"BOWL":{if(ln(a.phase==="READY","WRONG_PHASE"),i.scope==="BALL"){pc(n,a);break}for(let o=0;a.phase==="READY";o++)ln(o<60,"OVER_ATTEMPT_LIMIT"),pc(n,a);break}}return a}function fc(n,e){if(e.phase==="COMPLETE")return null;if(e.phase==="READY")return{kind:"BOWL",scope:"OVER"};const t=Qa(n,e);if(t.decision==="TOSS")return{kind:"CALL_TOSS",teamId:t.teamId,call:"HEADS"};if(t.decision==="INNINGS")return{kind:"CHOOSE_INNINGS",teamId:t.teamId,choice:"BOWL"};if(t.decision==="REVIEW")return{kind:"REVIEW_DECISION",teamId:t.teamId,review:e.reviews.pending.cue==="CONFIDENT"};if(t.decision==="BATTER")return{kind:"SET_BATTER",teamId:t.teamId,playerId:Ja(n,e)[0]};const i=Pn(e),a=qa(n,e).sort((o,r)=>i.bowling[o].legalBalls-i.bowling[r].legalBalls||Fe(n,r).skills[n.format].control-Fe(n,o).skills[n.format].control||(o<r?-1:1));return ln(a.length,"NO_ELIGIBLE_BOWLER"),{kind:"SET_BOWLER",teamId:t.teamId,playerId:a[0]}}function no(n){return Ka(n)}function N1(n,e,t=Ya){let i=sc(n,t);for(const a of e)i=hc(n,i,a);return i}const Ec=n=>n.teams.map(e=>({teamId:e.teamId,playerIds:[...e.playerIds],captainId:e.captainId,keeperId:e.keeperId}));function D1(n,e,t){const i=_1(e),a={rulesId:e.rulesId,gameId:n.gameId,matchId:n.matchId,seed:n.seed,groundId:n.ground.groundId,selectedTeams:Ec(n),commands:[...t],stateSha256:no(e)};return i.rain&&!i.reviews?Ss.parse({schemaId:Ea,...a}):_s.parse({schemaId:va,...a,rain:i.rain,reviewRulesId:e.reviews?.rulesId??null})}function C1(n){return n.schemaId===Ea?Ya:{rain:n.rain,reviews:n.reviewRulesId!==null}}function y1(n,e){const t=vs.parse(e);ln(t.rulesId===Re(n).rulesId,"RECORD_FORMAT_MISMATCH"),t.schemaId===va&&(ln(t.rain||t.reviewRulesId!==null,"RECORD_NO_RULES"),ln(t.reviewRulesId===null||t.reviewRulesId===(n.format==="T20"?Sa:_a),"RECORD_FORMAT_MISMATCH")),ln(t.gameId===n.gameId&&t.matchId===n.matchId&&t.seed===n.seed&&t.groundId===n.ground.groundId&&Ka(t.selectedTeams)===Ka(Ec(n)),"RECORD_SETUP_MISMATCH");const i=N1(n,t.commands,C1(t));return ln(no(i)===t.stateSha256,"RECORD_STATE_MISMATCH"),i}function Sc(n,e,t){const i=n.format==="T20"?"LC_T20_01":"LC_ODI_01",a={setupVersion:n.format==="T20"?"LC_T20_SETUP_V1":"LC_ODI_SETUP_V1",setup:{schemaVersion:"1.0.0",gameId:n.gameId,matchId:n.matchId,format:n.format,worldPackId:Fn.worldPackId,rulesId:i,modelId:"synthetic-alpha-01",randomId:"SHA256_COUNTER_V1",seed:n.seed,teamIds:n.selectedTeams.map(o=>o.teamId),groundId:n.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:Fn.worldFileSha256,worldCanonicalSha256:Fn.worldCanonicalSha256,rulesHash:Ba(i),modelHash:Cn,stagePackHash:Kn,selectedTeams:n.selectedTeams};return n.format==="T20"?Ha(a,e,t):Dh(a,e,t)}function k1(n,e,t,i){const a=u=>u.eligible?Math.max(0,Math.ceil((i-u.legalBalls)/6)):0,o=e.find(u=>u.id===n);if(!o||a(o)<1)return!1;const r=t-1;if(r<=0)return!0;let c=0;for(const u of e){const p=u.id===n?a(u)-1:a(u);c+=Math.min(p,u.id===n?Math.floor(r/2):Math.ceil(r/2))}return c>=r}function B1(n,e,t){const i=n.filter(r=>r.eligible),a=new Set(i.filter(r=>k1(r.id,n,e,t)).map(r=>r.id)),o=new Map;if(a.size===0)return o;for(const r of i)a.has(r.id)||o.set(r.id,"Would leave overs that no one could bowl");return o}function ue(n,e){if(!n)throw new Error(`LC_MATCH_ANALYTICS_${e}`)}function P1(n){return n.batRuns+n.extras.wides+n.extras.noBalls+n.extras.byes+n.extras.legByes+n.extras.penalties}function _c(n){ue(Number.isInteger(n)&&n>=0&&n<=4,"INNINGS_COUNT");const e=new Map,t=[],i=new Map,a=[],o=[],r=new Map,c=Array(n).fill(0),u=Array(n).fill(0),p=Array(n).fill(0);let S=0,h=0,A=0;function N(L){if(ue(L.sequence===A+1,"SEQUENCE_ORDER"),L.type!=="DELIVERY_RECORDED"){A=L.sequence;return}const E=L.payload.event,T=E.inningsIndex;ue(Number.isInteger(T)&&T>=0&&T<n,"INNINGS_INDEX");const g=P1(E);ue(Number.isSafeInteger(g)&&g>=0,"INVALID_RUNS"),E.shotSector!==null&&ue(Number.isInteger(E.shotSector)&&E.shotSector>=0&&E.shotSector<8,"SHOT_SECTOR"),E.executedLength!==null&&ue(["YORKER","FULL","GOOD","SHORT","FULL_TOSS"].includes(E.executedLength),"PITCH_LENGTH");const I=Math.floor(p[T]/6)+1,_=`${T}:${I}`,C=e.get(_)??{inningsIndex:T,overNumber:I,runs:0,wickets:0,legalBalls:0,attempts:0};C.runs+=g,C.wickets+=+(E.dismissal!==null),C.legalBalls+=Number(E.legalBall),C.attempts+=1,e.set(_,C);const f=[E.strikerId,E.nonStrikerId].sort();let R=t.at(-1);if((!R||R.inningsIndex!==T||R.players[0]!==f[0]||R.players[1]!==f[1])&&(R={inningsIndex:T,players:f,runs:0,legalBalls:0,fromSequence:L.sequence,toSequence:L.sequence},t.push(R)),R.runs+=g,R.legalBalls+=Number(E.legalBall),R.toSequence=L.sequence,E.shotSector!==null){const F=`${T}:${E.strikerId}:${E.shotSector}`,$=i.get(F)??{inningsIndex:T,batterId:E.strikerId,sector:E.shotSector,attempts:0,batRuns:0,fours:0,sixes:0};$.attempts++,$.batRuns+=E.batRuns,$.fours+=+(E.boundary==="FOUR"),$.sixes+=+(E.boundary==="SIX"),i.set(F,$)}else E.batRuns>0&&S++;c[T]+=g,u[T]+=+(E.dismissal!==null),p[T]+=Number(E.legalBall),E.executedLength===null?h++:r.set(E.executedLength,(r.get(E.executedLength)??0)+1),E.dismissal&&o.push({inningsIndex:T,sequence:L.sequence,playerId:E.dismissal.playerId,runs:c[T],wickets:u[T],legalBalls:p[T]}),a.push({inningsIndex:T,sequence:L.sequence,legalBalls:p[T],totalRuns:c[T],wickets:u[T]}),A=L.sequence}function y(L){const E=L?.innings.length??n;if(ue(E<=n,"INNINGS_COUNT"),L){for(let T=0;T<E;T++){const g=L.innings[T];ue(!!g&&c[T]===g.runs,`RUN_RECONCILIATION_${T}`),ue(u[T]===g.wickets,`WICKET_RECONCILIATION_${T}`),ue(p[T]===g.legalBalls,`BALL_RECONCILIATION_${T}`)}for(let T=E;T<n;T++)ue(c[T]===0&&u[T]===0&&p[T]===0,`INNINGS_RECONCILIATION_${T}`)}return{overSummaries:[...e.values()].map(T=>({...T})),worm:a.map(T=>({...T})),partnerships:t.map(T=>({...T,players:[...T.players]})),shotSectors:[...i.values()].map(T=>({...T})).sort((T,g)=>T.inningsIndex-g.inningsIndex||T.batterId.localeCompare(g.batterId)||T.sector-g.sector),unlocatedShots:S,finalRuns:c.slice(0,E),finalLegalBalls:p.slice(0,E),finalWickets:u.slice(0,E),fallOfWickets:o.map(T=>({...T})),pitchLengths:["YORKER","FULL","GOOD","SHORT","FULL_TOSS"].filter(T=>r.has(T)).map(T=>({length:T,attempts:r.get(T)})),unrecordedLengths:h}}return{append:N,snapshot:y,get appliedSequence(){return A}}}function x1(n){let e=_c(n),t=null;function i(a){const o=e.appliedSequence;(a.length<o||o>0&&a[o-1]?.eventHash!==t)&&(e=_c(n),t=null);for(const r of a.slice(e.appliedSequence))e.append(r),t=r.eventHash}return{update:i,snapshot:a=>e.snapshot(a),get appliedSequence(){return e.appliedSequence}}}const F1=new Set(["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket"]),H1=new Set(["slip-1","slip-2"]);function xt(n){return`${Math.floor(n/6)}.${n%6}`}function vc(n){let e=0,t=0,i=0;for(const a of n)F1.has(a.slotId)?e+=1:t+=1,H1.has(a.slotId)&&(i+=1);return{ring:e,boundary:t,closeCatchers:i}}function eo(n,e,t){const i=n==="T20"&&e<36||n==="ODI"&&e<60;return t==="SLIP_ATTACK"?["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","fine-leg"]:i?["slip-1","slip-2","point","cover","mid-off","mid-on","midwicket","deep-square-leg","long-on"]:t==="BALANCED_RING"?["slip-1","point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","long-on"]:n==="ODI"&&e>=240?["point","cover","deep-cover","long-off","mid-on","midwicket","deep-square-leg","fine-leg","long-on"]:["point","cover","mid-off","deep-cover","mid-on","midwicket","deep-square-leg","fine-leg","long-on"]}function to(n,e){return[...n].sort().map((i,a)=>({slotId:e[a],playerId:i}))}function io(n,e){if(n.length!==e.length)return!1;const t=i=>[...i].sort((a,o)=>ur(a.playerId,o.playerId)).map(a=>`${a.playerId}:${a.slotId}`).join("|");return t(n)===t(e)}function M1(n,e,t){const i=vc(t);return[{controlId:"BATTING_AGGRESSION",side:"BATTING",label:"Batting aggression (0–4)",currentSetting:n?`Level ${n.aggression} / 4`:"Awaiting striker",upside:"Higher aggression shifts contact toward scoring strokes and boundaries when chasing or accelerating late.",tradeOff:"Higher aggression increases aerial, edge, and miss contact; lower levels lean on defence at a slower scoring rate."},{controlId:"BATTING_INTENT",side:"BATTING",label:"Batting intent",currentSetting:n?n.intent:"Awaiting striker",upside:"ROTATE boosts single-taking to turn strike over; PROTECT suppresses risky singles to shield a partner or survive a spell.",tradeOff:"ROTATE adds run-out exposure against sharp ring fielders; PROTECT passes up singles and can stall scoreboard momentum."},{controlId:"BOWLING_LINE",side:"BOWLING",label:"Bowling line",currentSetting:e?e.line:"Awaiting bowler",upside:"STUMPS brings bowled and LBW into play and narrows straight sectors; OFF channels strokes into off-side catchers and ring stops.",tradeOff:"LEG line disables LBW dismissals and raises wide risk under the legality model."},{controlId:"BOWLING_LENGTH",side:"BOWLING",label:"Intended bowling length",currentSetting:e?e.length:"Awaiting bowler",upside:"GOOD balances control; YORKER raises misses and suppresses lofted contact; SHORT tests batters with higher aerial and edge rates.",tradeOff:"Execution depends on control and low fatigue: missed YORKER or FULL balls spill into high-scoring full tosses."},{controlId:"BOWLING_EFFORT",side:"BOWLING",label:"Bowling effort",currentSetting:e?e.effort:"Awaiting bowler",upside:"CONSERVE lowers wide/no-ball risk and slows fatigue across longer spells; MAXIMUM pushes effort in short bursts.",tradeOff:"MAXIMUM raises wide/no-ball risk and accelerates bowler fatigue, degrading movement and length accuracy later in the spell."},{controlId:"BOWLING_VARIATION",side:"BOWLING",label:"Delivery variation",currentSetting:e?e.variationId:"Awaiting bowler",upside:"Stock ball uses baseline control; selecting a bowler's supported variation changes pace or turn mix when batters settle.",tradeOff:"Only variations listed on the active bowler are legal; overusing effort alongside variations still accumulates spell fatigue."},{controlId:"FIELD_PLACEMENT",side:"FIELDING",label:"Named 9-man field",currentSetting:t.length===9?`${i.ring} in ring · ${i.boundary} outside · ${i.closeCatchers} slip${i.closeCatchers===1?"":"s"}`:"Awaiting innings",upside:"Slips maximize edge catches; ring fielders cut singles and create run-out pressure; deep riders suppress fours and sixes.",tradeOff:"Pushing fielders to the boundary opens single-taking gaps in the ring; circle and leg-side limits apply by format and striker hand."}]}const ao={line:"STUMPS",length:"GOOD",variationId:"stock",effort:"NORMAL"},bc={aggression:2,intent:"NORMAL"},V1=new Set(["BOWLED","LBW","CAUGHT","STUMPED","HIT_WICKET"]);function $1(n,e,t=[]){let i=0,a=0,o=0,r={...ao},c=[...t];const u=new Map,p=[],S={0:null,1:null};let h=null;const A=[],N=new Map;function y(g,I){const _=`${g}:${I}`,C=N.get(_);if(C)return C;const f=u.get(I)??{...bc},R={inningsIndex:g,playerId:I,dismissed:!1,initialPlan:{...f},planCounts:new Map,planChangesCount:0,ballsFaced:0,runs:0,dots:0,singles:0,boundaries:0};return N.set(_,R),A.push(R),R}function L(){for(const g of[0,1])S[g]&&(S[g].status="COMPLETED",S[g]=null);h&&(h.status="COMPLETED",h=null)}for(const g of n){const I=typeof g.payload=="object"&&g.payload!==null&&!Array.isArray(g.payload)?g.payload:{};if(g.type==="INNINGS_STARTED"){L(),i=typeof I.inningsIndex=="number"?I.inningsIndex:i+1,a=0,o=0,r={...ao},u.clear();continue}if(g.type==="INNINGS_COMPLETED"||g.type==="DECLARED"||g.type==="MATCH_COMPLETED"){L();continue}if(g.type==="BATTER_SELECTED"){const _=String(I.playerId??"");_&&y(i,_);continue}if(g.type==="BATTING_PLAN_CHANGED"){const _=String(I.playerId??""),C=typeof I.aggression=="number"?I.aggression:2,f=I.intent==="ROTATE"||I.intent==="PROTECT"?I.intent:"NORMAL";if(_){u.set(_,{aggression:C,intent:f});const R=y(i,_);R.planChangesCount+=1,R.ballsFaced===0&&(R.initialPlan={aggression:C,intent:f})}continue}if(g.type==="BOWLER_SELECTED"){const _=String(I.playerId??""),C=Math.floor(a/6),f=C%2;r={...ao};const R=S[f];if(R&&R.bowlerId===_)R.status="IN_PROGRESS",R.endOver=C+1,h=R;else{R&&(R.status="COMPLETED");const F=1-f;S[F]?.bowlerId===_&&(S[F].status="COMPLETED",S[F]=null),o+=1;const $={inningsIndex:i,spellNumberInInnings:o,endParity:f,bowlerId:_,status:"IN_PROGRESS",startOver:C+1,endOver:C+1,planCounts:new Map,initialPlan:{...r},planChangesCount:0,fieldChangesCount:0,latestFieldSlots:[...c],legalBalls:0,deliveryAttempts:0,runsConceded:0,wickets:0,dots:0,singles:0,boundaries:0,fours:0,sixes:0,wides:0,noBalls:0,intendedLengthMatches:0,intendedLengthEvaluatedBalls:0,executedLengths:{YORKER:0,FULL:0,GOOD:0,SHORT:0,FULL_TOSS:0},trajectories:{GROUND:0,AERIAL:0,EDGE:0,NO_CONTACT:0},fieldOutcomes:{STOP:0,CATCH:0,DROP:0,MISS:0,RUN_OUT:0}};S[f]=$,h=$,p.push($)}continue}if(g.type==="BOWLING_PLAN_CHANGED"){const _=I.line==="OFF"||I.line==="LEG"?I.line:"STUMPS",C=I.length==="YORKER"||I.length==="FULL"||I.length==="SHORT"?I.length:"GOOD",f=I.effort==="CONSERVE"||I.effort==="MAXIMUM"?I.effort:"NORMAL",R=typeof I.variationId=="string"&&I.variationId.length>0?I.variationId:"stock";r={line:_,length:C,variationId:R,effort:f},h&&(h.planChangesCount+=1,h.deliveryAttempts===0&&(h.initialPlan={...r}));continue}if(g.type==="FIELD_CHANGED"){Array.isArray(I.fieldSlots)&&(c=I.fieldSlots.map(_=>({slotId:_.slotId,playerId:_.playerId})),h&&(h.fieldChangesCount+=1,h.latestFieldSlots=[...c]));continue}if(g.type==="OVER_COMPLETED"){h&&h.status==="IN_PROGRESS"&&(h.status="BETWEEN_OVERS");continue}if(g.type==="DELIVERY_RECORDED"){const _=I.event;if(!_)continue;const C=Math.floor(a/6);(!h||h.bowlerId!==_.bowlerId)&&(o+=1,h={inningsIndex:_.inningsIndex,spellNumberInInnings:o,endParity:C%2,bowlerId:_.bowlerId,status:"IN_PROGRESS",startOver:C+1,endOver:C+1,planCounts:new Map,initialPlan:{...r},planChangesCount:0,fieldChangesCount:0,latestFieldSlots:[...c],legalBalls:0,deliveryAttempts:0,runsConceded:0,wickets:0,dots:0,singles:0,boundaries:0,fours:0,sixes:0,wides:0,noBalls:0,intendedLengthMatches:0,intendedLengthEvaluatedBalls:0,executedLengths:{YORKER:0,FULL:0,GOOD:0,SHORT:0,FULL_TOSS:0},trajectories:{GROUND:0,AERIAL:0,EDGE:0,NO_CONTACT:0},fieldOutcomes:{STOP:0,CATCH:0,DROP:0,MISS:0,RUN_OUT:0}},p.push(h)),h.endOver=Math.max(h.endOver,C+1),h.latestFieldSlots=c.length===9?[...c]:h.latestFieldSlots,h.deliveryAttempts+=1;const f=`${r.line}|${r.length}|${r.effort}|${r.variationId}`,R=h.planCounts.get(f);R?R.balls+=1:h.planCounts.set(f,{plan:{...r},balls:1}),_.legalBall&&(h.legalBalls+=1,a+=1);const F=_.batRuns+_.extras.wides+_.extras.noBalls;h.runsConceded+=F,_.legality==="WIDE"&&(h.wides+=_.extras.wides),_.legality==="NO_BALL"&&(h.noBalls+=_.extras.noBalls),_.legalBall&&_.batRuns===0&&_.extras.wides===0&&_.extras.noBalls===0&&_.extras.byes===0&&_.extras.legByes===0&&(h.dots+=1),_.batRuns===1&&_.boundary==="NONE"&&(h.singles+=1),_.boundary==="FOUR"?(h.boundaries+=1,h.fours+=1):_.boundary==="SIX"&&(h.boundaries+=1,h.sixes+=1),_.dismissal&&V1.has(_.dismissal.kind)&&(h.wickets+=1),_.executedLength&&(h.executedLengths[_.executedLength]+=1,h.intendedLengthEvaluatedBalls+=1,_.executedLength===r.length&&(h.intendedLengthMatches+=1)),_.trajectory?h.trajectories[_.trajectory]+=1:h.trajectories.NO_CONTACT+=1,_.fieldOutcome!=="NONE"&&(h.fieldOutcomes[_.fieldOutcome]+=1);const $=y(_.inningsIndex,_.strikerId),D=u.get(_.strikerId)??{...bc},G=`${D.aggression}|${D.intent}`;if(_.countsAsBallFaced){$.ballsFaced+=1;const M=$.planCounts.get(G);M?M.balls+=1:$.planCounts.set(G,{plan:{...D},balls:1}),_.batRuns===0&&($.dots+=1)}if($.runs+=_.batRuns,_.batRuns===1&&_.boundary==="NONE"&&($.singles+=1),(_.boundary==="FOUR"||_.boundary==="SIX")&&($.boundaries+=1),_.dismissal){const M=y(_.inningsIndex,_.dismissal.playerId);M.dismissed=!0}}}const E=p.filter(g=>g.deliveryAttempts>0).map(g=>{let I=g.initialPlan,_=-1;for(const M of g.planCounts.values())M.balls>_&&(_=M.balls,I=M.plan);const C=vc(g.latestFieldSlots),f=xt(g.legalBalls),R=g.legalBalls>0?Math.round(g.runsConceded*600/g.legalBalls):null,F=R===null?"—":(R/100).toFixed(2),$=e[g.bowlerId]??g.bowlerId,G=`${g.status==="COMPLETED"?"Completed spell":g.status==="BETWEEN_OVERS"?"Spell between overs":"Current over"} (overs ${g.startOver}–${g.endOver}): accepted plan targeted ${I.length} length on ${I.line} (${I.effort} effort, ${I.variationId}, ${C.ring} in ring / ${C.boundary} deep). Recorded ${f} overs, ${g.wickets}/${g.runsConceded} (econ ${F}), ${g.intendedLengthMatches}/${g.intendedLengthEvaluatedBalls} on intended length, ${g.dots} dots, ${g.boundaries} boundaries.`;return{spellId:`inn${g.inningsIndex}-spell${g.spellNumberInInnings}-${g.bowlerId}`,inningsIndex:g.inningsIndex,spellNumberInInnings:g.spellNumberInInnings,bowlerId:g.bowlerId,bowlerName:$,status:g.status,startOver:g.startOver,endOver:g.endOver,acceptedPlan:{primaryLine:I.line,primaryLength:I.length,primaryEffort:I.effort,primaryVariationId:I.variationId,latestRingFielders:C.ring,latestBoundaryFielders:C.boundary,latestCloseCatchers:C.closeCatchers,planChangesCount:g.planChangesCount,fieldChangesCount:g.fieldChangesCount},outcomes:{legalBalls:g.legalBalls,oversDisplay:f,deliveryAttempts:g.deliveryAttempts,runsConceded:g.runsConceded,wickets:g.wickets,dots:g.dots,singles:g.singles,boundaries:g.boundaries,fours:g.fours,sixes:g.sixes,wides:g.wides,noBalls:g.noBalls,economyX100:R,intendedLengthMatches:g.intendedLengthMatches,intendedLengthEvaluatedBalls:g.intendedLengthEvaluatedBalls,executedLengths:{...g.executedLengths},trajectories:{...g.trajectories},fieldOutcomes:{...g.fieldOutcomes}},factualSummary:G}}).reverse(),T=A.filter(g=>g.ballsFaced>0||g.runs>0||g.dismissed).map(g=>{let I=g.initialPlan,_=-1;for(const $ of g.planCounts.values())$.balls>_&&(_=$.balls,I=$.plan);const C=g.ballsFaced>0?Math.round(g.runs*1e4/g.ballsFaced):null,f=C===null?"—":(C/100).toFixed(2),R=e[g.playerId]??g.playerId,F=`Accepted plan: aggression ${I.aggression}/4 (${I.intent}). Recorded ${g.runs}${g.dismissed?"":"*"} (${g.ballsFaced}b, SR ${f}), ${g.dots} dots, ${g.singles} singles, ${g.boundaries} boundaries.`;return{stintId:`inn${g.inningsIndex}-bat-${g.playerId}`,inningsIndex:g.inningsIndex,playerId:g.playerId,playerName:R,dismissed:g.dismissed,acceptedPlan:{primaryAggression:I.aggression,primaryIntent:I.intent,planChangesCount:g.planChangesCount},outcomes:{ballsFaced:g.ballsFaced,runs:g.runs,dots:g.dots,singles:g.singles,boundaries:g.boundaries,strikeRateX100:C},factualSummary:F}}).reverse();return{spellReviews:E,battingStintReviews:T}}function W1(n){const e=n.innings[n.activeIndex],t=e?.innings,i=t?.legalBalls??0,a=t?.runs??0,o=t?.wickets??0,r=t?.targetToWin??null,c=t==null?null:t.strikerEnd==="NORTH"?t.northBatterId:t.southBatterId,u=c!=null?n.activeBattingPlans[c]??{aggression:2,intent:"NORMAL"}:null;let p=`${n.format} · ${n.phase}`,S="Named 9-man field · max 5 leg-side · max 2 behind square leg.";n.format==="T20"?i<36?(p="T20 Powerplay (Overs 0.0–5.5)",S="Max 2 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):i<90?(p="T20 Middle Overs (Overs 6.0–14.5)",S="Max 5 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):(p="T20 Late Overs (Overs 15.0–19.5)",S="Max 5 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):n.format==="ODI"?i<60?(p="ODI Powerplay 1 (Overs 0.0–9.5)",S="Max 2 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):i<240?(p="ODI Middle Overs (Overs 10.0–39.5)",S="Max 4 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):(p="ODI Late Overs (Overs 40.0–49.5)",S="Max 5 fielders outside 30-yard circle · max 5 leg-side · max 2 behind square leg."):(p=`Five-day Red-ball · Day ${n.redBallDay??1} · Innings ${n.activeIndex+1}`,S="No circle limit · max 5 leg-side · max 2 behind square leg · new ball at 80.0 overs.");const h=n.format==="T20"?120:n.format==="ODI"?300:null,A=h===null?null:Math.max(0,h-i),N=i>0?(a*6/i).toFixed(2):"0.00",y=r!==null&&A!==null&&A>0?(Math.max(0,r-a)*6/A).toFixed(2):null;let L=t?`${a}/${o} (${xt(i)} ov, CRR ${N}) · ${10-o} wicket${10-o===1?"":"s"} in hand.`:"Match setup complete; awaiting opening innings.";if(t&&r!==null){const D=Math.max(0,r-a);L=A!==null?`Chasing ${r}: need ${D} from ${A} balls (RRR ${y??"—"}, CRR ${N}, ${10-o} wkts in hand).`:`Fourth-innings target ${r}: need ${D} more runs (${10-o} wkts in hand).`}else if(t&&n.format==="RED_BALL"&&n.innings.length>1){const D=t.battingTeamId,G=n.innings.filter(J=>J.innings.battingTeamId===D).reduce((J,V)=>J+V.innings.runs,0),M=n.innings.filter(J=>J.innings.battingTeamId!==D).reduce((J,V)=>J+V.innings.runs,0),q=G-M;L=`${a}/${o} (${xt(i)} ov) · batting side ${q>=0?`leads by ${q}`:`trails by ${Math.abs(q)}`} overall.`}const E=`Seam ${(n.pitch.seamBp/100).toFixed(2)}/100 · Spin ${(n.pitch.turnBp/100).toFixed(2)}/100 · Wear ${n.pitch.wearPoints} pts.`;let T="No active bowler selected.";const g=t?.bowlerId??n.activeBowlingPlan?.bowlerId??null;if(g&&e){const D=e.bowling[g],G=D?.legalBalls??0,M=n.fatigueBpByPlayerId[g]??0,q=n.format==="T20"?24:n.format==="ODI"?60:null,J=q===null?"no over cap":`${xt(Math.max(0,q-G))} ov left in quota`;T=`${n.names[g]??g}: ${xt(G)} ov, ${D?.wickets??0}/${D?.runsConceded??0} · Fatigue ${Math.round(M/100)}% · ${J}.`}const I=M1(u,n.activeBowlingPlan,n.activeFieldSlots),_=[],C=n.format==="T20"&&i>=90||n.format==="ODI"&&i>=240,f=n.format==="T20"&&i>=36&&i<90||n.format==="ODI"&&i>=60&&i<240,R=y===null?null:Number(y);if(c&&u){const D=o>=4&&(A===null||A>24);_.push({presetId:"BAT_CONSOLIDATE",commandKind:"SET_BATTING_PLAN",label:"Consolidate & protect wicket",whenToUse:"Rebuild after early wickets, survive a testing spell, or bat time in red-ball.",tradeOff:"Lowers boundary frequency and passes up tight singles (aggression 1, PROTECT).",contextualMatch:D||n.format==="RED_BALL"&&o>=5,contextualReason:D?`${o} wickets down with overs remaining.`:"",activeNow:u.aggression===1&&u.intent==="PROTECT",battingPatch:{aggression:1,intent:"PROTECT"}},{presetId:"BAT_ROTATE_STRIKE",commandKind:"SET_BATTING_PLAN",label:"Work singles & rotate strike",whenToUse:"Keep the scoreboard moving in middle overs or a measured chase.",tradeOff:"Increases single attempts and run-out exposure against inner-ring fielders (aggression 2, ROTATE).",contextualMatch:f||R!==null&&R>=5&&R<=8,contextualReason:f?"Middle-overs spread field leaves single-taking pockets.":R!==null&&R>=5&&R<=8?`Measured required rate (${y}).`:"",activeNow:u.aggression===2&&u.intent==="ROTATE",battingPatch:{aggression:2,intent:"ROTATE"}},{presetId:"BAT_BALANCED_TEMPO",commandKind:"SET_BATTING_PLAN",label:"Balanced tempo",whenToUse:"Default tempo when building an innings platform without extra run-out risk.",tradeOff:"Neutral contact and running weights (aggression 2, NORMAL).",contextualMatch:!D&&!f&&!C&&(R===null||R<=8),contextualReason:!D&&!f&&!C?"Opening phase platform.":"",activeNow:u.aggression===2&&u.intent==="NORMAL",battingPatch:{aggression:2,intent:"NORMAL"}},{presetId:"BAT_BOUNDARY_PUSH",commandKind:"SET_BATTING_PLAN",label:"Boundary push",whenToUse:"Accelerate in death overs or chase a steep required rate with wickets in hand.",tradeOff:"Sharply increases aerial, edge, and miss dismissal exposure (aggression 4, NORMAL).",contextualMatch:C&&o<=6||R!==null&&R>8.5,contextualReason:R!==null&&R>8.5?`Required rate is ${y} per over.`:C?"Death-overs acceleration window.":"",activeNow:u.aggression===4&&u.intent==="NORMAL",battingPatch:{aggression:4,intent:"NORMAL"}})}if(n.activeBowlingPlan){const D=n.activeBowlingPlan,G=n.fatigueBpByPlayerId[D.bowlerId]??0,M=n.bowlerVariationsByPlayerId[D.bowlerId]??["stock"],q=M.includes("stock")?"stock":M[0]??"stock",J=n.format==="T20"&&i<36||n.format==="ODI"&&i<60;_.push({presetId:"BOWL_DISCIPLINED_CHANNEL",commandKind:"SET_BOWLING_PLAN",label:"Disciplined off-stump channel",whenToUse:"Standard containing and wicket-hunting plan feeding off-side ring and slip fielders.",tradeOff:"Missed lengths spill to FULL rather than yorkers (OFF, GOOD, NORMAL).",contextualMatch:!C&&G<4500,contextualReason:!C&&G<4500?"Controlled channel with fresh bowler.":"",activeNow:D.line==="OFF"&&D.length==="GOOD"&&D.effort==="NORMAL"&&D.variationId===q,bowlingPatch:{line:"OFF",length:"GOOD",effort:"NORMAL",variationId:q}},{presetId:"BOWL_ATTACK_STUMPS",commandKind:"SET_BOWLING_PLAN",label:"Pitch full at the stumps",whenToUse:"Search for bowled/LBW with a new ball, seam/spin movement, or against lower-order batters.",tradeOff:"Length errors become high-scoring full tosses (STUMPS, FULL, NORMAL).",contextualMatch:J||o>=7||n.pitch.seamBp>=5600,contextualReason:o>=7?"Lower order exposed.":J?"Powerplay / new-ball wicket window.":n.pitch.seamBp>=5600?"Above-neutral seam assistance.":"",activeNow:D.line==="STUMPS"&&D.length==="FULL"&&D.effort==="NORMAL"&&D.variationId===q,bowlingPatch:{line:"STUMPS",length:"FULL",effort:"NORMAL",variationId:q}},{presetId:"BOWL_CONSERVE_SPELL",commandKind:"SET_BOWLING_PLAN",label:"Conserve spell accuracy",whenToUse:"Extend a tired bowler's spell or cut extras when fatigue rises above 40%.",tradeOff:"Uses CONSERVE effort rather than maximum pace effort (OFF, GOOD, CONSERVE).",contextualMatch:G>=4e3,contextualReason:G>=4e3?`Active bowler fatigue is ${Math.round(G/100)}%.`:"",activeNow:D.line==="OFF"&&D.length==="GOOD"&&D.effort==="CONSERVE"&&D.variationId===q,bowlingPatch:{line:"OFF",length:"GOOD",effort:"CONSERVE",variationId:q}},{presetId:"BOWL_YORKER_CLOSE",commandKind:"SET_BOWLING_PLAN",label:"Death-overs yorker plan",whenToUse:"Suppress lofted boundaries in the closing overs with a high-control, rested bowler.",tradeOff:"Missed yorkers become full tosses, and MAXIMUM effort adds wide/no-ball and fatigue risk.",contextualMatch:C&&G<4500,contextualReason:C&&G<4500?"Late overs with rested bowler.":"",activeNow:D.line==="STUMPS"&&D.length==="YORKER"&&D.effort==="MAXIMUM"&&D.variationId===q,bowlingPatch:{line:"STUMPS",length:"YORKER",effort:"MAXIMUM",variationId:q}},{presetId:"BOWL_SHORT_TEST",commandKind:"SET_BOWLING_PLAN",label:"Short-ball examination",whenToUse:"Force aerial and edge contact for a short burst when catchers are in place.",tradeOff:"Raises aerial boundary risk plus MAXIMUM effort extras and faster fatigue.",contextualMatch:n.format==="RED_BALL"&&o>=6&&G<3500,contextualReason:n.format==="RED_BALL"&&o>=6&&G<3500?"Rested bowler testing lower order.":"",activeNow:D.line==="OFF"&&D.length==="SHORT"&&D.effort==="MAXIMUM"&&D.variationId===q,bowlingPatch:{line:"OFF",length:"SHORT",effort:"MAXIMUM",variationId:q}})}if(n.outfieldIds.length===9){const D=to(n.outfieldIds,eo(n.format,i,"SLIP_ATTACK")),G=to(n.outfieldIds,eo(n.format,i,"BALANCED_RING")),M=to(n.outfieldIds,eo(n.format,i,"BOUNDARY_PROTECT")),q=n.format==="T20"&&i<36||n.format==="ODI"&&i<60;_.push({presetId:"FIELD_SLIP_ATTACK",commandKind:"SET_FIELD",label:"Attacking two-slip cordon",whenToUse:"Convert edges with a new ball, live seam/spin pitch, or exposed lower order.",tradeOff:"Leaves fewer boundary sweepers if batters clear the infield (7 in ring, 2 slips, 2 deep).",contextualMatch:q||o>=7||n.format==="RED_BALL",contextualReason:q?"Legal 2-out powerplay cordon.":o>=7?"Catching cordon for lower order.":"",activeNow:io(n.activeFieldSlots,D),fieldSlots:D},{presetId:"FIELD_BALANCED_RING",commandKind:"SET_FIELD",label:"Balanced slip & ring",whenToUse:"Keep 1 slip and ring single-saving cover while posting phase-legal sweepers.",tradeOff:"Splits protection between edge catching and deep boundary cover.",contextualMatch:f,contextualReason:f?"Middle-overs ring + sweeper balance.":"",activeNow:io(n.activeFieldSlots,G),fieldSlots:G},{presetId:"FIELD_BOUNDARY_PROTECT",commandKind:"SET_FIELD",label:"Boundary rider defence",whenToUse:"Defend a total in late overs or against high-aggression boundary hitting.",tradeOff:"Removes slips and opens single-taking space inside the circle.",contextualMatch:C||R!==null&&R>8,contextualReason:C?"Maximum phase-legal boundary protection.":R!==null&&R>8?"Chasing side needs boundaries.":"",activeNow:io(n.activeFieldSlots,M),fieldSlots:M})}const{spellReviews:F,battingStintReviews:$}=$1(n.events,n.names,n.activeFieldSlots);return _2.parse({version:la,format:n.format,situation:{phaseLabel:p,fieldRestrictionLabel:S,scoreContextLabel:L,pitchSummaryLabel:E,activeBowlerWorkloadLabel:T},controlGuide:I,presets:_,spellReviews:F,battingStintReviews:$})}const Tc="Illustrative highlight from committed event categories — no measured ball speed, distance, or tracking coordinates.",oo=[{slotId:"slip-1",label:"First slip",sector:7,depth:"INNER",insideCircle:!0,legSideRhb:!1,behindSquare:!0,rhbPoint:{x10:1135,y10:1315}},{slotId:"slip-2",label:"Second slip",sector:7,depth:"INNER",insideCircle:!0,legSideRhb:!1,behindSquare:!0,rhbPoint:{x10:1225,y10:1275}},{slotId:"point",label:"Point",sector:6,depth:"MIDDLE",insideCircle:!0,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1380,y10:1080}},{slotId:"cover",label:"Cover",sector:5,depth:"MIDDLE",insideCircle:!0,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1320,y10:820}},{slotId:"mid-off",label:"Mid-off",sector:4,depth:"MIDDLE",insideCircle:!0,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1145,y10:650}},{slotId:"mid-on",label:"Mid-on",sector:4,depth:"MIDDLE",insideCircle:!0,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:855,y10:650}},{slotId:"midwicket",label:"Midwicket",sector:3,depth:"MIDDLE",insideCircle:!0,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:680,y10:820}},{slotId:"deep-square-leg",label:"Deep square leg",sector:2,depth:"DEEP",insideCircle:!1,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:245,y10:1050}},{slotId:"fine-leg",label:"Fine leg",sector:1,depth:"DEEP",insideCircle:!1,legSideRhb:!0,behindSquare:!0,rhbPoint:{x10:460,y10:1530}},{slotId:"deep-cover",label:"Deep cover",sector:5,depth:"DEEP",insideCircle:!1,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1560,y10:480}},{slotId:"long-on",label:"Long-on",sector:4,depth:"DEEP",insideCircle:!1,legSideRhb:!0,behindSquare:!1,rhbPoint:{x10:790,y10:240}},{slotId:"long-off",label:"Long-off",sector:4,depth:"DEEP",insideCircle:!1,legSideRhb:!1,behindSquare:!1,rhbPoint:{x10:1210,y10:240},odiOnly:!0}],Rc=new Map(oo.map(n=>[n.slotId,n])),Lc={x10:1e3,y10:740},Ac={x10:1e3,y10:1180},U1={x10:1e3,y10:1340};function Oc(n,e){if(!Number.isInteger(n)||n<0||n>7)throw new Error("INVALID_PRESENTATION_SECTOR");return e==="L"?7-n:n}function wc(n,e){return{x10:e==="L"?2e3-n.x10:n.x10,y10:n.y10}}function Nc(n){return n==="ODI"?oo:oo.filter(e=>!e.odiOnly)}function G1(n,e){return n==="T20"?e<36?{maxOutsideCircle:2,phaseLabel:"T20 Powerplay (overs 1–6): max 2 outside circle"}:{maxOutsideCircle:5,phaseLabel:"T20 Overs 7–20: max 5 outside circle"}:n==="ODI"?e<60?{maxOutsideCircle:2,phaseLabel:"ODI Powerplay 1 (overs 1–10): max 2 outside circle"}:e<240?{maxOutsideCircle:4,phaseLabel:"ODI Powerplay 2 (overs 11–40): max 4 outside circle"}:{maxOutsideCircle:5,phaseLabel:"ODI Powerplay 3 (overs 41–50): max 5 outside circle"}:{maxOutsideCircle:9,phaseLabel:"Five-day red-ball: outer circle unrestricted, max 5 leg side, max 2 behind square leg"}}function z1(n){const{format:e,strikerHand:t,legalBalls:i,fieldSlots:a,outfieldIds:o}=n,{maxOutsideCircle:r,phaseLabel:c}=G1(e,i),u=new Set(Nc(e).map(C=>C.slotId)),p=[];if(a.length!==9&&p.push({code:"SLOT_COUNT",message:`Exactly 9 outfielders must be placed (currently ${a.length}).`,affectedSlotIds:[]}),o.length===9){const C=[...a.map(R=>R.playerId)].sort().join("|"),f=[...o].sort().join("|");C!==f&&p.push({code:"UNIQUE_PLAYERS",message:"Every active outfielder must be assigned to exactly one field position.",affectedSlotIds:[]})}else new Set(a.map(C=>C.playerId)).size!==a.length&&p.push({code:"UNIQUE_PLAYERS",message:"Each outfielder may occupy only one position.",affectedSlotIds:[]});const S=new Map;for(const C of a)S.set(C.slotId,(S.get(C.slotId)??0)+1);const h=[...S.entries()].filter(([,C])=>C>1).map(([C])=>C);if(h.length>0){const C=h.map(f=>Rc.get(f)?.label??f);p.push({code:"DUPLICATE_POSITION",message:`Duplicate field position${h.length>1?"s":""}: ${C.join(", ")}.`,affectedSlotIds:h.slice(0,9)})}const A=[...new Set(a.map(C=>C.slotId).filter(C=>!u.has(C)))];A.length>0&&p.push({code:"UNSUPPORTED_POSITION",message:`Unsupported position for ${e}: ${A.join(", ")}.`,affectedSlotIds:A.slice(0,9)});let N=0,y=0,L=0;const E=[],T=[],g=[];for(const C of a){const f=Rc.get(C.slotId);if(!f)continue;f.insideCircle||(N+=1,E.push(C.slotId)),(t==="R"?f.legSideRhb:!f.legSideRhb)&&(y+=1,T.push(C.slotId),f.behindSquare&&(L+=1,g.push(C.slotId)))}N>r&&p.push({code:"CIRCLE_RESTRICTION",message:`Too many fielders outside the 30-yard circle (${N}/${r} allowed in this phase).`,affectedSlotIds:[...new Set(E)].slice(0,9)}),y>5&&p.push({code:"LEG_SIDE_LIMIT",message:`Too many leg-side fielders for ${t==="L"?"left-hand":"right-hand"} striker (${y}/5 maximum).`,affectedSlotIds:[...new Set(T)].slice(0,9)}),L>2&&p.push({code:"BEHIND_SQUARE_LEG_LIMIT",message:`Too many fielders behind square on the leg side (${L}/2 maximum).`,affectedSlotIds:[...new Set(g)].slice(0,9)});const I=p.length===0,_=I?`Legal field (${t}HB): ${N}/${r} outside circle · ${y}/5 leg side · ${L}/2 behind square leg.`:p.map(C=>C.message).join(" ");return rs.parse({isLegal:I,format:e,strikerHand:t,phaseLabel:c,outsideCircleCount:N,maxOutsideCircle:r,legSideCount:y,maxLegSide:5,behindSquareLegCount:L,maxBehindSquareLeg:2,duplicateSlotIds:h,violations:p,summaryText:_.slice(0,320)})}function K1(n,e){const t=n.slice(0,8),i=Number.parseInt(t,16);return((Number.isFinite(i)?i:0)^Math.imul(e,2654435761))>>>0&255}function Y1(n,e){const t=(e%5-2)*5,i=n==="YORKER"?1155:n==="FULL_TOSS"?1170:n==="FULL"?1095:n==="SHORT"?925:1020;return{x10:1e3+t,y10:i}}function j1(n){const{displaySector:e,boundary:t,fieldOutcome:i,runsScored:a,variationByte:o}=n,c=((o>>3)%7-3)*.045,u=(e-3.5)*(Math.PI/4)+c,p=t==="SIX"?895:t==="FOUR"?840:i==="CATCH"?530+o%150:i==="STOP"||a===0?370+o%70:a===1?520+o%80:670+o%90,S=Math.round(1e3+Math.sin(u)*p),h=Math.round(1e3-Math.cos(u)*p);return{x10:Math.max(40,Math.min(1960,S)),y10:Math.max(40,Math.min(1960,h))}}function Z1(n){if(n.dismissal)return{momentKind:"WICKET",isKeyMoment:!0};if(n.boundary==="SIX")return{momentKind:"SIX",isKeyMoment:!0};if(n.boundary==="FOUR")return{momentKind:"FOUR",isKeyMoment:!0};if(n.freeHitNext)return{momentKind:"FREE_HIT",isKeyMoment:!0};const e=n.extras.wides+n.extras.noBalls+n.extras.byes+n.extras.legByes+n.extras.penalties;return n.legality!=="LEGAL"||e>0?{momentKind:"EXTRA",isKeyMoment:!1}:n.batRuns+n.completedRuns>0?{momentKind:"RUNS",isKeyMoment:!1}:{momentKind:"DOT",isKeyMoment:!1}}function X1(n){const{events:e,names:t,hands:i}=n,a=new Map,o=[];for(const r of e){if(r.type!=="DELIVERY_RECORDED")continue;const u=r.payload?.event;if(!u||u.type!=="DELIVERY_RECORDED")continue;const p=a.get(u.inningsIndex)??0,S=u.legalBall?p+1:p;a.set(u.inningsIndex,S);const h=Math.floor((u.legalBall?S-1:p)/6),A=u.legalBall?(S-1)%6+1:p%6+1,N=u.legality==="WIDE"?`${h}.${A}wd`:u.legality==="NO_BALL"?`${h}.${A}nb`:`${h}.${A}`,y=i[u.strikerId]??"R",L=t[u.strikerId]??u.strikerId,E=t[u.bowlerId]??u.bowlerId,T=u.dismissal?t[u.dismissal.playerId]??u.dismissal.playerId:null,g=u.extras.wides+u.extras.noBalls+u.extras.byes+u.extras.legByes+u.extras.penalties,I=u.batRuns+g,{momentKind:_,isKeyMoment:C}=Z1(u),f=K1(r.eventHash,r.sequence),R=Y1(u.executedLength,f),$=typeof u.shotSector=="number"&&Number.isInteger(u.shotSector)&&u.shotSector>=0&&u.shotSector<=7?u.shotSector:null,D=$!==null?Oc($,y):null,G=D!==null?"RECORDED_SECTOR":"PITCH_CHANNEL_ONLY",M=D!==null?j1({displaySector:D,boundary:u.boundary,fieldOutcome:u.fieldOutcome,runsScored:I,variationByte:f}):u.dismissal&&["BOWLED","LBW","HIT_WICKET"].includes(u.dismissal.kind)?{x10:1e3,y10:1190}:{x10:1e3,y10:1330},q=u.dismissal?`WICKET · ${T} (${u.dismissal.kind.toLowerCase().replaceAll("_"," ")})`:u.boundary==="SIX"?`SIX · ${L} off ${E}`:u.boundary==="FOUR"?`FOUR · ${L} off ${E}`:u.freeHitNext?`NO-BALL (Free hit next) · ${I} run${I===1?"":"s"}`:`${N} · ${E} to ${L}: ${I} run${I===1?"":"s"}`,J=$!==null?`Recorded sector ${$+1} (${y}HB display sector ${(D??$)+1})`:"No shot sector recorded (pitch/keeper channel only)",V=u.executedLength?`${u.executedLength.toLowerCase().replaceAll("_"," ")} length`:"unrecorded length",P=u.trajectory?`, ${u.trajectory.toLowerCase()} trajectory`:"",j=`${N}: ${V}${P}. ${J}.`;o.push(da.parse({sequence:r.sequence,eventHash:r.eventHash,inningsIndex:u.inningsIndex,deliveryIndex:u.deliveryIndex,overBallLabel:N,strikerId:u.strikerId,strikerName:L,strikerHand:y,bowlerId:u.bowlerId,bowlerName:E,momentKind:_,isKeyMoment:C,runsScored:I,batRuns:u.batRuns,boundary:u.boundary,legality:u.legality,dismissalKind:u.dismissal?u.dismissal.kind:null,dismissedPlayerName:T,fieldOutcome:u.fieldOutcome,executedLength:u.executedLength,trajectory:u.trajectory,recordedSector:$,displaySector:D,sectorStatus:G,releasePoint:Lc,pitchBouncePoint:R,strikerCreasePoint:Ac,targetPoint:M,headline:q.slice(0,160),detailText:j.slice(0,280),trackingDisclaimer:Tc}))}return o.slice(-24)}function q1(n){const{format:e,phase:t,innings:i,activeIndex:a,fieldSlots:o,events:r,names:c,hands:u}=n,p=i[a]??i[i.length-1]??null,S=p?.innings??null,h=S===null?null:S.strikerEnd==="NORTH"?S.northBatterId:S.southBatterId,A=S===null?null:S.strikerEnd==="NORTH"?S.southBatterId:S.northBatterId,N=S?.bowlerId??null,y=p?.keeperId??null,L=h&&u[h]||"R",E=new Map(o.map(f=>[f.slotId,f.playerId])),T=Nc(e).map(f=>{const R=E.get(f.slotId)??null;return{slotId:f.slotId,label:f.label,sector:f.sector,displaySector:Oc(f.sector,L),depth:f.depth,insideCircle:f.insideCircle,legSideForStriker:L==="R"?f.legSideRhb:!f.legSideRhb,behindSquare:f.behindSquare,point:wc(f.rhbPoint,L),occupiedByPlayerId:R,occupiedByName:R?c[R]??R:null}}),g=z1({format:e,strikerHand:L,legalBalls:S?.legalBalls??0,fieldSlots:o,outfieldIds:p?.outfieldIds??o.map(f=>f.playerId)}),I=X1({events:r,names:c,hands:u}),_=I.length>0?I[I.length-1]:null,C=L==="L"?"Left-hand batter on strike: off side is on the left, leg side is on the right.":"Right-hand batter on strike: off side is on the right, leg side is on the left.";return A2.parse({version:os,format:e,phase:t,activeInningsIndex:Math.min(3,Math.max(0,a)),strikerId:h,strikerName:h?c[h]??h:null,strikerHand:L,nonStrikerId:A,nonStrikerName:A?c[A]??A:null,bowlerId:N,bowlerName:N?c[N]??N:null,keeperId:y,keeperName:y?c[y]??y:null,keeperPoint:U1,bowlerReleasePoint:Lc,strikerPoint:Ac,nonStrikerPoint:wc({x10:935,y10:755},L),boundaryRadiusX10:840,circleRadiusX10:480,positions:T,legality:g,recentHighlights:I,latestHighlight:_,orientationNote:C,trackingDisclaimer:Tc})}const J1=3,Dc=["third man","point","cover","mid-off","mid-on","mid-wicket","square leg","fine leg"],Q1={YORKER:"yorker",FULL:"full",GOOD:"good-length",SHORT:"short",FULL_TOSS:"full-toss"},n3={GROUND:"along the turf",AERIAL:"in the air",EDGE:"off the edge"};function jn(n){let e=2166136261;for(let t=0;t<n.length;t+=1)e^=n.charCodeAt(t),e=Math.imul(e,16777619);return e>>>0}function Zn(n){return(n>>>0).toString(16).padStart(8,"0")}function It(n){return`${Math.floor(n/6)}.${n%6}`}function e3(n){return`${Math.floor(n/6)}.${n%6+1}`}function Ei(n){return`${It(n.legalBalls)}-${n.maidens}-${n.runsConceded}-${n.wickets}`}function t3(n){return n==="T20"?120:n==="ODI"?300:null}function Ft(n,e,t,i,a,o,r){const c=jn(`${t}|${i}|${a}|${n}`),u=Zn(c),p=c%e.length;let S=p,h=!1;if(e.length>1&&r>0){const N=o.slice(-r);if(N.includes(e[p].id))for(let y=1;y<e.length;y+=1){const L=(p+y)%e.length;if(!N.includes(e[L].id)){S=L,h=!0;break}}}const A=e[S];return o.push(A.id),{selected:A,cooldownApplied:h,digest:u}}function i3(n,e,t,i){if(n==="T20"||n==="ODI")return e===1&&i[0]?i[0].runs+1:null;if(e===3&&i.length>=3){let a=0,o=0;for(const c of i)c.battingTeamId===t?a+=c.runs:o+=c.runs;const r=o-a;return r>=0?r+1:null}return null}function a3(n){const e=Math.max(1,Math.min(12,n.repetitionCooldownWindow??J1)),t=n.presentationKey??`lcxxvi-commentary:${n.format}:${n.teamIds[0]}:${n.teamIds[1]}:${n.groundName??"ground"}`,i=Zn(jn(t)),a=[],o=y=>y?n.playerNames[y]??y:"Unknown player",r=y=>y?n.teamNames[y]??y:"Unknown team",c=y=>y===n.teamIds[0]?n.teamIds[1]:n.teamIds[0],u=new Map;let p=0;const S=(y,L)=>{const E=u.get(y);if(E)return E;const T=L??n.teamIds[y%2],g=[...u.values()].filter(_=>_.inningsIndex<y),I={inningsIndex:y,battingTeamId:T,bowlingTeamId:c(T),runs:0,wickets:0,legalBalls:0,declared:!1,targetToWin:i3(n.format,y,T,g),allocatedBalls:t3(n.format),overTeamRuns:0,overWickets:0,overLegalBalls:0,pendingFreeHit:!1,partnershipRuns:0,partnershipBalls:0,batters:new Map,bowlers:new Map};return u.set(y,I),I},h=(y,L)=>{let E=y.batters.get(L);return E||(E={runs:0,ballsFaced:0,fours:0,sixes:0},y.batters.set(L,E)),E},A=(y,L)=>{let E=y.bowlers.get(L);return E||(E={legalBalls:0,maidens:0,runsConceded:0,wickets:0,currentOverBowlerRuns:0,currentOverLegalBalls:0},y.bowlers.set(L,E)),E},N=[];for(let y=0;y<n.events.length;y+=1){const L=n.events[y],E=L.eventHash??`seq-${L.sequence}`;if(L.type==="DELIVERY_RECORDED"){const g=L.payload.event;p=g.inningsIndex;const I=S(g.inningsIndex),_=(n.format==="T20"||n.format==="ODI")&&I.pendingFreeHit,C=e3(I.legalBalls),f=o(g.bowlerId),R=o(g.strikerId),F=o(g.nonStrikerId),$=g.extras.wides+g.extras.noBalls+g.extras.byes+g.extras.legByes+g.extras.penalties,D=g.batRuns+$,G=g.batRuns+g.extras.wides+g.extras.noBalls,M=h(I,g.strikerId),q=M.runs;g.countsAsBallFaced&&(M.ballsFaced+=1),M.runs+=g.batRuns,g.boundary==="FOUR"&&(M.fours+=1),g.boundary==="SIX"&&(M.sixes+=1);const J=A(I,g.bowlerId),V=J.wickets;J.runsConceded+=G,J.currentOverBowlerRuns+=G,g.legalBall&&(J.legalBalls+=1,J.currentOverLegalBalls+=1),g.dismissal&&g.dismissal.creditedBowlerId===g.bowlerId&&(J.wickets+=1);const P=I.partnershipRuns;I.runs+=D,I.overTeamRuns+=D,g.legalBall&&(I.legalBalls+=1,I.overLegalBalls+=1),I.partnershipRuns+=D,(g.legalBall||g.legality==="NO_BALL")&&(I.partnershipBalls+=1);const j=[],tn=[],U=[{slot:"inningsNumber",value:String(g.inningsIndex+1),sourceKind:"EVENT_FIELD",sourceRef:"delivery.inningsIndex"},{slot:"ballCoord",value:C,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.legalBallsBefore"},{slot:"bowlerName",value:f,sourceKind:"EVENT_FIELD",sourceRef:"delivery.bowlerId"},{slot:"strikerName",value:R,sourceKind:"EVENT_FIELD",sourceRef:"delivery.strikerId"},{slot:"teamRuns",value:`${I.runs}/${g.dismissal?I.wickets+1:I.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"}];g.batRuns>0&&(q<200&&M.runs>=200?(j.push("BATTER_DOUBLE_CENTURY"),tn.push(`${R} reaches a double century (${M.runs} off ${M.ballsFaced} balls).`)):q<150&&M.runs>=150?(j.push("BATTER_150"),tn.push(`${R} brings up 150 (${M.runs} off ${M.ballsFaced} balls).`)):q<100&&M.runs>=100?(j.push("BATTER_CENTURY"),tn.push(`Century for ${R} (${M.runs} off ${M.ballsFaced} balls).`)):q<50&&M.runs>=50&&(j.push("BATTER_FIFTY"),tn.push(`Fifty for ${R} (${M.runs} off ${M.ballsFaced} balls).`))),!g.dismissal&&D>0&&(P<150&&I.partnershipRuns>=150?(j.push("PARTNERSHIP_150"),tn.push(`150-run partnership (${I.partnershipRuns} off ${I.partnershipBalls} balls).`)):P<100&&I.partnershipRuns>=100?(j.push("PARTNERSHIP_CENTURY"),tn.push(`100-run stand (${I.partnershipRuns} off ${I.partnershipBalls} balls).`)):P<50&&I.partnershipRuns>=50&&(j.push("PARTNERSHIP_FIFTY"),tn.push(`50-run partnership (${I.partnershipRuns} off ${I.partnershipBalls} balls).`))),V<5&&J.wickets>=5?(j.push("BOWLER_FIVE_FOR"),tn.push(`Five-wicket haul for ${f} (${J.wickets}/${J.runsConceded}).`)):V<3&&J.wickets>=3&&(j.push("BOWLER_THREE_FOR"),tn.push(`Third wicket for ${f} (${J.wickets}/${J.runsConceded}).`));const Z={runs:I.partnershipRuns,balls:I.partnershipBalls};g.dismissal&&(I.wickets+=1,I.overWickets+=1,I.partnershipRuns=0,I.partnershipBalls=0,I.wickets===10&&(j.push("ALL_OUT"),tn.push(`${r(I.battingTeamId)} are all out for ${I.runs}.`))),I.targetToWin!==null&&I.runs>=I.targetToWin&&(j.push("WINNING_DELIVERY"),tn.push(`Winning runs! ${r(I.battingTeamId)} reach ${I.runs}/${I.wickets} to pass the target of ${I.targetToWin}.`),U.push({slot:"targetToWin",value:String(I.targetToWin),sourceKind:"CHASE_PROJECTION",sourceRef:"innings.targetToWin"}));const En=g.shotSector!==null&&Dc[g.shotSector]?Dc[g.shotSector]:null,Le=g.executedLength!==null?Q1[g.executedLength]??g.executedLength.toLowerCase():null,Ae=g.trajectory!==null?n3[g.trajectory]??g.trajectory.toLowerCase():null;En&&U.push({slot:"shotSector",value:En,sourceKind:"EVENT_FIELD",sourceRef:"delivery.shotSector"}),Le&&U.push({slot:"executedLength",value:Le,sourceKind:"EVENT_FIELD",sourceRef:"delivery.executedLength"}),U.push({slot:"batterScore",value:`${M.runs} (${M.ballsFaced})`,sourceKind:"BATTER_PROJECTION",sourceRef:`batter.${g.strikerId}`},{slot:"bowlerFigures",value:Ei(J),sourceKind:"BOWLER_PROJECTION",sourceRef:`bowler.${g.bowlerId}`});const Ie=(n.format==="T20"||n.format==="ODI")&&(g.freeHitNext||g.legality==="NO_BALL");_&&U.push({slot:"isFreeHit",value:"true",sourceKind:"FORMAT_RULE",sourceRef:`${n.format}.freeHitDelivery`}),Ie?(I.pendingFreeHit=!0,U.push({slot:"freeHitNext",value:"FREE_HIT",sourceKind:"FORMAT_RULE",sourceRef:`${n.format}.freeHitNext`})):g.legalBall&&(I.pendingFreeHit=!1);const Oe=n.events[y+1]?.type==="OVER_COMPLETED";g.legalBall&&I.overLegalBalls===6&&!Oe&&(J.currentOverLegalBalls===6&&J.currentOverBowlerRuns===0&&(J.maidens+=1,j.push("MAIDEN_OVER"),tn.push(`Maiden over completed by ${f}.`)),I.overTeamRuns=0,I.overWickets=0,I.overLegalBalls=0,J.currentOverBowlerRuns=0,J.currentOverLegalBalls=0);let Tn="DELIVERY_DOT",Me="DELIVERY",ce=String(D),xn=[];if(g.dismissal){Me="DISMISSAL";const rn=g.dismissal.playerId,dn=o(rn),en=h(I,rn),Pc=rn===g.nonStrikerId,he=g.dismissal.fielderId?o(g.dismissal.fielderId):null;if(ce=Pc?"W (run out NS)":"W",U.push({slot:"dismissedBatter",value:dn,sourceKind:"EVENT_FIELD",sourceRef:"delivery.dismissal.playerId"},{slot:"dismissalKind",value:g.dismissal.kind,sourceKind:"EVENT_FIELD",sourceRef:"delivery.dismissal.kind"},{slot:"dismissedScore",value:`${en.runs} (${en.ballsFaced})`,sourceKind:"BATTER_PROJECTION",sourceRef:`batter.${rn}`}),he&&U.push({slot:"fielderName",value:he,sourceKind:"EVENT_FIELD",sourceRef:"delivery.dismissal.fielderId"}),g.dismissal.kind==="RUN_OUT"&&Pc){Tn="WICKET_RUN_OUT_NON_STRIKER";const Un=he?` by ${he}`:"",lo=g.dismissal.wicketEnd.toLowerCase();xn=[{id:"W_RO_NS_1",render:()=>`${f} to ${R}. Non-striker ${dn} is run out${Un} at the ${lo} end for ${en.runs} (${en.ballsFaced})!`},{id:"W_RO_NS_2",render:()=>`${f} to ${R}. Mix-up in the running — non-striker ${dn} caught short${Un} at the ${lo} end, out for ${en.runs} (${en.ballsFaced}).`},{id:"W_RO_NS_3",render:()=>`${f} to ${R}. Direct trouble at the ${lo} end: non-striker ${dn} run out${Un} for ${en.runs} (${en.ballsFaced}).`}]}else if(g.dismissal.kind==="BOWLED")Tn="WICKET_BOWLED",xn=[{id:"W_BWL_1",render:()=>`${f} bowls ${dn} for ${en.runs} (${en.ballsFaced})!`},{id:"W_BWL_2",render:()=>`${f} to ${R} — through the defence, ${dn} bowled for ${en.runs} (${en.ballsFaced})!`},{id:"W_BWL_3",render:()=>`${f} hits the stumps! ${dn} departs bowled for ${en.runs} (${en.ballsFaced}).`}];else if(g.dismissal.kind==="LBW")Tn="WICKET_LBW",xn=[{id:"W_LBW_1",render:()=>`${f} traps ${dn} lbw for ${en.runs} (${en.ballsFaced})!`},{id:"W_LBW_2",render:()=>`${f} to ${R} — pinned in front, ${dn} out lbw for ${en.runs} (${en.ballsFaced}).`},{id:"W_LBW_3",render:()=>`Up goes the finger! ${f} strikes as ${dn} falls lbw for ${en.runs} (${en.ballsFaced}).`}];else if(g.dismissal.kind==="CAUGHT"){Tn="WICKET_CAUGHT";const Un=he?`caught by ${he}`:"caught";xn=[{id:"W_CT_1",render:()=>`${f} to ${R} — ${dn} ${Un} for ${en.runs} (${en.ballsFaced})!`},{id:"W_CT_2",render:()=>`Taken! ${f} induces the mistake and ${dn} is ${Un} for ${en.runs} (${en.ballsFaced}).`},{id:"W_CT_3",render:()=>`Wicket for ${f}: ${dn} departs, ${Un}, for ${en.runs} (${en.ballsFaced}).`}]}else if(g.dismissal.kind==="STUMPED"){Tn="WICKET_STUMPED";const Un=he?`stumped by ${he}`:"stumped";xn=[{id:"W_ST_1",render:()=>`${f} deceives ${dn} — ${Un} for ${en.runs} (${en.ballsFaced})!`},{id:"W_ST_2",render:()=>`Sharp work behind the stumps! ${dn} is ${Un} off ${f} for ${en.runs} (${en.ballsFaced}).`},{id:"W_ST_3",render:()=>`${f} draws ${dn} out of the crease, ${Un} for ${en.runs} (${en.ballsFaced}).`}]}else if(g.dismissal.kind==="RUN_OUT"){Tn="WICKET_RUN_OUT_STRIKER";const Un=he?` (${he})`:"";xn=[{id:"W_RO_S_1",render:()=>`${f} to ${R} — ${dn} run out${Un} for ${en.runs} (${en.ballsFaced})!`},{id:"W_RO_S_2",render:()=>`Quick throw${Un}! ${dn} is run out for ${en.runs} (${en.ballsFaced}).`},{id:"W_RO_S_3",render:()=>`Short of the ground! ${dn} departs run out${Un} for ${en.runs} (${en.ballsFaced}).`}]}else Tn="WICKET_HIT_WICKET",xn=[{id:"W_HW_1",render:()=>`${f} to ${R} — ${dn} is out hit wicket for ${en.runs} (${en.ballsFaced})!`},{id:"W_HW_2",render:()=>`Unfortunate dismissal: ${dn} disturbs the stumps, out hit wicket off ${f} for ${en.runs} (${en.ballsFaced}).`},{id:"W_HW_3",render:()=>`${dn} falls hit wicket to ${f} for ${en.runs} (${en.ballsFaced}).`}]}else if(g.legality==="WIDE")Tn="DELIVERY_WIDE",ce=`${D}wd`,U.push({slot:"wides",value:String(g.extras.wides),sourceKind:"EVENT_FIELD",sourceRef:"delivery.extras.wides"}),xn=[{id:"DLV_WD_1",render:()=>`${f} strays wide to ${R}; ${D} wide${D===1?"":"s"} added, ball to be re-bowled.`},{id:"DLV_WD_2",render:()=>`${f} misses the radar against ${R} — called wide (${D} extra${D===1?"":"s"}).`},{id:"DLV_WD_3",render:()=>`Wide signalled off ${f} to ${R}: ${D} run${D===1?"":"s"} to the total.`}];else if(g.legality==="NO_BALL"){Tn="DELIVERY_NO_BALL",ce=Ie?`${D}nb (FH)`:`${D}nb`,U.push({slot:"noBalls",value:String(g.extras.noBalls),sourceKind:"EVENT_FIELD",sourceRef:"delivery.extras.noBalls"});const rn=Ie?" Free Hit coming up next.":"",dn=g.batRuns>0?` plus ${g.batRuns} off the bat`:$>g.extras.noBalls?` plus ${$-g.extras.noBalls} extra${$-g.extras.noBalls===1?"":"s"}`:"";xn=[{id:"DLV_NB_1",render:()=>`No-ball called on ${f} to ${R} (${D} run${D===1?"":"s"}${dn}).${rn}`},{id:"DLV_NB_2",render:()=>`${f} oversteps against ${R}: no-ball costs ${D} run${D===1?"":"s"}${dn}.${rn}`},{id:"DLV_NB_3",render:()=>`Front-foot no-ball from ${f} to ${R}, ${D} added${dn}.${rn}`}]}else if(g.boundary==="SIX"){Tn="DELIVERY_SIX",ce="6";const rn=En?` over ${En}`:"";xn=[{id:"DLV_SIX_1",render:()=>`${f} to ${R} — launched${rn} for SIX!`},{id:"DLV_SIX_2",render:()=>`SIX! ${R} clears the rope${rn} off ${f}.`},{id:"DLV_SIX_3",render:()=>`${R} gets hold of ${f} and sends it sailing${rn} for 6.`},{id:"DLV_SIX_4",render:()=>`Maximum! Clean strike by ${R}${rn} off ${f} for six runs.`}]}else if(g.boundary==="FOUR"){Tn="DELIVERY_FOUR",ce="4";const rn=En?` through ${En}`:"";xn=[{id:"DLV_FOUR_1",render:()=>`${f} to ${R} — crisp stroke${rn} for FOUR!`},{id:"DLV_FOUR_2",render:()=>`FOUR! ${R} pierces the gap${rn} off ${f}.`},{id:"DLV_FOUR_3",render:()=>`${R} leans on ${f} and races it away${rn} to the boundary for 4.`},{id:"DLV_FOUR_4",render:()=>`Boundary for ${R}! Timed neatly${rn} off ${f}.`}]}else if(D===0){Tn="DELIVERY_DOT",ce="0";const rn=g.fieldOutcome==="STOP"?En?`, tidy stop at ${En}`:", tidy stop in the ring":"";xn=[{id:"DLV_DOT_1",render:()=>`${f} to ${R}, defended solidly — no run${rn}.`},{id:"DLV_DOT_2",render:()=>`Dot ball from ${f}; ${R} watchful at the crease${rn}.`},{id:"DLV_DOT_3",render:()=>`${f} hits the spot to ${R}, no scoring opportunity${rn}.`},{id:"DLV_DOT_4",render:()=>`${R} plays ${f} back safely — dot ball${rn}.`}]}else if(g.batRuns===0&&(g.extras.byes>0||g.extras.legByes>0)){Tn="DELIVERY_BYES_LEGBYES";const rn=g.extras.legByes>0?"lb":"b",dn=g.extras.legByes>0?"leg-bye":"bye";ce=`${D}${rn}`,xn=[{id:"DLV_BLB_1",render:()=>`${f} to ${R}: ${D} ${dn}${D===1?"":"s"} scampered through.`},{id:"DLV_BLB_2",render:()=>`Past the bat off ${f}; ${R} and ${F} cross for ${D} ${dn}${D===1?"":"s"}.`},{id:"DLV_BLB_3",render:()=>`${D} ${dn}${D===1?"":"s"} signalled as ${f} goes past ${R}.`}]}else if(D===1){Tn="DELIVERY_SINGLE",ce="1";const rn=En?` toward ${En}`:"";xn=[{id:"DLV_ONE_1",render:()=>`${f} to ${R}, worked${rn} for a single.`},{id:"DLV_ONE_2",render:()=>`${R} nudges ${f}${rn} to rotate the strike — 1 run.`},{id:"DLV_ONE_3",render:()=>`Quick single taken by ${R}${rn} off ${f}.`},{id:"DLV_ONE_4",render:()=>`${R} taps ${f}${rn} and crosses cleanly for 1.`}]}else{Tn="DELIVERY_MULTI_RUN",ce=String(D);const rn=En?` into ${En}`:"";xn=[{id:"DLV_MULTI_1",render:()=>`${f} to ${R}, placed${rn} and they come back for ${D} runs.`},{id:"DLV_MULTI_2",render:()=>`Good running between ${R} and ${F}${rn} off ${f} — ${D} runs.`},{id:"DLV_MULTI_3",render:()=>`${R} works ${f}${rn} in the gap for ${D} runs.`}]}j.length>0&&Me==="DELIVERY"&&(Me="MILESTONE");const X=Ft(Tn,xn,t,L.sequence,E,a,e),hn=!g.dismissal&&g.fieldOutcome==="DROP"?" Dropped chance in the field!":!g.dismissal&&g.fieldOutcome==="MISS"?" Misfield concedes extra ground.":"",Rn=tn.length>0?` ${tn.join(" ")}`:"",vi=`Innings ${g.inningsIndex+1}, ${C}: ${X.selected.render()}${hn}${Rn}`,Ve=[];_&&Ve.push("free-hit delivery"),Le&&Ve.push(`${Le} length`),Ae&&Ve.push(Ae),En&&Ve.push(`sector: ${En}`);const D3=Ve.length>0?` [${Ve.join(", ")}]`:"",C3=g.dismissal?`Stand ended on ${Z.runs} (${Z.balls}b)`:`Stand ${I.partnershipRuns} (${I.partnershipBalls}b)`,y3=I.targetToWin!==null&&I.runs<I.targetToWin?I.allocatedBalls!==null?` · Need ${I.targetToWin-I.runs} off ${Math.max(0,I.allocatedBalls-I.legalBalls)}b`:` · Need ${I.targetToWin-I.runs} more to win`:"",k3=`${vi}${D3} — Score ${I.runs}/${I.wickets}; ${R} ${M.runs} (${M.ballsFaced}), ${f} ${Ei(J)}, ${C3}${y3}.`;N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:Me,templateId:X.selected.id,templateFamily:Tn,cooldownApplied:X.cooldownApplied,presentationDigest:X.digest,milestoneTags:j,short:`${C} · ${ce}`,text:vi,detailed:k3,factSlots:U});continue}if(L.type==="OVER_COMPLETED"){const g=L.payload,I=S(p),_=Math.floor(I.legalBalls/6),C=o(g.bowlerId),f=A(I,g.bowlerId),R=f.currentOverLegalBalls===6&&f.currentOverBowlerRuns===0;R&&(f.maidens+=1);const F=I.overTeamRuns,$=I.overWickets;I.overTeamRuns=0,I.overWickets=0,I.overLegalBalls=0,f.currentOverBowlerRuns=0,f.currentOverLegalBalls=0;const D=R?["MAIDEN_OVER"]:[],G=r(I.battingTeamId),M=Ei(f),q=I.targetToWin!==null&&I.runs<I.targetToWin?I.allocatedBalls!==null?` (${I.targetToWin-I.runs} needed from ${Math.max(0,I.allocatedBalls-I.legalBalls)} balls)`:` (${I.targetToWin-I.runs} needed to win)`:"",J=R?"OVER_MAIDEN":"OVER_SUMMARY",P=Ft(J,R?[{id:"OV_MDN_1",render:()=>`End of over ${_} (maiden from ${C}): ${G} ${I.runs}/${I.wickets}${q}.`},{id:"OV_MDN_2",render:()=>`Maiden over! ${C} closes over ${_} without conceding off the bat or bowling extras — ${G} ${I.runs}/${I.wickets}${q}.`},{id:"OV_MDN_3",render:()=>`Over ${_} complete, a probing maiden by ${C}. ${G} stand at ${I.runs}/${I.wickets}${q}.`}]:[{id:"OV_SUM_1",render:()=>`End of over ${_} (${F} run${F===1?"":"s"}${$>0?`, ${$} wkt${$===1?"":"s"}`:""}): ${G} ${I.runs}/${I.wickets}${q}.`},{id:"OV_SUM_2",render:()=>`Over ${_} complete — ${F} off it${$>0?` and ${$} wicket${$===1?"":"s"}`:""}. ${G} are ${I.runs}/${I.wickets}${q}.`},{id:"OV_SUM_3",render:()=>`After ${_} over${_===1?"":"s"}, ${G} move to ${I.runs}/${I.wickets} (${F} from ${C}'s over)${q}.`}],t,L.sequence,E,a,e),j=P.selected.render();N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"OVER",templateId:P.selected.id,templateFamily:J,cooldownApplied:P.cooldownApplied,presentationDigest:P.digest,milestoneTags:D,short:`Ov ${_}: ${I.runs}/${I.wickets}${R?" (M)":""}`,text:j,detailed:`${j} ${C} figures: ${M}; current stand ${I.partnershipRuns} (${I.partnershipBalls}b).`,factSlots:[{slot:"overNumber",value:String(_),sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.completedOvers"},{slot:"overRuns",value:String(F),sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.overTeamRuns"},{slot:"inningsScore",value:`${I.runs}/${I.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"},{slot:"bowlerFigures",value:M,sourceKind:"BOWLER_PROJECTION",sourceRef:`bowler.${g.bowlerId}`}]});continue}if(L.type==="INNINGS_STARTED"){const g=L.payload;p=g.inningsIndex;const I=S(g.inningsIndex,g.battingTeamId),_=r(I.battingTeamId),C=I.targetToWin!==null?I.allocatedBalls!==null?` chasing ${I.targetToWin} from ${Math.floor(I.allocatedBalls/6)} overs`:` requiring ${I.targetToWin} to win`:"",f=Ft("INNINGS_STARTED",[{id:"INN_START_1",render:()=>`Start of innings ${g.inningsIndex+1}: ${_} begin batting${C}.`},{id:"INN_START_2",render:()=>`Opening innings ${g.inningsIndex+1} — ${_} take the crease${C}.`}],t,L.sequence,E,a,e),R=f.selected.render(),F=[{slot:"inningsNumber",value:String(g.inningsIndex+1),sourceKind:"EVENT_FIELD",sourceRef:"event.inningsIndex"},{slot:"battingTeam",value:_,sourceKind:"EVENT_FIELD",sourceRef:"event.battingTeamId"}];I.targetToWin!==null&&F.push({slot:"targetToWin",value:String(I.targetToWin),sourceKind:"CHASE_PROJECTION",sourceRef:"innings.targetToWin"}),N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"INNINGS",templateId:f.selected.id,templateFamily:"INNINGS_STARTED",cooldownApplied:f.cooldownApplied,presentationDigest:f.digest,milestoneTags:[],short:`Inn ${g.inningsIndex+1}: ${_}`,text:R,detailed:`${R} Format: ${n.format}.`,factSlots:F});continue}if(L.type==="INNINGS_COMPLETED"){const g=L.payload,I=S(g.inningsIndex),_=r(I.battingTeamId),C=It(I.legalBalls),f=I.wickets>=10,R=f?`End of innings ${g.inningsIndex+1}: ${_} all out for ${I.runs} in ${C} overs.`:`End of innings ${g.inningsIndex+1}: ${_} close on ${I.runs}/${I.wickets} (${C} overs).`;N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"INNINGS",templateId:f?"INN_END_ALL_OUT":"INN_END_CLOSED",templateFamily:"INNINGS_COMPLETED",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|INN_END`)),milestoneTags:f?["ALL_OUT"]:[],short:`End Inn ${g.inningsIndex+1}: ${I.runs}/${I.wickets}`,text:R,detailed:`${R} Legal deliveries: ${I.legalBalls}.`,factSlots:[{slot:"inningsNumber",value:String(g.inningsIndex+1),sourceKind:"EVENT_FIELD",sourceRef:"event.inningsIndex"},{slot:"inningsTotal",value:`${I.runs}/${I.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"},{slot:"overs",value:C,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.legalBalls"}]});continue}if(L.type==="MATCH_COMPLETED"){const g=L.payload.result;let I="Match complete",_="Match completed.";const C=[];if(g)if(C.push({slot:"resultKind",value:g.kind,sourceKind:"MATCH_RESULT",sourceRef:"result.kind"}),g.kind==="WIN"){const R=r(g.winnerTeamId);C.push({slot:"winnerTeam",value:R,sourceKind:"MATCH_RESULT",sourceRef:"result.winnerTeamId"}),g.marginType==="RUNS"?(I=`${R} won by ${g.marginRuns} runs`,_=`Result: ${R} win by ${g.marginRuns} run${g.marginRuns===1?"":"s"}.`,C.push({slot:"marginRuns",value:String(g.marginRuns),sourceKind:"MATCH_RESULT",sourceRef:"result.marginRuns"})):g.marginType==="WICKETS"?(I=`${R} won by ${g.marginWickets} wkts`,_=`Result: ${R} win by ${g.marginWickets} wicket${g.marginWickets===1?"":"s"}.`,C.push({slot:"marginWickets",value:String(g.marginWickets),sourceKind:"MATCH_RESULT",sourceRef:"result.marginWickets"})):(I=`${R} won by innings & ${g.marginRuns}`,_=`Result: ${R} win by an innings and ${g.marginRuns} run${g.marginRuns===1?"":"s"}.`,C.push({slot:"marginRuns",value:String(g.marginRuns),sourceKind:"MATCH_RESULT",sourceRef:"result.marginRuns"}))}else g.kind==="TIE"?(I="Match tied",_=`Result: Match tied (${g.completionReason}).`):g.kind==="DRAW"?(I="Match drawn",_=`Result: Match drawn (${g.completionReason}).`):(I="No result",_=`Result: No result (${g.completionReason}).`);else C.push({slot:"eventType",value:L.type,sourceKind:"EVENT_FIELD",sourceRef:"event.type"});const f=[...u.values()].sort((R,F)=>R.inningsIndex-F.inningsIndex).map(R=>`${r(R.battingTeamId)} ${R.runs}/${R.wickets}${R.declared?"d":""} (${It(R.legalBalls)} ov)`).join("; ");N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"RESULT",templateId:`RESULT_${g?.kind??"COMPLETE"}`,templateFamily:"MATCH_COMPLETED",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|RESULT`)),milestoneTags:[],short:I,text:_,detailed:f?`${_} Final scores: ${f}.`:_,factSlots:C});continue}if(L.type==="TOSS_RESOLVED"){const g=L.payload,I=r(g.winnerId),_=g.coin.toLowerCase(),C=`Toss: ${_}. ${I} won the toss.`;N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"SELECTION",templateId:"TOSS_RESOLVED_1",templateFamily:"TOSS_RESOLVED",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|TOSS`)),milestoneTags:[],short:`Toss: ${I} (${_})`,text:C,detailed:g.callerId&&g.call?`${C} (${r(g.callerId)} called ${g.call.toLowerCase()}).`:C,factSlots:[{slot:"coin",value:_,sourceKind:"EVENT_FIELD",sourceRef:"event.coin"},{slot:"winnerTeam",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.winnerId"}]});continue}if(L.type==="BATTER_SELECTED"){const g=L.payload.playerId,I=o(g),_=S(p),C=Ft("BATTER_SELECTED",[{id:"BAT_SEL_1",render:()=>`${I} comes in to bat.`},{id:"BAT_SEL_2",render:()=>`${I} walks to the crease.`}],t,L.sequence,E,a,e),f=C.selected.render();N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"SELECTION",templateId:C.selected.id,templateFamily:"BATTER_SELECTED",cooldownApplied:C.cooldownApplied,presentationDigest:C.digest,milestoneTags:[],short:`In: ${I}`,text:f,detailed:`${f} (${r(_.battingTeamId)} ${_.runs}/${_.wickets}).`,factSlots:[{slot:"batterName",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.playerId"}]});continue}if(L.type==="BOWLER_SELECTED"){const g=L.payload.playerId,I=o(g),_=S(p),C=Ei(A(_,g)),f=Ft("BOWLER_SELECTED",[{id:"BWL_SEL_1",render:()=>`${I} will bowl.`},{id:"BWL_SEL_2",render:()=>`${I} comes into the attack.`}],t,L.sequence,E,a,e),R=f.selected.render();N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"SELECTION",templateId:f.selected.id,templateFamily:"BOWLER_SELECTED",cooldownApplied:f.cooldownApplied,presentationDigest:f.digest,milestoneTags:[],short:`Bowl: ${I}`,text:R,detailed:`${R} Current figures: ${C}.`,factSlots:[{slot:"bowlerName",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.playerId"},{slot:"bowlerFigures",value:C,sourceKind:"BOWLER_PROJECTION",sourceRef:`bowler.${g}`}]});continue}if(L.type==="RAIN_DELAY"){const g=L.payload.seconds,I=Math.round(g/60),_=`Weather delay: ${I} minute${I===1?"":"s"} lost to rain.`;N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"CONDITIONS",templateId:"RAIN_DELAY_1",templateFamily:"RAIN_DELAY",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|RAIN`)),milestoneTags:[],short:`Rain (${I}m)`,text:_,detailed:`${_} (${g} seconds deducted from playing time).`,factSlots:[{slot:"lostMinutes",value:`${I} minute${I===1?"":"s"}`,sourceKind:"EVENT_FIELD",sourceRef:"event.seconds"}]});continue}if(L.type==="DECLARED"){const g=L.payload.teamId,I=r(g),_=S(p);_.declared=!0;const C=`${I} declared the innings at ${_.runs}/${_.wickets}.`;N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"TACTICAL",templateId:"DECLARED_1",templateFamily:"DECLARED",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|DECL`)),milestoneTags:[],short:`Declared (${_.runs}/${_.wickets}d)`,text:C,detailed:`${C} (${It(_.legalBalls)} overs bowled).`,factSlots:[{slot:"declaringTeam",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.teamId"},{slot:"declaredTotal",value:`${_.runs}/${_.wickets}`,sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.scoreAfter"}]});continue}if(L.type==="FOLLOW_ON_CHOSEN"){const g=!!L.payload.enforce,I=g?"Follow-on enforced.":"Follow-on declined.";N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"TACTICAL",templateId:g?"FOLLOW_ON_ENFORCED":"FOLLOW_ON_DECLINED",templateFamily:"FOLLOW_ON_CHOSEN",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|FO`)),milestoneTags:[],short:I,text:I,detailed:g?`${I} The trailing side will bat again immediately.`:`${I} The leading side elects to bat again.`,factSlots:[{slot:"followOnEnforced",value:String(g),sourceKind:"EVENT_FIELD",sourceRef:"event.enforce"}]});continue}if(L.type==="NEW_BALL_TAKEN"){const g=S(p),I="New ball taken.";N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"TACTICAL",templateId:"NEW_BALL_TAKEN_1",templateFamily:"NEW_BALL_TAKEN",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|NB`)),milestoneTags:[],short:"New ball",text:I,detailed:`${I} Taken after ${It(g.legalBalls)} overs with the score at ${g.runs}/${g.wickets}.`,factSlots:[{slot:"oversAtNewBall",value:It(g.legalBalls),sourceKind:"INNINGS_PROJECTION",sourceRef:"innings.legalBalls"}]});continue}if(L.type==="BATTING_PLAN_CHANGED"){const g=L.payload,I=o(g.playerId),_=`Batting plan updated for ${I}: aggression ${g.aggression}, ${g.intent.toLowerCase()} intent.`;N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"TACTICAL",templateId:"BAT_PLAN_1",templateFamily:"BATTING_PLAN_CHANGED",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|BATP`)),milestoneTags:[],short:`Bat plan: ${I}`,text:_,detailed:_,factSlots:[{slot:"batterName",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.playerId"},{slot:"aggression",value:String(g.aggression),sourceKind:"EVENT_FIELD",sourceRef:"event.aggression"}]});continue}if(L.type==="BOWLING_PLAN_CHANGED"){const g=L.payload,I=o(g.bowlerId),_=`Bowling plan for ${I}: ${g.line.toLowerCase()} line, ${g.length.toLowerCase().replaceAll("_"," ")} length (${g.effort.toLowerCase()} effort).`;N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"TACTICAL",templateId:"BWL_PLAN_1",templateFamily:"BOWLING_PLAN_CHANGED",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|BWLP`)),milestoneTags:[],short:`Bowl plan: ${I}`,text:_,detailed:_,factSlots:[{slot:"bowlerName",value:I,sourceKind:"EVENT_FIELD",sourceRef:"event.bowlerId"},{slot:"line",value:g.line.toLowerCase(),sourceKind:"EVENT_FIELD",sourceRef:"event.line"},{slot:"length",value:g.length.toLowerCase(),sourceKind:"EVENT_FIELD",sourceRef:"event.length"}]});continue}if(L.type==="FIELD_CHANGED"){const g=L.payload.fieldSlots,I="Field placement adjusted.",_=g.slice(0,4).map(C=>C.slotId.toLowerCase().replaceAll("_"," ")).join(", ");N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"TACTICAL",templateId:"FIELD_CHANGED_1",templateFamily:"FIELD_CHANGED",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|FLD`)),milestoneTags:[],short:"Field adjusted",text:I,detailed:_?`${I} Key ring/slip posts include ${_}.`:I,factSlots:[{slot:"slotCount",value:String(g.length),sourceKind:"EVENT_FIELD",sourceRef:"event.fieldSlots"}]});continue}if(L.type==="TEAMS_CONFIRMED"){const g=r(n.teamIds[0]),I=r(n.teamIds[1]),_=`Teams confirmed: ${g} vs ${I}.`;N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"SELECTION",templateId:"TEAMS_CONFIRMED_1",templateFamily:"TEAMS_CONFIRMED",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|TC`)),milestoneTags:[],short:`${g} v ${I}`,text:_,detailed:n.groundName?`${_} Venue: ${n.groundName} (${n.format}).`:`${_} Format: ${n.format}.`,factSlots:[{slot:"homeTeam",value:g,sourceKind:"INNINGS_PROJECTION",sourceRef:"match.teamIds[0]"},{slot:"awayTeam",value:I,sourceKind:"INNINGS_PROJECTION",sourceRef:"match.teamIds[1]"}]});continue}const T=L.type.replaceAll("_"," ").toLowerCase();N.push({adapterVersion:Dn,sequence:L.sequence,eventType:L.type,category:"SELECTION",templateId:"EVENT_GENERIC_FALLBACK",templateFamily:"EVENT_GENERIC",cooldownApplied:!1,presentationDigest:Zn(jn(`${t}|${L.sequence}|${E}|GEN`)),milestoneTags:[],short:T,text:T,detailed:T,factSlots:[{slot:"eventType",value:L.type,sourceKind:"EVENT_FIELD",sourceRef:"event.type"}]})}return{adapterVersion:Dn,format:n.format,presentationKeyDigest:i,repetitionCooldownWindow:e,entries:N}}const o3=4500,r3=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]);function pe(n,e){return n>>>e|n<<32-e}function s3(n){const e=new TextEncoder().encode(n),t=e.length*8,i=Math.ceil((e.length+9)/64)*64,a=new Uint8Array(i);a.set(e),a[e.length]=128;const o=new DataView(a.buffer);o.setUint32(i-8,Math.floor(t/4294967296),!1),o.setUint32(i-4,t>>>0,!1);const r=new Uint32Array([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),c=new Uint32Array(64);for(let u=0;u<i;u+=64){for(let T=0;T<16;T+=1)c[T]=o.getUint32(u+T*4,!1);for(let T=16;T<64;T+=1){const g=pe(c[T-15],7)^pe(c[T-15],18)^c[T-15]>>>3,I=pe(c[T-2],17)^pe(c[T-2],19)^c[T-2]>>>10;c[T]=c[T-16]+g+c[T-7]+I>>>0}let p=r[0],S=r[1],h=r[2],A=r[3],N=r[4],y=r[5],L=r[6],E=r[7];for(let T=0;T<64;T+=1){const g=pe(N,6)^pe(N,11)^pe(N,25),I=N&y^~N&L,_=E+g+I+r3[T]+c[T]>>>0,C=pe(p,2)^pe(p,13)^pe(p,22),f=p&S^p&h^S&h,R=C+f>>>0;E=L,L=y,y=N,N=A+_>>>0,A=h,h=S,S=p,p=_+R>>>0}r[0]=r[0]+p>>>0,r[1]=r[1]+S>>>0,r[2]=r[2]+h>>>0,r[3]=r[3]+A>>>0,r[4]=r[4]+N>>>0,r[5]=r[5]+y>>>0,r[6]=r[6]+L>>>0,r[7]=r[7]+E>>>0}return Array.from(r).map(u=>u.toString(16).padStart(8,"0")).join("")}const c3=[{assetId:"lc-sfx-bat-dot-v1",cueKind:"BAT_BALL_DOT",channel:"EFFECTS",title:"Willow tap — defensive dot",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"triangle-210Hz->120Hz-bandpass-65ms",durationMs:75},{assetId:"lc-sfx-bat-single-v1",cueKind:"BAT_BALL_SINGLE",channel:"EFFECTS",title:"Crisp bat knock — rotated single/runs",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"triangle-340Hz->165Hz-click-95ms",durationMs:105},{assetId:"lc-crowd-boundary-four-v1",cueKind:"BOUNDARY_FOUR",channel:"CROWD",title:"Sweet-spot drive + boundary applause swell",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"harmonic-knock-440Hz+bandpass-applause-680ms",durationMs:720},{assetId:"lc-crowd-boundary-six-v1",cueKind:"BOUNDARY_SIX",channel:"CROWD",title:"Lofted strike + full stadium roar",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"harmonic-strike-520Hz+warm-crowd-swell-960ms",durationMs:980},{assetId:"lc-sfx-wicket-fall-v1",cueKind:"WICKET_FALL",channel:"EFFECTS",title:"Timber rattle + crowd gasp",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"dual-stump-resonance-610Hz-390Hz+crowd-hush-820ms",durationMs:840},{assetId:"lc-sfx-milestone-chime-v1",cueKind:"MILESTONE_CHIME",channel:"CROWD",title:"Milestone applause & fifth-chord chime",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"sine-triad-523Hz-659Hz-784Hz+soft-applause-640ms",durationMs:680},{assetId:"lc-sfx-over-bell-v1",cueKind:"OVER_BELL",channel:"EFFECTS",title:"End-of-over brass chime",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"sine-bell-660Hz-880Hz-240ms",durationMs:260},{assetId:"lc-sfx-innings-change-v1",cueKind:"INNINGS_CHANGE",channel:"CROWD",title:"Innings interval pavilion chime",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"warm-chord-392Hz-494Hz-587Hz-540ms",durationMs:560},{assetId:"lc-crowd-match-complete-v1",cueKind:"MATCH_COMPLETE",channel:"CROWD",title:"Full-time pavilion fanfare & crowd ovation",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"major-fanfare-523Hz-659Hz-784Hz-1046Hz+ovation-1100ms",durationMs:1150},{assetId:"lc-ui-click-v1",cueKind:"UI_CLICK",channel:"INTERFACE",title:"Subtle tactile slate click",author:"Lord Cricket XXVI Original Synth",license:"MIT_ORIGINAL_LORD_CRICKET_XXVI",origin:"ORIGINAL_PROCEDURAL_SYNTH",synthesisProfile:"sine-tick-740Hz->420Hz-35ms",durationMs:40}].map(n=>({...n,sha256:s3(JSON.stringify({assetId:n.assetId,cueKind:n.cueKind,channel:n.channel,license:n.license,origin:n.origin,synthesisProfile:n.synthesisProfile,durationMs:n.durationMs}))})),l3={manifestVersion:ss,attributionNotice:"All audio cues are synthesized offline in-repo from original mathematical waveforms and noise envelopes owned by Lord Cricket XXVI (MIT). No third-party commercial sound recordings, voices, or network audio streams are used.",networkCallsAllowed:!1,assets:[...c3]};function d3(n,e=l3){return e.assets.find(t=>t.cueKind===n)??null}function ro(n,e){return n.factSlots.find(t=>t.slot===e)?.value}function u3(n){if(n.category==="RESULT")return{cueKind:"MATCH_COMPLETE",channel:"CROWD",priority:95,caption:`Match complete: ${n.short}`,narrationText:n.text};if(n.category==="INNINGS")return{cueKind:"INNINGS_CHANGE",channel:"CROWD",priority:75,caption:`Innings update: ${n.short}`,narrationText:n.text};if(n.category==="DISMISSAL")return{cueKind:"WICKET_FALL",channel:"EFFECTS",priority:92,caption:`Wicket! ${n.short}`,narrationText:n.text};if(n.milestoneTags.some(e=>["BATTER_FIFTY","BATTER_CENTURY","BATTER_150","BATTER_DOUBLE_CENTURY","PARTNERSHIP_FIFTY","PARTNERSHIP_CENTURY","PARTNERSHIP_150","BOWLER_THREE_FOR","BOWLER_FIVE_FOR"].includes(e))){const e=ro(n,"boundary"),t=n.milestoneTags.join(", ").replace(/_/g," ").toLowerCase();return{cueKind:"MILESTONE_CHIME",channel:"CROWD",priority:e==="6"?88:82,caption:`Milestone (${t}): ${n.short}`,narrationText:n.text}}if(n.category==="OVER")return{cueKind:"OVER_BELL",channel:"EFFECTS",priority:55,caption:`Over complete: ${n.short}`,narrationText:n.short};if(n.category==="DELIVERY"){const e=ro(n,"boundary"),t=Number(ro(n,"runs")??"0");return e==="6"?{cueKind:"BOUNDARY_SIX",channel:"CROWD",priority:86,caption:`SIX! ${n.short}`,narrationText:n.text}:e==="4"?{cueKind:"BOUNDARY_FOUR",channel:"CROWD",priority:80,caption:`FOUR! ${n.short}`,narrationText:n.text}:t>0?{cueKind:"BAT_BALL_SINGLE",channel:"EFFECTS",priority:35,caption:n.short}:{cueKind:"BAT_BALL_DOT",channel:"EFFECTS",priority:20,caption:n.short}}return null}function m3(n){const e=n.maxCues??48,t=[...n.commentaryEntries].sort((o,r)=>o.sequence-r.sequence),i=e>0?t.slice(-e):t,a=[];for(const o of i){const r=u3(o);if(!r)continue;const c=d3(r.cueKind);c&&a.push({cueId:`${n.matchId}:${o.sequence}:${r.cueKind}`,sequence:o.sequence,channel:r.channel,cueKind:r.cueKind,assetId:c.assetId,priority:r.priority,caption:r.caption.slice(0,280),...r.narrationText?{narrationText:r.narrationText.slice(0,360)}:{},ttlMs:o3})}return{adapterVersion:ua,matchId:n.matchId,format:n.format,cues:a}}const Cc="Transparent Game Award: batting (runs, boundaries, milestones, not-out, format-par strike rate) + bowling (24 pts/wkt, 3w/5w hauls, maidens, format-par economy) + attributable fielding (catches 7, stumpings 9, run-outs 11) + modest winning-team bonus (5 pts; standout losing performances can still win).",g3={T20:13e3,ODI:9200,RED_BALL:5500},p3={T20:750,ODI:520,RED_BALL:320},I3={T20:12,ODI:24,RED_BALL:30};function yc(n,e,t){return Math.max(e,Math.min(t,Math.round(n)))}function h3(n,e){if(!n)return{byPlayer:new Map,evaluated:!1};const t=new Map;for(const i of n){if(i.type!=="DELIVERY_RECORDED")continue;const o=i.payload?.event,r=o?.dismissal;if(!r||!r.fielderId)continue;const c=r.fielderId,u=e[c]??o?.bowlingTeamId??"unknown",p=t.get(c)??{teamId:u,catches:0,stumpings:0,runOuts:0};r.kind==="CAUGHT"?p.catches+=1:r.kind==="STUMPED"?p.stumpings+=1:r.kind==="RUN_OUT"&&(p.runOuts+=1),t.set(c,p)}return{byPlayer:t,evaluated:!0}}function f3(n){return{byPlayer:new Map(n.map(e=>[e.playerId,{teamId:e.teamId,catches:e.catches,stumpings:e.stumpings,runOuts:e.runOuts}])),evaluated:!0}}function E3(n,e){if(!n.batted)return 0;let t=n.runs*100;if(n.runs>=150?t+=5e3:n.runs>=100?t+=3500:n.runs>=50?t+=1500:n.runs>=30&&(t+=500),n.notOutWithRuns&&n.runs>=20&&(t+=400),t+=n.sixes*150+n.fours*50,n.ballsFaced>=10&&n.runs>=15){const i=Math.round(n.runs*1e4/n.ballsFaced),a=g3[e];t+=yc((i-a)*Math.min(40,n.ballsFaced)/250,-600,1400)}return t}function S3(n,e){if(!n.bowled)return 0;let t=n.wickets*2400;if(n.wickets>=5?t+=3e3:n.wickets>=3&&(t+=1200),t+=n.maidens*500,n.legalBalls>=I3[e]){const i=Math.round(n.runsConceded*600/n.legalBalls),a=p3[e],o=n.legalBalls/6;t+=yc((a-i)*Math.min(8,o)/4,-900,1600)}return t}function _3(n){return n.catches*700+n.stumpings*900+n.runOuts*1100}function v3(n){const e=[];if(n.batted&&e.push(`${n.runs}${n.notOutWithRuns?"*":""} (${n.ballsFaced})`),n.bowled&&e.push(`${n.wickets}/${n.runsConceded} (${Math.floor(n.legalBalls/6)}.${n.legalBalls%6})`),n.catches+n.stumpings+n.runOuts>0){const i=[];n.catches>0&&i.push(`${n.catches}c`),n.stumpings>0&&i.push(`${n.stumpings}st`),n.runOuts>0&&i.push(`${n.runOuts}ro`),e.push(i.join(" "))}return e.length>0?e.join(" · "):"Selected XI"}function b3(n){const{format:e,scorecard:t}=n,i=n.fixtureId??null,a=n.seasonNumber??null,o=n.sourceCompletionSha256??null,r=n.events??n.archive?.events,c={...n.participantTeamByPlayerId??{}},u=new Map,p=(f,R)=>{let F=u.get(f);return F||(F={playerId:f,teamId:R,runs:0,ballsFaced:0,fours:0,sixes:0,batted:!1,notOutWithRuns:!1,wickets:0,runsConceded:0,legalBalls:0,maidens:0,bowled:!1,catches:0,stumpings:0,runOuts:0},u.set(f,F)),c[f]=F.teamId,F};for(const f of t.innings){for(const[R,F]of Object.entries(f.batting)){const $=p(R,f.battingTeamId);(F.ballsFaced>0||F.dismissed||F.runs>0)&&($.batted=!0,$.runs+=F.runs,$.ballsFaced+=F.ballsFaced,$.fours+=F.fours,$.sixes+=F.sixes,!F.dismissed&&F.runs>0&&($.notOutWithRuns=!0))}for(const[R,F]of Object.entries(f.bowling)){const $=p(R,f.bowlingTeamId);(F.legalBalls>0||F.runsConceded>0||F.wickets>0)&&($.bowled=!0,$.wickets+=F.wickets,$.runsConceded+=F.runsConceded,$.legalBalls+=F.legalBalls,$.maidens+=F.maidens)}}const S=!r&&n.fieldingDigest?f3(n.fieldingDigest):h3(r,c);for(const[f,R]of S.byPlayer.entries()){const F=p(f,R.teamId);F.catches+=R.catches,F.stumpings+=R.stumpings,F.runOuts+=R.runOuts}const h=S.evaluated?"ARCHIVE_EVENTS":"SCORECARD_NOT_ATTRIBUTABLE";if(t.result.kind==="NO_RESULT"||u.size===0)return{record:ma.parse({awardVersion:wt,awardCategory:"PLAYER_OF_THE_MATCH",awardProvenance:"GAME_AWARD",format:e,matchId:t.matchId,fixtureId:i,seasonNumber:a,sourceCompletionSha256:o,status:"NO_RESULT_NOT_AWARDED",winnerPlayerId:null,winnerTeamId:null,fromWinningTeam:null,fromLosingTeam:!1,scoreTotalX100:null,components:null,fieldingSourceStatus:h,explanationText:"No Player of the Match awarded because the fixture finished as a no-result without a completed competitive outcome.",formulaSummary:Cc,candidates:[]}),allCandidates:[]};const A=t.result.kind==="WIN"?t.result.winnerTeamId:null,N=t.result.kind==="WIN"&&A!==null,y=[...u.values()].map(f=>{const R=E3(f,e),F=S3(f,e),$=_3(f),D=A!==null&&f.teamId===A,G=D?500:0,M=R+F+$+G;return{playerId:f.playerId,teamId:f.teamId,battingPointsX100:R,bowlingPointsX100:F,fieldingPointsX100:$,resultBonusX100:G,totalPointsX100:M,fromWinningTeam:D,summaryLine:v3(f)}}).sort((f,R)=>{if(R.totalPointsX100!==f.totalPointsX100)return R.totalPointsX100-f.totalPointsX100;const F=f.battingPointsX100+f.bowlingPointsX100+f.fieldingPointsX100,$=R.battingPointsX100+R.bowlingPointsX100+R.fieldingPointsX100;return $!==F?$-F:f.fromWinningTeam!==R.fromWinningTeam?f.fromWinningTeam?-1:1:ur(f.playerId,R.playerId)}),L=y[0],E=N&&L.teamId!==A,T=n.playerNames?.[L.playerId]??L.playerId,g=n.teamNames?.[L.teamId]??L.teamId,I=E?" (standout performance from the losing side)":"",_=h==="SCORECARD_NOT_ATTRIBUTABLE"?" Attributable fielding points unavailable because delivery event archive was not attached.":"";return{record:ma.parse({awardVersion:wt,awardCategory:"PLAYER_OF_THE_MATCH",awardProvenance:"GAME_AWARD",format:e,matchId:t.matchId,fixtureId:i,seasonNumber:a,sourceCompletionSha256:o,status:"AWARDED",winnerPlayerId:L.playerId,winnerTeamId:L.teamId,fromWinningTeam:N?L.fromWinningTeam:null,fromLosingTeam:E,scoreTotalX100:L.totalPointsX100,components:{battingPointsX100:L.battingPointsX100,bowlingPointsX100:L.bowlingPointsX100,fieldingPointsX100:L.fieldingPointsX100,resultBonusX100:L.resultBonusX100},fieldingSourceStatus:h,explanationText:`${T} (${g}${I}) awarded Player of the Match with ${(L.totalPointsX100/100).toFixed(2)} pts — ${L.summaryLine}.${_}`,formulaSummary:Cc,candidates:y.slice(0,5)}),allCandidates:y}}function T3(n){return b3(n).record}const so="LC_NEW_GAME_WORLD_COPY_V1",Si=Nn();function R3(n,e){if(Si.hash(e)!==Fn.worldCanonicalSha256)throw new Error("The original world does not match its accepted hash.");const t=Vi(n,["stock"],e.rulesIds);if([...t.players,...t.teams,...t.grounds].map(o=>o.name).some(o=>o.trim()!==o||o.length===0||[...o].some(r=>{const c=r.codePointAt(0);return c<32||c>=127&&c<=159})))throw new Error("Names must have 1 to 80 characters, with no control characters or surrounding spaces.");const a=structuredClone(t);if(a.packId=e.packId,a.players.length!==e.players.length||a.teams.length!==e.teams.length||a.grounds.length!==e.grounds.length)throw new Error("This editor cannot add or remove players, teams or grounds.");if(a.players.forEach((o,r)=>{o.name=e.players[r].name}),a.teams.forEach((o,r)=>{o.name=e.teams[r].name,o.colours=[...e.teams[r].colours]}),a.grounds.forEach((o,r)=>{o.name=e.grounds[r].name}),pn(a)!==pn(e))throw new Error("Only names and team colours can change in this editor.");return t}function L3(n,e){const t=R3(n,e);t.packId=e.packId;const i=Si.hash({copyVersion:so,baseWorldCanonicalSha256:Fn.worldCanonicalSha256,world:t});return t.packId=`world-edit-${i}`,bt.parse({copyVersion:so,baseWorldCanonicalSha256:Fn.worldCanonicalSha256,worldCanonicalSha256:Si.hash(t),world:t})}function kc(n,e){if(!n||typeof n!="object"||!("copyVersion"in n)||n.copyVersion!==so)throw new Error("Unsupported world copy version.");const t=bt.parse(n);if(t.baseWorldCanonicalSha256!==Fn.worldCanonicalSha256)throw new Error("The world copy has an unsupported base world.");if(Si.hash(t.world)!==t.worldCanonicalSha256)throw new Error("The world copy hash does not match its contents.");const i=L3(t.world,e);if(pn(t)!==pn(i))throw new Error("The world copy identity does not match its contents.");return t}const co="LC_T20_UI_V2",Mn=Object.freeze({engine:"LC_T20_MATCH_V1",eventChain:"LC_T20_EVENT_CHAIN_V1",worldHash:"f4cbe33f4a2ea41385143cc03ab6d64e94a356f8af75e30483a68de87bdca252",rulesHash:"7c67aec8e3aef8be7b849775d83bad64847338e03326848ec1f1d0d99c6fa745",modelHash:"d47d5caca955b7a374b0052d712b1674bca6d855e222194ce9f0587d8580b7ab",stagePackHash:"34efa3037702e44a134ea38b414eab3e97c6f79f10b3e5458bc2ab05412e5d7a"}),Ht=Object.freeze({engine:"LC_ODI_MATCH_V1",eventChain:"LC_ODI_EVENT_CHAIN_V1",worldHash:Mn.worldHash,rulesHash:"81f8ec39a793e3761dac2d477a7fc7d4981df2e69b262e88160cb93141c28ee5",modelHash:Mn.modelHash,stagePackHash:Mn.stagePackHash}),Mt=Object.freeze({engine:"LC_RED5_MATCH_V1",eventChain:"LC_RED5_EVENT_CHAIN_V1",worldHash:Mn.worldHash,rulesHash:"819b388b1947f71c6228b21680687472760bfcf4a872f0f41cc9508e65928800",modelHash:Mn.modelHash,stagePackHash:Mn.stagePackHash});Object.freeze({engine:Mt.engine,eventChain:Mt.eventChain,random:"SHA256_COUNTER_V1",model:"synthetic-alpha-01",modelHash:Mt.modelHash,rules:"LC_RED5_01",rulesHash:Mt.rulesHash,worldHash:Mt.worldHash}),Object.freeze({engine:Mn.engine,eventChain:Mn.eventChain,random:"SHA256_COUNTER_V1",model:"synthetic-alpha-01",modelHash:Mn.modelHash,rules:"LC_T20_01",rulesHash:Mn.rulesHash,worldHash:Mn.worldHash}),Object.freeze({engine:Ht.engine,eventChain:Ht.eventChain,random:"SHA256_COUNTER_V1",model:"synthetic-alpha-01",modelHash:Ht.modelHash,rules:"LC_ODI_01",rulesHash:Ht.rulesHash,worldHash:Ht.worldHash});const bn={version:m(co),requestId:w().regex(/^ui-[0-9]+$/),expectedRevision:k().int().nonnegative()},_i={saveId:w().min(1).max(160),seasonId:w().min(1).max(128),scheduleSha256:w().regex(/^[a-f0-9]{64}$/),fixtureId:w().min(1).max(128),fixtureOrdinal:k().int().min(0).max(55),roundNumber:k().int().min(1).max(14),matchDayDate:Q(),homeTeamId:w().min(1).max(128),awayTeamId:w().min(1).max(128),groundId:w().min(1).max(128),matchId:w().min(1).max(128),matchGameId:w().min(1).max(128),matchSeed:w().min(1).max(256),selections:wn([Hn,Hn]),careerStateSha256:w().regex(/^[a-f0-9]{64}$/),managedTeamId:w().min(1).max(128).optional()},Bc=An("launchVersion",[d({..._i,launchVersion:m("LC_CAREER_USER_MATCH_LAUNCH_V1")}),d({..._i,launchVersion:m("LC_CAREER_USER_MATCH_LAUNCH_V2"),worldCopy:bt}),d({..._i,launchVersion:m("LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"),rosterPack:Se}),d({..._i,launchVersion:m("LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"),rosterPack:Se,worldCopy:bt.optional()})]),A3=An("type",[d({...bn,type:m("BOOT"),fresh:H().optional(),careerFixture:Bc.nullable().optional()}),d({...bn,type:m("START"),format:O(["T20","ODI","RED_BALL"]).default("T20"),selections:wn([Hn,Hn]),groundId:w().min(1),careerFixture:Bc.nullable().optional(),worldCopy:bt.nullable().optional(),rosterPack:Se.nullable().optional()}),d({...bn,type:m("COMMAND"),origin:O(["HUMAN","AI"]),command:Vn([Sr,eg,rg])}),d({...bn,type:m("AI_STEP"),clubStyle:H().optional(),matchAware:H().optional(),teamId:w().min(1).max(128),delegated:H().optional(),redBallProfile:ca.optional()}),d({...bn,type:m("SET_DELEGATION"),teamId:w().min(1).max(128),expectedDelegationRevision:k().int().nonnegative(),categories:v(ts).max(10).refine(n=>new Set(n).size===n.length),redBallProfile:ca.optional()}),d({...bn,type:m("VERIFY")}),d({...bn,type:m("CHECK_SEEDED_WEATHER")}),d({...bn,type:m("REBUILD_ANALYTICS")}),d({...bn,type:m("CANCEL_ANALYTICS"),targetRequestId:w().regex(/^ui-[0-9]+$/)}),d({...bn,type:m("PREVIEW_DIAGNOSTIC"),includeSeed:H().optional()}),d({...bn,type:m("EXPORT_DIAGNOSTIC"),sha256:w().regex(/^[a-f0-9]{64}$/)}),d({...bn,type:m("LIST_SAVES")}),d({...bn,type:m("MANUAL_SAVE"),title:w().trim().min(1).max(80)}),d({...bn,type:m("LOAD_SAVE"),saveId:w().min(1).max(160)}),d({...bn,type:m("DELETE_SAVE"),saveId:w().min(1).max(160)}),d({...bn,type:m("EXPORT_SAVE"),saveId:w().min(1).max(160).nullable()}),d({...bn,type:m("IMPORT_SAVE"),archive:Qu(Uint8Array)}),d({...bn,type:m("SUPER_OVER"),action:An("kind",[d({kind:m("START")}),d({kind:m("COMMAND"),command:pa}),d({kind:m("AI"),teamId:w().min(1).max(128)})])}),d({...bn,type:m("TOURNAMENT_START"),format:O(["T20","ODI"]),runId:w().min(1).max(128),runSeed:w().min(1).max(128),fixture:LI,rosterPack:Se.optional(),selections:wn([Hn,Hn]).optional()}),d({...bn,type:m("SCENARIO_START"),scenarioId:w().min(1).max(128)}),d({...bn,type:m("RECOVER_MANAGED")}),d({...bn,type:m("ABANDON_MANAGED")}),d({...bn,type:m("RETRY_WRITER")}),d({...bn,type:m("RELEASE_WRITER")})]);function O3(n,e,t,i=()=>({gameId:"human-exhibition",matchId:"human-t20"})){const{world:a}=Fa(n,e),o={teams:a.teams.map(V=>{const P=V.squadIds.map(Z=>a.players.find(In=>In.playerId===Z)),j=P.find(Z=>Z.role==="KEEPER"),tn=P.filter(Z=>Z.playerId!==j.playerId&&mt(Z)).slice(0,6),U=[j,...tn,...P.filter(Z=>Z!==j&&!tn.includes(Z))].slice(0,11);return{id:V.teamId,name:V.name,players:P.map(Z=>({id:Z.playerId,name:Z.name,role:Z.role,style:Z.bowlingStyle,canBowl:mt(Z),batHand:Z.batHand})),suggested:{teamId:V.teamId,playerIds:U.map(Z=>Z.playerId),captainId:U[0].playerId,keeperId:j.playerId}}}),grounds:a.grounds.map(V=>({id:V.groundId,name:V.name,seamBp:V.pitchPrior.seamBp,turnBp:V.pitchPrior.turnBp}))};let r=null,c=null,u=null,p=a;function S(V){if(c&&V){const P=kc(V,a).world,j=new Map(P.teams.map(Z=>[Z.teamId,Z.name])),tn=new Map(P.grounds.map(Z=>[Z.groundId,Z.name])),U=new Map(P.players.map(Z=>[Z.playerId,Z.name]));p={...c.world,teams:c.world.teams.map(Z=>{const In=j.get(Z.teamId);return In?{...Z,name:In}:Z}),grounds:c.world.grounds.map(Z=>{const In=tn.get(Z.groundId);return In?{...Z,name:In}:Z}),players:c.world.players.map(Z=>{const In=U.get(Z.playerId);return In?{...Z,name:In}:Z})};return}p=c?.world??(V?kc(V,a).world:a)}function h(V){const P=V?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V2"?V.worldCopy:V?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE"?V.worldCopy??null:null;S(P),u=V}const A=new Map,N=[],y=V=>ne(se(V)),L=x1(2);let E=null,T=-1,g=null,I=null,_=null,C=null,f=[],R=[];function F(){if(!r)return null;const V=r,P=V.core,j=P.innings[P.activeInningsIndex],tn=j?.innings;L.update(V.events);const U=P.phase==="COMPLETE"?hi(V):null,Z=Object.fromEntries(V.setup.teams.flatMap(X=>X.xi.map(hn=>[hn.playerId,p.players.find(Rn=>Rn.playerId===hn.playerId)?.name??hn.name]))),In=X=>p.teams.find(hn=>hn.teamId===X)?.name??"",En=P.phase==="TOSS"?V.setup.teams[0].teamId:P.phase==="AWAITING_INNINGS"?P.tossWinnerId:P.phase==="AWAITING_BATTER"?tn.battingTeamId:P.phase==="AWAITING_BOWLER"?tn.bowlingTeamId:null,Le={TOSS:`${In(En)}: call the toss`,AWAITING_INNINGS:`${In(P.tossWinnerId)} won the toss: choose bat or bowl`,AWAITING_BATTER:`${In(En)}: select ${tn?.northBatterId===null&&tn.southBatterId===null?"the opening batter":"the next batter"}`,AWAITING_BOWLER:`${In(En)}: select a bowler`,READY:"Ready: set tactics or advance play",COMPLETE:"Match complete: review the scorecard"},Ae=(V.setup.teams.find(X=>X.teamId===En)?.xi??[]).map(X=>{let hn="";P.phase==="AWAITING_BATTER"&&(hn=j.batting[X.playerId].dismissed?"Already dismissed":[tn.northBatterId,tn.southBatterId].includes(X.playerId)?"Already batting":""),P.phase==="AWAITING_BOWLER"&&(hn=X.playerId===j.keeperId?"Designated keeper":X.bowlingStyle===null?"Not a bowler":tn.previousOverBowlerId===X.playerId?"Bowled the previous over":j.bowling[X.playerId].legalBalls>=24?"Four-over limit reached":"");const{power:Rn,rotation:vi,defence:Ve}=X.skills.T20;return{id:X.playerId,name:Z[X.playerId]??X.name,reason:hn,...P.phase==="AWAITING_BATTER"?{batting:{power:Rn,rotation:vi,defence:Ve}}:{}}});if(P.phase==="AWAITING_BOWLER"&&j&&tn){const X=V.setup.teams.find(Rn=>Rn.teamId===En)?.xi??[],hn=B1(X.map(Rn=>({id:Rn.playerId,eligible:Rn.playerId!==j.keeperId&&Rn.bowlingStyle!==null,legalBalls:j.bowling[Rn.playerId]?.legalBalls??0})),Math.ceil((120-tn.legalBalls)/6),24);for(const Rn of Ae)!Rn.reason&&hn.has(Rn.id)&&(Rn.reason=hn.get(Rn.id))}let Ie=P.phase==="COMPLETE"?"Match complete":P.phase!=="READY"?"Complete the next decision first":"";if(P.phase==="READY"&&j)try{const X=tn.strikerEnd==="NORTH"?tn.northBatterId:tn.southBatterId,hn=V.setup.teams.flatMap(Rn=>Rn.xi).find(Rn=>Rn.playerId===X);gt(P.fieldSlots,j.outfieldIds,hn.batHand,tn.legalBalls)}catch{Ie="Field is invalid for this striker. Apply a legal named field before advancing."}const Oe=P.result,Tn=Object.fromEntries(V.setup.teams.flatMap(X=>X.xi.map(hn=>[hn.playerId,hn.batHand]))),Me=p.grounds.find(X=>X.groundId===V.setup.ground.groundId)?.name??V.setup.ground.name;if(E!==V||T!==V.revision||g!==p){const X=Object.fromEntries(V.setup.teams.map(hn=>[hn.teamId,In(hn.teamId)]));f=a3({format:"T20",events:V.events,playerNames:Z,teamNames:X,teamIds:[V.setup.teams[0].teamId,V.setup.teams[1].teamId],groundName:Me,presentationKey:`lcxxvi-commentary:T20:${V.setup.matchId}`}).entries,R=m3({format:"T20",matchId:V.setup.matchId,commentaryEntries:f}).cues,I=W1({format:"T20",phase:P.phase,innings:P.innings,activeIndex:P.activeInningsIndex,events:V.events,names:Z,pitch:P.pitch,fatigueBpByPlayerId:P.fatigueBp,activeBattingPlans:P.battingPlans,activeBowlingPlan:P.bowlingPlan,activeFieldSlots:P.fieldSlots,outfieldIds:j?.outfieldIds??[],bowlerVariationsByPlayerId:Object.fromEntries(V.setup.teams.flatMap(hn=>hn.xi.map(Rn=>[Rn.playerId,Rn.variations])))}),_=q1({format:"T20",phase:P.phase,innings:P.innings,activeIndex:P.activeInningsIndex,fieldSlots:P.fieldSlots,events:V.events,names:Z,hands:Tn}),E=V,T=V.revision,g=p}const ce=f,xn=P.phase==="COMPLETE"&&Oe?Oe.kind==="TIE"?"Match tied":`${In(Oe.winnerTeamId)} won by ${Oe.marginRuns??Oe.marginWickets} ${Oe.marginType?.toLowerCase()}`:null;return{format:"T20",fatigueBp:{...P.fatigueBp},captainNotes:Object.fromEntries(V.setup.teams.map(X=>[X.teamId,w3(V.commands,X.teamId,Z)])),revision:V.revision,phase:P.phase,nextDecision:Le[P.phase]??P.phase,decisionTeamId:En,teams:V.setup.teams.map(X=>({id:X.teamId,name:In(X.teamId),captainId:X.captainId,keeperId:X.keeperId,playerIds:[...X.playerIds],...p.packId!==a.packId?{colours:[...p.teams.find(hn=>hn.teamId===X.teamId).colours]}:{}})),names:Z,hands:Tn,ground:p.grounds.find(X=>X.groundId===V.setup.ground.groundId)?.name??V.setup.ground.name,innings:structuredClone(P.innings),activeIndex:P.activeInningsIndex,candidates:Ae,bowlingPlan:structuredClone(P.bowlingPlan),battingPlans:structuredClone(P.battingPlans),fieldSlots:structuredClone(P.fieldSlots),positions:di.positions.map(X=>X.slotId),matchId:V.setup.matchId,advanceReason:Ie,commentary:ce,audioCues:R,scorecard:U,analytics:U?L.snapshot(U):null,tacticalAssistant:I,fieldPresentation:_,matchAward:P.phase==="COMPLETE"&&U?C??=T3({format:"T20",scorecard:U,events:V.events,playerNames:Z,teamNames:Object.fromEntries(p.teams.map(X=>[X.teamId,X.name]))}):null,resultText:xn,eventCount:V.events.length,lastEventHash:V.lastEventHash}}function $(){if(!u||u.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"||!r||r.core.phase!=="COMPLETE")return null;const V=hi(r),P=y(V),j=qh({seasonId:u.seasonId,fixtureId:u.fixtureId,matchId:u.matchId,matchDayDate:u.matchDayDate,session:r}),tn=y({source:"USER_MATCH",seasonId:u.seasonId,fixtureId:u.fixtureId,matchId:u.matchId,scorecardSha256:P,finalEventHash:r.lastEventHash});return{resultVersion:"LC_CAREER_USER_MATCH_RESULT_V1",seasonId:u.seasonId,scheduleSha256:u.scheduleSha256,fixtureId:u.fixtureId,matchId:u.matchId,fixtureOrdinal:u.fixtureOrdinal,roundNumber:u.roundNumber,matchDayDate:u.matchDayDate,homeTeamId:u.homeTeamId,awayTeamId:u.awayTeamId,selectedTeams:[structuredClone(u.selections[0]),structuredClone(u.selections[1])],scorecard:V,scorecardSha256:P,finalEventHash:r.lastEventHash,sourceCompletionSha256:tn,conditionDelta:j,completedSession:structuredClone(r)}}function D(){if(!r||r.core.phase!=="COMPLETE")throw new Error("Complete the match before verifying its final scorecard.");const V=c?r1(r,c):Wh(r.setup,r.events,qs(r)),P=hi(r);if(y(hi(V))!==y(P))throw new Error("Replay scorecard mismatch.");return c||Uh(r),{revision:r.revision,eventsSha256:y(r.events),scorecardSha256:y(P),eventCount:r.events.length,replay:!0,resimulation:!0,humanRequests:N.filter(j=>j.origin==="HUMAN").length,systemAutopilotRequests:N.filter(j=>j.origin==="AI").length}}function G(V){if(!r)throw new Error("Start a match first.");const P=V.command;if(P.kind==="CONFIRM_TEAMS")throw new Error("Team confirmation is only available through match setup.");if(P.commandId!==V.requestId||P.expectedRevision!==V.expectedRevision)throw new Error("Command envelope mismatch.");const j=r.core.innings[r.core.activeInningsIndex],tn="teamId"in P.payload?P.payload.teamId:P.kind==="SET_BATTING_PLAN"?j?.innings.battingTeamId:j?.innings.bowlingTeamId,U=P.kind==="ADVANCE"?"SYSTEM":`USER:${tn}`;if(P.actorId!==(V.origin==="AI"?P.kind==="ADVANCE"?"SYSTEM":`AI:${tn}`:U))throw new Error("Only human-owned or explicitly delegated AI-owned commands may change the team decision.");r=c?za(r,P).session:Bt(r,P).session,N.push({requestId:V.requestId,origin:V.origin,commandKind:P.kind,engineActorId:P.actorId})}function M(V,P=null){c=P,r=c?tc(V,c):Gh(V,n,e),h(null),A.clear(),N.splice(0,N.length,...r.commands.map(j=>({requestId:j.commandId,origin:j.actorId.startsWith("AI:")?"AI":"HUMAN",commandKind:j.kind,engineActorId:j.actorId})))}function q(){return r?structuredClone(r):null}function J(V,P=null){return{version:co,requestId:V,revision:r?.revision??0,pins:Mn,catalog:r?null:structuredClone(o),view:F(),error:P,verification:null,careerResult:$(),...u?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"&&r?.core.phase==="COMPLETE"?{rosterCareerSession:structuredClone(r)}:{}}}return{restore:M,setWorldCopy:S,snapshot:q,boundFixture:()=>u,currentResponse:J,handle(V){let P="invalid",j=null,tn=null,U;try{U=A3.parse(V),P=U.requestId;const In=A.get(P);if(In){if(In.request!==JSON.stringify(U))throw new Error("Request ID already used with different content.");return structuredClone(In.response)}if(U.type==="BOOT"&&U.careerFixture){if(r&&(r.setup.gameId!==U.careerFixture.matchGameId||r.setup.matchId!==U.careerFixture.matchId))throw new Error("Recovered match does not match the scheduled career fixture.");h(U.careerFixture)}if(U.type!=="BOOT"&&U.expectedRevision!==(r?.revision??0))throw new Error("Stale revision. Review the current decision and try again.");if(U.type==="START"){if(U.format!=="T20")throw new Error("T20 controller received a non-T20 start.");if(r)throw new Error("A match is already in progress.");if(U.careerFixture&&U.worldCopy)throw new Error("A career match cannot replace its world copy.");const En=U.careerFixture&&(U.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"||U.careerFixture.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V4_LIFECYCLE")?U.careerFixture:null;if(U.rosterPack&&(U.worldCopy||U.careerFixture&&!En))throw new Error("An imported roster cannot replace a career or edited world.");if(En&&JSON.stringify(U.rosterPack)!==JSON.stringify(En.rosterPack))throw new Error("Career roster binding mismatch.");if(c=U.rosterPack??null,h(U.careerFixture??null),U.careerFixture||S(U.worldCopy??null),u){if(u.matchId!==U.careerFixture?.matchId||u.groundId!==U.groundId)throw new Error("Career fixture binding mismatch.");if(u.homeTeamId!==U.selections[0].teamId||u.awayTeamId!==U.selections[1].teamId)throw new Error("Career fixture team order mismatch.");if(JSON.stringify(u.selections)!==JSON.stringify(U.selections))throw new Error("Career fixture XI snapshot mismatch.")}const Le=u?{gameId:u.matchGameId,matchId:u.matchId}:i();if(c){const Ae=Ga(c,{...Le,seed:u?u.matchSeed:t(),format:"T20",selection:{groundId:U.groundId,teams:U.selections}});r=za(Ae,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:P,expectedRevision:0}).session,h(U.careerFixture??null),U.careerFixture||(p=c.world),N.push({requestId:P,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}else{const Ae=Ha({setupVersion:"LC_T20_SETUP_V1",setup:{schemaVersion:"1.0.0",...Le,format:"T20",worldPackId:Fn.worldPackId,rulesId:"LC_T20_01",modelId:"synthetic-alpha-01",randomId:"SHA256_COUNTER_V1",seed:u?u.matchSeed:t(),teamIds:U.selections.map(Tn=>Tn.teamId),groundId:U.groundId,capabilities:{limitedOversRain:!1,superOver:!1,injuries:!1,prediction:!1}},worldFileSha256:Fn.worldFileSha256,worldCanonicalSha256:Mn.worldHash,rulesHash:Mn.rulesHash,modelHash:Cn,stagePackHash:Kn,selectedTeams:U.selections},n,e),Ie=Ii(Ae);for(const[Tn,Me]of Object.entries(Mn))if(Ie.executionManifest[Tn]!==Me)throw new Error("Worker build identity mismatch.");r=Bt(Ie,{kind:"CONFIRM_TEAMS",payload:{},actorId:"SYSTEM",commandId:P,expectedRevision:0}).session,N.push({requestId:P,origin:"HUMAN",commandKind:"CONFIRM_TEAMS",engineActorId:"SYSTEM"})}}else U.type==="COMMAND"?G(U):U.type==="VERIFY"&&(tn=D())}catch(In){j=In instanceof Error&&In.name!=="ZodError"?In.message:"Invalid request. Check selections, required fields and supported settings."}const Z={version:co,requestId:P,revision:r?.revision??0,pins:Mn,catalog:r?null:structuredClone(o),view:F(),error:j,verification:tn,careerResult:$(),...u?.launchVersion==="LC_CAREER_USER_MATCH_LAUNCH_V3_ROSTER"&&r?.core.phase==="COMPLETE"?{rosterCareerSession:structuredClone(r)}:{}};return U&&!j&&A.set(P,{request:JSON.stringify(U),response:structuredClone(Z)}),Z}}}function w3(n,e,t){const i=n.filter(p=>p.actorId===`AI:${e}`),a=i.filter(p=>p.kind==="SET_BOWLING_PLAN").slice(-5),o=a.filter(p=>p.payload.length==="YORKER").length;if(o>=2)return`Called for yorkers in ${o} of the last ${a.length} bowling plan changes.`;const r=i.filter(p=>p.kind==="SET_BOWLER").slice(-6),c=r.at(-1)?.payload.bowlerId,u=r.filter(p=>p.payload.bowlerId===c).length;return c&&u>=2?`Picked ${t[c]} for ${u} of the last ${r.length} overs assigned.`:""}const He=n=>`${Math.floor(n/6)}${n%6?`.${n%6}`:""}`;function N3(n,e){const t=O3(n,e,()=>"rain-catalog").currentResponse("ui-0").catalog;if(!t)throw new Error("RAIN_CATALOGUE_UNAVAILABLE");let i=null;const a=E=>t.teams.find(T=>T.id===E)?.name??E,o=(E,T)=>E.teams.flatMap(g=>g.xi).find(g=>g.playerId===T)?.name??T;function r(E){return{format:E.rulesId==="LC_T20_RAIN_01"?"T20":"ODI",...E}}function c(E,T){const g=T.lastDelivery;if(!g)return null;const I=Object.values(g.extras).reduce((C,f)=>C+f,0),_=[];return g.dismissal&&_.push(`OUT: ${o(E,g.dismissal.playerId)}`),g.batRuns&&_.push(`${g.batRuns} run${g.batRuns===1?"":"s"}`),g.extras.wides&&_.push(`${g.extras.wides} wide${g.extras.wides===1?"":"s"}`),g.extras.noBalls&&_.push("no-ball"),g.extras.byes&&_.push(`${g.extras.byes} bye${g.extras.byes===1?"":"s"}`),g.extras.legByes&&_.push(`${g.extras.legByes} leg-bye${g.extras.legByes===1?"":"s"}`),!_.length&&!I&&_.push("No run"),`${o(E,g.bowlerId)} to ${o(E,g.strikerId)}: ${_.join(", ")}.`}function u(E){const T=E.result;if(!T)return null;const g=T.method==="RESOURCE_TABLE"?" (rain rules)":"";return T.kind==="NO_RESULT"?"No result: rain ended play before the minimum overs.":T.kind==="TIE"?`Match tied${g}.`:`${a(T.winnerTeamId)} won by ${T.margin} ${T.marginType==="RUNS"?T.margin===1?"run":"runs":T.margin===1?"wicket":"wickets"}${g}.`}const p=E=>E==="LBW"?"leg before":"caught behind",S=E=>E?` Ball tracking: pitching ${E.pitching==="IN"?"in line":E.pitching==="OUT"?"outside leg":"umpire's call"}, impact ${E.impact==="IN"?"in line":E.impact==="OUT"?"outside the line":"umpire's call"}, wickets ${E.wickets==="IN"?"hitting":E.wickets==="OUT"?"missing":"umpire's call"}.`:"";function h(E,T){const g=`${o(E,T.strikerId)} (${p(T.kind)}, off ${o(E,T.bowlerId)})`,I=T.onFieldOut?"given out":"given not out",_=a(T.reviewTeamId);switch(T.outcome){case"NOT_REVIEWED":return`${g}: ${I}; ${_} did not review.`;case"NO_REVIEWS_LEFT":return`${g}: ${I}; ${_} had no reviews left.`;case"OVERTURNED":return`${g}: ${I}; ${_} reviewed and the decision was overturned.${S(T.tracking)}`;case"STRUCK_DOWN":return`${g}: ${I}; ${_} reviewed and lost the review.${S(T.tracking)}`;case"UMPIRES_CALL":return`${g}: ${I}; ${_} reviewed: umpire's call, so the decision stands and the review is kept.${S(T.tracking)}`}}function A(E,T,g){const I=T.innings.map((D,G)=>{const M=D.innings,q=M.strikerEnd==="NORTH"?M.northBatterId:M.southBatterId;return{battingTeamId:M.battingTeamId,battingName:a(M.battingTeamId),score:`${M.runs}/${M.wickets}`,overs:He(M.legalBalls),allocationOvers:He(T.allocations[G]),target:G===1?T.target:null,batters:[M.northBatterId,M.southBatterId].filter(J=>J!==null).map(J=>({id:J,name:o(E,J),runs:D.batting[J].runs,balls:D.batting[J].ballsFaced,onStrike:J===q})),bowler:M.bowlerId?{id:M.bowlerId,name:o(E,M.bowlerId),figures:`${He(D.bowling[M.bowlerId].legalBalls)}-${D.bowling[M.bowlerId].runsConceded}-${D.bowling[M.bowlerId].wickets}`}:null}}),_=T.stoppages.map(D=>{const G=a(T.innings[D.inningsIndex].innings.battingTeamId),M=`${G} ${D.runs}/${D.wickets} after ${He(D.legalBalls)} overs`;if(D.terminal)return`Rain stopped play for good with ${M}.`;const q=`${He(D.ballsLost)} overs lost`;return D.inningsIndex===0?`Rain with ${M}: ${q}. Each side now has ${He(D.allocations[0])} overs.`:`Rain with ${M}: ${q}. ${G} now have ${He(D.allocations[1])} overs; revised target ${D.targetAfter}.`});let C=null;const f=T.innings[1];if(f&&T.phase!=="COMPLETE"&&T.stoppages.length){const D=G=>T.stoppages.filter(M=>M.inningsIndex===G&&!M.terminal).map(M=>({ballsBowled:M.legalBalls,wicketsLost:M.wickets,ballsLost:M.ballsLost}));C=ac({format:E.format,firstInningsRuns:T.innings[0].innings.runs,firstResources:fi(E.format,T.startAllocations[0],D(0)),secondResourcesAvailable:fi(E.format,T.startAllocations[1],D(1)),ballsLeft:T.allocations[1]-f.innings.legalBalls,wicketsLost:f.innings.wickets})}const R=Qa(E,T);let F=[];if(R?.decision==="BATTER"&&(F=Ja(E,T).map(D=>({id:D,name:o(E,D),detail:""}))),R?.decision==="BOWLER"){const D=T.innings[T.activeInningsIndex];F=qa(E,T).map(G=>({id:G,name:o(E,G),detail:`${He(D.bowling[G].legalBalls)} overs, ${D.bowling[G].runsConceded} runs, ${D.bowling[G].wickets} wickets`}))}let $=null;if(T.reviews){const D=T.reviews.pending,G=D?T.innings[T.activeInningsIndex].innings.battingTeamId===D.reviewTeamId:!1;$={left:E.teams.map(M=>({teamName:a(M.teamId),left:T.reviews.reviewsLeft[M.teamId]??0})),appeal:D?{text:`Appeal for ${p(D.kind)} against ${o(E,D.strikerId)}, off ${o(E,D.bowlerId)}: ${D.onFieldOut?"given OUT":"given NOT OUT"}.`,feeling:G?D.cue==="CONFIDENT"?`${o(E,D.strikerId)} is sure it was not out.`:`${o(E,D.strikerId)} is not sure.`:D.cue==="CONFIDENT"?"The bowler and keeper are convinced it was out.":"The bowler and keeper are not sure."}:null,log:T.reviews.log.map(M=>h(E,M))}}return{rules:{rain:T.weatherOff!==!0,reviews:T.reviews!==void 0},reviews:$,gameId:g.gameId,format:E.format,phase:T.phase,teams:E.teams.map(D=>({id:D.teamId,name:a(D.teamId)})),tossWinnerName:T.tossWinnerId?a(T.tossWinnerId):null,innings:I,stoppages:_,target:T.target,parNow:C,pending:R?{...R,teamName:a(R.teamId)}:null,options:F,lastBall:c(E,T),resultText:u(T)}}function N(){if(!i)throw new Error("No rain match is open.");const E=D1(i.setup,i.state,i.commands);return{record:E,view:A(i.setup,i.state,E)}}function y(E){const T=vs.parse(E);if(i&&i.setup.gameId===T.gameId&&i.commands.length===T.commands.length&&no(i.state)===T.stateSha256)return;const g=Sc(r(T),n,e),I=y1(g,T);i={setup:g,state:I,commands:[...T.commands]}}function L(E){const T=i;T.state=hc(T.setup,T.state,ba.parse(E)),T.commands.push(E)}return{teams:t.teams.map(E=>({id:E.id,name:E.name})),grounds:t.grounds.map(E=>({id:E.id,name:E.name})),start(E){const T=_=>{const C=t.teams.find(f=>f.id===_);if(!C)throw new Error("Unknown team.");return C.suggested};if(E.teamIds[0]===E.teamIds[1])throw new Error("Choose two different teams.");const g=Sc({...E,selectedTeams:[T(E.teamIds[0]),T(E.teamIds[1])]},n,e),I=E.rules??{rain:!0,reviews:!1};if(!I.rain&&!I.reviews)throw new Error("Choose rain, player reviews or both.");return i={setup:g,state:sc(g,I),commands:[]},N()},open(E){return y(E),N()},command(E,T){return y(E),L(T),N()},aiDecisions(E,T){y(E);const g=i;for(let I=0;I<50;I++){const _=Qa(g.setup,g.state);if(!_||_.teamId===T)break;L(fc(g.setup,g.state))}return N()},simulateToEnd(E){y(E);const T=i;for(let g=0;T.state.phase!=="COMPLETE"&&g<4e3;g++)L(fc(T.setup,T.state));return N()}}}const Vt=N3(new TextEncoder().encode(xc),Fc);self.onmessage=n=>{const e=n.data;let t;try{const i=e.type==="START"?Vt.start(e):e.type==="OPEN"?Vt.open(e.record):e.type==="COMMAND"?Vt.command(e.record,e.command):e.type==="AI"?Vt.aiDecisions(e.record,e.playerTeamId):Vt.simulateToEnd(e.record);t={id:e.id,match:i,error:null}}catch(i){t={id:e.id,match:null,error:i instanceof Error?i.message:"The rain match could not continue."}}self.postMessage(t)}})();
