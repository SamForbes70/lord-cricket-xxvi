@echo off
call "%~dp0Play-Lord-Cricket.bat" %*
