// Auto-generated deterministic offline shell for Lord Cricket XXVI (838f3fe740b35c16)
const CACHE_PREFIX = "lcxxvi-offline-";
const CACHE_NAME = CACHE_PREFIX + "838f3fe740b35c16";
const MAX_RETAINED_ENGINE_CACHES = 2;
const PRECACHE_URLS = ["/offline-manifest.json","/","/assets/aster-quay-R9AzvREm.webp","/assets/engineering-BrDsDFp9.css","/assets/engineering-e_dvEl1f.js","/assets/main-Dfznc4pp.css","/assets/main-O7K-xtjw.js","/assets/match.worker-S_wdYOBN.js","/assets/rain.worker-CCFThztl.js","/assets/reviews-NmJoXZz4.js","/assets/tournament.worker-dHEpQStG.js","/engineering.html","/index.html"];

self.addEventListener("install", event => {
  // Never call skipWaiting() automatically: updates are offered outside active transactions.
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(PRECACHE_URLS))
  );
});

self.addEventListener("activate", event => {
  event.waitUntil((
    async () => {
      const keys = (await caches.keys()).filter(k => k.startsWith(CACHE_PREFIX)).sort();
      if (keys.length > MAX_RETAINED_ENGINE_CACHES) {
        const stale = keys.slice(0, keys.length - MAX_RETAINED_ENGINE_CACHES).filter(k => k !== CACHE_NAME);
        await Promise.all(stale.map(k => caches.delete(k)));
      }
      await self.clients.claim();
    }
  )());
});

self.addEventListener("message", event => {
  if (event.data && event.data.type === "LCXXVI_APPLY_SAFE_UPDATE") {
    self.skipWaiting();
  }
});

self.addEventListener("fetch", event => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  event.respondWith((
    async () => {
      const cached = await caches.match(req, { ignoreSearch: req.mode === "navigate" });
      if (cached) return cached;
      try {
        const net = await fetch(req);
        if (net && net.ok && url.pathname.startsWith("/assets/")) {
          const cache = await caches.open(CACHE_NAME);
          cache.put(req, net.clone());
        }
        return net;
      } catch (err) {
        if (req.mode === "navigate") {
          const fallback = await caches.match(url.pathname === "/engineering.html" ? "/engineering.html" : "/index.html");
          if (fallback) return fallback;
        }
        throw err;
      }
    }
  )());
});
