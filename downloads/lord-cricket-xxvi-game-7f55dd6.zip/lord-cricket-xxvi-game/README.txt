LORD CRICKET XXVI - playable build
==================================

Offline cricket management game: persistent multi-season 8-club T20 career world (player lifecycle, youth academy,
contracts & budgets, tactical briefings, 2D live field, contextual commentary, optional procedural audio/narration,
historical statistics & leaderboards, match/season awards and career stories), scenario challenges, fictional
tournaments (user-made competitions, tours and auctions), and T20, ODI and five-day red-ball exhibitions with optional
super overs, rain-shortened matches and player reviews.

How to play on Windows (ZERO extra installs required on Windows 10/11)
  1. Extract this entire ZIP to a folder on your laptop (do not double-click inside the unextracted ZIP preview).
  2. Double-click Play-Lord-Cricket.bat (or start-game.bat).
     - Uses Node.js 18+ if installed, real Python 3 if installed, or automatically compiles and launches
       LordCricketXXVI.exe using Windows' built-in .NET Framework 4.x compiler (no downloads needed).
     - Opens http://127.0.0.1:4180/ in a standalone Edge/Chrome app window.
     - To stop a background server later, double-click Stop-Lord-Cricket.bat (or right-click the tray icon -> Quit Server).
     - Optional: double-click Build-Exe.bat to create LordCricketXXVI.exe directly.

How to play on Mac/Linux (needs Node.js 18+ or Python 3)
  Run ./start-game.sh (or: bash start-game.sh)

Where everything is, and a 30-minute test session: HOW-TO-PLAY.md in this folder.

Your saves live in your browser (IndexedDB), tied to http://127.0.0.1:4180. Use the game's Export buttons to keep
.lcxxvi backups.
