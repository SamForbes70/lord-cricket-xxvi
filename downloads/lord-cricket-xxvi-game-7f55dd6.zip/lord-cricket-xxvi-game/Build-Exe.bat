@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" ( echo .NET Framework 4.x csc.exe not found. & pause & exit /b 1 )
"%CSC%" /nologo /optimize+ /target:winexe /out:"%~dp0LordCricketXXVI.exe" /r:System.Windows.Forms.dll /r:System.Drawing.dll "%~dp0LordCricketLauncher.cs"
if errorlevel 1 ( pause & exit /b 1 )
echo Built LordCricketXXVI.exe successfully. Double-click LordCricketXXVI.exe to play.
